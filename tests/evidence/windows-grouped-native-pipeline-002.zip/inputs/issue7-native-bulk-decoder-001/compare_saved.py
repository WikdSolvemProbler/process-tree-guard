"""Saved-data full capture+decode comparison. No private DLL/Toolhelp calls."""
import argparse
import ctypes
import hashlib
import json
from pathlib import Path
import struct
import sys
import time
import types
import unittest

HERE=Path(__file__).resolve().parent
WIRE=struct.Struct("<III520s")
ORDERS=(("old","new"),("new","old"),("old","new"),("new","old"))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(value,message):
    if not value:raise ValueError(message)
def checked(path,pin):
    raw=path.read_bytes()
    require(sha(raw)==pin,"bound bytes differ: "+str(path))
    return raw
def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False).encode()

class NoWindowsCalls:
    """Per-module proxy; never changes the global ctypes package."""
    def __getattr__(self,name):
        if name in ("WinDLL","CDLL","OleDLL","PyDLL","windll","oledll","cdll","pydll"):
            raise AssertionError("library loading disabled in saved-data control")
        return getattr(ctypes,name)

class FixedClock:
    def __init__(self):self.calls=0
    def perf_counter_ns(self):
        value=1_000_000+self.calls
        self.calls+=1
        return value

def load(name,path,raw):
    module=types.ModuleType(name);module.__file__=str(path);sys.modules[name]=module
    exec(compile(raw,str(path),"exec"),module.__dict__)
    module.ctypes=NoWindowsCalls()
    return module

def execute(module,wire,header,returned=None):
    """Full unchanged snapshot() body with fresh allocation and a fixed shim."""
    clock=FixedClock()
    previous_time=module.time
    module.time=clock
    owner=module.NativeBulk.__new__(module.NativeBulk)
    owner.closed=False;owner.quarantined=False
    owner.module=1  # Sentinel only; constructor/load/close are never invoked.
    calls=0
    def shim(rows,capacity,out):
        nonlocal calls
        calls+=1
        require(calls==1 and capacity==4096 and len(rows)==4096,"shim called again/wrongbuffer")
        require(len(wire)<=ctypes.sizeof(rows),"fixture exceeds fixedbuffer")
        # Ordinary memory copy only, no Windows API/private DLL function.
        ctypes.memmove(ctypes.addressof(rows),wire,len(wire))
        native=ctypes.cast(out,ctypes.POINTER(module.Evidence)).contents
        for key,_ in module.Evidence._fields_:
            setattr(native,key,header[key])
        return header["status"] if returned is None else returned
    owner.call=shim
    try:
        try:
            result=owner.snapshot()
            outcome={"ok":True,"result":result}
        except Exception as error:
            outcome={"ok":False,"type":type(error).__name__,"message":str(error),
                     "evidence":getattr(error,"evidence",None)}
        require(calls==1,"did not execute exactly one shim")
        require(clock.calls==4,"unexpected internalclock schedule")
        return outcome
    finally:
        module.time=previous_time

def main(approved):
    deadline=time.perf_counter_ns()+15_000_000_000
    code=0;errors=[];measurements=[];adversarial=[];python_fact=None
    proposal=None;semantic_pin=None
    def check():
        if time.perf_counter_ns()>=deadline:raise TimeoutError("15-second saved-data control deadline")
    def bindings():
        checked(HERE/"proposal.json",approved)
        for name,pin in proposal["source_sha256"].items():checked(HERE/name,pin)
        for path,pin in proposal["reference_sha256"].items():checked(Path(path),pin)
        for path,pin in proposal["tool_sha256"].items():checked(Path(path),pin)
    with (HERE/"comparison-001.jsonl").open("x",encoding="utf-8") as output:
        def emit(kind,**values):
            print(json.dumps({"kind":kind,**values},ensure_ascii=True,allow_nan=False),file=output,flush=True)
        emit("context",proposal_sha256=approved,inner_seconds=15,outer_seconds=30,
             fixed_orders=ORDERS,private_dll_loads=0,native_snapshot_calls=0,benchmark_slots=0,
             scope="Saveddata/shim only: full snapshot() allocation+memoryshim+marshal+decode/evidence; no actual enumeration or native/endtoend speed inference",
             clocks="Only real wall/processCPU bookends around each full call; adapter internal timestamp clock fixed and equal; processCPU may be quantized",
             cold_warm="No explicit warmup or retry. FixedAB/BA/AB/BA order; first call may include ordinary cold code/allocator/codec effects, not a controlled cold-host claim")
        try:
            raw=checked(HERE/"proposal.json",approved);proposal=json.loads(raw)
            require(proposal["schema"]=="bulk-byte-decoder-proposal-v1"
                    and proposal["inner_seconds"]==15 and proposal["outer_seconds"]==30
                    and proposal["paired_orders"]==[list(x) for x in ORDERS],"unreviewed constants")
            bindings()
            old_path=Path(proposal["old_adapter_path"])
            old=load("baseline_bulk_adapter",old_path,checked(old_path,proposal["reference_sha256"][str(old_path).replace("\\","/")]))
            new=load("candidate_bulk_adapter",HERE/"bulk_snapshot_bytes.py",
                     checked(HERE/"bulk_snapshot_bytes.py",proposal["source_sha256"]["bulk_snapshot_bytes.py"]))
            modules={"old":old,"new":new}
            saved_raw=checked(Path(proposal["native_raw_path"]),proposal["native_raw_sha256"])
            saved=[json.loads(line) for line in saved_raw.splitlines()]
            selected=[row for row in saved if row["kind"]=="snapshot_observed"]
            require(len(selected)==1 and saved[-1]["kind"]=="terminal" and saved[-1]["qualified"] is True,
                    "qualified saved observation absent")
            observation=selected[0]
            header=observation["evidence"]["native"]
            require(header["count"]==524 and header["status"]==0,"fixed savedcount/status")
            wire=checked(HERE/"saved-wire-001.bin",proposal["source_sha256"]["saved-wire-001.bin"])
            expected_wire=b"".join(WIRE.pack(row["pid"],row["parent_pid"],row["name_units"],
                bytes.fromhex(row["name_utf16le_hex"])) for row in observation["evidence"]["raw_utf16_rows"])
            require(wire==expected_wire and len(wire)==header["count"]*532,"reconstructed fixed wire differs")
            emit("fixture",rows=header["count"],wire_bytes=len(wire),wire_sha256=sha(wire),
                 provenance="Reconstructed from saved raw UTF16prefix/PID/parent; zero tails justified by old accepted nulltail check and exact Csource, not original raw memory bytes",
                 preparation="Input assembly outside timing; full fresh4096-row allocation+shim copy and all output validation remain inside each snapshot() call")
            canonical_valid=None
            for pair,order in enumerate(ORDERS):
                outcomes={}
                for name in order:
                    check()
                    wall_begin=time.perf_counter_ns()
                    cpu_begin=time.process_time_ns()
                    outcome=execute(modules[name],wire,header)
                    cpu_end=time.process_time_ns()
                    wall_end=time.perf_counter_ns()
                    require(cpu_end>=cpu_begin and wall_end>=wall_begin,"bookend counter regression")
                    require(outcome["ok"],"valid saved fixture refused")
                    result=outcome["result"]
                    require(result[0]==observation["rows"] and result[1]==observation["upper_ticks"]
                            and result[2]["native"]==header
                            and result[2]["raw_utf16_rows"]==observation["evidence"]["raw_utf16_rows"],
                            "full output differs from saved semantic facts")
                    raw_result=canonical(outcome)
                    if canonical_valid is None:
                        canonical_valid=raw_result
                        with (HERE/"saved-semantic-output-001.json").open("xb") as f:f.write(raw_result+b"\n")
                        semantic_pin=sha(raw_result+b"\n")
                    require(raw_result==canonical_valid,"full old/new captured output differs")
                    outcomes[name]=raw_result
                    row={"pair":pair,"variant":name,"wall_begin_ns":wall_begin,"wall_end_ns":wall_end,
                         "cpu_begin_ns":cpu_begin,"cpu_end_ns":cpu_end,
                         "wall_ns":wall_end-wall_begin,"process_cpu_ns":cpu_end-cpu_begin,
                         "full_output_sha256":sha(raw_result),"matches_saved_facts":True}
                    measurements.append(row);emit("measured",**row)
                require(outcomes["old"]==outcomes["new"],"paired output mismatch")
            # Fixed adversarial byte/header controls, outside performance calls.
            variants=[]
            def variant(name,blob=None,changes=None,returned=None,valid=False):
                variants.append((name,wire if blob is None else bytes(blob),
                                 {**header,**(changes or {})},returned,valid))
            duplicate=bytearray(wire);duplicate[532:536]=duplicate[:4]
            variant("duplicate_pid",duplicate)
            zero_units=bytearray(wire);struct.pack_into("<I",zero_units,8,0)
            variant("zero_name_units",zero_units)
            long_units=bytearray(wire);struct.pack_into("<I",long_units,8,260)
            variant("unterminated_capacity",long_units)
            nul=bytearray(wire);nul[12:14]=b"\0\0"
            variant("embedded_utf16_nul",nul)
            units=struct.unpack_from("<I",wire,8)[0]
            for offset in (0,1):
                tail=bytearray(wire);tail[12+units*2+offset]=1
                variant("nonzero_tail_byte_"+str(offset),tail)
            unicode_wire=bytearray(wire);text="\u00df\U0001f600\ud800.EXE".encode("utf-16le","surrogatepass")
            struct.pack_into("<III520s",unicode_wire,0,*struct.unpack_from("<II",wire,0),len(text)//2,text)
            variant("casefold_and_surrogates",unicode_wire,valid=True)
            maximum=bytearray(wire);text=("A"*259).encode("utf-16le")
            struct.pack_into("<III520s",maximum,0,*struct.unpack_from("<II",wire,0),259,text)
            variant("maximum_terminated_name",maximum,valid=True)
            variant("native_status",changes={"status":3,"primary_error":5})
            variant("close_error_even_if_status_zero",changes={"close_error":5})
            variant("clock_error_even_if_status_zero",changes={"clock_error":5})
            variant("zero_count",changes={"count":0})
            variant("count_exceeds_capacity",changes={"count":4097})
            variant("zero_upper",changes={"upper_ticks":0})
            variant("qpc_regression",changes={"end_qpc":header["begin_qpc"]-1})
            variant("return_status_mismatch",returned=1)
            for name,blob,fields,returned,valid in variants:
                check()
                old_result=execute(old,blob,fields,returned)
                new_result=execute(new,blob,fields,returned)
                require(old_result["ok"] is valid and new_result["ok"] is valid,"wrong expected acceptance: "+name)
                require(canonical(old_result)==canonical(new_result),"full refusal/evidence mismatch: "+name)
                row={"case":name,"expected_accept":valid,"full_output_equal":True,
                     "old_output_sha256":sha(canonical(old_result)),
                     "new_output_sha256":sha(canonical(new_result)),
                     "reason":None if valid else old_result["message"]}
                adversarial.append(row);emit("adversarial",**row)
            # Reuse exact 11 pure tests against new source, no CEXE or DLL.
            previous=sys.modules.get("bulk_snapshot")
            sys.modules["bulk_snapshot"]=new
            try:
                test_path=Path(proposal["old_test_path"])
                tests=load("candidate_decoder_tests",test_path,
                           checked(test_path,proposal["reference_sha256"][str(test_path).replace("\\","/")]))
                with (HERE/"python-tests-001.log").open("x",encoding="utf-8") as log:
                    result=unittest.TextTestRunner(stream=log,verbosity=2).run(
                        unittest.defaultTestLoader.loadTestsFromModule(tests))
                python_fact={"tests":result.testsRun,"failures":len(result.failures),
                             "errors":len(result.errors),"skipped":len(result.skipped)}
                require(result.wasSuccessful() and result.testsRun==11 and not result.skipped,
                        "candidate puretests failed")
            finally:
                if previous is None:sys.modules.pop("bulk_snapshot",None)
                else:sys.modules["bulk_snapshot"]=previous
            emit("python_tests",**python_fact)
            check()
        except BaseException as error:
            code=1;errors.append({"type":type(error).__name__,"message":str(error)})
            emit("error",**errors[-1])
        finally:
            if proposal is not None:
                try:bindings()
                except BaseException as error:
                    code=1;errors.append({"type":type(error).__name__,"message":str(error)})
            check_observed=time.perf_counter_ns()
            if check_observed>=deadline:
                code=1;errors.append({"type":"TimeoutError","message":"pre-receipt deadline"})
            if len(measurements)!=8 or len(adversarial)!=16 or python_fact is None:code=1
            emit("checks_complete",code=code,pre_receipt_checks_passed=code==0,errors=errors,
                 observations=len(measurements),adversarial_cases=len(adversarial),python_tests=python_fact,
                 qualified_native_capture=False,qualified_census=False,qualified_phase=False)
    artifacts={}
    for name in ("comparison-001.jsonl","saved-semantic-output-001.json","python-tests-001.log"):
        path=HERE/name
        if path.exists():artifacts[name]=sha(path.read_bytes())
    observed=time.perf_counter_ns()
    if observed>=deadline:code=1;errors.append({"type":"TimeoutError","message":"deadline after final artifact hash"})
    receipt={"schema":"bulk-byte-decoder-comparison-v1","code":code,"qualified":code==0,
             "proposal_sha256":approved,"artifact_sha256":artifacts,"errors":errors,
             "paired_calls":len(measurements),"adversarial_cases":len(adversarial),"python_tests":python_fact,
             "receipt_observed_ns":observed,"deadline_ns":deadline,
             "deadline_scope":"All checks/hashes through receipt observation15s; receipt emission under30s wholeJob",
             "private_dll_loads":0,"native_snapshot_calls":0,"benchmark_slots":0,
             "qualified_native_capture":False,"qualified_census":False,"qualified_phase":False,
             "scope":"Only saved-data/shim output equivalence and listed refusal controls; microtimings cannot establish native/fullcensus speed or50ms admission"}
    with (HERE/"receipt-001.json").open("x",encoding="utf-8") as f:
        json.dump(receipt,f,indent=2,allow_nan=False);f.write("\n")
    return code

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--approved-proposal-sha",required=True)
    raise SystemExit(main(p.parse_args().approved_proposal_sha))
