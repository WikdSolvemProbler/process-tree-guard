/* Scripted Windows API controls. No real snapshot, handle or clock APIs called. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <string.h>
static HANDLE WINAPI fake_snapshot(DWORD,DWORD);
static VOID WINAPI fake_upper(LPFILETIME);
static BOOL WINAPI fake_first(HANDLE,LPPROCESSENTRY32W);
static BOOL WINAPI fake_next(HANDLE,LPPROCESSENTRY32W);
static BOOL WINAPI fake_close(HANDLE);
static BOOL WINAPI fake_counter(LARGE_INTEGER *);
static BOOL WINAPI fake_frequency(LARGE_INTEGER *);
static DWORD WINAPI fake_error(void);
#define CreateToolhelp32Snapshot fake_snapshot
#define GetSystemTimePreciseAsFileTime fake_upper
#define Process32FirstW fake_first
#define Process32NextW fake_next
#define CloseHandle fake_close
#define QueryPerformanceCounter fake_counter
#define QueryPerformanceFrequency fake_frequency
#define GetLastError fake_error
#include "bulk_snapshot.c"
static int mode, counter_calls, snapshot_calls, upper_calls, first_calls, next_calls, close_calls, position;
static DWORD last_error;
static PROCESSENTRY32W data_rows[3];
static int data_count;
static void reset(int selected) {
    int i;
    mode=selected;
    counter_calls=snapshot_calls=upper_calls=first_calls=next_calls=close_calls=position=0;
    last_error=0;
    memset(data_rows,0,sizeof(data_rows));
    data_count=2;
    for(i=0;i<2;++i) {
        data_rows[i].dwSize=(DWORD)sizeof(PROCESSENTRY32W);
        data_rows[i].th32ProcessID=(DWORD)(20+i);
        data_rows[i].th32ParentProcessID=10;
        data_rows[i].szExeFile[0]=L'A';
        data_rows[i].szExeFile[1]=(WCHAR)(L'0'+i);
    }
    if(mode==7) data_rows[1].th32ProcessID=data_rows[0].th32ProcessID;
    if(mode==8) for(i=0;i<260;++i)data_rows[0].szExeFile[i]=L'X';
    if(mode==9) data_rows[0].szExeFile[0]=0;
}
static HANDLE WINAPI fake_snapshot(DWORD flags,DWORD pid) {
    ++snapshot_calls;
    if(flags!=2 || pid!=0) { last_error=87;return INVALID_HANDLE_VALUE; }
    if(mode==1) {last_error=123;return INVALID_HANDLE_VALUE;}
    return (HANDLE)(ULONG_PTR)64;
}
static VOID WINAPI fake_upper(LPFILETIME out) {
    ++upper_calls;
    out->dwHighDateTime=(mode==10)?0:3;
    out->dwLowDateTime=0;
}
static BOOL WINAPI fake_first(HANDLE handle,LPPROCESSENTRY32W out) {
    ++first_calls;
    if(handle!=(HANDLE)(ULONG_PTR)64 || out->dwSize!=sizeof(*out)) {last_error=87;return FALSE;}
    if(mode==2) {last_error=124;return FALSE;}
    *out=data_rows[0];position=1;return TRUE;
}
static BOOL WINAPI fake_next(HANDLE handle,LPPROCESSENTRY32W out) {
    ++next_calls;
    if(handle!=(HANDLE)(ULONG_PTR)64) {last_error=87;return FALSE;}
    if(mode==3) {last_error=125;return FALSE;}
    if(position>=data_count) {last_error=ERROR_NO_MORE_FILES;return FALSE;}
    *out=data_rows[position++];return TRUE;
}
static BOOL WINAPI fake_close(HANDLE handle) {
    ++close_calls;
    if(handle!=(HANDLE)(ULONG_PTR)64) {last_error=87;return FALSE;}
    if(mode==4) {last_error=126;return FALSE;}
    return TRUE;
}
static BOOL WINAPI fake_counter(LARGE_INTEGER *out) {
    ++counter_calls;
    if((mode==5 && counter_calls==8)||(mode==11&&counter_calls==1)) {last_error=127;return FALSE;}
    out->QuadPart=1000+counter_calls;
    if(mode==6 && counter_calls==3)out->QuadPart=1001;
    return TRUE;
}
static BOOL WINAPI fake_frequency(LARGE_INTEGER *out) {
    if(mode==12) {last_error=128;return FALSE;}
    out->QuadPart=10000000;return TRUE;
}
static DWORD WINAPI fake_error(void) {return last_error;}
static int one(const char *name,int selected,uint32_t cap,uint32_t expected,int expected_close) {
    static ptg_row rows[PTG_MAX_ROWS]; /* Test fixture only; avoid default1MiB stack. */
    ptg_evidence e;
    uint32_t result;
    reset(selected);
    result=ptg_bulk_snapshot(rows,cap,&e);
    if(result!=expected || e.status!=expected || close_calls!=expected_close
       || (snapshot_calls && upper_calls!=1)) {
        printf("FAIL %s status=%u expected=%u close=%d upper=%d\n",name,result,expected,close_calls,upper_calls);
        return 1;
    }
    if(!result && (e.count!=2 || rows[0].pid!=20 || rows[1].pid!=21
       || rows[0].name_units!=2 || rows[0].name[2]!=0 || e.upper_ticks!=((uint64_t)3<<32))) {
        printf("FAIL %s rows\n",name);return 1;
    }
    printf("PASS %s status=%u count=%u close=%d\n",name,result,e.count,close_calls);
    return 0;
}
int main(void) {
    int failures=0;
    failures+=one("complete_raw_rows",0,PTG_MAX_ROWS,0,1);
    failures+=one("snapshot_error",1,PTG_MAX_ROWS,3,0);
    failures+=one("first_error",2,PTG_MAX_ROWS,4,1);
    failures+=one("next_error",3,PTG_MAX_ROWS,5,1);
    failures+=one("close_error",4,PTG_MAX_ROWS,9,1);
    failures+=one("final_qpc_failure_sticky",5,PTG_MAX_ROWS,2,1);
    failures+=one("qpc_regression",6,PTG_MAX_ROWS,11,1);
    failures+=one("duplicate_pid",7,PTG_MAX_ROWS,8,1);
    failures+=one("unterminated_name",8,PTG_MAX_ROWS,7,1);
    failures+=one("empty_name",9,PTG_MAX_ROWS,7,1);
    failures+=one("zero_upper",10,PTG_MAX_ROWS,10,1);
    failures+=one("initial_qpc_failure",11,PTG_MAX_ROWS,2,0);
    failures+=one("frequency_failure",12,PTG_MAX_ROWS,2,0);
    failures+=one("overflow_not_truncation",0,1,6,1);
    failures+=one("zero_capacity",0,0,1,0);
    failures+=one("oversize_capacity",0,PTG_MAX_ROWS+1,1,0);
    printf("terminal failures=%d native_api_calls=0\n",failures);
    return failures?1:0;
}
