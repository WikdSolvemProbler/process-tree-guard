@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Auxiliary/Build/vcvars64.bat" 10.0.28000.0 -vcvars_ver=14.51
if errorlevel 1 exit /b %errorlevel%
echo SelectedWindowsSDKVersion=%WindowsSDKVersion%
echo SelectedVCToolsVersion=%VCToolsVersion%
"C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe" /nologo /Bv /showIncludes /std:c11 /W4 /WX /O2 /MT /LD bulk_snapshot.c /Fe:ptg_bulk_snapshot_001.dll /Fo:bulk_snapshot.obj /link /INCREMENTAL:NO /DYNAMICBASE /NXCOMPAT /Brepro kernel32.lib
if errorlevel 1 exit /b %errorlevel%
"C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe" /nologo /Bv /showIncludes /std:c11 /W4 /WX /O2 /MT test_bulk_snapshot.c /Fe:test_bulk_snapshot.exe /Fo:test_bulk_snapshot.obj /link /INCREMENTAL:NO /DYNAMICBASE /NXCOMPAT /Brepro kernel32.lib
if errorlevel 1 exit /b %errorlevel%
"C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/dumpbin.exe" /DEPENDENTS /HEADERS /EXPORTS ptg_bulk_snapshot_001.dll
exit /b %errorlevel%
