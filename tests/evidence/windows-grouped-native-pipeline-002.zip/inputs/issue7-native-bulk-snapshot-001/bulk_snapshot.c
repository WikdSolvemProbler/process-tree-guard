/* One in-process full Toolhelp enumeration; no state, allocation or retries. */
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0A00
#include <windows.h>
#include <tlhelp32.h>
#include <stdint.h>
#include <stddef.h>

#define PTG_MAX_ROWS 4096u
#define PTG_NAME_UNITS 260u
typedef struct {
    uint32_t pid, parent_pid, name_units;
    uint16_t name[PTG_NAME_UNITS];
} ptg_row;
typedef struct {
    uint32_t version, bytes, status, primary_error, close_error, clock_error;
    uint32_t count, capacity, name_units, reserved;
    uint64_t upper_ticks;
    int64_t frequency, begin_qpc, snapshot_upper_begin_qpc, snapshot_upper_end_qpc;
    int64_t enumerate_begin_qpc, enumerate_end_qpc, close_begin_qpc, close_end_qpc, end_qpc;
} ptg_evidence;
_Static_assert(sizeof(WCHAR)==2, "UTF16 ABI");
_Static_assert(sizeof(PROCESSENTRY32W)==568, "AMD64 Toolhelp ABI");
_Static_assert(offsetof(PROCESSENTRY32W,th32ProcessID)==8 &&
               offsetof(PROCESSENTRY32W,th32ParentProcessID)==32 &&
               offsetof(PROCESSENTRY32W,szExeFile)==44, "Toolhelp field offsets");
_Static_assert(sizeof(ptg_row)==532, "row ABI");
_Static_assert(offsetof(ptg_row,name)==12, "row name ABI");
_Static_assert(sizeof(ptg_evidence)==120, "evidence ABI");
_Static_assert(offsetof(ptg_evidence,upper_ticks)==40, "upper ABI");
_Static_assert(offsetof(ptg_evidence,frequency)==48, "clock ABI");

static void clear_bytes(void *p, size_t count) {
    volatile unsigned char *v=(volatile unsigned char *)p;
    while(count) { *v++=0; --count; }
}
static int64_t tick(ptg_evidence *e) {
    LARGE_INTEGER value;
    if(!QueryPerformanceCounter(&value) || value.QuadPart<=0) {
        e->clock_error=GetLastError();
        if(!e->clock_error) e->clock_error=ERROR_INVALID_DATA;
        return 0;
    }
    return value.QuadPart;
}
static void fail(ptg_evidence *e, uint32_t status, DWORD error) {
    if(!e->status) {
        e->status=status;
        e->primary_error=error;
    }
}
__declspec(dllexport) uint32_t __cdecl ptg_bulk_snapshot(
        ptg_row *rows, uint32_t capacity, ptg_evidence *e) {
    HANDLE snapshot=INVALID_HANDLE_VALUE;
    PROCESSENTRY32W data;
    FILETIME upper;
    LARGE_INTEGER frequency;
    DWORD creation_error=0;
    uint32_t i,j,length;
    if(!e) return 1;
    clear_bytes(e,sizeof(*e));
    e->version=1;
    e->bytes=(uint32_t)sizeof(*e);
    e->capacity=capacity;
    e->name_units=PTG_NAME_UNITS;
    if(!rows || capacity==0 || capacity>PTG_MAX_ROWS) {
        fail(e,1,ERROR_INVALID_PARAMETER);
        return e->status;
    }
    if(!QueryPerformanceFrequency(&frequency) || frequency.QuadPart<=0) {
        e->clock_error=GetLastError();
        if(!e->clock_error) e->clock_error=ERROR_INVALID_DATA;
        fail(e,2,e->clock_error);
        return e->status;
    }
    e->frequency=frequency.QuadPart;
    e->begin_qpc=tick(e);
    if(e->clock_error) { fail(e,2,e->clock_error); goto finished; }
    e->snapshot_upper_begin_qpc=tick(e);
    if(e->clock_error) { fail(e,2,e->clock_error); goto finished; }
    snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    if(!snapshot || snapshot==INVALID_HANDLE_VALUE) creation_error=GetLastError();
    /* No QPC or other successful-path native call between snapshot and upper. */
    GetSystemTimePreciseAsFileTime(&upper);
    e->upper_ticks=((uint64_t)upper.dwHighDateTime<<32)|upper.dwLowDateTime;
    e->snapshot_upper_end_qpc=tick(e);
    if(!snapshot || snapshot==INVALID_HANDLE_VALUE) {
        snapshot=INVALID_HANDLE_VALUE;
        fail(e,3,creation_error);
        goto finished;
    }
    if(e->clock_error) { fail(e,2,e->clock_error); goto cleanup; }
    if(!e->upper_ticks) { fail(e,10,ERROR_INVALID_DATA); goto cleanup; }
    clear_bytes(&data,sizeof(data));
    data.dwSize=(DWORD)sizeof(data);
    e->enumerate_begin_qpc=tick(e);
    if(e->clock_error) { fail(e,2,e->clock_error); goto cleanup; }
    if(!Process32FirstW(snapshot,&data)) {
        fail(e,4,GetLastError());
        goto enumeration_finished;
    }
    for(;;) {
        if(e->count>=capacity) { fail(e,6,ERROR_INSUFFICIENT_BUFFER); break; }
        length=0;
        while(length<PTG_NAME_UNITS && data.szExeFile[length]) ++length;
        if(!length || length>=PTG_NAME_UNITS) { fail(e,7,ERROR_INVALID_DATA); break; }
        for(i=0;i<e->count;++i) {
            if(rows[i].pid==data.th32ProcessID) { fail(e,8,ERROR_INVALID_DATA); break; }
        }
        if(e->status) break;
        rows[e->count].pid=data.th32ProcessID;
        rows[e->count].parent_pid=data.th32ParentProcessID;
        rows[e->count].name_units=length;
        for(j=0;j<PTG_NAME_UNITS;++j) {
            rows[e->count].name[j]=(j<length)?(uint16_t)data.szExeFile[j]:0;
        }
        ++e->count;
        if(!Process32NextW(snapshot,&data)) {
            DWORD error=GetLastError();
            if(error!=ERROR_NO_MORE_FILES) fail(e,5,error);
            break;
        }
    }
enumeration_finished:
    e->enumerate_end_qpc=tick(e);
cleanup:
    e->close_begin_qpc=tick(e);
    if(!CloseHandle(snapshot)) {
        e->close_error=GetLastError();
        fail(e,9,e->close_error);
    }
    snapshot=INVALID_HANDLE_VALUE;
    e->close_end_qpc=tick(e);
finished:
    e->end_qpc=tick(e);
    if(e->clock_error) fail(e,2,e->clock_error);
    if(!e->status && !(e->begin_qpc<=e->snapshot_upper_begin_qpc
       && e->snapshot_upper_begin_qpc<=e->snapshot_upper_end_qpc
       && e->snapshot_upper_end_qpc<=e->enumerate_begin_qpc
       && e->enumerate_begin_qpc<=e->enumerate_end_qpc
       && e->enumerate_end_qpc<=e->close_begin_qpc
       && e->close_begin_qpc<=e->close_end_qpc
       && e->close_end_qpc<=e->end_qpc)) fail(e,11,ERROR_INVALID_DATA);
    return e->status;
}
