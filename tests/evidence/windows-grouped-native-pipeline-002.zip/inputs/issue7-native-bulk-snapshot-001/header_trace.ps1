function Get-PinnedHeaderTrace {
    param([Parameter(Mandatory)][string]$Trace,
          [Parameter(Mandatory)][System.Collections.IDictionary]$HeaderPins)
    if($HeaderPins.Count -eq 0){throw "empty header pin set"}
    $records=[Collections.Generic.List[object]]::new()
    foreach($line in ($Trace -split "\r?\n")){
        $match=[regex]::Match($line,'^\s*Note: including file:\s*(.+?)\s*$')
        if(-not $match.Success){continue}
        $reported=$match.Groups[1].Value
        if(-not [IO.Path]::IsPathFullyQualified($reported)){throw "nonabsolute include record: $reported"}
        $records.Add([pscustomobject]@{reported=$reported;canonical=[IO.Path]::GetFullPath($reported)})
    }
    $verified=[Collections.Generic.List[object]]::new()
    foreach($expected in $HeaderPins.Keys){
        if($HeaderPins[$expected] -isnot [string] -or $HeaderPins[$expected] -cnotmatch '^[a-f0-9]{64}$'){
            throw "invalid header digest pin"
        }
        if(-not [IO.Path]::IsPathFullyQualified($expected)){throw "nonabsolute pinned header: $expected"}
        $canonical=[IO.Path]::GetFullPath($expected)
        $found=@($records|Where-Object{[string]::Equals($_.canonical,$canonical,[StringComparison]::OrdinalIgnoreCase)})
        if($found.Count -eq 0){throw "intended header absent from complete include records: $expected"}
        $observations=[Collections.Generic.List[object]]::new()
        foreach($actual in $found){
            $digest=(Get-FileHash -LiteralPath $actual.reported -Algorithm SHA256).Hash.ToLower()
            if($digest -ne $HeaderPins[$expected]){throw "reported header hash differs: $($actual.reported)"}
            $observations.Add([pscustomobject]@{reported_path=$actual.reported;canonical_path=$actual.canonical;sha256=$digest})
        }
        $verified.Add([pscustomobject]@{expected_path=$expected;canonical_expected=$canonical;expected_sha256=$HeaderPins[$expected];observations=$observations.ToArray()})
    }
    return $verified.ToArray()
}
