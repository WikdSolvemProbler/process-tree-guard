from copy import deepcopy
import json
import unittest

from grouped_census import collect
from replay_grouped import replay

POLICY = {"pinned_basenames": [], "veto_sha256": ["f" * 64]}
GUARD = (90, 9000, 100)


class Clock:
    def __init__(self):
        self.value = 100
        self.fail_next = False
    def __call__(self):
        if self.fail_next:
            self.fail_next = False
            raise OSError("scripted clock unavailable")
        self.value += 10
        return self.value


def signature(identity="11" * 16):
    return {"volume": 8, "file_id_128": identity, "size": 4, "allocation": 4096,
            "links": 1, "creation_ticks": 100, "write_ticks": 200, "change_ticks": 300,
            "attributes": 32, "directory": False, "delete_pending": False}


class FakeBackend:
    def __init__(self, paths=None):
        self.clock = Clock()
        self.paths = paths or {101: "C:/Python.exe", 102: "C:/Python.exe"}
        self.names = {pid: "python.exe" for pid in self.paths}
        self.opened, self.closed, self.inspections = [], [], []
        self.path_calls = {}
        self.job_members = set()
        self.path_change = self.path_failure = self.creation_change = self.job_change = None
        self.dead_after = self.close_failure = self.open_failure = None
        self.before_rebind = self.content_change = self.repeat_callback = False
        self.interrupt_member = self.interrupt_close = None
        self.digest = "a" * 64
        self.volume = 8
        self.born_after_snapshot = None
        self.clock_failure_after_close = False
        self.completed_reads = 0

    def observer_pid(self):
        return 50

    def snapshot(self):
        return ([{"pid": 50, "parent_pid": 90, "name": "python.exe"},
                 {"pid": 90, "parent_pid": 1, "name": "process-tree-guard.exe"}]
                + [{"pid": pid, "parent_pid": 90, "name": self.names[pid]}
                   for pid in self.paths]
                + [{"pid": 999, "parent_pid": 1, "name": "uninspected.exe"}]), 2000

    def open_process(self, pid):
        if pid == self.open_failure:
            raise OSError("OpenProcess failed")
        self.opened.append(pid + 10000)
        return pid + 10000

    def close_process(self, handle):
        self.closed.append(handle)
        if self.clock_failure_after_close:
            self.clock.fail_next = True
        if handle == self.interrupt_close:
            raise KeyboardInterrupt("cleanup interrupt")
        if handle == self.close_failure:
            raise OSError("CloseHandle failed")

    def pid(self, handle):
        return 90 if handle == 9000 else handle - 10000

    def path(self, handle):
        pid = self.pid(handle)
        self.path_calls[pid] = self.path_calls.get(pid, 0) + 1
        last = self.path_calls[pid] >= 2
        if pid == self.interrupt_member and last:
            raise KeyboardInterrupt("member interrupt")
        if pid == self.path_failure and last:
            raise OSError("retained identity query failed")
        if pid == 90:
            return "C:/guard/process-tree-guard.exe"
        if pid == self.path_change and last:
            return self.paths[pid].swapcase()
        return self.paths[pid]

    def creation(self, handle):
        pid = self.pid(handle)
        if pid == 90:
            return 100
        if pid == self.born_after_snapshot:
            return 2500
        return 1000 + pid + (1 if pid == self.creation_change and self.path_calls[pid] >= 2 else 0)

    def member(self, handle, job):
        pid = self.pid(handle)
        result = pid in self.job_members
        return not result if pid == self.job_change and self.path_calls[pid] >= 2 else result

    def alive(self, handle):
        pid = self.pid(handle)
        return not (pid == self.dead_after and self.path_calls[pid] >= 2)

    def inspect_group(self, path, callback):
        self.inspections.append(path)
        c = self.clock
        observed = {"schema": 3, "path": path, "begin_ns": c(),
                    "scope": "shared path observation; P1 between fixed reads; not independent per-process reads",
                    "named_before": signature(), "held_before": signature()}
        try:
            if self.before_rebind:
                observed["held_before"] = signature("22" * 16)
                raise ValueError("image named entry differs from opened native identity")
            observed["read_first"] = {"begin_ns": c(), "end_ns": c(), "sha256": self.digest}
            self.completed_reads += 1
            observed["member_check"] = {"begin_ns": c()}
            try:
                callback()
                if self.repeat_callback:
                    callback()
            finally:
                observed["member_check"]["end_ns"] = c()
            observed["rewind"] = {"begin_ns": c(), "end_ns": c(), "position": 0}
            observed["read_second"] = {"begin_ns": c(), "end_ns": c(),
                                       "sha256": "b" * 64 if self.content_change else self.digest}
            self.completed_reads += 1
            observed.update(held_after=signature(), named_after=signature(), sha256=self.digest)
            for name in ("named_before", "held_before", "held_after", "named_after"):
                observed[name]["volume"] = self.volume
            observed["end_ns"] = c()
            if self.content_change:
                raise ValueError("image fixed read digests differ")
            return self.digest, observed
        except Exception as error:
            observed["end_ns"] = c()
            error.evidence = observed
            raise


def observed(backend, policy=POLICY, job=None):
    result = collect(backend, GUARD, policy, job, clock=backend.clock)
    return result, replay(result, policy, expected_guard=(90, 100), expected_observer_pid=50,
                          expected_job_present=job is not None)


class GroupTests(unittest.TestCase):
    def test_shared_once_two_process_passes_and_no_per_row_digest(self):
        backend = FakeBackend()
        result, checked = observed(backend)
        self.assertTrue(result["admissible"], result)
        self.assertTrue(checked["record_valid"], checked)
        self.assertTrue(checked["admissible"], checked)
        self.assertEqual(backend.inspections, ["C:/Python.exe"])
        self.assertEqual(backend.completed_reads, 2)
        self.assertEqual(backend.path_calls, {90: 2, 101: 2, 102: 2})
        self.assertCountEqual(backend.closed, backend.opened)
        self.assertNotIn(9000, backend.closed)
        rows = [r for r in result["rows"] if r["pid"] != 90]
        self.assertEqual({r["group_id"] for r in rows}, {"g0"})
        self.assertTrue(all("image_sha256" not in r and "image_file" not in r for r in rows))

    def test_exact_strings_do_not_merge_case_aliases_even_same_file_identity(self):
        backend = FakeBackend({101: "C:/Python.exe", 102: "c:/python.exe"})
        result, checked = observed(backend)
        self.assertEqual(len(result["groups"]), 2)
        self.assertEqual(len(backend.inspections), 2)
        self.assertTrue(checked["admissible"], checked)

    def test_every_member_failure_invalidates_all_references_and_preserves_second_read(self):
        for field in ("path_failure", "path_change", "creation_change", "job_change"):
            with self.subTest(field=field):
                backend = FakeBackend()
                setattr(backend, field, 102)
                result, checked = observed(backend, job=77 if field == "job_change" else None)
                self.assertFalse(result["admissible"])
                self.assertFalse(checked["admissible"])
                self.assertEqual(backend.completed_reads, 2)
                self.assertTrue(all(r["state"] == "membership_unverified"
                                    for r in result["rows"] if r.get("group_id") == "g0"))
                self.assertCountEqual(backend.closed, backend.opened)

    def test_file_change_and_before_open_rebind_are_not_later_rescued(self):
        for field, reads in (("content_change", 2), ("before_rebind", 0)):
            with self.subTest(field=field):
                backend = FakeBackend()
                setattr(backend, field, True)
                result, checked = observed(backend)
                self.assertFalse(result["admissible"])
                self.assertFalse(checked["admissible"])
                self.assertEqual(backend.completed_reads, reads)
                if reads == 0:
                    self.assertTrue(all(r["P1"]["phase"] == "after_failed_group"
                                        for r in result["rows"] if "group_id" in r))

    def test_repeated_callback_is_not_a_selective_retry(self):
        backend = FakeBackend()
        backend.repeat_callback = True
        result, checked = observed(backend)
        self.assertFalse(result["admissible"])
        self.assertFalse(checked["admissible"])
        self.assertEqual(backend.path_calls[101], 2)
        self.assertEqual(backend.path_calls[102], 2)

    def test_membership_priority_and_known_content_veto(self):
        backend = FakeBackend({101: "C:/cl.exe"})
        backend.names[101] = "cl.exe"
        backend.job_members.add(101)
        result, checked = observed(backend, job=77)
        self.assertTrue(result["admissible"], result)
        self.assertTrue(checked["admissible"], checked)
        self.assertEqual(backend.inspections, [])
        backend = FakeBackend()
        result, checked = observed(backend, {"pinned_basenames": [], "veto_sha256": ["a" * 64]})
        self.assertFalse(result["admissible"])
        self.assertTrue(all(r["state"] == "pinned_workload_outside_job"
                            for r in result["rows"] if "group_id" in r))
        self.assertFalse(checked["admissible"])

    def test_retained_stable_exited_process_is_recorded_not_dropped(self):
        backend = FakeBackend()
        backend.dead_after = 102
        result, checked = observed(backend)
        self.assertTrue(result["admissible"])
        self.assertTrue(checked["admissible"], checked)
        row = next(r for r in result["rows"] if r["pid"] == 102)
        self.assertIs(row["P1"]["alive_at_member_check"], False)

    def test_open_or_close_failure_refuses_whole_census_and_attempts_remaining_cleanup(self):
        for field, value in (("open_failure", 102), ("close_failure", 10102)):
            backend = FakeBackend()
            setattr(backend, field, value)
            result, checked = observed(backend)
            self.assertFalse(result["admissible"])
            self.assertFalse(checked["admissible"])
            self.assertCountEqual(backend.closed, backend.opened)

    def test_console_interrupt_propagates_after_all_owned_cleanup_attempts(self):
        for field, value in (("interrupt_member", 102), ("interrupt_close", 10102)):
            backend = FakeBackend()
            setattr(backend, field, value)
            with self.assertRaises(KeyboardInterrupt):
                collect(backend, GUARD, POLICY, clock=backend.clock)
            self.assertCountEqual(backend.closed, backend.opened)

    def test_independent_replay_rejects_forged_members_aliases_hashes_and_timing(self):
        backend = FakeBackend()
        result, _ = observed(backend)
        mutations = (
            lambda c: c["groups"][0]["member_row_ids"].pop(),
            lambda c: c["groups"][0].update(raw_image_path="c:/python.exe"),
            lambda c: c["groups"][0]["file_observation"]["read_second"].update(sha256="b" * 64),
            lambda c: c["groups"][0]["file_observation"]["named_after"].update(file_id_128="11" * 8 + "22" * 8),
            lambda c: c["rows"][1]["P1"].update(begin_ns=c["groups"][0]["file_observation"]["read_second"]["end_ns"]),
            lambda c: c["rows"][1].update(alive_after=True),
            lambda c: c["rows"].pop(),
            lambda c: c["groups"][0].update(member_callback_calls=True),
            lambda c: c["groups"][0]["file_observation"]["held_after"].update(volume=True),
        )
        for mutate in mutations:
            with self.subTest(mutate=mutate):
                forged = deepcopy(result)
                mutate(forged)
                checked = replay(forged, POLICY, expected_guard=(90, 100), expected_observer_pid=50, expected_job_present=False)
                self.assertFalse(checked["admissible"], checked)


    def test_snapshot_birth_bound_failure_is_not_dropped_or_rebound(self):
        backend = FakeBackend()
        backend.born_after_snapshot = 102
        result, checked = observed(backend)
        self.assertFalse(result["admissible"])
        self.assertFalse(checked["admissible"])
        row = next(row for row in result["rows"] if row["pid"] == 102)
        self.assertEqual(row["P0"]["created_ticks"], 2500)
        self.assertEqual(row["state"], "membership_unverified")
        self.assertNotIn("group_id", row)
        self.assertCountEqual(backend.closed, backend.opened)

    def test_clock_failure_during_cleanup_cannot_skip_owned_handles_or_pass(self):
        backend = FakeBackend()
        backend.clock_failure_after_close = True
        result, checked = observed(backend)
        self.assertFalse(result["admissible"])
        self.assertFalse(checked["admissible"])
        self.assertCountEqual(backend.closed, backend.opened)
        self.assertTrue(result["errors"])


    def test_json_round_trip_preserves_full_unsigned_volume_and_raw_path_strings(self):
        backend = FakeBackend({101: "C:/Python.exe", 102: "c:/python.exe"})
        backend.volume = 2**63 + 39
        result, _ = observed(backend)
        decoded = json.loads(json.dumps(result, allow_nan=False))
        self.assertEqual(decoded["groups"][0]["file_observation"]["held_before"]["volume"], 2**63 + 39)
        self.assertNotEqual(decoded["groups"][0]["raw_image_path"], decoded["groups"][1]["raw_image_path"])
        checked = replay(decoded, POLICY, expected_guard=(90, 100), expected_observer_pid=50, expected_job_present=False)
        self.assertTrue(checked["admissible"], checked)


    def test_zero_or_pseudo_job_handle_cannot_become_any_job_query(self):
        for invalid in (0, False, -1, 2**64-1):
            backend = FakeBackend()
            with self.assertRaises(ValueError):
                collect(backend, GUARD, POLICY, invalid, clock=backend.clock)
            self.assertEqual(backend.opened, [])


    def test_terminal_clock_regression_after_decision_work_cannot_pass(self):
        class TerminalRegression(FakeBackend):
            def __init__(self):
                super().__init__()
                self.after_final_close = False
                self.terminal_countdown = None
            def close_process(self, handle):
                super().close_process(handle)
                if handle == 10101:
                    self.terminal_countdown = 1
        backend = TerminalRegression()
        def clock():
            if backend.terminal_countdown is not None:
                if backend.terminal_countdown == 0:
                    backend.terminal_countdown = None
                    return backend.clock.value - 5
                backend.terminal_countdown -= 1
            return backend.clock()
        result = collect(backend, GUARD, POLICY, clock=clock)
        self.assertGreater(result["end_ns"], result["begin_ns"])
        self.assertTrue(result["errors"])
        self.assertFalse(result["admissible"])
        self.assertCountEqual(backend.closed, backend.opened)


if __name__ == "__main__":
    unittest.main()
