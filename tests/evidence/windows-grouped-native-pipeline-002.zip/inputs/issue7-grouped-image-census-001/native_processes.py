"""Draft sampled census of known competing workload images on Windows."""

import _winapi
import ctypes
import os
from ctypes import wintypes
from dataclasses import asdict, dataclass
import time

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
TH32CS_SNAPPROCESS = 2
ERROR_NO_MORE_FILES = 18
INVALID_HANDLE = ctypes.c_void_p(-1).value
COMPILERS = frozenset({
    "cargo.exe", "rustc.exe", "rustdoc.exe", "cl.exe", "link.exe", "clang.exe",
    "clang-cl.exe", "lld.exe", "lld-link.exe", "rust-lld.exe", "gcc.exe",
    "g++.exe", "cc1.exe", "cc1plus.exe", "msbuild.exe", "cmake.exe", "ninja.exe",
})
WORKLOADS = frozenset({
    "python.exe", "pythonw.exe", "python3.exe", "pytest.exe", "ptg.exe",
    "process-tree-guard.exe", "testkit.exe", "sysprims.exe", "processkit-cli.exe",
    "timeout.exe",
})
GUARD_IMAGE = "process-tree-guard.exe"


class ProcessEntry(ctypes.Structure):
    _fields_ = [
        ("size", wintypes.DWORD), ("usage", wintypes.DWORD), ("pid", wintypes.DWORD),
        ("heap", ctypes.c_size_t), ("module", wintypes.DWORD), ("threads", wintypes.DWORD),
        ("parent_pid", wintypes.DWORD), ("base_priority", wintypes.LONG),
        ("flags", wintypes.DWORD), ("name", wintypes.WCHAR * 260),
    ]


@dataclass(frozen=True)
class Entry:
    pid: int
    parent_pid: int
    name: str


def bind(name, args, result):
    call = getattr(kernel32, name)
    call.argtypes = args
    call.restype = result
    return call


kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
create_snapshot = bind("CreateToolhelp32Snapshot", [wintypes.DWORD, wintypes.DWORD], wintypes.HANDLE)
first_process = bind("Process32FirstW", [wintypes.HANDLE, ctypes.POINTER(ProcessEntry)], wintypes.BOOL)
next_process = bind("Process32NextW", [wintypes.HANDLE, ctypes.POINTER(ProcessEntry)], wintypes.BOOL)
is_member = bind("IsProcessInJob", [wintypes.HANDLE, wintypes.HANDLE, ctypes.POINTER(wintypes.BOOL)],
                 wintypes.BOOL)


precise_filetime = bind("GetSystemTimePreciseAsFileTime",
                        [ctypes.POINTER(wintypes.FILETIME)], None)


def entries(*, capture_upper=False):
    handle = create_snapshot(TH32CS_SNAPPROCESS, 0)
    upper = wintypes.FILETIME()
    precise_filetime(ctypes.byref(upper))
    if not handle or handle == INVALID_HANDLE:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        data = ProcessEntry()
        data.size = ctypes.sizeof(data)
        if not first_process(handle, ctypes.byref(data)):
            raise ctypes.WinError(ctypes.get_last_error())
        result = {}
        while True:
            if data.pid in result:
                raise RuntimeError("duplicate PID in process snapshot")
            result[data.pid] = Entry(data.pid, data.parent_pid, data.name.casefold())
            if not next_process(handle, ctypes.byref(data)):
                error = ctypes.get_last_error()
                if error != ERROR_NO_MORE_FILES:
                    raise ctypes.WinError(error)
                return (result, filetime(upper)) if capture_upper else result
    finally:
        _winapi.CloseHandle(handle)


from contextlib import ExitStack, contextmanager
from pathlib import Path
from time import time_ns

SYNCHRONIZE = 0x100000
FILETIME_UNIX_OFFSET = 116444736000000000
P = ctypes.POINTER
process_image = bind("QueryFullProcessImageNameW",
                     [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, P(wintypes.DWORD)],
                     wintypes.BOOL)
process_times = bind("GetProcessTimes", [wintypes.HANDLE] + [P(wintypes.FILETIME)] * 4,
                     wintypes.BOOL)


@contextmanager
def open_exact(pid):
    handle = _winapi.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, False, pid)
    try:
        yield handle
    finally:
        _winapi.CloseHandle(handle)


def filetime(value):
    return value.dwHighDateTime << 32 | value.dwLowDateTime


def identity(handle):
    name = ctypes.create_unicode_buffer(32768)
    size = wintypes.DWORD(len(name))
    if not process_image(handle, 0, name, ctypes.byref(size)):
        raise ctypes.WinError(ctypes.get_last_error())
    created, exited, kernel, user = (wintypes.FILETIME() for _ in range(4))
    if not process_times(handle, ctypes.byref(created), ctypes.byref(exited),
                         ctypes.byref(kernel), ctypes.byref(user)):
        raise ctypes.WinError(ctypes.get_last_error())
    if not filetime(created):
        raise ValueError("process creation time unavailable")
    return Path(name.value), filetime(created)


def is_alive(handle):
    status = _winapi.WaitForSingleObject(handle, 0)
    if status == _winapi.WAIT_TIMEOUT:
        return True
    if status == _winapi.WAIT_OBJECT_0:
        return False
    raise OSError(f"unexpected process wait status {status}")


def snapshot_identity(entry, image, created, upper):
    if not 0 < created <= upper:
        raise ValueError("process creation exceeds precise snapshot upper bound")
    if image.name.casefold() != entry.name:
        raise ValueError("process image name differs from snapshot")


@contextmanager
def enclosing_guard(expected_path):
    """Hold the named ancestor selected by its image and ordered creation times."""
    snapshot = entries()
    current = os.getpid()
    seen = set()
    last_created = time_ns() // 100 + FILETIME_UNIX_OFFSET
    with ExitStack() as stack:
        while current in snapshot and current not in seen:
            seen.add(current)
            entry = snapshot[current]
            handle = stack.enter_context(open_exact(current))
            image, created = identity(handle)
            if not is_alive(handle) or not 0 < created <= last_created \
                    or image.name.casefold() != entry.name:
                raise ValueError("unverified enclosing process chain")
            last_created = created
            if entry.name == GUARD_IMAGE:
                if not image.samefile(expected_path):
                    raise ValueError("enclosing guard is not the pinned image")
                yield current, handle, created
                return
            current = entry.parent_pid
    raise ValueError("pinned enclosing guard was not found")


class WindowsBackend:
    """Read-only native facts; no process/file observation cache."""
    @staticmethod
    def observer_pid():
        return os.getpid()

    @staticmethod
    def snapshot():
        found, upper = entries(capture_upper=True)
        return [asdict(entry) for entry in found.values()], upper

    @staticmethod
    def open_process(pid):
        return _winapi.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, False, pid)

    @staticmethod
    def close_process(handle):
        _winapi.CloseHandle(handle)

    @staticmethod
    def path(handle):
        name = ctypes.create_unicode_buffer(32768)
        size = wintypes.DWORD(len(name))
        if not process_image(handle, 0, name, ctypes.byref(size)):
            raise ctypes.WinError(ctypes.get_last_error())
        if not 0 < size.value < len(name):
            raise ValueError("invalid native process image length")
        raw = name[:size.value]
        if not isinstance(raw, str) or "\0" in raw:
            raise ValueError("invalid native process image string")
        return raw

    @staticmethod
    def creation(handle):
        created, exited, kernel, user = (wintypes.FILETIME() for _ in range(4))
        if not process_times(handle, ctypes.byref(created), ctypes.byref(exited),
                             ctypes.byref(kernel), ctypes.byref(user)):
            raise ctypes.WinError(ctypes.get_last_error())
        value = filetime(created)
        if not value:
            raise ValueError("process creation time unavailable")
        return value

    @staticmethod
    def member(handle, job_handle):
        found = wintypes.BOOL()
        if not is_member(handle, job_handle, ctypes.byref(found)):
            raise ctypes.WinError(ctypes.get_last_error())
        return bool(found.value)

    @staticmethod
    def alive(handle):
        return is_alive(handle)

    @staticmethod
    def inspect_group(path, member_check):
        from grouped_image import inspect_group_image
        return inspect_group_image(path, member_check)
