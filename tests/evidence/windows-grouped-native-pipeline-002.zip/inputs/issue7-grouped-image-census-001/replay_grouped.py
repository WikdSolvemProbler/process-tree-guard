"""Independent raw replay for grouped-image-census-v1; no native imports."""
import ntpath
import re

COMPILER_NAMES = frozenset({
    "cargo.exe", "rustc.exe", "rustdoc.exe", "cl.exe", "link.exe", "clang.exe",
    "clang-cl.exe", "lld.exe", "lld-link.exe", "rust-lld.exe", "gcc.exe",
    "g++.exe", "cc1.exe", "cc1plus.exe", "msbuild.exe", "cmake.exe", "ninja.exe",
})
RUNTIME_NAMES = frozenset({
    "python.exe", "pythonw.exe", "python3.exe", "pytest.exe", "ptg.exe",
    "process-tree-guard.exe", "testkit.exe", "sysprims.exe", "processkit-cli.exe",
    "timeout.exe",
})
ALLOWED_STATES = {"pinned_enclosing_guard", "campaign_member", "unclassified_background"}
SCOPE = "shared path observation; P1 between fixed reads; not independent per-process reads"


def replay(census, policy, *, expected_guard, expected_observer_pid, expected_job_present):
    errors, refusals = [], []
    def bad(message):
        errors.append(message)
    def uint(value, maximum=2**63-1, minimum=0):
        return type(value) is int and minimum <= value <= maximum
    def interval(value, low, high, label):
        if (not isinstance(value, dict) or not uint(value.get("begin_ns"))
                or not uint(value.get("end_ns")) or not low <= value["begin_ns"] <= value["end_ns"] <= high):
            bad("invalid interval: " + label)
            return False
        return True
    try:
        if census.get("admission_scope") != "image/process census only; all unchanged caller latency/counter/resource gates still required":
            bad("wrong admission scope")
        if census.get("scope") != "P0/read1/P1/read2 shared path observation; no post-read2 process freshness":
            bad("wrong sampling definition")
        if census["schema"] != "grouped-image-census-v1":
            raise ValueError("wrong grouped schema")
        if not interval(census, 0, 2**63-1, "census"):
            raise ValueError("invalid census clock")
        start, end = census["begin_ns"], census["end_ns"]
        guard_pid, guard_created = expected_guard
        if (census["observer_pid"] != expected_observer_pid or census["guard_pid"] != guard_pid
                or census["guard_created_ticks"] != guard_created):
            bad("external observer/guard identity differs")
        if type(census["job_present"]) is not bool:
            bad("invalid Job-presence mode")
        job_present = census["job_present"]
        if type(expected_job_present) is not bool or job_present is not expected_job_present:
            bad("owned-Job phase differs from external caller context")
        snapshot = census["snapshot"]
        if not interval(snapshot, start, end, "snapshot"):
            raise ValueError("invalid snapshot interval")
        upper = snapshot["upper_ticks"]
        if not uint(upper, 2**64-1, 1):
            raise ValueError("invalid precise snapshot upper")
        entries = snapshot["entries"]
        if not isinstance(entries, list):
            raise ValueError("missing full snapshot entries")
        seen = set()
        for entry in entries:
            if (not isinstance(entry, dict) or not uint(entry.get("pid"), 2**32-1)
                    or entry["pid"] in seen or not uint(entry.get("parent_pid"), 2**32-1)
                    or not isinstance(entry.get("name"), str) or entry["name"] != entry["name"].casefold()):
                raise ValueError("invalid/duplicate snapshot entry")
            seen.add(entry["pid"])
        if guard_pid not in seen or expected_observer_pid not in seen:
            bad("snapshot lacks guard/observer")
        relevant = COMPILER_NAMES | RUNTIME_NAMES | set(policy["pinned_basenames"])
        wanted = [entry for entry in entries if entry["pid"] != expected_observer_pid
                  and (entry["pid"] == guard_pid or entry["name"] in relevant)]
        rows, groups = census["rows"], census["groups"]
        if not isinstance(rows, list) or not isinstance(groups, list):
            raise ValueError("missing rows/groups")
        if [row.get("pid") for row in rows] != [entry["pid"] for entry in wanted]:
            bad("snapshot-relevant process set/order was dropped or changed")
        by_row, process_ok, p0_ok = {}, {}, {}
        retained = set()
        all_p0_end = snapshot["end_ns"]
        latest_observation = snapshot["end_ns"]

        def pass_ok(fact, row, label):
            if not interval(fact, snapshot["end_ns"], end, row["row_id"] + "/" + label):
                return False
            calls = fact.get("calls")
            expected = ["path", "creation"] + (["member"] if job_present else []) + ["alive"]
            if not isinstance(calls, list):
                bad("missing native call records")
                return False
            operations = [call.get("operation") for call in calls]
            if operations != expected[:len(operations)] or len(operations) > len(expected):
                bad("native process call schedule differs")
                return False
            prior = fact["begin_ns"]
            for call in calls:
                if not interval(call, prior, fact["end_ns"], "native process call"):
                    return False
                prior = call["end_ns"]
                if type(call.get("ok")) is not bool:
                    bad("invalid native call result")
                    return False
            if "error" in fact:
                refusals.append("native process check failed: " + row["row_id"])
                return False
            if operations != expected or any(call["ok"] is not True for call in calls):
                bad("passing process fact lacks all successful native calls")
                return False
            path, created, member = fact.get("raw_image_path"), fact.get("created_ticks"), fact.get("job_member")
            if not isinstance(path, str) or not path or "\0" in path:
                bad("invalid raw native path string")
                return False
            if ntpath.basename(path).casefold() != row["name"] or not uint(created, 2**64-1, 1) or created > upper:
                refusals.append("native snapshot identity mismatch: " + row["row_id"])
                return False
            if ((job_present and type(member) is not bool)
                    or (not job_present and member is not None)
                    or type(fact.get("alive_at_member_check")) is not bool):
                bad("invalid native membership/liveness types")
                return False
            return True

        for index, row in enumerate(rows):
            rid = "r" + str(index)
            if row.get("row_id") != rid or rid in by_row:
                raise ValueError("invalid row identifier")
            by_row[rid] = row
            if index >= len(wanted) or any(row.get(key) != wanted[index][key] for key in ("pid", "parent_pid", "name")):
                bad("row differs from original snapshot entry")
            if row.get("snapshot_upper_ticks") != upper:
                bad("row snapshot bound differs")
            allowed_row_keys = {"pid", "parent_pid", "name", "row_id", "snapshot_upper_ticks",
                                "open", "P0", "P1", "group_id", "problems", "state", "close"}
            if set(row) - allowed_row_keys:
                bad("unknown row fields or fabricated per-row evidence")
            if any(key in row for key in ("image_sha256", "image_file", "alive_after")):
                bad("fabricated per-row file/read or old-liveness semantics")
            opening = row.get("open")
            open_ok = interval(opening, snapshot["end_ns"], end, rid + "/open")
            if open_ok and type(opening.get("ok")) is not bool:
                bad("invalid retained-handle status type")
                open_ok = False
            if open_ok and opening.get("ok") is True:
                handle = opening.get("handle")
                if not uint(handle, 2**64-2, 1) or handle in retained:
                    bad("invalid/duplicated retained handle")
                    open_ok = False
                retained.add(handle)
                expected_owner = "borrowed_guard" if row["pid"] == guard_pid else "owned"
                if opening.get("ownership") != expected_owner:
                    bad("incorrect process-handle ownership")
                    open_ok = False
            else:
                refusals.append("process handle not retained: " + rid)
                open_ok = False
            first = pass_ok(row.get("P0"), row, "P0") if open_ok else False
            p0_ok[rid] = first
            if first:
                if row["P0"].get("phase") != "P0" or opening["end_ns"] > row["P0"]["begin_ns"]:
                    bad("P0 occurs before handle retention")
                all_p0_end = max(all_p0_end, row["P0"]["end_ns"])
            last = pass_ok(row.get("P1"), row, "P1") if open_ok else False
            if last:
                latest_observation = max(latest_observation, row["P1"]["end_ns"])
            okay = first and last
            if okay:
                a, b = row["P0"], row["P1"]
                if (a["end_ns"] > b["begin_ns"] or any(a[key] != b[key] for key in
                    ("raw_image_path", "created_ticks", "job_member"))
                        or (not a["alive_at_member_check"] and b["alive_at_member_check"])):
                    refusals.append("retained process facts changed: " + rid)
                    okay = False
            if row["pid"] == guard_pid:
                if (row["name"] != "process-tree-guard.exe" or not okay
                        or row["P0"]["created_ticks"] != guard_created
                        or row["P0"]["alive_at_member_check"] is not True
                        or row["P1"]["alive_at_member_check"] is not True):
                    refusals.append("held enclosing guard was lost")
                    okay = False
                if "close" in row:
                    bad("borrowed enclosing guard closed by census")
            process_ok[rid] = okay

        expected_groups = {}
        for row in rows:
            rid = row["row_id"]
            if (p0_ok[rid] and row["pid"] != guard_pid and row["P0"]["job_member"] is not True
                    and row["name"] not in COMPILER_NAMES):
                expected_groups.setdefault(row["P0"]["raw_image_path"], []).append(rid)
        if len(groups) != len(expected_groups):
            bad("exact-string group partition differs")
        group_valid, group_digest = {}, {}
        signature_keys = {"volume", "file_id_128", "size", "allocation", "links",
                          "creation_ticks", "write_ticks", "change_ticks", "attributes",
                          "directory", "delete_pending"}
        for index, group in enumerate(groups):
            gid = "g" + str(index)
            if group.get("group_id") != gid or gid in group_valid:
                raise ValueError("invalid group identifier")
            key, members = group.get("raw_image_path"), group.get("member_row_ids")
            if (index >= len(expected_groups) or key != list(expected_groups)[index]
                    or members != expected_groups.get(key)):
                bad("fixed exact-string group members changed/aliased")
            if not interval(group, all_p0_end, end, gid):
                continue
            latest_observation = max(latest_observation, group["end_ns"])
            observed = group.get("file_observation")
            good = ("file_error" not in group and type(group.get("member_callback_calls")) is int
                    and group["member_callback_calls"] == 1)
            if not good:
                refusals.append("group inspection/callback failed: " + gid)
            complete = isinstance(observed, dict) and all(field in observed for field in (
                "named_before", "held_before", "held_after", "named_after", "read_first",
                "read_second", "member_check", "rewind", "sha256", "end_ns"))
            if not complete:
                good = False
                refusals.append("group evidence incomplete: " + gid)
            if complete:
                if (type(observed.get("schema")) is not int or observed["schema"] != 3
                        or observed.get("scope") != SCOPE or observed.get("path") != key):
                    bad("wrong group file schema/scope/path")
                    good = False
                good = interval(observed, group["begin_ns"], group["end_ns"], gid + "/file") and good
                signatures = [observed[name] for name in ("named_before", "held_before", "held_after", "named_after")]
                for signature in signatures:
                    if not isinstance(signature, dict) or set(signature) != signature_keys:
                        bad("invalid complete native file signature")
                        good = False
                        continue
                    fid = signature["file_id_128"]
                    if (not uint(signature["volume"], 2**64-1)
                            or not isinstance(fid, str) or re.fullmatch("[0-9a-f]{32}", fid) is None
                            or int(fid, 16) == 0):
                        bad("invalid full volume/128-bit identity")
                        good = False
                    if (any(not uint(signature[name]) for name in ("size", "allocation"))
                            or any(not uint(signature[name], 2**32-1) for name in ("links", "attributes"))
                            or any(type(signature[name]) is not int or not -2**63 <= signature[name] < 2**63
                                   for name in ("creation_ticks", "write_ticks", "change_ticks"))
                            or signature["directory"] is not False or signature["delete_pending"] is not False
                            or (type(signature["attributes"]) is int and signature["attributes"] & 0x10)):
                        bad("invalid regular-file signature values")
                        good = False
                if any(signature != signatures[0] for signature in signatures[1:]):
                    good = False
                    refusals.append("file identity/metadata changed: " + gid)
                try:
                    points = [observed["begin_ns"], observed["read_first"]["begin_ns"],
                              observed["read_first"]["end_ns"], observed["member_check"]["begin_ns"],
                              observed["member_check"]["end_ns"], observed["rewind"]["begin_ns"],
                              observed["rewind"]["end_ns"], observed["read_second"]["begin_ns"],
                              observed["read_second"]["end_ns"], observed["end_ns"]]
                    if (any(not uint(value) for value in points) or points != sorted(points)
                            or type(observed["rewind"]["position"]) is not int or observed["rewind"]["position"] != 0):
                        bad("invalid shared read/member/rewind chronology")
                        good = False
                    digest = group.get("shared_sha256")
                    if (not isinstance(digest, str) or re.fullmatch("[0-9a-f]{64}", digest) is None
                            or digest != observed["sha256"]
                            or digest != observed["read_first"]["sha256"]
                            or digest != observed["read_second"]["sha256"]):
                        good = False
                        refusals.append("shared read digests differ/missing: " + gid)
                    group_digest[gid] = digest
                    for rid in members:
                        row = by_row[rid]
                        last = row.get("P1", {})
                        if (not process_ok[rid] or last.get("phase") != "between_reads"
                                or not uint(last.get("begin_ns")) or not uint(last.get("end_ns"))
                                or not observed["member_check"]["begin_ns"] <= last["begin_ns"]
                                <= last["end_ns"] <= observed["member_check"]["end_ns"]):
                            good = False
                            refusals.append("member not checked inside shared reads: " + rid)
                except (KeyError, TypeError):
                    good = False
                    bad("invalid complete group read structure")
            for rid in members or []:
                if rid not in by_row:
                    bad("unknown group member")
                    good = False
                elif by_row[rid].get("group_id") != gid:
                    bad("row reference differs from fixed group")
                    good = False
            group_valid[gid] = good

        # Closure is part of the measured census, after all observation work.
        for row in rows:
            if row["pid"] != guard_pid and row.get("open", {}).get("ok") is True:
                closing = row.get("close")
                close_ok = interval(closing, latest_observation, end, row["row_id"] + "/close")
                if not close_ok or closing.get("ok") is not True:
                    process_ok[row["row_id"]] = False
                    refusals.append("owned process close failed: " + row["row_id"])
                    if row.get("group_id") in group_valid:
                        group_valid[row["group_id"]] = False
        for group in groups:
            gid = group["group_id"]
            expected_valid = group_valid.get(gid, False)
            if type(group.get("valid")) is not bool or group["valid"] != expected_valid:
                bad("declared group validity differs from replay")
        expected_states = []
        veto = set(policy["veto_sha256"])
        for row in rows:
            rid, gid = row["row_id"], row.get("group_id")
            good = process_ok.get(rid, False)
            if gid is not None:
                good = good and group_valid.get(gid, False)
            elif good:
                if (row["P1"].get("phase") != "exempt"
                        or (row["pid"] != guard_pid and row["P0"]["job_member"] is not True
                            and row["name"] not in COMPILER_NAMES)):
                    good = False
                    refusals.append("eligible member lacks group or is unbracketed")
            if not good:
                state = "membership_unverified"
            elif row["pid"] == guard_pid:
                state = "pinned_enclosing_guard"
            elif row["P0"]["job_member"] is True:
                state = "campaign_member"
            elif row["name"] in COMPILER_NAMES:
                state = "compiler_present"
            elif group_digest.get(gid) in veto:
                state = "pinned_workload_outside_job"
            else:
                state = "unclassified_background"
            expected_states.append(state)
            if row.get("state") != state:
                bad("declared classification differs: " + rid)
            if state not in ALLOWED_STATES:
                refusals.append("row veto/unverified: " + rid)
        if census.get("errors"):
            refusals.append("recorded census failure")
        computed = bool(rows) and not errors and not refusals and all(state in ALLOWED_STATES for state in expected_states)
        if type(census.get("admissible")) is not bool or census["admissible"] != computed:
            bad("declared whole-census admission differs")
        return {"record_valid": not errors, "admissible": computed and not errors,
                "errors": errors, "refusals": refusals}
    except (KeyError, TypeError, ValueError, IndexError) as error:
        bad(type(error).__name__ + ": " + str(error))
        return {"record_valid": False, "admissible": False, "errors": errors, "refusals": refusals}
