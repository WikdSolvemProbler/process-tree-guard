"""Fresh one-census bridge. Native code ownership is held by the caller."""
import time

def error_record(error):
    return {"type":type(error).__name__,"message":str(error),
            "winerror":getattr(error,"winerror",None)}

class NativeCensusBackend:
    def __init__(self, process_backend, native_module, clock=time.perf_counter_ns):
        self.process_backend=process_backend
        self.native_module=native_module
        self.clock=clock
        self.record={"schema":"native-census-link-v1","attempts":0,"module_calls":0,
                     "begin_ns":None,"end_ns":None,"returned":False,"evidence":None,
                     "error":None,"clock_errors":[]}

    def __getattr__(self,name):
        return getattr(self.process_backend,name)

    def now(self):
        try:
            value=self.clock()
            if type(value) is not int or not 0<=value<=2**63-1:
                raise ValueError("invalid bridge clock")
            return value
        except BaseException as error:
            self.record["clock_errors"].append(error_record(error))
            if not isinstance(error,Exception):
                raise
            return None

    def snapshot(self):
        self.record["attempts"]+=1
        if self.record["attempts"]!=1:
            # Retain original observation; never call again to rescue a sample.
            self.record["clock_errors"].append({"type":"ValueError",
                "message":"duplicate bridge snapshot attempt","winerror":None})
            raise ValueError("one native call per census; no retry")
        self.record["begin_ns"]=self.now()
        if self.record["begin_ns"] is None:
            self.record["error"]={"type":"ValueError","message":"initial bridge clock failed","winerror":None}
            raise ValueError("initial bridge clock failed")
        try:
            self.record["module_calls"]+=1
            rows,upper,evidence=self.native_module.snapshot()
            # Preserve before any caller/collector/post-clock validation.
            self.record["evidence"]=evidence
            self.record["returned"]=True
            return rows,upper
        except BaseException as error:
            self.record["error"]=error_record(error)
            if hasattr(error,"evidence"):
                self.record["evidence"]=error.evidence
            raise
        finally:
            # Record clock failure separately; never overwrite primary evidence.
            self.record["end_ns"]=self.now()
