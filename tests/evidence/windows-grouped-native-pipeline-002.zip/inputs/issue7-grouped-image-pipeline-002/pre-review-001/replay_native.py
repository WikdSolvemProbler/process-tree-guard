"""Independent strict native-row linkage. No native imports or calls.

Only emitted UTF16 prefixes are independently replayed. Unemitted tail bytes
remain a pinned-runtime check backed by its qualified controls, never a new raw
tail/loaded-image/immutable-memory proof.
"""
import json
import re

U32=("version","bytes","status","primary_error","close_error","clock_error",
     "count","capacity","name_units","reserved")
I64=("frequency","begin_qpc","snapshot_upper_begin_qpc","snapshot_upper_end_qpc",
     "enumerate_begin_qpc","enumerate_end_qpc","close_begin_qpc","close_end_qpc","end_qpc")
EVIDENCE={"begin_ns","scope","native_begin_ns","native_end_ns","native","raw_utf16_rows","end_ns"}
SCOPE="same full Toolhelp observation; module setup separate; all row work inside"

def integer(value,low=0,high=2**63-1):
    return type(value) is int and low<=value<=high

def ordered(*values):
    return all(integer(value) for value in values) and list(values)==sorted(values)

def strict_json(raw):
    def pairs(items):
        result={}
        for key,value in items:
            if key in result:raise ValueError("duplicate JSON key")
            result[key]=value
        return result
    def noninteger(value):raise ValueError("noninteger native JSON token: "+value)
    return json.loads(raw,object_pairs_hook=pairs,parse_float=noninteger,parse_constant=noninteger)

def decode_observation(e):
    errors=[]
    def require(value,message):
        if not value:errors.append(message)
    if not isinstance(e,dict):
        return None,["missing native observation"]
    require(set(e)==EVIDENCE,"native observation schema/error differs")
    if set(e)!=EVIDENCE:return None,errors
    require(e["scope"]==SCOPE,"native observation scope differs")
    require(ordered(e["begin_ns"],e["native_begin_ns"],e["native_end_ns"],e["end_ns"]),
            "Python native-call ordering")
    n=e["native"]
    if not isinstance(n,dict) or set(n)!=set(U32+I64+("upper_ticks",)):
        return None,errors+["native wire header differs"]
    require(all(integer(n[key],0,2**32-1) for key in U32),"native DWORD type/range")
    require(integer(n["upper_ticks"],1,2**64-1),"native precise upper type/range")
    require(all(integer(n[key],1,2**63-1) for key in I64),"native QPC type/range")
    require((n["version"],n["bytes"],n["capacity"],n["name_units"],n["reserved"])
            ==(1,120,4096,260,0),"native ABI/constants differ")
    require(all(n[key]==0 for key in ("status","primary_error","close_error","clock_error")),
            "native API/clock/close refusal")
    require(integer(n["count"],1,4096),"native row count exceeds fixed capacity")
    require(ordered(*(n[key] for key in I64[1:])),"native QPC chain")
    if errors:return None,errors
    # Same pinned Windows QPC source: compare exact rational call positions,
    # without float conversion, selective reread or a physical API error claim.
    require(e["native_begin_ns"]*n["frequency"]<=n["begin_qpc"]*1_000_000_000
            and n["end_qpc"]*1_000_000_000<=e["native_end_ns"]*n["frequency"],
            "C clock positions outside Python native call")
    raw=e["raw_utf16_rows"]
    if not isinstance(raw,list) or len(raw)!=n["count"]:
        return None,errors+["raw native population/count differs"]
    entries=[];seen=set()
    for index,row in enumerate(raw):
        if not isinstance(row,dict) or set(row)!={"pid","parent_pid","name_units","name_utf16le_hex"}:
            errors.append("native row schema");continue
        pid,parent,units,text=(row[key] for key in ("pid","parent_pid","name_units","name_utf16le_hex"))
        if (not integer(pid,0,2**32-1) or not integer(parent,0,2**32-1)
                or not integer(units,1,259) or not isinstance(text,str)
                or len(text)!=units*4 or re.fullmatch("[0-9a-f]+",text) is None):
            errors.append("native row scalar/hex bounds");continue
        try:name=bytes.fromhex(text).decode("utf-16le","surrogatepass")
        except (ValueError,UnicodeError):
            errors.append("native UTF16 decoding");continue
        if "\0" in name or not name or pid in seen:
            errors.append("native NUL/empty/duplicate identity");continue
        seen.add(pid)
        entries.append({"pid":pid,"parent_pid":parent,"name":name.casefold()})
    require(len(entries)==n["count"],"native complete decoded population differs")
    return entries,errors

def replay(census,link):
    errors=[]
    def require(value,message):
        if not value:errors.append(message)
    try:
        require(isinstance(link,dict) and set(link)=={"schema","attempts","module_calls",
                "begin_ns","end_ns","returned","evidence","error","clock_errors"},"native bridge schema")
        if errors:return {"record_valid":False,"admissible":False,"errors":errors}
        require(link["schema"]=="native-census-link-v1"
                and type(link["attempts"]) is int and link["attempts"]==1
                and type(link["module_calls"]) is int and link["module_calls"]==1,
                "native bridge count/retry")
        require(link["returned"] is True and link["error"] is None and link["clock_errors"]==[],
                "native bridge operation/clock refused")
        require(ordered(link["begin_ns"],link["end_ns"]),"native bridge clock order")
        entries,observed_errors=decode_observation(link["evidence"]);errors.extend(observed_errors)
        snapshot=census["snapshot"]
        require(isinstance(snapshot,dict),"census snapshot missing")
        require(ordered(snapshot["begin_ns"],link["begin_ns"],link["evidence"]["begin_ns"],
                link["evidence"]["end_ns"],link["end_ns"],snapshot["end_ns"]),
                "native observation outside collector snapshot")
        require(entries==snapshot["entries"],"every native row differs from complete census entries")
        require(type(snapshot["upper_ticks"]) is int
                and snapshot["upper_ticks"]==link["evidence"]["native"]["upper_ticks"],
                "native/census precise upper differs")
    except (KeyError,TypeError,ValueError,AttributeError):
        errors.append("incomplete native-census link")
    return {"record_valid":not errors,"admissible":not errors,"errors":errors,
            "independent_tail_bytes":False,
            "scope":"all emitted raw native rows/header/clocks linked; tail predicate relies on pinned runtime"}

def component_proof(raw,expected_seal_sha):
    rows=[strict_json(line) for line in raw.splitlines() if line.strip()]
    if [row.get("kind") for row in rows]!=["context","module_setup","snapshot_observed","snapshot",
                                          "output_timing","module_cleanup","terminal"]:
        raise ValueError("native prerequisite event sequence differs")
    context,setup,observed,snapshot,timing,cleanup,terminal=rows
    if context.get("seal_sha256")!=expected_seal_sha:
        raise ValueError("native prerequisite seal context differs")
    entries,errors=decode_observation(snapshot.get("evidence"))
    if errors or entries!=snapshot.get("rows") or snapshot.get("upper_ticks")!=snapshot["evidence"]["native"]["upper_ticks"]:
        raise ValueError("native prerequisite raw population refuses: "+repr(errors))
    if (observed.get("rows")!=snapshot["rows"] or observed.get("evidence")!=snapshot["evidence"]
            or observed.get("upper_ticks")!=snapshot["upper_ticks"]):
        raise ValueError("native prerequisite observation lost before validation")
    by_pid={row["pid"]:row for row in entries}
    if (not integer(snapshot.get("observer_pid"),1,2**32-1)
            or not integer(snapshot.get("guard_pid"),1,2**32-1)
            or snapshot["observer_pid"]==snapshot["guard_pid"]
            or by_pid.get(snapshot["observer_pid"],{}).get("name")!="python.exe"
            or by_pid.get(snapshot["guard_pid"],{}).get("name")!="process-tree-guard.exe"
            or not integer(snapshot.get("observer_created_ticks"),1,snapshot["upper_ticks"])
            or not integer(snapshot.get("guard_created_ticks"),1,snapshot["upper_ticks"])
            or snapshot.get("held_observer_alive") is not True or snapshot.get("held_guard_alive") is not True):
        raise ValueError("native prerequisite held identities unverified")
    if (type(terminal.get("code")) is not int or terminal["code"]!=0
            or terminal.get("qualified") is not True
            or type(terminal.get("native_capture_attempts")) is not int or terminal["native_capture_attempts"]!=1
            or type(terminal.get("native_observation_count")) is not int or terminal["native_observation_count"]!=1
            or terminal.get("controller_identity_validated") is not True
            or not integer(terminal.get("baseline_handles"),1,2**32-1)
            or type(terminal.get("final_handles")) is not int
            or terminal["final_handles"]!=terminal["baseline_handles"]
            or not ordered(terminal.get("observed_ns"),terminal.get("deadline_ns"))
            or terminal["observed_ns"]>=terminal["deadline_ns"]
            or terminal.get("primary_failure") is not None or terminal.get("module_cleanup_failure") is not None
            or terminal.get("reporting_failures")!=[] or terminal.get("cleanup_errors")!=[]
            or terminal.get("census_qualified") is not False or terminal.get("phase_qualified") is not False
            or terminal.get("campaign_qualified") is not False or terminal.get("benchmark_slots")!=0):
        raise ValueError("native prerequisite terminal qualification refuses")
    if (cleanup.get("primary_failure") is not None or cleanup.get("cleanup_failure") is not None
            or cleanup.get("evidence",{}).get("cleanup_errors")!=[]
            or not ordered(cleanup["evidence"].get("cleanup_begin_ns"),cleanup["evidence"].get("cleanup_end_ns"))):
        raise ValueError("native prerequisite owned module cleanup refuses")
    return {"qualified":True,"rows":len(entries),"scope":"native component prerequisite only, not new census proof"}
