// Offline ZIP audit only: no extraction, subprocess, archived-code imports or native calls.
import crypto from 'node:crypto';
import zlib from 'node:zlib';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const need=(v,m)=>{if(!v)throw Error(m)};
export function crc32(b){let c=0xffffffff;for(let x of b){c^=x;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0)}return (c^0xffffffff)>>>0}
export function decodeZip(b){
 let end=b.length-22;need(end>=0&&b.readUInt32LE(end)===0x06054b50,'exact EOCD');
 let count=b.readUInt16LE(end+10),size=b.readUInt32LE(end+12),off=b.readUInt32LE(end+16),entries=new Map();
 need(b.readUInt16LE(end+4)===0&&b.readUInt16LE(end+6)===0&&count===b.readUInt16LE(end+8)&&b.readUInt16LE(end+20)===0&&off+size===end,'single complete ZIP');
 let pos=off;
 for(let i=0;i<count;i++){
  need(b.readUInt32LE(pos)===0x02014b50,'central signature');let flag=b.readUInt16LE(pos+8),method=b.readUInt16LE(pos+10),crc=b.readUInt32LE(pos+16),compressed=b.readUInt32LE(pos+20),length=b.readUInt32LE(pos+24),nl=b.readUInt16LE(pos+28),xl=b.readUInt16LE(pos+30),cl=b.readUInt16LE(pos+32),local=b.readUInt32LE(pos+42);
  let name=b.subarray(pos+46,pos+46+nl).toString('utf8');need(flag===0x800&&method===8&&!name.startsWith('/')&&!name.includes('\\')&&!name.split('/').includes('..')&&!entries.has(name),'safe unique deflate name');
  need(b.readUInt32LE(local)===0x04034b50&&b.readUInt16LE(local+6)===flag&&b.readUInt16LE(local+8)===method&&b.readUInt32LE(local+14)===crc&&b.readUInt32LE(local+18)===compressed&&b.readUInt32LE(local+22)===length,'local header binding');
  let lnl=b.readUInt16LE(local+26),lxl=b.readUInt16LE(local+28);need(b.subarray(local+30,local+30+lnl).toString('utf8')===name,'local filename');let start=local+30+lnl+lxl;need(start+compressed<=off,'data before central directory');let raw=zlib.inflateRawSync(b.subarray(start,start+compressed));need(raw.length===length&&crc32(raw)===crc,'member size/CRC');entries.set(name,raw);pos+=46+nl+xl+cl;
 }need(pos===end,'complete central directory');return entries;
}
export function audit(b){
 let e=decodeZip(b),index=JSON.parse(e.get('INDEX.json'));need(e.size===Object.keys(index).length+1,'exhaustive index');
 for(let[n,p]of Object.entries(index)){need(e.has(n),'indexed member missing');let raw=e.get(n);need(raw.length===p.bytes&&sha(raw)===p.sha256,'member SHA '+n)}
 let pre='inputs/issue7-grouped-image-pipeline-002/';let rows=n=>e.get(pre+n).toString('utf8').trim().split(/\r?\n/).map(JSON.parse);
 let d=rows('diagnostic-001.jsonl'),c=rows('census-001.jsonl'),t=rows('telemetry-001.jsonl'),samples=d.filter(x=>x.kind==='sample'),terminal=d.at(-1);
 need(sha(e.get(pre+'diagnostic-001.jsonl'))==='4092db50df3400e88e9c9010fcb15d9a8ad89c10d2cd758f4fa186774d0108f3','exact raw capture');
 need(samples.length===3&&c.length===3&&t.length===3,'three complete streams');let expected=[40946100,59638700,48262100];for(let i=0;i<3;i++){need(samples[i].strict_complete_ns===expected[i]&&samples[i].finished_ns-samples[i].stamp_begin_ns===expected[i],'strict arithmetic');need(samples[i].time_budget_pass===(i!==1)&&samples[i].row_count===26&&samples[i].group_count===4,'retained cutoff result');need(samples[i].independent_replay.record_valid===true&&samples[i].native_population_replay.record_valid===true&&samples[i].native_sample_errors.length===0,'replay/native sample facts')}
 need(terminal.code===0&&terminal.diagnostic_pipeline_qualified===false&&terminal.phase_qualified===false&&terminal.campaign_qualified===false&&terminal.benchmark_slots===0,'failed qualification retained');need(JSON.stringify(terminal.partial_phase_verdict.reasons)==='["coverage"]','coverage refusal');need(terminal.observed_ns<terminal.deadline_ns&&terminal.primary_failure===null&&terminal.cleanup_failure===null&&terminal.reporting_failures.length===0,'clean diagnostic terminal');
 let unit=JSON.parse(e.get(pre+'unit-receipt-001.json'));need(unit.tests===34&&unit.qualified===true&&unit.code===0&&unit.failures===0&&unit.test_errors===0&&unit.skipped===0&&unit.errors.length===0,'actual pure34 receipt');for(let[n,h]of Object.entries(unit.artifact_sha256))need(sha(e.get(pre+n))===h,'unit artifact');
 for(let i=1;i<=4;i++)need([...e.keys()].some(n=>n.startsWith(pre+'pre-review-00'+i+'/')),'preserved draft '+i);
 return {archive_sha256:sha(b),members:e.size,indexed_members:Object.keys(index).length,strict_ms:expected.map(x=>x/1e6),qualification:'FAILED',benchmark_slots:0,scope:'Offline member CRC/SHA/index and selected raw arithmetic only; detailed lossless full128/counter/group/population audits retained separately. No native or benchmark execution.'};
}
