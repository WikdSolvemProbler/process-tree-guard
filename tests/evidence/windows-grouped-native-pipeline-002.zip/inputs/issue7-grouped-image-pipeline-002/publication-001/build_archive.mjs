// Deterministic offline ZIP builder. Caller supplies captured buffers; no subprocess/native experiment.
import zlib from 'node:zlib';
const need=(v,m)=>{if(!v)throw Error(m)};
const crc32=b=>{let c=0xffffffff;for(let x of b){c^=x;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0)}return (c^0xffffffff)>>>0};
export function build(entries){
 const local=[],central=[];let offset=0;
 for(const[name,raw]of [...entries].sort((a,b)=>a[0].localeCompare(b[0],'en'))){
  need(!name.startsWith('/')&&!name.includes('\\')&&!name.split('/').includes('..'),'unsafe member');let n=Buffer.from(name),compressed=zlib.deflateRawSync(raw,{level:6}),crc=crc32(raw);need(n.length<65536&&raw.length<0xffffffff&&compressed.length<0xffffffff,'ZIP32 bounds');
  let l=Buffer.alloc(30);l.writeUInt32LE(0x04034b50);l.writeUInt16LE(20,4);l.writeUInt16LE(0x800,6);l.writeUInt16LE(8,8);l.writeUInt16LE(33,12);l.writeUInt32LE(crc,14);l.writeUInt32LE(compressed.length,18);l.writeUInt32LE(raw.length,22);l.writeUInt16LE(n.length,26);local.push(l,n,compressed);
  let c=Buffer.alloc(46);c.writeUInt32LE(0x02014b50);c.writeUInt16LE(20,4);c.writeUInt16LE(20,6);c.writeUInt16LE(0x800,8);c.writeUInt16LE(8,10);c.writeUInt16LE(33,14);c.writeUInt32LE(crc,16);c.writeUInt32LE(compressed.length,20);c.writeUInt32LE(raw.length,24);c.writeUInt16LE(n.length,28);c.writeUInt32LE(offset,42);central.push(c,n);offset+=l.length+n.length+compressed.length;
 }
 let cd=Buffer.concat(central),end=Buffer.alloc(22);need(entries.size<65536&&offset+cd.length<0xffffffff,'ZIP32 archive bounds');end.writeUInt32LE(0x06054b50);end.writeUInt16LE(entries.size,8);end.writeUInt16LE(entries.size,10);end.writeUInt32LE(cd.length,12);end.writeUInt32LE(offset,16);return Buffer.concat([...local,cd,end]);
}
