// FS-only independent offline audit; no process/DLL/native API launches.
// Integer JSON tokens are BigInt throughout. Decimal-string output preserves precision.
var fs=await import("node:fs/promises");
var crypto=await import("node:crypto");
var sec="C:/Users/Peter/process-tree-guard/target/codex-security";
var pipe2=sec+"/issue7-grouped-image-pipeline-002";
var sha=raw=>crypto.createHash("sha256").update(raw).digest("hex");

function lossless(text){
 let i=0;function ws(){while(/\s/.test(text[i]||"")&&i<text.length)i++;}
 function val(){ws();let c=text[i];
  if(c==='"'){let a=i++;while(i<text.length){if(text[i]==='\\'){i+=2;continue;}if(text[i++]==='"')return JSON.parse(text.slice(a,i));}throw Error("unterminated string");}
  if(c==='['){i++;let a=[];ws();if(text[i]===']'){i++;return a;}while(true){a.push(val());ws();if(text[i++]===']')return a;if(text[i-1]!==',')throw Error("array delimiter");}}
  if(c==='{'){i++;let o={};ws();if(text[i]==='}'){i++;return o;}while(true){let k=val();if(typeof k!=="string"||Object.hasOwn(o,k))throw Error("duplicate/nonstring key");ws();if(text[i++]!==':')throw Error("colon");o[k]=val();ws();if(text[i++]==='}')return o;if(text[i-1]!==',')throw Error("object delimiter");}}
  for(let [token,v]of [["true",true],["false",false],["null",null]])if(text.startsWith(token,i)){i+=token.length;return v;}
  let m=/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/.exec(text.slice(i));if(!m)throw Error("JSON token at"+i);i+=m[0].length;return /[.eE]/.test(m[0])?Number(m[0]):BigInt(m[0]);
 }let out=val();ws();if(i!==text.length)throw Error("JSON trailing bytes");return out;
}
function eq(a,b){
 if(typeof a!==typeof b)return false;if(a===null||b===null||typeof a!=="object")return Object.is(a,b);
 if(Array.isArray(a)!==Array.isArray(b))return false;let ak=Object.keys(a),bk=Object.keys(b);
 return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&eq(a[k],b[k]));
}
function ordered(...xs){return xs.every(x=>typeof x==="bigint"&&x>=0n)&&xs.every((x,i)=>!i||x>=xs[i-1]);}
function safeJSON(value){return JSON.stringify(value,(k,v)=>typeof v==="bigint"?v.toString():v,2)+"\n";}
var failures=[];
function check(v,s){if(!v)failures.push(s);}
function span(a){return a.end_ns-a.begin_ns;}
function sums(a){return a.reduce((s,x)=>s+x,0n);}
var diag=(await fs.readFile(pipe2+"/diagnostic-001.jsonl","utf8")).trim().split(/\r?\n/).map(lossless);
var census=(await fs.readFile(pipe2+"/census-001.jsonl","utf8")).trim().split(/\r?\n/).map(lossless);
var tel=(await fs.readFile(pipe2+"/telemetry-001.jsonl","utf8")).trim().split(/\r?\n/).map(lossless);
var context=diag[0], identity=diag[1], setup=diag[2], samples=diag.filter(x=>x.kind==="sample"),cleanup=diag.at(-2),terminal=diag.at(-1);
var plan=lossless(await fs.readFile(pipe2+"/plan.json","utf8"));
check(eq(diag.map(x=>x.kind),["context","identity","module_setup","sample","sample","sample","module_cleanup","terminal"]),"event sequence");
check(samples.length===3&&census.length===3&&tel.length===3,"three complete streams");
check(eq(context.source_sha256,terminal.source_sha256),"pre/post binding map equality");
check(terminal.code===0n&&terminal.completed===3n&&terminal.primary_failure===null&&terminal.cleanup_failure===null&&eq(terminal.reporting_failures,[]),"terminal code/errors");
check(terminal.diagnostic_pipeline_qualified===false&&terminal.phase_qualified===false&&terminal.campaign_qualified===false&&terminal.benchmark_slots===0n,"no qualification or slots");
check(ordered(terminal.observed_ns,terminal.deadline_ns)&&terminal.observed_ns<terminal.deadline_ns,"terminal deadline");
var pinPaths=new Map();function add(path,pin){if(pinPaths.has(path))check(pinPaths.get(path)===pin,"conflicting pin "+path);pinPaths.set(path,pin);}
add(pipe2+"/plan.json","591d98b8e2830caffba258603af19a0950f3098ebf6cd1b16bad7d5e27d9b26a");add(pipe2+"/qualify_pipeline.py",plan.driver_sha256);
for(var[n,h]of Object.entries(plan.local_source_sha256))add(pipe2+"/"+n,h);
for(var[n,h]of Object.entries(plan.grouped_source_sha256))add(sec+"/issue7-grouped-image-census-001/"+n,h);
var fixed=sec+"/issue7-quiet-launch-013";add(fixed+"/manifest.json","313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae");
var manifest=lossless(await fs.readFile(fixed+"/manifest.json","utf8"));
for(var[n,h]of Object.entries(manifest.file_sha256))add(fixed+"/"+n,h);
for(var group of ["tools","fingerprints"])for(var v of Object.values(manifest[group]))add(v.path,v.sha256);
var inp=sec+"/issue7-quiet-campaign-inputs-002";add(inp+"/inputs.json",manifest.input_manifest_sha256);var ins=lossless(await fs.readFile(inp+"/inputs.json","utf8"));
add(inp+"/checkout/tests/campaign/windows_slot_job.py",ins.file_sha256["tests/campaign/windows_slot_job.py"]);
add(plan.native_control_receipt.path,plan.native_control_receipt.sha256);var oldReceipt=lossless(await fs.readFile(plan.native_control_receipt.path,"utf8"));
for(var[n,h]of Object.entries(oldReceipt.artifact_sha256))add(plan.native_control_receipt.path.replace(/[^/]+$/,"")+n,h);
add(pipe2+"/unit-receipt-001.json",plan.unit_prerequisite.sha256);var ur=lossless(await fs.readFile(pipe2+"/unit-receipt-001.json","utf8"));add(pipe2+"/unit-plan.json",ur.plan_sha256);
for(var[n,h]of Object.entries(ur.artifact_sha256))add(pipe2+"/"+n,h);
var up=lossless(await fs.readFile(pipe2+"/unit-plan.json","utf8"));for(var[n,h]of Object.entries(up.source_sha256))add(pipe2+"/"+n,h);
add(plan.native_component.raw_path,plan.native_component.raw_sha256);add(plan.native_component.seal_path,plan.native_component.seal_sha256);
for(var[p,h]of Object.entries(plan.native_component.evidence_sha256))add(p,h);
var seal=lossless(await fs.readFile(plan.native_component.seal_path,"utf8"));
var pathmod=await import("node:path");for(var[n,h]of Object.entries(seal.source_sha256))add(pathmod.resolve(pathmod.dirname(plan.native_component.seal_path),n).replaceAll("\\","/"),h);
for(var[p,h]of Object.entries(seal.tool_sha256))add(p,h);
add(plan.adapter_path,plan.adapter_sha256);add(plan.dll_path,plan.dll_sha256);
for(var[p,h]of pinPaths)check(sha(await fs.readFile(p))===h,"file pin differs "+p);
check(sha(await fs.readFile(pipe2+"/diagnostic-001.jsonl"))==="4092db50df3400e88e9c9010fcb15d9a8ad89c10d2cd758f4fa186774d0108f3","raw diagnostic SHA");
var policy=manifest.image_policy;
var compilerNames=new Set(["cargo.exe","rustc.exe","rustdoc.exe","cl.exe","link.exe","clang.exe","clang-cl.exe","lld.exe","lld-link.exe","rust-lld.exe","gcc.exe","g++.exe","cc1.exe","cc1plus.exe","msbuild.exe","cmake.exe","ninja.exe"]);
var relevant=new Set([...compilerNames,"python.exe","pythonw.exe","python3.exe","pytest.exe","ptg.exe","process-tree-guard.exe","testkit.exe","sysprims.exe","processkit-cli.exe","timeout.exe",...policy.pinned_basenames]);
var stages=[],windowAudit=[],rawNativeCounts=[],allUnicodeNamesASCII=true;
for(var k=0;k<3;k++){
 let out=samples[k],row=census[k],c=row.census,l=row.native_link,e=l.evidence,n=e.native,t=tel[k].raw;
 check(out.index===BigInt(k)&&row.index===BigInt(k)&&tel[k].index===BigInt(k),"sample indices "+k);
 check(eq(out.native_observation,l),"emitted native observation equality "+k);
 check(l.schema==="native-census-link-v1"&&l.attempts===1n&&l.module_calls===1n&&l.returned===true&&l.error===null&&eq(l.clock_errors,[]),"one native call no failure "+k);
 check(ordered(c.begin_ns,c.snapshot.begin_ns,l.begin_ns,e.begin_ns,e.native_begin_ns,e.native_end_ns,e.end_ns,l.end_ns,c.snapshot.end_ns,c.end_ns),"native/census bounds "+k);
 check(n.version===1n&&n.bytes===120n&&n.capacity===4096n&&n.name_units===260n&&n.reserved===0n,"native ABI "+k);
 check(["status","primary_error","close_error","clock_error"].every(a=>n[a]===0n),"native status "+k);
 let qkeys=["begin_qpc","snapshot_upper_begin_qpc","snapshot_upper_end_qpc","enumerate_begin_qpc","enumerate_end_qpc","close_begin_qpc","close_end_qpc","end_qpc"];
 check(ordered(...qkeys.map(a=>n[a]))&&n.frequency>0n,"native clocks "+k);
 check(e.native_begin_ns<=n.begin_qpc*1000000000n/n.frequency&&n.end_qpc*1000000000n/n.frequency<=e.native_end_ns,"CPython floor cross bounds "+k);
 check(n.count===BigInt(e.raw_utf16_rows.length)&&n.count>=1n&&n.count<=4096n,"native count "+k);
 let entries=[],pids=new Set();
 for(let r of e.raw_utf16_rows){
  check(typeof r.pid==="bigint"&&r.pid>=0n&&r.pid<2n**32n&&typeof r.parent_pid==="bigint"&&r.parent_pid>=0n&&r.parent_pid<2n**32n,"PID DWORD");
  check(r.name_units>=1n&&r.name_units<260n&&r.name_utf16le_hex.length===Number(r.name_units)*4&&/^[a-f0-9]+$/.test(r.name_utf16le_hex),"native prefix bounds");
  let name=Buffer.from(r.name_utf16le_hex,"hex").toString("utf16le");allUnicodeNamesASCII&&=/^[\x00-\x7f]*$/.test(name);
  check(name.length>0&&!name.includes("\0")&&!pids.has(r.pid.toString()),"native decoded name/uniquePID");pids.add(r.pid.toString());
  entries.push({pid:r.pid,parent_pid:r.parent_pid,name:name.toLowerCase()});
 }
 check(eq(entries,c.snapshot.entries)&&c.snapshot.upper_ticks===n.upper_ticks,"full native population equality "+k);
 rawNativeCounts.push(n.count);
 let expected=entries.filter(r=>r.pid!==c.observer_pid&&(r.pid===c.guard_pid||relevant.has(r.name)));
 check(eq(expected,c.rows.map(r=>({pid:r.pid,parent_pid:r.parent_pid,name:r.name}))),"complete relevant partition "+k);
 check(c.observer_pid===identity.observer_pid&&c.guard_pid===identity.guard_pid&&c.guard_created_ticks===identity.guard_created_ticks&&c.job_present===false,"held context "+k);
 check(c.errors.length===0&&c.admissible===true,"census errors/admission "+k);
 let members=new Map(),held=new Set();
 for(let r of c.rows){
  check(r.snapshot_upper_ticks===n.upper_ticks&&r.open.ok===true&&ordered(r.open.begin_ns,r.open.end_ns),"row open "+k);
  check(!held.has(r.open.handle.toString()),"unique retained handles");held.add(r.open.handle.toString());
  for(let fact of [r.P0,r.P1]){
   check(ordered(fact.begin_ns,fact.end_ns)&&fact.job_member===null&&typeof fact.alive_at_member_check==="boolean"&&fact.created_ticks>0n&&fact.created_ticks<=n.upper_ticks,"process fact typed/birth");
   check(eq(fact.calls.map(x=>x.operation),["path","creation","alive"]),"process check coverage");
   let previous=fact.begin_ns;for(let call of fact.calls){check(call.ok===true&&ordered(previous,call.begin_ns,call.end_ns,fact.end_ns),"process call bounds");previous=call.end_ns;}
   check(fact.raw_image_path.split(/[\\/]/).at(-1).toLowerCase()===r.name,"process reported path basename");
  }
  check(r.P0.end_ns<=r.P1.begin_ns&&r.P0.raw_image_path===r.P1.raw_image_path&&r.P0.created_ticks===r.P1.created_ticks&&!(r.P0.alive_at_member_check===false&&r.P1.alive_at_member_check===true),"P0/P1 retained identity");
  if(r.pid===c.guard_pid)check(r.open.ownership==="borrowed_guard"&&r.P0.created_ticks===c.guard_created_ticks&&r.P0.alive_at_member_check&&r.P1.alive_at_member_check,"held guard");
  else check(r.open.ownership==="owned"&&r.close.ok===true&&ordered(r.P1.end_ns,r.close.begin_ns,r.close.end_ns,c.end_ns),"owned handle closure");
  check(eq(r.problems,[]),"row problems");
  if(r.group_id){if(!members.has(r.group_id))members.set(r.group_id,[]);members.get(r.group_id).push(r);}
  else check(r.P1.phase==="exempt"&&(r.pid===c.guard_pid||compilerNames.has(r.name)),"exempt partition");
 }
 let paths=new Set(),previousGroup=c.snapshot.end_ns;
 for(let gr of c.groups){
  check(!paths.has(gr.raw_image_path),"exact path group distinct");paths.add(gr.raw_image_path);
  let rs=members.get(gr.group_id)||[],f=gr.file_observation;
  check(eq(rs.map(r=>r.row_id),gr.member_row_ids)&&rs.length>0,"fixed group membership");
  check(ordered(previousGroup,gr.begin_ns,f.begin_ns,f.end_ns,gr.end_ns),"group sequential envelope");previousGroup=gr.end_ns;
  check(gr.member_callback_calls===1n&&gr.valid===true&&eq(gr.problems,[])&&f.schema===3n&&f.path===gr.raw_image_path,"group native result");
  let sig=f.named_before;check(["held_before","held_after","named_after"].every(a=>eq(sig,f[a])),"full128 metadata stable "+k);
  check(sig.volume>=0n&&sig.volume<2n**64n&&/^[a-f0-9]{32}$/.test(sig.file_id_128)&&!/^0+$/.test(sig.file_id_128)&&sig.directory===false&&sig.delete_pending===false&&(sig.attributes&16n)===0n,"file identity/type");
  check(ordered(f.begin_ns,f.read_first.begin_ns,f.read_first.end_ns,f.member_check.begin_ns,f.member_check.end_ns,f.rewind.begin_ns,f.rewind.end_ns,f.read_second.begin_ns,f.read_second.end_ns,f.end_ns),"two reads callback rewind");
  check(f.rewind.position===0n&&gr.shared_sha256===f.sha256&&f.read_first.sha256===f.sha256&&f.read_second.sha256===f.sha256&&/^[a-f0-9]{64}$/.test(f.sha256),"two digest/seek consistency");
  for(let r of rs){check(r.P0.raw_image_path===gr.raw_image_path&&r.P0.end_ns<=f.read_first.begin_ns&&r.P1.phase==="between_reads"&&ordered(f.member_check.begin_ns,r.P1.begin_ns,r.P1.end_ns,f.member_check.end_ns),"P0/read1/P1/read2 member bracket");}
 }
 for(let r of c.rows){
  let gr=c.groups.find(g=>g.group_id===r.group_id),state=r.pid===c.guard_pid?"pinned_enclosing_guard":compilerNames.has(r.name)?"compiler_present":policy.veto_sha256.includes(gr?.shared_sha256)?"pinned_workload_outside_job":"unclassified_background";
  check(r.state===state&&["pinned_enclosing_guard","unclassified_background"].includes(state),"independent image classification");
 }
 check(t.schema===2n&&t.native_errors.length===0&&t.job_before===null&&t.job_after===null&&t.groups===1n&&t.processors===16n,"telemetry native shape/context");
 check(ordered(out.stamp_begin_ns,t.monotonic_ns,out.stamp_end_ns,out.raw_emit_end_ns,c.begin_ns,c.end_ns,out.census_return_ns,out.finished_ns),"strict output cutoff chain");
 check(out.strict_complete_ns===out.finished_ns-out.stamp_begin_ns&&out.legacy_sample_to_return_ns===out.census_return_ns-t.monotonic_ns,"latency arithmetic");
 let budget=out.strict_complete_ns<=50000000n&&out.legacy_sample_to_return_ns<=50000000n;
 check(out.time_budget_pass===budget&&out.snapshot_qualified===budget&&row.source_monotonic_ns===t.monotonic_ns&&row.census_return_ns===out.census_return_ns,"budget verdict");
 check(out.native_population_replay.record_valid===true&&out.native_population_replay.admissible===true&&out.native_population_replay.independent_tail_bytes===false&&out.independent_replay.record_valid===true&&out.independent_replay.admissible===true&&eq(out.native_sample_errors,[]),"emitted replay verdicts");
 let calls=t.calls;check([calls.job_before_begin,calls.job_before_end,calls.job_after_begin,calls.job_after_end].every(x=>x===0n),"noJob native call zeros");
 check(ordered(t.monotonic_ns,calls.awake_before_begin,calls.awake_before_end,calls.system_begin,calls.system_end,calls.awake_after_begin,calls.awake_after_end,t.monotonic_ns+t.read_ns),"system single-read clock bracket");
 check(t.awake_ticks<=t.system_awake_before&&t.system_awake_before<=t.system_awake_after&&(t.system_awake_after-t.awake_ticks)*100n<=t.read_ns+100n&&t.read_ns<=10000000n&&t.system.idle<=t.system.kernel,"sample awake/readspan/counter order");
 let snapshotSpan=span(c.snapshot),cNativeSpan=n.end_qpc-n.begin_qpc;
 let nativeNs=q=>q*1000000000n/n.frequency;
 let open=sums(c.rows.map(r=>span(r.open))),P0=sums(c.rows.map(r=>span(r.P0))),exemptP1=sums(c.rows.filter(r=>!r.group_id).map(r=>span(r.P1))),P1=sums(c.rows.filter(r=>r.group_id).map(r=>span(r.P1))),closes=sums(c.rows.filter(r=>r.close).map(r=>span(r.close))),groupTotal=sums(c.groups.map(span)),reads=sums(c.groups.map(g=>span(g.file_observation.read_first)+span(g.file_observation.read_second)));
 let collectorParts=[snapshotSpan,open,P0,exemptP1,closes,groupTotal],censusSpan=span(c);
 check(sums(collectorParts)<=censusSpan,"nonoverlap decomposition envelope");
 stages.push({index:k,strict_ns:out.strict_complete_ns,stamp_ns:out.stamp_end_ns-out.stamp_begin_ns,raw_emit_ns:out.raw_emit_end_ns-out.stamp_end_ns,to_census_begin_ns:c.begin_ns-out.raw_emit_end_ns,census_ns:censusSpan,census_return_gap_ns:out.census_return_ns-c.end_ns,census_output_flush_ns:out.finished_ns-out.census_return_ns,
  snapshot_wrapper_ns:snapshotSpan,bridge_and_collector_snapshot_overhead_ns:snapshotSpan-span(e),native_python_allocation_ns:e.native_begin_ns-e.begin_ns,native_call_ns:e.native_end_ns-e.native_begin_ns,native_postdecode_ns:e.end_ns-e.native_end_ns,
  c_snapshot_plus_upper_ns:nativeNs(n.snapshot_upper_end_qpc-n.snapshot_upper_begin_qpc),c_enumerate_ns:nativeNs(n.enumerate_end_qpc-n.enumerate_begin_qpc),c_close_ns:nativeNs(n.close_end_qpc-n.close_begin_qpc),c_native_remainder_ns:nativeNs(cNativeSpan)-nativeNs(n.snapshot_upper_end_qpc-n.snapshot_upper_begin_qpc)-nativeNs(n.enumerate_end_qpc-n.enumerate_begin_qpc)-nativeNs(n.close_end_qpc-n.close_begin_qpc),
  process_open_ns:open,P0_ns:P0,exempt_P1_ns:exemptP1,process_close_ns:closes,groups_total_ns:groupTotal,groups_member_P1_ns:P1,groups_excluding_member_P1_ns:groupTotal-P1,shared_read_ns:reads,group_nonread_nonmember_ns:groupTotal-P1-reads,collector_unattributed_ns:censusSpan-sums(collectorParts),row_count:c.rows.length,group_count:c.groups.length,native_rows:n.count});
 if(k){
  let a=tel[k-1].raw,b=t,total=(b.system.kernel+b.system.user)-(a.system.kernel+a.system.user),busy=total-(b.system.idle-a.system.idle),awakeCap=(b.system_awake_before-a.system_awake_after)*a.processors,qpcCap=((b.calls.system_begin-a.calls.system_end)/100n)*a.processors,cap=awakeCap<qpcCap?awakeCap:qpcCap,observer=b.observer_ns-a.observer_ns;
  let errors=[];if(b.monotonic_ns-a.monotonic_ns<4500000000n||b.monotonic_ns-a.monotonic_ns>7500000000n)errors.push("sample_gap");
  if(b.awake_ticks<=a.awake_ticks||b.interrupt_ticks<=a.interrupt_ticks||((b.awake_ticks-a.awake_ticks)-(b.interrupt_ticks-a.interrupt_ticks)>2500000n)||((b.interrupt_ticks-a.interrupt_ticks)-(b.awake_ticks-a.awake_ticks)>2500000n))errors.push("awake_clock_discontinuity");
  if(a.available_bytes<4294967296n||b.available_bytes<4294967296n)errors.push("physical_memory");
  if(a.ac_line!==1n||b.ac_line!==1n||a.saver!==0n||b.saver!==0n)errors.push("power_state");
  if(!["idle","kernel","user"].every(x=>a.system[x]<=b.system[x])||busy<0n)errors.push("system_cpu_counter_order");
  if(cap<=0n||total*10n<cap*9n||total*10n>cap*11n)errors.push("system_counter_capacity");
  if(observer<0n||observer*10n>cap)errors.push("observer_cpu");
  let pct=100*Number(busy)/Number(cap),derived={errors,residual_cpu_upper_pct:pct,capacity_lower_ticks:cap,system_total_observed_ticks:total,awake_capacity_lower_ticks:awakeCap,qpc_capacity_lower_ticks:qpcCap,system_busy_observed_ticks:busy,job_cpu_ticks:0n,raw_residual_ticks:busy,sampler_cpu_ns:observer};
  for(let name of Object.keys(derived))check(typeof derived[name]==="number"?Math.abs(derived[name]-out.interval[name])<1e-12:eq(derived[name],out.interval[name]),"independent window field "+name);
  windowAudit.push(derived);
 }
}
check(allUnicodeNamesASCII,"actual names require no nonASCII Python casefold emulation");
var fullSetup=samples[0].setup_complete;
check(ordered(fullSetup.begin_ns,context.setup_prefix.end_ns,setup.begin_ns,setup.end_ns,fullSetup.end_ns,samples[0].stamp_begin_ns),"complete setup nested wall");
check(ordered(fullSetup.cpu_begin_ns,context.setup_prefix.cpu_end_ns,setup.cpu_begin_ns,setup.cpu_end_ns,fullSetup.cpu_end_ns,tel[0].raw.observer_ns),"complete setup nested CPU");
check(ordered(cleanup.begin_ns,cleanup.evidence.cleanup_begin_ns,cleanup.evidence.cleanup_end_ns,cleanup.end_ns,terminal.observed_ns)&&eq(cleanup.evidence.cleanup_errors,[])&&eq(cleanup.quarantine,[])&&cleanup.primary_failure===null&&cleanup.cleanup_failure===null,"module closure/error contract");
var trailer=terminal.observer_trailer;
check(trailer.begin_cpu_ns===tel[2].raw.observer_ns&&trailer.delta_ns===trailer.end_cpu_ns-trailer.begin_cpu_ns&&trailer.delta_ns>=0n&&trailer.scored===false,"unscored CPU trailer");
var values=windowAudit.map(x=>x.residual_cpu_upper_pct),median=(values[0]+values[1])/2;
check(eq(terminal.partial_phase_verdict,{candidate_pass:false,reasons:["coverage"]})&&values.every(x=>x<=15)&&median<=10&&terminal.partial_window_checks_passed===true,"coverage-only partial verdict");
check(eq(samples.map(x=>x.time_budget_pass),[true,false,true]),"middle50ms rejection retained");


add(pipe2+"/plan.review-candidate.json","591d98b8e2830caffba258603af19a0950f3098ebf6cd1b16bad7d5e27d9b26a");
add(pipe2+"/native-launch.review-candidate.json","036b615bc575fb2f4806da0559bccf4d941057163fbcfc8c7568600b96066ded");
for(var[p,h]of pinPaths)check(sha(await fs.readFile(p))===h,"final pin differs "+p);
check(ur.schema==="native-pipeline-pure-units-receipt-v1"&&ur.qualified===true&&ur.tests===34n&&ur.failures===0n&&ur.test_errors===0n&&ur.skipped===0n&&ur.code===0n&&eq(ur.errors,[])&&ur.observed_ns<ur.deadline_ns,"actual PURE34 prerequisite");
function uint(x,b=64n){return typeof x==="bigint"&&x>=0n&&x<2n**b;}
for(var k=0;k<3;k++){
 let t=tel[k].raw,c=census[k].census;
 for(let [key,bits]of [["monotonic_ns",63n],["awake_ticks",64n],["interrupt_ticks",64n],["observer_ns",63n],["read_ns",63n],["groups",16n],["processors",32n],["available_bytes",64n],["ac_line",8n],["saver",8n],["system_awake_before",64n],["system_awake_after",64n]])
  check(uint(t[key],bits),"telemetry exact unsigned scalar "+key);
 check(Object.values(t.system).every(x=>uint(x))&&Object.values(t.calls).every(x=>uint(x,63n)),"typed CPU/native calls");
 check(tel[k].kind==="sample"&&tel[k].phase==="pre"&&tel[k].endpoint===false&&uint(tel[k].utc_ns)&&tel[k].utc_ns>=946684800000000000n&&tel[k].utc_ns<4102444800000000000n,"telemetry UTC/context");
 if(k){let utcDelta=tel[k].utc_ns-tel[0].utc_ns,monoDelta=t.monotonic_ns-tel[0].raw.monotonic_ns;
  check(tel[k].utc_ns>=tel[k-1].utc_ns&&utcDelta-monoDelta<1000000000n&&monoDelta-utcDelta<1000000000n,"UTC monotonic ordering");}
 for(let gr of c.groups){let s=gr.file_observation.named_before;
  check(uint(s.volume)&&uint(s.size,63n)&&uint(s.allocation,63n)&&uint(s.links,32n)&&uint(s.attributes,32n)&&["creation_ticks","write_ticks","change_ticks"].every(key=>typeof s[key]==="bigint"&&s[key]>=-(2n**63n)&&s[key]<2n**63n),"native file signature exact ranges");}
 let z=stages[k];
 check(z.stamp_ns+z.raw_emit_ns+z.to_census_begin_ns+z.census_ns+z.census_return_gap_ns+z.census_output_flush_ns===z.strict_ns,"complete disjoint strict stage sum");
 check(z.snapshot_wrapper_ns+z.process_open_ns+z.P0_ns+z.exempt_P1_ns+z.process_close_ns+z.groups_total_ns+z.collector_unattributed_ns===z.census_ns,"complete disjoint census stage sum");
}
check(terminal.observer_trailer.end_cpu_ns-fullSetup.cpu_begin_ns===(fullSetup.cpu_end_ns-fullSetup.cpu_begin_ns)+(tel[2].raw.observer_ns-tel[0].raw.observer_ns)+trailer.delta_ns,"overall CPU setup+sampled+trailer disjoint sum");


for(var k=0;k<3;k++){
 let c=census[k].census,n=census[k].native_link.evidence.native;
 check(identity.observer_created_ticks>0n&&identity.observer_created_ticks<=n.upper_ticks&&identity.guard_created_ticks>0n&&identity.guard_created_ticks<=n.upper_ticks,"held creation upper anchors");
 check(samples[k].independent_validation_begin_ns>=samples[k].finished_ns&&samples[k].independent_validation_end_ns>=samples[k].independent_validation_begin_ns,"post-cutoff replay ordering");
 check(stages[k].native_python_allocation_ns+stages[k].native_call_ns+stages[k].native_postdecode_ns===span(census[k].native_link.evidence),"native snapshot exact decomposition");
}
var artifactHashes={};for(var name of ["diagnostic-001.jsonl","census-001.jsonl","telemetry-001.jsonl","native-001.stdout.log","native-001.stderr.log"])artifactHashes[name]=sha(await fs.readFile(pipe2+"/"+name));
check((await fs.readFile(pipe2+"/native-001.stderr.log")).length===0,"native stderr empty");
var p0detail=census.map((x,i)=>{
 let calls=x.census.rows.flatMap(r=>r.P0.calls.map(call=>({row_id:r.row_id,pid:r.pid,name:r.name,operation:call.operation,ns:span(call)})));
 return {index:i,total_P0_ns:sums(x.census.rows.map(r=>span(r.P0))),
  operations:Object.fromEntries(["path","creation","alive"].map(op=>[op,sums(calls.filter(x=>x.operation===op).map(x=>x.ns))])),
  largest_calls:calls.sort((a,b)=>a.ns>b.ns?-1:1).slice(0,5)};
});


var audit={
 schema:"grouped-native-pipeline-offline-audit-method-v1",
 execution_scope:"Persistent Node filesystem reads and integer arithmetic only; no subprocess, DLL, native capture, benchmark or gate rerun",
 integer_encoding:"all original integer tokens parsed BigInt; audit BigInt values emitted as exact decimal strings",
 raw_sha256:artifactHashes,
 unique_bound_paths_checked:pinPaths.size,
 pin_failure_count:failures.filter(x=>x.includes("pin")).length,
 failures, audit_pass:failures.length===0,
 observations:3, relevant_rows:census.map(x=>x.census.rows.length),
 native_rows:rawNativeCounts, groups:census.map(x=>x.census.groups.length),
 all_emitted_native_names_ascii:allUnicodeNamesASCII,
 native_replay_scope:"all emitted UTF16 prefixes/counts/order/PID/parent/clock/upper linked to complete collector entries; unemitted tail bytes remain qualified runtime checks, not independently recovered raw data",
 grouped_scope:"fixed exact-path groups and full128 signatures, P0/read1/P1/read2 checks, all relevant rows/classification/owned closes; no post-read2 process freshness/loaded-image/continuous-interval proof",
 strict_budget_pass:samples.map(x=>x.time_budget_pass),
 strict_ns:samples.map(x=>x.strict_complete_ns),
 legacy_ns:samples.map(x=>x.legacy_sample_to_return_ns),
 independently_derived_windows:windowAudit,
 partial_verdict:terminal.partial_phase_verdict,
 diagnostic_pipeline_qualified:false,phase_qualified:false,campaign_qualified:false,benchmark_slots:0,
 setup:{complete_wall_ns:span(fullSetup),complete_cpu_ns:fullSetup.cpu_end_ns-fullSetup.cpu_begin_ns,
  prefix_wall_ns:span(context.setup_prefix),module_wall_ns:span(setup),module_cpu_ns:setup.cpu_end_ns-setup.cpu_begin_ns,
  nesting:"prefix and module are components within complete setup; do not add them again"},
 cleanup:{wall_ns:span(cleanup),cpu_ns:cleanup.cpu_end_ns-cleanup.cpu_begin_ns,errors:cleanup.evidence.cleanup_errors,quarantine:cleanup.quarantine},
 observer_trailer:trailer,
 sampled_observer_cpu_ns:tel[2].raw.observer_ns-tel[0].raw.observer_ns,
 total_bookended_cpu_ns:trailer.end_cpu_ns-fullSetup.cpu_begin_ns,
 deadline:{observed_ns:terminal.observed_ns,deadline_ns:terminal.deadline_ns,passed:terminal.observed_ns<terminal.deadline_ns},
 stages_nonoverlapping:stages,P0_detail:p0detail,
 stage_definition:"Strict latency splits into stamp/raw flush/to-census/census/return-gap/census flush. Census splits snapshot-wrapper/opens/P0/exemptP1/closes/groups/unattributed. Native C, group-member and shared-read details are nested breakdowns, never additional top-level costs.",
 interpretation:{
  middle_largest_excess:"P0 path-operation envelopes total13.5615ms (vs2.7833/3.8831ms); one retained Python process PID26444 rowr1 is10.0829ms (vs0.7608/0.8834ms). This accounts for9.2-9.3ms of the middle observation's excess, not its entire59.6387ms.",
  middle_other_costs:"Native snapshot wrapper23.2044ms and grouped work19.1353ms are retained independent components. Middle shared reads2.0147ms were not the slowest of the three. No single newly proposed API cause follows.",
  cause_limit:"Recorded path operation includes buffer allocation, ctypes/native query, returned-string validation and possible descheduling. No per-call CPU or native-only bracket establishes the cause of the10.0829ms interval.",
  disposition:"FAIL unchanged50ms middle observation; coverage remains2/12. Exit0 only means diagnostic completed. No qualified comparison, speedup, parity or phase.",
  next_step:"Preserve this failed diagnostic; prioritize agreed production cleanup-reporting repair. Any observer optimization should first isolate the existing path wrapper/allocation/native-call envelopes in a separately reviewed bounded control, preserving every P0/P1 identity check and all numeric gates; no new API, cache, reduced checks, automatic retry or run authorized here."
 }};
var sourcePath=pipe2+"/independent-audit-method-001.mjs";
audit.audit_source_sha256=sha(await fs.readFile(sourcePath));
await fs.writeFile(pipe2+"/independent-audit-method-001.json",safeJSON(audit),{flag:"wx"});
console.log({audit_pass:audit.audit_pass,failures:audit.failures,json_sha256:sha(await fs.readFile(pipe2+"/independent-audit-method-001.json")),source_sha256:audit.audit_source_sha256});
