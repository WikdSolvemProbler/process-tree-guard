"""One prospective three-snapshot grouped census diagnostic; no workloads."""
import argparse
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
GROUPED = HERE.with_name("issue7-grouped-image-census-001")
FIXED = HERE.with_name("issue7-quiet-launch-013")
INPUTS = HERE.with_name("issue7-quiet-campaign-inputs-002")
MANIFEST_SHA = "313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae"


def checked(path, digest):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError("bound bytes differ: " + str(path))
    return raw


def loaded(name, path, raw):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def bindings(plan_sha):
    plan_raw = checked(HERE / "plan.json", plan_sha)
    plan = json.loads(plan_raw)
    if (plan.get("reviewed") is not True or plan["schema"] != "grouped-native-pipeline-diagnostic-v2"
            or plan["snapshots"] != 3 or plan["spacing_ns"] != 5_000_000_000
            or plan["inner_seconds"] != 35 or plan["outer_seconds"] != 45
            or plan["budget_ns"] != 50_000_000):
        raise ValueError("unreviewed diagnostic constants")
    sources = {name: checked(GROUPED / name, pin)
               for name, pin in plan["grouped_source_sha256"].items()}
    checked(HERE / "qualify_pipeline.py", plan["driver_sha256"])
    prerequisite = plan["native_control_receipt"]
    if (not isinstance(prerequisite, dict)
            or prerequisite.get("reviewed_qualified") is not True
            or not isinstance(prerequisite.get("path"), str)
            or not isinstance(prerequisite.get("sha256"), str)):
        raise ValueError("native component qualification is not sealed")
    prerequisite_path = Path(prerequisite["path"])
    prerequisite_raw = checked(prerequisite_path, prerequisite["sha256"])
    prerequisite_receipt = json.loads(prerequisite_raw)
    if (prerequisite_receipt.get("schema") != "grouped-native-components-receipt-v1"
            or prerequisite_receipt.get("qualified") is not True
            or type(prerequisite_receipt.get("exit_code")) is not int
            or prerequisite_receipt["exit_code"] != 0
            or prerequisite_receipt.get("failure") is not None
            or type(prerequisite_receipt.get("completed_cases")) is not int
            or prerequisite_receipt["completed_cases"] != 6):
        raise ValueError("native component receipt is not qualified")
    prerequisite_artifacts = prerequisite_receipt["artifact_sha256"]
    if set(prerequisite_artifacts) != {"native_controls.py", "run.ps1", "plan.json",
                                       "stdout-001.log", "stderr-001.log", "native-controls-001.jsonl"}:
        raise ValueError("native component evidence member set differs")
    for name, pin in prerequisite_artifacts.items():
        checked(prerequisite_path.parent / name, pin)
    manifest = json.loads(checked(FIXED / "manifest.json", MANIFEST_SHA))
    frozen = {name: checked(FIXED / name, digest)
              for name, digest in manifest["file_sha256"].items()}
    input_raw = checked(INPUTS / "inputs.json", manifest["input_manifest_sha256"])
    inputs = json.loads(input_raw)
    slot_name = "tests/campaign/windows_slot_job.py"
    slot = checked(INPUTS / "checkout" / slot_name, inputs["file_sha256"][slot_name])
    pins = {"plan.json": plan_sha, "driver": plan["driver_sha256"],
            "manifest013": MANIFEST_SHA,
            "inputs.json": manifest["input_manifest_sha256"],
            "native_control_receipt": prerequisite["sha256"],
            **{"native_control/" + k: v for k, v in prerequisite_artifacts.items()},
            slot_name: inputs["file_sha256"][slot_name],
            **{"grouped/" + k: hashlib.sha256(v).hexdigest() for k, v in sources.items()},
            **{"013/" + k: hashlib.sha256(v).hexdigest() for k, v in frozen.items()}}
    for group in ("tools", "fingerprints"):
        for name, value in manifest[group].items():
            checked(Path(value["path"]), value["sha256"])
            pins[group + "/" + name] = value["sha256"]
    if not Path(sys.executable).samefile(manifest["tools"]["python"]["path"]):
        raise ValueError("unsealed interpreter")
    if (sys.getwindowsversion().build != manifest["windows_build"]
            or sys.version != manifest["python_version"]):
        raise ValueError("host/tool version differs from frozen reference")
    local = {name: checked(HERE / name, pin) for name, pin in plan["local_source_sha256"].items()}
    native_replay = loaded("native_replay_preflight", HERE / "replay_native.py", local["replay_native.py"])
    unit = plan["unit_prerequisite"]
    if unit.get("reviewed_qualified") is not True or not isinstance(unit.get("sha256"), str):
        raise ValueError("new replay/bridge pure unit prerequisite is not sealed")
    unit_receipt = native_replay.strict_json(checked(HERE / "unit-receipt-001.json", unit["sha256"]))
    if (unit_receipt.get("schema") != "native-pipeline-pure-units-receipt-v1"
            or unit_receipt.get("qualified") is not True or type(unit_receipt.get("code")) is not int
            or unit_receipt["code"] != 0 or type(unit_receipt.get("tests")) is not int
            or unit_receipt["tests"] != 31 or unit_receipt.get("errors") != []
            or any(type(unit_receipt.get(k)) is not int or unit_receipt[k] != 0
                   for k in ("failures","test_errors","skipped","private_dll_loads","native_snapshot_calls","benchmark_slots"))
            or not native_replay.ordered(unit_receipt.get("observed_ns"), unit_receipt.get("deadline_ns"))
            or unit_receipt["observed_ns"] >= unit_receipt["deadline_ns"]):
        raise ValueError("new pure unit receipt not qualified")
    unit_plan = native_replay.strict_json(checked(HERE / "unit-plan.json", unit_receipt["plan_sha256"]))
    for name, pin in unit_plan["source_sha256"].items(): checked(HERE / name, pin)
    if set(unit_receipt["artifact_sha256"]) != {"unit-tests-001.log"}:
        raise ValueError("new pure unit artifacts differ")
    for name, pin in unit_receipt["artifact_sha256"].items(): checked(HERE / name, pin)
    pins["unit_receipt"] = unit["sha256"]
    pins["unit_plan"] = unit_receipt["plan_sha256"]
    pins.update({"unit_artifact/"+name: pin for name,pin in unit_receipt["artifact_sha256"].items()})
    component = plan["native_component"]
    component_raw = checked(Path(component["raw_path"]), component["raw_sha256"])
    native_replay.component_proof(component_raw, component["seal_sha256"])
    seal_raw = checked(Path(component["seal_path"]), component["seal_sha256"])
    seal = native_replay.strict_json(seal_raw)
    if seal.get("reviewed") is not True:
        raise ValueError("native component seal not reviewed")
    for path, pin in component["evidence_sha256"].items():
        checked(Path(path), pin)
    for name, pin in seal["source_sha256"].items():
        checked(Path(component["seal_path"]).parent / name, pin)
    for path, pin in seal["tool_sha256"].items():
        checked(Path(path), pin)
    fast_path = Path(plan["adapter_path"])
    fast_raw = checked(fast_path, plan["adapter_sha256"])
    checked(Path(plan["dll_path"]), plan["dll_sha256"])
    if (seal["dll_sha256"] != plan["dll_sha256"]
            or seal["dependency_sha256"] != plan["dependency_sha256"]
            or seal["source_sha256"]["../issue7-native-bulk-decoder-001/bulk_snapshot_bytes.py"] != plan["adapter_sha256"]):
        raise ValueError("native setup differs from qualified component")
    pins.update({"local/"+name: hashlib.sha256(raw).hexdigest() for name, raw in local.items()})
    pins.update({"native_component/"+name: pin for name, pin in component["evidence_sha256"].items()})
    pins.update({"component_raw": component["raw_sha256"], "component_seal": component["seal_sha256"],
                 "adapter": plan["adapter_sha256"], "dll": plan["dll_sha256"]})
    return plan, manifest, sources, frozen, slot, pins, local, fast_raw


def main(plan_sha):
    observer_setup_begin_ns = time.perf_counter_ns()
    observer_setup_cpu_begin_ns = time.process_time_ns()
    plan, manifest, sources, frozen, slot, before, local, fast_raw = bindings(plan_sha)
    loaded("image_policy", GROUPED / "image_policy.py", sources["image_policy.py"])
    loaded("grouped_image", GROUPED / "grouped_image.py", sources["grouped_image.py"])
    collector = loaded("grouped_census", GROUPED / "grouped_census.py", sources["grouped_census.py"])
    native = loaded("native_processes", GROUPED / "native_processes.py", sources["native_processes.py"])
    replay = loaded("replay_grouped", GROUPED / "replay_grouped.py", sources["replay_grouped.py"])
    math = loaded("quiet_gate", FIXED / "quiet_gate.py", frozen["quiet_gate.py"])
    loaded("windows_slot_job", INPUTS / "checkout/tests/campaign/windows_slot_job.py", slot)
    sampler = loaded("quiet_sampler", FIXED / "quiet_sampler.py", frozen["quiet_sampler.py"])
    raw_replay = loaded("telemetry_replay", FIXED / "replay.py", frozen["replay.py"])
    clock_info = time.get_clock_info("perf_counter")
    if (clock_info.implementation != "QueryPerformanceCounter()"
            or clock_info.monotonic is not True or clock_info.adjustable is not False):
        raise ValueError("pinned Windows CPython QPC implementation differs")
    deadline = time.perf_counter_ns() + plan["inner_seconds"] * 1_000_000_000
    bridge = loaded("native_bridge", HERE / "native_bridge.py", local["native_bridge.py"])
    native_replay = loaded("native_replay", HERE / "replay_native.py", local["replay_native.py"])
    fast = loaded("bulk_snapshot", Path(plan["adapter_path"]), fast_raw)
    module = None
    backend = None
    quarantine_owners = []
    primary_failure = None
    cleanup_failure = None
    snapshot_calls = []
    emitted_census = []
    samples, cases, windows = [], [], []
    code = 0
    reporting_failures = []

    with ((HERE / "diagnostic-001.jsonl").open("x", encoding="utf-8") as output,
          (HERE / "telemetry-001.jsonl").open("x", encoding="utf-8") as raw_output,
          (HERE / "census-001.jsonl").open("x", encoding="utf-8") as census_output):
        def emit(stream, kind, **values):
            nonlocal code
            try:
                print(json.dumps({"kind": kind, **values}, allow_nan=False), file=stream, flush=True)
            except BaseException as error:
                code = 1
                reporting_failures.append({"kind":kind, "failure":bridge.error_record(error)})
        observer_setup_cpu_end_ns = time.process_time_ns()
        observer_setup_end_ns = time.perf_counter_ns()
        emit(output, "context", source_sha256=before,
             observer_setup={"begin_ns":observer_setup_begin_ns,"end_ns":observer_setup_end_ns,
                "cpu_begin_ns":observer_setup_cpu_begin_ns,"cpu_end_ns":observer_setup_cpu_end_ns,
                "scope":"bindings/imports before first sample; module load additionally recorded; not sampled observations"}, snapshots=3, spacing_ns=5_000_000_000,
             benchmark_slots=0, scope="prospective grouped observation diagnostic; not a phase/campaign",
             cutoff="strict stamp-entry through telemetry flush, census and census flush; original sample-to-census-return also retained",
             post_cutoff="independent JSON replay and diagnostic logging excluded from latency, retained in subsequent observer CPU windows",
             census_budget_ns=50_000_000,
             native_replay_scope="complete emitted prefixes and full entries, not unemitted tail/loaded-image/atomic-memory proof",
             clock_implementation=clock_info.implementation, clock_monotonic=clock_info.monotonic,
             clock_adjustable=clock_info.adjustable, clock_resolution_seconds=clock_info.resolution,
             clock_scope="absolute rational brackets rely on pinned Windows CPython3.12.10 pytime.c QPC-without-offset implementation")
        try:
            with native.open_exact(os.getpid()) as self_handle:
                observer_created = native.WindowsBackend.creation(self_handle)
            with native.enclosing_guard(manifest["tools"]["outer_guard"]["path"]) as guard:
                emit(output, "identity", observer_pid=os.getpid(), observer_created_ticks=observer_created,
                     guard_pid=guard[0], guard_created_ticks=guard[2], job_present=False)
                sampler.warm_job_query()
                setup_begin = time.perf_counter_ns()
                setup_cpu_begin = time.process_time_ns()
                module = fast.NativeBulk(Path(plan["dll_path"]), plan["dll_sha256"], plan["dependency_sha256"])
                setup_cpu_end = time.process_time_ns()
                setup_end = time.perf_counter_ns()
                emit(output, "module_setup", begin_ns=setup_begin, end_ns=setup_end,
                     cpu_begin_ns=setup_cpu_begin, cpu_end_ns=setup_cpu_end, evidence=module.evidence,
                     scope="once-only code setup, no native observation warmup")
                origin = time.perf_counter_ns()
                for index in range(3):
                    remaining = origin + index * 5_000_000_000 - time.perf_counter_ns()
                    if remaining > 0:
                        time.sleep(remaining / 1e9)
                    if time.perf_counter_ns() >= deadline:
                        raise TimeoutError("35-second diagnostic deadline before stamp")
                    snapshot_calls.clear()
                    stamp_begin = time.perf_counter_ns()
                    sample = sampler.stamp()
                    stamp_end = time.perf_counter_ns()
                    emit(raw_output, "sample", index=index, phase="pre", endpoint=False,
                         raw=asdict(sample), utc_ns=time.time_ns())
                    raw_emit_end = time.perf_counter_ns()
                    backend = bridge.NativeCensusBackend(native.WindowsBackend(), module)
                    census = collector.collect(backend, guard, manifest["image_policy"])
                    census_return = time.perf_counter_ns()
                    # Ordinary full evidence output is inside the stricter cutoff.
                    emit(census_output, "census", index=index, census=census, native_link=backend.record,
                         source_monotonic_ns=sample.monotonic_ns, census_return_ns=census_return)
                    finished = time.perf_counter_ns()
                    validation_begin = time.perf_counter_ns()
                    # Decode the actual emitted bytes: no in-memory-only replay pass.
                    written = [native_replay.strict_json(line) for line in (HERE / "census-001.jsonl").read_text(encoding="utf-8").splitlines()]
                    if len(written) != index + 1 or written[-1]["index"] != index:
                        raise ValueError("actual census stream coverage differs")
                    verdict = replay.replay(written[-1]["census"], manifest["image_policy"],
                                            expected_guard=(guard[0], guard[2]),
                                            expected_observer_pid=os.getpid(), expected_job_present=False)
                    for prior_index, prior in enumerate(emitted_census):
                        raw_replay.same(written[prior_index], prior, "prior emitted census changed")
                    raw_replay.same(written[-1]["census"], census, "current emitted census differs")
                    raw_replay.same(written[-1]["native_link"], backend.record, "current emitted native facts differ")
                    native_verdict = native_replay.replay(written[-1]["census"], written[-1]["native_link"])
                    emitted_census.append(written[-1])
                    raw_rows = [native_replay.strict_json(line) for line in (HERE / "telemetry-001.jsonl").read_text(encoding="utf-8").splitlines()]
                    if len(raw_rows) != index + 1:
                        raise ValueError("actual telemetry stream coverage differs")
                    decoded = []
                    for row_index, row in enumerate(raw_rows):
                        if (not isinstance(row, dict)
                                or set(row) != {"kind", "index", "phase", "endpoint", "raw", "utc_ns"}
                                or row["kind"] != "sample" or type(row["index"]) is not int
                                or row["index"] != row_index or row["phase"] != "pre"
                                or row["endpoint"] is not False or type(row["utc_ns"]) is not int
                                or not 946_684_800_000_000_000 <= row["utc_ns"] < 4_102_444_800_000_000_000):
                            raise ValueError("actual telemetry row schema/context differs")
                        decoded.append(raw_replay.sample_from_raw(row["raw"], False))
                        if row_index:
                            if (row["utc_ns"] < raw_rows[row_index - 1]["utc_ns"]
                                    or abs((row["utc_ns"] - raw_rows[0]["utc_ns"])
                                           - (decoded[-1].monotonic_ns - decoded[0].monotonic_ns))
                                    > raw_replay.UTC_TOLERANCE):
                                raise ValueError("actual telemetry UTC/monotonic discontinuity")
                    raw_replay.same(raw_rows[-1]["raw"], asdict(sample), "emitted telemetry differs from actual native sample")
                    for prior_index, prior in enumerate(samples):
                        raw_replay.same(asdict(decoded[prior_index]), asdict(prior), "prior emitted telemetry was altered")
                    parsed_sample = decoded[-1]
                    native_errors = math.sample_errors(parsed_sample, during=False)
                    samples.append(parsed_sample)
                    interval = None
                    if index:
                        interval = math.window(samples[-2], parsed_sample, during=False)
                        windows.append(interval)
                    strict_span = finished - stamp_begin
                    legacy_span = census_return - sample.monotonic_ns
                    budget_ok = 0 <= strict_span <= 50_000_000 and 0 <= legacy_span <= 50_000_000
                    case_ok = (budget_ok and census["admissible"] and verdict["record_valid"]
                               and verdict["admissible"] and native_verdict["record_valid"]
                               and native_verdict["admissible"] and not native_errors)
                    cases.append(case_ok)
                    emit(output, "sample", index=index, stamp_begin_ns=stamp_begin, stamp_end_ns=stamp_end,
                         raw_emit_end_ns=raw_emit_end, source_monotonic_ns=sample.monotonic_ns,
                         census_return_ns=census_return, finished_ns=finished,
                         strict_complete_ns=strict_span, legacy_sample_to_return_ns=legacy_span,
                         native_observation=backend.record, native_population_replay=native_verdict,
                         native_sample_errors=native_errors,
                         independent_replay=verdict, independent_validation_begin_ns=validation_begin,
                         independent_validation_end_ns=time.perf_counter_ns(), interval=interval,
                         row_count=len(census["rows"]), group_count=len(census["groups"]),
                         time_budget_pass=budget_ok, census_admissible=census["admissible"],
                         snapshot_qualified=case_ok)
                    if time.perf_counter_ns() >= deadline:
                        raise TimeoutError("35-second diagnostic deadline after sample/replay")
        except BaseException as error:
            code = 1
            primary_failure = bridge.error_record(error)
            owner = getattr(error, "quarantine_owner", None)
            if owner is not None: quarantine_owners.append(owner)
            emit(output, "error", type=type(error).__name__, error=str(error),
                 winerror=getattr(error, "winerror", None), evidence=getattr(error, "evidence", None),
                 partial_native_link=backend.record if backend is not None else None,
                 quarantine=[{"module_handle":getattr(owner,"module",None),
                    "closed":getattr(owner,"closed",None),"quarantined":getattr(owner,"quarantined",None)}
                    for owner in quarantine_owners])
        finally:
            if module is not None:
                cleanup_begin = time.perf_counter_ns()
                cleanup_cpu_begin = time.process_time_ns()
                try:
                    module.close()
                except BaseException as error:
                    code = 1
                    cleanup_failure = bridge.error_record(error)
                    owner = getattr(error, "quarantine_owner", None)
                    if owner is not None: quarantine_owners.append(owner)
                cleanup_cpu_end = time.process_time_ns()
                cleanup_end = time.perf_counter_ns()
                emit(output, "module_cleanup", begin_ns=cleanup_begin, end_ns=cleanup_end,
                     cpu_begin_ns=cleanup_cpu_begin, cpu_end_ns=cleanup_cpu_end,
                     evidence=module.evidence, primary_failure=primary_failure,
                     cleanup_failure=cleanup_failure, quarantine=[{"module_handle":getattr(owner,"module",None),
                        "closed":getattr(owner,"closed",None),"quarantined":getattr(owner,"quarantined",None)}
                        for owner in quarantine_owners])
            try:
                after = bindings(plan_sha)[5]
                unchanged = before == after
            except BaseException as error:
                code, after, unchanged = 1, None, False
                emit(output, "source_error", type=type(error).__name__, error=str(error))
            # Compute derived diagnostic verdict before the final CPU/clock gate.
            partial_verdict = math.verdict(windows, during=False)
            partial_failures = [reason for reason in partial_verdict["reasons"] if reason != "coverage"]
            partial_ok = len(windows) == 2 and not partial_failures
            trailer_cpu_end = time.process_time_ns()
            trailer_begin = samples[-1].observer_ns if samples else None
            if trailer_begin is not None and trailer_cpu_end < trailer_begin:
                code = 1
                emit(output, "cpu_error", error="observer trailer counter regressed")
            terminal_observed_ns = time.perf_counter_ns()
            if terminal_observed_ns >= deadline:
                code = 1
                emit(output, "deadline", stage="terminal")
            emit(output, "terminal", code=code, completed=len(cases), source_sha256=after,
                 observed_ns=terminal_observed_ns, deadline_ns=deadline,
                 primary_failure=primary_failure, cleanup_failure=cleanup_failure, reporting_failures=reporting_failures,
                 observer_trailer={"begin_cpu_ns":trailer_begin,"end_cpu_ns":trailer_cpu_end,
                    "delta_ns":trailer_cpu_end-trailer_begin if trailer_begin is not None else None,
                    "scored":False,"scope":"after final sample through replay, cleanup and postbinding; excludes final terminal serialization/stream close; unscored, no invented fourth window"},
                 sources_unchanged=unchanged, partial_phase_verdict=partial_verdict,
                 partial_window_checks_passed=partial_ok,
                 diagnostic_pipeline_qualified=(code == 0 and not reporting_failures and primary_failure is None
                                                and cleanup_failure is None and unchanged and len(cases) == 3
                                                and all(cases) and partial_ok),
                 phase_qualified=False, campaign_qualified=False, benchmark_slots=0,
                 scope="diagnostic exit0 is not admission; coverage remains incomplete")
    return code


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--approved-plan-sha", required=True)
    args = parser.parse_args()
    raise SystemExit(main(args.approved_plan_sha))
