"""Pure saved-data and injected bridge tests. No ctypes, DLL, or native calls."""
import copy
import json
from pathlib import Path
import unittest
import replay_native as replay
from native_bridge import NativeCensusBackend

HERE=Path(__file__).resolve().parent
RAW=HERE.with_name("issue7-native-bulk-decoder-capture-001")/"native-001.jsonl"
SEAL="986950d2d85c1a93fe7eae922fdfe0d752cb5f0a7b67067cff95bb6c9dfcba25"

class Module:
    def __init__(self,result=None,error=None):
        self.result=result;self.error=error;self.calls=0
    def snapshot(self):
        self.calls+=1
        if self.error:raise self.error
        return self.result

class PureControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw=RAW.read_bytes()
        cls.events=[replay.strict_json(line) for line in cls.raw.splitlines()]
        cls.observation=next(row for row in cls.events if row["kind"]=="snapshot")
    def fixture(self):
        # Unit-only synthetic collector envelope around ACTUAL saved native data.
        # This is not a genuine census or a new native observation.
        observation=copy.deepcopy(self.observation)
        evidence=observation["evidence"]
        census={"snapshot":{"begin_ns":evidence["begin_ns"]-2,
            "end_ns":evidence["end_ns"]+2,
            "upper_ticks":observation["upper_ticks"],"entries":observation["rows"]}}
        link={"schema":"native-census-link-v1","attempts":1,"module_calls":1,
            "begin_ns":evidence["begin_ns"]-1,"end_ns":evidence["end_ns"]+1,
            "returned":True,"error":None,"clock_errors":[],"evidence":evidence}
        return census,link
    def refused(self,mutator):
        census,link=self.fixture();mutator(census,link)
        result=replay.replay(census,link)
        self.assertFalse(result["record_valid"]);self.assertFalse(result["admissible"])
    def test_saved_valid_link(self):
        census,link=self.fixture()
        result=replay.replay(census,link)
        self.assertTrue(result["record_valid"]);self.assertFalse(result["independent_tail_bytes"])
    def test_population_drop(self):
        self.refused(lambda c,l:c["snapshot"]["entries"].pop())
    def test_parent_changed(self):
        self.refused(lambda c,l:c["snapshot"]["entries"][0].update(parent_pid=2**32-1))
    def test_pid_boolean(self):
        self.refused(lambda c,l:c["snapshot"]["entries"][0].update(pid=False))
    def test_pid_float(self):
        self.refused(lambda c,l:c["snapshot"]["entries"][0].update(pid=0.0))
    def test_raw_prefix_changed(self):
        self.refused(lambda c,l:l["evidence"]["raw_utf16_rows"][0].update(name_utf16le_hex="6100",name_units=1))
    def test_raw_tail_not_in_contract(self):
        self.refused(lambda c,l:l["evidence"]["raw_utf16_rows"][0].update(invented_tail="00"))
    def test_duplicate_pid(self):
        self.refused(lambda c,l:l["evidence"]["raw_utf16_rows"][1].update(pid=l["evidence"]["raw_utf16_rows"][0]["pid"]))
    def test_upper_bool(self):
        self.refused(lambda c,l:c["snapshot"].update(upper_ticks=True))
    def test_upper_shift(self):
        self.refused(lambda c,l:c["snapshot"].update(upper_ticks=c["snapshot"]["upper_ticks"]+1))
    def test_native_api_failure(self):
        self.refused(lambda c,l:l["evidence"]["native"].update(status=1))
    def test_native_capacity(self):
        self.refused(lambda c,l:l["evidence"]["native"].update(count=4097))
    def test_native_qpc_reversed(self):
        self.refused(lambda c,l:l["evidence"]["native"].update(end_qpc=1))
    def test_cross_clock_outside(self):
        self.refused(lambda c,l:l["evidence"].update(native_begin_ns=l["evidence"]["native_end_ns"]))
    def test_collector_bracket(self):
        self.refused(lambda c,l:c["snapshot"].update(end_ns=0))
    def test_bridge_count_bool(self):
        self.refused(lambda c,l:l.update(attempts=True))
    def test_bridge_partial_error(self):
        self.refused(lambda c,l:l.update(error={"message":"refused"}))
    def test_bridge_clock_error(self):
        self.refused(lambda c,l:l.update(clock_errors=[{"message":"regressed"}]))
    def test_component_valid(self):
        self.assertTrue(replay.component_proof(self.raw,SEAL)["qualified"])
    def component_refused(self,change):
        rows=copy.deepcopy(self.events);change(rows)
        with self.assertRaises((ValueError,KeyError,TypeError)):
            replay.component_proof("\n".join(json.dumps(row) for row in rows),SEAL)
    def test_component_handle_failure(self):
        self.component_refused(lambda rows:rows[-1].update(final_handles=0))
    def test_component_deadline(self):
        self.component_refused(lambda rows:rows[-1].update(observed_ns=rows[-1]["deadline_ns"]))
    def test_component_count_boolean(self):
        self.component_refused(lambda rows:rows[-1].update(native_capture_attempts=True))
    def test_component_wrong_seal(self):
        with self.assertRaises(ValueError):replay.component_proof(self.raw,"0"*64)
    def test_duplicate_json(self):
        with self.assertRaises(ValueError):replay.strict_json('{"x":1,"x":2}')
    def test_float_json(self):
        with self.assertRaises(ValueError):replay.strict_json('{"x":1.0}')
    def test_nan_json(self):
        with self.assertRaises(ValueError):replay.strict_json('{"x":NaN}')
    def test_bridge_one_call(self):
        module=Module(([],7,{"saved":"actual partial placeholder"}))
        backend=NativeCensusBackend(object(),module,clock=iter([10,20]).__next__)
        self.assertEqual(backend.snapshot(),([],7))
        with self.assertRaises(ValueError):backend.snapshot()
        self.assertEqual(module.calls,1)
        self.assertEqual(backend.record["evidence"],{"saved":"actual partial placeholder"})
        self.assertEqual(backend.record["attempts"],2)
    def test_bridge_primary_evidence_survives_postclock_failure(self):
        error=OSError("primary");error.evidence={"partial":"retained"}
        module=Module(error=error)
        times=iter([10])
        backend=NativeCensusBackend(object(),module,clock=lambda:next(times))
        with self.assertRaises(OSError) as caught:backend.snapshot()
        self.assertIs(caught.exception,error)
        self.assertEqual(backend.record["evidence"],error.evidence)
        self.assertEqual(backend.record["error"]["message"],"primary")
        self.assertEqual(len(backend.record["clock_errors"]),1)
    def test_bridge_success_postclock_failure_preserves_observation(self):
        module=Module(([],7,{"saved":True}))
        times=iter([10])
        backend=NativeCensusBackend(object(),module,clock=lambda:next(times))
        self.assertEqual(backend.snapshot(),([],7))
        self.assertTrue(backend.record["returned"])
        self.assertEqual(backend.record["evidence"],{"saved":True})
        self.assertIsNone(backend.record["end_ns"])
        self.assertEqual(len(backend.record["clock_errors"]),1)
    def test_bridge_initial_clock_refuses_without_call(self):
        module=Module(([],7,{}))
        backend=NativeCensusBackend(object(),module,clock=lambda:True)
        with self.assertRaises(ValueError):backend.snapshot()
        self.assertEqual(module.calls,0)
    def test_delegated_process_check(self):
        class Process:
            def path(self,handle):return ("original",handle)
        backend=NativeCensusBackend(Process(),Module())
        self.assertEqual(backend.path(7),("original",7))

if __name__=="__main__":unittest.main(verbosity=2)
