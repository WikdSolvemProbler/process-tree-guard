"""Single pure unit phase. Never imports ctypes or a private DLL."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import sys
import time
import types
import unittest

HERE=Path(__file__).resolve().parent
def checked(path,pin):
    raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=pin:raise ValueError("unit binding differs: "+str(path))
    return raw
def load(name,raw):
    module=types.ModuleType(name);module.__file__=str(HERE/(name+".py"));sys.modules[name]=module
    exec(compile(raw,module.__file__,"exec"),module.__dict__);return module
def main(pin):
    raw=checked(HERE/"unit-plan.json",pin);plan=json.loads(raw)
    if plan["schema"]!="native-pipeline-pure-units-v1" or plan["inner_seconds"]!=35 or plan["outer_seconds"]!=45:
        raise ValueError("unit constants differ")
    sources={name:checked(HERE/name,value) for name,value in plan["source_sha256"].items()}
    fixture=Path(plan["fixture_path"]);checked(fixture,plan["fixture_sha256"])
    if not Path(sys.executable).samefile(plan["python_path"]):raise ValueError("interpreter differs")
    checked(Path(plan["python_path"]),plan["python_sha256"])
    checked(Path(plan["guard_path"]),plan["guard_sha256"])
    deadline=time.perf_counter_ns()+35_000_000_000
    load("native_bridge",sources["native_bridge.py"]);load("replay_native",sources["replay_native.py"])
    tests=load("test_native_link",sources["test_native_link.py"])
    code=1;errors=[];result=None
    with (HERE/"unit-tests-001.log").open("x",encoding="utf-8") as output:
        try:
            suite=unittest.defaultTestLoader.loadTestsFromModule(tests)
            result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)
            output.flush()
            for name,value in plan["source_sha256"].items():checked(HERE/name,value)
            checked(fixture,plan["fixture_sha256"]);checked(HERE/"unit-plan.json",pin)
            checked(Path(plan["python_path"]),plan["python_sha256"]);checked(Path(plan["guard_path"]),plan["guard_sha256"])
            if (result.testsRun!=plan["expected_tests"] or result.failures or result.errors or result.skipped):
                raise ValueError("exact pure controls did not all pass")
            observed=time.perf_counter_ns()
            if observed>=deadline:raise TimeoutError("unit35s checked deadline")
            code=0
        except BaseException as error:
            errors.append({"type":type(error).__name__,"message":str(error)})
        output.flush()
    # Authoritative gate after log closure and all artifact reads.
    artifact=hashlib.sha256((HERE/"unit-tests-001.log").read_bytes()).hexdigest()
    observed=time.perf_counter_ns()
    if observed>=deadline:
        code=1;errors.append({"type":"TimeoutError","message":"final35s deadline"})
    receipt={"schema":"native-pipeline-pure-units-receipt-v1","code":code,"qualified":code==0,
        "tests":result.testsRun if result else None,"failures":len(result.failures) if result else None,
        "errors":errors,"test_errors":len(result.errors) if result else None,
        "skipped":len(result.skipped) if result else None,"observed_ns":observed,"deadline_ns":deadline,
        "artifact_sha256":{"unit-tests-001.log":artifact},"plan_sha256":pin,
        "private_dll_loads":0,"native_snapshot_calls":0,"benchmark_slots":0}
    with (HERE/"unit-receipt-001.json").open("x",encoding="utf-8") as output:
        json.dump(receipt,output,indent=2,allow_nan=False);output.write("\n")
    return code
if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--approved-plan-sha",required=True)
    raise SystemExit(main(parser.parse_args().approved_plan_sha))
