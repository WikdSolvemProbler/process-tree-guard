# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Peter Shiller
"""Calibrate live nested Job accounting with a fixed, bounded Python fixture."""

import _winapi
import argparse
import ctypes
import json
import os
import subprocess
import sys
import time
from ctypes import wintypes
from dataclasses import asdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from quiet_sampler import SlotJob, _bind, _checked, emit, job_cpu, stamp, window

P = ctypes.POINTER
GetProcessTimes = _bind("GetProcessTimes", [wintypes.HANDLE] + [P(wintypes.FILETIME)] * 4,
                        wintypes.BOOL)
IsProcessInJob = _bind("IsProcessInJob", [wintypes.HANDLE, wintypes.HANDLE, P(wintypes.BOOL)],
                       wintypes.BOOL)
ACCOUNTING_TOLERANCE_TICKS = 500_000


def fixture(mode):
    return [sys.executable, "-I", "-B", str(Path(__file__).resolve()), mode]


def pulse():
    until = time.perf_counter() + 12
    while time.perf_counter() < until:
        cpu_until = time.process_time_ns() + 10_000_000
        while time.process_time_ns() < cpu_until and time.perf_counter() < until:
            pass
        time.sleep(0.03)


def nested():
    inner = SlotJob()
    try:
        child = inner.launch(fixture("--pulse"), 0, stdin=subprocess.DEVNULL,
                             stdout=sys.stdout, stderr=sys.stderr)
        try:
            emit(sys.stdout, "nested_ready", owner_pid=os.getpid(), pulse_pid=child.pid)
            code = child.wait(14)
        finally:
            child.close()
        drain = inner.drain()
        accounting = job_cpu(inner)
        emit(sys.stdout, "nested_terminal", code=code, accounting=asdict(accounting), drain=drain)
        if code or drain["terminated"] or accounting.total_processes != 1:
            raise RuntimeError("inner Job failed")
    finally:
        inner.close()


def exact_process_times(handle, job):
    member = wintypes.BOOL()
    _checked(IsProcessInJob(handle, job._handle, ctypes.byref(member)), "IsProcessInJob")
    if not member.value:
        raise RuntimeError("fixture handle does not belong to outer Job")
    created, exited, kernel, user = (wintypes.FILETIME() for _ in range(4))
    _checked(GetProcessTimes(handle, ctypes.byref(created), ctypes.byref(exited),
                             ctypes.byref(kernel), ctypes.byref(user)), "GetProcessTimes")
    return [value.dwHighDateTime << 32 | value.dwLowDateTime
            for value in (created, exited, kernel, user)]


def wait_ready(path, owner_pid, deadline):
    while time.perf_counter() < deadline:
        raw = path.read_bytes()
        if b"\n" in raw:
            ready = json.loads(raw.splitlines()[0])
            if ready["kind"] != "nested_ready" or ready["owner_pid"] != owner_pid:
                raise RuntimeError("wrong nested fixture identity")
            return ready["pulse_pid"]
        time.sleep(0.025)
    raise TimeoutError("nested calibration fixture did not start")


def calibrate(output):
    job = SlotJob()
    child = None
    pulse_handle = None
    try:
        child_path = output.with_suffix(".fixture.stdout")
        with output.open("x", encoding="utf-8") as stream, \
                child_path.open("xb") as child_stdout, \
                output.with_suffix(".fixture.stderr").open("xb") as child_stderr:
            previous = stamp(job)
            if previous.job.total_processes or previous.job.total:
                raise RuntimeError("calibration Job is not new")
            origin = previous.monotonic_ns / 1e9
            emit(stream, "origin", raw=asdict(previous), benchmark_slots=0)
            child = job.launch(fixture("--nested"), 0, stdin=subprocess.DEVNULL,
                               stdout=child_stdout, stderr=child_stderr)
            pulse_pid = wait_ready(child_path, child.pid, origin + 2)
            pulse_handle = _winapi.OpenProcess(0x1000, False, pulse_pid)
            former_total = 0
            valid = []
            for index in range(1, 4):
                time.sleep(max(0, origin + 5 * index - time.perf_counter()))
                mark = time.perf_counter_ns()
                current = stamp(job)
                identities = [exact_process_times(handle, job)
                              for handle in (child._handle, pulse_handle)]
                read_span = time.perf_counter_ns() - mark
                process_total = sum(record[2] + record[3] for record in identities)
                control = window(previous, current, during=True)
                error = control["job_cpu_ticks"] - (process_total - former_total)
                active_ok = all(record[1] == 0 for record in identities) if index < 3 else \
                    all(record[1] != 0 for record in identities)
                passed = (not control["errors"] and read_span <= 10_000_000 and active_ok
                          and abs(error) <= ACCOUNTING_TOLERANCE_TICKS)
                valid.append(passed)
                emit(stream, "interval", raw=asdict(current), process_times=identities,
                     interval=control, read_span_ns=read_span, job_minus_exact_ticks=error,
                     expected_liveness=active_ok, pass_control=passed)
                former_total = process_total
                previous = current
            code = child.wait(0)
            child.close()
            child = None
            _winapi.CloseHandle(pulse_handle)
            pulse_handle = None
            drain = job.drain()
            final = job_cpu(job)
            success = (all(valid) and code == 0 and not drain["terminated"]
                       and final.total_processes == 2 and final.active_processes == 0)
            emit(stream, "terminal", valid=success, code=code, drain=drain,
                 final=asdict(final), benchmark_slots=0)
            return 0 if success else 1
    finally:
        if child is not None:
            child.close()
        if pulse_handle is not None:
            _winapi.CloseHandle(pulse_handle)
        job.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    options = parser.add_mutually_exclusive_group(required=True)
    options.add_argument("--calibrate", type=Path)
    options.add_argument("--nested", action="store_true")
    options.add_argument("--pulse", action="store_true")
    args = parser.parse_args()
    if args.calibrate:
        raise SystemExit(calibrate(args.calibrate))
    if args.nested:
        nested()
    else:
        pulse()