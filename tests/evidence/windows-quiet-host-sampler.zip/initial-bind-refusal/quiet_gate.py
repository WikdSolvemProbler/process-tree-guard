# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Peter Shiller
"""Draft quiet-host scoring for issue #7. No benchmark launch entry point."""

from dataclasses import dataclass
from statistics import median

INTERVALS = 12
SECONDS = 5
MIB = 1024 * 1024
MIN_AVAILABLE = 4096 * MIB
MEDIAN_CPU = 10.0
OUTSIDE_MAX_CPU = 15.0
DURING_MAX_CPU = 25.0
DURING_PAIRED_CPU = 15.0
MAX_READ_NS = 10_000_000
MAX_WAKE_DIFFERENCE = 2_500_000
NS_PER_SECOND = 1_000_000_000
MAX_OBSERVER_CPU = 0.1
NEGATIVE_TOLERANCE_PP = 0.5


@dataclass(frozen=True)
class Cpu:
    idle: int
    kernel: int
    user: int

    @property
    def total(self):
        return self.kernel + self.user

    @property
    def busy(self):
        return self.total - self.idle


@dataclass(frozen=True)
class Job:
    kernel: int
    user: int
    total_processes: int
    active_processes: int

    @property
    def total(self):
        return self.kernel + self.user


@dataclass(frozen=True)
class Sample:
    monotonic_ns: int
    awake_ticks: int
    interrupt_ticks: int
    observer_ns: int
    read_ns: int
    groups: int
    processors: int
    available_bytes: int
    ac_line: int
    saver: int
    before: Cpu
    after: Cpu
    job: Job | None


def cpu_ordered(first, second):
    return (first.idle <= second.idle and first.kernel <= second.kernel
            and first.user <= second.user and first.busy <= second.busy)


def window(first, last, *, during=False):
    errors = []
    elapsed = last.monotonic_ns - first.monotonic_ns
    awake = last.awake_ticks - first.awake_ticks
    interrupt = last.interrupt_ticks - first.interrupt_ticks
    if not 4.5 * NS_PER_SECOND <= elapsed <= 7.5 * NS_PER_SECOND:
        errors.append("sample_gap")
    if awake <= 0 or interrupt <= 0 or abs(interrupt - awake) > MAX_WAKE_DIFFERENCE:
        errors.append("awake_clock_discontinuity")
    if any(not 0 <= sample.read_ns <= MAX_READ_NS for sample in (first, last)):
        errors.append("counter_read_span")
    if first.groups != 1 or last.groups != 1 or not 1 <= first.processors <= 64 \
            or first.processors != last.processors:
        errors.append("processor_group_or_count")
    if min(first.available_bytes, last.available_bytes) < MIN_AVAILABLE:
        errors.append("physical_memory")
    if (first.ac_line, last.ac_line, first.saver, last.saver) != (1, 1, 0, 0):
        errors.append("power_state")

    if not (cpu_ordered(first.before, first.after)
            and cpu_ordered(first.after, last.before)
            and cpu_ordered(last.before, last.after)):
        errors.append("system_cpu_counter_order")
    total_lower = last.before.total - first.after.total
    busy_upper = last.after.busy - first.before.busy
    capacity = awake * first.processors
    if capacity <= 0 or not 0.9 * capacity <= total_lower <= 1.1 * capacity:
        errors.append("system_counter_capacity")
    observer = last.observer_ns - first.observer_ns
    if observer < 0 or (capacity > 0 and observer > capacity * MAX_OBSERVER_CPU):
        errors.append("observer_cpu")
    job_delta = 0
    if during:
        if first.job is None or last.job is None:
            errors.append("missing_job_cpu")
        elif (min(first.job.kernel, first.job.user) < 0
              or last.job.kernel < first.job.kernel or last.job.user < first.job.user
              or last.job.total_processes < first.job.total_processes
              or not 0 <= last.job.active_processes <= last.job.total_processes):
            errors.append("job_counter_order")
        else:
            job_delta = last.job.total - first.job.total
    elif first.job is not None or last.job is not None:
        errors.append("unexpected_job_cpu")

    raw_residual = busy_upper - job_delta
    if total_lower > 0 and raw_residual * 100 < -NEGATIVE_TOLERANCE_PP * total_lower:
        errors.append("job_exceeds_system_busy")
    value = None if total_lower <= 0 else 100 * max(0, raw_residual) / total_lower
    return {
        "errors": errors, "residual_cpu_upper_pct": value,
        "system_total_lower_ticks": total_lower, "system_busy_upper_ticks": busy_upper,
        "job_cpu_ticks": job_delta, "raw_residual_ticks": raw_residual,
        "sampler_cpu_ns": observer,
    }


def verdict(windows, *, during=False):
    reasons = [f"window_{index}:{reason}"
               for index, row in enumerate(windows, 1) for reason in row["errors"]]
    count = len(windows)
    if (not during and count != INTERVALS) or (during and count < INTERVALS):
        reasons.append("coverage")
    values = [row["residual_cpu_upper_pct"] for row in windows]
    if any(value is None for value in values):
        reasons.append("missing_cpu")
    elif values:
        if median(values) > MEDIAN_CPU:
            reasons.append("median_cpu")
        if max(values) > (DURING_MAX_CPU if during else OUTSIDE_MAX_CPU):
            reasons.append("maximum_cpu")
        if during and any(min(a, b) > DURING_PAIRED_CPU for a, b in zip(values, values[1:])):
            reasons.append("adjacent_high_cpu")
    return {"candidate_pass": not reasons, "reasons": reasons}