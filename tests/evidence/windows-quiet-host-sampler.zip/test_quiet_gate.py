"""Pure and receipt-based controls. No child processes are launched."""

from dataclasses import replace
from pathlib import Path
import json
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from quiet_gate import Cpu, Job, Sample, INTERVALS, MIN_AVAILABLE, verdict, window

CAPACITY = 800_000_000
TICKS = 50_000_000


def sample(step, busy=0, job=None):
    total = CAPACITY * (step + 1)
    cpu = Cpu(total - busy, total, 0)
    return Sample(step * 5_000_000_000, step * TICKS, step * TICKS, 0, 0,
                  1, 16, MIN_AVAILABLE, 1, 0, cpu, cpu, job)


def row(cpu, *errors):
    return {"residual_cpu_upper_pct": cpu, "errors": list(errors)}


def decode(raw):
    return Sample(**dict(raw, before=Cpu(**raw["before"]), after=Cpu(**raw["after"]),
                         job=None if raw["job"] is None else Job(**raw["job"])))


class GateTests(unittest.TestCase):
    def test_system_bracket_and_job_subtraction(self):
        empty = Job(0, 0, 0, 0)
        completed = Job(16_000_000, 16_000_000, 2, 0)
        first = sample(0, job=empty)
        last = sample(1, 80_000_000, completed)
        ordinary = window(replace(first, job=None), replace(last, job=None))
        self.assertEqual(ordinary["residual_cpu_upper_pct"], 10)
        self.assertEqual(ordinary["errors"], [])
        result = window(first, last, during=True)
        self.assertEqual(result["residual_cpu_upper_pct"], 6)
        self.assertEqual(result["job_cpu_ticks"], 32_000_000)
        self.assertEqual(result["errors"], [])

        widened = replace(last, after=Cpu(last.after.idle, last.after.kernel + 8_000_000, 0))
        self.assertEqual(window(first, widened, during=True)["residual_cpu_upper_pct"], 7)

    def test_negative_and_unproved_job_accounting(self):
        first = sample(0, job=Job(0, 0, 0, 0))
        last = sample(1, 32_000_000, Job(80_000_000, 0, 1, 0))
        self.assertIn("job_exceeds_system_busy", window(first, last, during=True)["errors"])
        self.assertIn("missing_job_cpu", window(first, replace(last, job=None), during=True)["errors"])
        self.assertIn("unexpected_job_cpu", window(first, last)["errors"])

    def test_discontinuous_host_or_nonconforming_sampler(self):
        first = sample(0)
        last = sample(1)
        for patch, name in (
            ({"monotonic_ns": 9_000_000_000}, "sample_gap"),
            ({"interrupt_ticks": TICKS + 2_500_001}, "awake_clock_discontinuity"),
            ({"read_ns": 10_000_001}, "counter_read_span"),
            ({"groups": 2}, "processor_group_or_count"),
            ({"processors": 17}, "processor_group_or_count"),
            ({"available_bytes": MIN_AVAILABLE - 1}, "physical_memory"),
            ({"ac_line": 0}, "power_state"),
            ({"saver": 1}, "power_state"),
            ({"observer_ns": 80_000_001}, "observer_cpu"),
            ({"awake_ticks": TICKS // 2, "interrupt_ticks": TICKS // 2}, "system_counter_capacity"),
            ({"before": Cpu(0, 0, 0)}, "system_cpu_counter_order"),
        ):
            with self.subTest(name=name):
                self.assertIn(name, window(first, replace(last, **patch))["errors"])

    def test_limits_do_not_drop_bad_windows(self):
        low = [row(2)] * INTERVALS
        self.assertTrue(verdict(low)["candidate_pass"])
        self.assertEqual(verdict(low[:-1])["reasons"], ["coverage"])
        self.assertEqual(verdict(low[:-1] + [row(15.01)])["reasons"], ["maximum_cpu"])
        self.assertEqual(verdict([row(10.01)] * INTERVALS)["reasons"], ["median_cpu"])
        self.assertEqual(verdict(low[:-2] + [row(15.01)] * 2, during=True)["reasons"],
                         ["adjacent_high_cpu"])
        self.assertEqual(verdict(low[:-1] + [row(25.01)], during=True)["reasons"], ["maximum_cpu"])
        self.assertIn("window_12:physical_memory",
                      verdict(low[:-1] + [row(2, "physical_memory")])["reasons"])

    def test_exact_saved_native_calibration_and_observation(self):
        calibration = [json.loads(line) for line in (HERE / "calibration.jsonl").read_text().splitlines()]
        before, after, result = calibration
        computed = window(decode(before["raw"]), decode(after["raw"]), during=True)
        self.assertEqual(after["interval"], computed)
        self.assertTrue(result["interval_valid"])
        self.assertEqual(after["raw"]["job"]["total_processes"], 2)
        self.assertEqual(after["raw"]["job"]["active_processes"], 0)
        self.assertEqual(after["benchmark_slots"], 0)

        records = [json.loads(line) for line in (HERE / "observe-001.jsonl").read_text().splitlines()]
        context, *samples, decision = records
        self.assertEqual(context["benchmark_slots"], 0)
        self.assertEqual(len(samples), INTERVALS + 1)
        computed = [window(decode(a["raw"]), decode(b["raw"])) for a, b in zip(samples, samples[1:])]
        self.assertEqual([item["interval"] for item in samples[1:]], computed)
        self.assertEqual({key: decision[key] for key in ("candidate_pass", "reasons")},
                         verdict(computed))


if __name__ == "__main__":
    unittest.main()