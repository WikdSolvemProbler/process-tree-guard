# Windows quiet campaign qualification

This records telemetry qualification for issue #7. It authorizes zero benchmark slots. The tested thresholds are prospective and require review on the full launcher and frozen run manifest.

Twelve consecutive five-second windows before and after the campaign would require a median total CPU reading of at most 10%, no window above 15%, at least 4 GiB physical memory available, and continuous sampled AC power with battery saver off. Use one processor group and retain every raw CPU endpoint. During the campaign use a five-second cadence and subtract only the cumulative kernel and user time attributed to the exact enclosing campaign Job. A proposed full-run gate rejects a median above 10%, any window above 25%, or two consecutive windows above 15%. It also rejects invalid counters, unacceptable gaps, a failed drain, a failed postflight, or competing build and benchmark processes.

The observed percentage bounds the bracketed reported-counter calculation. It does not establish a physical upper bound on interference because the counters are quantized and can update at different times. The evaluator retains negative residuals and refuses a discrepancy beyond 0.5 percentage points. The full runner must resolve phase crossings, incomplete final intervals, competing workloads, and continuous evidence from preflight through drain and postflight. These are separate from the run package and freeze gate in the benchmark specification.

The first native calibration failed before opening a Job because the precise clock functions were absent from the machine's Kernel32 exports. The corrected launcher binds the Windows realtime API set. Its settled nested-Job fixture captured two terminated members and a natural drain. A separate calibration retained exact handles for a nested controller and its child. The outer Job's CPU delta matched the sum of their independently queried deltas in all three windows. Both processes were live in the first two windows and had exited by the third. All fixture commands ran within the pinned finite Windows guard.

The host-only observation used the same counters and collected 12 complete windows. It used no Job, launched no benchmark workloads, and was separate from the calibration fixtures. Its highest reading was 7.85%, and its median was 2.25%. This establishes that the sampled minute met the tested limits. It does not admit a future capture.

The source and input manifest pins the canonical checkout and exact SysPrims option, the CI guard and testkit binaries used by the full correctness run, the three existing competitors, and the tools. The candidate launcher, exact argv, environment, power and process checks, and review approvals must be bound to a new manifest before the full campaign runs.

Microsoft reference material

- [System CPU times](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getsystemtimes)
- [Nested Jobs and accounting](https://learn.microsoft.com/en-us/windows/win32/procthread/nested-jobs)
- [Job cumulative process times](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_basic_accounting_information)
- [Unbiased interrupt clock](https://learn.microsoft.com/en-us/windows/win32/api/realtimeapiset/nf-realtimeapiset-queryunbiasedinterrupttimeprecise)