import json
import os
from pathlib import Path
import runpy
import sys
import time

suite_path, journal_path, tree_sha = sys.argv[1:]
namespace = runpy.run_path(suite_path, run_name="ptg_journalled_suite")
main = namespace["main"]
base_result = namespace["CertificateResult"]

with Path(journal_path).open("x", encoding="utf-8", newline="\n") as journal:
    def write(event, **fields):
        record = {"event": event, "monotonic_ns": time.monotonic_ns(), **fields}
        journal.write(json.dumps(record, ensure_ascii=True) + "\n")
        journal.flush()
        os.fsync(journal.fileno())

    class JournalResult(base_result):
        def startTest(self, test):
            super().startTest(test)
            write("start", test=test.id())

        def _record(self, test, outcome, tier_label=None, detail=None):
            super()._record(test, outcome, tier_label, detail)
            write("result", test=test.id(), outcome=outcome)

    main.__globals__["CertificateResult"] = JournalResult
    write("suite_start", tree_sha=tree_sha)
    code = main(["--tree-sha", tree_sha])
    write("suite_terminal", exit_code=code)
    raise SystemExit(code)
