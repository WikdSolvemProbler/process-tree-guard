from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
TREE = "59cc806a8060596bdfcca0ec8bd28c4fbf1c3b3e"
PORTABLE_TREE = TREE
IMAGE_SOURCE = "e73981af6bf380cc1ac0dfec52a8806b7cbf8b71"
FOCUSED = {
    "test_campaign_logic.ConfigPathTests.test_relative_config_paths_anchor_to_the_config_folder",
    "test_campaign_logic.RecordConsistencyTests.test_package_checker_flags_inconsistent_records",
}


def digest(raw):
    return sha256(raw).hexdigest()


def normalized(raw):
    return raw.replace(b"\r\n", b"\n")


def main():
    files = {f"windows/{name}": (ROOT / name).read_bytes() for name in (
        "started.json", "terminal.json", "staged-build.json", "stdout.log", "stderr.log",
        "run-journalled.py", "journal.jsonl",
    )}
    terminal = json.loads(files["windows/terminal.json"])
    if (terminal["exit_code"] != 0 or terminal["tree_sha"] != TREE
        or terminal["binary_source_commit"] != IMAGE_SOURCE
        or terminal["binaries_verified_after"] is not True
        or terminal["stdout_sha256"] != digest(files["windows/stdout.log"])
        or terminal["stderr_sha256"] != digest(files["windows/stderr.log"])
        or terminal["journal_sha256"] != digest(files["windows/journal.jsonl"])
        or terminal["staged_build_sha256"] != digest(files["windows/staged-build.json"])
        or terminal["tree_archive_sha256"] != digest((ROOT / "tree.tar").read_bytes())):
        raise ValueError("Windows terminal evidence differs")
    if b"(647 run, 4 skipped, 0 failures, 0 errors)" not in files["windows/stdout.log"]:
        raise ValueError("Windows stdout tally differs")

    certs = ROOT / "checkout/tests/certificates"
    index = json.loads((certs / "index.json").read_bytes())
    if index["tree_sha"] != TREE or index["outcomes"] != {"pass": 643, "skip": 4}:
        raise ValueError("Windows suite census differs")
    counters = Counter()
    focused_passes = set()
    for path in sorted(certs.glob("*.json")):
        raw = path.read_bytes()
        files[f"windows/certificates/{path.name}"] = raw
        if path.name == "index.json":
            continue
        record = json.loads(raw)
        if record["run_id"] != index["run_id"] or record["tree_sha"] != TREE:
            raise ValueError(f"stale Windows certificate: {path.name}")
        counters[record["outcome"]] += 1
        if record["test"] in FOCUSED and record["outcome"] == "pass":
            focused_passes.add(record["test"])
    if counters != index["outcomes"] or focused_passes != FOCUSED or index["certificates"] != 647:
        raise ValueError("Windows certificates differ")

    journal = [json.loads(line) for line in files["windows/journal.jsonl"].splitlines()]
    if (len(journal) != 1296 or journal[0]["event"] != "suite_start"
        or journal[0]["tree_sha"] != TREE or journal[-1]["event"] != "suite_terminal"
        or journal[-1]["exit_code"] != 0):
        raise ValueError("journal boundary or event count differs")
    seen = {}
    for start, result in zip(journal[1:-1:2], journal[2:-1:2]):
        if (start["event"] != "start" or result["event"] != "result"
            or start["test"] != result["test"] or start["test"] in seen
            or start["monotonic_ns"] > result["monotonic_ns"]):
            raise ValueError("journal test identity or order differs")
        seen[result["test"]] = result["outcome"]
    if Counter(seen.values()) != counters or any(seen.get(test) != "pass" for test in FOCUSED):
        raise ValueError("journal and certificates disagree")
    for path in certs.glob("*.json"):
        if path.name != "index.json":
            cert = json.loads(path.read_bytes())
            if seen.get(cert["test"]) != cert["outcome"]:
                raise ValueError(f"journal differs from certificate: {path.name}")

    native = ROOT.parent / "goal-native-profile-59cc806-001"
    names = (
        "payload.json", "payload.tar.gz", "launch.ps1",
        "linux-command.txt", "linux.ssh-exit.txt", "linux.stdout.log", "linux.stderr.log",
        "macos-command.txt", "macos.ssh-exit.txt", "macos.stdout.log", "macos.stderr.log",
        "cleanup-command.txt", "cleanup-verify.log", "cleanup-verify.stderr.log",
    )
    for name in names:
        files[f"native/{name}"] = (native / name).read_bytes()
    payload = json.loads(files["native/payload.json"])
    if (payload["commit"] != PORTABLE_TREE
        or payload["sha256"] != digest(files["native/payload.tar.gz"])
        or payload["payload_bytes"] != len(files["native/payload.tar.gz"])):
        raise ValueError("native test archive differs")
    for platform in ("linux", "macos"):
        out = normalized(files[f"native/{platform}.stdout.log"])
        err = normalized(files[f"native/{platform}.stderr.log"])
        if (files[f"native/{platform}.ssh-exit.txt"].strip() != b"0"
            or f"tree_sha={PORTABLE_TREE}\n".encode() not in out or b"scratch_removed=" not in out
            or len(re.findall(rb"^test_.+ \.\.\. ok$", err, re.M)) != 2
            or not all(name.rsplit(".", 1)[1].encode() + b" (" + name.encode() + b") ... ok" in err
                       for name in FOCUSED)
            or b"Ran 2 tests" not in err or not err.rstrip().endswith(b"OK")):
            raise ValueError(f"native test evidence differs: {platform}")
    cleanup = normalized(files["native/cleanup-verify.log"])
    if (b"macos_scratch=absent macos_process_group=absent\n" not in cleanup
        or b"linux_scratch=absent linux_scope=absent\n" not in cleanup
        or files["native/cleanup-verify.stderr.log"]):
        raise ValueError("native cleanup differs")

    summary = {
        "test_source": TREE, "windows_ci_binary_source": IMAGE_SOURCE,
        "windows_full_suite": index["outcomes"], "portable_tree": PORTABLE_TREE,
        "portable_exact_source": {"linux": 2, "macos": 2},
        "native_cleanup_verified": True,
    }
    files["package-verification.py"] = Path(__file__).read_bytes()
    files["summary.json"] = (json.dumps(summary, indent=2, sort_keys=True) + "\n").encode()
    files["INDEX.json"] = (json.dumps({name: digest(data) for name, data in files.items()},
                                     indent=2, sort_keys=True) + "\n").encode()
    archive = ROOT / "sysprims-profile-correctness.zip"
    with ZipFile(archive, "x", compression=ZIP_DEFLATED) as bundle:
        for name, raw in sorted(files.items()):
            bundle.writestr(ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0)), raw, compress_type=ZIP_DEFLATED)
    with ZipFile(archive) as bundle:
        if bundle.testzip() is not None or set(bundle.namelist()) != set(files):
            raise ValueError("archive member census differs")
        if any(bundle.read(name) != raw for name, raw in files.items()):
            raise ValueError("archive content differs")
    print(json.dumps({"archive_sha256": digest(archive.read_bytes()), **summary}, indent=2))


if __name__ == "__main__":
    main()