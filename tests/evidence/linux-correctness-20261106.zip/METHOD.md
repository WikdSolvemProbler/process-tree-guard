# Portable Linux correctness

Both attempts tested the same Git archive on ARM64 Linux 6.8 through the
Tailscale Mac and its Linux guest. Each guest scope used a finite wall-clock
deadline and control-group SIGKILL. Independent checks confirmed both scopes
were absent after execution.

The first standard run reached its 460-second guest cap. Its 262 progress
characters included one failure at ordinal 195 in the unchanged suite order,
the sleeping-launcher owner pricing test. The interruption prevented a full
report or traceback. An unchanged isolated run of that case passed. The first
guest scratch was preserved.

The second run started from a fresh extraction of the exact same archive.
The standard suite's result class emitted per-test start/end and immediate
tracebacks. It completed all 647 cases with 593 passes, 54 platform or tier
skips, and no failures. Its own scratch was removed. The records concern the
portable suite on this guest. The production Linux backend is a separate issue.
