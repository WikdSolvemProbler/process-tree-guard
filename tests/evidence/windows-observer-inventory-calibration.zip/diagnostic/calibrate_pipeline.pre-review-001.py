"""Fixed no-benchmark calibration of exact 013 code, with few QPC reads."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
FIXED = HERE.with_name("issue7-quiet-launch-013")
sys.path.insert(0, str(FIXED))
import inventory_gate as gate
from image_policy import ALLOWED
from quiet_sampler import stamp, warm_job_query

APPROVED = "313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae"


def source_hashes(manifest):
    result = {}
    for name, expected in manifest["file_sha256"].items():
        actual = hashlib.sha256((FIXED / name).read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError(f"frozen source differs: {name}")
        result[name] = actual
    return result


def main():
    raw = (FIXED / "manifest.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != APPROVED:
        raise ValueError("original 013 manifest differs")
    manifest = json.loads(raw)
    before = source_hashes(manifest)
    absolute_deadline = time.perf_counter_ns() + 35_000_000_000
    completed = 0
    code = 0
    snapshots = []
    original_snapshot = gate.create_snapshot

    def measured_snapshot(*args):
        begin = time.perf_counter_ns()
        result = original_snapshot(*args)
        end = time.perf_counter_ns()
        snapshots.append({"begin_ns": begin, "end_ns": end,
                          "native_return_valid": bool(result) and result != gate.INVALID_HANDLE})
        return result

    with (
        (HERE / "calibration-001.jsonl").open("x", encoding="utf-8") as output,
        (HERE / "raw-sample-001.jsonl").open("x", encoding="utf-8") as raw_samples,
    ):
        def emit(kind, **fields):
            print(json.dumps({"kind": kind, **fields}), file=output, flush=True)

        emit("context", scope="fixed no-benchmark full 013 pipeline calibration",
             instrumentation="perf_counter_ns at stage and snapshot boundaries only; no added CPU queries",
             manifest_sha256=APPROVED, source_sha256=before,
             snapshots=3, spacing_seconds=5, inner_seconds=35, benchmark_slots=0)
        try:
            with gate.enclosing_guard(manifest["tools"]["outer_guard"]["path"]) as guard:
                warm_job_query()
                gate.create_snapshot = measured_snapshot
                origin = time.perf_counter_ns()
                for index in range(3):
                    remaining = origin + index * 5_000_000_000 - time.perf_counter_ns()
                    if remaining > 0:
                        time.sleep(remaining / 1e9)
                    if time.perf_counter_ns() >= absolute_deadline:
                        raise TimeoutError("absolute diagnostic budget")
                    snapshots.clear()
                    stamp_begin = time.perf_counter_ns()
                    sample = stamp()
                    stamp_end = time.perf_counter_ns()
                    emit_begin = time.perf_counter_ns()
                    print(json.dumps({"kind": "sample", "phase": "pre", "endpoint": False,
                                      "raw": asdict(sample), "utc_ns": time.time_ns()}),
                          file=raw_samples, flush=True)
                    emit_end = time.perf_counter_ns()
                    inventory_begin = time.perf_counter_ns()
                    rows = gate.inventory(guard, None, manifest["image_policy"])
                    finished = time.perf_counter_ns()
                    emit("sample", index=index, source_monotonic_ns=sample.monotonic_ns,
                         stamp_begin_ns=stamp_begin, stamp_end_ns=stamp_end,
                         raw_emit_begin_ns=emit_begin, raw_emit_end_ns=emit_end,
                         inventory_begin_ns=inventory_begin, finished_ns=finished,
                         snapshot_calls=list(snapshots), rows=rows,
                         all_allowed=all(row["state"] in ALLOWED for row in rows),
                         whole_bracket_ns=finished - sample.monotonic_ns,
                         time_budget_pass=0 <= finished - sample.monotonic_ns <= 50_000_000)
                    completed += 1
        except BaseException as error:
            code = 1
            emit("error", error=f"{type(error).__name__}: {error}",
                 partial_snapshot_calls=list(snapshots))
        finally:
            gate.create_snapshot = original_snapshot
            after = source_hashes(manifest)
            emit("terminal", code=code, snapshots=completed,
                 frozen_sources_unchanged=before == after, source_sha256=after,
                 benchmark_slots=0)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
