$ErrorActionPreference = 'Stop'
$root = 'C:/Users/Peter/process-tree-guard/target/codex-security/issue7-grouped-image-native-controls-001'
$python = 'C:/Users/Peter/AppData/Local/Programs/Python/Python312/python.exe'
$guard = 'C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe'
$pins = [ordered]@{
  $python = '4d6f5f81a4bca11191c4c7c6b43632694d0a4ce74e068619d8fdc161d469859a'
  $guard = '1899137f687541256fb89749b2fe6a2940f2e420faaf2330fc84f32cfd7fae43'
  "$root/native_controls.py" = '224409040ef7d27e87dd09706ac601aaf7920f6d6573f69373a9e1969d36349d'
}
function Assert-Pins {
  foreach ($item in $pins.GetEnumerator()) {
    if ((Get-FileHash -LiteralPath $item.Key -Algorithm SHA256).Hash.ToLowerInvariant() -cne $item.Value) {
      throw "pin differs: $($item.Key)"
    }
  }
}
Assert-Pins
foreach ($name in @('stdout-001.log','stderr-001.log','native-controls-001.jsonl','receipt-001.json')) {
  if (Test-Path -LiteralPath "$root/$name") { throw "existing outcome refused: $name" }
}
$begin = [DateTime]::UtcNow.ToString('o')
$exitCode = $null
$failure = $null
try {
  & $python -I -B "$root/native_controls.py" 1> "$root/stdout-001.log" 2> "$root/stderr-001.log"
  $exitCode = $LASTEXITCODE
  Assert-Pins
} catch { $failure = $_.Exception.Message }
$artifacts = [ordered]@{}
foreach ($name in @('native_controls.py','run.ps1','plan.json','stdout-001.log','stderr-001.log','native-controls-001.jsonl')) {
  if (Test-Path -LiteralPath "$root/$name") {
    $artifacts[$name] = (Get-FileHash -LiteralPath "$root/$name" -Algorithm SHA256).Hash.ToLowerInvariant()
  }
}
$terminal = $null
$rows = @()
try {
  $rows = @(Get-Content -LiteralPath "$root/native-controls-001.jsonl" | ForEach-Object { $_ | ConvertFrom-Json })
  $terminals = @($rows | Where-Object kind -eq 'terminal')
  if ($terminals.Count -eq 1) { $terminal = $terminals[0] }
} catch { $failure = "raw parsing failed: $($_.Exception.Message)" }
$cases = @($rows | Where-Object kind -eq 'case')
$qualified = $exitCode -eq 0 -and $null -eq $failure -and $null -ne $terminal -and $terminal.code -eq 0 -and $terminal.qualified -eq $true -and $cases.Count -eq 6 -and @($cases | Where-Object qualified -ne $true).Count -eq 0
$receipt = [ordered]@{
 schema='grouped-native-components-receipt-v1'; began_utc=$begin; ended_utc=[DateTime]::UtcNow.ToString('o')
 exit_code=$exitCode; failure=$failure; qualified=[bool]$qualified
 artifact_sha256=$artifacts; tools=$pins; completed_cases=$cases.Count
 scope='Six genuine native fixture-file/member callback component controls; fixture files are not process images. Not a census, phase, campaign, or performance result.'
 benchmark_slots=0; census_qualified=$false; phase_qualified=$false; campaign_qualified=$false
}
$json = $receipt | ConvertTo-Json -Depth 12
$file = [System.IO.File]::Open("$root/receipt-001.json",[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::Write,[System.IO.FileShare]::Read)
try {
 $bytes=[System.Text.UTF8Encoding]::new($false).GetBytes($json)
 $file.Write($bytes,0,$bytes.Length)
} finally { $file.Dispose() }
if (-not $qualified) { exit 1 }
exit 0
