"""Fixed native grouped-file/member components; never a census or benchmark."""
import ctypes
from ctypes import wintypes as w
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
GROUP = BASE / "issue7-grouped-image-census-001"
PINS = {
 "image_policy.py": "f9ca5e411de733df0e44cec6b3604790ed21336213850ef7f35b8acd0d54ff9d",
 "grouped_image.py": "7fa830c41eac2c0a7b320dbb74162880cd6388655c8d356c07b88bbdd7f45898",
 "native_processes.py": "8bef895fbfefe86f39fd8bf414d46ca4037dda6e71fb4a09e839910c33b4a166",
 "grouped_census.py": "ba5301dbdad4bbcdc7cf2c38cc0c3daabe22878306846f5de686aa81728f989a",
 "replay_grouped.py": "f4e11b443a8a5afef5119cdaf4c04787331ebd1ddf8061d904a807b863f2ca52",
 "METHOD.json": "83e9823c76d75fded8bb944fa1d5a06e878f12d4eba56137e242ac43cb2a8d01",
}
OWNER = BASE / "issue7-native-image-verification-001/native_image_control.py"
OWNER_SHA = "e95d7c1cde00de756da5712ada770a3fde77767e407618bd84a3e0bad19879ea"
SLOT = BASE / "issue7-quiet-campaign-inputs-002/checkout/tests/campaign/windows_slot_job.py"
SLOT_SHA = "7c4160a9870fa8cda70a352c60dea6239cf979b1c463d365b7eeef227d9027ba"
CASES = ("stable", "in_place", "growth", "truncation", "callback_failure", "before_open_rebind")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def checked_sources():
    actual = {name: sha(GROUP / name) for name in PINS}
    if actual != PINS or sha(OWNER) != OWNER_SHA or sha(SLOT) != SLOT_SHA:
        raise ValueError("component source pin mismatch")
    return {**actual, "owner": OWNER_SHA, "slot": SLOT_SHA}

def load(name, path, expected):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError("module changed before execution")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module

def require(value, message):
    if not value:
        raise ValueError(message)

def main():
    pins_before = checked_sources()
    image = load("grouped_image", GROUP / "grouped_image.py", PINS["grouped_image.py"])
    load("image_policy", GROUP / "image_policy.py", PINS["image_policy.py"])
    core = load("grouped_census", GROUP / "grouped_census.py", PINS["grouped_census.py"])
    native = load("native_processes", GROUP / "native_processes.py", PINS["native_processes.py"])
    owner = load("fixture_owner", OWNER, OWNER_SHA)
    slot = load("windows_slot_job", SLOT, SLOT_SHA)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    count = kernel.GetProcessHandleCount
    count.argtypes = [w.HANDLE, ctypes.POINTER(w.DWORD)]
    count.restype = w.BOOL
    current = kernel.GetCurrentProcess
    current.argtypes, current.restype = [], w.HANDLE
    def handles():
        value = w.DWORD()
        if not count(current(), ctypes.byref(value)):
            raise ctypes.WinError(ctypes.get_last_error())
        return value.value
    deadline = time.perf_counter_ns() + 15_000_000_000
    def check_time():
        if time.perf_counter_ns() >= deadline:
            raise TimeoutError("15-second component deadline")
    baseline = handles()
    backend = native.WindowsBackend()
    process = job = None
    results = []
    cleanup_errors = []
    code = 0
    with (HERE / "native-controls-001.jsonl").open("x", encoding="utf-8") as output:
        def emit(kind, **values):
            print(json.dumps({"kind": kind, **values}, allow_nan=False), file=output, flush=True)
        emit("context", pins=pins_before, pid=os.getpid(), benchmark_slots=0,
             scope="fixture-file/member callback components only; fixture is not process image; not a census, phase or campaign",
             fixed_cases=CASES, inner_seconds=15, outer_seconds=30)
        try:
            entries, upper = backend.snapshot()
            entry = next(row for row in entries if row["pid"] == os.getpid())
            process = backend.open_process(os.getpid())
            job = slot.SlotJob()  # Empty owned Job; never launch or assign.
            component_baseline = handles()
            for case in CASES:
                check_time()
                owned = owner.OwnedFixture(HERE / ("fixture-" + case))
                record = {"case": case, "begin_ns": time.perf_counter_ns(),
                          "snapshot_upper_ticks": upper, "entry": entry, "callback_count": 0}
                original_opened, original_digest = image.opened, image.held_digest
                original_create, original_close = image.create_file, image.close_handle
                live = set()
                read_calls = []
                def tracked_create(*args):
                    handle = original_create(*args)
                    if handle and handle != image.INVALID_HANDLE_VALUE:
                        live.add(handle)
                    return handle
                def tracked_close(handle):
                    result = original_close(handle)
                    if result:
                        require(handle in live, "unknown file handle close")
                        live.remove(handle)
                    return result
                def tracked_digest(handle, size):
                    call = {"begin_ns": time.perf_counter_ns(), "size": size}
                    read_calls.append(call)
                    try:
                        digest = original_digest(handle, size)
                        call["sha256"] = digest
                        return digest
                    except Exception as error:
                        call["error"] = str(error)
                        raise
                    finally:
                        call["end_ns"] = time.perf_counter_ns()
                try:
                    owned.create()
                    owned.write("target", b"same")
                    owned.write("replacement", b"next")
                    target = owned.check_file("target")
                    record["target_initial"] = image.named_metadata(target)
                    record["replacement_initial"] = image.named_metadata(owned.check_file("replacement"))
                    record["P0"] = core.probe(backend, process, entry, upper, job._handle, "P0", time.perf_counter_ns)
                    require(not core.fact_problems(record["P0"], entry, upper, True), "native P0 failed")
                    image.create_file, image.close_handle = tracked_create, tracked_close
                    image.held_digest = tracked_digest
                    @contextmanager
                    def before_content(path, access):
                        if access == image.GENERIC_READ | image.FILE_READ_ATTRIBUTES:
                            record["rebind_begin_ns"] = time.perf_counter_ns()
                            owned.replace("replacement", "target")
                            record["rebind_end_ns"] = time.perf_counter_ns()
                        with original_opened(path, access) as handle:
                            yield handle
                    if case == "before_open_rebind":
                        image.opened = before_content
                    def member():
                        record["callback_count"] += 1
                        require(record["callback_count"] == 1, "callback repeated")
                        record["P1"] = core.probe(backend, process, entry, upper, job._handle, "P1", time.perf_counter_ns)
                        require(not core.member_problems({**entry, "P0": record["P0"], "P1": record["P1"]}, upper, True), "native member pair failed")
                        require(record["P1"]["job_member"] is False, "controller unexpectedly belongs to empty Job")
                        record["mutation_begin_ns"] = time.perf_counter_ns()
                        if case == "in_place": owned.write("target", b"edit")
                        elif case == "growth": owned.append("target", b"+")
                        elif case == "truncation": owned.write("target", b"")
                        record["mutation_end_ns"] = time.perf_counter_ns()
                        if case == "callback_failure":
                            raise ValueError("fixed member callback refusal")
                    try:
                        digest, evidence = image.inspect_group_image(target, member)
                        record.update(returned=True, digest=digest, evidence=evidence)
                    except Exception as error:
                        record.update(returned=False, error_type=type(error).__name__, error=str(error),
                                      winerror=getattr(error, "winerror", None),
                                      evidence=getattr(error, "evidence", None))
                    finally:
                        image.opened, image.held_digest = original_opened, original_digest
                        image.create_file, image.close_handle = original_create, original_close
                    record["read_calls"] = read_calls
                    record["remaining_file_handles"] = sorted(live)
                    require(not live, "file handle leak")
                    final = owned.check_file("target").read_bytes()
                    record.update(final_bytes_hex=final.hex(), final_size=len(final), final_sha256=hashlib.sha256(final).hexdigest())
                    evidence = record["evidence"]
                    require(isinstance(evidence, dict), "missing actual file evidence")
                    expected = {"stable": b"same", "in_place": b"edit", "growth": b"same+",
                                "truncation": b"", "callback_failure": b"same", "before_open_rebind": b"next"}[case]
                    require(final == expected, "controlled final bytes differ")
                    if case == "stable":
                        require(record["returned"] and not core.file_problems(evidence, hashlib.sha256(b"same").hexdigest()), "stable observation failed")
                    else:
                        expected_error = {"in_place": "image fixed read digests differ", "growth": "image exceeds its initial size",
                                          "truncation": "image ended before its initial size", "callback_failure": "fixed member callback refusal",
                                          "before_open_rebind": "image named entry differs from opened native identity"}[case]
                        require(not record["returned"] and record["error"] == expected_error, "wrong refusal branch")
                    if case == "before_open_rebind":
                        require(record["callback_count"] == 0 and not read_calls, "rebind reached callback/hash")
                        require(evidence["held_before"] == record["replacement_initial"], "replacement full signature differs")
                        require(evidence["named_before"] == record["target_initial"] and evidence["named_before"] != evidence["held_before"], "no actual native binding mismatch")
                    else:
                        require(record["callback_count"] == 1 and evidence["read_first"]["sha256"] == hashlib.sha256(b"same").hexdigest(), "first read/callback absent")
                        require(evidence["member_check"]["begin_ns"] <= record["P1"]["begin_ns"] <= record["P1"]["end_ns"] <= evidence["member_check"]["end_ns"], "native P1 outside shared callback")
                        if case in ("growth", "truncation"):
                            require(len(read_calls) == 2 and read_calls[1].get("error") == record["error"], "no specific second-read extent refusal")
                        elif case == "in_place":
                            require(evidence["read_second"]["sha256"] == hashlib.sha256(b"edit").hexdigest(), "second read did not observe edit")
                        elif case == "callback_failure":
                            require(len(read_calls) == 1 and "read_second" not in evidence, "callback refusal reached second read")
                    record["qualified"] = True
                except BaseException as error:
                    code = 1
                    record.update(qualified=False, qualification_error=f"{type(error).__name__}: {error}",
                                  unexpected_evidence=getattr(error, "evidence", None))
                finally:
                    image.opened, image.held_digest = original_opened, original_digest
                    image.create_file, image.close_handle = original_create, original_close
                    # Emergency close preserves failure, never rescues qualification.
                    for handle in list(live):
                        code = 1
                        if original_close(handle): live.remove(handle)
                    record["cleanup_errors"] = owned.cleanup()
                    record["fixture_absent"] = not owned.path.exists()
                    if record["cleanup_errors"] or not record["fixture_absent"] or handles() != component_baseline:
                        code = 1
                        record["qualified"] = False
                    record["end_ns"] = time.perf_counter_ns()
                    emit("case", **record)
                    results.append(record)
                check_time()
        except BaseException as error:
            code = 1
            emit("error", error=f"{type(error).__name__}: {error}", evidence=getattr(error, "evidence", None))
        finally:
            if process is not None:
                try: backend.close_process(process)
                except BaseException as error: cleanup_errors.append(str(error))
            if job is not None:
                try:
                    drained = job.drain()
                    emit("empty_job_drain", **drained)
                    require(drained["active_before"] == drained["active_after"] == 0 and drained["terminated"] is False, "empty Job not empty")
                except BaseException as error: cleanup_errors.append(str(error))
                finally:
                    try: job.close()
                    except BaseException as error: cleanup_errors.append(str(error))
            try:
                require(checked_sources() == pins_before, "source pins changed")
                check_time()
            except BaseException as error: cleanup_errors.append(str(error))
            final_handles = handles()
            if cleanup_errors or final_handles != baseline or len(results) != len(CASES) or not all(row.get("qualified") for row in results):
                code = 1
            emit("terminal", code=code, qualified=code == 0, cleanup_errors=cleanup_errors,
                 handle_count=final_handles, baseline=baseline, completed_cases=len(results), benchmark_slots=0,
                 census_qualified=False, phase_qualified=False, campaign_qualified=False)
    return code

if __name__ == "__main__":
    raise SystemExit(main())
