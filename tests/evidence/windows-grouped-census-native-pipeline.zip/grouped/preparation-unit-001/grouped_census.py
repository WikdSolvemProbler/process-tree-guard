"""Prospective grouped reported-path census. No native execution on import."""
import ntpath
import time
import sys
from image_policy import ALLOWED, classify

COMPILERS = frozenset({
    "cargo.exe", "rustc.exe", "rustdoc.exe", "cl.exe", "link.exe", "clang.exe",
    "clang-cl.exe", "lld.exe", "lld-link.exe", "rust-lld.exe", "gcc.exe",
    "g++.exe", "cc1.exe", "cc1plus.exe", "msbuild.exe", "cmake.exe", "ninja.exe",
})
WORKLOADS = frozenset({
    "python.exe", "pythonw.exe", "python3.exe", "pytest.exe", "ptg.exe",
    "process-tree-guard.exe", "testkit.exe", "sysprims.exe", "processkit-cli.exe",
    "timeout.exe",
})
GUARD_IMAGE = "process-tree-guard.exe"


def error_record(error):
    return {"type": type(error).__name__, "message": str(error),
            "winerror": getattr(error, "winerror", None)}


def integer(value, low=0, high=2**63-1):
    return type(value) is int and low <= value <= high


def ordered(begin, end):
    return integer(begin) and integer(end) and begin <= end


def probe(backend, handle, entry, upper, job_handle, phase, clock):
    fact = {"phase": phase, "begin_ns": clock(), "calls": [], "job_member": None}
    try:
        operations = [("path", "raw_image_path", (handle,)),
                      ("creation", "created_ticks", (handle,))]
        if job_handle is not None:
            operations.append(("member", "job_member", (handle, job_handle)))
        operations.append(("alive", "alive_at_member_check", (handle,)))
        for operation, field, arguments in operations:
            call = {"operation": operation, "begin_ns": clock(), "ok": False}
            fact["calls"].append(call)
            try:
                fact[field] = getattr(backend, operation)(*arguments)
                call["ok"] = True
            except Exception as error:
                call["error"] = error_record(error)
                raise
            finally:
                call["end_ns"] = clock()
        problems = fact_problems(fact, entry, upper, job_handle is not None,
                                 complete_timing=False)
        if problems:
            raise ValueError("; ".join(problems))
    except Exception as error:
        fact["error"] = error_record(error)
    finally:
        fact["end_ns"] = clock()
    return fact


def fact_problems(fact, entry, upper, job_present, *, complete_timing=True):
    problems = []
    if not isinstance(fact, dict) or "error" in fact:
        return ["required process query failed"]
    path = fact.get("raw_image_path")
    if (not isinstance(path, str) or not path or "\0" in path
            or ntpath.basename(path).casefold() != entry["name"]):
        problems.append("process image string/basename differs from snapshot")
    if not integer(fact.get("created_ticks"), 1, upper):
        problems.append("process creation exceeds precise snapshot bound")
    member = fact.get("job_member")
    if (job_present and type(member) is not bool) or (not job_present and member is not None):
        problems.append("invalid owned-Job membership observation")
    if type(fact.get("alive_at_member_check")) is not bool:
        problems.append("missing native liveness observation")
    if complete_timing:
        if not ordered(fact.get("begin_ns"), fact.get("end_ns")):
            problems.append("invalid process check interval")
        expected = ["path", "creation"] + (["member"] if job_present else []) + ["alive"]
        calls = fact.get("calls", [])
        if [call.get("operation") for call in calls] != expected:
            problems.append("missing/out-of-order native process checks")
        previous = fact.get("begin_ns")
        for call in calls:
            if (not call.get("ok") or not ordered(call.get("begin_ns"), call.get("end_ns"))
                    or not integer(previous) or call["begin_ns"] < previous
                    or not integer(fact.get("end_ns")) or call["end_ns"] > fact["end_ns"]):
                problems.append("invalid native process call evidence")
                break
            previous = call["end_ns"]
    return problems


def member_problems(row, upper, job_present):
    problems = fact_problems(row.get("P0"), row, upper, job_present)
    problems += fact_problems(row.get("P1"), row, upper, job_present)
    if problems:
        return problems
    first, last = row["P0"], row["P1"]
    if any(first[key] != last[key] for key in
           ("raw_image_path", "created_ticks", "job_member")):
        problems.append("process creation/path/owned-Job membership changed")
    if not first["alive_at_member_check"] and last["alive_at_member_check"]:
        problems.append("retained process object appeared to revive")
    if first["end_ns"] > last["begin_ns"]:
        problems.append("process passes overlap/out of order")
    return problems


def file_problems(observed, digest):
    if (not isinstance(observed, dict) or type(observed.get("schema")) is not int
            or observed["schema"] != 3):
        return ["missing grouped file observation"]
    try:
        if (not isinstance(digest, str) or len(digest) != 64
                or any(char not in "0123456789abcdef" for char in digest)):
            return ["invalid shared digest"]
        signatures = [observed[key] for key in
                      ("named_before", "held_before", "held_after", "named_after")]
        required = {"volume", "file_id_128", "size", "allocation", "links",
                    "creation_ticks", "write_ticks", "change_ticks", "attributes",
                    "directory", "delete_pending"}
        for value in signatures:
            if not isinstance(value, dict) or set(value) != required:
                return ["incomplete native file signature"]
            identity = value["file_id_128"]
            if (not integer(value["volume"], 0, 2**64-1) or not isinstance(identity, str)
                    or len(identity) != 32 or any(c not in "0123456789abcdef" for c in identity)
                    or int(identity, 16) == 0):
                return ["invalid full native file identity"]
            if (any(not integer(value[key], 0, 2**63-1) for key in ("size", "allocation"))
                    or any(not integer(value[key], 0, 2**32-1) for key in ("links", "attributes"))
                    or any(not integer(value[key], -2**63, 2**63-1)
                           for key in ("creation_ticks", "write_ticks", "change_ticks"))
                    or value["directory"] is not False or value["delete_pending"] is not False
                    or value["attributes"] & 0x10):
                return ["invalid native regular-file metadata"]
        if any(value != signatures[0] for value in signatures[1:]):
            return ["group file identity/metadata changed"]
        if observed.get("scope") != "shared path observation; P1 between fixed reads; not independent per-process reads":
            return ["incorrect grouped observation scope"]
        if (observed["sha256"] != digest or observed["read_first"]["sha256"] != digest
                or observed["read_second"]["sha256"] != digest):
            return ["group file read digests differ"]
        bounds = [observed["begin_ns"], observed["read_first"]["begin_ns"],
                  observed["read_first"]["end_ns"], observed["member_check"]["begin_ns"],
                  observed["member_check"]["end_ns"], observed["rewind"]["begin_ns"],
                  observed["rewind"]["end_ns"], observed["read_second"]["begin_ns"],
                  observed["read_second"]["end_ns"], observed["end_ns"]]
        if (any(not integer(value) for value in bounds) or bounds != sorted(bounds)
                or type(observed["rewind"]["position"]) is not int
                or observed["rewind"]["position"] != 0):
            return ["group read/member/rewind ordering failed"]
    except (KeyError, TypeError, ValueError):
        return ["incomplete group file evidence"]
    return []

def collect(backend, guard, image_policy, job_handle=None, *, clock=time.perf_counter_ns):
    """Collect one finite caller-bounded observation; no cache survives this call.

    The caller owns the enclosing guard/Job/deadline. This function never launches,
    terminates, suspends or changes a process. All file and process handles it owns
    are closed before return. Failures remain in the receipt and refuse admission.
    """
    clock_errors = []
    original_clock = clock
    previous_clock = None
    def safe_clock():
        nonlocal previous_clock
        try:
            value = original_clock()
            if not integer(value) or (previous_clock is not None and value < previous_clock):
                clock_errors.append({"type": "ValueError", "message": "invalid/regressing census clock", "winerror": None})
            if integer(value):
                previous_clock = value
            return value
        except Exception as error:
            clock_errors.append(error_record(error))
            return None
    clock = safe_clock
    observer = backend.observer_pid()
    guard_pid, guard_handle, guard_created = guard
    receipt = {"schema": "grouped-image-census-v1", "begin_ns": clock(),
               "observer_pid": observer, "guard_pid": guard_pid,
               "guard_created_ticks": guard_created, "job_present": job_handle is not None,
               "rows": [], "groups": [], "errors": clock_errors,
               "scope": "P0/read1/P1/read2 shared path observation; no post-read2 process freshness"}
    handles, owned, group_by_path = {}, [], {}
    upper = None
    try:
        snapshot = {"begin_ns": clock()}
        receipt["snapshot"] = snapshot
        try:
            entries, upper = backend.snapshot()
            snapshot.update(entries=entries, upper_ticks=upper)
        finally:
            snapshot["end_ns"] = clock()
        if not isinstance(entries, list) or not integer(upper, 1, 2**64-1):
            raise ValueError("invalid native snapshot")
        pids = []
        for entry in entries:
            if (not isinstance(entry, dict) or not integer(entry.get("pid"), 0, 2**32-1)
                    or not integer(entry.get("parent_pid"), 0, 2**32-1)
                    or not isinstance(entry.get("name"), str)
                    or entry["name"] != entry["name"].casefold()):
                raise ValueError("malformed snapshot entry")
            pids.append(entry["pid"])
        if len(set(pids)) != len(pids) or observer not in pids or guard_pid not in pids:
            raise ValueError("duplicate/missing snapshot identity")
        relevant = COMPILERS | WORKLOADS | set(image_policy["pinned_basenames"])
        veto = set(image_policy["veto_sha256"])
        for entry in entries:
            pid = entry["pid"]
            if pid == observer or (pid != guard_pid and entry["name"] not in relevant):
                continue
            row = {**entry, "row_id": "r" + str(len(receipt["rows"])),
                   "snapshot_upper_ticks": upper}
            receipt["rows"].append(row)
            opening = {"begin_ns": clock(), "ok": False,
                       "ownership": "borrowed_guard" if pid == guard_pid else "owned"}
            row["open"] = opening
            try:
                handle = guard_handle if pid == guard_pid else backend.open_process(pid)
                if not integer(handle, 1, 2**64-2):
                    raise ValueError("invalid retained process handle")
                if handle in handles.values():
                    raise ValueError("duplicate live process handle")
                handles[row["row_id"]] = handle
                if pid != guard_pid:
                    owned.append((row, handle))
                opening.update(ok=True, handle=handle)
            except Exception as error:
                opening["error"] = error_record(error)
            finally:
                opening["end_ns"] = clock()
            if not opening["ok"]:
                continue
            row["P0"] = probe(backend, handle, row, upper, job_handle, "P0", clock)
        # Membership and grouping are fixed only from complete P0 facts.
        for row in receipt["rows"]:
            first = row.get("P0")
            if fact_problems(first, row, upper, job_handle is not None):
                continue
            if row["pid"] == guard_pid or first["job_member"] is True or row["name"] in COMPILERS:
                row["P1"] = probe(backend, handles[row["row_id"]], row, upper,
                                  job_handle, "exempt", clock)
                continue
            key = first["raw_image_path"]  # EXACT str equality; never Path equality/case folding.
            if key not in group_by_path:
                group = {"group_id": "g" + str(len(receipt["groups"])),
                         "raw_image_path": key, "member_row_ids": []}
                group_by_path[key] = group
                receipt["groups"].append(group)
            group_by_path[key]["member_row_ids"].append(row["row_id"])
            row["group_id"] = group_by_path[key]["group_id"]
        by_id = {row["row_id"]: row for row in receipt["rows"]}
        for group in receipt["groups"]:
            members = tuple(by_id[key] for key in group["member_row_ids"])
            group["begin_ns"] = clock()

            group["member_callback_calls"] = 0
            def member_check(members=members):
                group["member_callback_calls"] += 1
                if group["member_callback_calls"] != 1:
                    raise ValueError("member callback repeated; no selective retry")
                for row in members:
                    row["P1"] = probe(backend, handles[row["row_id"]], row, upper,
                                      job_handle, "between_reads", clock)

            try:
                digest, observed = backend.inspect_group(group["raw_image_path"], member_check)
                group.update(shared_sha256=digest, file_observation=observed)
            except Exception as error:
                group["file_error"] = error_record(error)
                if hasattr(error, "evidence"):
                    group["file_observation"] = error.evidence
            finally:
                group["end_ns"] = clock()
        # An early file failure cannot manufacture a bracketed check; retain any
        # still-possible P1 only as explicitly unbracketed failure forensics.
        for row in receipt["rows"]:
            if row["row_id"] in handles and "P1" not in row:
                row["P1"] = probe(backend, handles[row["row_id"]], row, upper,
                                  job_handle, "after_failed_group", clock)
    except Exception as error:
        receipt["errors"].append(error_record(error))
    finally:
        active_exception = sys.exc_info()[1]
        cleanup_interrupt = None
        for row, handle in reversed(owned):
            closing = {"begin_ns": clock(), "ok": False}
            row["close"] = closing
            try:
                backend.close_process(handle)
                closing["ok"] = True
            except BaseException as error:
                closing["error"] = error_record(error)
                if not isinstance(error, Exception) and cleanup_interrupt is None:
                    cleanup_interrupt = error
            finally:
                closing["end_ns"] = clock()
        if cleanup_interrupt is not None and active_exception is None:
            raise cleanup_interrupt
    by_id = {row["row_id"]: row for row in receipt["rows"]}
    for group in receipt["groups"]:
        problems = []
        if "file_error" in group:
            problems.append("group file operation failed")
        if group.get("member_callback_calls") != 1:
            problems.append("member callback absent/repeated")
        problems += file_problems(group.get("file_observation"), group.get("shared_sha256"))
        observed = group.get("file_observation", {})
        if (not ordered(group.get("begin_ns"), group.get("end_ns"))
                or not ordered(observed.get("begin_ns"), observed.get("end_ns"))
                or observed["begin_ns"] < group["begin_ns"]
                or observed["end_ns"] > group["end_ns"]):
            problems.append("file observation outside group interval")
        if observed.get("path") != group["raw_image_path"]:
            problems.append("file observation path differs from fixed group")
        for key in group["member_row_ids"]:
            row = by_id[key]
            problems += member_problems(row, upper, job_handle is not None)
            last = row.get("P1", {})
            bounds = observed.get("member_check", {})
            if (last.get("phase") != "between_reads"
                    or not ordered(bounds.get("begin_ns"), bounds.get("end_ns"))
                    or not integer(last.get("begin_ns")) or not integer(last.get("end_ns"))
                    or last["begin_ns"] < bounds.get("begin_ns", 0)
                    or last["end_ns"] > bounds.get("end_ns", -1)):
                problems.append("member P1 not between shared file reads")
            if not row.get("close", {}).get("ok"):
                problems.append("member process handle close failed")
        group["problems"] = problems
        group["valid"] = not problems
    group_ids = {group["group_id"]: group for group in receipt["groups"]}
    for row in receipt["rows"]:
        problems = member_problems(row, upper, job_handle is not None) if upper is not None else ["snapshot failed"]
        if not row.get("open", {}).get("ok"):
            problems.append("process handle unavailable")
        if row["pid"] == guard_pid:
            if (row["name"] != GUARD_IMAGE or row.get("P0", {}).get("created_ticks") != guard_created
                    or any(row.get(pass_name, {}).get("alive_at_member_check") is not True
                           for pass_name in ("P0", "P1"))):
                problems.append("pinned enclosing guard lost")
        elif not row.get("close", {}).get("ok"):
            problems.append("process close failed")
        group = group_ids.get(row.get("group_id"))
        if group is None and not problems:
            if (row["pid"] != guard_pid and row["P0"]["job_member"] is not True
                    and row["name"] not in COMPILERS):
                problems.append("eligible process lacks fixed shared group")
            if row["P1"].get("phase") != "exempt":
                problems.append("unbracketed process check is failure forensics only")
        if group is not None and not group["valid"]:
            problems.append("shared group invalid")
        row["problems"] = problems
        if problems:
            row["state"] = "membership_unverified"
        else:
            row["state"] = classify(
                row["name"], None if group is None else group["shared_sha256"],
                enclosing=row["pid"] == guard_pid,
                member=row["P0"]["job_member"] is True, compiler_names=COMPILERS,
                veto_sha256=set(image_policy["veto_sha256"]))
    receipt["admissible"] = (not receipt["errors"] and bool(receipt["rows"])
                             and sum(row["pid"] == guard_pid for row in receipt["rows"]) == 1
                             and all(row["state"] in ALLOWED for row in receipt["rows"]))
    receipt["end_ns"] = clock()
    if not ordered(receipt["begin_ns"], receipt["end_ns"]):
        receipt["errors"].append({"type": "ValueError", "message": "invalid census clock", "winerror": None})
        receipt["admissible"] = False
    return receipt
