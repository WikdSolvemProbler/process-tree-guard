"""One prospective three-snapshot grouped census diagnostic; no workloads."""
import argparse
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
GROUPED = HERE.with_name("issue7-grouped-image-census-001")
FIXED = HERE.with_name("issue7-quiet-launch-013")
INPUTS = HERE.with_name("issue7-quiet-campaign-inputs-002")
MANIFEST_SHA = "313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae"


def checked(path, digest):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError("bound bytes differ: " + str(path))
    return raw


def loaded(name, path, raw):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def bindings(plan_sha):
    plan_raw = checked(HERE / "plan.json", plan_sha)
    plan = json.loads(plan_raw)
    if (plan["schema"] != "grouped-pipeline-diagnostic-v1"
            or plan["snapshots"] != 3 or plan["spacing_ns"] != 5_000_000_000
            or plan["inner_seconds"] != 35 or plan["outer_seconds"] != 45
            or plan["budget_ns"] != 50_000_000):
        raise ValueError("unreviewed diagnostic constants")
    sources = {name: checked(GROUPED / name, pin)
               for name, pin in plan["grouped_source_sha256"].items()}
    checked(HERE / "qualify_pipeline.py", plan["driver_sha256"])
    manifest = json.loads(checked(FIXED / "manifest.json", MANIFEST_SHA))
    frozen = {name: checked(FIXED / name, digest)
              for name, digest in manifest["file_sha256"].items()}
    input_raw = checked(INPUTS / "inputs.json", manifest["input_manifest_sha256"])
    inputs = json.loads(input_raw)
    slot_name = "tests/campaign/windows_slot_job.py"
    slot = checked(INPUTS / "checkout" / slot_name, inputs["file_sha256"][slot_name])
    pins = {"plan.json": plan_sha, "driver": plan["driver_sha256"],
            "manifest013": MANIFEST_SHA,
            "inputs.json": manifest["input_manifest_sha256"],
            slot_name: inputs["file_sha256"][slot_name],
            **{"grouped/" + k: hashlib.sha256(v).hexdigest() for k, v in sources.items()},
            **{"013/" + k: hashlib.sha256(v).hexdigest() for k, v in frozen.items()}}
    for group in ("tools", "fingerprints"):
        for name, value in manifest[group].items():
            checked(Path(value["path"]), value["sha256"])
            pins[group + "/" + name] = value["sha256"]
    if not Path(sys.executable).samefile(manifest["tools"]["python"]["path"]):
        raise ValueError("unsealed interpreter")
    if (sys.getwindowsversion().build != manifest["windows_build"]
            or sys.version != manifest["python_version"]):
        raise ValueError("host/tool version differs from frozen reference")
    return plan, manifest, sources, frozen, slot, pins


def main(plan_sha):
    plan, manifest, sources, frozen, slot, before = bindings(plan_sha)
    loaded("image_policy", GROUPED / "image_policy.py", sources["image_policy.py"])
    loaded("grouped_image", GROUPED / "grouped_image.py", sources["grouped_image.py"])
    collector = loaded("grouped_census", GROUPED / "grouped_census.py", sources["grouped_census.py"])
    native = loaded("native_processes", GROUPED / "native_processes.py", sources["native_processes.py"])
    replay = loaded("replay_grouped", GROUPED / "replay_grouped.py", sources["replay_grouped.py"])
    math = loaded("quiet_gate", FIXED / "quiet_gate.py", frozen["quiet_gate.py"])
    loaded("windows_slot_job", INPUTS / "checkout/tests/campaign/windows_slot_job.py", slot)
    sampler = loaded("quiet_sampler", FIXED / "quiet_sampler.py", frozen["quiet_sampler.py"])
    deadline = time.perf_counter_ns() + plan["inner_seconds"] * 1_000_000_000
    original_snapshot = native.create_snapshot
    snapshot_calls = []
    samples, cases, windows = [], [], []
    code = 0

    def measured_snapshot(*args):
        begin = time.perf_counter_ns()
        try:
            value = original_snapshot(*args)
            return value
        finally:
            snapshot_calls.append({"begin_ns": begin, "end_ns": time.perf_counter_ns()})

    with ((HERE / "diagnostic-001.jsonl").open("x", encoding="utf-8") as output,
          (HERE / "telemetry-001.jsonl").open("x", encoding="utf-8") as raw_output,
          (HERE / "census-001.jsonl").open("x", encoding="utf-8") as census_output):
        def emit(stream, kind, **values):
            print(json.dumps({"kind": kind, **values}, allow_nan=False), file=stream, flush=True)
        emit(output, "context", source_sha256=before, snapshots=3, spacing_ns=5_000_000_000,
             benchmark_slots=0, scope="prospective grouped observation diagnostic; not a phase/campaign",
             cutoff="strict stamp-entry through telemetry flush, census and census flush; original sample-to-census-return also retained",
             post_cutoff="independent JSON replay and diagnostic logging excluded from latency, retained in subsequent observer CPU windows",
             census_budget_ns=50_000_000)
        try:
            with native.open_exact(os.getpid()) as self_handle:
                observer_created = native.WindowsBackend.creation(self_handle)
            with native.enclosing_guard(manifest["tools"]["outer_guard"]["path"]) as guard:
                emit(output, "identity", observer_pid=os.getpid(), observer_created_ticks=observer_created,
                     guard_pid=guard[0], guard_created_ticks=guard[2], job_present=False)
                sampler.warm_job_query()
                native.create_snapshot = measured_snapshot
                origin = time.perf_counter_ns()
                for index in range(3):
                    remaining = origin + index * 5_000_000_000 - time.perf_counter_ns()
                    if remaining > 0:
                        time.sleep(remaining / 1e9)
                    if time.perf_counter_ns() >= deadline:
                        raise TimeoutError("35-second diagnostic deadline before stamp")
                    snapshot_calls.clear()
                    stamp_begin = time.perf_counter_ns()
                    sample = sampler.stamp()
                    stamp_end = time.perf_counter_ns()
                    emit(raw_output, "sample", index=index, phase="pre", endpoint=False,
                         raw=asdict(sample), utc_ns=time.time_ns())
                    raw_emit_end = time.perf_counter_ns()
                    census = collector.collect(native.WindowsBackend(), guard, manifest["image_policy"])
                    census_return = time.perf_counter_ns()
                    # Ordinary full evidence output is inside the stricter cutoff.
                    emit(census_output, "census", index=index, census=census,
                         source_monotonic_ns=sample.monotonic_ns, census_return_ns=census_return)
                    finished = time.perf_counter_ns()
                    validation_begin = time.perf_counter_ns()
                    # Decode the actual emitted bytes: no in-memory-only replay pass.
                    written = [json.loads(line) for line in (HERE / "census-001.jsonl").read_text(encoding="utf-8").splitlines()]
                    if len(written) != index + 1 or written[-1]["index"] != index:
                        raise ValueError("actual census stream coverage differs")
                    verdict = replay.replay(written[-1]["census"], manifest["image_policy"],
                                            expected_guard=(guard[0], guard[2]),
                                            expected_observer_pid=os.getpid(), expected_job_present=False)
                    native_errors = math.sample_errors(sample, during=False)
                    samples.append(sample)
                    interval = None
                    if index:
                        interval = math.window(samples[-2], sample, during=False)
                        windows.append(interval)
                    strict_span = finished - stamp_begin
                    legacy_span = census_return - sample.monotonic_ns
                    budget_ok = 0 <= strict_span <= 50_000_000 and 0 <= legacy_span <= 50_000_000
                    case_ok = (budget_ok and census["admissible"] and verdict["record_valid"]
                               and verdict["admissible"] and not native_errors)
                    cases.append(case_ok)
                    emit(output, "sample", index=index, stamp_begin_ns=stamp_begin, stamp_end_ns=stamp_end,
                         raw_emit_end_ns=raw_emit_end, source_monotonic_ns=sample.monotonic_ns,
                         census_return_ns=census_return, finished_ns=finished,
                         strict_complete_ns=strict_span, legacy_sample_to_return_ns=legacy_span,
                         snapshot_calls=list(snapshot_calls), native_sample_errors=native_errors,
                         independent_replay=verdict, independent_validation_begin_ns=validation_begin,
                         independent_validation_end_ns=time.perf_counter_ns(), interval=interval,
                         row_count=len(census["rows"]), group_count=len(census["groups"]),
                         time_budget_pass=budget_ok, census_admissible=census["admissible"],
                         snapshot_qualified=case_ok)
                    if time.perf_counter_ns() >= deadline:
                        raise TimeoutError("35-second diagnostic deadline after sample/replay")
        except BaseException as error:
            code = 1
            emit(output, "error", type=type(error).__name__, error=str(error),
                 winerror=getattr(error, "winerror", None), evidence=getattr(error, "evidence", None),
                 partial_snapshot_calls=list(snapshot_calls))
        finally:
            native.create_snapshot = original_snapshot
            try:
                after = bindings(plan_sha)[-1]
                unchanged = before == after
            except BaseException as error:
                code, after, unchanged = 1, None, False
                emit(output, "source_error", type=type(error).__name__, error=str(error))
            if time.perf_counter_ns() >= deadline:
                code = 1
                emit(output, "deadline", stage="terminal")
            # A two-window diagnostic deliberately cannot pass twelve-window phase coverage.
            partial_verdict = math.verdict(windows, during=False)
            partial_failures = [reason for reason in partial_verdict["reasons"] if reason != "coverage"]
            partial_ok = len(windows) == 2 and not partial_failures
            emit(output, "terminal", code=code, completed=len(cases), source_sha256=after,
                 sources_unchanged=unchanged, partial_phase_verdict=partial_verdict,
                 partial_window_checks_passed=partial_ok,
                 diagnostic_pipeline_qualified=(code == 0 and unchanged and len(cases) == 3
                                                and all(cases) and partial_ok),
                 phase_qualified=False, campaign_qualified=False, benchmark_slots=0,
                 scope="diagnostic exit0 is not admission; coverage remains incomplete")
    return code


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--approved-plan-sha", required=True)
    args = parser.parse_args()
    raise SystemExit(main(args.approved_plan_sha))
