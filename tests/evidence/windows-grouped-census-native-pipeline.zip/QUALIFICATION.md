# Grouped native components passed; observer pipeline unqualified

One reviewed native component attempt passed all six fixed cases: stable data,
persistent in-place edit, growth, truncation, explicit callback refusal, and
successful pre-content-open pathname replacement. Expected refusal branches,
final bytes, actual retained process P0/P1 facts, empty Job membership, full
native identities and read/callback ordering are retained. Fixture files are
not that process's image: this is a component control, not fabricated census
proof. Handles returned170 to170, the empty Job drained0 to0 without termination,
and all six exclusive identity-owned fixtures were removed. Two independent Sol
source/plan and raw reviews plus an independent Python raw audit are recorded.

The one separately approved full observer diagnostic completed three snapshots,
not a campaign. All actual census records and strict emitted-JSON census and
telemetry replays passed consistency checks. Complete output-inclusive spans
were88.4836,82.8714,62.2483ms; original sample-to-census-return spans were87.681,
81.7326,61.1095ms. All exceeded the unchanged50ms budget. Populations differed
39/38/41rows, with4exact-path groups each. Changed observation schedules and
populations prevent a paired speedup inference against earlier per-row methods.

Two recorded windows failed physical-memory admission; the first also exceeded
observer CPU. Residual CPU estimates33.9613% and27.1331% exceeded pre-phase limits.
Only two windows exist, so twelve-window coverage remains incomplete. Exit0
means diagnostic completion; pipeline, phase and campaign qualification are all
false. Zero benchmark slots ran. No reliable comparative speed result exists.

Recorded cost decomposition is nonoverlapping: native snapshot20.142–28.414ms,
enumeration/wrapper remainder7.566–9.091ms; group work excluding member checks
18.676–35.230ms, including shared reads2.646–4.129ms. The remaining group envelope
combines native open/metadata/close and Python work; it is not an isolated API
or OS-cause measurement. Census output was0.776–1.068ms. A proposed native bulk
enumeration repair is outside this package and has no qualified result.

The independent raw audit reproduced all arithmetic and observed both original
recorded guard and observer identities absent. All sources/tool pins stayed
unchanged. Source drafts and prelaunch corrections remain preserved. Later
memory snapshots are separate diagnostic context; no runtime was reset or
process stopped. The raw CIM process records are valid, while the first derived
aggregation failed to resolve dictionary fields; the original report and exact-
record aggregation correction are retained.

No production guard guarantee/default or numeric threshold changed. The grouped
METHOD describes reduced independent observation count, transient/ABA, process
freshness and loaded-image limits. Prior failed records remain failed. Frozen013
sources and dependencies are included; its separately published protocol ZIP
contains the bound executables. INDEX.json binds every other member.
