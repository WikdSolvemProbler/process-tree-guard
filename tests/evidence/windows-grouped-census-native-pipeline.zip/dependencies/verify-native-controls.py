import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
d=root/'target/codex-security/issue7-grouped-image-native-controls-001'
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt_bytes=(d/'receipt-001.json').read_bytes(); raw_bytes=(d/'native-controls-001.jsonl').read_bytes()
assert sha(receipt_bytes)=='f91dff30512a970e7c45d37905d1556cfe1e217c8467d1bc08fe415f2a1a2a52'
assert sha(raw_bytes)=='67988ba4906a05a8fc450457be535d97b0ee64b961d66a4299bc94a2960ebaf5'
r=json.loads(receipt_bytes)
assert r['qualified'] is True and r['exit_code']==0 and r['failure'] is None
for n,p in r['artifact_sha256'].items():assert sha((d/n).read_bytes())==p,n
rows=[json.loads(x)for x in raw_bytes.splitlines()]
cases=[x for x in rows if x['kind']=='case']
expected={'stable':b'same','in_place':b'edit','growth':b'same+','truncation':b'','callback_failure':b'same','before_open_rebind':b'next'}
assert [x['case']for x in cases]==list(expected)
errors={'in_place':'image fixed read digests differ','growth':'image exceeds its initial size','truncation':'image ended before its initial size','callback_failure':'fixed member callback refusal','before_open_rebind':'image named entry differs from opened native identity'}
for row in cases:
 c=row['case']; evidence=row['evidence']
 assert row['qualified'] is True and row['fixture_absent'] is True and row['cleanup_errors']==[] and row['remaining_file_handles']==[]
 assert bytes.fromhex(row['final_bytes_hex'])==expected[c] and row['final_size']==len(expected[c]) and row['final_sha256']==sha(expected[c])
 first=row['P0']; assert first['phase']=='P0' and 0<first['created_ticks']<=row['snapshot_upper_ticks'] and first['job_member'] is False and first['alive_at_member_check'] is True
 assert [x['operation']for x in first['calls']]==['path','creation','member','alive'] and all(x['ok'] is True for x in first['calls'])
 if c=='before_open_rebind':
  assert row['callback_count']==0 and row['read_calls']==[]
  assert all(evidence['held_before'][k]==row['replacement_initial'][k] for k in ['volume','file_id_128'])
  assert evidence['named_before']==row['target_initial'] and evidence['named_before']!=evidence['held_before']
 else:
  last=row['P1']; assert row['callback_count']==1 and last['phase']=='P1'
  assert all(first[k]==last[k]for k in ['raw_image_path','created_ticks','job_member']) and last['alive_at_member_check'] is True
  assert [x['operation']for x in last['calls']]==['path','creation','member','alive'] and all(x['ok'] is True for x in last['calls'])
  assert first['end_ns']<=evidence['read_first']['begin_ns']<=evidence['read_first']['end_ns']<=evidence['member_check']['begin_ns']<=last['begin_ns']<=last['end_ns']<=evidence['member_check']['end_ns']
  assert evidence['read_first']['sha256']==sha(b'same')
 if c=='stable':
  assert row['returned'] is True and row['digest']==sha(b'same') and evidence['read_second']['sha256']==sha(b'same')
  assert all(evidence[k]==evidence['named_before']for k in ['held_before','held_after','named_after'])
 else:assert row['returned'] is False and row['error']==errors[c]
 if c=='in_place':assert evidence['read_second']['sha256']==sha(b'edit')
 if c in ['growth','truncation']:assert len(row['read_calls'])==2 and row['read_calls'][1]['error']==errors[c]
 if c=='callback_failure':assert len(row['read_calls'])==1 and 'read_second' not in evidence
terminal=[x for x in rows if x['kind']=='terminal']; assert len(terminal)==1
t=terminal[0]; assert t['qualified'] is True and t['code']==0 and t['completed_cases']==6 and t['cleanup_errors']==[]
assert t['baseline']==t['handle_count']==170 and max(x['end_ns']for x in cases)<=t['terminal_observed_ns']<t['deadline_ns']
drain=[x for x in rows if x['kind']=='empty_job_drain']; assert len(drain)==1 and drain[0]['active_before']==drain[0]['active_after']==0 and drain[0]['terminated'] is False
assert t['census_qualified'] is False and t['phase_qualified'] is False and t['campaign_qualified'] is False
print(json.dumps({'native_components_verified':6,'raw_sha256':sha(raw_bytes),'receipt_sha256':sha(receipt_bytes),'handles':[t['baseline'],t['handle_count']],'scope':'component only; no census/phase/campaign qualification'},indent=2))
