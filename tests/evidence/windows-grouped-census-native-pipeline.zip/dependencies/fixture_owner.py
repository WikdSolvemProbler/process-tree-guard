"""Fixed read-only image controls plus replacement of one owned temporary file."""
import ctypes
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
FIXED = HERE.with_name("issue7-quiet-launch-013")
EXPECTED = "8adc1aa23a2298c3adab9ca561b621e8dccca4e78e59407aea39b9b08a2b9440"
MANIFEST = "313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae"


def loaded(name, path, expected):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise RuntimeError(f"source differs before execution: {name}")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module



class OwnedFixture:
    """Exclusive ordinary scratch; uncertain identities are left untouched."""
    def __init__(self, path):
        self.path = path
        self.created = False
        self.identity = None
        self.files = {}

    @staticmethod
    def ident(path):
        value = path.lstat()
        if path.is_symlink() or getattr(value, "st_file_attributes", 0) & 0x400:
            raise ValueError("fixture reparse/symlink refused")
        return value.st_dev, value.st_ino

    def create(self):
        self.path.mkdir()  # Existing directory fails before ownership is acquired.
        self.created = True
        self.identity = self.ident(self.path)

    def check_dir(self):
        if self.identity is None or self.ident(self.path) != self.identity:
            raise ValueError("owned fixture directory identity changed")

    def check_file(self, name):
        self.check_dir()
        path = self.path / name
        if name not in self.files or self.ident(path) != self.files[name]:
            raise ValueError("owned fixture file identity changed")
        return path

    def write(self, name, data):
        self.check_dir()
        path = self.path / name
        if name in self.files:
            self.check_file(name)
            with path.open("wb") as output:
                output.write(data)
            self.check_file(name)
        else:
            with path.open("xb") as output:
                output.write(data)
            self.files[name] = self.ident(path)

    def append(self, name, data):
        path = self.check_file(name)
        with path.open("ab") as output:
            output.write(data)
        self.check_file(name)

    def replace(self, source, target):
        src, dst = self.check_file(source), self.check_file(target)
        expected = self.files[source]
        os.replace(src, dst)
        self.files.pop(source)
        self.files[target] = expected
        self.check_file(target)

    def cleanup(self):
        if not self.created:
            return []
        errors = []
        try:
            self.check_dir()
        except (OSError, ValueError) as error:
            return [f"quarantined directory: {error}"]
        for name in list(self.files):
            try:
                self.check_file(name).unlink()
                self.files.pop(name)
            except (OSError, ValueError) as error:
                errors.append(f"quarantined {name}: {error}")
        if not errors:
            try:
                self.check_dir()
                self.path.rmdir()  # Unknown entries are never removed.
            except (OSError, ValueError) as error:
                errors.append(f"quarantined directory: {error}")
        return errors


def main():
    manifest_raw = (FIXED / "manifest.json").read_bytes()
    if hashlib.sha256(manifest_raw).hexdigest() != MANIFEST:
        raise ValueError("013 manifest differs")
    manifest = json.loads(manifest_raw)
    for name, digest in manifest["file_sha256"].items():
        if hashlib.sha256((FIXED / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"013 source differs: {name}")
    loaded("image_policy", FIXED / "image_policy.py", manifest["file_sha256"]["image_policy.py"])
    image = loaded("native_image", HERE / "native_image.py", EXPECTED)
    old = loaded("old_inventory_control", FIXED / "inventory_gate.py",
                 manifest["file_sha256"]["inventory_gate.py"])
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    count_handles = kernel.GetProcessHandleCount
    count_handles.argtypes = [w.HANDLE, ctypes.POINTER(w.DWORD)]
    count_handles.restype = w.BOOL
    current_process = kernel.GetCurrentProcess
    current_process.argtypes = []
    current_process.restype = w.HANDLE

    def handles():
        value = w.DWORD()
        if not count_handles(current_process(), ctypes.byref(value)):
            raise ctypes.WinError(ctypes.get_last_error())
        return value.value

    deadline = time.perf_counter_ns() + 20_000_000_000
    code = 0
    fixture = HERE / "native-fixture-001"
    owned = OwnedFixture(fixture)
    if not fixture.resolve().is_relative_to(HERE.resolve()):
        raise ValueError("fixture escaped diagnostic directory")
    with (HERE / "native-control-001.jsonl").open("x", encoding="utf-8") as output:
        def emit(kind, **values):
            print(json.dumps({"kind": kind, **values}), file=output, flush=True)
        baseline = handles()
        emit("context", helper_sha256=EXPECTED, manifest_sha256=MANIFEST,
             scope="fixed per-row component controls, no workload process", benchmark_slots=0)
        try:
            images = {"python": manifest["tools"]["python"],
                      "guard": manifest["fingerprints"]["guard"],
                      "sysprims": manifest["fingerprints"]["sysprims"],
                      "outer_guard": manifest["tools"]["outer_guard"]}
            for name, expected in images.items():
                if time.perf_counter_ns() >= deadline:
                    raise TimeoutError("20-second native component deadline")
                path = Path(expected["path"])
                begin = time.perf_counter_ns()
                digest, evidence = image.inspect_image(path)
                end = time.perf_counter_ns()
                old_digest = old.image_digest(path)
                if digest != expected["sha256"] or old_digest != digest:
                    raise ValueError(f"pinned/native/013 digest disagreement: {name}")
                emit("image", name=name, native_elapsed_ns=end - begin,
                     evidence=evidence, old_digest=old_digest, pinned_digest=expected["sha256"])
                if time.perf_counter_ns() >= deadline:
                    raise TimeoutError("20-second deadline after pinned image comparison")
            owned.create()
            target, replacement = fixture / "target", fixture / "replacement"
            original = image.held_digest
            for mutation in ("in_place", "replacement", "growth", "truncation"):
                if time.perf_counter_ns() >= deadline:
                    raise TimeoutError("20-second native component deadline")
                owned.write("target", b"same")
                owned.write("replacement", b"next")

                read_pass = 0
                read_calls = []

                def mutate_at_read(handle, size):
                    nonlocal read_pass
                    read_pass += 1
                    event = {"pass": read_pass, "begin_ns": time.perf_counter_ns()}
                    read_calls.append(event)
                    try:
                        digest = original(handle, size)
                        event["sha256"] = digest
                    finally:
                        event["end_ns"] = time.perf_counter_ns()
                    if read_pass == 1:
                        event["mutation_begin_ns"] = time.perf_counter_ns()
                        if mutation == "truncation":
                            owned.write("target", b"")
                        elif mutation == "growth":
                            owned.append("target", b"+")
                        elif mutation == "replacement":
                            owned.replace("replacement", "target")
                        elif mutation == "in_place":
                            owned.write("target", b"edit")
                        event["mutation_end_ns"] = time.perf_counter_ns()
                    return digest
                image.held_digest = mutate_at_read
                refused = None
                refusal_evidence = None
                try:
                    image.inspect_image(target)
                except ValueError as error:
                    refused = str(error)
                    refusal_evidence = getattr(error, "evidence", None)
                finally:
                    image.held_digest = original
                if refused is None:
                    raise ValueError(f"native mutation was not refused: {mutation}")
                emit("owned_mutation", mutation=mutation, refused=True, reason=refused,
                     partial_file_evidence_available=refusal_evidence is not None,
                     refusal_evidence=refusal_evidence, read_calls=read_calls,
                     scope="only this control's temporary files were changed")
                if handles() != baseline:
                    raise ValueError("native image controls changed process handle count")
        except BaseException as error:
            code = 1
            emit("error", error=f"{type(error).__name__}: {error}")
        finally:
            cleanup_errors = owned.cleanup()
            if cleanup_errors:
                code = 1
                emit("cleanup_refused", reasons=cleanup_errors)
            if time.perf_counter_ns() >= deadline:
                code = 1
                emit("error", error="20-second deadline exceeded before terminal")
            if hashlib.sha256((HERE / "native_image.py").read_bytes()).hexdigest() != EXPECTED:
                code = 1
                emit("error", error="helper source changed")
            emit("terminal", code=code, handle_count=handles(), baseline=baseline,
                 fixture_absent=not fixture.exists(), benchmark_slots=0)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
