import hashlib,json,sys,types
from pathlib import Path
from dataclasses import asdict
root=Path(__file__).resolve().parents[2]
base=root/'target/codex-security'
p=base/'issue7-grouped-image-pipeline-001'
g=base/'issue7-grouped-image-census-001'
f=base/'issue7-quiet-launch-013'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(name,path,pin):
 raw=path.read_bytes();assert sha(raw)==pin
 module=types.ModuleType(name);module.__file__=str(path);sys.modules[name]=module
 exec(compile(raw,str(path),'exec'),module.__dict__);return module
raw=(p/'diagnostic-001.jsonl').read_bytes()
assert sha(raw)=='08a439f23f95772ad8c31ed0367f835f0b751bdbbe84104f25e7a7e1bea1029c'
rows=[json.loads(x)for x in raw.splitlines()]
context=next(x for x in rows if x['kind']=='context'); identity=next(x for x in rows if x['kind']=='identity')
terminal=next(x for x in rows if x['kind']=='terminal'); cases=[x for x in rows if x['kind']=='sample']
assert terminal['code']==0 and terminal['completed']==3 and terminal['sources_unchanged'] is True
assert terminal['diagnostic_pipeline_qualified'] is False and terminal['phase_qualified'] is False and terminal['campaign_qualified'] is False
assert terminal['source_sha256']==context['source_sha256']
math=load('quiet_gate',f/'quiet_gate.py',context['source_sha256']['013/quiet_gate.py'])
rawparser=load('telemetry_replay',f/'replay.py',context['source_sha256']['013/replay.py'])
replay=load('replay_grouped',g/'replay_grouped.py',context['source_sha256']['grouped/replay_grouped.py'])
manifest=json.loads((f/'manifest.json').read_bytes())
telemetry=[json.loads(x)for x in (p/'telemetry-001.jsonl').read_bytes().splitlines()]
census=[json.loads(x)for x in (p/'census-001.jsonl').read_bytes().splitlines()]
assert len(cases)==len(telemetry)==len(census)==3
samples=[];windows=[];spans=[]
for i,(case,t,c)in enumerate(zip(cases,telemetry,census)):
 assert case['index']==t['index']==c['index']==i
 sample=rawparser.sample_from_raw(t['raw'],False);samples.append(sample)
 assert not math.sample_errors(sample,during=False)
 result=replay.replay(c['census'],manifest['image_policy'],expected_guard=(identity['guard_pid'],identity['guard_created_ticks']),expected_observer_pid=identity['observer_pid'],expected_job_present=False)
 assert result==case['independent_replay'] and result['record_valid'] and result['admissible']
 assert case['strict_complete_ns']==case['finished_ns']-case['stamp_begin_ns']
 assert case['legacy_sample_to_return_ns']==case['census_return_ns']-sample.monotonic_ns
 assert case['strict_complete_ns']>50000000 and case['legacy_sample_to_return_ns']>50000000 and case['time_budget_pass'] is False and case['snapshot_qualified'] is False
 spans.append({'index':i,'strict_ns':case['strict_complete_ns'],'legacy_ns':case['legacy_sample_to_return_ns'],'rows':len(c['census']['rows']),'groups':len(c['census']['groups']),'available_bytes':sample.available_bytes})
 if i:
  win=math.window(samples[-2],sample,during=False);assert win==case['interval'];windows.append(win)
assert math.verdict(windows,during=False)==terminal['partial_phase_verdict']
native=load('identity_native',g/'native_processes.py',context['source_sha256']['grouped/native_processes.py'])
identities=[]
for role,pid,created in [('observer',identity['observer_pid'],identity['observer_created_ticks']),('guard',identity['guard_pid'],identity['guard_created_ticks'])]:
 try:
  with native.open_exact(pid)as handle:
   found=native.WindowsBackend.creation(handle);alive=native.WindowsBackend.alive(handle)
   assert found!=created or not alive,'original identity still running'
   identities.append({'role':role,'pid':pid,'expected_created_ticks':created,'opened_created_ticks':found,'alive_at_check':alive,'original_identity_running':False})
 except OSError as error:
  assert error.winerror==87,error
  identities.append({'role':role,'pid':pid,'expected_created_ticks':created,'open_winerror':87,'original_identity_absent':True})
result={'schema':1,'diagnostic_raw_sha256':sha(raw),'independent_raw_replay':'passed','samples':spans,'windows':windows,'partial_verdict':terminal['partial_phase_verdict'],'benchmark_slots':0,'pipeline_qualified':False,'exact_identity_checks':identities,'scope':'Independent raw replay and original observer/guard identity checks; failed admission remains failed; no speed comparison'}
out=p/'independent-audit-001.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
