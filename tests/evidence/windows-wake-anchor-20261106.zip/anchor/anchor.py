"""Build the anchor derivative from exact, hash-pinned directional sources."""

import base64
import hashlib
import json
from pathlib import Path
from types import ModuleType

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE.with_name("wake-msvc-driver-dev-001")
FROZEN = {
    "capture.py": "9b2586e765222da108d726e8ae1702fb413810046ed1a0c78436ae00e50f9fff",
    "analysis.py": "4a1707fb42ccfa84151bbd2cb6f01d5cacda2eb7240d8c082711bb1d681cba53",
    "schedule.py": "2f80bcc0ca933f216b0477545bb1b81d71ef4783b9e904d9728616e89bc169ba",
    "qualify-suspended.py": "e11cd48dce9f4b3612323f870dd539bdf7c5fc8ffc643a879410151bb0695523",
    "schedule-review.json": "4731f889ee1aa0a355eec5802679307e5307eedb44d9e7a1fdaefec358f1016c",
    "capture-manifest-operational-003.json": "c980b1ebd3407baee2852d3f6e9fc4db2d883887a5690547b9efca4e311d2118",
}
STRATUM = ("manual", "startup")
ROW_COUNT = 807
PROTOCOL_SHA = "86817439a69fd4123b82f6819ca6c737e09ead9874fbdadc6e89628bd1c01f82"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def pinned(path, digest):
    raw = path.read_bytes()
    require(sha(raw) == digest, f"pinned input changed: {path}")
    return raw


def original(name):
    return pinned(ORIGINAL / name, FROZEN[name])


def load(name, path, source, **bindings):
    module = ModuleType(name)
    module.__dict__.update(__file__=str(path), **bindings)
    exec(compile(source, str(path), "exec"), module.__dict__)
    return module


def replace_once(source, old, new):
    require(source.count(old) == 1, f"frozen source seam differs: {old}")
    return source.replace(old, new, 1)


SCHEDULE = load("anchor_original_schedule", ORIGINAL / "schedule.py", original("schedule.py"))
ORIGINAL_PLAN = original("schedule-review.json")
ORIGINAL_MANIFEST = json.loads(original("capture-manifest-operational-003.json"))


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def project_schedule(raw):
    source = json.loads(raw)
    require(raw == SCHEDULE.schedule_bytes(source["seed_hex"]), "source schedule is not canonical")
    rows = []
    for row in source["rows"]:
        if row["phase"] == "measured" and (row["mode"], row["workload"]) != STRATUM:
            continue
        rows.append(dict(row, index=len(rows), source_index=row["index"]))
    require(len(rows) == ROW_COUNT, "projected row population mismatch")
    return json_bytes(dict(schema=1, seed_hex=source["seed_hex"], source_sha256=sha(raw), rows=rows))


def projected_schedule(seed):
    require(seed == json.loads(ORIGINAL_PLAN)["seed_hex"], "anchor must use the frozen seed")
    return project_schedule(ORIGINAL_PLAN)


def analysis_module(*, synthetic=False):
    source = original("analysis.py").decode("utf-8")
    for old, new in (
        ('STRATA = tuple((mode, workload) for mode in schedule.MODES for workload in schedule.WORKLOADS)',
         'STRATA = (ANCHOR_STRATUM,)'),
        ('schedule.schedule_bytes(plan["seed_hex"]) == schedule_raw',
         'projected_schedule(plan["seed_hex"]) == schedule_raw'),
        ('len(rows) == len(plan["rows"]) == 2967', 'len(rows) == len(plan["rows"]) == ANCHOR_ROWS'),
        ('sha(Path(__file__).read_bytes())', 'ANCHOR_SHA'),
    ):
        # The digest expression also occurs in the original synthetic fixture.
        if old == 'sha(Path(__file__).read_bytes())':
            require(source.count(old) == 2, "analysis digest seams differ")
            source = source.replace(old, new)
        else:
            source = replace_once(source, old, new)
    if synthetic:
        for old, new in (
            ('schedule_raw = schedule.schedule_bytes(seed)', 'schedule_raw = project_schedule(schedule.schedule_bytes(seed))'),
            ('len(results) == 16', 'len(results) == 4'),
            ('    capture["rows"][5]["wait"]["process_handle"] = 6',
             '    probe(schedule_raw, manifest_raw, capture)\n    capture["rows"][5]["wait"]["process_handle"] = 6'),
        ):
            source = replace_once(source, old, new)
    return load("anchor_analysis", ORIGINAL / "analysis.py", source,
                ANCHOR_STRATUM=STRATUM, ANCHOR_ROWS=ROW_COUNT, ANCHOR_SHA=sha(Path(__file__).read_bytes()),
                project_schedule=project_schedule, projected_schedule=(lambda seed: project_schedule(SCHEDULE.schedule_bytes(seed))) if synthetic else projected_schedule)


def operational_bindings(manifest):
    bindings = {
        f"frozen:{name}": {"path": str(ORIGINAL / name), "sha256": digest}
        for name, digest in FROZEN.items()
    }
    bindings.update({
        "protocol": {"path": str(HERE / "PROTOCOL.md"), "sha256": PROTOCOL_SHA},
        "replay": {"path": str(HERE / "verify.py"), "sha256": manifest["replay_sha256"]},
        "controller_shell": ORIGINAL_MANIFEST["launch_recipe"]["bootstrap"]["shell"],
        "controller_bootstrap_guard": {
            "path": ORIGINAL_MANIFEST["launch_recipe"]["bootstrap"]["guard"]["path"],
            "sha256": ORIGINAL_MANIFEST["launch_recipe"]["bootstrap"]["guard"]["sha256"],
        },
    })
    bindings["controller_shell"] = {
        key: bindings["controller_shell"][key] for key in ("path", "sha256")
    }
    for label, binding in manifest["qualification_receipts"].items():
        bindings[f"qualification:{label}"] = binding
    bindings["original_environment_recipe_proof"] = ORIGINAL_MANIFEST["environment_recipe_proof"]
    for role in ("controller", "receipt", "input_manifest"):
        bindings[f"original_integrated_preflight:{role}"] = ORIGINAL_MANIFEST["integrated_preflight"][role]
    bindings["ancestry_probe"] = {"path": str(HERE / "qualify-ancestry.py"),
                                  "sha256": manifest["ancestry_probe_sha256"]}
    return bindings


def verify_manifest(manifest, args):
    for key in (
        "schema", "candidate_commits", "suspended_sha256", "schedule_generator_sha256", "python_sha256",
        "arm_sha256", "control_ids", "cwd", "assets", "child_environment_sha256", "environment_binding",
        "telemetry", "launch",
    ):
        require(manifest.get(key) == ORIGINAL_MANIFEST[key], f"changed frozen field: {key}")
    require(manifest.get("protocol_sha256") == PROTOCOL_SHA, "protocol digest mismatch")
    require(manifest.get("original_manifest_sha256") == FROZEN["capture-manifest-operational-003.json"],
            "original manifest binding mismatch")
    require(manifest.get("original_schedule_sha256") == FROZEN["schedule-review.json"],
            "original schedule binding mismatch")
    require(manifest["schedule"]["path"] == str(args.schedule.resolve()), "schedule path mismatch")
    require(manifest["output_path"] == str(args.out.resolve()), "output path mismatch")
    require(manifest["bootstrap"] == ORIGINAL_MANIFEST["launch_recipe"]["bootstrap"], "bootstrap changed")
    qualification = manifest["qualification_receipts"]
    for name, binding in ORIGINAL_MANIFEST["qualification_receipts"].items():
        if name != "ancestry":
            require(qualification.get(name) == binding, f"changed qualification: {name}")
    require(manifest["launcher_process_precommand"] == ORIGINAL_MANIFEST["launch_recipe"]["launcher_process_precommand"],
            "launcher environment reset changed")
    require(manifest["launcher_recipe_path"] == str(HERE / "launcher-recipe.json"), "recipe path changed")
    pinned(HERE / "PROTOCOL.md", PROTOCOL_SHA)
    controller_expected(manifest, args)


def controller_expected(manifest, args):
    template = manifest["controller_argv_template"]
    require(len(template) == 15, "controller template length mismatch")
    require(template == [
        ORIGINAL_MANIFEST["launch_recipe"]["controller_argv_template"][0],
        "-B", str(HERE / "capture.py"), "--manifest", str(args.manifest.resolve()),
        "--manifest-sha256", "<manifest-sha256>", "--schedule", str(args.schedule.resolve()),
        "--admission", str(args.admission.resolve()), "--admission-sha256", "<admission-sha256>",
        "--out", str(args.out.resolve()),
    ], "controller template differs from frozen recipe")
    substitutions = {"<manifest-sha256>": args.manifest_sha256, "<admission-sha256>": args.admission_sha256}
    return [substitutions.get(arg, arg) for arg in template]


def launcher_recipe(manifest, args):
    controller = controller_expected(manifest, args)
    controller[12] = "<admission-sha256>"
    launch = manifest["launch"]
    root = [launch["root_path"], "--timeout", str(launch["root_seconds"]), "--", *controller]
    backup = [launch["backup_path"], "--timeout", str(launch["backup_seconds"]), "--", *root]
    bootstrap = manifest["bootstrap"]
    quoted = " ".join("'" + arg.replace("'", "''") + "'" for arg in backup)
    command = manifest["launcher_process_precommand"] + "; & " + quoted + "; exit $LASTEXITCODE"
    return dict(
        schema=1, state="EXACT_RECIPE_FOR_INDEPENDENT_REVIEW",
        manifest_path=str(args.manifest.resolve()), manifest_sha256=args.manifest_sha256,
        admission_path=str(args.admission.resolve()), admission_digest_placeholder="<admission-sha256>",
        working_directory=str(HERE.parents[2]), output_path=str(args.out.resolve()),
        terminal_receipt_path=str(args.out.resolve().with_name(args.out.name + "-terminal.json")),
        controller_argv_template=controller, root_argv_template=root, backup_argv_template=backup,
        bootstrap_argv_prefix=[
            bootstrap["guard"]["path"], "--timeout", str(bootstrap["timeout_seconds"]), "--",
            bootstrap["shell"]["path"], "-NoProfile", "-NonInteractive", "-EncodedCommand",
        ],
        powershell_text_template=command,
        transport="UTF-16LE without BOM, then standard Base64",
        deadline_chain_seconds=[bootstrap["timeout_seconds"], launch["backup_seconds"], launch["root_seconds"]],
        root_reserve_seconds=launch["reserve_seconds"], fixture_deadline_seconds=2,
        row_watchdog_seconds={"startup": 3, "control": 3, "wait50_warmup": 10},
    )


def verify_launcher_admission(analysis, manifest, args):
    raw = args.admission.read_bytes()
    analysis.verify_admission(raw, args.admission_sha256, args.manifest_sha256)
    admission = analysis.parse(raw)
    digest = admission.get("launcher_recipe_sha256")
    require(analysis.valid_sha(digest), "admission lacks exact launcher recipe digest")
    expected = launcher_recipe(manifest, args)
    recipe_raw = pinned(Path(manifest["launcher_recipe_path"]), digest)
    require(recipe_raw == json_bytes(expected), "launcher recipe differs from exact derivation")
    require(all(row.get("manifest_sha256") == args.manifest_sha256 and
                row.get("launcher_recipe_sha256") == digest for row in admission["critics"]),
            "each reviewer must bind the exact manifest and launcher recipe")
    return expected, digest


def rendered_launcher(recipe, admission_digest):
    placeholder = recipe["admission_digest_placeholder"]
    template = recipe["powershell_text_template"]
    require(template.count(placeholder) == 1, "launcher substitution count differs")
    command = template.replace(placeholder, admission_digest)
    encoded = base64.b64encode(command.encode("utf-16-le")).decode("ascii")
    return [*recipe["bootstrap_argv_prefix"], encoded]


def capture_module():
    entry = HERE / "capture.py"
    source = original("capture.py").decode("utf-8")
    for old, new in (
        ('SUSPENDED = HERE / "qualify-suspended.py"', 'SUSPENDED = ORIGINAL / "qualify-suspended.py"'),
        ('A, ANALYSIS_SHA = load_source("capture_analysis", HERE / "analysis.py")',
         'A, ANALYSIS_SHA = anchor_analysis(), hash_anchor()'),
        ('"analysis": (HERE / "analysis.py", "analysis_sha256")',
         '"analysis": (HERE / "anchor.py", "analysis_sha256")'),
        ('"schedule_generator": (HERE / "schedule.py", "schedule_generator_sha256")',
         '"schedule_generator": (ORIGINAL / "schedule.py", "schedule_generator_sha256")'),
        ('    return bindings\n\n\nclass RuntimeHold:',
         '    bindings.update(operational_bindings(manifest))\n    return bindings\n\n\nclass RuntimeHold:'),
        ('schedule.schedule_bytes(plan["seed_hex"]) == raw_plan', 'projected_schedule(plan["seed_hex"]) == raw_plan'),
        ('    return manifest, plan\n', '    verify_anchor_manifest(manifest, args)\n    verify_launcher_admission(A, manifest, args)\n    return manifest, plan\n'),
        ('        capture["controller_argv"] = controller_argv()',
         '        capture["controller_argv"] = controller_argv()\n'
         '        A.require(capture["controller_argv"] == controller_expected(manifest, args), "controller argv differs from freeze")'),
    ):
        source = replace_once(source, old, new)
    return load("anchor_capture", entry, source, ORIGINAL=ORIGINAL, anchor_analysis=analysis_module,
                hash_anchor=lambda: sha(Path(__file__).read_bytes()), operational_bindings=operational_bindings,
                projected_schedule=projected_schedule, verify_anchor_manifest=verify_manifest,
                controller_expected=controller_expected, verify_launcher_admission=verify_launcher_admission)


def anchor_result(analysis, data, host_reasons):
    endpoint = next(row for row in analysis.summarize(data, host_reasons, analysis.REPLICATES)
                    if row["endpoint"] == "raw_q90")
    arms = {arm: sorted(values[arm] for block in data[STRATUM] for _, values in block)
            for arm in SCHEDULE.ARMS}
    quantiles = {
        arm: {f"p{p * 10}_ns": values[analysis.nearest_rank(len(values), p, 10) - 1] for p in (5, 9)}
        for arm, values in arms.items()
    }
    signs = [*endpoint["half_estimate_ns"], *endpoint["permutation_estimate_ns"].values()]
    directional = endpoint["verdict"] == "slower"
    calibrated = directional and 3_907_900 <= endpoint["estimate_ns"] <= 11_907_900 and all(v > 0 for v in signs)
    return dict(endpoint=endpoint, quantiles=quantiles, directional_replication=directional, anchor_calibrated=calibrated)

