"""Prepare a draft manifest and verify held asset identities without launching a workload."""

from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace

from hashlib import sha256
from pathlib import Path
from types import ModuleType


_anchor_path = Path(__file__).resolve().with_name("anchor.py")
_anchor_source = _anchor_path.read_bytes()
if sha256(_anchor_source).hexdigest() != "1cab369473a605379296f15aab5aa6535d5b1b36430b67969dce0ded6c305ba2":
    raise ValueError("anchor source digest mismatch")
_anchor = ModuleType("pinned_anchor")
_anchor.__file__ = str(_anchor_path)
exec(compile(_anchor_source, str(_anchor_path), "exec"), _anchor.__dict__)

FROZEN = _anchor.FROZEN
HERE = _anchor.HERE
ORIGINAL_MANIFEST = _anchor.ORIGINAL_MANIFEST
ORIGINAL_PLAN = _anchor.ORIGINAL_PLAN
PROTOCOL_SHA = _anchor.PROTOCOL_SHA
capture_module = _anchor.capture_module
json_bytes = _anchor.json_bytes
launcher_recipe = _anchor.launcher_recipe
pinned = _anchor.pinned
project_schedule = _anchor.project_schedule
require = _anchor.require
sha = _anchor.sha
verify_manifest = _anchor.verify_manifest


def digest(path):
    return sha(path.read_bytes())


def main():
    manifest_path = HERE / "manifest.draft.json"
    schedule_path = HERE / "schedule.json"
    admission_path = HERE / "admission.json"
    output_path = HERE / "capture-001"
    require(not admission_path.exists() and not output_path.exists(), "use an unadmitted draft namespace")
    schedule = project_schedule(ORIGINAL_PLAN)
    pinned(schedule_path, sha(schedule))
    driver = capture_module()
    ancestry = HERE / "ancestry-002.json"
    receipt = driver.A.parse(ancestry.read_bytes())
    driver_sha = digest(HERE / "capture.py")
    require(receipt["passed"] is True and receipt["capture_driver_sha256"] == driver_sha,
            "anchor ancestry qualification missing")
    frozen = ORIGINAL_MANIFEST
    manifest = {key: deepcopy(frozen[key]) for key in (
        "schema", "candidate_commits", "suspended_sha256", "schedule_generator_sha256", "python_sha256",
        "arm_sha256", "control_ids", "cwd", "assets", "qualification_receipts", "child_environment_sha256",
        "environment_binding", "telemetry", "launch",
    )}
    manifest["qualification_receipts"]["ancestry"] = {"path": str(ancestry), "sha256": digest(ancestry)}
    manifest.update(
        state="DRAFT_FOR_INDEPENDENT_REVIEW_NOT_ADMITTED", timed_capture_authorized=False,
        scope="single standalone manual-startup anchor under observed laptop load",
        protocol_sha256=PROTOCOL_SHA, original_manifest_sha256=FROZEN["capture-manifest-operational-003.json"],
        original_schedule_sha256=FROZEN["schedule-review.json"],
        driver_sha256=driver_sha, analysis_sha256=digest(HERE / "anchor.py"),
        replay_sha256=digest(HERE / "verify.py"), ancestry_probe_sha256=digest(HERE / "qualify-ancestry.py"),
        schedule_sha256=sha(schedule), schedule={"path": str(schedule_path),
            "phase_counts": {"control": 15, "warmup": 72, "measured": 720}},
        launcher_recipe_path=str(HERE / "launcher-recipe.json"), output_path=str(output_path), bootstrap=frozen["launch_recipe"]["bootstrap"],
        launcher_process_precommand=frozen["launch_recipe"]["launcher_process_precommand"],
        controller_argv_template=[
            frozen["launch_recipe"]["controller_argv_template"][0], "-B", str(HERE / "capture.py"),
            "--manifest", str(manifest_path), "--manifest-sha256", "<manifest-sha256>",
            "--schedule", str(schedule_path), "--admission", str(admission_path),
            "--admission-sha256", "<admission-sha256>", "--out", str(output_path),
        ],
    )
    manifest["runtime_hold_bindings"] = driver.runtime_hold_bindings(manifest)
    manifest_raw = json_bytes(manifest)
    args = SimpleNamespace(manifest=manifest_path, manifest_sha256=sha(manifest_raw), schedule=schedule_path,
                           admission=admission_path, admission_sha256="0" * 64, out=output_path)
    verify_manifest(manifest, args)
    suspended = driver.load_suspended(manifest["suspended_sha256"])
    support = suspended.load("support")
    require(driver.qualification_receipts(manifest, suspended, support.OUTER_SHA) ==
            manifest["qualification_receipts"], "native qualification set differs")
    hold = driver.RuntimeHold(manifest["runtime_hold_bindings"])
    with hold.resources:
        held = {"share_mode": "FILE_SHARE_READ", "before": hold.acquire(), "after": hold.verify()}
        driver.A.verify_asset_holds(manifest, {"asset_hold": held})
    with manifest_path.open("xb") as handle:
        handle.write(manifest_raw)
    recipe = json_bytes(launcher_recipe(manifest, args))
    with Path(manifest["launcher_recipe_path"]).open("xb") as handle:
        handle.write(recipe)
    print(f"Launcher recipe SHA-256 {sha(recipe)}")
    print(f"Draft manifest SHA-256 {sha(manifest_raw)} ({len(held['before'])} verified held inputs)")


if __name__ == "__main__":
    main()
