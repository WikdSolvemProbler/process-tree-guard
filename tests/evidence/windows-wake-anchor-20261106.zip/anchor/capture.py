"""Run the explicitly admitted standalone anchor capture."""
import sys

from hashlib import sha256
from pathlib import Path
from types import ModuleType


_anchor_path = Path(__file__).resolve().with_name("anchor.py")
_anchor_source = _anchor_path.read_bytes()
if sha256(_anchor_source).hexdigest() != "1cab369473a605379296f15aab5aa6535d5b1b36430b67969dce0ded6c305ba2":
    raise ValueError("anchor source digest mismatch")
_anchor = ModuleType("pinned_anchor")
_anchor.__file__ = str(_anchor_path)
exec(compile(_anchor_source, str(_anchor_path), "exec"), _anchor.__dict__)


if __name__ == "__main__":
    sys.exit(_anchor.capture_module().main())
