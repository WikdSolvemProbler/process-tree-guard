"""Prepare or verify anchor evidence without launching any workload."""

import argparse
from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from hashlib import sha256
from pathlib import Path
from types import ModuleType


_anchor_path = Path(__file__).resolve().with_name("anchor.py")
_anchor_source = _anchor_path.read_bytes()
if sha256(_anchor_source).hexdigest() != "1cab369473a605379296f15aab5aa6535d5b1b36430b67969dce0ded6c305ba2":
    raise ValueError("anchor source digest mismatch")
_anchor = ModuleType("pinned_anchor")
_anchor.__file__ = str(_anchor_path)
exec(compile(_anchor_source, str(_anchor_path), "exec"), _anchor.__dict__)

HERE = _anchor.HERE
ORIGINAL = _anchor.ORIGINAL
ORIGINAL_PLAN = _anchor.ORIGINAL_PLAN
ROW_COUNT = _anchor.ROW_COUNT
STRATUM = _anchor.STRATUM
analysis_module = _anchor.analysis_module
anchor_result = _anchor.anchor_result
capture_module = _anchor.capture_module
controller_expected = _anchor.controller_expected
json_bytes = _anchor.json_bytes
load = _anchor.load
original = _anchor.original
pinned = _anchor.pinned
project_schedule = _anchor.project_schedule
require = _anchor.require
sha = _anchor.sha
verify_manifest = _anchor.verify_manifest

HISTORICAL = {
    "capture-admission-002.json": "9dbb2bbc3c250a14c97f46c6bd48ce603c0377673ccd50e1c0b557fc678771e7",
    "directional-capture-002/capture.json": "d92ccdb12c51eadc703674d1f1758f09d71624f12b5cedd5b4968ee5667d0258",
    "analysis-002.json": "5f8186357f43872f82bbce7a7c9f2b7c97f23a1d322b3f8c829ddf946012931e",
}


def check_rejection(fn, expected):
    try:
        fn()
    except ValueError as error:
        require(expected in str(error), f"unexpected rejection: {error}")
    else:
        raise ValueError(f"unexpected acceptance: {expected}")


def synthetic():
    a = analysis_module(synthetic=True)
    checks = []

    def probe(schedule, manifest, capture):
        def reject(name, expected, mutate):
            altered = deepcopy(capture)
            mutate(altered)
            check_rejection(lambda: a.validate(schedule, manifest, sha(manifest), altered), expected)
            checks.append(name)

        reject("missing-row", "row population mismatch", lambda c: c["rows"].pop())
        reject("source-index", "differs from the exact plan",
               lambda c: c["rows"][77]["scheduled"].update(source_index=-1))
        reject("launch-order", "differs from the exact plan",
               lambda c: c["rows"].__setitem__(slice(77, 79), c["rows"][77:79][::-1]))
        reject("failed-control", "control native exit mismatch",
               lambda c: c["rows"][1]["root_before_cleanup"].update(exit_code_u32=0))
        reject("changed-arm-digest", "arm digest mismatch",
               lambda c: c["rows"][77].update(arm_sha256="0" * 64))
        reject("host-time-order", "telemetry counters moved backwards", lambda c: c["telemetry"][1].update(monotonic_ns=1))
        reject("host-flag-mismatch", "host flags disagree",
               lambda c: c["host_stability"].update(suspend_resume=True))

    a.probe = probe
    a.self_check()
    checks.append("frozen-synthetic-oracles")
    original_bootstrap = a.bootstrap
    original_point = a.point
    a.bootstrap = lambda data, points, length, repeats: {
        STRATUM: [(1, 2) if length != 8 else (-1, 2)] * 4
    }
    blocks = [[(order, dict(main=108, wake=100, bare=50)) for order in a.schedule.PERMUTATIONS]
              for _ in range(40)]
    result = a.summarize({STRATUM: blocks}, [], 2)[1]
    require(result["reasons"] == ["block_length_classification_differs"], "L8 conflict not rejected")
    checks.append("l8-disagreement")
    a.bootstrap = lambda *_: {STRATUM: [(1, 2)] * 4}
    a.point = lambda trips: [-1] * 4 if len(trips) == 120 else original_point(trips)
    result = a.summarize({STRATUM: blocks}, [], 2)[1]
    require(result["reasons"] == ["opposite_half_or_permutation_sign"], "half conflict not rejected")
    checks.append("half-sign")
    a.bootstrap, a.point = original_bootstrap, original_point

    # Exercise the original terminal file-hold validator with a changed digest.
    before = dict(path="test", final_path="test", sha256="1" * 64, volume=1, file_id=1, size=1)
    manifest = dict(runtime_hold_bindings={"fixture": dict(path="test", sha256="2" * 64)})
    held = dict(asset_hold=dict(share_mode="FILE_SHARE_READ", before={"fixture": before},
                               after={"fixture": dict(held=before, reopened_path=before)}))
    check_rejection(lambda: a.verify_asset_holds(manifest, held), "held bytes or identity mismatch")
    checks.append("changed-held-asset")
    capture_module()
    checks.extend(check_synthetic_recipe(a))
    return checks


def check_synthetic_recipe(a):
    # The synthetic envelope is confined to a disposable folder and never used by capture.py.
    with TemporaryDirectory(prefix="anchor-recipe-synthetic-") as folder:
        path = Path(folder)
        draft = _anchor.ORIGINAL_MANIFEST
        args = SimpleNamespace(manifest=path / "fake-manifest", manifest_sha256="1" * 64,
                               schedule=path / "fake-schedule", admission=path / "fake-admission",
                               admission_sha256="0" * 64, out=path / "fake-output")
        recipe_path = path / "recipe.json"
        manifest = dict(
            launch=draft["launch"], bootstrap=draft["launch_recipe"]["bootstrap"],
            launcher_process_precommand=draft["launch_recipe"]["launcher_process_precommand"],
            launcher_recipe_path=str(recipe_path),
            controller_argv_template=[
                draft["launch_recipe"]["controller_argv_template"][0], "-B", str(HERE / "capture.py"),
                "--manifest", str(args.manifest), "--manifest-sha256", "<manifest-sha256>",
                "--schedule", str(args.schedule), "--admission", str(args.admission),
                "--admission-sha256", "<admission-sha256>", "--out", str(args.out),
            ],
        )
        recipe = _anchor.launcher_recipe(manifest, args)
        recipe_raw = json_bytes(recipe)
        recipe_digest = sha(recipe_raw)
        recipe_path.write_bytes(recipe_raw)
        envelope = dict(manifest_sha256=args.manifest_sha256, launcher_recipe_sha256=recipe_digest,
                        timed_capture_authorized=True, critics=[
                            dict(reviewer=f"synthetic-{i}", objections=[], manifest_sha256=args.manifest_sha256,
                                 launcher_recipe_sha256=recipe_digest) for i in (0, 1)])
        def verify():
            raw = json_bytes(envelope)
            args.admission.write_bytes(raw)
            args.admission_sha256 = sha(raw)
            return _anchor.verify_launcher_admission(a, manifest, args)
        require(verify() == (recipe, recipe_digest), "valid synthetic recipe rejected")
        require(len(_anchor.rendered_launcher(recipe, args.admission_sha256)) == 9,
                "encoded launcher vector length differs")
        envelope["critics"][0]["launcher_recipe_sha256"] = "0" * 64
        check_rejection(verify, "each reviewer must bind")
        envelope["critics"][0]["launcher_recipe_sha256"] = recipe_digest
        recipe_path.write_bytes(recipe_raw + b"\n")
        check_rejection(verify, "pinned input changed")
    return ["exact-synthetic-recipe", "reviewer-recipe-binding", "changed-recipe-bytes"]


def check_historical():
    old = load("frozen_directional_analysis", ORIGINAL / "analysis.py", original("analysis.py"))
    manifest_raw = original("capture-manifest-operational-003.json")
    manifest_sha = sha(manifest_raw)
    manifest = old.parse(manifest_raw)
    admission = "capture-admission-002.json"
    old.verify_admission(pinned(ORIGINAL / admission, HISTORICAL[admission]), HISTORICAL[admission], manifest_sha)
    capture_path = "directional-capture-002/capture.json"
    capture = old.parse(pinned(ORIGINAL / capture_path, HISTORICAL[capture_path]))
    require(capture["admission_sha256"] == HISTORICAL[admission], "historical admission binding differs")
    old.verify_outer_receipt(manifest, capture)
    old.verify_asset_holds(manifest, capture)
    require(capture["qualification_receipts"] == manifest["qualification_receipts"],
            "historical qualification bindings differ")
    for binding in manifest["qualification_receipts"].values():
        pinned(Path(binding["path"]), binding["sha256"])
    data, host_reasons = old.validate(ORIGINAL_PLAN, manifest_raw, manifest_sha, capture)
    old.verify_raw_rows((ORIGINAL / capture_path).parent, capture["rows"])
    published = old.parse(pinned(ORIGINAL / "analysis-002.json", HISTORICAL["analysis-002.json"]))
    expected = next(row for row in published["endpoints"]
                    if (row["mode"], row["workload"]) == STRATUM and row["endpoint"] == "raw_q90")
    result = anchor_result(analysis_module(), {STRATUM: data[STRATUM]}, host_reasons)
    require(json_bytes(expected) == json_bytes(result["endpoint"]), "historical endpoint did not reproduce")
    return result


def replay(args):
    a = analysis_module()
    driver = capture_module()
    manifest_raw = pinned(args.manifest, args.manifest_sha256)
    manifest = a.parse(manifest_raw)
    raw = pinned(args.capture, args.capture_sha256)
    capture = a.parse(raw)
    output_path = Path(capture["output_directory"])
    require(capture["admission_sha256"] == args.admission_sha256, "capture admission receipt mismatch")
    launch_args = SimpleNamespace(manifest=args.manifest, manifest_sha256=args.manifest_sha256,
                                  schedule=args.schedule, admission=args.admission,
                                  admission_sha256=args.admission_sha256, out=output_path)
    verify_manifest(manifest, launch_args)
    _, recipe_digest = _anchor.verify_launcher_admission(a, manifest, launch_args)
    require(capture["controller_argv"] == controller_expected(manifest, launch_args),
            "controller argv differs from freeze")
    require(manifest["runtime_hold_bindings"] == driver.runtime_hold_bindings(manifest), "runtime hold plan differs")
    for binding in manifest["runtime_hold_bindings"].values():
        pinned(Path(binding["path"]), binding["sha256"])
    a.verify_outer_receipt(manifest, capture)
    a.verify_asset_holds(manifest, capture)
    require(capture["qualification_receipts"] == manifest["qualification_receipts"],
            "capture qualification bindings differ")
    data, host_reasons = a.validate(args.schedule.read_bytes(), manifest_raw, args.manifest_sha256, capture)
    require(not host_reasons, "host stability gate failed")
    a.verify_raw_rows(args.capture.resolve().parent, capture["rows"])
    return dict(schema=1, scope="standalone observed-load laptop anchor", capture_sha256=args.capture_sha256,
                admission_sha256=args.admission_sha256, manifest_sha256=args.manifest_sha256,
                schedule_sha256=manifest["schedule_sha256"], launcher_recipe_sha256=recipe_digest,
                **anchor_result(a, data, host_reasons))


def launch_check(args):
    """Return the sole approved argv for an external bounded launcher. Never execute it."""
    a = analysis_module()
    manifest = a.parse(pinned(args.manifest, args.manifest_sha256))
    verify_manifest(manifest, args)
    require(not args.out.exists(), "capture output namespace already exists")
    recipe, digest = _anchor.verify_launcher_admission(a, manifest, args)
    require(not Path(recipe["terminal_receipt_path"]).exists(), "terminal receipt namespace already exists")
    return dict(launcher_recipe_sha256=digest, working_directory=recipe["working_directory"],
                terminal_receipt_path=recipe["terminal_receipt_path"],
                argv=_anchor.rendered_launcher(recipe, args.admission_sha256))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("schedule", "qualify", "replay"):
        command = commands.add_parser(name)
        command.add_argument("--out", type=Path, required=True)
    command = commands.choices["replay"]
    for name in ("manifest", "schedule", "admission", "capture"):
        command.add_argument(f"--{name}", type=Path, required=True)
        if name != "schedule":
            command.add_argument(f"--{name}-sha256", required=True)
    command = commands.add_parser("launch-check")
    for name in ("manifest", "schedule", "admission", "out"):
        command.add_argument(f"--{name}", type=Path, required=True)
    for name in ("manifest", "admission"):
        command.add_argument(f"--{name}-sha256", required=True)
    args = parser.parse_args()
    if args.command == "launch-check":
        print(json_bytes(launch_check(args)).decode("utf-8"), end="")
        return
    if args.command == "schedule":
        output = project_schedule(ORIGINAL_PLAN)
    elif args.command == "qualify":
        schedule = project_schedule(ORIGINAL_PLAN)
        require(len(json.loads(schedule)["rows"]) == ROW_COUNT, "anchor row count differs")
        output = json_bytes(dict(schema=1, purpose="offline and synthetic qualification only",
                                 schedule_sha256=sha(schedule), synthetic=synthetic(),
                                 historical=check_historical()))
    else:
        output = json_bytes(replay(args))
    with args.out.open("xb") as stream:
        stream.write(output)


if __name__ == "__main__":
    main()
