"""Run the original synthetic ancestry probe against the anchor driver."""

import sys

from hashlib import sha256
from pathlib import Path
from types import ModuleType


_anchor_path = Path(__file__).resolve().with_name("anchor.py")
_anchor_source = _anchor_path.read_bytes()
if sha256(_anchor_source).hexdigest() != "1cab369473a605379296f15aab5aa6535d5b1b36430b67969dce0ded6c305ba2":
    raise ValueError("anchor source digest mismatch")
_anchor = ModuleType("pinned_anchor")
_anchor.__file__ = str(_anchor_path)
exec(compile(_anchor_source, str(_anchor_path), "exec"), _anchor.__dict__)

HERE = _anchor.HERE
ORIGINAL = _anchor.ORIGINAL
capture_module = _anchor.capture_module
load = _anchor.load
pinned = _anchor.pinned
replace_once = _anchor.replace_once

SOURCE_SHA = "904165003d2ec290e55891010fec75b2503822ca11f8d3e8815221a6f4eff98c"


if __name__ == "__main__":
    source = pinned(ORIGINAL / "qualify-ancestry.py", SOURCE_SHA).decode("utf-8")
    start = source.index("_capture_path =")
    end = source.index("\n\nGUARD =", start)
    source = replace_once(source, source[start:end], "capture = capture_module()\n")
    probe = load("anchor_ancestry_probe", HERE / "qualify-ancestry.py", source, capture_module=capture_module)
    sys.exit(probe.main())
