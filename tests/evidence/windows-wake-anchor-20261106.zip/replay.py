"""Verify and replay the frozen standalone anchor analysis on Windows."""

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify_inventory():
    actual = set()
    for line in (HERE / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        path = (HERE / relative).resolve()
        require(path != HERE and path.is_relative_to(HERE) and path not in actual and
                sha(path.read_bytes()) == expected, f"package checksum mismatch: {relative}")
        actual.add(path)
    expected = {path.resolve() for path in HERE.rglob("*") if path.is_file() and path.name != "SHA256SUMS"}
    require(actual == expected, "archive inventory population mismatch")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--python-image", type=Path, default=Path(sys.executable))
    parser.add_argument("--pwsh-image", type=Path, required=True)
    args = parser.parse_args()
    if os.name != "nt":
        parser.error("the frozen analyzer verifies Windows historical paths")
    out = args.out.resolve()
    if out.is_relative_to(HERE) or out.exists():
        parser.error("choose a fresh destination outside the evidence package")
    verify_inventory()
    index = json.loads((HERE / "replay-paths.json").read_bytes())
    key = lambda path: os.path.normcase(os.fspath(path))
    redirects = {key(old): HERE / relative for old, relative in index["historical_paths"].items()}
    for role, path in (("python", args.python_image), ("controller_shell", args.pwsh_image)):
        entry = index["external_images"][role]
        path = path.resolve()
        require(sha(path.read_bytes()) == entry["sha256"], f"{role} executable digest differs")
        redirects[key(entry["path"])] = path

    locations = index["inputs"]
    def exact(role):
        entry = locations[role]
        raw = redirects[key(entry["path"])].read_bytes()
        require(sha(raw) == entry["sha256"], f"{role} input digest differs")
        return raw

    terminal = json.loads(exact("terminal"))
    recipe_raw = (HERE / "anchor/launcher-recipe.json").read_bytes()
    recipe = json.loads(recipe_raw)
    template = recipe["powershell_text_template"]
    placeholder = recipe["admission_digest_placeholder"]
    admission_sha = locations["admission"]["sha256"]
    require(template.count(placeholder) == 1, "terminal substitution is ambiguous")
    encoded = base64.b64encode(template.replace(placeholder, admission_sha).encode("utf-16-le")).decode()
    require(terminal["process"]["argv"] == [*recipe["bootstrap_argv_prefix"], encoded] and
            terminal["process"]["exit_code"] == 0 and terminal["rows"] == 807 and
            terminal["capture_sha256"] == locations["capture"]["sha256"] and
            terminal["manifest_sha256"] == locations["manifest"]["sha256"] and
            terminal["admission_sha256"] == admission_sha and
            terminal["launcher_recipe_sha256"] == sha(recipe_raw),
            "external terminal receipt mismatch")

    historical_source = Path(locations["verify"]["path"])
    source = exact("verify")
    argv = [str(historical_source), "replay"]
    for role in ("manifest", "schedule", "admission", "capture"):
        entry = locations[role]
        argv.extend((f"--{role}", entry["path"]))
        if role != "schedule":
            argv.extend((f"--{role}-sha256", entry["sha256"]))
    argv.extend(("--out", str(out)))
    original_read, original_stat, original_resolve = Path.read_bytes, Path.stat, Path.resolve
    original_argv, original_executable = sys.argv, sys.executable

    def mapped(path):
        return redirects.get(key(path), path)

    def read_bound(path):
        return original_read(mapped(path))

    def stat_bound(path, *args, **kwargs):
        return original_stat(mapped(path), *args, **kwargs)

    def resolve_bound(path, *args, **kwargs):
        return path if key(path) in redirects else original_resolve(path, *args, **kwargs)

    try:
        Path.read_bytes, Path.stat, Path.resolve = read_bound, stat_bound, resolve_bound
        sys.argv, sys.executable = argv, index["external_images"]["python"]["path"]
        exec(compile(source, str(historical_source), "exec"),
             {"__name__": "__main__", "__file__": str(historical_source)})
    finally:
        sys.argv, sys.executable = original_argv, original_executable
        Path.read_bytes, Path.stat, Path.resolve = original_read, original_stat, original_resolve

    require(out.read_bytes() == (HERE / "anchor/anchor-analysis-001.json").read_bytes(),
            "frozen replay differs from the archived analysis bytes")
    print("Verified package and external terminal receipt. Reproduced the anchor analysis byte for byte.")


if __name__ == "__main__":
    main()

