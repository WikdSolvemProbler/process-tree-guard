# Direct-child reaper source and no-child ABI qualification

Candidate010 implements a concrete single-call held-pidfd reaper against009's
actual DirectChild and cleanup Deadline. It does not add a forwarding trait.
Pending returns the same owner. Valid positive exit/signal observations create
a private receipt retaining the original pidfd and raw event. Errors retain
opaque original ownership and evidence; ECHILD never creates a receipt. A
positive-but-invalid consuming observation is distinct from Pending. Consumption
is classified before post-call clock validation, and AfterReap preserves an
already validated event when that later check fails. No retry or Drop cleanup
is presented as a guarantee.

The actual C bridge performs one fixed waitid(P_PIDFD,WEXITED|WNOHANG) call when
invoked with sufficient storage. Rust does not decode native siginfo_t padding.
Installed C headers normalize a fixed-width frame and retain all zero-initialized
native bytes. Both languages assert the normalized frame layout, and scalar
ABI checks precede C writes into Rust. No DirectChild was constructed, and no
native reaper wait or child fixture was invoked during this qualification.

Root and independent critic reviewed source-candidate.json SHA
af03e7a07eda9abd6ea3497dce145219b10f3e7efd0ab6c214a8f602294feae5
and exact finite plan
ed6cba7d6656ffc4a3c89bdee6f05e19ec580eca9e0d76043eca610ad7b34ba1.
Approval covered one ordinary no-child constant/header reporter and full-graph
object compilation only. REVIEW.json records scope, resolved requirements and
remaining work. All18 source snapshot entries retain their exact lengths/hashes.
The unmodified009 baseline is bound by archive SHA
9f7532dc455e73b8b82d0f7e73fcbbea0c5b4788613d9286f4a39e48ac7051f1.

Exactly one native attempt passed on Linux6.8.0-147-generic ARM64. Pinned GCC
and Rust versions/hashes and exact commands are recorded. For each C translation
unit, dependency paths and input identities/content hashes were captured before
and after compilation. The bridge had114 dependencies and the reporter37;
snapshots matched. Only pinned private sources or root-owned, non-user-writable
installed headers were admitted before reporter execution. Compiler/reporter
environment changes were scoped, recorded and did not change host settings.
Original header-provenance JSON bytes preserve nanosecond integers without a
JavaScript-number rewrite.

The reporter calls only constant/header ABI queries and printf. It returned0
and reported the following actual installed-header values:

| Representation | Size | Alignment | Member offsets |
| --- | ---: | ---: | --- |
| Normalized C/Rust frame | 40 | 4 | 0,4,8,12,16,20,24,28,32,36 |
| Native siginfo_t | 128 | 8 | signo0,errno4,code8,pid16,uid20,status24 |

P_PIDFD was3, WEXITED4 and WNOHANG1. The full constant report and raw stdout are
retained. Native size128 is an observation for these headers, not a Rust layout
assumption. The reporter SHA is
41f4f467365b43172542e879b0eda731c841f5490b466f6a1505f8128727404b.
It was the only newly built executable invoked. Its reviewed source creates no
fixture child and never calls the bridge's wait function. This is not a claim
that the surrounding OS/toolchain performs no process-wait syscalls.

The C bridge/reporter objects and ordinary/test objects of the full Rust graph
compiled with warnings denied. Neither Rust object nor any harness ran. Local
header inspection confirmed ARM64 ELF64 little-endian objects and the reporter
executable. RESULTS.json records every artifact hash and size. There is no
cross-language wait/status runtime, normal-exit, Pending, signaled-exit or ECHILD
qualification here; those require the separately reviewed genuine-child fixture.

Independent ordinary checks found the original unit/cgroup and all11 recorded
controller/tool PIDs absent. All58 artifacts were downloaded and hash-verified
from only /tmp/ptg-child-reaper-010.yfrqcttp, UID501, device64769 inode1111952.
PID absence is reported without inventing creation timestamps. The complete
pre-removal ZIP was verified first: SHA
ee13953fae2569a6be7c70912a15be0b1131778f2bdb02be6b9645772981100f,
1,811,177bytes,103members. Cleanup repeated scope/PID checks, matched retained
directory/file identities, hashes, sizes and modes, removed only those58 files
and verified empty directories, and confirmed the exact scratch absent. No root
or guessed recursive deletion was used. The pre-removal ZIP is not nested here;
its evidence members appear directly with later cleanup receipts.

The refused source-edit patch and a copied preservation prefix corrected before
execution are preserved as preparation history. There was no failed compiler or
reporter attempt and no automatic retry. Exact source/frame/probe/command/tool/
header/report/object bytes and raw streams remain available for review. The
Windows diagnostic worker explicitly held profiling during this CLI window.

Limits remain: kernel calls can stall, and returned ownership does not protect
against drop, panic or process death. Full native caller/SIGCHLD policy, prearmed
child deadlines, actual reaping, terminal orchestration, subreaper adoption,
watchdog/exec-result behavior and populated cgroup settlement remain open. No
root, payload, privileged concurrency or production activation ran. No speed,
supported-kernel-floor or broader architecture qualification is claimed.

INDEX.json records exact lengths and SHA-256 for every other public member;
CRC, membership and exact bytes are verified. No tracked documentation or Git
history was changed by this task.
