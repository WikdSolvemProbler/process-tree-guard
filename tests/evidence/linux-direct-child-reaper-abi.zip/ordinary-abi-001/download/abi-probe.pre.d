waitid_abi_probe.o: \
 target/codex-security/issue2-linux-child-reaper-010/waitid_abi_probe.c \
 /usr/include/stdc-predef.h \
 target/codex-security/issue2-linux-child-reaper-010/waitid_bridge.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 /usr/include/inttypes.h /usr/include/stdio.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/aarch64-linux-gnu/bits/stdio_lim.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/aarch64-linux-gnu/bits/stdio2-decl.h \
 /usr/include/aarch64-linux-gnu/bits/stdio.h \
 /usr/include/aarch64-linux-gnu/bits/stdio2.h
