# Preservation preparation notes

Before the preservation helper's first execution, source inspection found its
copied local unit prefix still used009. It was corrected to the exact010 prefix
and matched to the separately updated remote helper. No mismatched scope command
was executed and no file was removed during that preparation correction.

The first actual preservation command returned0, retained all58 files and found
the original unit/cgroup and all11 recorded controller/tool PIDs absent. Header
provenance JSON contains nanosecond integer metadata; its exact bytes are retained
and hash-verified without rewriting those integers through JavaScript numbers.
