"""Static AST/hash/shell-argument checks only; no VM/native launch."""
import ast
import base64
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

HERE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
plan_bytes=(HERE/"plan.json").read_bytes()
assert sha(plan_bytes)=="ed6cba7d6656ffc4a3c89bdee6f05e19ec580eca9e0d76043eca610ad7b34ba1"
plan=json.loads(plan_bytes)
for name,digest in plan["files"].items():assert sha((HERE/name).read_bytes())==digest,name
for name,digest in plan["local_executable_sha256"].items():assert sha(Path(name).read_bytes())==digest,name
driver=(HERE/"guest_controller.py").read_text(encoding="utf-8")
ast.parse(driver)
assert "FILTER" not in driver and "authority-tests" not in driver
assert "--emit=obj" in driver
assert plan["object_builds"] == ["activation-main.o", "activation-tests.o"]
assert plan["runtime_test_invocations"] == 0
assert plan["no_fixture_children"] is True and plan["reaper_runtime_calls"] == 0
assert plan["abi_reporter_executions"] == 1
assert plan["normalized_frame"]["bytes"] == 40
assert "ptg_waitid_once(" not in driver and "poll_reap(" not in driver
outer=shlex.split((HERE/"linux-command.txt").read_text(encoding="utf-8"))
assert outer[:6]==[plan["mac_gtimeout"]["path"],"--signal=KILL","--kill-after=3s","80s","/bin/sh","-c"]
assert len(outer)==7 and outer[-1]==(HERE/"mac-preflight.sh").read_text(encoding="utf-8")
preflight=outer[-1]
nested=shlex.split(preflight[preflight.index("\nexec ")+6:])
assert nested[:4]==["/opt/homebrew/bin/limactl","shell","ae1-runner","--"]
assert nested[4:-1]==plan["guest_argv"][:-1]
assert nested[-1]==driver
ssh_argv=["C:/Windows/System32/OpenSSH/ssh.exe","-T","-o","BatchMode=yes","-o",
          "StrictHostKeyChecking=yes","-o","ConnectTimeout=8","peters-mac-mini",
          (HERE/"linux-command.txt").read_text(encoding="utf-8")]
windows_command_units=len(subprocess.list2cmdline(ssh_argv).encode("utf-16-le"))//2
assert windows_command_units<32760
assert "--foreground"not in nested and "sudo"not in nested
payload=(HERE/"payload.json").read_bytes()
assert sha(payload)==plan["source_payload_sha256"]
entries=json.loads(payload)["files"]
assert set(entries)==set(plan["source_inputs"])
for name,pin in plan["source_inputs"].items():
    raw=base64.b64decode(entries[name],validate=True)
    assert len(raw)==pin["bytes"]and sha(raw)==pin["sha256"],name
receipt={"plan_sha256":sha(plan_bytes),"validator_sha256":sha(Path(__file__).read_bytes()),
         "python_ast":"pass","all_plan_source_and_tool_hashes":"pass","shell_argument_roundtrip":"pass",
         "payload_member_bytes":"pass","native_or_VM_launch":False}
receipt["windows_ssh_commandline_utf16_units"]=windows_command_units
with(HERE/"static-validation.json").open("x",encoding="utf-8",newline="\n")as f:f.write(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
