# Prepared ordinary010 no-child header ABI qualification

PREPARED ONLY. Exact source candidate
af03e7a07eda9abd6ea3497dce145219b10f3e7efd0ab6c214a8f602294feae5
was independently reviewed for object compilation and the constant/header ABI
reporter only. This exact plan and command require review before any compiler
or reporter launch. No native wait observation or child fixture is approved here.

The finite chain is unchanged from009: Linux ordinary user scope70s with
control-group SIGKILL, a separate guest waiting-client75s/kill-after3s, Mac
gtimeout80s/kill-after3s and Windows Job100s. UID501, non-root primary group,
ARM64, exact current scope and effective RuntimeMax/KillMode/KillSignal/
SendSIGKILL properties must match before staging. SSH uses BatchMode, strict
known hosts and an8s connection limit. No root, sudo, admin authentication,
account change, cgroup component operation or concurrency lane is involved.

The original real Rust compiler must retain SHA
b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f;
the installed /usr/bin/gcc must retain SHA
a20520ee21543f243d40636a9181a142c45ecd989de31ab86b99a8ea5ada870d.
Expected local tool pins come from the reviewed009 plan and are live-verified
only within the coordinated CLI window. All source/payload bytes are checked
and staged inside a fresh private UID501 mode0700 scratch. Windows reads/hashes
the plan, command and payload once, then uses those same verified buffers.

Compiler/reporter subprocesses receive a fixed PATH, locale and private TMPDIR.
Include/compiler/loader override environment keys are removed only from those
subprocesses; present values are represented by hashes, never printed. No host
environment or system setting is changed.

For each real C translation unit, GCC first emits an explicit dependency file.
The controller accepts only exact pinned private source inputs or regular,
root-owned, non-group/other-writable headers under /usr/include, /usr/lib/gcc
or /usr/local/include. Canonical paths, identities, lengths, hashes and relevant
timestamps are recorded. Compilation emits a second dependency file; paths and
before/after snapshots must agree. The bridge and reporter use C17, -Wall,
-Wextra, -Werror, -O2 and -fno-common. Source continuity is checked again later.
This assumes a trusted administrator/toolchain; it is not a hostile-root
change-and-restore file-race proof.

Only after the C/header checks succeed is waitid-abi-report linked and executed.
Its reviewed main calls only the constant/header ABI queries and printf. It
creates no fixture child and never invokes waitid, the reaper, clone, fork or
exec. The normalized40-byte/alignment4/member-offset report must match Rust's
assertions; actual siginfo size/alignment/offsets and constants are recorded
without assuming native padding or size128. The raw reporter JSON is retained.
Its binary SHA is recorded before execution.

The full actual Rust graph is then compiled with edition2021, -D warnings and
--emit=obj, ordinary and with --test. Those objects and any test harness are not
linked or invoked. The C metadata reporter is the only newly built executable
run in this qualification. The C bridge's wait function is compiled, not called.
The Rust representation assertions compile; cross-language wait/status runtime
behavior still requires the separately reviewed genuine-child fixture.

Every command's raw streams and exit are retained as observed, along with all
source/tool/header/command/report/object hashes. Success records the complete
retained inventory. Failure records the scratch path and a best-effort partial
inventory, including snapshot errors; it does not fabricate completion. Preserve
all artifacts before a separate bounded identity-checked ordinary cleanup. No
automatic retry or root fallback is authorized under this attempt ID.

Method's Windows diagnostic must be terminal before any local CLI/remote phase
here starts; release the window only after preservation, cleanup and local CLI
are terminal. No performance result, child reaping, timer behavior, populated
settlement, terminal controller or production readiness is qualified here.
