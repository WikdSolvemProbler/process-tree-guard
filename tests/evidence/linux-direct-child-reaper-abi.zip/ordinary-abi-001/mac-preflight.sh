set -eu
test "$(/usr/bin/id -u)" = 501
printf '%s  %s\n' '6a7b0620313d337d70366cd4d3b969b49854abfeb1db602bdf3328122e223c6d' '/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout' | /usr/bin/shasum -a 256 -c -
exec '/opt/homebrew/bin/limactl' 'shell' 'ae1-runner' '--' '/usr/bin/timeout' '--signal=KILL' '--kill-after=3s' '75s' '/usr/bin/systemd-run' '--user' '--scope' '--quiet' '--expand-environment=no' '--unit' 'ptg-child-reaper-010.scope' '-p' 'RuntimeMaxSec=70s' '-p' 'KillMode=control-group' '-p' 'KillSignal=SIGKILL' '-p' 'SendSIGKILL=yes' '--' '/usr/bin/python3' '-I' '-B' '-c' '"""Ordinary installed-header ABI reporter and object compilation; no wait or child fixture."""
import base64
import hashlib
import json
import os
from pathlib import Path
import selectors
import shlex
import stat
import subprocess
import sys
import tempfile

EXPECTED = {"target/codex-security/issue2-linux-child-reaper-010/transport.rs":{"bytes":16882,"sha256":"907472caaa18f3e4a288f323c8969d85b5b0e494bcfad2cbf65357d24185fee9"},"target/codex-security/issue2-linux-child-reaper-010/cross_peer.rs":{"bytes":18353,"sha256":"dab5eb3884ff1711d4396aa422b795cf5747c06a8d647f731e4250028dcd4091"},"target/codex-security/issue2-linux-child-reaper-010/release_lease.rs":{"bytes":18547,"sha256":"8b148c0f6a8a445af0e577a669d233c74eed1c75ec4dfd8311e54d70ece20bf4"},"target/codex-security/issue2-linux-child-reaper-010/prepared_run.rs":{"bytes":17124,"sha256":"55e302b30dee581f7fe0515847fcdcfa2abd8998775275cb48e705c45a6ea78a"},"target/codex-security/issue2-linux-child-reaper-010/native_activation.rs":{"bytes":11236,"sha256":"4d4dd0cd8641edd0bb41a9f57138237135856b9dcced4036f765549b3cefe82b"},"target/codex-security/issue2-linux-child-reaper-010/cgroup_authority.rs":{"bytes":18950,"sha256":"7b579ec2a118c10b788f401e0cb32263dc262363a8d12f5576e2da5cb62bea15"},"target/codex-security/issue2-linux-child-reaper-010/settlement.rs":{"bytes":13222,"sha256":"b9c7f7b129aadcc591fc6335b4a438975b39fbf0342c2ae762e9f51774abe26a"},"target/codex-security/issue2-linux-child-reaper-010/settlement_fixture.rs":{"bytes":7825,"sha256":"b6dc0456d2f30a37dc6222167044e9458dcb05fabfa2636626311b3a964b7058"},"target/codex-security/issue2-linux-child-reaper-010/settlement_controls.rs":{"bytes":3515,"sha256":"e45852239c8e67e85f94d01558f20df8c655e14bffcb683c6158ceeb1198388a"},"target/codex-security/issue2-linux-child-reaper-010/abi-flags.c":{"bytes":273,"sha256":"dabf258922de316924704d822c48160eb9d489289496ee18f45bfc5a8000d4c2"},"target/codex-security/issue2-linux-child-reaper-010/child_reaper.rs":{"bytes":11474,"sha256":"10582f9283f81dc25b29408911835b0d3e1657a6c449ca441c0f5f4b69d2bcba"},"target/codex-security/issue2-linux-child-reaper-010/waitid_bridge.h":{"bytes":3022,"sha256":"4b3562bd4e0e8fe9540f7986fbd125859906e0462a136075e32baf6c10ffb851"},"target/codex-security/issue2-linux-child-reaper-010/waitid_bridge.c":{"bytes":4412,"sha256":"066ef61dfa5d606b4c819ffd26be66988dabe8bef955b1fe46be07ba84449077"},"target/codex-security/issue2-linux-child-reaper-010/waitid_abi_probe.c":{"bytes":1239,"sha256":"41e67e4ec649e3b18b739d359674ed754ddbdc305f3226c2187ae3425bfa595e"},"target/codex-security/issue2-linux-generic-request-001/request.rs":{"bytes":9207,"sha256":"6531478a6cb85c31ba4639c01c144c789968178df57b64d3d128073a8d91b4c4"},"src/deadline.rs":{"bytes":1171,"sha256":"56252eb28270b4743d73e17e05ae933d3fad8168e7b4ba34405e859be9c85c53"}}
PAYLOAD_SHA256 = "8f85616ee5deaf0b3813faa8da7ddd0fec844b2ea9eb29192148ed04fbfbeee0"
UNIT = "ptg-child-reaper-010.scope"
CONTROL_GROUP = "/user.slice/user-501.slice/user@501.service/app.slice/" + UNIT
COMPILER = "/home/petershiller1.guest/.rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu/bin/rustc"
COMPILER_SHA256 = "b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f"
C_COMPILER = "/usr/bin/gcc"
C_COMPILER_SHA256 = "a20520ee21543f243d40636a9181a142c45ecd989de31ab86b99a8ea5ada870d"

def demand(value, text):
    if not value:
        raise RuntimeError(text)

def write_all(fd, data):
    while data:
        n = os.write(fd, data)
        demand(n > 0, "short retained stream write")
        data = data[n:]

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for part in iter(lambda: f.read(65536), b""):
            h.update(part)
    return h.hexdigest()

def retained_inventory(root):
    rows = {}
    for path in sorted(root.rglob("*")):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            demand(info.st_uid == 501, "unexpected non-owned artifact directory")
            continue
        demand(stat.S_ISREG(info.st_mode) and info.st_uid == 501 and info.st_nlink == 1
               and info.st_size <= 32 * 1024 * 1024, "unexpected retained artifact type/size")
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            before = os.fstat(fd)
            value = hashlib.sha256()
            count = 0
            while count <= 32 * 1024 * 1024:
                part = os.read(fd, 65536)
                if not part: break
                count += len(part)
                value.update(part)
            after = os.fstat(fd)
            demand((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                   == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                   and [before.st_dev, before.st_ino] == [info.st_dev, info.st_ino] and count == info.st_size,
                   "retained artifact changed during snapshot")
            rows[str(path.relative_to(root))] = {"bytes": count, "sha256": value.hexdigest(),
                                                "device": before.st_dev, "inode": before.st_ino}
        finally:
            os.close(fd)
    return rows

tree = None
try:
    os.umask(0o077)
    demand(os.getuid() == 501 and os.geteuid() == 501, "ordinary UID501 required")
    demand(os.getgid() != 0 and os.getegid() != 0, "root group refused")
    demand(os.uname().machine == "aarch64", "ARM64 qualification only")
    scope = Path("/proc/self/cgroup").read_text().strip()
    demand(scope == "0::" + CONTROL_GROUP, "unexpected actual user scope")
    prop = subprocess.run(["/usr/bin/systemctl", "--user", "show", UNIT,
                           "-p", "RuntimeMaxUSec", "-p", "KillMode", "-p", "KillSignal",
                           "-p", "SendSIGKILL", "-p", "ControlGroup", "-p", "ActiveState"],
                          capture_output=True, text=True, timeout=3)
    print("SCOPE_PROPERTIES=" + json.dumps({"stdout": prop.stdout, "stderr": prop.stderr,
          "exit": prop.returncode, "actual_cgroup": scope}), flush=True)
    demand(prop.returncode == 0, "effective scope query refused")
    properties = dict(line.split("=", 1) for line in prop.stdout.splitlines())
    for key, value in {"RuntimeMaxUSec": "1min 10s", "KillMode": "control-group", "KillSignal": "9",
                       "SendSIGKILL": "yes", "ControlGroup": CONTROL_GROUP, "ActiveState": "active"}.items():
        demand(properties.get(key) == value, "effective finite scope property differs: " + key)
    packet = sys.stdin.buffer.read(1024 * 1024 + 1)
    demand(len(packet) <= 1024 * 1024 and hashlib.sha256(packet).hexdigest() == PAYLOAD_SHA256,
           "exact source payload differs")
    entries = json.loads(packet)["files"]
    demand(set(entries) == set(EXPECTED), "source member set differs")
    tree = Path(tempfile.mkdtemp(prefix="ptg-child-reaper-010.", dir="/tmp"))
    held = tree.stat()
    demand(held.st_uid == 501 and stat.S_IMODE(held.st_mode) == 0o700, "scratch custody differs")
    print("ORDINARY_SCRATCH=" + json.dumps({"path": str(tree), "device": held.st_dev,
          "inode": held.st_ino, "uid": held.st_uid, "mode": stat.S_IMODE(held.st_mode)}), flush=True)
    for name, pin in EXPECTED.items():
        data = base64.b64decode(entries[name], validate=True)
        demand(len(data) == pin["bytes"] and hashlib.sha256(data).hexdigest() == pin["sha256"],
               "source bytes differ: " + name)
        path = tree / name
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with path.open("xb") as f:
            f.write(data)
        demand(digest(path) == pin["sha256"], "staged source differs: " + name)
    os.environ["TMPDIR"] = str(tree)
    os.chdir(tree)
    tool_env = dict(os.environ)
    removed_environment = {}
    for key in ("CPATH", "C_INCLUDE_PATH", "CPLUS_INCLUDE_PATH", "OBJC_INCLUDE_PATH",
                "GCC_EXEC_PREFIX", "COMPILER_PATH", "LIBRARY_PATH", "GCC_SPECS",
                "LD_PRELOAD", "LD_LIBRARY_PATH", "LD_AUDIT", "LD_DEBUG",
                "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "RUSTFLAGS", "RUSTC_LOG",
                "CFLAGS", "CPPFLAGS", "LDFLAGS"):
        if key in tool_env:
            removed_environment[key] = hashlib.sha256(tool_env.pop(key).encode("utf-8", "surrogateescape")).hexdigest()
    tool_env.update(PATH="/usr/bin:/bin", TMPDIR=str(tree), LC_ALL="C", LANG="C", TZ="UTC")
    print("TOOL_ENVIRONMENT=" + json.dumps({"removed_value_sha256": removed_environment,
          "PATH": tool_env["PATH"], "LC_ALL": tool_env["LC_ALL"], "TMPDIR": str(tree),
          "scope": "compiler and ABI-reporter subprocesses only; no host setting change"}), flush=True)

    def command(argv, tag):
        print("NATIVE_ARGV=" + json.dumps({"tag": tag, "argv": argv}), flush=True)
        out_path, err_path = tree / (tag + ".stdout.log"), tree / (tag + ".stderr.log")
        with out_path.open("xb") as out, err_path.open("xb") as err:
            child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, close_fds=True, env=tool_env)
            print("NATIVE_CHILD=" + json.dumps({"tag": tag, "pid": child.pid}), flush=True)
            with selectors.DefaultSelector() as selector:
                selector.register(child.stdout, selectors.EVENT_READ, (out, 1))
                selector.register(child.stderr, selectors.EVENT_READ, (err, 2))
                while selector.get_map():
                    for key, events in selector.select(timeout=0.1):
                        data = os.read(key.fileobj.fileno(), 4096)
                        if not data:
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                            continue
                        retained, transport = key.data
                        retained.write(data)
                        retained.flush()
                        write_all(transport, data)
            code = child.wait()
        (tree / (tag + ".exit.txt")).write_text(str(code))
        print("NATIVE_EXIT=" + json.dumps({"tag": tag, "pid": child.pid, "exit": code,
              "stdout_sha256": digest(out_path), "stderr_sha256": digest(err_path)}), flush=True)
        demand(code == 0, "native step failed: " + tag)
        return out_path

    source_paths = {(tree / name).resolve(): pin for name, pin in EXPECTED.items()}
    installed_roots = [Path("/usr/include"), Path("/usr/lib/gcc"), Path("/usr/local/include")]

    def dependencies(path):
        text = path.read_text().replace("\\\n", " ")
        target, separator, tail = text.partition(":")
        demand(bool(separator) and bool(target.strip()), "invalid compiler dependency file")
        names = shlex.split(tail)
        demand(bool(names), "empty compiler dependency list")
        return {Path(name).resolve(strict=True) for name in names}

    def header_snapshot(paths):
        rows = {}
        for path in sorted(paths):
            before = path.stat()
            demand(stat.S_ISREG(before.st_mode), "compiler dependency is not regular")
            value = digest(path)
            after = path.stat()
            demand((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                   == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
                   "compiler dependency changed during hashing")
            if path in source_paths:
                pin = source_paths[path]
                demand(before.st_uid == 501 and before.st_size == pin["bytes"] and value == pin["sha256"],
                       "private compiler input differs")
                role = "pinned_source"
            else:
                demand(any(path.is_relative_to(root) for root in installed_roots)
                       and before.st_uid == 0 and before.st_mode & 0o022 == 0,
                       "compiler dependency is outside reviewed installed-header roots")
                role = "installed_header"
            rows[str(path)] = {"role": role, "bytes": before.st_size, "sha256": value,
                               "device": before.st_dev, "inode": before.st_ino,
                               "mtime_ns": before.st_mtime_ns, "ctime_ns": before.st_ctime_ns,
                               "uid": before.st_uid, "mode": stat.S_IMODE(before.st_mode)}
        return rows

    cflags = ["-std=c17", "-Wall", "-Wextra", "-Werror", "-O2", "-fno-common"]
    source_directory = "target/codex-security/issue2-linux-child-reaper-010/"
    header_manifest = {}

    def compile_c(name, output, tag):
        source = source_directory + name
        pre = tree / (tag + ".pre.d")
        post = tree / (tag + ".d")
        command([C_COMPILER, *cflags, "-M", "-MF", str(pre), source], tag + "-dependencies")
        before_paths = dependencies(pre)
        before = header_snapshot(before_paths)
        command([C_COMPILER, *cflags, "-MD", "-MF", str(post), "-c", source, "-o", output], tag + "-compile")
        after_paths = dependencies(post)
        after = header_snapshot(after_paths)
        demand(before_paths == after_paths and before == after, "C header provenance changed across compilation")
        header_manifest[tag] = {"before": before, "after": after, "match": True}
        (tree / "header-provenance.json").write_text(json.dumps(header_manifest, indent=2) + "\n")
        print("C_HEADER_PROVENANCE=" + json.dumps({"tag": tag, "dependencies": len(before),
              "sha256": digest(tree / "header-provenance.json"), "before_after_match": True}), flush=True)

    demand(digest(Path(COMPILER)) == COMPILER_SHA256, "pinned native compiler differs")
    demand(digest(Path(C_COMPILER)) == C_COMPILER_SHA256, "pinned native C compiler differs")
    print("NATIVE_CONTEXT=" + json.dumps({"pid": os.getpid(), "uid": os.getuid(),
          "uname": list(os.uname()), "compiler": COMPILER, "compiler_sha256": digest(Path(COMPILER)),
          "gcc_sha256": digest(Path("/usr/bin/gcc")), "payload_executions": 0,
          "root_fixture_executions": 0, "cgroup_writes": 0}), flush=True)
    command([COMPILER, "--version", "--verbose"], "compiler-version")
    command([C_COMPILER, "--version"], "c-compiler-version")
    compile_c("waitid_bridge.c", "waitid-bridge.o", "bridge")
    compile_c("waitid_abi_probe.c", "waitid-abi-probe.o", "abi-probe")
    command([C_COMPILER, "waitid-bridge.o", "waitid-abi-probe.o", "-o", "waitid-abi-report"], "abi-link")
    print("ABI_REPORTER_BINARY=" + json.dumps({"path": str(tree / "waitid-abi-report"),
          "sha256": digest(tree / "waitid-abi-report")}), flush=True)
    abi_output = command([str(tree / "waitid-abi-report")], "abi-report")
    abi = json.loads(abi_output.read_bytes())
    normalized = {"schema": 1, "frame_size": 40, "frame_align": 4, "called_offset": 0,
                  "result_offset": 4, "call_errno_offset": 8, "signo_offset": 12,
                  "signal_errno_offset": 16, "code_offset": 20, "pid_offset": 24,
                  "uid_offset": 28, "status_offset": 32, "native_size_offset": 36}
    native_fields = ["siginfo_signo_offset", "siginfo_errno_offset", "siginfo_code_offset",
                     "siginfo_pid_offset", "siginfo_uid_offset", "siginfo_status_offset"]
    constants = ["P_PIDFD", "WEXITED", "WNOHANG", "SIGCHLD", "CLD_EXITED", "CLD_KILLED",
                 "CLD_DUMPED", "NSIG", "ECHILD", "EINTR", "EBADF", "EFAULT", "EINVAL"]
    demand(set(abi) == set(normalized) | set(native_fields) | set(constants) | {"siginfo_size", "siginfo_align"},
           "ABI report member set differs")
    demand(all(type(value) is int for value in abi.values()), "ABI report contains non-integer values")
    demand(all(abi[key] == value for key, value in normalized.items()), "C report differs from Rust frame assertions")
    size, alignment = abi["siginfo_size"], abi["siginfo_align"]
    demand(4 <= size <= 512 and alignment > 0 and alignment & (alignment - 1) == 0
           and size % alignment == 0 and all(0 <= abi[key] <= size - 4 for key in native_fields),
           "native installed-header layout exceeds bounded storage")
    demand(all(0 < abi[key] <= 2147483647 for key in constants)
           and abi["WEXITED"] & abi["WNOHANG"] == 0 and abi["NSIG"] > abi["SIGCHLD"]
           and len({abi["CLD_EXITED"], abi["CLD_KILLED"], abi["CLD_DUMPED"]}) == 3,
           "installed-header wait/signal constants are invalid")
    (tree / "abi-report.json").write_text(json.dumps(abi, indent=2) + "\n")
    print("ABI_HEADER_REPORT=" + json.dumps({"values": abi, "normalized_frame_matches": True,
          "native_siginfo_padding_assumed": False, "fixture_children": 0,
          "waitid_calls_by_reporter": 0, "basis": "reviewed reporter only calls constant ABI queries"}), flush=True)
    for testing, output_name in ((False, "activation-main.o"), (True, "activation-tests.o")):
        args = [COMPILER, "--edition=2021", "-D", "warnings", "--emit=obj"]
        if testing:
            args.append("--test")
        args.extend(["target/codex-security/issue2-linux-child-reaper-010/transport.rs", "-o", output_name])
        command(args, "compile-test-object" if testing else "compile-main-object")
        print("NATIVE_OBJECT=" + json.dumps({"path": str(tree / output_name),
              "test_object": testing, "sha256": digest(tree / output_name)}), flush=True)
    for name, pin in EXPECTED.items():
        demand(digest(tree / name) == pin["sha256"], "source changed during qualification: " + name)
    inventory = retained_inventory(tree)
    (tree / "ordinary-inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
    print("ORDINARY_COMPONENT_COMPLETE=" + json.dumps({"object_builds_passed": 2,
          "abi_reporter_passed": True, "abi_values": abi, "fixture_children": 0,
          "reaper_runtime_calls": 0, "header_provenance_sha256": digest(tree / "header-provenance.json"),
          "scratch_retained": str(tree), "scratch_identity": [held.st_dev, held.st_ino],
          "file_inventory": inventory, "payload_executions": 0, "root_fixture_executions": 0,
          "cgroup_writes": 0, "scope": "installed-header ABI report and whole-graph object compilation; no wait/child/harness execution"}), flush=True)
except BaseException as error:
    partial_inventory = None
    inventory_error = None
    if tree is not None:
        try:
            partial_inventory = retained_inventory(tree)
        except BaseException as snapshot_error:
            inventory_error = type(snapshot_error).__name__ + ": " + str(snapshot_error)
    print("ORDINARY_COMPONENT_REFUSED=" + json.dumps({"error": type(error).__name__ + ": " + str(error),
          "scratch_retained": None if tree is None else str(tree),
          "file_inventory": partial_inventory, "inventory_error": inventory_error,
          "policy": "preserve raw failure and owned artifacts before exact identity cleanup; no retry/root fallback"}), flush=True)
    raise
'
