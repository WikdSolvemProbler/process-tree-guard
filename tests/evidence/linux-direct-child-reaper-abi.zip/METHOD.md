# Native held-pidfd direct-child reaper candidate010

SOURCE ONLY at preparation. No compiler, ABI reporter, waitid call or child
fixture has run for010. This fresh source graph preserves009. The inherited
native_activation.rs only adds the concrete child_reaper module; no production
backend, terminal controller, root operation or concurrency lane is enabled.

poll_reap consumes the actual DirectChild and borrows009's actual finite cleanup
Deadline. It validates the installed-header bridge ABI and checks the deadline
before making exactly one fixed waitid(P_PIDFD, WEXITED|WNOHANG) API call on the
original held pidfd. There is no PID lookup, discovery, retry loop, new cleanup
timer or Drop cleanup. The C bridge accepts no PID or caller-provided wait flags.

Pending requires a successful zero-event observation and returns the very same
DirectChild by move, with its full observation and a successful post-call clock
check. A positive observation must match the original PID, SIGCHLD, an allowed
exit classification and a valid status before producing ReapedChild. Exited and
signaled/core-dump outcomes are distinct. UID is retained as observed metadata,
not substituted for the held-pidfd identity check.

Every returned failure retains its original ownership and evidence. A wait error,
including ECHILD, never creates a reap receipt. A positive but invalid observation
is ConsumedInvalid, not Pending. Error owners are opaque QuarantinedChild values
with no safe conversion back to reusable DirectChild. ReapedChild retains the
original pidfd and exact raw event and has no conversion back to DirectChild.
Classification happens before post-call deadline validation. If that final clock
check fails after a valid consuming reap, AfterReap retains the valid receipt and
its event rather than pretending the child is still pending. NotCalled variants
explicitly preserve deadline/ABI refusal evidence without inventing a syscall.

The normalized C/Rust frame is deliberately fixed at40bytes/alignment4 with ten
fixed-width members. Both languages assert every member offset. This is a local
wire contract, not an assumed copy of native siginfo_t. Installed C headers alone
decode native siginfo_t. The C source asserts native field widths and a bounded
maximum native size, reports actual native sizeof/alignment/member offsets and
constants, and zero-initializes the whole native structure before the wait call.
Rust retains every native byte in a512-byte capacity buffer; it never interprets
native padding. The actual native length is reported and checked, not assumed128.

Before C writes any frame into Rust, scalar ABI queries verify schema, normalized
size/alignment/offsets, native capacity and the header-derived constants. The
queries themselves perform no wait operation. Error observations retain the ABI
report, normalized frame, complete zero-initialized native bytes, target descriptor,
expected PID and pre-call time as applicable. No error formatter dumps PreparedRun
argv or credential plans.

The first proposed qualification is separate and has no fixture children. It
compiles the real C bridge and ABI reporter against installed headers, validates
the exact compiler dependency paths/hashes, runs only the constant/header reporter,
and compiles ordinary and test objects of the full real Rust graph with warnings
denied. The reporter creates no child and never calls ptg_waitid_once, waitid,
clone, fork or exec. Its fixed-width frame report must match Rust's assertions.
Neither Rust object nor a test harness is invoked, and no DirectChild is fabricated
to call the reaper. Native wait observations remain unqualified at this stage.

A later sequential real-child fixture requires its own exact source/plan review.
It may use genuine clone3(CLONE_PIDFD) results and prearmed child deadlines for
normal, gated-pending/released, signaled and repeated raw-wait/ECHILD observations.
A repeated raw wait must borrow a prior exact ReapedChild receipt, never recreate
an owner. No such fixture, clone path or runtime test is included in this stage.

Limits remain explicit. WNOHANG avoids a deliberate waiting loop but a kernel call
can still stall; independent finite process coverage remains necessary. Borrowed
Deadline checks do not establish a complete custodian. Returned ownership is not
protection against drop, panic or process death. Consuming terminal orchestration,
subreaper adoption, exec-result distinction, populated cgroup settlement, actual
child reaping qualification and production/kernel-floor acceptance remain open.
