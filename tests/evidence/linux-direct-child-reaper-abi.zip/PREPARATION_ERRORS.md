# Preparation errors preserved

One source-edit patch was refused before compilation or execution. Its second
hunk mistakenly targeted the ABI reporter's names array inside waitid_bridge.c.
The patch tool reported:

```text
apply_patch verification failed: Failed to find expected lines in
C:\Users\Peter\process-tree-guard\target\codex-security\issue2-linux-child-reaper-010\waitid_bridge.c:
    static const char *const names[PTG_ABI_WORD_COUNT] = {
```

The correction targeted waitid_bridge.c and waitid_abi_probe.c separately. The
final source snapshot binds the actual resulting bytes. No build or native
attempt occurred during this error, and009 remained unchanged.
