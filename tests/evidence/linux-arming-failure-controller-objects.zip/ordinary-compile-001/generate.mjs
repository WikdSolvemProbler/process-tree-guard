import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here=path.dirname(fileURLToPath(import.meta.url));
const arm=path.dirname(here);
const base=path.dirname(arm);
const repo=path.dirname(path.dirname(base));
const sha=b=>createHash('sha256').update(b).digest('hex');
const read=p=>fs.readFile(p);
const put=(name,data)=>fs.writeFile(path.join(here,name),data,{flag:'wx'});
const quote=s=>"'"+s.replaceAll("'","'\"'\"'")+"'";
const join=a=>a.map(quote).join(' ');
const candidateBytes=await read(path.join(arm,'source-candidate.json'));
if(sha(candidateBytes)!=='7d1fe469658bde0be0548b7871c379d668efb52c46a85d816b167a323ba3ed11')throw Error('reviewed source candidate differs');
const candidate=JSON.parse(candidateBytes);
for(const [name,pin]of Object.entries(candidate.files)){
  const data=await read(path.join(arm,name));
  if(sha(data)!==pin.sha256 || data.length!==pin.bytes)throw Error('reviewed source differs: '+name);
}
const modules=["abi-flags.c","arming_failure_controller.rs","cgroup_authority.rs","child_fixture.c","child_fixture.h","child_reaper.rs","child_reaper_fixture.rs","cross_peer-metadata-only.rs","cross_peer.rs","native_activation.rs","prepared_run.rs","release_lease.rs","settlement.rs","settlement_controls.rs","settlement_fixture.rs","terminal_bridge.c","terminal_bridge.h","terminal_controller.rs","transport-metadata-only.rs","transport.rs","waitid_abi_probe.c","waitid_bridge.c","waitid_bridge.h"];
const baseline13=JSON.parse(await read(path.join(base,'issue2-linux-terminal-controller-013/source-candidate.json')));
for(const name of modules.filter(n=>/\.(c|h)$/.test(n)))if(candidate.files[name].sha256!==baseline13.files[name].sha256)throw Error('C source changed: '+name);
if(sha(await read(path.join(repo,'tests/evidence/linux-terminal-controller-objects.zip')))!=='0848ccef7232bb14df277ab4e0ad4a65a637f7b020af3eb1ff1ad3da64b7c4eb')throw Error('prior C archive changed');
const sourceFiles={};
for(const n of modules)sourceFiles['target/codex-security/issue2-linux-arming-failure-controller-014/'+n]=await read(path.join(arm,n));
for(const [name,digest]of Object.entries({
  'target/codex-security/issue2-linux-generic-request-001/request.rs':'6531478a6cb85c31ba4639c01c144c789968178df57b64d3d128073a8d91b4c4',
  'src/deadline.rs':'56252eb28270b4743d73e17e05ae933d3fad8168e7b4ba34405e859be9c85c53',
})){
  const data=await read(path.join(repo,name));
  if(sha(data)!==digest)throw Error('inherited source dependency changed: '+name);
  sourceFiles[name]=data;
}
const expected=Object.fromEntries(Object.entries(sourceFiles).map(([n,b])=>[n,{bytes:b.length,sha256:sha(b)}]));
const payload=Buffer.from(JSON.stringify({files:Object.fromEntries(Object.entries(sourceFiles).map(([n,b])=>[n,b.toString('base64')]))})+'\n');
if(payload.length>1024*1024)throw Error('payload bound exceeded');
await put('payload.json',payload);
const template=(await read(path.join(here,'guest_controller.template.py'))).toString('utf8');
const driver=template.replace('@EXPECTED_JSON@',JSON.stringify(expected)).replace('@PAYLOAD_SHA256@',sha(payload));
if(driver.includes('@EXPECTED_JSON@')||driver.includes('@PAYLOAD_SHA256@'))throw Error('unreplaced driver pin');
await put('guest_controller.py',driver);
const guestArgv=['/usr/bin/timeout','--signal=KILL','--kill-after=3s','75s',
  '/usr/bin/systemd-run','--user','--scope','--quiet','--expand-environment=no',
  '--unit','ptg-arming-failure-controller-014.scope','-p','RuntimeMaxSec=70s',
  '-p','KillMode=control-group','-p','KillSignal=SIGKILL','-p','SendSIGKILL=yes',
  '--','/usr/bin/python3','-I','-B','-c',driver];
const tool='/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout';
const toolSha='6a7b0620313d337d70366cd4d3b969b49854abfeb1db602bdf3328122e223c6d';
const preflight='set -eu\n'+
  "test \"$(/usr/bin/id -u)\" = 501\n"+
  `printf '%s  %s\\n' ${quote(toolSha)} ${quote(tool)} | /usr/bin/shasum -a 256 -c -\n`+
  'exec '+join(['/opt/homebrew/bin/limactl','shell','ae1-runner','--',...guestArgv])+'\n';
const macArgv=[tool,'--signal=KILL','--kill-after=3s','80s','/bin/sh','-c',preflight];
await put('mac-preflight.sh',preflight);
const commandText=join(macArgv)+'\n';
if(commandText.length>30000)throw Error('prepared SSH command exceeds conservative Windows argument bound');
await put('linux-command.txt',commandText);
const locals=[
  'C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe',
  'C:/Users/Peter/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe',
  'C:/Windows/System32/OpenSSH/ssh.exe',
];
const inputs=["generate.mjs","guest_controller.template.py","guest_controller.py","launch.ps1","METHOD.md","payload.json","mac-preflight.sh","linux-command.txt","preserve.py","preserve_remote.template.py","../source-candidate.json","../../issue2-linux-terminal-controller-013/source-candidate.json","../../issue2-linux-terminal-controller-013/ordinary-compile-002/download/terminal-bridge.o","../../issue2-linux-terminal-controller-013/ordinary-compile-002/download/header-provenance.json","../../../../tests/evidence/linux-terminal-controller-objects.zip"].concat(Object.keys(candidate.files).map(n=>'../'+n));
const files={};for(const n of inputs)files[n]=sha(await read(path.join(here,n)));
const priorPlanBytes=await read(path.join(base,'issue2-linux-cgroup-authority-009','ordinary-compile-001','plan.json'));
if(sha(priorPlanBytes)!=='a1be6642ecee082589a298f96cb808b9c1aa7e500d75476ffde8a6de141a2a30')throw Error('reviewed expected tool pins differ');
const toolPins=JSON.parse(priorPlanBytes).local_executable_sha256;
for(const n of locals)if(!(n in toolPins))throw Error('missing expected local tool pin');
const plan={schema:1,state:'UNEXECUTED_PENDING_EXACT_SOURCE_AND_PLAN_REVIEWS',review_pending:true,purpose:'014 ordinary full-graph Rust normal/test OBJECTS only; unchanged013 C qualification reference, no C compile',reviewed_source_candidate_sha256:sha(candidateBytes),files,local_executable_sha256:toolPins,source_payload_sha256:sha(payload),source_payload_bytes:payload.length,source_inputs:expected,mac_gtimeout:{path:tool,sha256:toolSha},native_compiler:{path:'/home/petershiller1.guest/.rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu/bin/rustc',sha256:'b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f'},guest_argv:guestArgv.slice(0,-1).concat('<exact pinned guest_controller.py bytes>'),source002_mac_admin:'DEFERRED; no sudo/admin command',deadlines_seconds:{windows_job:100,mac_outer:80,guest_waiting_client:75,linux_user_scope:70,kill_after:3},target:'peters-mac-mini -> ordinary Lima ae1-runner UID501 ARM64',object_builds:['activation-main.o','activation-tests.o'],c_compile_executions:0,prior_c_qualification:{archive_repository_path:'tests/evidence/linux-terminal-controller-objects.zip',archive_sha256:'0848ccef7232bb14df277ab4e0ad4a65a637f7b020af3eb1ff1ad3da64b7c4eb',bridge_object_sha256:'ae4539f319063c8c766728085b192e5c5ae38da10b4f138eac64e4fc1fd6ffbd',header_provenance_sha256:'bc05d888979a61f576923be75dd6eff667cd1adaf16e584bfac7963a8d8f608b',scope:'Prior013 unchanged C OBJECT evidence only; no fresh C compile/ABI or native behavior claim'},runtime_test_invocations:0,prototype_executions:0,fixture_children:0,abi_reporter_executions:0,prohibitions:'No C compiler/link/reporter/controller/test/runtime/child/root/cgroup/payload/concurrency invocation, source rewrite or retry',failure_policy:'Retain all raw errors/partial artifacts; verify immutable archive BEFORE exact held-identity/hash ordinary cleanup; no guessed cleanup',source_scope:'Native Rust OBJECT acceptance only; actual native armer/entry/runtime remain unqualified'};
const planBytes=Buffer.from(JSON.stringify(plan,null,2)+'\n');
await put('plan.json',planBytes);
const digest=sha(planBytes);
const argv=[locals[0],'--timeout','100','--',locals[1],'-NoProfile','-NonInteractive','-File',
  path.join(here,'launch.ps1').replaceAll('\\','/'),'-ApprovedPlanSha',digest];
await put('local-argv.json',JSON.stringify({prepared_only:true,plan_sha256:digest,argv},null,2)+'\n');
console.log(JSON.stringify({plan_sha256:digest,payload_sha256:sha(payload),payload_bytes:payload.length,
  guest_driver_sha256:sha(Buffer.from(driver)),command_sha256:files['linux-command.txt'],
  launcher_sha256:files['launch.ps1'],files:Object.keys(files).length},null,2));
