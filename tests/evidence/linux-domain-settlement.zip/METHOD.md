# Linux empty-domain settlement source and execution evidence

This archive preserves source revisions 005 and 006, all prepared plans, the failed first ordinary launch, native compile and denial controls, the executed root component test, independent cleanup, the exact native test binary, and shared source dependencies. Original files retain their repository-relative paths. The top-level INDEX.json records every other member's byte length and SHA-256.

## Qualified execution scope

A sequential root test ran on the disposable Linux ARM64 6.8 VM. It created a fresh protected canonical root at /sys/fs/cgroup/process-tree-guard, called the actual descriptor-relative authority factory for one empty leaf, wrote cgroup.kill through the retained authority, observed populated=0, revalidated the retained identities, removed the exact leaf and fixed root, and confirmed absence. The selected ignored native test passed once with zero failures and twelve other tests filtered out.

The fixed root identity was device (0,31), mount 36, inode 158553. The generated leaf was run-da9cbfedaa5f97c77af2ad00229cea5a with the same device and mount and inode 158613. The native removal receipt records poll_wakeups=0. The poll loop was compiled but no populated wait occurred.

This test launched zero payloads and performed no leaf concurrency, account creation, namespace operation, global control setting change or persistent installation. It qualifies the observed factory and sequential empty-domain kill/drain/remove component on this VM only. Populated polling and deadline expiry, child reaping, watchdog behavior, general activation, the complete OneShotPort, CreatedLeaf custody on arm failure and mandatory PendingSettlement ownership remain open. The production Linux backend remains disabled.

## Reviewed and executed inputs

Revision 005 introduced the real bounded settlement API with typed ownership on every returned failure. Revision 006 left settlement.rs byte-identical and changed the root fixture's ignored description and failure comment to the approved empty-domain scope.

The first ordinary 006 launch stopped before compilation because a CRLF command file caused the shell's set invocation to fail. The exact refusal and source are preserved under ordinary-attempt-001. A fresh 006b scope with LF text compiled the real module graph and passed the ordinary read-only denial test. Independent guest C-header and Rust receipts matched the selected flags. No root factory ran in that ordinary control.

The native binary is 7831632 bytes with SHA-256 66baff03d905ee8519a3824502f17fd993b55a082ac44ab56ab78501bcf1c292. Its ordinary private handoff carried exact byte and source pins. The root controller copied only the hardcoded inputs through retained no-follow directory and file descriptors into a fresh root-owned 0700 scratch directory, verified source stability and hashes, and re-hashed the root copies. The inner service checked every copied digest before exec.

The executed plan SHA-256 was 95d63f813831c8cbce246bc7000ac0d294839f609410062711f0fd38787d9b09. Its controller source is ab5f11ea82b4ff2b449de1cc019de9b2fc696bf22d86da878c205e5c7111a2cd. Prior preparations are retained separately and were not executed. Both systemd-run calls in the executed command set --expand-environment=no so the reviewed Python and shell text reaches the services literally.

## Finite process containment

The actual outer controller and inner fixture verified their effective properties and exact cgroup membership before running the component. The controller used Type=exec, RuntimeMaxSec=50s, TimeoutStopSec=3s, KillMode=control-group, KillSignal=SIGKILL, SendSIGKILL=yes and Delegate=no. The fixture used the same settings with RuntimeMaxSec=12s. The privileged waiting client additionally ran under a 65-second guest timeout with a three-second kill grace and its own process group. Mac gtimeout was 75 seconds with a three-second grace, and the isolated Windows Job deadline was 100 seconds.

The root test required exclusive creation and refused any preexisting canonical root. On normal return it verified exact root and leaf removal, and the controller checked fixed-root absence and removed only its own staged scratch inodes. Nonzero exit, timeout or missing identity would leave uncertain directories untouched and report VM quarantine. Such directory artifacts are distinct from process deadline coverage.

The original prepared METHOD files remain unchanged as historical planning records. This top-level method states the scope of the later actual execution.

## Independent cleanup and preservation order

A separate bounded ordinary-user check verified that the canonical fixed root and exact root scratch /tmp/ptg-empty-domain-root-006.49fwbley were absent. The controller and fixture units were inactive/dead, had no MainPID or ControlPID, and had empty ControlGroup values. Their exact cgroup directories and both ordinary 006/006b scopes were absent. A scan for the exact selected test argv found no worker. Other command-line access limits, if any, remain recorded in the raw JSON. The first failed ordinary launch had no matching scratch directory.

The root scratch removal receipt identified device 64769 and inode 2128181. The independent check found its name absent. The exact native binary was downloaded as UID 501, verified before transfer, and matched the expected hash again after transfer. It is included under native-binary-download.

Before removing the retained ordinary handoff, an immutable pre-removal archive was created and every member verified. It has SHA-256 ba08c444c409d3a25d5d34d295eae3bfc2d6b395ccc7d4f264ccd315cf295ba1. Its receipt and full source index are included here, while the complete pre-removal ZIP remains in the local package workspace.

Removal then ran only as UID 501 against /tmp/ptg-authority-linux-006b.NZuquohz, recorded device 64769 and inode 2128106. It used held no-follow directory descriptors and a full recorded inode/mode/hash inventory. It validated the entire tree before deleting anything, rechecked each entry before unlink or rmdir, and removed only the exact owned parent after its contents were gone. It performed no root operation. The deletion receipt confirms that all previously absent root and scope paths remained absent. The final public archive adds that receipt without replacing any earlier evidence.

## Reproduction and limits

The source, input tar, build commands, ordinary native receipts, root command, reviewed plan, effective service properties and raw stdout/stderr are included. Extracting at a repository root preserves the relative Rust module paths. Any replay requires a separately reviewed finite scope and must refuse a preexisting canonical root.

The root service runtimes and component timestamps are raw functional-test receipts. This archive makes no performance, throughput or benchmark claim. It contains no additional root experiment or retry and does not resume earlier rejected privileged concurrency work.
