#![allow(dead_code)]
#[path="src/deadline.rs"] mod deadline;
#[path="src/sys/linux/mod.rs"] mod linux;
type Policy = fn(u32,u32,&[u32],&std::ffi::CStr)->bool;
#[used]
#[unsafe(no_mangle)]
pub(crate) static PTG_LINUX_COMPONENT_ENTRY: unsafe fn(std::os::fd::OwnedFd,Policy)->linux::RunOutcome = linux::run_received;
