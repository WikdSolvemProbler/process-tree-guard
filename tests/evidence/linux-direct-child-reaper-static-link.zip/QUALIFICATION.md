# Linux012 ordinary direct-child reaper component passed

The sole reviewed012 attempt returned0 with empty stderr. Actual full-graph
normal/test object compilation and the exact selected test passed. Exactly
three sequential clone3(CLONE_PIDFD) children were exercised: PID2754055 exited23;
PID2754056 first yielded Pending with its original PID/pidfd, then exited29
after the gate byte; PID2754057 first yielded Pending, received SIGTERM through
its exact pidfd, and was reaped with signal15/no core. Each genuine ReapedChild
retained its pidfd for one repeated raw wait, all three returning ECHILD10.
All128 native siginfo bytes and normalized fields are retained for every raw
observation. No second owner was fabricated for repeated waits.

Before each clone, the child3s and independent parent5s absolute BOOTTIME timers
were armed. Actual arm/readback/before-clone/after-clone timestamps are recorded.
The cases completed before expiry; this does NOT qualify the timer-expiry,
cleanup-failure/quarantine or post-reap clock-error branches. The child code
monitors its inherited timer and every parent poll includes its retained cleanup
timer, under the independently verified70/75/80/100 outer containment chain.

The C bridge and fixture objects were byte-identical to failed011:

- waitid-bridge.o: fc70194391d0fc41a0c769719ce42d79154cdb82588fa669f458e71f72674a13
- child-fixture.o: 5a96576738116536248b448532fa55c6a2926ed11768f7ce3e71c73e08ae3808

The deterministic static archive contains only those two members in that order;
each extracted member matched its original bytes. nm still reported the
undefined __stack_chk_guard reference. Normal Rust -L native/-l static linkage
succeeded without appending raw C object link arguments, disabling stack
protection or changing existing hardening flags. Archive SHA is
397351379244e4466d9973827c7f74eac0ef3c0c832aef50a139ce34a6dc54e6.

The actual GNU link map (SHA afad87c4bd71dfa5bf3e528d8cd351a6d068eac6d6ebe613f2e0c4140481e521)
retains both archive members and explicitly records the needed provider:

    ld-linux-aarch64.so.1  .../libptg_reaper_fixture.a(waitid-bridge.o) (__stack_chk_guard@@GLIBC_2.17)

The separate ordinary read-only002 inspection recorded the actual libc.so
AS_NEEDED loader script and a defined8-byte GLOBAL DEFAULT OBJECT symbol in
section16 of the loader, rather than UND or a substring-only claim. This and
the unchanged C objects validate the practical native linkage repair on this
toolchain and support the documented link-order explanation. No speed result
or unique-cause theorem is asserted. Failed011 and inspection001's environment
refusal remain unchanged;002 parser revisions and the offline command-size
generation refusal are preserved too. No automatic retry occurred under any ID.

All103 remote artifacts were independently verified and downloaded through
held no-follow descriptors. The pre-removal ZIP passed every INDEX byte/hash/
length and CRC check before cleanup: SHA
8ad52689a36b1bb73e74e300bc8111df9300a184ccc7795930cbb3c44ca5cd4d,
10,321,136bytes/213members. Sources, raw streams, dependency/header snapshots,
ABI reporter, C/Rust objects, archive/extracted members, linked test executable,
link map, command/plan/tool pins and all failed preparation evidence are retained.

Original UID5010700 scratch /tmp/ptg-child-reaper-012.fqc66n0s,
device64769/inode1111952, was removed only after the preserved held file and
directory identities/hashes matched again. All26 exact recorded controller/
tool/fixture PIDs and original unit/cgroup were absent in both independent
checks. Scratch absence was confirmed. This is recorded PID-absence evidence,
not an invented creation-time attestation. No root or guessed cleanup was used.

This qualifies only the ordinary direct-child reaper component on this ARM64
Linux host. It does not qualify populated cgroup cleanup, original lease/owner
or exec-report supervision, watchdog/adopted-descendant/subreaper settlement,
full terminal orchestration, production activation, performance or superiority.
No payload exec, cgroup component operation, root action, account/setting change,
adversarial concurrency or daemon was included. The next implementation work is
the actual consuming full-run terminal owner, with removal after exact reaping.
