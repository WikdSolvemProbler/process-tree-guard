# Linux012 native static-archive linkage repair (offline preparation)

This fresh directory preserves failed011 archive
a2e04ba953e7974a23b44164bc07e6ce3236d90f6abdabe811811c30588c2b14.
The actual reaper, C bridge and sequential ordinary fixture are unchanged from
the reviewed011 source. The proposed repair changes native linkage only.

The011 raw linker invocation placed dynamic -lc before the late object paths
passed via -C link-arg. GNU ld's --as-needed considers earlier unresolved
references, rather than references first introduced by later objects. That
supports the observed __stack_chk_guard/loader ordering hypothesis. It remains
an inference until a fresh reviewed link succeeds with unchanged object code.
Primary references: https://sourceware.org/binutils/docs/ld/Options.html
(--as-needed) and https://doc.rust-lang.org/rustc/command-line-arguments.html
(-l native static libraries).

The proposed path uses verified /usr/bin/ar to build one deterministic native
static archive containing exactly waitid-bridge.o and child-fixture.o. Record
ar version, exact member list, archive hash and extracted member byte equality.
Use normal Rust -L native=<scratch> -l static=ptg_reaper_fixture, rather than
appended raw C object arguments. Preserve every existing C/Rust hardening flag;
do not disable stack protection or inject a dynamic-loader path. Record a GNU
link map, and retain the original undefined __stack_chk_guard reference through
verified nm output for the unchanged bridge object.

Actual ar/nm identities, versions and toolchain libc/loader symbol resolution
must first be inspected under a separate ordinary finite read-only scope.
No such inspection, build, link or child attempt has run under012. Tool hashes
remain mandatory pending inputs; generation must refuse their absence. All VM
commands wait for the Windows component/pipeline window to be released.

After exact source and complete plan reviews, the single proposed attempt uses
the same70/75/80/100 containment, header provenance, source/binary gates, one
exact selected-test list/count and three sequential native no-exec children as
011. Every failure and partial artifact is preserved without a silent retry.
Archive before exact held-identity cleanup. No root/cgroup/payload/concurrency
lane, backend activation, timer weakening or new production guarantee is added.

The functional fixture still covers only real direct-child exit23, gated
Pending→29, exact pidfd SIGTERM and repeat-ECHILD. Full original lease/owner/
payload/watchdog terminal supervision, exec-report custody, adopted descendants
under a dedicated subreaper, populated drain and removal last remain the next
actual production-integration work after this component qualifies.
