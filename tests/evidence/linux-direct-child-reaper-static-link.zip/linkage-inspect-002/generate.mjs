import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const sha=b=>createHash('sha256').update(b).digest('hex');
const quote=s=>"'"+s.replaceAll("'","'\"'\"'")+"'";
const join=a=>a.map(quote).join(' ');
const put=(name,data)=>fs.writeFile(path.join(here,name),data,{flag:'wx'});
const query=await fs.readFile(path.join(here,'query.py'),'utf8');
const tool='/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout';
const toolSha='6a7b0620313d337d70366cd4d3b969b49854abfeb1db602bdf3328122e223c6d';
const guest=['/usr/bin/timeout','--signal=KILL','--kill-after=3s','35s',
  '/usr/bin/systemd-run','--user','--scope','--quiet','--expand-environment=no',
  '--unit','ptg-reaper-linkage-inspect-012-002.scope','-p','RuntimeMaxSec=30s',
  '-p','KillMode=control-group','-p','KillSignal=SIGKILL','-p','SendSIGKILL=yes',
  '--','/usr/bin/python3','-I','-B','-c',query];
const preflight='set -eu\n'+"test \"$(/usr/bin/id -u)\" = 501\n"+
  `printf '%s  %s\\n' ${quote(toolSha)} ${quote(tool)} | /usr/bin/shasum -a 256 -c -\n`+
  'exec '+join(['/opt/homebrew/bin/limactl','shell','ae1-runner','--',...guest])+'\n';
await put('mac-preflight.sh',preflight);
await put('linux-command.txt',join([tool,'--signal=KILL','--kill-after=3s','45s','/bin/sh','-c',preflight])+'\n');
await put('payload.json',Buffer.alloc(0));
const localPins={
 'C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe':'1899137f687541256fb89749b2fe6a2940f2e420faaf2330fc84f32cfd7fae43',
 'C:/Users/Peter/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe':'2a6769a3330dc1084d0154bfde7d164ab750ca7f700f313f9d417c1be78b2233',
 'C:/Windows/System32/OpenSSH/ssh.exe':'98d447730047f5df91373e852d057928a921c3d1e89938700ab656ba84b19dc8',
};
const files={};
for(const name of ['query.py','METHOD.md','generate.mjs','launch.ps1','mac-preflight.sh','linux-command.txt','payload.json'])
  files[name]=sha(await fs.readFile(path.join(here,name)));
const plan={schema:1,state:'PREPARED_READ_ONLY_NO_REMOTE_RUN',files,
 local_executable_sha256:localPins,source_query_sha256:sha(Buffer.from(query)),
 guest_argv:guest.slice(0,-1).concat('<exact pinned query.py bytes>'),
 deadlines_seconds:{windows_job:65,mac_outer:45,guest_waiting_client:35,linux_user_scope:30,per_query:3,kill_after:3},
 mac_gtimeout:{path:tool,sha256:toolSha},
 gcc_sha256:'a20520ee21543f243d40636a9181a142c45ecd989de31ab86b99a8ea5ada870d',
 scope:'ordinary root-owned file/tool identity/version and actual libc-script/loader symbol query only',
 native_builds:0,native_links:0,fixture_children:0,root_actions:0,remote_artifacts_created:false,
 failure_policy:'preserve original raw refusal; no automatic retry, alternate path, root or fixture work',
 window:'wait for parent-approved Windows pipeline release before any CLI or remote launch'};
const bytes=Buffer.from(JSON.stringify(plan,null,2)+'\n');
await put('plan.json',bytes);
const argv=[Object.keys(localPins)[0],'--timeout','65','--',Object.keys(localPins)[1],'-NoProfile','-NonInteractive',
 '-File',path.join(here,'launch.ps1').replaceAll('\\','/'),'-ApprovedPlanSha',sha(bytes)];
await put('local-argv.json',JSON.stringify({prepared_only:true,plan_sha256:sha(bytes),argv},null,2)+'\n');
console.log(JSON.stringify({plan_sha256:sha(bytes),query_sha256:plan.source_query_sha256,files:Object.keys(files).length},null,2));
