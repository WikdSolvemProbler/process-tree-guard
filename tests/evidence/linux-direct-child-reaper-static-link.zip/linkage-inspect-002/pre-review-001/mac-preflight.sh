set -eu
test "$(/usr/bin/id -u)" = 501
printf '%s  %s\n' '6a7b0620313d337d70366cd4d3b969b49854abfeb1db602bdf3328122e223c6d' '/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout' | /usr/bin/shasum -a 256 -c -
exec '/opt/homebrew/bin/limactl' 'shell' 'ae1-runner' '--' '/usr/bin/timeout' '--signal=KILL' '--kill-after=3s' '35s' '/usr/bin/systemd-run' '--user' '--scope' '--quiet' '--expand-environment=no' '--unit' 'ptg-reaper-linkage-inspect-012-002.scope' '-p' 'RuntimeMaxSec=30s' '-p' 'KillMode=control-group' '-p' 'KillSignal=SIGKILL' '-p' 'SendSIGKILL=yes' '--' '/usr/bin/python3' '-I' '-B' '-c' '"""Ordinary read-only tool/link-script inspection. No build, link or fixture."""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

UNIT = "ptg-reaper-linkage-inspect-012-002.scope"
GROUP = "/user.slice/user-501.slice/user@501.service/app.slice/" + UNIT
GCC_SHA = "a20520ee21543f243d40636a9181a142c45ecd989de31ab86b99a8ea5ada870d"

def demand(value, message):
    if not value:
        raise RuntimeError(message)

def emit(kind, **values):
    print(kind + "=" + json.dumps(values), flush=True)

def root_file(path, maximum=16 * 1024 * 1024):
    path = Path(path).resolve(strict=True)
    before = path.stat()
    demand(stat.S_ISREG(before.st_mode) and before.st_uid == 0
           and before.st_mode & 0o022 == 0 and before.st_size <= maximum,
           "tool/library is not a bounded trusted root-owned regular file")
    data = path.read_bytes()
    after = path.stat()
    stable = lambda value: (value.st_dev, value.st_ino, value.st_size,
                            value.st_mtime_ns, value.st_ctime_ns)
    demand(stable(before) == stable(after) and len(data) == before.st_size,
           "tool/library changed while reading")
    return {"resolved": str(path), "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data), "device": before.st_dev, "inode": before.st_ino,
            "mtime_ns": before.st_mtime_ns, "ctime_ns": before.st_ctime_ns,
            "uid": before.st_uid, "mode": stat.S_IMODE(before.st_mode)}, data

pids = []
def query(argv):
    environment = {"PATH": "/usr/bin:/bin", "LC_ALL": "C", "LANG": "C"}
    if argv[0] == "/usr/bin/systemctl":
        # Control query needs its inherited ordinary user bus. Do not copy
        # compiler/loader override variables into any native tool environment.
        for key in ("XDG_RUNTIME_DIR", "DBUS_SESSION_BUS_ADDRESS"):
            if key in os.environ:
                environment[key] = os.environ[key]
    child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, close_fds=True,
                             env=environment)
    pids.append(child.pid)
    try:
        out, err = child.communicate(timeout=3)
    except subprocess.TimeoutExpired:
        child.kill()
        out, err = child.communicate(timeout=2)
        emit("QUERY", argv=argv, pid=child.pid, timeout=True, exit=child.returncode,
             stdout=out.decode("utf-8", "backslashreplace"), stderr=err.decode("utf-8", "backslashreplace"))
        raise
    emit("QUERY", argv=argv, pid=child.pid, exit=child.returncode,
         stdout=out.decode("utf-8", "backslashreplace"), stderr=err.decode("utf-8", "backslashreplace"))
    demand(child.returncode == 0, "read-only native query refused")
    return out

try:
    demand(os.getuid() == os.geteuid() == 501 and os.getgid() != 0
           and os.getegid() != 0 and os.uname().machine == "aarch64", "ordinary ARM64 UID501 required")
    demand(Path("/proc/self/cgroup").read_text().strip() == "0::" + GROUP, "unexpected finite query scope")
    props = query(["/usr/bin/systemctl", "--user", "show", UNIT, "-p", "RuntimeMaxUSec",
                   "-p", "KillMode", "-p", "KillSignal", "-p", "SendSIGKILL", "-p", "ControlGroup"])
    actual = dict(line.split("=", 1) for line in props.decode().splitlines())
    for key, value in {"RuntimeMaxUSec": "30s", "KillMode": "control-group", "KillSignal": "9",
                       "SendSIGKILL": "yes", "ControlGroup": GROUP}.items():
        demand(actual.get(key) == value, "effective query bound differs: " + key)
    emit("INSPECTION_CONTEXT", controller_pid=os.getpid(), uid=os.getuid(), uname=list(os.uname()),
         scope=GROUP, build_invocations=0, fixture_children=0, payload_execs=0, root_actions=0,
         note="only fixed installed-tool queries and root-owned file reads; no scratch/filesystem writes")
    old = query(["/usr/bin/systemctl", "--user", "show", "ptg-reaper-linkage-inspect-012.scope",
                 "-p", "LoadState", "-p", "ActiveState", "-p", "ControlGroup"])\
                 .decode()
    old_props = dict(line.split("=", 1) for line in old.splitlines())
    demand(old_props.get("LoadState") == "not-found" and old_props.get("ActiveState") == "inactive",
           "failed001 unit is not absent/inactive")
    old_group = Path("/sys/fs/cgroup/user.slice/user-501.slice/user@501.service/app.slice/ptg-reaper-linkage-inspect-012.scope")
    demand(not old_group.exists() and all(not Path("/proc/" + str(pid)).exists() for pid in (2496909, 2496920)),
           "failed001 exact scope/PID remains; no guessed intervention")
    emit("PRIOR_FAILED_QUERY_CLEANUP", unit_gone=True, cgroup_gone=True,
         recorded_pids_absent=[2496909, 2496920], remote_artifacts_created=False,
         identity_scope="exact recorded PID absence only; no invented creation-time claim")
    tools = {}
    for name in ("gcc", "ar", "nm", "readelf"):
        path = "/usr/bin/" + name
        record, _ = root_file(path)
        if name == "gcc": demand(record["sha256"] == GCC_SHA, "pinned GCC differs")
        tools[name] = {"path": path, **record}
        emit("TOOL_IDENTITY", name=name, **tools[name])
        query([path, "--version"])
        after, _ = root_file(path)
        demand(after == record, "tool changed across version query")
    script_name = query(["/usr/bin/gcc", "-print-file-name=libc.so"]).decode().strip()
    demand(script_name.startswith("/"), "GCC did not resolve an absolute libc script")
    script_record, script_bytes = root_file(script_name, 1024 * 1024)
    script = script_bytes.decode("utf-8")
    emit("LIBC_LINK_SCRIPT", requested=script_name, identity=script_record, text=script)
    loaders = re.findall(r"AS_NEEDED\s*\(\s*(/[^\s)]+)", script)
    demand(len(loaders) == 1 and Path(loaders[0]).name == "ld-linux-aarch64.so.1",
           "actual libc AS_NEEDED loader differs from scoped ARM64 expectation")
    provider, _ = root_file(loaders[0])
    symbols = query(["/usr/bin/readelf", "--dyn-syms", "--wide", provider["resolved"]]).decode()
    guard = [line for line in symbols.splitlines() if "__stack_chk_guard" in line]
    definitions = []
    for line in guard:
        fields = line.split()
        if (len(fields) >= 8 and fields[3] == "OBJECT" and fields[4] in ("GLOBAL", "WEAK")
                and fields[5] in ("DEFAULT", "PROTECTED") and fields[6] not in ("UND", "UNDEF")
                and fields[2] == "8" and fields[7] == "__stack_chk_guard@@GLIBC_2.17"):
            definitions.append({"raw": line, "type": fields[3], "binding": fields[4],
                                "visibility": fields[5], "section": fields[6],
                                "size": int(fields[2]), "symbol": fields[7]})
    emit("STACK_GUARD_PROVIDER", source="actual libc script AS_NEEDED entry", identity=provider,
         matching_symbols=guard, defined_versioned_objects=definitions)
    demand(bool(definitions), "defined usable versioned ARM64 stack-guard object not observed")
    for name, prior in tools.items():
        current, _ = root_file(prior["path"])
        demand(current == {key: value for key, value in prior.items() if key != "path"},
               "tool changed during inspection: " + name)
    emit("LINKAGE_INSPECTION_COMPLETE", tools=tools, controller_pid=os.getpid(), query_pids=pids,
         native_builds=0, native_links=0, fixture_children=0, root_actions=0, remote_scratch_created=False,
         conclusion="tool identities and provider observed; ordering diagnosis remains inference until reviewed native link succeeds")
except BaseException as error:
    emit("LINKAGE_INSPECTION_REFUSED", error=type(error).__name__ + ": " + str(error),
         controller_pid=os.getpid(), query_pids=pids, policy="retain raw refusal; no automatic retry or privileged fallback")
    raise
'
