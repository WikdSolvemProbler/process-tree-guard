# Prepared read-only native linker-tool inspection

Fresh002 corrects001's retained refusal: its systemctl subprocess had lost the
ordinary user-bus environment and refused before any native tool identity was
queried. Preserve001 stdout/stderr/exit/plan/source unchanged; no retry occurs
under that ID. Only exact systemctl control queries retain XDG_RUNTIME_DIR and
DBUS_SESSION_BUS_ADDRESS. Other tool environments remain fixed and sanitized.
Record each variable's presence/value hash. Require the actual inherited XDG
path /run/user/501 and its owned0700 directory/UID501 bus socket. If an explicit
DBUS address exists it must name that bus; if absent, the validated XDG bus is
systemctl's normal context. Do not synthesize an environment value or accept a
foreign UID's runtime. These checks precede the first user-bus query.
After verifying002's own bound, check only001's exact unit/cgroup and two
recorded PIDs absent. No process discovery, signal or filesystem cleanup occurs.

Run once only after the Windows native window is released and the exact command
is reviewed. This query uses an ordinary UID501 scope30s, guest client35s,
pinned Mac gtimeout45s and Windows Job65s. Effective Linux bounds and scope are
verified before the fixed tool queries. Every tool subprocess has its own3s
communicate bound within that enclosing whole-process-tree deadline.

Read/hash root-owned, non-group/other-writable regular files for /usr/bin/gcc,
ar, nm and readelf, recording actual resolved paths/identities and versions.
GCC must match the previously qualified hash. Read GCC's actual libc.so linker
script and its one scoped ARM64 AS_NEEDED loader, then inspect that loader's
dynamic symbols for __stack_chk_guard. All tool identities must remain stable.
Record and require an8-byte defined OBJECT, GLOBAL/WEAK, DEFAULT/PROTECTED,
non-UND __stack_chk_guard@@GLIBC_2.17 entry, rather than substring presence.
The raw version, script and readelf output remains evidence; tool hashes supply
mandatory reviewed inputs to the later012 static-archive plan.

No compile, link, C object execution, native fixture child, root/cgroup/payload
operation, scratch creation, host setting change or installation is included.
No remote filesystem artifact is created. All stdout/stderr/exit and exact
source/command/tool pins are preserved locally. A refusal remains unchanged and
does not authorize retry, alternate path or privilege. This inspection observes
the symbol provider; it cannot by itself prove the011 link-order diagnosis or
qualify the sequential reaper.
