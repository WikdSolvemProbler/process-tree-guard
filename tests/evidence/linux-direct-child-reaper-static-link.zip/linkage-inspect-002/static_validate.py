"""Static pins/argv plus the actual pure address predicate; no VM/native query."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess

here = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
plan_bytes = (here / "plan.json").read_bytes()
assert sha(plan_bytes) == "98c0efd2a8e58b375a40fb0885fcba97fd0894be7018e7981d353da761d19d4b"
plan = json.loads(plan_bytes)
for name, pin in plan["files"].items():
    assert sha((here / name).read_bytes()) == pin, name
for name, pin in plan["local_executable_sha256"].items():
    assert sha(Path(name).read_bytes()) == pin, name
source = (here / "query.py").read_text()
tree = ast.parse(source)
predicates = [node.args[0] for node in ast.walk(tree) if isinstance(node, ast.Call)
              and isinstance(node.func, ast.Name) and node.func.id == "demand"
              and node.args and any(isinstance(part, ast.Name) and part.id == "bus_address"
                                    for part in ast.walk(node.args[0]))]
assert len(predicates) == 1
expression = compile(ast.Expression(predicates[0]), "actual-query-address-predicate", "eval")
base = "unix:path=/run/user/501/bus"
good = [None, base, base + ",guid=" + "ab" * 16]
bad = [base + ",guid=" + "ab" * 15, base + ",guid=" + "ab" * 16 + ";unix:path=/run/user/0/bus",
       base + ",extra=value", base + ";unix:path=/run/user/0/bus", base + "\n",
       "unix:path=/run/user/0/bus", base + ",guid=" + "zz" * 16]
for value in good:
    assert eval(expression, {"__builtins__": {}, "re": re, "bus_address": value}) is True
for value in bad:
    assert eval(expression, {"__builtins__": {}, "re": re, "bus_address": value}) is False
outer = shlex.split((here / "linux-command.txt").read_text())
assert outer[:6] == [plan["mac_gtimeout"]["path"], "--signal=KILL", "--kill-after=3s", "45s", "/bin/sh", "-c"]
assert len(outer) == 7 and outer[-1] == (here / "mac-preflight.sh").read_text()
nested = shlex.split(outer[-1][outer[-1].index("\nexec ") + 6:])
assert nested[:4] == ["/opt/homebrew/bin/limactl", "shell", "ae1-runner", "--"]
assert nested[4:-1] == plan["guest_argv"][:-1] and nested[-1] == source
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-T", "-o", "BatchMode=yes", "-o",
       "StrictHostKeyChecking=yes", "-o", "ConnectTimeout=8", "peters-mac-mini",
       (here / "linux-command.txt").read_text()]
units = len(subprocess.list2cmdline(ssh).encode("utf-16-le")) // 2
assert units < 32760
receipt = {"plan_sha256": sha(plan_bytes), "validator_sha256": sha(Path(__file__).read_bytes()),
           "source_ast_and_seven_pins": "passed", "local_tool_pins": "passed",
           "exact_address_predicate_cases": {"allowed": len(good), "refused": len(bad)},
           "shell_argv_roundtrip": "passed", "windows_commandline_units": units,
           "VM_or_native_query": False}
with (here / "static-validation.json").open("x") as output:
    output.write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
