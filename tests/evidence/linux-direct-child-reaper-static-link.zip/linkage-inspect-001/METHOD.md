# Prepared read-only native linker-tool inspection

Run once only after the Windows native window is released and the exact command
is reviewed. This query uses an ordinary UID501 scope30s, guest client35s,
pinned Mac gtimeout45s and Windows Job65s. Effective Linux bounds and scope are
verified before the fixed tool queries. Every tool subprocess has its own3s
communicate bound within that enclosing whole-process-tree deadline.

Read/hash root-owned, non-group/other-writable regular files for /usr/bin/gcc,
ar, nm and readelf, recording actual resolved paths/identities and versions.
GCC must match the previously qualified hash. Read GCC's actual libc.so linker
script and its one scoped ARM64 AS_NEEDED loader, then inspect that loader's
dynamic symbols for __stack_chk_guard. All tool identities must remain stable.
The raw version, script and readelf output remains evidence; tool hashes supply
mandatory reviewed inputs to the later012 static-archive plan.

No compile, link, C object execution, native fixture child, root/cgroup/payload
operation, scratch creation, host setting change or installation is included.
No remote filesystem artifact is created. All stdout/stderr/exit and exact
source/command/tool pins are preserved locally. A refusal remains unchanged and
does not authorize retry, alternate path or privilege. This inspection observes
the symbol provider; it cannot by itself prove the011 link-order diagnosis or
qualify the sequential reaper.
