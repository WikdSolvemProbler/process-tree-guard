"""Ordinary read-only tool/link-script inspection. No build, link or fixture."""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

UNIT = "ptg-reaper-linkage-inspect-012.scope"
GROUP = "/user.slice/user-501.slice/user@501.service/app.slice/" + UNIT
GCC_SHA = "a20520ee21543f243d40636a9181a142c45ecd989de31ab86b99a8ea5ada870d"

def demand(value, message):
    if not value:
        raise RuntimeError(message)

def emit(kind, **values):
    print(kind + "=" + json.dumps(values), flush=True)

def root_file(path, maximum=16 * 1024 * 1024):
    path = Path(path).resolve(strict=True)
    before = path.stat()
    demand(stat.S_ISREG(before.st_mode) and before.st_uid == 0
           and before.st_mode & 0o022 == 0 and before.st_size <= maximum,
           "tool/library is not a bounded trusted root-owned regular file")
    data = path.read_bytes()
    after = path.stat()
    stable = lambda value: (value.st_dev, value.st_ino, value.st_size,
                            value.st_mtime_ns, value.st_ctime_ns)
    demand(stable(before) == stable(after) and len(data) == before.st_size,
           "tool/library changed while reading")
    return {"resolved": str(path), "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data), "device": before.st_dev, "inode": before.st_ino,
            "mtime_ns": before.st_mtime_ns, "ctime_ns": before.st_ctime_ns,
            "uid": before.st_uid, "mode": stat.S_IMODE(before.st_mode)}, data

pids = []
def query(argv):
    child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, close_fds=True,
                             env={"PATH": "/usr/bin:/bin", "LC_ALL": "C", "LANG": "C"})
    pids.append(child.pid)
    try:
        out, err = child.communicate(timeout=3)
    except subprocess.TimeoutExpired:
        child.kill()
        out, err = child.communicate(timeout=2)
        emit("QUERY", argv=argv, pid=child.pid, timeout=True, exit=child.returncode,
             stdout=out.decode("utf-8", "backslashreplace"), stderr=err.decode("utf-8", "backslashreplace"))
        raise
    emit("QUERY", argv=argv, pid=child.pid, exit=child.returncode,
         stdout=out.decode("utf-8", "backslashreplace"), stderr=err.decode("utf-8", "backslashreplace"))
    demand(child.returncode == 0, "read-only native query refused")
    return out

try:
    demand(os.getuid() == os.geteuid() == 501 and os.getgid() != 0
           and os.getegid() != 0 and os.uname().machine == "aarch64", "ordinary ARM64 UID501 required")
    demand(Path("/proc/self/cgroup").read_text().strip() == "0::" + GROUP, "unexpected finite query scope")
    props = query(["/usr/bin/systemctl", "--user", "show", UNIT, "-p", "RuntimeMaxUSec",
                   "-p", "KillMode", "-p", "KillSignal", "-p", "SendSIGKILL", "-p", "ControlGroup"])
    actual = dict(line.split("=", 1) for line in props.decode().splitlines())
    for key, value in {"RuntimeMaxUSec": "30s", "KillMode": "control-group", "KillSignal": "9",
                       "SendSIGKILL": "yes", "ControlGroup": GROUP}.items():
        demand(actual.get(key) == value, "effective query bound differs: " + key)
    emit("INSPECTION_CONTEXT", controller_pid=os.getpid(), uid=os.getuid(), uname=list(os.uname()),
         scope=GROUP, build_invocations=0, fixture_children=0, payload_execs=0, root_actions=0,
         note="only fixed installed-tool queries and root-owned file reads; no scratch/filesystem writes")
    tools = {}
    for name in ("gcc", "ar", "nm", "readelf"):
        path = "/usr/bin/" + name
        record, _ = root_file(path)
        if name == "gcc": demand(record["sha256"] == GCC_SHA, "pinned GCC differs")
        tools[name] = {"path": path, **record}
        emit("TOOL_IDENTITY", name=name, **tools[name])
        query([path, "--version"])
        after, _ = root_file(path)
        demand(after == record, "tool changed across version query")
    script_name = query(["/usr/bin/gcc", "-print-file-name=libc.so"]).decode().strip()
    demand(script_name.startswith("/"), "GCC did not resolve an absolute libc script")
    script_record, script_bytes = root_file(script_name, 1024 * 1024)
    script = script_bytes.decode("utf-8")
    emit("LIBC_LINK_SCRIPT", requested=script_name, identity=script_record, text=script)
    loaders = re.findall(r"AS_NEEDED\s*\(\s*(/[^\s)]+)", script)
    demand(len(loaders) == 1 and Path(loaders[0]).name == "ld-linux-aarch64.so.1",
           "actual libc AS_NEEDED loader differs from scoped ARM64 expectation")
    provider, _ = root_file(loaders[0])
    symbols = query(["/usr/bin/readelf", "--dyn-syms", "--wide", provider["resolved"]]).decode()
    guard = [line for line in symbols.splitlines() if "__stack_chk_guard" in line]
    emit("STACK_GUARD_PROVIDER", source="actual libc script AS_NEEDED entry", identity=provider,
         matching_symbols=guard, symbol_present=bool(guard))
    demand(bool(guard), "actual loader stack-guard symbol not observed")
    for name, prior in tools.items():
        current, _ = root_file(prior["path"])
        demand(current == {key: value for key, value in prior.items() if key != "path"},
               "tool changed during inspection: " + name)
    emit("LINKAGE_INSPECTION_COMPLETE", tools=tools, controller_pid=os.getpid(), query_pids=pids,
         native_builds=0, native_links=0, fixture_children=0, root_actions=0, remote_scratch_created=False,
         conclusion="tool identities and provider observed; ordering diagnosis remains inference until reviewed native link succeeds")
except BaseException as error:
    emit("LINKAGE_INSPECTION_REFUSED", error=type(error).__name__ + ": " + str(error),
         controller_pid=os.getpid(), query_pids=pids, policy="retain raw refusal; no automatic retry or privileged fallback")
    raise
