# Preserved offline generation refusal

The first012 generation stopped before creating plan.json or launching any
process. Its expanded SSH command text was27,394characters, above the inherited
arbitrary24,000-character conservative text cap. Actual partial payload/driver/
Mac preflight and the generating inputs are preserved in generation-refused-001.

The generator's text cap is now30,000characters. The separate exact Windows
list2cmdline UTF16-unit check must still be <32760 before any native launch.
No deadline, process containment, guard behavior, hardening flag or source
fixture was changed by this preparation fix. No native build was attempted.
