"""Ordinary exact preservation/removal of the attempted012 fixture only."""
import base64
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

ROOT = @ROOT_JSON@
ROOT_ID = @ROOT_ID_JSON@
EXPECTED = @EXPECTED_JSON@
PIDS = @PIDS_JSON@
UNIT = "ptg-child-reaper-012.scope"
CGROUP = "/sys/fs/cgroup/user.slice/user-501.slice/user@501.service/app.slice/" + UNIT

def demand(value, text):
    if not value: raise RuntimeError(text)
def identity(s): return [s.st_dev, s.st_ino]
def stable(s): return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]
def query(argv, allowed=(0,)):
    p = subprocess.run(argv, capture_output=True, text=True, timeout=3)
    print("QUERY=" + json.dumps({"argv": argv, "exit": p.returncode, "stdout": p.stdout,
          "stderr": p.stderr}), flush=True)
    demand(p.returncode in allowed, "ordinary cleanup query refused")
    return p

mode = sys.argv[1]
demand(mode in ("preserve", "remove"), "unexpected action")
demand(os.getuid() == 501 and os.geteuid() == 501, "ordinary UID501 required")
own_unit = "ptg-child-reaper-012-" + mode + ".scope"
own_group = "/user.slice/user-501.slice/user@501.service/app.slice/" + own_unit
demand(Path("/proc/self/cgroup").read_text().strip() == "0::" + own_group, "wrong cleanup scope")
p = query(["/usr/bin/systemctl", "--user", "show", own_unit, "-p", "RuntimeMaxUSec",
           "-p", "KillMode", "-p", "KillSignal", "-p", "SendSIGKILL", "-p", "ControlGroup"])
props = dict(row.split("=", 1) for row in p.stdout.splitlines())
for key, value in {"RuntimeMaxUSec": "30s", "KillMode": "control-group", "KillSignal": "9",
                   "SendSIGKILL": "yes", "ControlGroup": own_group}.items():
    demand(props.get(key) == value, "wrong finite cleanup property: " + key)
old = query(["/usr/bin/systemctl", "--user", "show", UNIT, "-p", "LoadState",
             "-p", "ActiveState", "-p", "SubState", "-p", "ControlGroup"], (0, 1, 4))
old_props = dict(row.split("=", 1) for row in old.stdout.splitlines())
demand(old_props.get("LoadState") == "not-found" and old_props.get("ActiveState") == "inactive",
       "original unit is not verifiably gone")
demand(not os.path.lexists(CGROUP), "original cgroup path remains")
workers = []
for pid in PIDS:
    path = "/proc/" + str(pid)
    exists = os.path.lexists(path)
    workers.append({"pid": pid, "proc_entry_present": exists})
demand(not any(row["proc_entry_present"] for row in workers), "a recorded worker PID remains; no guessing")
print("INDEPENDENT_SCOPE_WORKERS=" + json.dumps({"unit_gone": True, "cgroup_gone": True,
      "recorded_pids": workers, "scope": "PID absence; no unrecorded creation-time claim"}), flush=True)
before = json.loads(sys.stdin.buffer.read(1024 * 1024)) if mode == "remove" else None
demand(os.path.realpath(ROOT) == ROOT, "scratch path not canonical")
parent = os.open("/tmp", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
root = os.open(ROOT.rsplit("/", 1)[1], os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
held = os.fstat(root)
demand(identity(held) == ROOT_ID and held.st_uid == 501 and stat.S_IMODE(held.st_mode) == 0o700,
       "scratch identity/custody changed")
files, directories = {}, {"": {"identity": identity(held), "mode": stat.S_IMODE(held.st_mode)}}

def walk(fd, prefix):
    names = {name[len(prefix):].split("/", 1)[0] for name in EXPECTED if name.startswith(prefix)}
    demand(set(os.listdir(fd)) == names, "unexpected ordinary inventory at " + prefix)
    for name in sorted(names):
        relative = prefix + name
        info = os.stat(name, dir_fd=fd, follow_symlinks=False)
        demand(info.st_uid == 501, "non-owned ordinary artifact")
        if stat.S_ISDIR(info.st_mode):
            child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            try:
                demand(identity(os.fstat(child)) == identity(info), "directory binding changed")
                demand(stat.S_IMODE(info.st_mode) == 0o700, "ordinary directory not private")
                directories[relative] = {"identity": identity(info), "mode": stat.S_IMODE(info.st_mode)}
                walk(child, relative + "/")
            finally: os.close(child)
        else:
            child = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
            try:
                start = os.fstat(child)
                demand(stat.S_ISREG(start.st_mode) and start.st_nlink == 1 and identity(start) == identity(info),
                       "not one exact regular artifact")
                pin = EXPECTED[relative]
                demand(start.st_size == pin["bytes"] and start.st_size <= 32 * 1024 * 1024,
                       "ordinary artifact length changed")
                data = bytearray()
                while len(data) <= pin["bytes"]:
                    part = os.read(child, 65536)
                    if not part: break
                    data.extend(part)
                demand(stable(os.fstat(child)) == stable(start), "artifact changed during preservation")
                demand(hashlib.sha256(data).hexdigest() == pin["sha256"], "artifact hash changed")
                if "device" in pin:
                    demand(identity(start) == [pin["device"], pin["inode"]], "completion artifact inode changed")
                files[relative] = {"identity": identity(start), "bytes": len(data), "sha256": pin["sha256"],
                                   "mode": stat.S_IMODE(start.st_mode)}
                if mode == "preserve": files[relative]["data_b64"] = base64.b64encode(data).decode("ascii")
            finally: os.close(child)
    if mode == "remove":
        expected_directory = before["directories"][prefix.rstrip("/")]
        demand(identity(os.fstat(fd)) == expected_directory["identity"], "preserved directory identity changed")
        for name in sorted(names):
            relative = prefix + name
            current = os.stat(name, dir_fd=fd, follow_symlinks=False)
            if relative in files:
                saved = before["files"][relative]
                demand(files[relative] == saved and identity(current) == saved["identity"],
                       "preserved file binding changed before unlink")
                os.unlink(name, dir_fd=fd)
                print("REMOVED_FILE=" + json.dumps({"relative": relative, "identity": saved["identity"]}), flush=True)
            else:
                saved = before["directories"][relative]
                demand(identity(current) == saved["identity"], "preserved empty directory name changed")
                os.rmdir(name, dir_fd=fd)
                print("REMOVED_DIRECTORY=" + json.dumps({"relative": relative, "identity": saved["identity"]}), flush=True)

try:
    walk(root, "")
    if mode == "remove":
        demand(set(files) == set(before["files"]) and set(directories) == set(before["directories"]),
               "preserved complete inventory differs")
        demand(identity(os.stat(ROOT.rsplit("/", 1)[1], dir_fd=parent, follow_symlinks=False)) == ROOT_ID,
               "root binding changed before final rmdir")
        os.rmdir(ROOT.rsplit("/", 1)[1], dir_fd=parent)
        demand(not os.path.lexists(ROOT), "root scratch removal unverified")
    print("RESULT=" + json.dumps({"mode": mode, "root": ROOT, "identity": ROOT_ID,
          "files": files, "directories": directories, "recorded_workers_absent": workers,
          "original_scope_gone": True, "scratch_removed": mode == "remove"}), flush=True)
finally:
    os.close(root)
    os.close(parent)
