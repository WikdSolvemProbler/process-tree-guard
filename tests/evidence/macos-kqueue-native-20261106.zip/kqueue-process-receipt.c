/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright 2026 Peter Shiller */

#define _DARWIN_C_SOURCE
#include <errno.h>
#include <inttypes.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <sys/event.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static bool registration(pid_t pid, uint32_t notes, const char *label, int expected, int *kept)
{
    int queue = kqueue();
    if (queue < 0) {
        perror("kqueue");
        return false;
    }
    const struct timespec immediate = {0, 0};
    struct kevent change, receipt = {0};
    EV_SET(&change, (uintptr_t)pid, EVFILT_PROC, EV_ADD | EV_RECEIPT, notes, 0, NULL);
    errno = 0;
    int count = kevent(queue, &change, 1, &receipt, 1, &immediate);
    int call_errno = errno;
    printf("registration=%s pid=%jd requested=%#x count=%d flags=%#x data=%jd errno=%d expected=%d\n",
           label, (intmax_t)pid, (unsigned)notes, count, (unsigned)receipt.flags,
           (intmax_t)receipt.data, call_errno, expected);
    bool ok = count == 1 && receipt.ident == (uintptr_t)pid &&
              receipt.filter == EVFILT_PROC && (receipt.flags & EV_ERROR) != 0 &&
              receipt.data == expected;
    if (ok && kept != NULL) {
        *kept = queue;
    } else {
        close(queue);
    }
    return ok;
}

static bool notification(int queue, pid_t pid, uint32_t notes, const char *label, intptr_t *data)
{
    const struct timespec deadline = {2, 0};
    struct kevent event = {0};
    errno = 0;
    int count = kevent(queue, NULL, 0, &event, 1, &deadline);
    int call_errno = errno;
    printf("notification=%s ident=%ju count=%d flags=%#x fflags=%#x data=%jd errno=%d\n",
           label, (uintmax_t)event.ident, count, (unsigned)event.flags,
           (unsigned)event.fflags, (intmax_t)event.data, call_errno);
    *data = event.data;
    return count == 1 && event.ident == (uintptr_t)pid && event.filter == EVFILT_PROC &&
           (event.flags & EV_ERROR) == 0 && event.fflags == notes;
}

static int64_t now_ms(void)
{
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) {
        return -1;
    }
    return (int64_t)now.tv_sec * 1000 + now.tv_nsec / 1000000;
}

enum reap_result { REAP_ERROR, REAP_PENDING, REAP_DONE };

static enum reap_result reap(pid_t child, int *status)
{
    int64_t started = now_ms();
    if (started < 0) {
        return REAP_ERROR;
    }
    for (;;) {
        pid_t result = waitpid(child, status, WNOHANG);
        if (result == child) {
            return REAP_DONE;
        }
        if (result < 0 && errno != EINTR) {
            return REAP_ERROR;
        }
        int64_t now = now_ms();
        if (now < 0) {
            return REAP_ERROR;
        }
        if (now - started >= 2000) {
            return result == 0 ? REAP_PENDING : REAP_ERROR;
        }
        const struct timespec delay = {0, 10000000};
        nanosleep(&delay, NULL);
    }
}

static _Noreturn void controlled_child(int release, int fork_queue)
{
    close(fork_queue);
    struct pollfd gate = {.fd = release, .events = POLLIN};
    unsigned char byte = 0;
    if (poll(&gate, 1, 8000) != 1 || read(release, &byte, 1) != 1 || byte != 'G') {
        _exit(91);
    }
    close(release);
    _exit(7);
}

int main(void)
{
    if (geteuid() == 0) {
        fprintf(stderr, "ordinary account required\n");
        return 1;
    }
    if (signal(SIGCHLD, SIG_DFL) == SIG_ERR || signal(SIGPIPE, SIG_IGN) == SIG_ERR) {
        perror("signal setup");
        return 1;
    }

    int fork_queue = -1;
    pid_t observer = getpid();
    if (!registration(observer, NOTE_FORK, "fork-control", 0, &fork_queue)) {
        return 1;
    }
    int release[2];
    if (pipe(release) != 0) {
        perror("pipe");
        close(fork_queue);
        return 1;
    }
    pid_t child = fork();
    if (child == 0) {
        close(release[1]);
        controlled_child(release[0], fork_queue);
    }
    if (child < 0) {
        perror("fork");
        close(release[0]);
        close(release[1]);
        close(fork_queue);
        return 1;
    }
    close(release[0]);
    printf("identity observer=%jd child=%jd observer_group=%jd child_group=%jd\n",
           (intmax_t)observer, (intmax_t)child, (intmax_t)getpgrp(), (intmax_t)getpgid(child));

    intptr_t fork_data = -1;
    bool group_ok = getpgid(child) == getpgrp();
    bool fork_ok = notification(fork_queue, observer, NOTE_FORK, "fork-control", &fork_data);
    close(fork_queue);

    int exit_queue = -1;
    bool track = registration(child, NOTE_FORK | NOTE_TRACK, "NOTE_TRACK", ENOTSUP, NULL);
    bool trackerr = registration(child, NOTE_FORK | NOTE_TRACKERR, "NOTE_TRACKERR", ENOTSUP, NULL);
    bool note_child = registration(child, NOTE_FORK | NOTE_CHILD, "NOTE_CHILD", ENOTSUP, NULL);
    bool exit_registered = registration(child, NOTE_EXIT | NOTE_EXITSTATUS, "exit-control", 0, &exit_queue);

    bool released = write(release[1], "G", 1) == 1;
    close(release[1]);
    intptr_t exit_data = -1;
    bool exit_ok = false;
    if (exit_registered) {
        exit_ok = notification(exit_queue, child, NOTE_EXIT | NOTE_EXITSTATUS, "exit-control", &exit_data);
        close(exit_queue);
    }

    int status = -1;
    enum reap_result natural = reap(child, &status);
    bool natural_reap = natural == REAP_DONE;
    bool fallback = natural == REAP_PENDING;
    if (fallback && kill(child, SIGKILL) != 0 && errno != ESRCH) {
        perror("kill exact unreaped child");
    }
    bool reaped = natural_reap || (fallback && reap(child, &status) == REAP_DONE);
    bool passed = group_ok && fork_ok && fork_data == 0 && track && trackerr && note_child &&
                  exit_registered && released && exit_ok && natural_reap &&
                  WIFEXITED(status) && WEXITSTATUS(status) == 7 && exit_data == status;
    printf("terminal passed=%d released=%d reaped=%d fallback=%d wait_status=%d\n",
           passed, released, reaped, fallback, status);
    return passed ? 0 : 1;
}
