$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/Users/Peter/process-tree-guard/target/codex-security/issue7-native-image-by-name-002'
$pins=@{
'header_trace.ps1'='bcdb9f324e5d81530d987c6e359a583ab74773d2f2c6a06d4f49c6f0e869743a'
'C:/Program Files (x86)/Windows Kits/10/Include/10.0.28000.0/um/winbase.h'='a7068b15a262cc2d4f0e51a1ca2f1514566d6f331562c6775235d560b3404d06'
'C:/Program Files (x86)/Windows Kits/10/Include/10.0.28000.0/um/winnt.h'='fb3d10c0dcc86c737c91652182b81f6bff33a189803570b8dcaa818c96c5b99a'
'C:/Program Files (x86)/Windows Kits/10/Include/10.0.28000.0/um/minwinbase.h'='7d1408f4b8eeba96ae45892209132258cde80cab6dab192b4cceea591972c78b'
'C:/Program Files (x86)/Windows Kits/10/Include/10.0.28000.0/shared/sdkddkver.h'='a80967a364c6c6974c4c80a7052aaa135cd3d236bf470ad038de2aaccb373cc0'
'by_name_control.c'='16cb0732d48a4ff46deb904f631fa493df76ad3bf3b779192073dec6c14717c7'
'build_native.cmd'='a196b4f05ebde48f738622ab5affd0ae134f3533e203e8c5b732a1a55e65faf3'
'C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe'='b0a1818ebae6da7f18230a84e76ce839212584ac4c2ab55b97a0d5268085da57'
'C:/Windows/System32/cmd.exe'='ccd79a7568ea9240ccd6fe124807b9d3e4dbc3a4cf92954299ac3029f4a91d02'
}
foreach($name in $pins.Keys){if((Get-FileHash -LiteralPath $name -Algorithm SHA256).Hash.ToLower() -ne $pins[$name]){throw "pin differs: $name"}}
foreach($name in @('build-001.stdout.log','build-001.stderr.log','build-001.exit.txt','build-receipt-001.json','by_name_control.exe','by_name_control.obj')){if(Test-Path -LiteralPath $name){throw "preexisting output: $name"}}
& 'C:/Windows/System32/cmd.exe' /d /c build_native.cmd 1>build-001.stdout.log 2>build-001.stderr.log
$buildExit=$LASTEXITCODE
Set-Content -LiteralPath build-001.exit.txt -Value $buildExit
$binaryHash=$null
if($buildExit -eq 0){$binaryHash=(Get-FileHash -LiteralPath by_name_control.exe -Algorithm SHA256).Hash.ToLower()}
if($buildExit -eq 0){
$parserBytes=[IO.File]::ReadAllBytes((Join-Path $PWD 'header_trace.ps1'))
$parserHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($parserBytes)).ToLower()
if($parserHash -ne 'bcdb9f324e5d81530d987c6e359a583ab74773d2f2c6a06d4f49c6f0e869743a'){throw 'parser bytes changed before execution'}
. ([scriptblock]::Create([Text.Encoding]::UTF8.GetString($parserBytes)))
$trace=(Get-Content -LiteralPath build-001.stdout.log -Raw)+(Get-Content -LiteralPath build-001.stderr.log -Raw)
$headerPins=@{
'C:/Program Files (x86)/Windows Kits/10/Include/10.0.28000.0/um/winbase.h'='a7068b15a262cc2d4f0e51a1ca2f1514566d6f331562c6775235d560b3404d06'
'C:/Program Files (x86)/Windows Kits/10/Include/10.0.28000.0/um/winnt.h'='fb3d10c0dcc86c737c91652182b81f6bff33a189803570b8dcaa818c96c5b99a'
'C:/Program Files (x86)/Windows Kits/10/Include/10.0.28000.0/um/minwinbase.h'='7d1408f4b8eeba96ae45892209132258cde80cab6dab192b4cceea591972c78b'
'C:/Program Files (x86)/Windows Kits/10/Include/10.0.28000.0/shared/sdkddkver.h'='a80967a364c6c6974c4c80a7052aaa135cd3d236bf470ad038de2aaccb373cc0'
}
$headerVerification=@(Get-PinnedHeaderTrace -Trace $trace -HeaderPins $headerPins)
if($headerVerification.Count -ne 4){throw 'four pinned SDK headers were not verified'}
}
$after=@{}
foreach($name in $pins.Keys){$after[$name]=(Get-FileHash -LiteralPath $name -Algorithm SHA256).Hash.ToLower();if($after[$name] -ne $pins[$name]){throw "pin changed: $name"}}
@{schema=1;compile_exit=$buildExit;source_sha256=$pins['by_name_control.c'];binary_sha256=$binaryHash;tool_source_pins=$after;os_version=[Environment]::OSVersion.Version.ToString();process_architecture=[Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture.ToString();compile_outer_seconds=60;native_payload_runs=0;header_verification=$headerVerification}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath build-receipt-001.json
Get-Content -LiteralPath build-001.stdout.log
Get-Content -LiteralPath build-001.stderr.log
exit $buildExit
