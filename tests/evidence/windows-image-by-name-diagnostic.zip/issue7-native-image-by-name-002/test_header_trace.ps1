$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/Users/Peter/process-tree-guard/target/codex-security/issue7-native-image-by-name-002'
$parserBytes=[IO.File]::ReadAllBytes((Join-Path $PWD 'header_trace.ps1'))
$parserHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($parserBytes)).ToLower()
if($parserHash -ne 'bcdb9f324e5d81530d987c6e359a583ab74773d2f2c6a06d4f49c6f0e869743a'){throw 'parser source differs'}
. ([scriptblock]::Create([Text.Encoding]::UTF8.GetString($parserBytes)))
$header='C:/Program Files (x86)/Windows Kits/10/Include/10.0.28000.0/um/winbase.h'
$pin=@{$header='a7068b15a262cc2d4f0e51a1ca2f1514566d6f331562c6775235d560b3404d06'}
$double=$header.Replace('/','\\')
$positive=@(Get-PinnedHeaderTrace -Trace ("Note: including file:  "+$double) -HeaderPins $pin)
if($positive.Count -ne 1 -or $positive[0].observations.Count -ne 1){throw 'doubled separator control failed'}
$negative=@(
    ("Note: including file: "+$header.Replace('10.0.28000.0','10.0.26100.0')),
    ("Note: including file: "+$header+"/extra"),
    ("warning text contains "+$header),
    ("Note: including file: C:/unrelated/"+$header.Substring(3)),
    ("Note: including file: winbase.h")
)
$refused=0
foreach($trace in $negative){
    try{Get-PinnedHeaderTrace -Trace $trace -HeaderPins $pin|Out-Null}
    catch{$refused++;continue}
    throw "invalid include trace accepted: $trace"
}
try{
    Get-PinnedHeaderTrace -Trace ("Note: including file: "+$header) -HeaderPins @{$header=('0'*64)}|Out-Null
    throw 'wrong hash accepted'
}catch{
    if($_.Exception.Message -eq 'wrong hash accepted'){throw}
    $refused++
}
try{
    Get-PinnedHeaderTrace -Trace ('Note: including file: '+$header) -HeaderPins @{}|Out-Null
    throw 'empty pin set accepted'
}catch{
    if($_.Exception.Message -eq 'empty pin set accepted'){throw}
    $refused++
}
@{kind='parser_tests';passed=8;negative_refusals=$refused;positive_repeated_separators=$true;benchmark_slots=0}|ConvertTo-Json -Compress
