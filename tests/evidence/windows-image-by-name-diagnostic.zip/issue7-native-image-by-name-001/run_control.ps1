$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/Users/Peter/process-tree-guard/target/codex-security/issue7-native-image-by-name-001'
$source='16cb0732d48a4ff46deb904f631fa493df76ad3bf3b779192073dec6c14717c7'
$build=Get-Content -LiteralPath build-receipt-001.json -Raw|ConvertFrom-Json
if($build.compile_exit -ne 0 -or $build.source_sha256 -ne $source){throw 'build not approved source'}
if((Get-FileHash -LiteralPath by_name_control.c -Algorithm SHA256).Hash.ToLower() -ne $source){throw 'source changed'}
if((Get-FileHash -LiteralPath by_name_control.exe -Algorithm SHA256).Hash.ToLower() -ne $build.binary_sha256){throw 'binary changed'}
foreach($name in @('native-001.jsonl','native-001.stderr.log','native-001.exit.txt','native-run-receipt-001.json')){if(Test-Path -LiteralPath $name){throw "preexisting output: $name"}}
$manifestPath='C:/Users/Peter/process-tree-guard/target/codex-security/issue7-quiet-launch-013/manifest.json'
$helperPath='C:/Users/Peter/process-tree-guard/target/codex-security/issue7-native-image-verification-001/native_image.py'
if((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLower() -ne '313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae'){throw 'reference manifest changed'}
if((Get-FileHash -LiteralPath $helperPath -Algorithm SHA256).Hash.ToLower() -ne '8adc1aa23a2298c3adab9ca561b621e8dccca4e78e59407aea39b9b08a2b9440'){throw 'reference helper changed'}
& ./by_name_control.exe 1>native-001.jsonl 2>native-001.stderr.log
$runExit=$LASTEXITCODE
Set-Content -LiteralPath native-001.exit.txt -Value $runExit
$after=@{}
foreach($name in @('by_name_control.c','by_name_control.exe','build_native.cmd',$manifestPath,$helperPath)){$after[$name]=(Get-FileHash -LiteralPath $name -Algorithm SHA256).Hash.ToLower()}
if($after['by_name_control.c'] -ne $source -or $after['by_name_control.exe'] -ne $build.binary_sha256 -or $after['build_native.cmd'] -ne 'a196b4f05ebde48f738622ab5affd0ae134f3533e203e8c5b732a1a55e65faf3' -or $after[$manifestPath] -ne '313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae' -or $after[$helperPath] -ne '8adc1aa23a2298c3adab9ca561b621e8dccca4e78e59407aea39b9b08a2b9440'){throw 'source/binary/reference changed'}
@{schema=1;run_exit=$runExit;source_binary_reference_after=$after;os_version=[Environment]::OSVersion.Version.ToString();process_architecture=[Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture.ToString();outer_seconds=30;inner_seconds=15;scope='standalone by-name SDK/export/field/timing observations; no collector equivalence';benchmark_slots=0}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath native-run-receipt-001.json
Get-Content -LiteralPath native-001.stderr.log
exit $runExit
