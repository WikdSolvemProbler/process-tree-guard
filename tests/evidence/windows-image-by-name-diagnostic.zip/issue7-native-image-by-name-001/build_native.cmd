@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Auxiliary/Build/vcvars64.bat" 10.0.28000.0
if errorlevel 1 exit /b %errorlevel%
echo SelectedWindowsSDKVersion=%WindowsSDKVersion%
"C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe" /nologo /Bv /showIncludes /std:c11 /W4 /WX /O2 by_name_control.c /Fe:by_name_control.exe /Fo:by_name_control.obj /link bcrypt.lib
exit /b %errorlevel%
