// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

use super::*;

const PR_SET_NO_NEW_PRIVS: c_int = 38;
const REQUEST_SECONDS: f64 = 5.0;
const POLICY_REFUSAL: &str = "verified identity refused by activation policy";

unsafe extern "C" {
    fn prctl(option: c_int, ...) -> c_int;
    fn getgroups(size: c_int, groups: *mut u32) -> c_int;
}

#[derive(Debug, PartialEq, Eq)]
struct VerifiedIdentity {
    uid: u32,
    gid: u32,
    groups: Vec<u32>,
}

struct PreparedRun {
    owner_pid: c_int,
    identity: VerifiedIdentity,
    plan: request::ExecPlan,
    lease: RetainedLease,
}

fn status_field<'a>(status: &'a str, name: &str) -> Probe<&'a str> {
    let mut fields = status.lines().filter_map(|line| line.strip_prefix(name));
    let value = fields
        .next()
        .ok_or_else(|| format!("missing process status field {name}"))?;
    check(fields.next().is_none(), "duplicate process status field")?;
    Ok(value.trim())
}

fn status_ids(status: &str, name: &str) -> Probe<Vec<u32>> {
    status_field(status, name)?
        .split_whitespace()
        .map(|id| {
            id.parse()
                .map_err(|_| format!("invalid process ID field {name}"))
        })
        .collect()
}

fn verify_identity(owner: &OwnedFd, peer: Credentials) -> Probe<VerifiedIdentity> {
    native(validate_pidfd(owner, peer, &mut NativeReceipt::default()))?;
    let status = io_result(fs::read_to_string(format!("/proc/{}/status", peer.pid)))?;
    check(
        peer.uid != 0
            && peer.gid != 0
            && status_ids(&status, "Uid:")? == [peer.uid; 4]
            && status_ids(&status, "Gid:")? == [peer.gid; 4],
        "owner credentials differ from the kernel transport identity",
    )?;
    for name in ["CapEff:", "CapPrm:", "CapInh:", "CapAmb:"] {
        check(
            status_field(&status, name)? == "0000000000000000",
            "owner retained capabilities",
        )?;
    }
    check(
        status_field(&status, "NoNewPrivs:")? == "1",
        "owner lacks NoNewPrivs",
    )?;
    let groups = status_ids(&status, "Groups:")?;
    check(!groups.contains(&0), "owner has a root supplementary group")?;
    // A PID exit or replacement during the numeric procfs lookup refuses preparation.
    native(validate_pidfd(owner, peer, &mut NativeReceipt::default()))?;
    Ok(VerifiedIdentity {
        uid: peer.uid,
        gid: peer.gid,
        groups,
    })
}

fn prepare(
    admitted: Admitted,
    admitted_ns: u64,
    authorizes: impl FnOnce(&VerifiedIdentity) -> bool,
) -> Probe<PreparedRun> {
    let Admitted { peer, owner, plan } = admitted;
    let identity = verify_identity(&owner, peer)?;
    check(authorizes(&identity), POLICY_REFUSAL)?;
    let lease = RetainedLease::from_owner(owner, plan.duration(), admitted_ns)?;
    check(
        lease.sample()?.decision == Decision::Permit,
        "owner or deadline became inactive during preparation",
    )?;
    Ok(PreparedRun {
        owner_pid: peer.pid,
        identity,
        plan,
        lease,
    })
}

fn native_groups() -> Probe<Vec<u32>> {
    let count = native(os_result(unsafe { getgroups(0, ptr::null_mut()) } as isize))?;
    check(count <= 65536, "native group count exceeds fixture limit")?;
    let mut groups = vec![0; count];
    let copied = native(os_result(
        unsafe { getgroups(count as c_int, groups.as_mut_ptr()) } as isize,
    ))?;
    check(copied == count, "native group snapshot changed")?;
    Ok(groups)
}

fn peer_fixture(listener: &Rendezvous, mut gate: UnixStream, until: Instant) -> Probe<c_int> {
    if unsafe { close(listener.fd.as_raw_fd()) } != 0 {
        return Err("failed to close inherited listener".into());
    }
    gate_read(&mut gate, b'G', until)?;
    // Tighten the ordinary test child's own task policy before it authenticates.
    native(os_result(unsafe {
        prctl(
            PR_SET_NO_NEW_PRIVS,
            1 as c_long,
            0 as c_long,
            0 as c_long,
            0 as c_long,
        )
    } as isize))?;
    let me = ordinary_credentials()?;
    let connection = connect_client(&listener.path)?;
    let owner = native(pidfd_for(me.pid))?;
    let frame = request::encode(
        REQUEST_SECONDS,
        &[b"/never-executed", b"", b"\xff prepared"],
    )
    .map_err(|error| format!("{error:?}"))?;
    native(send_packet(
        connection.as_raw_fd(),
        &frame,
        &[owner.as_raw_fd()],
    ))?;
    drop((connection, owner));
    gate_read(&mut gate, b'Q', until)?;
    Ok(OWNER_EXIT)
}

unsafe extern "C" {
    fn timerfd_gettime(fd: c_int, value: *mut ItimerSpec) -> c_int;
}

fn verify_plan(
    prepared: &PreparedRun,
    original_argv: *const *const c_char,
    original_owner: RawFd,
    admitted_ns: u64,
) -> Probe<u64> {
    let args = prepared.plan.arguments();
    let argv = prepared.plan.argv();
    let request_ns = u64::try_from(prepared.plan.duration().as_nanos())
        .map_err(|_| "native verifier request duration overflow")?;
    check(
        prepared.lease.owner.as_raw_fd() == original_owner
            && prepared.lease.admitted_ns == admitted_ns
            && prepared.lease.deadline_ns == admitted_ns + request_ns
            && prepared.plan.duration() == Duration::from_secs_f64(REQUEST_SECONDS)
            && args.len() == 3
            && prepared.plan.program().to_bytes() == b"/never-executed"
            && args[1].to_bytes().is_empty()
            && args[2].to_bytes() == b"\xff prepared"
            && argv.len() == args.len() + 1
            && argv.as_ptr() == original_argv
            && argv[..args.len()]
                .iter()
                .zip(args)
                .all(|(ptr, arg)| *ptr == arg.as_ptr())
            && argv.last().is_some_and(|pointer| pointer.is_null()),
        "prepared run did not retain its original fd, argument vector or absolute budget",
    )?;
    native(close_on_exec(prepared.lease.owner.as_raw_fd()))?;
    native(close_on_exec(prepared.lease.timer.as_raw_fd()))?;
    let mut active = ItimerSpec {
        interval: Timespec::default(),
        value: Timespec::default(),
    };
    native(os_result(
        unsafe { timerfd_gettime(prepared.lease.timer.as_raw_fd(), &mut active) } as isize,
    ))?;
    let seconds = u64::try_from(active.value.seconds).map_err(|_| "negative timer remainder")?;
    let nanoseconds =
        u64::try_from(active.value.nanoseconds).map_err(|_| "negative timer fraction")?;
    check(
        nanoseconds < NS_PER_SECOND
            && active.interval.seconds == 0
            && active.interval.nanoseconds == 0,
        "absolute timer is periodic or its fraction is invalid",
    )?;
    let remaining = seconds
        .checked_mul(NS_PER_SECOND)
        .and_then(|n| n.checked_add(nanoseconds))
        .ok_or("native timer remainder overflow")?;
    check(
        remaining > 0 && remaining <= request_ns,
        "absolute timer remainder is outside the original budget",
    )?;
    Ok(remaining)
}

fn run_lane(
    listener: &Rendezvous,
    parent: Credentials,
    group: c_int,
    scope: &str,
    expected_identity: &VerifiedIdentity,
    allow: bool,
) -> Probe<()> {
    let label = if allow { "allow" } else { "deny" };
    let before = descriptor_count()?;
    let until = Instant::now() + LANE_BOUND;
    let (mut owner_gate, client_gate) = io_result(UnixStream::pair())?;
    for gate in [&owner_gate, &client_gate] {
        io_result(gate.set_nonblocking(true))?;
        native(close_on_exec(gate.as_raw_fd()))?;
    }
    let pid = unsafe { fork() };
    native(os_result(pid as isize))?;
    if pid == 0 {
        drop(owner_gate);
        child_exit(peer_fixture(listener, client_gate, until));
    }
    drop(client_gate);
    let mut owner = DirectChild::new(pid);
    let verdict: Probe<()> = (|| {
        owner.hold(parent, group, scope)?;
        gate_write(&mut owner_gate, b'G')?;
        let connection = listener.accept(until)?;
        let fd = connection.as_raw_fd();
        wait_fd(fd, POLLIN, until)?;
        let mut receipt = NativeReceipt::default();
        let admitted = native(receive_observed(fd, &mut receipt))?;
        let admitted_ns = boottime_ns()?;
        let peer = Credentials { pid, ..parent };
        check(
            receipt.peer == Some(peer)
                && receipt.sender == Some(peer)
                && receipt.rights == 1
                && receipt.pidfd_cloexec
                && receipt.pidfd_pid == Some(pid)
                && receipt.pidfd_revents == Some(0)
                && admitted.peer == peer,
            "unexpected authenticated owner receipt",
        )?;
        let original_owner = admitted.owner.as_raw_fd();
        check(
            original_owner != owner.fd()?,
            "transferred pidfd aliases independent descriptor number",
        )?;
        let original_argv = admitted.plan.argv().as_ptr();
        let pre_prepare = descriptor_count()?;
        let mut verified = false;
        let outcome = prepare(admitted, admitted_ns, |identity| {
            verified = identity == expected_identity;
            allow && verified
        });
        check(
            verified,
            "activation policy did not see the verified identity",
        )?;
        if allow {
            check(
                descriptor_count()? == pre_prepare + 1,
                "prepared run handle count differs",
            )?;
        } else {
            check(
                descriptor_count()? + 1 == pre_prepare,
                "refused run retained a handle",
            )?;
        }
        wait_fd(fd, POLLIN | POLLHUP, until)?;
        let mut eof = NativeReceipt::default();
        check(
            matches!(receive_observed(fd, &mut eof), Err(Refusal::EmptyPacket)) && eof.rights == 0,
            "preparation transport did not reach native EOF",
        )?;
        drop(connection);
        match (allow, outcome) {
            (true, Ok(prepared)) => {
                check(
                    prepared.identity == *expected_identity && prepared.owner_pid == pid,
                    "prepared run identity differs",
                )?;
                let remaining = verify_plan(&prepared, original_argv, original_owner, admitted_ns)?;
                check(
                    prepared.lease.sample()?.decision == Decision::Permit,
                    "prepared run lost its owner after transport EOF",
                )?;
                gate_write(&mut owner_gate, b'Q')?;
                wait_fd(prepared.lease.owner.as_raw_fd(), POLLIN, until)?;
                check(
                    prepared.lease.sample()?.decision == Decision::OwnerLost,
                    "prepared run did not retain its original owner identity",
                )?;
                owner.reap(until, OWNER_EXIT)?;
                println!("prepared_lane={label} pid={pid} identity={:?} argv=owned_original retained_pidfd=verified transport=eof_closed admitted_ns={} deadline_ns={} remaining_ns={remaining} owner_loss=verified exit={OWNER_EXIT}",
                         prepared.identity, prepared.lease.admitted_ns, prepared.lease.deadline_ns);
            }
            (false, Err(reason)) if reason == POLICY_REFUSAL => {
                gate_write(&mut owner_gate, b'Q')?;
                owner.reap(until, OWNER_EXIT)?;
                println!("prepared_lane={label} pid={pid} identity=verified policy=refused handles=closed transport=eof_closed exit={OWNER_EXIT}");
            }
            (_, Err(error)) => return Err(error),
            (_, Ok(_)) => return Err("denied activation returned a prepared run".into()),
        }
        Ok(())
    })();
    drop(owner_gate);
    if let Err(error) = owner.settle() {
        return Err(format!(
            "prepared lane {label} disposition={verdict:?} cleanup={error}"
        ));
    }
    drop(owner);
    verdict?;
    check(
        descriptor_count()? == before,
        "prepared lane descriptor baseline changed",
    )?;
    println!("prepared_lane={label} descriptors=settled");
    Ok(())
}

pub(super) fn run() -> Probe<()> {
    let args: Vec<_> = std::env::args_os().collect();
    check(
        args.len() == 2,
        "supply the exact preparation scratch directory",
    )?;
    let parent = ordinary_credentials()?;
    let group = unsafe { getpgrp() };
    let scope = io_result(fs::read_to_string("/proc/self/cgroup"))?;
    let expected = VerifiedIdentity {
        uid: parent.uid,
        gid: parent.gid,
        groups: native_groups()?,
    };
    let before = descriptor_count()?;
    let listener = Rendezvous::create(Path::new(&args[1]), parent.uid)?;
    let verdict: Probe<()> = (|| {
        for allow in [true, false] {
            run_lane(&listener, parent, group, &scope, &expected, allow)?;
        }
        Ok(())
    })();
    verdict.and(listener.remove())?;
    check(
        descriptor_count()? == before,
        "prepared controller descriptor baseline changed",
    )?;
    println!(
        "prepared_run=passed lanes=2 listener=unlinked descriptors=settled boundary=pre_cgroup"
    );
    Ok(())
}
