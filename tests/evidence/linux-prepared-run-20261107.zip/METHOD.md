# Linux PreparedRun boundary

PreparedRun moves the authenticated PTGEX2 argument plan and its original transferred owner pidfd into one prepared state. The controller records CLOCK_BOOTTIME immediately after packet authentication. Before arming the lease it verifies the kernel-owned caller identity and invokes the selected identity policy. A permitted request receives one absolute timer derived from the original admission sample and the decoded timeout.

The identity check brackets the procfs status read with validation of the same received pidfd. It compares all four UID and GID fields with the transport identity, checks zero effective, permitted, inherited and ambient capabilities, requires NoNewPrivs and refuses the root supplementary group. The allowlist receives only the resulting verified identity. This follows the scope of the archived fixed-command proof's identity verifier. [Archived external admission source and evidence](https://github.com/WikdSolvemProbler/process-tree-guard/blob/8d18bad/tests/evidence/linux-external-admission-20261106.zip)

The ordinary-user verifier runs the prior four transport lanes and three release lanes before the two PreparedRun lanes. The two new lanes each authenticate a direct child with the same ordinary UID and GID. Only that disposable child tightens its own NoNewPrivs flag before connecting. The controller compares the verified supplementary groups with a native getgroups snapshot.

| Lane | Required receipt |
| --- | --- |
| Allow | Original argv pointer array and owned strings, including an empty argument and non-UTF-8 bytes, survive the move. The transferred close-on-exec pidfd remains the owner handle. The original five-second budget produces one live absolute timer. Native transport EOF leaves the prepared owner active, and the retained pidfd later signals when the original direct child exits 23 |
| Deny | Policy sees the same verified identity and refuses it. The original transferred fd is closed on return and no timer remains. Native transport EOF and original direct-child exit 23 are verified |

Both new lanes verify descriptor baselines, direct-child reaping and group and scope membership. They use the existing three-second observation and one-second failed-child cleanup bounds. The outer authorized scope separately limits the complete process tree. The controller unlinks the original owner-only rendezvous after both lanes. The new boundary finishes before any cgroup leaf allocation, permit write, credential transition or payload execution. The caller's command is an inspection-only byte string.

The previous transport and cross-peer sources are unchanged. The release source factors out the lease constructor and adds the preparation entry point. The preparation source owns the verified identity, original ExecPlan and retained lease. The first local metadata attempt found a missing c_char import. Attempt 001 and its compiler output remain preserved. Attempt 002 adds that import and passes the local formatting and metadata checks. The metadata derivative substitutes placeholder Unix-only standard library types on Windows. Native GNU Linux execution supplies the runtime result.

Preserve these paths in the native input. The sole argument is the already-created canonical owner-only 0700 scratch directory. Use the approved finite ordinary-user Linux scope.

```text
rustc --edition=2021 -D warnings -C linker=/usr/bin/gcc target/codex-security/issue2-linux-prepared-run-002/transport.rs -o prepared-run
umask 077
./prepared-run "$tree"
```

| Input | SHA-256 |
| --- | --- |
| target/codex-security/issue2-linux-prepared-run-002/transport.rs | 907472caaa18f3e4a288f323c8969d85b5b0e494bcfad2cbf65357d24185fee9 |
| target/codex-security/issue2-linux-prepared-run-002/cross_peer.rs | dab5eb3884ff1711d4396aa422b795cf5747c06a8d647f731e4250028dcd4091 |
| target/codex-security/issue2-linux-prepared-run-002/release_lease.rs | 8b148c0f6a8a445af0e577a669d233c74eed1c75ec4dfd8311e54d70ece20bf4 |
| target/codex-security/issue2-linux-prepared-run-002/prepared_run.rs | 099fd24a9d0eb741c2fde8c0c796495923bfea60c81f16b5ab432c78fdf58e74 |
| target/codex-security/issue2-linux-generic-request-001/request.rs | 6531478a6cb85c31ba4639c01c144c789968178df57b64d3d128073a8d91b4c4 |
| src/deadline.rs | 56252eb28270b4743d73e17e05ae933d3fad8168e7b4ba34405e859be9c85c53 |

The native ABI matches the prior 64-bit Linux fixture. PreparedRun is an input for a future supervisor that owns a verified cgroup leaf. Production activation policy, cgroup authority and cleanup integration, stdio and environment handling, kernel-floor support and concurrent lifecycle qualification remain open.
