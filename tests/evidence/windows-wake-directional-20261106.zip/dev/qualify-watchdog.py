"""Untimed synthetic proof of the capture path's asynchronous Job deadline."""

import argparse
import importlib.util
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
DRIVER = HERE / "qualify-suspended.py"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--deadline", type=int, choices=(1, 3, 10), required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    if out.parent != HERE:
        raise ValueError("choose a fresh adjacent receipt directory")
    out.mkdir(exist_ok=False)
    source = DRIVER.read_bytes()
    spec = importlib.util.spec_from_file_location("watchdog_suspended", DRIVER)
    D = importlib.util.module_from_spec(spec)
    exec(compile(source, str(DRIVER), "exec"), D.__dict__)
    row = dict(scope="untimed asynchronous watchdog qualification", passed=False,
               driver_sha256=D.hashlib.sha256(source).hexdigest(), proof_script_sha256=D.sha(Path(__file__)))
    try:
        S, N, P = (D.load(role) for role in ("support", "native", "policy"))
        row["outer"] = S.outer_identity()
        fixture, expected_sha = D.INPUTS["testkit"]
        D.require(D.sha(fixture) == expected_sha, "testkit digest mismatch")
        row["testkit_sha256"] = expected_sha
        D.arm(N, P, S, row, out, [str(fixture), "sleep", "30"], args.deadline,
              D.WATCHDOG_EXIT, b"", expect_watchdog=True)
        row["passed"] = True
    except Exception as error:
        row["error"] = repr(error)
    finally:
        D.save(out / "receipt.json", row)
    return 0 if row["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
