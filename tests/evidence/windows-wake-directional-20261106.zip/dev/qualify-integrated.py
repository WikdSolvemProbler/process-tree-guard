"""Fixture-only integrated qualification. No admission or candidate execution."""

import argparse
import hashlib
import importlib.util
from pathlib import Path
import sys
import time


HERE = Path(__file__).resolve().parent
DRIVER = HERE / "capture.py"
OPERATIONAL_KEYS = (
    "schema", "candidate_commits", "driver_sha256", "suspended_sha256",
    "analysis_sha256", "schedule_generator_sha256", "python_sha256",
    "schedule_sha256", "schedule", "arm_sha256", "control_ids", "cwd", "assets",
    "qualification_receipts", "child_environment_sha256", "environment_binding",
    "telemetry", "launch", "runtime_hold_bindings",
)


def operational_digest(A, manifest):
    return A.sha(A.canon({key: manifest[key] for key in OPERATIONAL_KEYS}).encode())


def load_capture():
    raw = DRIVER.read_bytes()
    spec = importlib.util.spec_from_file_location("integrated_bound_capture", DRIVER)
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(DRIVER), "exec"), module.__dict__)
    return module, hashlib.sha256(raw).hexdigest()


def fixture_selection(plan):
    seen = set()
    rows = []
    for row in plan:
        if row["phase"] == "control":
            rows.append(row)
        elif row["phase"] == "measured" and row["arm"] == "bare":
            key = (row["macroblock"] // 20, row["workload"])
            if key not in seen:
                seen.add(key)
                rows.append(row)
    if len(rows) != 19 or len(seen) != 4:
        raise ValueError("unexpected fixture-only integrated selection")
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    out = args.out.resolve()
    if out.parent != HERE:
        raise ValueError("choose a fresh adjacent receipt directory")
    out.mkdir(exist_ok=False)
    C, driver_sha = load_capture()
    A = C.A
    receipt = dict(scope="fixture-only integrated preflight; no candidate arm or admission",
                   passed=False, driver_sha256=driver_sha, proof_source_sha256=C.hash_file(Path(__file__)),
                   manifest_sha256=args.manifest_sha256, cases=[], telemetry=[])
    hold = None
    try:
        raw = args.manifest.read_bytes()
        A.require(A.sha(raw) == args.manifest_sha256, "preflight manifest hash mismatch")
        manifest = A.parse(raw)
        A.require(manifest["driver_sha256"] == driver_sha and manifest["timed_capture_authorized"] is False,
                  "expected non-admitted manifest and frozen driver")
        receipt["operational_inputs_sha256"] = operational_digest(A, manifest)
        A.require(manifest["analysis_sha256"] == C.ANALYSIS_SHA
                  and manifest["schedule_generator_sha256"] == A.SCHEDULE_SOURCE_SHA
                  and manifest["python_sha256"] == C.hash_file(Path(sys.executable)),
                  "analysis, schedule generator or interpreter changed")
        schedule_raw = Path(manifest["schedule"]["path"]).read_bytes()
        plan = A.parse(schedule_raw)
        A.require(A.sha(schedule_raw) == manifest["schedule_sha256"]
                  and C.schedule.schedule_bytes(plan["seed_hex"]) == schedule_raw,
                  "frozen schedule mismatch")
        A.require(tuple(manifest["control_ids"]) == A.CONTROL_IDS, "control order mismatch")
        D = C.load_suspended(manifest["suspended_sha256"])
        A.require(str(D.CWD) == manifest["cwd"] and D.CWD.is_dir(), "cwd mismatch")
        for role, (path, digest) in D.INPUTS.items():
            A.require(manifest["assets"][role] == {"path": str(path), "sha256": digest}
                      and C.hash_file(path) == digest, f"{role} asset mismatch")
        bindings = C.runtime_hold_bindings(manifest)
        A.require(bindings == manifest["runtime_hold_bindings"], "runtime hold manifest differs")
        hold = C.RuntimeHold(bindings)
        receipt["asset_hold"] = {"share_mode": "FILE_SHARE_READ", "before": hold.acquire()}
        receipt["denied_access"] = {role: hold.prove_denied_access(D.INPUTS[role][0])
                                    for role in ("testkit", "fixture")}
        S, N, P = (D.load(role) for role in ("support", "native", "policy"))
        receipt["qualification_receipts"] = C.qualification_receipts(manifest, D, S.OUTER_SHA)
        expected_env = manifest["child_environment_sha256"]
        A.require(D.environment_block(P)[1]["utf16_sha256"] == expected_env, "preflight environment mismatch")
        C.__file__ = __file__
        receipt["controller_argv"] = C.controller_argv()
        receipt["outer_guards"], cutoff = C.guard_chain(S, manifest)
        A.verify_outer_receipt(manifest, receipt)
        origin = C.telemetry(S)
        receipt["host_telemetry_origin"] = origin
        selected = fixture_selection(plan["rows"])
        checkpoints = set(A.checkpoint_indexes(selected)[:-1])
        seen = set()
        last_settled = origin["monotonic_ns"]
        for expected in selected:
            A.require(time.monotonic() < cutoff, "independent guard cutoff reached")
            index = expected["index"]
            sample = None
            if index in checkpoints:
                sample = dict(index=index, **C.telemetry(S))
                receipt["telemetry"].append(sample)
                A.require(not any(A.telemetry_flags(origin, receipt["telemetry"], manifest["telemetry"]).values()),
                          "preflight host telemetry gate failed")
            folder = out / f"{index:04}"
            folder.mkdir()
            row = dict(scheduled=expected, status="INCOMPLETE", oracle={"passed": False})
            receipt["cases"].append(row)
            argv, budget, exit_code, stdout, marker = C.make_case(D, expected, folder, row)
            row["argv"] = argv
            C.write_record(folder / "prepared.json", row)
            try:
                A.require(expected["phase"] == "control" or expected["arm"] == "bare",
                          "candidate forbidden in integrated preflight")
                D.arm(N, P, S, row, folder, argv, budget, exit_code, stdout, marker=marker,
                      capture=True, expected_env_sha256=expected_env)
                A.verify_armed_deadline(row, budget, f"row {index}")
                A.validate_argv(row, manifest, out)
                identity = (row["suspended"]["pid"], row["suspended"]["creation_filetime"])
                A.require(identity not in seen and last_settled < row["start_ns"] <
                          row["measurement_end_ns"] < row["settled_ns"], "identity reuse or overlapping arm")
                seen.add(identity)
                if sample is not None:
                    A.require(last_settled <= sample["monotonic_ns"] <= row["start_ns"],
                              "telemetry sample crossed its arm boundary")
                last_settled = row["settled_ns"]
                if expected["phase"] == "control":
                    A.validate_control(row, row["control_id"])
                else:
                    A.require(row["identity_before"] == row["identity_after"]
                              and row["wait"]["process_handle"] == row["exit"]["process_handle"] ==
                              row["create"]["process_handle"] and row["wait"]["native_return"] == 0
                              and row["exit"]["exit_code_u32"] == 0 and not row.get("trusted_cleanup_requested"),
                              "bare fixture native endpoint did not hold")
                row.update(status="PASS", oracle={"passed": True})
            except Exception as error:
                row.update(status="FAIL", error=repr(error))
                raise
            finally:
                C.write_record(folder / "final.json", row)
        end = dict(index=len(plan["rows"]), **C.telemetry(S))
        receipt["telemetry"].append(end)
        A.require(last_settled <= end["monotonic_ns"] and
                  not any(A.telemetry_flags(origin, receipt["telemetry"], manifest["telemetry"]).values()),
                  "terminal telemetry gate failed")
        A.verify_raw_rows(out, receipt["cases"])
        receipt["asset_hold"]["after"] = hold.verify()
        A.verify_asset_holds(manifest, receipt)
        receipt["passed"] = True
    except BaseException as error:
        receipt["error"] = repr(error)
    finally:
        try:
            C.write_record(out / "receipt.json", receipt)
        finally:
            if hold is not None:
                hold.resources.close()
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
