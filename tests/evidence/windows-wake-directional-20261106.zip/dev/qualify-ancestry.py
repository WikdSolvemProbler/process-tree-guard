"""Exercise the capture ancestry check without executing a capture or fixture."""

import argparse
import ctypes as C
from ctypes import wintypes as W
import importlib.util
from pathlib import Path
import sys

import _winapi

_capture_path = Path(__file__).resolve().with_name("capture.py")
_capture_source = _capture_path.read_bytes()
_capture_spec = importlib.util.spec_from_file_location("bound_ancestry_capture", _capture_path)
capture = importlib.util.module_from_spec(_capture_spec)
exec(compile(_capture_source, str(_capture_path), "exec"), capture.__dict__)


GUARD = Path("C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe")
ROOT_SECONDS = 30
BACKUP_SECONDS = 45


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    output = args.out.resolve()
    if output.parent != Path(__file__).resolve().parent:
        raise ValueError("choose a fresh adjacent receipt directory")
    D = capture.load_suspended()
    S = D.load("support")
    receipt = {"purpose": "synthetic ancestry proof only", "passed": False,
               "capture_driver_sha256": capture.hash_file(Path(capture.__file__))}
    try:
        # The verifier normally derives its own controller argv from __file__.
        # Bind this probe's real entry point without calling capture admission.
        capture.__file__ = __file__
        policy = dict(root_path=str(GUARD), backup_path=str(GUARD),
                      root_sha256=S.OUTER_SHA, backup_sha256=S.OUTER_SHA,
                      root_seconds=ROOT_SECONDS, backup_seconds=BACKUP_SECONDS,
                      reserve_seconds=12)
        receipt["verified_chain"], _ = capture.guard_chain(S, {"launch": policy})
        membership = {}
        current = _winapi.GetCurrentProcess()
        root = _winapi.OpenProcess(S.SYNC_QUERY, False, receipt["verified_chain"]["root"]["pid"])
        try:
            for name, handle in (("controller", current), ("root_guard", root)):
                member = W.BOOL()
                S.native_ok(S.is_member(handle, None, C.byref(member)))
                membership[name] = bool(member.value)
            if membership != {"controller": True, "root_guard": True}:
                raise RuntimeError("expected the root guard and controller to be contained")
        finally:
            _winapi.CloseHandle(root)
        receipt["job_membership_any"] = membership
        receipt["passed"] = True
    except Exception as error:
        receipt["error"] = repr(error)
    finally:
        capture.write_record(output, receipt)
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
