"""Untimed owner, deadline and normal-return cleanup qualification."""

import argparse
import ctypes as C
from ctypes import wintypes as W
import importlib.util
import os
from pathlib import Path
import sys
import time

import _winapi


HERE = Path(__file__).resolve().parent
BASE = HERE / "qualify-suspended.py"


def load_driver():
    spec = importlib.util.spec_from_file_location("qualification_suspended", BASE)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    return driver


def hold(S, name, marker, job, deadline, handles, row):
    while True:
        try:
            pid = int(marker.read_text(encoding="ascii").strip())
            break
        except (FileNotFoundError, PermissionError):
            S.check(time.monotonic() < deadline, f"{name} did not publish a readable PID")
            time.sleep(0.005)
    handle = _winapi.OpenProcess(S.SYNC_QUERY, False, pid)
    handles[name] = handle
    identity = S.snapshot(handle, job)
    row[f"{name}_live_before_trigger"] = identity
    S.check(identity["pid"] == pid and identity["member"] and identity["native_wait"] == 258,
            f"{name} was not held live in the qualification Job")
    return handle


def read_image(S, handle):
    size = W.DWORD(32768)
    path = C.create_unicode_buffer(size.value)
    S.native_ok(S.image_name(handle, 0, path, C.byref(size)))
    return Path(path.value)


def await_exit(S, handle, job, deadline, expected, name, row):
    remaining_ms = max(0, int((deadline - time.monotonic()) * 1000))
    S.check(_winapi.WaitForSingleObject(handle, remaining_ms) == 0, f"{name} did not signal")
    state = S.snapshot(handle, job)
    row[f"{name}_before_cleanup"] = state
    S.check(state["native_wait"] == 0 and state["exit_code_u32"] == expected,
            f"{name} exit was {state['exit_code_u32']}, expected {expected}")


def expect_gone(S, names, job, handles, row):
    for name in names:
        state = S.snapshot(handles[name], job)
        row[f"{name}_before_cleanup"] = state
        prior = row[f"{name}_live_before_trigger"]
        S.check(state["native_wait"] == 0 and
                (state["pid"], state["creation_filetime"]) ==
                (prior["pid"], prior["creation_filetime"]),
                f"original {name} was not gone at guard return")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    D = load_driver()
    out = args.out.resolve()
    D.require(out.parent == HERE, "choose a fresh adjacent receipt directory")
    out.mkdir(exist_ok=False)
    receipt = dict(scope="untimed native owner and descendant qualification",
                   driver_sha256=D.sha(Path(__file__)), suspended_driver_sha256=D.sha(BASE),
                   passed=False, cases=[])
    try:
        receipt["inputs"] = {}
        for name, (path, expected) in D.INPUTS.items():
            actual = D.sha(path)
            receipt["inputs"][name] = {"path": str(path), "sha256": actual}
            D.require(actual == expected, f"{name} digest mismatch")
        S, N, P = (D.load(role) for role in ("support", "native", "policy"))
        receipt["outer"] = S.outer_identity()
        testkit = str(D.INPUTS["testkit"][0])
        for role in ("wake", "main"):
            exe = D.INPUTS[role][0]
            for mode in ("manual", "auto"):
                for contract in ("owner-exits", "deadline", "normal-exit"):
                    name = f"{role}-{mode}-{contract}"
                    folder = out / name
                    folder.mkdir()
                    row = dict(case=name, passed=False)
                    receipt["cases"].append(row)
                    guard = [str(exe), *(["auto"] if mode == "auto" else []),
                             "--timeout", "2" if contract == "deadline" else "6", "--"]
                    marked = [testkit, "deep", "1", "2", str(folder), "5"]
                    if contract == "owner-exits":
                        pid_file, go = folder / "guard.pid", folder / "go"
                        argv = [testkit, "own-guard", str(pid_file), str(go), "4", *guard, *marked]
                        expected, stderr = 0, b""
                    elif contract == "deadline":
                        argv = [*guard, *marked]
                        expected, stderr = 124, None
                    else:
                        marker = folder / "leaf.pid"
                        go = folder / "go"
                        argv = [*guard, testkit, "spawn-marked", "0", str(go), "4",
                                testkit, "mark", str(marker), "5"]
                        expected, stderr = 0, b""

                    def observe(root, job, deadline, handles, record):
                        ready = min(deadline, time.monotonic() + (1.8 if contract == "deadline" else 3.0))
                        guard_handle = root
                        if contract == "owner-exits":
                            guard_handle = hold(S, "candidate", pid_file, job, ready, handles, record)
                            image = read_image(S, guard_handle)
                            record["candidate_image"] = str(image)
                            D.require(os.path.normcase(str(image)) == os.path.normcase(str(exe)),
                                      "published candidate image differs from the pinned executable")
                        if contract == "normal-exit":
                            hold(S, "leaf", marker, job, ready, handles, record)
                            names = ("leaf",)
                        else:
                            hold(S, "payload", folder / "1.pid", job, ready, handles, record)
                            hold(S, "leaf", folder / "2.pid", job, ready, handles, record)
                            names = ("payload", "leaf")
                        if contract != "deadline":
                            D.require(S.snapshot(root, job)["native_wait"] == 258, "owner or candidate exited before GO")
                            D.require(S.snapshot(guard_handle, job)["native_wait"] == 258, "candidate exited before GO")
                            go.write_bytes(b"go")
                            record["go_published_after_holds"] = True
                        if contract == "owner-exits":
                            await_exit(S, root, job, deadline, 0, "owner", record)
                            await_exit(S, guard_handle, job, deadline, 125, "candidate", record)
                        else:
                            await_exit(S, guard_handle, job, deadline, expected, "candidate", record)
                        expect_gone(S, names, job, handles, record)

                    try:
                        D.arm(N, P, S, row, folder, argv, 9, expected, b"", observe=observe,
                              expected_stderr=stderr)
                        if contract == "deadline":
                            D.require(b"PROCESS_TIMEOUT" in bytes.fromhex(row["streams_before_cleanup"]["stderr_hex"]),
                                      "timeout diagnostic missing")
                        D.require(not row.get("trusted_cleanup_requested"), "external cleanup needed")
                        row["passed"] = True
                    except Exception as error:
                        row["error"] = repr(error)
                        raise
                    finally:
                        D.save(folder / "receipt.json", row)
        receipt["passed"] = True
    except Exception as error:
        receipt["error"] = repr(error)
    finally:
        D.save(out / "receipt.json", receipt)
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
