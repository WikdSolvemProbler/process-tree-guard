# Windows Wake directional development evidence

This package preserves the observed-load MSVC comparison from one Windows x64
laptop on 6 November 2026. The exact candidates were frozen main
`8bf828a467e03d9f5f249a9da76b5845df53d057` and Windows-repaired Wake
`9c6f0df93cee92dcaca0e89ebc3f09134eeab53d`. The Wake snapshot descends from
`681ad2300ff86826c600eeccadc4063dedb46b66`.

The completed run had 2,967 slots, including 2,880 measured arms, 72 warmup
arms, and 15 controls. The only directional result among the 16 prespecified
contrasts was manual startup raw p90. Main minus repaired Wake was +7.9079 ms,
with a nominal primary interval of [+2.6032, +17.0082] ms. Both block-length
sensitivities agreed. The other 15 contrasts were unresolved. The intervals
are conditional on the stationary weak-dependence approximation. This
observed-load comparison does not establish equivalence or fulfill the
separate quiet-host acceptance.

## Evidence and provenance

- `dev/directional-capture-002/` contains the aggregate capture and every
  prepared row, final row, native stream and fixture marker. The matching
  external terminal receipt is `dev/directional-capture-002-terminal.json`.
- `dev/` also contains the frozen analyzer, schedule, capture source, operational
  manifest, exact admission, and the zero-row failed capture and terminal
  receipt. That first attempt stopped at environment admission.
- The native qualification receipts include the 31 untimed endpoint, safety,
  and asynchronous deadline cases, the integrated 19-case fixture run, and
  selected earlier failed qualification receipts.
- `build/` contains the matched-build receipts and logs, exact main source
  archive, repaired Wake source snapshot, source identity record, and available
  original Git blob bytes. A snapshot and lineage receipt are supplied for
  Wake because the canonical repository does not carry its Git commit object.
- `binary-map.json` maps included executable bytes to their historical
  absolute paths and SHA-256 digests. The Windows SDK, Python and PowerShell
  binaries are identified in the receipts and are not redistributed here.
- `environment-summary.json` preserves the whole sanitized environment digest
  and the verified source of launch-context divergence. Private per-key probe
  files and raw environment values are omitted.

## Replay on Windows

Extract the complete archive to a short path. Use 64-bit CPython 3.12.10 and
run the wrapper under a finite whole-process guard from the extracted folder.
The destination must be a fresh file outside the extracted evidence package.

```powershell
process-tree-guard --timeout 600 -- python -B .\replay.py --out C:\Temp\wake-replay.json
```

The wrapper checks every listed SHA-256, verifies the terminal capture receipt,
and runs the unchanged analyzer. It redirects only manifest-bound absolute
qualification receipt reads to the verified copies in this archive. It
compares the 16 replayed results and supporting calculations to the archived
output, allowing the printed Python version metadata to differ. Replay
starts no candidates, fixtures, or child processes.
