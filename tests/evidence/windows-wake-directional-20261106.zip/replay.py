"""Verify this package and replay its frozen Windows analysis without workloads."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
import runpy
import sys


HERE = Path(__file__).resolve().parent
DEV = HERE / "dev"


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verify_inventory():
    seen = set()
    for line in (HERE / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        path = (HERE / name).resolve()
        if path == HERE or not path.is_relative_to(HERE) or path in seen or sha(path) != digest:
            raise ValueError(f"package checksum mismatch: {name}")
        seen.add(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if os.name != "nt":
        parser.error("the frozen analysis verifies Windows-native historical paths")
    out = args.out.resolve()
    if out.is_relative_to(HERE) or out.exists():
        parser.error("choose a fresh output outside the evidence package")
    verify_inventory()
    manifest = DEV / "capture-manifest-operational-003.json"
    admission = DEV / "capture-admission-002.json"
    capture = DEV / "directional-capture-002" / "capture.json"
    analysis = DEV / "analysis.py"
    schedule = DEV / "schedule-review.json"
    accepted = json.loads(manifest.read_bytes())
    old_dev = PureWindowsPath(accepted["launch_recipe"]["controller_argv_template"][2]).parent
    redirects = {}
    for binding in accepted["qualification_receipts"].values():
        old = PureWindowsPath(binding["path"])
        local = DEV.joinpath(*old.relative_to(old_dev).parts)
        if sha(local) != binding["sha256"]:
            raise ValueError(f"qualification checksum mismatch: {local}")
        redirects[os.path.normcase(str(old))] = local
    terminal = json.loads((DEV / "directional-capture-002-terminal.json").read_bytes())
    if terminal["capture_sha256"] != sha(capture) or terminal["process"]["exit_code"] != 0:
        raise ValueError("capture terminal receipt mismatch")
    argv = [str(analysis), "--manifest", str(manifest), "--manifest-sha256", sha(manifest),
            "--schedule", str(schedule), "--admission", str(admission), "--admission-sha256", sha(admission),
            "--capture", str(capture), "--capture-sha256", sha(capture), "--out", str(out)]
    # The frozen analyzer reads a small manifest-bound set of absolute historical
    # qualification paths. Redirect just those byte reads to verified copies.
    original_read = Path.read_bytes
    original_argv = sys.argv

    def read_bound(path):
        return original_read(redirects.get(os.path.normcase(os.fspath(path)), path))

    try:
        Path.read_bytes = read_bound
        sys.argv = argv
        runpy.run_path(str(analysis), run_name="__main__")
    finally:
        sys.argv = original_argv
        Path.read_bytes = original_read
    expected = json.loads((DEV / "analysis-002.json").read_bytes())
    replayed = json.loads(out.read_bytes())
    expected.pop("python_version")
    replayed.pop("python_version")
    if replayed != expected:
        raise ValueError("replayed analysis differs from the archived result")
    print("Verified package, capture and all 16 replayed endpoint results.")


if __name__ == "__main__":
    main()
