set -eu
umask 077
tag=ptg-owner002-macos-47d8f47-001
tree=$(/usr/bin/mktemp -d "/tmp/$tag.XXXXXXXX")
case "$tree" in "/tmp/$tag."*) ;; *) exit 125;; esac
[ -d "$tree" ] && [ ! -L "$tree" ]
cleanup() {
    result=$?
    trap - EXIT
    case "$tree" in "/tmp/$tag."*) ;; *) exit 125;; esac
    if [ ! -L "$tree" ] && /bin/rm -rf -- "$tree" && [ ! -e "$tree" ]; then
        printf 'test_scratch_removed=%s\n' "$tree"
    else
        printf 'test_scratch_present=%s\n' "$tree"
        result=125
    fi
    exit "$result"
}
trap cleanup EXIT
printf 'test_scratch=%s\n' "$tree"
printf 'shell_pid=%s shell_pgid=%s\n' "$$" "$(/bin/ps -o pgid= -p "$$")"
/bin/cat > "$tree/payload.tar.gz"
[ "$(/usr/bin/shasum -a 256 "$tree/payload.tar.gz" | /usr/bin/cut -d ' ' -f 1)" = 'da7f9f4db3607ca6ca1288d935edf03a798315f109329706977241eb91aef67b' ]
/usr/bin/tar -xzf "$tree/payload.tar.gz" -C "$tree"
[ "$(/usr/bin/shasum -a 256 "$tree/tests/tests/test_campaign_logic.py" | /usr/bin/cut -d ' ' -f 1)" = 'bcf6359af3af7c6f76da96d5174854a202a3342742dfd88e911429682a83b117' ]
/usr/bin/uname -srm
/opt/homebrew/bin/python3.12 --version
cd "$tree/tests/tests"
/usr/bin/env -u PTG_SUITE_BUILD -u PYTHONPATH -u PYTHONHOME PYTHONDONTWRITEBYTECODE=1 /opt/homebrew/bin/python3.12 -B -c 'import unittest
from test_campaign_logic import OwnerVerificationTimingTests as Case
names = ("run_live_sleeping_launcher_gate", "run_live_inside_delay_gate")
loader = unittest.TestLoader()
assert len(loader.getTestCaseNames(Case)) == 3
assert not set(names).intersection(loader.getTestCaseNames(Case))
for name in names:
    suite = loader.loadTestsFromName("test_campaign_logic.OwnerVerificationTimingTests." + name)
    assert suite.countTestCases() == 1 and not loader.errors
    assert next(iter(suite)).id().endswith("." + name)
    print("live_explicit_load=1 executed=0 method=" + name)
'
/usr/bin/env -u PTG_SUITE_BUILD -u PYTHONPATH -u PYTHONHOME PYTHONDONTWRITEBYTECODE=1 /opt/homebrew/bin/python3.12 -B -m unittest -v test_campaign_logic.OwnerVerificationTimingTests
