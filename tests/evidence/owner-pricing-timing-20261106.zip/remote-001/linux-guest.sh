set -eu
umask 077
tag=ptg-owner-linux-47d8f47-004
tree=$(/usr/bin/mktemp -d "/tmp/$tag.XXXXXXXX")
case "$tree" in "/tmp/$tag."*) ;; *) exit 125;; esac
[ -d "$tree" ] && [ ! -L "$tree" ]
cleanup() {
    result=$?
    trap - EXIT
    case "$tree" in "/tmp/$tag."*) ;; *) exit 125;; esac
    if [ ! -L "$tree" ] && /bin/rm -rf -- "$tree" && [ ! -e "$tree" ]; then
        printf 'test_scratch_removed=%s\n' "$tree"
    else
        printf 'test_scratch_present=%s\n' "$tree"
        result=125
    fi
    exit "$result"
}
trap cleanup EXIT
printf 'test_scratch=%s\n' "$tree"
/usr/bin/cat /proc/self/cgroup
/usr/bin/systemctl --user show ptg-owner-linux-47d8f47-004.scope -p RuntimeMaxUSec -p KillMode -p KillSignal
/bin/cat > "$tree/payload.tar.gz"
[ "$(/usr/bin/sha256sum "$tree/payload.tar.gz" | /usr/bin/cut -d ' ' -f 1)" = '2137f6e0fc8edfeec6d5f1069a3cc14edf74aabe1e6f6de175013c17152213d1' ]
/usr/bin/tar -xzf "$tree/payload.tar.gz" -C "$tree"
[ "$(/usr/bin/sha256sum "$tree/tests/tests/test_campaign_logic.py" | /usr/bin/cut -d ' ' -f 1)" = '1684c8663c698a6ef6a7eb307a5a7d379d10d5dc86395a32fe77a1a6689ad7e7' ]
/usr/bin/uname -srm
/usr/bin/python3 --version
cd "$tree/tests/tests"
/usr/bin/env -u PTG_SUITE_BUILD -u PYTHONPATH -u PYTHONHOME PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -B -m unittest -v \
    test_campaign_logic.OwnerVerificationTimingTests.test_sleeping_launcher_does_not_move_the_owner_price \
    test_campaign_logic.OwnerVerificationTimingTests.test_launcher_delay_inside_the_bracket_moves_the_owner_price \
    test_campaign_logic.OwnerVerificationTimingTests.test_refusing_launcher_is_infra_failure_never_a_price
