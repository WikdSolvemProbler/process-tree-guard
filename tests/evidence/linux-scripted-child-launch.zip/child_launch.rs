// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

//! Compile-only child boundary. The parent must establish native placement
//! and lease ownership before supplying a release decision.

use std::ffi::{c_char, CStr, CString};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Stage {
    ClearAmbient,
    Groups,
    Gid,
    Uid,
    NoNewPrivs,
    Exec,
}

#[derive(Debug, PartialEq, Eq)]
enum Failure {
    NotPlaced,
    OwnerLost,
    Deadline,
    Child { stage: Stage, errno: i32 },
}

enum Release {
    Permit,
    OwnerLost,
    Deadline,
}

struct Identity {
    uid: u32,
    gid: u32,
    groups: Vec<u32>,
}

struct LaunchPlan {
    identity: Identity,
    arguments: Vec<CString>,
    argv: Vec<*const c_char>,
    environment: Vec<CString>,
    envp: Vec<*const c_char>,
}

fn vector(entries: &[CString]) -> Vec<*const c_char> {
    entries
        .iter()
        .map(|entry| entry.as_ptr())
        .chain(std::iter::once(std::ptr::null()))
        .collect()
}

impl LaunchPlan {
    fn new(identity: Identity, arguments: Vec<CString>) -> Option<Self> {
        if identity.uid == 0
            || identity.gid == 0
            || identity.groups.contains(&0)
            || arguments.first()?.to_bytes().first() != Some(&b'/')
        {
            return None;
        }
        // An explicit fixture environment prevents inheritance from the
        // controller. General caller environment policy is still open.
        let environment = vec![c"LANG=C".to_owned()];
        Some(Self {
            identity,
            argv: vector(&arguments),
            envp: vector(&environment),
            arguments,
            environment,
        })
    }

    fn release(self, placed: bool, decision: Release) -> Result<Permitted, Failure> {
        if !placed {
            return Err(Failure::NotPlaced);
        }
        match decision {
            Release::Permit => Ok(Permitted(self)),
            Release::OwnerLost => Err(Failure::OwnerLost),
            Release::Deadline => Err(Failure::Deadline),
        }
    }
}

struct Permitted(LaunchPlan);

trait ChildOps {
    fn clear_ambient(&mut self) -> Result<(), i32>;
    fn set_groups(&mut self, groups: &[u32]) -> Result<(), i32>;
    fn set_gid(&mut self, ids: [u32; 3]) -> Result<(), i32>;
    fn set_uid(&mut self, ids: [u32; 3]) -> Result<(), i32>;
    fn set_no_new_privs(&mut self) -> Result<(), i32>;
    fn exec(
        &mut self,
        program: &CStr,
        argv: &[*const c_char],
        envp: &[*const c_char],
    ) -> Result<std::convert::Infallible, i32>;
}

impl Permitted {
    fn execute(&self, ops: &mut impl ChildOps) -> Failure {
        let plan = &self.0;
        let identity = &plan.identity;
        let mut run = || -> Result<std::convert::Infallible, Failure> {
            let failure = |stage| move |errno| Failure::Child { stage, errno };
            ops.clear_ambient().map_err(failure(Stage::ClearAmbient))?;
            ops.set_groups(&identity.groups)
                .map_err(failure(Stage::Groups))?;
            ops.set_gid([identity.gid; 3])
                .map_err(failure(Stage::Gid))?;
            ops.set_uid([identity.uid; 3])
                .map_err(failure(Stage::Uid))?;
            ops.set_no_new_privs().map_err(failure(Stage::NoNewPrivs))?;
            debug_assert_eq!(plan.envp.len(), plan.environment.len() + 1);
            ops.exec(&plan.arguments[0], &plan.argv, &plan.envp)
                .map_err(failure(Stage::Exec))
        };
        match run() {
            Ok(never) => match never {},
            Err(failure) => failure,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const ORDER: [Stage; 6] = [
        Stage::ClearAmbient,
        Stage::Groups,
        Stage::Gid,
        Stage::Uid,
        Stage::NoNewPrivs,
        Stage::Exec,
    ];

    struct Script {
        stop: Stage,
        seen: Vec<Stage>,
    }

    impl Script {
        fn step(&mut self, stage: Stage) -> Result<(), i32> {
            self.seen.push(stage);
            if stage == self.stop {
                Err(2)
            } else {
                Ok(())
            }
        }
    }

    impl ChildOps for Script {
        fn clear_ambient(&mut self) -> Result<(), i32> {
            self.step(Stage::ClearAmbient)
        }
        fn set_groups(&mut self, groups: &[u32]) -> Result<(), i32> {
            assert_eq!(groups, [999, 1000]);
            self.step(Stage::Groups)
        }
        fn set_gid(&mut self, ids: [u32; 3]) -> Result<(), i32> {
            assert_eq!(ids, [1000; 3]);
            self.step(Stage::Gid)
        }
        fn set_uid(&mut self, ids: [u32; 3]) -> Result<(), i32> {
            assert_eq!(ids, [501; 3]);
            self.step(Stage::Uid)
        }
        fn set_no_new_privs(&mut self) -> Result<(), i32> {
            self.step(Stage::NoNewPrivs)
        }
        fn exec(
            &mut self,
            program: &CStr,
            argv: &[*const c_char],
            envp: &[*const c_char],
        ) -> Result<std::convert::Infallible, i32> {
            assert_eq!(program, c"/never-executed");
            assert_eq!(argv.len(), 4);
            assert_eq!(envp.len(), 2);
            assert_eq!(argv[0], program.as_ptr());
            assert!(argv[3].is_null() && envp[1].is_null());
            // The permitted plan owns these three buffers throughout the call.
            unsafe {
                assert_eq!(CStr::from_ptr(argv[1]), c"");
                assert_eq!(CStr::from_ptr(argv[2]).to_bytes(), b"\xff prepared");
                assert_eq!(CStr::from_ptr(envp[0]), c"LANG=C");
            }
            self.step(Stage::Exec)?;
            unreachable!("the scripted exec must return an errno")
        }
    }

    fn plan() -> LaunchPlan {
        LaunchPlan::new(
            Identity {
                uid: 501,
                gid: 1000,
                groups: vec![999, 1000],
            },
            vec![
                c"/never-executed".to_owned(),
                c"".to_owned(),
                CString::new(&b"\xff prepared"[..]).unwrap(),
            ],
        )
        .unwrap()
    }

    #[test]
    fn release_refuses_missing_placement_and_inactive_lease() {
        for (placed, decision, failure) in [
            (false, Release::Permit, Failure::NotPlaced),
            (true, Release::OwnerLost, Failure::OwnerLost),
            (true, Release::Deadline, Failure::Deadline),
        ] {
            assert_eq!(plan().release(placed, decision).err(), Some(failure));
        }
    }

    #[test]
    fn setup_failures_stop_before_exec_and_exec_errno_is_distinct() {
        for (index, stop) in ORDER.into_iter().enumerate() {
            let allowed = plan().release(true, Release::Permit).unwrap();
            let mut script = Script {
                stop,
                seen: Vec::new(),
            };
            assert_eq!(
                allowed.execute(&mut script),
                Failure::Child {
                    stage: stop,
                    errno: 2
                }
            );
            assert_eq!(script.seen, ORDER[..=index]);
        }
    }
}
