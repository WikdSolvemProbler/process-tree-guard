# Windows correctness reruns

Each full run started from a Git archive of the recorded revision, under an
isolated Windows Job. The staged release binaries were checked against their
build receipt and the suite recorded its tree SHA. The final run also rehashed
each staged binary after the suite.

The first run lacked the fourth deep PID at the fixture's original deadline.
The second run passed that test and failed the wide-72 setup before its atomic
PID list appeared. The final patch separated bounded setup for the two large
count cases from the two-second kill interval, and used smaller sleepers.
The full rerun passed 643 tests with four skips. Negative controls continued
to reject incomplete publication.

The archive includes the earlier full failures, the injected-delay receipt,
the Job count diagnostic, the two fixture patches, focused Linux output, and
the final 647 per-test certificates. These are correctness results for the
listed snapshots. The separate performance comparison has its own archive.
