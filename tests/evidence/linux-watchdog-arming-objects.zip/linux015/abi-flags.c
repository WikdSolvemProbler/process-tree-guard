#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
int main(void) {
    printf("abi_cflags O_DIRECTORY=%d O_NOFOLLOW=%d O_PATH=%d O_CLOEXEC=%d O_NONBLOCK=%d O_WRONLY=%d\n",
           O_DIRECTORY, O_NOFOLLOW, O_PATH, O_CLOEXEC, O_NONBLOCK, O_WRONLY);
    return 0;
}