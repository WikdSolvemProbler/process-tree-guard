// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller
#ifndef PTG_CHILD_FIXTURE_H
#define PTG_CHILD_FIXTURE_H
#include <stddef.h>
#include <stdint.h>

/* Parent owns every nonnegative returned descriptor. No FD is client input. */
struct ptg_spawn_frame {
    uint32_t schema;
    int32_t result;
    int32_t call_errno;
    int32_t pid;
    int32_t pidfd;
    int32_t timerfd;
    int32_t gate_read;
    int32_t gate_write;
    int32_t ready_read;
    int32_t ready_write;
    int32_t setup_close_errno;
    uint32_t signal_preflight_bits;
    uint64_t child_deadline_ns;
    uint64_t before_arm_ns;
    uint64_t after_arm_ns;
    uint64_t before_clone_ns;
    uint64_t after_clone_ns;
    uint64_t armed_remaining_ns;
};
_Static_assert(sizeof(struct ptg_spawn_frame) == 96, "spawn frame size");
_Static_assert(_Alignof(struct ptg_spawn_frame) == 8, "spawn frame alignment");
_Static_assert(offsetof(struct ptg_spawn_frame, child_deadline_ns) == 48, "spawn timestamp offset");

uint64_t ptg_fixture_spawn_abi(uint32_t word);
uint64_t ptg_fixture_now(int32_t *error);
int32_t ptg_fixture_ordinary(int32_t *error, uint32_t *facts);
void ptg_fixture_spawn(uint32_t mode, uint64_t until_ns, struct ptg_spawn_frame *out);
int32_t ptg_fixture_signal(int32_t pidfd, uint32_t which, int32_t *error);
int32_t ptg_fixture_poll(int32_t event, int32_t timer, int32_t *event_bits,
                         int32_t *timer_bits, int32_t *error);
#endif
