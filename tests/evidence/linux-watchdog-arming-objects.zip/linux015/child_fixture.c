// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller
#define _GNU_SOURCE 1
#include "child_fixture.h"
#include <errno.h>
#include <fcntl.h>
#include <linux/sched.h>
#include <poll.h>
#include <signal.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/timerfd.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

_Static_assert(sizeof(pid_t) == 4 && (pid_t)-1 < 0, "native PID width");
_Static_assert(sizeof(struct clone_args) == 88, "installed clone_args size");
_Static_assert(offsetof(struct clone_args, pidfd) == 8, "native clone pidfd offset");
_Static_assert(offsetof(struct clone_args, exit_signal) == 32, "native clone signal offset");
_Static_assert(sizeof(time_t) == 8, "native clock seconds width");

uint64_t ptg_fixture_spawn_abi(uint32_t word) {
    switch (word) {
    case 0: return 1;
    case 1: return sizeof(struct ptg_spawn_frame);
    case 2: return _Alignof(struct ptg_spawn_frame);
    case 3: return offsetof(struct ptg_spawn_frame, child_deadline_ns);
    case 4: return SYS_clone3;
    case 5: return CLONE_PIDFD;
    case 6: return SYS_pidfd_send_signal;
    case 7: return SIGCHLD;
    case 8: return SIGTERM;
    case 9: return SIGKILL;
    case 10: return CLOCK_BOOTTIME;
    case 11: return TFD_TIMER_ABSTIME;
    case 12: return ECHILD;
    case 13: return EINTR;
    case 14: return ESRCH;
    case 15: return POLLIN;
    case 16: return POLLHUP;
    case 17: return POLLERR;
    default: return UINT64_MAX;
    }
}

uint64_t ptg_fixture_now(int32_t *error) {
    struct timespec now;
    if (clock_gettime(CLOCK_BOOTTIME, &now) != 0) {
        *error = errno;
        return 0;
    }
    if (now.tv_sec < 0 || now.tv_nsec < 0 || now.tv_nsec >= 1000000000L) {
        *error = EINVAL;
        return 0;
    }
    *error = 0;
    return (uint64_t)now.tv_sec * UINT64_C(1000000000) + (uint64_t)now.tv_nsec;
}

int32_t ptg_fixture_ordinary(int32_t *error, uint32_t *facts) {
    struct sigaction term, child;
    sigset_t mask;
    *facts = 0;
    if (getuid() == 0 || getgid() == 0 || getuid() != geteuid() || getgid() != getegid()) {
        *error = EPERM;
        return -1;
    }
    *facts |= 1;
    if (sigaction(SIGTERM, NULL, &term) != 0 || sigaction(SIGCHLD, NULL, &child) != 0
            || sigprocmask(SIG_BLOCK, NULL, &mask) != 0) {
        *error = errno;
        return -1;
    }
    if (term.sa_handler == SIG_DFL) *facts |= 2;
    if (sigismember(&mask, SIGTERM) == 0) *facts |= 4;
    if (child.sa_handler == SIG_DFL) *facts |= 8;
    if ((child.sa_flags & SA_NOCLDWAIT) == 0) *facts |= 16;
    if (sigismember(&mask, SIGCHLD) == 0) *facts |= 32;
    if (*facts != 63) {
        *error = EINVAL;
        return -1;
    }
    *error = 0;
    return 0;
}

/* Called only in the child after a fork-like clone without CLONE_VM. No Rust,
 * allocation, stdio, lock, exec or new process is used. All waits watch the
 * timerfd that was armed before clone, including EINTR retries. */
static _Noreturn void child_main(uint32_t mode, int timer, int gate,
                                 int ready, pid_t parent) {
    if (getppid() != parent) _exit(90);
    struct pollfd initial = { .fd = timer, .events = POLLIN };
    if (poll(&initial, 1, 0) != 0) _exit(124);
    const unsigned char token = 'R';
    if (write(ready, &token, 1) != 1) _exit(91);
    if (close(ready) != 0) _exit(92);
    if (mode == 1) _exit(23);
    for (;;) {
        struct pollfd waits[2] = {
            { .fd = timer, .events = POLLIN },
            { .fd = gate, .events = POLLIN }
        };
        const int result = poll(waits, 2, -1);
        if (result < 0 && errno == EINTR) continue;
        if (result <= 0) _exit(93);
        if (waits[0].revents != 0) _exit(124);
        if (waits[1].revents != POLLIN) _exit(94);
        unsigned char byte = 0;
        if (read(gate, &byte, 1) != 1) _exit(95);
        if (mode == 2 && byte == 'G') _exit(29);
        _exit(96);
    }
}

void ptg_fixture_spawn(uint32_t mode, uint64_t until_ns, struct ptg_spawn_frame *out) {
    memset(out, 0, sizeof(*out));
    out->schema = 1;
    out->result = -1;
    out->pid = out->pidfd = out->timerfd = -1;
    out->gate_read = out->gate_write = out->ready_read = out->ready_write = -1;
    out->child_deadline_ns = until_ns;
    int32_t error = 0;
    if (mode < 1 || mode > 3 || ptg_fixture_ordinary(&error, &out->signal_preflight_bits) != 0) {
        out->call_errno = error != 0 ? error : EINVAL;
        return;
    }
    out->before_arm_ns = ptg_fixture_now(&error);
    if (error != 0 || until_ns <= out->before_arm_ns
            || until_ns - out->before_arm_ns > UINT64_C(3000000000)) {
        out->call_errno = error != 0 ? error : EINVAL;
        return;
    }
    out->timerfd = timerfd_create(CLOCK_BOOTTIME, TFD_CLOEXEC | TFD_NONBLOCK);
    if (out->timerfd < 0) { out->call_errno = errno; return; }
    const struct itimerspec arm = {
        .it_value = { .tv_sec = (time_t)(until_ns / UINT64_C(1000000000)),
                      .tv_nsec = (long)(until_ns % UINT64_C(1000000000)) }
    };
    if (timerfd_settime(out->timerfd, TFD_TIMER_ABSTIME, &arm, NULL) != 0) {
        out->call_errno = errno; return;
    }
    struct itimerspec retained;
    if (timerfd_gettime(out->timerfd, &retained) != 0) { out->call_errno = errno; return; }
    out->armed_remaining_ns = (uint64_t)retained.it_value.tv_sec * UINT64_C(1000000000)
                              + (uint64_t)retained.it_value.tv_nsec;
    out->after_arm_ns = ptg_fixture_now(&error);
    if (error != 0 || out->armed_remaining_ns == 0 || out->after_arm_ns >= until_ns) {
        out->call_errno = error != 0 ? error : ETIMEDOUT; return;
    }
    int gate[2];
    if (pipe2(gate, O_CLOEXEC | O_NONBLOCK) != 0) { out->call_errno = errno; return; }
    out->gate_read = gate[0]; out->gate_write = gate[1];
    int ready[2];
    if (pipe2(ready, O_CLOEXEC | O_NONBLOCK) != 0) { out->call_errno = errno; return; }
    out->ready_read = ready[0]; out->ready_write = ready[1];
    const pid_t parent = getpid();
    struct clone_args args;
    memset(&args, 0, sizeof(args));
    args.flags = CLONE_PIDFD;
    args.pidfd = (uint64_t)(uintptr_t)&out->pidfd;
    args.exit_signal = SIGCHLD;
    out->before_clone_ns = ptg_fixture_now(&error);
    if (error != 0 || out->before_clone_ns >= until_ns) {
        out->call_errno = error != 0 ? error : ETIMEDOUT; return;
    }
    const long result = syscall(SYS_clone3, &args, sizeof(args));
    if (result == 0) {
        if (close(out->gate_write) != 0 || close(out->ready_read) != 0) _exit(97);
        child_main(mode, out->timerfd, out->gate_read, out->ready_write, parent);
    }
    if (result < 0) { out->call_errno = errno; return; }
    out->pid = (int32_t)result;
    out->result = 1;
    out->after_clone_ns = ptg_fixture_now(&error);
    /* A post-clone clock error is a positive-clone custody error, never refusal. */
    out->call_errno = error;
}

int32_t ptg_fixture_signal(int32_t pidfd, uint32_t which, int32_t *error) {
    if (which > 1) { *error = EINVAL; return -1; }
    const int result = (int)syscall(SYS_pidfd_send_signal, pidfd,
                                   which == 0 ? SIGTERM : SIGKILL, NULL, 0);
    *error = result < 0 ? errno : 0;
    return result;
}

int32_t ptg_fixture_poll(int32_t event, int32_t timer, int32_t *event_bits,
                         int32_t *timer_bits, int32_t *error) {
    struct pollfd watched[2] = {
        { .fd = event, .events = POLLIN }, { .fd = timer, .events = POLLIN }
    };
    const int result = poll(watched, 2, -1);
    *error = result < 0 ? errno : 0;
    *event_bits = watched[0].revents;
    *timer_bits = watched[1].revents;
    return result;
}
