// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller
// Separate kernel-UAPI translation unit: never mix libc sigset_t with this ABI.
#include "native_arming.h"
#include <asm-generic/signal.h>
#include <asm/unistd.h>
#if !defined(__linux__) || !(defined(__aarch64__) || defined(__x86_64__))
#error "kernel signal ABI is restricted to Linux LP64 ARM64/x86-64"
#endif
_Static_assert(sizeof(unsigned long)==8 && sizeof(uint64_t)==8,"LP64 kernel word");
_Static_assert(_NSIG==64 && _NSIG_WORDS==1,"kernel64-signal set");
_Static_assert(sizeof(sigset_t)==8,"kernel rt_sigprocmask set size, NOT libc sigset_t");
_Static_assert(SIG_SETMASK==2 && SIGKILL==9 && SIGSTOP==19,"kernel signal constants");
uint64_t ptg_arm_kernel_signal_abi(uint32_t word) {
    switch(word) {
    case 0:return sizeof(sigset_t);
    case 1:return _NSIG;
    case 2:return SIG_SETMASK;
    case 3:return __NR_rt_sigprocmask;
    case 4:return SIGKILL;
    case 5:return SIGSTOP;
    case 6:return sizeof(unsigned long);
    default:return UINT64_MAX;
    }
}
