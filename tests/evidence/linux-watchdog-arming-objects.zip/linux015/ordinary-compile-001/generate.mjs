// Source-only finite plan assembly. No subprocess/SSH/compiler/native call.
import fs from 'node:fs/promises';
import path from 'node:path';
import zlib from 'node:zlib';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),arm=path.dirname(here);
const repo=path.dirname(path.dirname(path.dirname(arm)));
const sha=b=>createHash('sha256').update(b).digest('hex');
const put=(name,data)=>fs.writeFile(path.join(here,name),data,{flag:'wx'});
const quote=s=>"'"+s.replaceAll("'","'\"'\"'")+"'";
const shell=a=>a.map(quote).join(' ');
function windowsArg(s){if(s&&!/[\s\"]/.test(s))return s;let out='"',slashes=0;for(let c of s){if(c==='\\'){slashes++;continue}if(c==='"'){out+='\\'.repeat(slashes*2+1)+'"';slashes=0;continue}out+='\\'.repeat(slashes)+c;slashes=0}return out+'\\'.repeat(slashes*2)+'"'}
export async function generate(){
 const candidateRaw=await fs.readFile(path.join(arm,'source-candidate.json'));
 if(sha(candidateRaw)!=='3f21e307dc788cc4cbda5224f8061b3a0d5940d7679377ca8f34291f5e3620d4')throw Error('source freeze differs');
 const candidate=JSON.parse(candidateRaw),captured={};
 for(let[n,p]of Object.entries(candidate.files)){let b=await fs.readFile(path.join(arm,n));if(sha(b)!==p.sha256||b.length!==p.bytes)throw Error('source '+n);captured['target/codex-security/issue2-linux-arming-015/'+n]=b}
 captured['target/codex-security/issue2-linux-arming-015/source-candidate.json']=candidateRaw;
 for(let[n,p]of Object.entries(candidate.external_dependencies)){let b=await fs.readFile(path.join(repo,n));if(sha(b)!==p.sha256||b.length!==p.bytes)throw Error('external '+n);captured[n]=b}
 const expected=Object.fromEntries(Object.entries(captured).map(([n,b])=>[n,{bytes:b.length,sha256:sha(b)}]));
 const raw=Buffer.from(JSON.stringify({files:Object.fromEntries(Object.entries(captured).map(([n,b])=>[n,b.toString('base64')]))})+'\n');
 if(raw.length>4*1024*1024)throw Error('raw packet bound');
 const packet=zlib.gzipSync(raw,{level:9});if(packet.length>1024*1024)throw Error('compressed packet bound');
 await put('payload.json.gz',packet);await put('source-packet-index.json',JSON.stringify(expected,null,2)+'\n');
 const template=await fs.readFile(path.join(here,'guest_controller.template.py'),'utf8');
 const driver=template.replace('@EXPECTED_JSON@',JSON.stringify(expected)).replace('@PAYLOAD_SHA256@',sha(packet));
 if(/@EXPECTED_JSON@|@PAYLOAD_SHA256@/.test(driver))throw Error('unreplaced marker');
 await put('guest_controller.py',driver);
 const driverRaw=Buffer.from(driver),driverCompressed=zlib.gzipSync(driverRaw,{level:9});if(driverRaw.length>131072||driverCompressed.length>65536)throw Error('driver bound');
 const bootstrap='import base64,hashlib,zlib\n'+'packed=base64.b64decode('+JSON.stringify(driverCompressed.toString('base64'))+',validate=True)\n'+
 'assert len(packed)<=65536\nd=zlib.decompressobj(31)\nraw=d.decompress(packed,131073)\n'+
 'assert len(raw)<=131072 and d.eof and not d.unused_data and not d.unconsumed_tail\n'+
 'assert hashlib.sha256(raw).hexdigest()=='+JSON.stringify(sha(driverRaw))+'\n'+
 'exec(compile(raw,"<sealed-ordinary015>","exec"),{"__name__":"__main__"})\n';
 await put('guest-bootstrap.py.txt',bootstrap);
 const guestArgv=['/usr/bin/timeout','--signal=KILL','--kill-after=3s','75s','/usr/bin/systemd-run','--user','--scope','--quiet','--expand-environment=no','--unit','ptg-native-arming-015.scope','-p','RuntimeMaxSec=70s','-p','KillMode=control-group','-p','KillSignal=SIGKILL','-p','SendSIGKILL=yes','--','/usr/bin/python3','-I','-B','-c',bootstrap];
 const macTool='/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout',macHash='6a7b0620313d337d70366cd4d3b969b49854abfeb1db602bdf3328122e223c6d';
 const preflight='set -eu\ntest "$(/usr/bin/id -u)" = 501\n'+"printf '%s  %s\\n' "+quote(macHash)+' '+quote(macTool)+' | /usr/bin/shasum -a 256 -c -\nexec '+shell(['/opt/homebrew/bin/limactl','shell','ae1-runner','--',...guestArgv])+'\n';
 await put('mac-preflight.sh',preflight);
 const command=shell([macTool,'--signal=KILL','--kill-after=3s','80s','/bin/sh','-c',preflight])+'\n';
 const ssh='C:/Windows/System32/OpenSSH/ssh.exe';
 const sshArgs=['-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8','peters-mac-mini',command];
 const commandUnits=[ssh,...sshArgs].map(windowsArg).join(' ').length;
 if(command.length>30000||commandUnits>=32760)throw Error('Windows SSH commandline exceeds reviewed bound');
 await put('linux-command.txt',command);
 const localTools={
 'C:/Users/Peter/process-tree-guard/target/codex-security/windows-cleanup-verdict-001/cargo-target-001/release/process-tree-guard.exe':'8fa4e58bb6becf3e3c4536557be187b2b4163498d37b55a5ee8c030846fe0cf0',
 'C:/Users/Peter/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe':'2a6769a3330dc1084d0154bfde7d164ab750ca7f700f313f9d417c1be78b2233',
 [ssh]:'98d447730047f5df91373e852d057928a921c3d1e89938700ab656ba84b19dc8',
 'C:/Users/Peter/AppData/Local/Programs/Python/Python312/python.exe':'4d6f5f81a4bca11191c4c7c6b43632694d0a4ce74e068619d8fdc161d469859a'};
 for(let[p,h]of Object.entries(localTools))if(sha(await fs.readFile(p))!==h)throw Error('local tool '+p);
 const names=['generate.mjs','guest_controller.template.py','guest_controller.py','guest-bootstrap.py.txt','launch.ps1','METHOD.md','payload.json.gz','source-packet-index.json','mac-preflight.sh','linux-command.txt','preserve.py','preserve_remote.template.py','../source-candidate.json',...Object.keys(candidate.files).map(n=>'../'+n),...Object.keys(candidate.external_dependencies).map(n=>path.relative(here,path.join(repo,n)).replaceAll('\\','/'))];
 const files={};for(let n of names)files[n]=sha(await fs.readFile(path.join(here,n)));
 const plan={schema:1,state:'UNEXECUTED_PENDING_EXACT_PLAN_REVIEWS',review_pending:true,purpose:'Linux015 ordinary2C and wholeRustnormal/test OBJECTS only; no compiled code execution',reviewed_source_candidate_sha256:sha(candidateRaw),files,local_executable_sha256:localTools,source_payload_sha256:sha(packet),source_payload_bytes:packet.length,source_uncompressed_sha256:sha(raw),source_uncompressed_bytes:raw.length,source_inputs:expected,source_members:Object.keys(expected).length,compression:{source:'gzip,1MiBcompressed/4MiBraw strict EOF/no trailing',driver:'gzip,64KiBcompressed/128KiBraw samebufferSHA before compile/exec controller only'},driver_sha256:sha(driverRaw),driver_compressed_sha256:sha(driverCompressed),mac_gtimeout:{path:macTool,sha256:macHash},native_compiler:{path:'/home/petershiller1.guest/.rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu/bin/rustc',sha256:'b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f'},native_c_compiler:{path:'/usr/bin/gcc',sha256:'a20520ee21543f243d40636a9181a142c45ecd989de31ab86b99a8ea5ada870d'},guest_argv:guestArgv.slice(0,-1).concat('<exact pinned gzip driver bootstrap>'),windows_ssh_commandline_utf16_units:commandUnits,deadlines_seconds:{windows_job:100,mac_outer:80,guest_waiting_client:75,linux_user_scope:70,kill_after:3},preservation_deadlines_seconds:{windows_job:65,mac_outer:45,guest_waiting_client:35,linux_user_scope:30,kill_after:3},object_builds:['native-arming.o','kernel-signal-abi.o','activation-main.o','activation-tests.o'],object_format:'ELF64 little-endian AARCH64 ET_REL, checked by bytes, not execution',c_compile_executions:2,rust_object_builds:2,dependency_queries:2,abi_reporter_executions:0,prototype_executions:0,fixture_children:0,payload_executions:0,privileged_execution:0,source002_mac_admin:'DEFERRED',prohibitions:'No link, reporter, harness, watchdog, clone, native candidate function, root/cgroup payload, concurrency, rewrite, retry or automaticnextphase',failure_policy:'Raw errors/partial inventory retained; archive BEFORE held descriptor-relative exact removal; if no trustworthy inventory quarantine and preserve raw without guessed cleanup',target:'peters-mac-mini -> ordinary Lima ae1-runner UID501 ARM64',qualification:'Compilation/provenance only. Native arming/mask/lease/readiness/runtime and production remain unqualified.'};
 const pb=Buffer.from(JSON.stringify(plan,null,2)+'\n');await put('plan.json',pb);const ph=sha(pb),tool=Object.keys(localTools)[0],pwsh=Object.keys(localTools)[1],python=Object.keys(localTools)[3];
 await put('local-argv.json',JSON.stringify({prepared_only:true,plan_sha256:ph,argv:[tool,'--timeout','100','--',pwsh,'-NoProfile','-NonInteractive','-File',path.join(here,'launch.ps1').replaceAll('\\','/'),'-ApprovedPlanSha',ph],preserve:['preserve','prearchive','remove'].map(mode=>({mode,argv:[tool,'--timeout','65','--',python,'-I','-B',path.join(here,'preserve.py').replaceAll('\\','/'),mode,ph]}))},null,2)+'\n');
 return {plan_sha256:ph,files:Object.keys(files).length,source_members:Object.keys(expected).length,packet_bytes:packet.length,raw_bytes:raw.length,driver_bytes:driverRaw.length,command_units:commandUnits};
}
