"""Preserve exact ordinary015 artifacts, verify archive, then exact-owned cleanup."""
import ast
import base64
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import zipfile

HERE=Path(__file__).resolve().parent
ORIGINAL=HERE.parent
PRESERVED=ORIGINAL/"preservation-002"
ARM=ORIGINAL.parent
REPO=ARM.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
def capture():
    raw=(ORIGINAL/"linux.stdout.log").read_bytes()
    completion=[json.loads(x.split(b"=",1)[1])for x in raw.splitlines()if x.startswith(b"ORDINARY_COMPONENT_COMPLETE=")]
    refused=[json.loads(x.split(b"=",1)[1])for x in raw.splitlines()if x.startswith(b"ORDINARY_COMPONENT_REFUSED=")]
    scratch=[json.loads(x.split(b"=",1)[1])for x in raw.splitlines()if x.startswith(b"ORDINARY_SCRATCH=")]
    assert len(scratch)==1 and len(completion)+len(refused)==1
    completed=completion[0] if completion else refused[0]
    assert completed["scratch_retained"]==scratch[0]["path"]
    completed["scratch_identity"]=[scratch[0]["device"],scratch[0]["inode"]]
    assert isinstance(completed["file_inventory"],dict), "No exact partial inventory; preserve raw and quarantine without guessed cleanup"
    expected=dict(completed["file_inventory"])
    if completion:
        assert completed["object_builds_passed"]==2 and completed["fixture_children"]==0 and completed["selected_fixture_tests"]==0 and completed["c_objects_passed"]==2 and completed["prototype_executions"]==0
        inventory=(json.dumps(expected,indent=2)+"\n").encode()
        expected["ordinary-inventory.json"]={"bytes":len(inventory),"sha256":sha(inventory)}
    contexts=[json.loads(x.split(b"=",1)[1]) for x in raw.splitlines() if x.startswith(b"NATIVE_CONTEXT=")]
    assert len(contexts)<=1
    pids={scratch[0]["controller_pid"]}
    identities={str(scratch[0]["controller_pid"]):scratch[0]["controller_identity"]}
    if contexts: assert contexts[0]["pid"]==scratch[0]["controller_pid"]
    for line in raw.splitlines():
        if line.startswith(b"NATIVE_CHILD="):
            row=json.loads(line.split(b"=",1)[1])
            pids.add(row["pid"]);identities[str(row["pid"])]=row["identity"]
    assert all(type(pid)is int and pid>0 for pid in pids)
    template=(ORIGINAL/"preserve_remote.template.py").read_text(encoding="utf-8")
    source=template.replace("@EXPECTED_JSON@",json.dumps(expected)).replace("@ROOT_JSON@",json.dumps(scratch[0]["path"]))
    source=source.replace("@ROOT_ID_JSON@",json.dumps(completed["scratch_identity"])).replace("@PIDS_JSON@",json.dumps(sorted(pids)))
    source=source.replace("@PID_IDENTITIES_JSON@",json.dumps(identities))
    assert sha(source.encode())==sha((HERE/"remote-source.py.txt").read_bytes()), "actual source inventory differs"
    return completed, source

TOOL="/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout"

def run(mode):
    completed, source = capture()
    assert mode=="remove", "removal-only controller"
    source=(HERE/"bootstrap.py.txt").read_text(encoding="utf-8")
    unit="ptg-native-arming-015-"+mode+".scope"
    argv=["/usr/bin/timeout","--signal=KILL","--kill-after=3s","35s","/usr/bin/systemd-run",
          "--user","--scope","--quiet","--expand-environment=no","--unit",unit,
          "-p","RuntimeMaxSec=30s","-p","KillMode=control-group","-p","KillSignal=SIGKILL",
          "-p","SendSIGKILL=yes","--","/usr/bin/python3","-I","-B","-c",source,mode]
    preflight='set -eu\n'+'test "$(/usr/bin/id -u)" = 501\n'
    preflight+="printf '%s  %s\\n' "+shlex.quote("6a7b0620313d337d70366cd4d3b969b49854abfeb1db602bdf3328122e223c6d")+" "+shlex.quote(TOOL)+" | /usr/bin/shasum -a 256 -c -\n"
    preflight+='exec '+shlex.join(["/opt/homebrew/bin/limactl","shell","ae1-runner","--",*argv])+"\n"
    command=shlex.join([TOOL,"--signal=KILL","--kill-after=3s","45s","/bin/sh","-c",preflight])+"\n"
    with(HERE/(mode+"-command.txt")).open("x",encoding="utf-8",newline="\n")as f:f.write(command)
    ssh_argv=["C:/Windows/System32/OpenSSH/ssh.exe","-T","-o","BatchMode=yes","-o","StrictHostKeyChecking=yes","-o","ConnectTimeout=8","peters-mac-mini",command]
    windows_units=len(subprocess.list2cmdline(ssh_argv).encode("utf-16-le"))//2
    assert windows_units<=30000, "Windows SSH commandline too long"
    with(HERE/"commandline-validation.json").open("x",encoding="utf-8")as f:json.dump({"utf16_units":windows_units,"cap":30000},f)
    data=None
    if mode=="remove":
        verify_zip(ORIGINAL/"pre-removal.zip")
        with zipfile.ZipFile(ORIGINAL/"pre-removal.zip") as saved:
            assert len(saved.namelist())==393, "prearchive member count"
            assert saved.read("ordinary-compile-001/preservation-002/preserve.json") == (PRESERVED/"preserve.json").read_bytes(), "archive lacks exact preserve receipt"
        before=json.loads((PRESERVED/"preserve.json").read_bytes())
        assert before["mode"]=="preserve" and before["scratch_removed"] is False and before["original_scope_gone"] is True
        assert before["root"]=="/tmp/ptg-native-arming-015.f5i12bzt" and before["identity"]==[64769,1111923] and len(before["files"])==191
        assert len(before["recorded_workers_absent"])==9 and all(r["proc_entry_present"] is False for r in before["recorded_workers_absent"])
        for name,row in before["files"].items():
            raw=(PRESERVED/"download"/name).read_bytes()
            assert len(raw)==row["bytes"] and sha(raw)==row["sha256"], "download differs: "+name
            decoded=base64.b64decode(row.pop("data_b64"),validate=True)
            assert decoded==raw, "receipt bytes differ"
        data=json.dumps(before).encode()
    try:
        r=subprocess.run(["C:/Windows/System32/OpenSSH/ssh.exe","-T","-o","BatchMode=yes","-o",
                          "StrictHostKeyChecking=yes","-o","ConnectTimeout=8","peters-mac-mini",command],
                         input=data,capture_output=True,timeout=60)
    except subprocess.TimeoutExpired as error:
        for suffix,b in((".stdout.log",error.stdout or b""),(".stderr.log",error.stderr or b"")):
            with(HERE/(mode+suffix)).open("xb")as f:f.write(b)
        with(HERE/(mode+".exception.json")).open("x",encoding="utf-8")as f:
            json.dump({"type":"TimeoutExpired","seconds":60,"policy":"partial streams preserved; no retry or guessed cleanup"},f)
        raise
    for suffix,b in((".stdout.log",r.stdout),(".stderr.log",r.stderr),(".exit.txt",str(r.returncode).encode())):
        with(HERE/(mode+suffix)).open("xb")as f:f.write(b)
    if r.returncode:raise RuntimeError("ordinary "+mode+" refused; raw error retained; no retry")
    rows=[json.loads(x[7:])for x in r.stdout.splitlines()if x.startswith(b"RESULT=")]
    assert len(rows)==1
    result=rows[0]
    assert result["identity"]==completed["scratch_identity"]
    with(HERE/(mode+".json")).open("x",encoding="utf-8",newline="\n")as f:f.write(json.dumps(result,indent=2)+"\n")
    if mode=="preserve":
        for name,row in result["files"].items():
            content=base64.b64decode(row["data_b64"],validate=True)
            assert len(content)==row["bytes"]and sha(content)==row["sha256"]
            dest=HERE/"download"/name
            dest.parent.mkdir(parents=True,exist_ok=True)
            with dest.open("xb")as f:f.write(content)
    print(json.dumps({"mode":mode,"exit":r.returncode,"files":len(result["files"]),
                      "recorded_workers_absent":result["recorded_workers_absent"],
                      "original_scope_gone":result["original_scope_gone"],"scratch_removed":result["scratch_removed"],
                      "receipt_sha256":sha((HERE/(mode+".json")).read_bytes())},indent=2))

def verify_zip(path):
    with zipfile.ZipFile(path)as z:
        assert z.testzip()is None
        assert len(z.namelist())==len(set(z.namelist())),"duplicate archive member"
        index=json.loads(z.read("INDEX.json"))
        assert set(z.namelist())==set(index)|{"INDEX.json"}
        for name,pin in index.items():
            b=z.read(name)
            assert len(b)==pin["bytes"]and sha(b)==pin["sha256"],name

def archive(destination):
    assert not destination.exists()
    files={}
    for p in sorted(ARM.rglob("*")):
        if p.is_file()and p.suffix!=".zip"and p.name!="archive-receipt.json"and"__pycache__"not in p.parts:
            files[p.relative_to(ARM).as_posix()]=p.read_bytes()
    for name in("src/deadline.rs","target/codex-security/issue2-linux-generic-request-001/request.rs"):
        files["dependencies/"+name]=(REPO/name).read_bytes()
    index={n:{"bytes":len(b),"sha256":sha(b)}for n,b in files.items()}
    with zipfile.ZipFile(destination,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for name,b in files.items():z.writestr(name,b)
        z.writestr("INDEX.json",json.dumps(index,indent=2)+"\n")
    verify_zip(destination)
    receipt={"archive":str(destination),"sha256":sha(destination.read_bytes()),"bytes":destination.stat().st_size,
             "members":len(index)+1,"exact_member_verification":"passed"}
    if destination.name!="pre-removal.zip":
        with(HERE/"archive-receipt.json").open("x",encoding="utf-8",newline="\n")as f:f.write(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps(receipt,indent=2))

def bound_inputs():
    assert len(sys.argv)==3 and re.fullmatch("[0-9a-f]{64}",sys.argv[2])
    raw=(HERE/"plan.json").read_bytes()
    assert sha(raw)==sys.argv[2],"exact preservation plan differs"
    plan=json.loads(raw)
    for name,pin in plan["files"].items():assert sha((HERE/name).read_bytes())==pin,name
    for name,pin in plan["local_executable_sha256"].items():assert sha(Path(name).read_bytes())==pin,name
bound_inputs()
if sys.argv[1]=="remove":run(sys.argv[1])
else:raise RuntimeError("unknown action")

bound_inputs()
