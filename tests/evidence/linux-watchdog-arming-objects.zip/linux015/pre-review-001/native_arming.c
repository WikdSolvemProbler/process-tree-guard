// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller
#define _GNU_SOURCE 1
#include "native_arming.h"
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <linux/sched.h>
#include <poll.h>
#include <signal.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

_Static_assert(sizeof(pid_t)==4 && (pid_t)-1<0,"Linux PID scalar");
_Static_assert(sizeof(struct clone_args)==88,"installed clone3 structure");
_Static_assert(offsetof(struct clone_args,pidfd)==8,"installed pidfd offset");
_Static_assert(sizeof(struct pollfd)==8,"installed pollfd shape");
_Static_assert(NSIG==65,"Linux signal mask representation");
_Static_assert(sizeof(struct ptg_arm_spawn)==80 && offsetof(struct ptg_arm_spawn,original_signal_mask)==56,"spawn bridge ABI");
_Static_assert(sizeof(struct ptg_arm_ready)==88 && offsetof(struct ptg_arm_ready,before_ns)==72,"readiness bridge ABI");
_Static_assert(sizeof(struct ptg_arm_kill)==8,"kill bridge ABI");

uint64_t ptg_arm_abi(uint32_t word) {
    switch(word) {
    case 0:return 1;
    case 1:return sizeof(struct ptg_arm_spawn);
    case 2:return sizeof(struct ptg_arm_ready);
    case 3:return sizeof(struct ptg_arm_kill);
    case 4:return CLONE_PIDFD;
    case 5:return SIGCHLD;
    case 6:return SYS_clone3;
    case 7:return CLOCK_BOOTTIME;
    case 8:return sizeof(struct pollfd);
    default:return UINT64_MAX;
    }
}
static uint64_t now_ns(int *error) {
    struct timespec now;
    if(clock_gettime(CLOCK_BOOTTIME,&now)!=0){*error=errno;return 0;}
    if(now.tv_sec<0 || now.tv_nsec<0 || now.tv_nsec>=1000000000L
       || (uint64_t)now.tv_sec>(UINT64_MAX-(uint64_t)now.tv_nsec)/UINT64_C(1000000000)){
        *error=EOVERFLOW;return 0;
    }
    *error=0;return (uint64_t)now.tv_sec*UINT64_C(1000000000)+(uint64_t)now.tv_nsec;
}
void ptg_arm_kill_held(int32_t fd,struct ptg_arm_kill *out) {
    // First action is the held write. No clock, allocation, formatting or reopen.
    const ssize_t result=write(fd,"1",1);
    out->result=(int32_t)result;
    out->call_errno=result<0?errno:0;
}
static _Noreturn void cancel_exit(int kill_fd) {
    const ssize_t result=write(kill_fd,"1",1);
    _exit(result==1?124:125); // attempt result only; never an empty-domain receipt.
}
static _Noreturn void watchdog_child(int owner,int timer,int supervisor,int kill_fd,int ready) {
    // All maskable signals were blocked BEFORE clone. No inherited Rust signal
    // handler can run here. SIGKILL still works. No Rust/heap/stdio/exec path.
    const int source[5]={owner,timer,supervisor,kill_fd,ready};
    int staged[5]={-1,-1,-1,-1,-1};
    for(unsigned i=0;i<5;i++) {
        staged[i]=fcntl(source[i],F_DUPFD_CLOEXEC,64);
        if(staged[i]<0)cancel_exit(staged[3]>=0?staged[3]:kill_fd);
    }
    for(unsigned i=0;i<5;i++)if(dup3(staged[i],(int)i+3,O_CLOEXEC)<0)cancel_exit(staged[3]);
    // Exact child-local retained layout:3=owner,4=original timer,5=exact
    // supervisor pidfd,6=held cgroup.kill,7=sole readiness writer.
    if(syscall(SYS_close_range,8U,UINT_MAX,0U)!=0)cancel_exit(6);
    if(syscall(SYS_close_range,0U,2U,0U)!=0)cancel_exit(6);
    struct pollfd watched[3]={{.fd=3,.events=POLLIN},{.fd=4,.events=POLLIN},{.fd=5,.events=POLLIN}};
    const int initial=poll(watched,3,0);
    if(initial!=0 || watched[0].revents || watched[1].revents || watched[2].revents)cancel_exit(6);
    const unsigned char token='R';
    if(write(7,&token,1)!=1)cancel_exit(6);
    if(close(7)!=0)cancel_exit(6);
    // Never read/disarm/retarget the execution timer. Any owner/supervisor
    // readiness, expiry, unexpected poll state or EINTR cancels immediately.
    // The original finite BOOTTIME timer bounds the otherwise blocking poll.
    for(unsigned i=0;i<3;i++)watched[i].revents=0;
    (void)poll(watched,3,-1);
    cancel_exit(6);
}
void ptg_arm_spawn_watchdog(int32_t owner,int32_t timer,int32_t supervisor,
    int32_t kill_fd,int32_t ready,uint64_t until,struct ptg_arm_spawn *out) {
    memset(out,0,sizeof(*out));out->schema=1;out->pid=out->pidfd=-1;
    out->mask_restore_result=INT32_MIN;out->initial_poll_result=INT32_MIN;out->clone_result=INT32_MIN;out->stage=1;
    if(owner<0||timer<0||supervisor<0||kill_fd<0||ready<0){out->call_errno=EBADF;return;}
    struct pollfd initial[3]={{.fd=owner,.events=POLLIN},{.fd=timer,.events=POLLIN},{.fd=supervisor,.events=POLLIN}};
    const int sampled=poll(initial,3,0);out->initial_poll_result=sampled;
    for(unsigned i=0;i<3;i++)out->initial_revents[i]=initial[i].revents;
    if(sampled!=0){out->call_errno=sampled<0?errno:ECANCELED;return;}
    int error=0;out->before_clone_ns=now_ns(&error);
    if(error||out->before_clone_ns>=until){out->call_errno=error?error:ETIMEDOUT;return;}
    sigset_t all,original;
    if(sigfillset(&all)!=0||sigprocmask(SIG_SETMASK,&all,&original)!=0){out->call_errno=errno;return;}
    for(int signal=1;signal<NSIG;signal++)if(sigismember(&original,signal)==1)
        out->original_signal_mask|=UINT64_C(1)<<(signal-1);
    struct clone_args args;memset(&args,0,sizeof(args));
    args.flags=CLONE_PIDFD;args.pidfd=(uint64_t)(uintptr_t)&out->pidfd;args.exit_signal=SIGCHLD;
    out->stage=2;
    const long result=syscall(SYS_clone3,&args,sizeof(args));
    if(result==0)watchdog_child(owner,timer,supervisor,kill_fd,ready);
    const int clone_error=result<0?errno:0;out->clone_result=(int32_t)result;
    // Publish positive-clone custody BEFORE restoration or clock operations.
    if(result>0){out->pid=(int32_t)result;out->child_created=1;}
    out->mask_restore_result=sigprocmask(SIG_SETMASK,&original,NULL);
    out->mask_restore_errno=out->mask_restore_result<0?errno:0;
    if(result<0){out->call_errno=clone_error;return;}
    out->stage=3;out->after_clone_ns=now_ns(&error);out->call_errno=error;
    if(out->mask_restore_result!=0||error)return;
    out->stage=4;
}
void ptg_arm_wait_ready(int32_t ready,int32_t child,int32_t owner,int32_t timer,
    int32_t supervisor,int32_t setup_timer,uint64_t until,struct ptg_arm_ready *out) {
    memset(out,0,sizeof(*out));out->result=-1;out->read_count=-1;out->poll_result=out->after_poll_result=INT32_MIN;
    int error=0;out->before_ns=now_ns(&error);
    if(error||out->before_ns>=until){out->call_errno=error?error:ETIMEDOUT;return;}
    struct pollfd watched[6]={{.fd=ready,.events=POLLIN},{.fd=child,.events=POLLIN},
        {.fd=owner,.events=POLLIN},{.fd=timer,.events=POLLIN},{.fd=supervisor,.events=POLLIN},
        {.fd=setup_timer,.events=POLLIN}};
    int result=poll(watched,6,-1);out->poll_result=result;
    for(unsigned i=0;i<6;i++)out->revents[i]=watched[i].revents;
    if(result<=0){out->call_errno=result<0?errno:EIO;return;}
    for(unsigned i=1;i<6;i++)if(watched[i].revents){out->call_errno=ECANCELED;return;}
    if(!(watched[0].revents&POLLIN)||watched[0].revents&~(POLLIN|POLLHUP)){out->call_errno=EPROTO;return;}
    unsigned char byte=0;const ssize_t count=read(ready,&byte,1);
    out->read_count=(int32_t)count;out->token=byte;
    if(count!=1||byte!='R'){out->call_errno=count<0?errno:EPROTO;return;}
    for(unsigned i=0;i<6;i++)watched[i].revents=0;
    result=poll(watched,6,0);out->after_poll_result=result;
    for(unsigned i=0;i<6;i++)out->after_revents[i]=watched[i].revents;
    if(result<0){out->call_errno=errno;return;}
    for(unsigned i=1;i<6;i++)if(watched[i].revents){out->call_errno=ECANCELED;return;}
    out->after_ns=now_ns(&error);
    if(error||out->after_ns<out->before_ns||out->after_ns>=until){out->call_errno=error?error:ETIMEDOUT;return;}
    out->result=0;
}
