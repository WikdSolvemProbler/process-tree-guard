// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

use super::*;
use std::cell::RefCell;

#[test]
fn callback_error_follows_kill_and_keeps_its_outcome() {
    // One callback error exercises the shared driver's order. This is not
    // native fault injection or a cgroup-quarantine simulation.
    let events = RefCell::new(Vec::new());
    let result: std::result::Result<((), ()), _> = terminate_then(
        (),
        |_| {
            events.borrow_mut().push("kill");
            KillOutcome::Written
        },
        |_, observed| {
            assert_eq!(observed, KillOutcome::Written);
            events.borrow_mut().push("callback error");
            Err("one callback failure".into())
        },
    );
    let failure = result.unwrap_err();
    assert_eq!(failure.kill_outcome, KillOutcome::Written);
    assert_eq!(failure.error, "one callback failure");
    assert_eq!(*events.borrow(), ["kill", "callback error"]);
}

#[test]
fn unsuccessful_kill_never_enters_cleanup_wait_setup() {
    for outcome in [
        KillOutcome::Short { bytes: 0 },
        KillOutcome::Failed { errno: Some(4) },
        KillOutcome::Failed { errno: Some(5) },
        KillOutcome::Failed { errno: None },
    ] {
        let events = RefCell::new(Vec::new());
        let result: std::result::Result<(&str, ()), _> = terminate_then(
            "retained custody",
            |_| {
                events.borrow_mut().push("kill");
                outcome
            },
            |_, _| {
                events.borrow_mut().push("wait setup");
                Ok(())
            },
        );
        let quarantine = result.unwrap_err();
        assert_eq!(quarantine.kill_outcome, outcome);
        assert_eq!(quarantine.custody, "retained custody");
        assert_eq!(*events.borrow(), ["kill"]);
    }
}

#[test]
fn successful_post_kill_result_preserves_outcome() {
    let result = terminate_then((), |_| KillOutcome::Written, |_, recorded| Ok((recorded, 23)));
    assert_eq!(result.unwrap(), ((), (KillOutcome::Written, 23)));
}

#[cfg(target_os = "linux")]
#[test]
fn native_regular_file_kill_attempt_precedes_expired_timer_refusal() {
    use std::fs::{self, OpenOptions};
    use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt};

    // No DomainControls is forged. The actual low-level held-write helper is
    // tested on one newly created ordinary regular file; no cgroup is opened.
    let path = std::env::temp_dir().join(format!(
        "ptg-termination007-{}-{}", std::process::id(), boottime_ns().unwrap(),
    ));
    let mut directory = fs::DirBuilder::new();
    directory.mode(0o700).create(&path).unwrap();
    println!("termination007 ordinary_fixture={}", path.display());
    let file_path = path.join("ordinary-write-control");
    let file = OpenOptions::new()
        .read(true)
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(&file_path)
        .unwrap();
    let held: OwnedFd = file.into();
    let failure = terminate_then(held, request_kill, |_, _| Deadline::arm(1).map(|_| ()))
        .unwrap_err();
    assert_eq!(failure.kill_outcome, KillOutcome::Written);
    assert!(failure.error.contains("already expired"));
    drop(failure.custody);
    let bytes = fs::read(&file_path).unwrap();
    fs::remove_file(&file_path).unwrap();
    fs::remove_dir(&path).unwrap();
    assert_eq!(bytes, b"1");
    println!("termination007 ordinary_file_write=1 expired_timer_refused=true payloads=0 cgroup_writes=0");
}
