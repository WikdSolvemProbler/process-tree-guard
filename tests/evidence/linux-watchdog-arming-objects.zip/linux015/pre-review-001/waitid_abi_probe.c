// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller
#include "waitid_bridge.h"
#include <inttypes.h>
#include <stdio.h>

/* This program calls only the constant/header ABI reporter. It creates no
 * child and never calls ptg_waitid_once, waitid, clone, fork, or exec.
 */
int main(void) {
    static const char *const names[] = {
        "schema", "frame_size", "frame_align", "called_offset", "result_offset",
        "call_errno_offset", "signo_offset", "signal_errno_offset", "code_offset",
        "pid_offset", "uid_offset", "status_offset", "native_size_offset",
        "siginfo_size", "siginfo_align", "siginfo_signo_offset", "siginfo_errno_offset",
        "siginfo_code_offset", "siginfo_pid_offset", "siginfo_uid_offset", "siginfo_status_offset",
        "P_PIDFD", "WEXITED", "WNOHANG", "SIGCHLD", "CLD_EXITED", "CLD_KILLED", "CLD_DUMPED",
        "NSIG", "ECHILD", "EINTR", "EBADF", "EFAULT", "EINVAL"
    };
    _Static_assert(sizeof(names) / sizeof(names[0]) == PTG_ABI_WORD_COUNT, "ABI word count");
    printf("{");
    for (uint32_t i = 0; i < PTG_ABI_WORD_COUNT; ++i) {
        printf("%s\"%s\":%" PRIu64, i == 0 ? "" : ",", names[i], ptg_waitid_abi_word(i));
    }
    printf("}\n");
    return 0;
}
