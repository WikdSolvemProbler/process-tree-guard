"""Eight SysPrims Windows correctness controls, with an explicit no-launch inspect mode."""

import argparse
from copy import deepcopy
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TESTS = ROOT / "tests"
CAMPAIGN = TESTS / "campaign"
ARCHIVE = TESTS / "evidence/windows-campaign-20261106.zip"
EXE = TESTS / "build/competitors/sysprims.exe"
FIXTURE = TESTS / "build/testkit.exe"
PINS = {
    ARCHIVE: "ef653c4fb2921adc9e466f767225ba257b26e0b9adecf354b8000f30ccf751bd",
    EXE: "0a3144a6ca7b2df7ee382bbbac85d89f5ed75ee2643e1036356a8eaa4d490867",
    FIXTURE: "c92afd62a1327399d5c2516de53e94ad0d4b7f05de4318f32aa2838b5220ce92",
    CAMPAIGN / "runner.py": "ab0ce012de2644d115633a13459f80746ec99b46b3332d2ef9ed7c4dafcac3f4",
    CAMPAIGN / "windows_slot_job.py": "a4d1ee810a6db1565f1e22bdc13dd3d535bbf08e487b594234d0a79922094e15",
    CAMPAIGN / "plan.py": "a616a82dbeebfe5041fc55d55733d06c4b0c2af27614884c097ae3b0bb52a3bf",
    CAMPAIGN / "probe.py": "604af6a7b77ed598cf744414bb4a601d47ff8c8e5a0ce58cc14e5019eecc996e",
    CAMPAIGN / "arms.py": "e2ce9da8136c1d6aefc126c26cc6dfc0ed4adac97d86f7a2734099ca05f82806",
    Path(sys.executable): "4d6f5f81a4bca11191c4c7c6b43632694d0a4ce74e068619d8fdc161d469859a",
}
WARN = "--log-level=warn"
TEMPLATE = ["timeout", "{timeout_ms}ms", "{child}", "{child_args}"]
STDIN = "ptg-output-stdout"
EXPECTED = {"stdout": b"ptg-output-stdout\n", "stderr": b"error-stream\n"}
MAX_STREAM_BYTES = 65536
ORDER = (
    ("NO_WINDOW", "fast", "default"),
    ("NO_WINDOW", "fast", "warn"),
    ("NO_WINDOW", "kill", "warn"),
    ("NO_WINDOW", "kill", "default"),
    ("DETACHED", "fast", "warn"),
    ("DETACHED", "fast", "default"),
    ("DETACHED", "kill", "default"),
    ("DETACHED", "kill", "warn"),
)


def require(ok, why):
    if not ok:
        raise ValueError(why)


def digest(path):
    with path.open("rb") as file:
        return file_digest(file, "sha256").hexdigest()


def pinned_inputs():
    for path, expected in PINS.items():
        require(digest(path) == expected, f"input identity differs: {path}")
    with ZipFile(ARCHIVE) as bundle:
        raw = bundle.read("complete/campaign.json")
        archived = json.loads(bundle.read("complete/staged-hashes.json"))
        pins = {entry["Path"]: entry["Hash"].lower() for entry in archived}
        require(pins[str(EXE)] == PINS[EXE] and pins[str(FIXTURE)] == PINS[FIXTURE],
                "archive does not bind both executable pins")
        require(sha256(raw).hexdigest() == pins[str(TESTS / "campaign.json")],
                "archive campaign configuration digest differs")
    config = json.loads(raw)
    sysprims = config["arms"]["sysprims"]
    require(sysprims["templates"] == {"fast": TEMPLATE, "kill": TEMPLATE},
            "archive SysPrims templates differ")
    require(sysprims["expected_exit"] == {"fast": 0, "kill": 124}, "archive exit oracles differ")
    require(TESTS / sysprims["executable"] == EXE, "archive SysPrims path differs")
    sysprims["executable"] = str(EXE)
    for path in ("fast", "kill"):
        child = config["children"][path]
        require(TESTS / child["program"] == FIXTURE, "archive fixture path differs")
        child["program"] = str(FIXTURE)
    fast = config["children"]["fast"]
    require(fast["args"] == ["relay", "0"] and fast["stdin"] == STDIN
            and all(fast[f"expected_{label}"].encode() == expected for label, expected in EXPECTED.items()),
            "archive fast workload differs")
    require(config["children"]["kill"]["args"] ==
            ["spawn", "0", "{sleep_s}", "{self}", "mark", "{marker}", "{sleep_s}"],
            "archive kill workload differs")
    require(config["survivor_checker"] == ["python", "campaign\\probe.py"],
            "archive survivor oracle differs")
    config["survivor_checker"] = ["python", str(CAMPAIGN / "probe.py")]
    return config


def configured(config, mode, path):
    result = deepcopy(config)
    if mode == "warn":
        result["arms"]["sysprims"]["templates"][path].insert(0, WARN)
    return result


def planned_argv(runner, slot, config):
    from arms import expand_template, resolve_template

    child, arguments = runner.child_for(slot, config, "<slot-marker>")
    timeout = runner.FAST_TIMEOUT_S if slot.path == "fast" else runner.KILL_TIMEOUT_S
    template = resolve_template(slot.arm, slot.path, config)
    return [str(EXE), *expand_template(template, timeout, child, arguments)]


def verify_plan(config, runner, make_slot):
    require(runner.SLOT_DEADLINE_S == 30.0 and runner.PROBE_DEADLINE_S == 10.0,
            "runner slot/probe bounds differ")
    require(runner.creation_flags("NO_WINDOW") == 0x08000000
            and runner.creation_flags("DETACHED") == 0x208, "runner Windows creation flags differ")
    slots = []
    for ordinal, (context, path, mode) in enumerate(ORDER):
        slot = make_slot("control", "sysprims", path, context, ordinal)
        actual = planned_argv(runner, slot, configured(config, mode, path))
        base = [str(EXE), "timeout", "10000ms" if path == "fast" else "2000ms", str(FIXTURE)]
        tail = (["relay", "0"] if path == "fast"
                else ["spawn", "0", "30", str(FIXTURE), "mark", "<slot-marker>", "30"])
        if mode == "warn":
            base.insert(1, WARN)
        require(actual == base + tail, f"slot {ordinal} argv differs")
        slots.append({"context": context, "path": path, "mode": mode, "argv": actual})
    return slots


def durable_write(path, data):
    with path.open("xb") as file:
        file.write(data)
        file.flush()
        os.fsync(file.fileno())


def save_json(path, value):
    durable_write(path, (json.dumps(value, indent=2, allow_nan=False) + "\n").encode())


class RecordingJob:
    def __init__(self, native_job, folder, kill):
        self.job = native_job
        self.folder = folder
        self.kill = kill
        self.streams = {}
        self.captured = {}
        self.capture_error = None

    def launch(self, argv, creationflags, *, stdin, stdout, stderr):
        if self.kill:
            require(stdin == stdout == stderr == subprocess.DEVNULL,
                    "kill stdio differs from the archived runner")
            for label in EXPECTED:
                self.streams[label] = (self.folder / f"{label}.arm.bin").open("xb")
            stdout, stderr = self.streams["stdout"], self.streams["stderr"]
        return self.job.launch(argv, creationflags, stdin=stdin, stdout=stdout, stderr=stderr)

    def snapshot(self, label, path):
        with Path(path).open("rb") as source:
            data = source.read(MAX_STREAM_BYTES + 1)
        kept = data[:MAX_STREAM_BYTES]
        durable_write(self.folder / f"{label}.before-cleanup.bin", kept)
        self.captured[label] = {"bytes": len(kept), "sha256": sha256(kept).hexdigest(),
                                "truncated": len(data) > MAX_STREAM_BYTES}

    def drain(self):
        try:
            if self.kill:
                for label, stream in self.streams.items():
                    self.snapshot(label, stream.name)
        except (OSError, ValueError) as error:
            self.capture_error = str(error)
        finally:
            drained = self.job.drain()
        return drained

    def close(self):
        try:
            self.job.close()
        finally:
            for stream in self.streams.values():
                stream.close()


def observe_case(folder, mode, slot, config, runner, job_type):
    observer = RecordingJob(job_type(), folder, slot.path == "kill")
    original_observe = runner._observe_output

    def capture_fast(record, expected, out_path, err_path):
        observer.snapshot("stdout", out_path)
        observer.snapshot("stderr", err_path)
        original_observe(record, expected, out_path, err_path)

    try:
        runner._observe_output = capture_fast
        row = runner._run_slot(slot, config, observer, None)
    finally:
        runner._observe_output = original_observe
        observer.close()
    row["qualification_mode"] = mode
    row["before_cleanup_streams"] = observer.captured
    row["capture_error"] = observer.capture_error
    save_json(folder / "slot.json", row)
    return row


def validate_case(folder, row, scenario):
    require(row["capture_error"] is None and set(row["before_cleanup_streams"]) == set(EXPECTED),
            "incomplete before-cleanup streams")
    data = {}
    for label, meta in row["before_cleanup_streams"].items():
        raw = (folder / f"{label}.before-cleanup.bin").read_bytes()
        require(meta == {"bytes": len(raw), "sha256": sha256(raw).hexdigest(), "truncated": False},
                f"{label} evidence differs or was truncated")
        data[label] = raw
    argv = list(row["argv"])
    if row["path"] == "kill":
        require(isinstance(row["tree_marker"], str) and argv.count(row["tree_marker"]) == 1,
                "exact marker path missing from kill argv")
        argv[argv.index(row["tree_marker"])] = "<slot-marker>"
    require(argv == scenario["argv"], "executed argv differs")
    job = row["slot_job"]
    require(job["active_after"] == 0, "slot Job did not drain")
    mode = row["qualification_mode"]
    if row["path"] == "fast":
        require(row["exit_code"] == 0 and data["stdout"] == EXPECTED["stdout"],
                "fast status or stdout mismatch")
        for label in EXPECTED:
            require(row[f"output_{label}_sha256"] == sha256(data[label]).hexdigest(),
                    f"runner {label} digest differs from retained bytes")
        if mode == "warn":
            require(row["outcome"] == "ok" and data["stderr"] == EXPECTED["stderr"],
                    "explicit WARN output contract failed")
        else:
            require(row["outcome"] == "output-mismatch"
                    and EXPECTED["stderr"] in data["stderr"]
                    and b"Running command with timeout" in data["stderr"],
                    "default logging control did not reproduce the expected mismatch")
    else:
        require(row["exit_code"] == 124 and row["survivor"] is False and row["outcome"] == "ok"
                and type(row["grandchild_pid"]) is int and row["grandchild_pid"] > 0
                and job["active_before"] == 0 and job["terminated"] is False,
                "kill status, pre-drain survivor, or natural Job settlement differs")
        timed_out_diagnostic = b"Command timed out" in data["stderr"]
        require(timed_out_diagnostic == (mode == "default"), "kill INFO diagnostic control differs")
        if mode == "default":
            require(b"reliability" in data["stderr"], "default reliability diagnostic missing")


def capture(out, config, runner, slot_type, job_type, slots):
    require(out.is_absolute() and out.parent == HERE, "output must be a fresh direct scratch child")
    for name in list(os.environ):
        if name.upper() == "RUST_LOG":
            del os.environ[name]
    require(not any(name.upper() == "RUST_LOG" for name in os.environ), "RUST_LOG is still present")
    out.mkdir()
    terminal = {"state": "RUNNING", "expected": len(slots), "completed": 0, "error": None}
    save_json(out / "plan.json", {
        "slots": slots, "rust_log_present": False, "no_latency_verdict": True,
        "kill_output_capture": "regular files in both diagnostic modes",
        "pin_sha256": {str(path): digest(path) for path in PINS},
    })
    save_json(out / "started.json", terminal)
    try:
        for i, scenario in enumerate(slots):
            folder = out / f"{i:02d}"
            folder.mkdir()
            save_json(folder / "planned.json", scenario)
            context, path, mode = (scenario[key] for key in ("context", "path", "mode"))
            slot = slot_type("control", "sysprims", path, context, i)
            case_config = configured(config, mode, path)
            row = observe_case(folder, mode, slot, case_config, runner, job_type)
            validate_case(folder, row, scenario)
            terminal["completed"] += 1
        for path, expected in PINS.items():
            require(digest(path) == expected, f"terminal pin differs: {path}")
        terminal["state"] = "COMPLETE"
    except BaseException as error:
        terminal.update(state="REFUSED", error=repr(error))
        raise
    finally:
        save_json(out / "terminal.json", terminal)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--inspect", action="store_true", help="verify pins and plan without launching slots")
    modes.add_argument("--capture", type=Path, metavar="FRESH_OUTPUT_DIRECTORY")
    args = parser.parse_args()
    require(sys.platform == "win32" and sys.flags.isolated and sys.dont_write_bytecode,
            "use pinned Windows Python -I -B")
    config = pinned_inputs()
    sys.path.insert(0, str(CAMPAIGN))
    from plan import Slot
    import runner
    from windows_slot_job import CLEANUP_TIMEOUT_S, SlotJob

    require(CLEANUP_TIMEOUT_S == 5.0, "slot Job cleanup deadline differs")
    slots = verify_plan(config, runner, Slot)
    if args.inspect:
        print(json.dumps({"state": "VALIDATED_NO_LAUNCH", "slots": slots, "cases": len(slots)}, indent=2))
        return
    capture(args.capture, config, runner, Slot, SlotJob, slots)


if __name__ == "__main__":
    main()
