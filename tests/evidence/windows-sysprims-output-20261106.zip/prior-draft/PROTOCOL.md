# SysPrims v0.2.4 output and kill controls

This Windows diagnostic asks whether the archived SysPrims executable preserves the relay fixture's exact stdout and stderr when its own INFO tracing is filtered. It also checks both diagnostic logging modes against the same timeout fixture and survivor oracle. An eligible result describes these eight controls only. The complete 1,940-slot archive and its verdict remain the record of the default campaign.

## Fixed inputs and order

Use the source, Python, SysPrims, and testkit digests in diagnostic.py. The archived complete/staged-hashes.json independently binds the two binaries and complete/campaign.json. Both fast modes use the archive relay fixture, exact input ptg-output-stdout, 10000ms and exit 0. Both kill modes use the archive spawn and marker fixture, 2000ms and exit 124. The explicit mode inserts the single top-level --log-level=warn token before timeout. The isolated Python worker removes RUST_LOG case-insensitively before either mode. Keep the unchanged campaign NO_WINDOW and DETACHED creation flags.

| Slot | Context | Path | Mode |
| ---: | --- | --- | --- |
| 0 | NO_WINDOW | fast | default |
| 1 | NO_WINDOW | fast | warn |
| 2 | NO_WINDOW | kill | warn |
| 3 | NO_WINDOW | kill | default |
| 4 | DETACHED | fast | warn |
| 5 | DETACHED | fast | default |
| 6 | DETACHED | kill | default |
| 7 | DETACHED | kill | warn |

Before any live capture, use two independent approvals of the exact source digests, plan, output directory, and a bounded whole-tree launcher. A separately qualified native outer guard must cover the Python controller, arms, and all auxiliary probes, including failure paths. The existing native SlotJob atomically admits each arm and independently drains it. The runner retains its 30-second arm wait and 10-second survivor probe deadline, and the Job retains its five-second cleanup deadline. Capture one attempt and retain incomplete evidence. The scratch controller checks asset digests before and after but does not itself verify the outer guard's identity or hold asset files open. Record launcher admission, exact argv, and terminal outcome externally before interpreting any live result.

## Oracles and boundaries

Every slot must drain its Job and preserve the actual argv and stdout and stderr snapshots. The archived fast runner already uses regular files and computes raw digests. The diagnostic copies bytes before the existing oracle and native Job drainage. The production runner normally sends kill output to DEVNULL. This diagnostic explicitly substitutes separate regular output files in both kill control modes to observe the timeout reliability diagnostic. Kill stdin remains DEVNULL. A stream snapshot is capped at 65,536 bytes and truncation refuses the attempt.

A fast default control must reproduce the logged stderr mismatch while preserving the fixture stderr substring and exact stdout. A fast WARN control must match both fixture streams exactly, with stdout ptg-output-stdout followed by LF and stderr error-stream followed by LF. Both must return zero and preserve runner digests matching the raw copies.

Every kill control must return 124, name the published descendant PID, record no survivor before Job drainage, and show that the runner's Job drained without termination intervention. The default kill control must expose the timeout reliability diagnostic. The WARN kill control filters that INFO event while preserving raw bytes of any retained diagnostics. The SysPrims Windows timeout path attaches its own Job after spawning and can fall back to direct-child termination, so these fixture outcomes cannot establish general protection equivalence.

The unchanged runner emits elapsed fields, and raw-copy instrumentation can affect those fields. This diagnostic defines no speed, quiet-host, protection equivalence or campaign qualification verdict. A future fast-only WARN arm would need a separately reviewed campaign definition and must account for malformed slots currently sharing the fast template. The default kill and scaling invocations are required for that proposal so the reliability diagnostics remain available where separately captured.

## No-launch checks

Run diagnostic.py --inspect under the pinned Windows Python with -I -B and a finite outer launcher. This verifies archive and local asset pins, context flags, runner bounds and all eight argv vectors. The synthetic adapter check uses in-process fake Job objects to confirm snapshots precede drainage for fast and kill paths and that an obstructed snapshot still drains and preserves prior bytes. It launches no real slots.

[SysPrims logging configuration](https://github.com/3leaps/sysprims/blob/v0.2.4/crates/sysprims-cli/src/main.rs#L77-L85) · [Tracing and direct error output](https://github.com/3leaps/sysprims/blob/v0.2.4/crates/sysprims-cli/src/main.rs#L691-L719) · [Timeout outcome and reliability log](https://github.com/3leaps/sysprims/blob/v0.2.4/crates/sysprims-cli/src/main.rs#L1066-L1135) · [Windows Job assignment and fallback](https://github.com/3leaps/sysprims/blob/v0.2.4/crates/sysprims-timeout/src/windows.rs#L463-L509)
