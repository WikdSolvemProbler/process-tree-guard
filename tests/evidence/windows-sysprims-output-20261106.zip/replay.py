"""Offline replay of the reviewed SysPrims correctness attempt."""

from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys
from types import SimpleNamespace

MANIFEST = "65bbd46db44bc62149a4ff411db01db26326e233cb2a0b56587413394b449e7d"


def check(value, why):
    if not value:
        raise ValueError(why)


def digest(raw):
    return sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def replay(root):
    manifest_path = root / "manifest-001.json"
    check(digest(manifest_path.read_bytes()) == MANIFEST, "frozen manifest differs")
    manifest = load(manifest_path)
    assets, inv = manifest["assets"], manifest["invocation"]
    approval_path = root / "approval-001.json"
    approval_sha = digest(approval_path.read_bytes())
    approval = load(approval_path)
    check(approval["schema"] == manifest["schema"] and approval["state"] == "APPROVED"
          and approval["manifest_sha256"] == MANIFEST and approval["unresolved_objections"] == 0
          and approval["reviewers"] == ["sysprims_review_method", "sysprims_review_critic"],
          "frozen two-reviewer approval differs")
    inspect_path = root / "inspect-exact-001.json"
    check(digest(inspect_path.read_bytes()) == approval["inspect_sha256"] == assets["inspect_exact"]["sha256"]
          and load(inspect_path)["slots"] == manifest["expected_slots"], "inspect evidence differs")
    dispatch_path = root / "outer-dispatch-001.json"
    dispatch = load(dispatch_path)
    outer = load(root / "outer-terminal-001.json")
    backup = manifest["backup"]
    backup_argv = [part.replace("{manifest_sha256}", MANIFEST).replace("{approval_sha256}", approval_sha)
                   for part in backup["argv"]]
    check(outer["exit_code"] == 0 and outer["manifest_sha256"] == MANIFEST
          and outer["dispatch_sha256"] == digest(dispatch_path.read_bytes())
          and dispatch["timeout_seconds"] == backup["timeout_seconds"] == 140
          and dispatch["guard"] == backup["guard"] == assets["outer_guard"]["path"]
          and dispatch["guard_sha256"] == assets["outer_guard"]["sha256"]
          and dispatch["argv"] == backup_argv, "backup invocation or receipt differs")

    receipt = root / "wrapper-receipt-001"
    wrapper = load(receipt / "wrapper.json")
    attempt = root / "attempt-001"
    terminal_path = attempt / "terminal.json"
    terminal = load(terminal_path)
    check(wrapper["manifest_sha256"] == MANIFEST and wrapper["approval_sha256"] == approval_sha
          and wrapper["primary_guard"] == assets["outer_guard"]["path"]
          and wrapper["primary_guard_sha256"] == assets["outer_guard"]["sha256"]
          and wrapper["primary_argv"] == inv["primary_argv"]
          and wrapper["cwd"] == inv["cwd"] and wrapper["primary_exit"] == 0
          and wrapper["held_inputs_verified"] is True and wrapper["terminal_read_error"] is None
          and wrapper["terminal_sha256"] == digest(terminal_path.read_bytes())
          and terminal == {"state": "COMPLETE", "expected": 8, "completed": 8, "error": None},
          "primary guard receipt or terminal differs")
    for label in ("stdout", "stderr"):
        check(wrapper[f"{label}_sha256"] == digest((receipt / f"{label}.log").read_bytes()),
              f"wrapper {label} bytes differ")
    plan = load(attempt / "plan.json")
    check(plan["slots"] == manifest["expected_slots"] and plan["cwd"] == inv["cwd"]
          and plan["pycache_prefix"] == inv["pycache_prefix"]
          and plan["rust_log_present"] is False and plan["no_latency_verdict"] is True
          and plan["guarded_argv"] == [assets["outer_guard"]["path"], *inv["primary_argv"]],
          "executed plan differs")
    check({path.casefold(): value for path, value in plan["pin_sha256"].items()}.items()
          <= {asset["path"].casefold(): asset["sha256"] for asset in assets.values()}.items(),
          "controller pins differ from the manifest")

    driver = root / "diagnostic.py"
    check(digest(driver.read_bytes()) == assets["driver"]["sha256"], "approved validator differs")
    validate = runpy.run_path(str(driver), run_name="sysprims_offline_validation")["validate_case"]
    # Replay from a relocated evidence folder using the exact captured runtime identities.
    frozen = validate.__globals__
    frozen["sys"] = SimpleNamespace(executable=assets["controller_python"]["path"])
    frozen["PROBE"] = assets["probe"]["path"]
    frozen["isolated_args"] = lambda: ["-I", "-B", "-X", f"pycache_prefix={inv['pycache_prefix']}"]

    summary = []
    for index, scenario in enumerate(plan["slots"]):
        folder = attempt / f"{index:02d}"
        row = load(folder / "slot.json")
        check(load(folder / "planned.json") == scenario
              and row["rep"] == index and row["kind"] == "control" and row["arm"] == "sysprims"
              and row["context"] == scenario["context"] and row["path"] == scenario["path"]
              and row["qualification_mode"] == scenario["mode"], f"slot identity differs: {index}")
        validate(folder, row, scenario)
        summary.append({
            "context": row["context"], "path": row["path"], "mode": row["qualification_mode"],
            "exit": row["exit_code"], "outcome": row["outcome"], "survivor": row["survivor"],
            "stdout_bytes": row["before_cleanup_streams"]["stdout"]["bytes"],
            "stderr_bytes": row["before_cleanup_streams"]["stderr"]["bytes"],
            "natural_job_drain": True,
        })
    return {"manifest_sha256": MANIFEST, "controls": len(summary), "rows": summary}


if __name__ == "__main__":
    print(json.dumps(replay(Path(sys.argv[1]).resolve()), indent=2))
