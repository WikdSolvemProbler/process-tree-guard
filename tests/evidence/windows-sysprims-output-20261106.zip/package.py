from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from replay import replay

HERE = Path(__file__).resolve().parent
EXTERNAL = {"controller_python", "wrapper_powershell", "outer_guard", "archive", "sysprims", "testkit"}


def digest(data):
    return sha256(data).hexdigest()


def main():
    published = (HERE / "analysis-001.json").read_bytes()
    if published.replace(b"\r\n", b"\n") != (json.dumps(replay(HERE), indent=2) + "\n").encode():
        raise ValueError("published analysis differs from replay")
    manifest = json.loads((HERE / "manifest-001.json").read_bytes())
    top = (
        "manifest-001.json", "approval-001.json", "outer-dispatch-001.json", "outer-terminal-001.json",
        "analysis-001.json", "replay.py", "package.py",
    )
    files = {name: HERE / name for name in top}
    mapping = {}
    for role, binding in manifest["assets"].items():
        path = Path(binding["path"])
        if digest(path.read_bytes()) != binding["sha256"]:
            raise ValueError(f"reviewed asset changed: {role}")
        name = None
        if role not in EXTERNAL:
            name = path.name if path.is_relative_to(HERE) else f"assets/{role}/{path.name}"
            files[name] = path
        mapping[role] = {"sha256": binding["sha256"], "member": name}
    for directory in ("attempt-001", "wrapper-receipt-001"):
        for path in (HERE / directory).rglob("*"):
            if path.is_file():
                files[path.relative_to(HERE).as_posix()] = path
    if any((HERE / "attempt-001/tmp").iterdir()):
        raise ValueError("attempt temporary directory is not empty")
    for name in ("diagnostic.py", "PROTOCOL.md", "inspect-001.json", "synthetic-001.json"):
        files[f"prior-draft/{name}"] = HERE.parent / "sysprims-output-qualification-001" / name

    archive, verify = map(Path, sys.argv[1:])
    if archive.exists() or verify.exists():
        raise ValueError("fresh archive and replay paths required")
    index = {"files": {}, "manifest_assets": mapping}
    with ZipFile(archive, "x", compression=ZIP_DEFLATED) as bundle:
        for name, path in sorted(files.items()):
            raw = path.read_bytes()
            bundle.writestr(ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0)), raw, compress_type=ZIP_DEFLATED)
            index["files"][name] = {"sha256": digest(raw), "bytes": len(raw)}
        bundle.writestr("INDEX.json", json.dumps(index, indent=2, sort_keys=True) + "\n")
    with ZipFile(archive) as bundle:
        if bundle.testzip() is not None or set(bundle.namelist()) != {*files, "INDEX.json"}:
            raise ValueError("archive census differs")
        for name, binding in index["files"].items():
            raw = bundle.read(name)
            if digest(raw) != binding["sha256"] or len(raw) != binding["bytes"]:
                raise ValueError(f"archive member differs: {name}")
        bundle.extractall(verify)
    normalized = (json.dumps(replay(verify), indent=2) + "\n").encode()
    if normalized != published.replace(b"\r\n", b"\n"):
        raise ValueError("fresh archive replay differs")
    print(json.dumps({"archive_sha256": digest(archive.read_bytes()), "files": len(files),
                      "normalized_analysis_sha256": digest(normalized)}, indent=2))


if __name__ == "__main__":
    main()
