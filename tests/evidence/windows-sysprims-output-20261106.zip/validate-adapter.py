"""Validate stream, marker, probe, and cleanup adapters with no child processes."""

import argparse
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import diagnostic as d

KILL_INFO = b"Command timed out reliability=Unproven\n"


class FakeNative:
    def __init__(self, expected_before_drain):
        self.expected_before_drain = expected_before_drain
        self.drained = False
        self.closed = False

    def launch(self, argv, flags, *, stdin, stdout, stderr):
        assert flags and stdin == subprocess.DEVNULL
        Path(argv[-2]).write_bytes(b"1002")
        stderr.write(KILL_INFO)
        stderr.flush()
        return object()

    def drain(self):
        for path, data in self.expected_before_drain.items():
            assert path.read_bytes() == data
        self.drained = True
        return {"active_before": 0, "active_after": 0, "terminated": False}

    def close(self):
        self.closed = True


def refuse(folder, row, scenario, change, message):
    mutated = deepcopy(row)
    change(mutated)
    try:
        d.validate_case(folder, mutated, scenario)
    except ValueError as error:
        assert message in str(error), error
    else:
        raise AssertionError(f"accepted invalid row: {message}")


def fast(out):
    folder = out / "fast"
    folder.mkdir()
    paths = {name: folder / f"{name}.temporary" for name in d.EXPECTED}
    for name, path in paths.items():
        path.write_bytes(d.EXPECTED[name])
    native = FakeNative({
        folder / f"{name}.before-cleanup.bin": value
        for name, value in d.EXPECTED.items()
    })
    planned = {"argv": ["fake-arm", d.WARN, "timeout"]}

    def original(record, spec, stdout, stderr):
        for name, path in (("stdout", stdout), ("stderr", stderr)):
            record[f"output_{name}_sha256"] = sha256(path.read_bytes()).hexdigest()

    def run_slot(slot, config, observer, event_dir):
        row = {"path": slot.path, "argv": planned["argv"], "exit_code": 0, "outcome": "ok"}
        runner._observe_output(row, {}, paths["stdout"], paths["stderr"])
        row["slot_job"] = observer.drain()
        return row

    runner = SimpleNamespace(_observe_output=original, _run_slot=run_slot, subprocess=object())
    old_subprocess = runner.subprocess
    row = d.observe_case(folder, "warn", SimpleNamespace(path="fast"), {}, runner, lambda: native)
    d.validate_case(folder, row, planned)
    assert native.drained and native.closed and runner._observe_output is original
    assert runner.subprocess is old_subprocess
    refuse(folder, row, planned, lambda r: r["slot_job"].update(terminated=True), "naturally at zero")
    refuse(folder, row, planned, lambda r: r.update(job_settled_ns=r["setup_started_ns"] + d.MAX_SLOT_NS),
           "20-second")


def kill(out):
    folder = out / "kill"
    folder.mkdir()
    marker = out / "tmp" / "ptg-kill-synthetic.marker"
    planned = {"argv": ["fake-arm", "timeout", "2000ms", "fake-child", "mark", "<slot-marker>", "30"]}
    argv = [str(marker) if token == "<slot-marker>" else token for token in planned["argv"]]
    native = FakeNative({
        folder / "stdout.before-cleanup.bin": b"",
        folder / "stderr.before-cleanup.bin": KILL_INFO,
        folder / "grandchild.before-cleanup.marker": b"1002",
    })
    probe_argv = [sys.executable, *d.isolated_args(), str(d.PROBE), "1002"]

    def fake_probe(cmd, *, timeout, capture_output):
        assert cmd == probe_argv and timeout == 10.0 and capture_output is True
        return SimpleNamespace(returncode=0, stdout=b"", stderr=b"")

    def run_slot(slot, config, observer, event_dir):
        observer.launch(argv, 1, stdin=subprocess.DEVNULL,
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        done = runner.subprocess.run(probe_argv, timeout=10.0, capture_output=True)
        return {"path": "kill", "argv": argv, "exit_code": 124, "outcome": "ok",
                "tree_marker": str(marker), "arm_pid": 1001, "child_pid": None, "grandchild_pid": 1002,
                "survivor": bool(done.returncode), "slot_job": observer.drain()}

    runner = SimpleNamespace(_observe_output=object(), _run_slot=run_slot,
                             subprocess=SimpleNamespace(run=fake_probe))
    row = d.observe_case(folder, "default", SimpleNamespace(path="kill"), {}, runner, lambda: native)
    d.validate_case(folder, row, planned)
    assert native.drained and native.closed
    refuse(folder, row, planned, lambda r: r.update(child_pid=1003), "PID identities")
    refuse(folder, row, planned, lambda r: r["before_cleanup_marker"].update(sha256="wrong"), "retained marker")
    refuse(folder, row, planned, lambda r: r["isolated_probe"]["argv"].remove("-I"), "isolated survivor")


def obstructed(out):
    folder = out / "kill-obstructed"
    folder.mkdir()
    marker = out / "tmp" / "ptg-kill-obstructed.marker"
    fixed = folder / "stdout.before-cleanup.bin"
    fixed.write_bytes(b"preexisting")
    native = FakeNative({fixed: b"preexisting"})
    observer = d.RecordingJob(native, folder, True)
    try:
        observer.launch(["fake-arm", "mark", str(marker), "30"], 1,
                        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        assert observer.drain()["active_after"] == 0
        assert observer.capture_error
    finally:
        observer.close()
    assert native.drained and native.closed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.parent != HERE:
        raise ValueError("fresh scratch child required")
    d.require_fresh_prefix(output)
    output.mkdir()
    (output / "tmp").mkdir()
    fast(output)
    kill(output)
    obstructed(output)
    d.require_fresh_prefix(output)
    print(json.dumps({"state": "SYNTHETIC_PASS", "paths": 3, "invalid_rows_refused": 5,
                      "real_slots_launched": 0}, indent=2))


if __name__ == "__main__":
    main()
