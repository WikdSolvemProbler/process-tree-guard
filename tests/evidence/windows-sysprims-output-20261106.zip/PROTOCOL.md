# SysPrims v0.2.4 output and kill controls, revision 002

This Windows diagnostic asks whether the archived SysPrims executable preserves the relay fixture's exact stdout and stderr when its own INFO tracing is filtered. It also exercises default and explicit logging modes against the archived kill fixture. The earlier diagnostic draft and the completed 1,940-slot archive each retain their own evidence and verdicts.

## Fixed inputs and order

Use the archive, source, Python, isolated guard, SysPrims and testkit digests pinned in diagnostic.py. The archived complete/staged-hashes.json independently binds both candidate executables and complete/campaign.json. The survivor probe is the corrected implementation at e73981af6bf380cc1ac0dfec52a8806b7cbf8b71, with the exact probe.py digest pinned in the driver.

Both fast modes use the archive relay fixture, exact input ptg-output-stdout, 10000ms and exit 0. Both kill modes use the archive spawn and marker fixture, 2000ms and exit 124. The explicit mode inserts one top-level --log-level=warn token before timeout. The worker removes RUST_LOG case-insensitively before both modes. Both contexts use the unchanged campaign creation flags.

| Slot | Context | Path | Mode |
| ---: | --- | --- | --- |
| 0 | NO_WINDOW | fast | default |
| 1 | NO_WINDOW | fast | warn |
| 2 | NO_WINDOW | kill | warn |
| 3 | NO_WINDOW | kill | default |
| 4 | DETACHED | fast | warn |
| 5 | DETACHED | fast | default |
| 6 | DETACHED | kill | default |
| 7 | DETACHED | kill | warn |

## Admission and finite execution

Two independent Sol reviewers must approve the same frozen manifest, source, launcher and output paths before a live capture. Use one bounded attempt and preserve partial and terminal evidence. The launcher must use the canonical repository tests directory as its working directory. The exact native guard argv consists of its absolute pinned image, --timeout 110 --, the pinned absolute python.exe, -I -B -X pycache_prefix=<absolute attempt sibling named ATTEMPT.pycache>, the absolute revision 002 diagnostic.py, then --capture <absolute fresh direct scratch child ATTEMPT>. Bind the actual invocation, parent and terminal receipt externally. The driver records the expected argv and checks the pinned bytes at admission and completion.

The Python worker and every actual survivor probe use isolated mode, bytecode writes disabled, and the same explicit absent pycache prefix. The driver verifies the prefix is fresh before loading the campaign modules, at each probe, and after each slot. The private attempt directory contains a new tmp directory for both TEMP and TMP. All arms and the survivor probe inherit the fixed tests working directory and private temp configuration. The existing native SlotJob admits each arm atomically. The unchanged runner bounds the arm wait at 30 seconds and the survivor probe at 10 seconds. The native Job bounds cleanup at five seconds. The 110-second outer guard contains the controller and all auxiliary processes. Earlier guard or runner deadlines may end an invalid attempt before every slot is attempted.

## Oracles and evidence

Every slot must prove zero active Job processes before and after drainage with zero harness termination interventions. The monotonic interval starts before native Job and arm setup and ends at terminal native Job accounting. It must be strictly below 20 seconds in every slot. The fixture's normal 30-second worker sleeps therefore cannot supply a passing cleanup observation. This interval is a correctness limit.

Keep actual argv, raw stdout and stderr snapshots, and the original runner record. The fast path copies the original regular files before the existing output oracle and Job drainage. The diagnostic uses regular stdout and stderr files in both kill modes to preserve SysPrims diagnostics, while the production campaign uses DEVNULL for all kill streams. Diagnostic kill stdin still uses DEVNULL. A stream snapshot is capped at 65,536 bytes and truncation refuses the result.

A fast default control must show exact stdout, zero exit, the fixture stderr substring and the logged stderr mismatch. A fast WARN control must match both fixture streams exactly, with stdout ptg-output-stdout followed by LF and stderr error-stream followed by LF. Both modes must match the runner's captured digests.

A kill control must return 124 and pass the independent survivor probe before native Job drainage. The exact archived testkit spawn command publishes only its grandchild's marker. All 198 archived SysPrims kill records carry the grandchild PID and a null child PID. Retain raw grandchild marker bytes before the runner removes its temp files, check that the marker contains exactly the runner's positive DWORD grandchild PID, require the absent direct-child marker, and verify the actual isolated probe used that exact PID and returned zero. Job accounting applies to the whole slot. The external PID probe covers the published grandchild.

The default kill control must expose the INFO timeout reliability diagnostic. The WARN kill control tests the same workload with that diagnostic filtered. SysPrims attaches its Job after spawning and can fall back to direct-child termination, so the fixture result cannot establish equivalence with atomic containment.

This diagnostic records no speed, quiet-host, protection-equivalence or campaign qualification verdict. Raw capture adds work to the runner's elapsed fields. A future WARN-only fast configuration requires a separate frozen campaign design and an explicit distinction between fast and malformed template generation. The measured kill and scaling configuration should preserve default logging.

## No-launch validation

The inspect mode verifies eight argv vectors, all exact pins, the grandchild-only archive census and the isolated runner and probe setup. The companion synthetic adapter checks fast and kill stream and marker preservation, the restored runner hooks, and unconditional drainage after a failed snapshot. Five mutated rows check the natural-settlement, strict deadline, identity, raw marker and probe gates. All these checks use in-process stubs.

[SysPrims log option](https://github.com/3leaps/sysprims/blob/v0.2.4/crates/sysprims-cli/src/main.rs#L77-L85) · [Timeout reliability log](https://github.com/3leaps/sysprims/blob/v0.2.4/crates/sysprims-cli/src/main.rs#L1066-L1135) · [Windows Job assignment and fallback](https://github.com/3leaps/sysprims/blob/v0.2.4/crates/sysprims-timeout/src/windows.rs#L463-L509)
