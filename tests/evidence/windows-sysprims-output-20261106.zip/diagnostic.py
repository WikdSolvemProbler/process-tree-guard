"""Eight SysPrims Windows correctness controls, with an explicit no-launch inspect mode."""

import argparse
from copy import deepcopy
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TESTS = ROOT / "tests"
CAMPAIGN = TESTS / "campaign"
ARCHIVE = TESTS / "evidence/windows-campaign-20261106.zip"
EXE = TESTS / "build/competitors/sysprims.exe"
FIXTURE = TESTS / "build/testkit.exe"
GUARD = Path("C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe")
PROBE = CAMPAIGN / "probe.py"
OUTER_SECONDS = 110
MAX_SLOT_NS = 20_000_000_000
PINS = {
    ARCHIVE: "ef653c4fb2921adc9e466f767225ba257b26e0b9adecf354b8000f30ccf751bd",
    EXE: "0a3144a6ca7b2df7ee382bbbac85d89f5ed75ee2643e1036356a8eaa4d490867",
    FIXTURE: "c92afd62a1327399d5c2516de53e94ad0d4b7f05de4318f32aa2838b5220ce92",
    CAMPAIGN / "runner.py": "ab0ce012de2644d115633a13459f80746ec99b46b3332d2ef9ed7c4dafcac3f4",
    CAMPAIGN / "windows_slot_job.py": "a4d1ee810a6db1565f1e22bdc13dd3d535bbf08e487b594234d0a79922094e15",
    CAMPAIGN / "plan.py": "a616a82dbeebfe5041fc55d55733d06c4b0c2af27614884c097ae3b0bb52a3bf",
    PROBE: "5858ad7e97c93e95941965c4c15ae295f147f091c3cedb482d68257a16733433",
    GUARD: "1899137f687541256fb89749b2fe6a2940f2e420faaf2330fc84f32cfd7fae43",
    TESTS / "support/testkit.rs": "b0e10b5799fe8674cbfe44c0170be89fb52cea0422187cc2c0234c4484ce66cb",
    CAMPAIGN / "arms.py": "e2ce9da8136c1d6aefc126c26cc6dfc0ed4adac97d86f7a2734099ca05f82806",
    Path(sys.executable): "4d6f5f81a4bca11191c4c7c6b43632694d0a4ce74e068619d8fdc161d469859a",
}
WARN = "--log-level=warn"
TEMPLATE = ["timeout", "{timeout_ms}ms", "{child}", "{child_args}"]
STDIN = "ptg-output-stdout"
EXPECTED = {"stdout": b"ptg-output-stdout\n", "stderr": b"error-stream\n"}
MAX_STREAM_BYTES = 65536
ORDER = (
    ("NO_WINDOW", "fast", "default"),
    ("NO_WINDOW", "fast", "warn"),
    ("NO_WINDOW", "kill", "warn"),
    ("NO_WINDOW", "kill", "default"),
    ("DETACHED", "fast", "warn"),
    ("DETACHED", "fast", "default"),
    ("DETACHED", "kill", "default"),
    ("DETACHED", "kill", "warn"),
)


def require(ok, why):
    if not ok:
        raise ValueError(why)


def digest(path):
    with path.open("rb") as file:
        return file_digest(file, "sha256").hexdigest()


def pinned_inputs():
    for path, expected in PINS.items():
        require(digest(path) == expected, f"input identity differs: {path}")
    with ZipFile(ARCHIVE) as bundle:
        raw = bundle.read("complete/campaign.json")
        archived = json.loads(bundle.read("complete/staged-hashes.json"))
        pins = {entry["Path"]: entry["Hash"].lower() for entry in archived}
        require(pins[str(EXE)] == PINS[EXE] and pins[str(FIXTURE)] == PINS[FIXTURE],
                "archive does not bind both executable pins")
        require(sha256(raw).hexdigest() == pins[str(TESTS / "campaign.json")],
                "archive campaign configuration digest differs")
        archived_kills = 0
        with bundle.open("complete/observations.jsonl") as records:
            for line in records:
                row = json.loads(line)
                if row["arm"] == "sysprims" and row["path"] == "kill":
                    require(row["child_pid"] is None and type(row["grandchild_pid"]) is int
                            and 0 < row["grandchild_pid"] <= 0xFFFFFFFF,
                            "archive fixture marker shape differs")
                    archived_kills += 1
        require(archived_kills == 198, "archive kill marker census differs")
    config = json.loads(raw)
    sysprims = config["arms"]["sysprims"]
    require(sysprims["templates"] == {"fast": TEMPLATE, "kill": TEMPLATE},
            "archive SysPrims templates differ")
    require(sysprims["expected_exit"] == {"fast": 0, "kill": 124}, "archive exit oracles differ")
    require(TESTS / sysprims["executable"] == EXE, "archive SysPrims path differs")
    sysprims["executable"] = str(EXE)
    for path in ("fast", "kill"):
        child = config["children"][path]
        require(TESTS / child["program"] == FIXTURE, "archive fixture path differs")
        child["program"] = str(FIXTURE)
    fast = config["children"]["fast"]
    require(fast["args"] == ["relay", "0"] and fast["stdin"] == STDIN
            and all(fast[f"expected_{label}"].encode() == expected for label, expected in EXPECTED.items()),
            "archive fast workload differs")
    require(config["children"]["kill"]["args"] ==
            ["spawn", "0", "{sleep_s}", "{self}", "mark", "{marker}", "{sleep_s}"],
            "archive kill workload differs")
    require(config["survivor_checker"] == ["python", "campaign\\probe.py"],
            "archive survivor oracle differs")
    config["survivor_checker"] = ["python", *isolated_args(), str(PROBE)]
    return config


def isolated_args():
    return ["-I", "-B", "-X", f"pycache_prefix={sys.pycache_prefix}"]


def guarded_argv(out):
    return [
        str(GUARD), "--timeout", str(OUTER_SECONDS), "--", sys.executable,
        *isolated_args(), str(Path(__file__).resolve()), "--capture", str(out),
    ]


def require_fresh_prefix(out=None):
    require(sys.pycache_prefix is not None, "explicit fresh pycache prefix required")
    prefix = Path(sys.pycache_prefix)
    require(prefix.is_absolute() and prefix.parent == HERE and prefix == prefix.resolve(),
            "pycache prefix must be a direct canonical scratch child")
    if out is not None:
        require(prefix == out.with_name(out.name + ".pycache"), "attempt and pycache namespace differ")
    require(not prefix.exists() and not prefix.is_symlink(), "pycache prefix already exists")


def configured(config, mode, path):
    result = deepcopy(config)
    if mode == "warn":
        result["arms"]["sysprims"]["templates"][path].insert(0, WARN)
    return result


def planned_argv(runner, slot, config):
    from arms import expand_template, resolve_template

    child, arguments = runner.child_for(slot, config, "<slot-marker>")
    timeout = runner.FAST_TIMEOUT_S if slot.path == "fast" else runner.KILL_TIMEOUT_S
    template = resolve_template(slot.arm, slot.path, config)
    return [str(EXE), *expand_template(template, timeout, child, arguments)]


def verify_plan(config, runner, make_slot):
    require(runner.SLOT_DEADLINE_S == 30.0 and runner.PROBE_DEADLINE_S == 10.0,
            "runner slot/probe bounds differ")
    require(runner.creation_flags("NO_WINDOW") == 0x08000000
            and runner.creation_flags("DETACHED") == 0x208, "runner Windows creation flags differ")
    slots = []
    for ordinal, (context, path, mode) in enumerate(ORDER):
        slot = make_slot("control", "sysprims", path, context, ordinal)
        actual = planned_argv(runner, slot, configured(config, mode, path))
        base = [str(EXE), "timeout", "10000ms" if path == "fast" else "2000ms", str(FIXTURE)]
        tail = (["relay", "0"] if path == "fast"
                else ["spawn", "0", "30", str(FIXTURE), "mark", "<slot-marker>", "30"])
        if mode == "warn":
            base.insert(1, WARN)
        require(actual == base + tail, f"slot {ordinal} argv differs")
        slots.append({"context": context, "path": path, "mode": mode, "argv": actual})
    return slots


def durable_write(path, data):
    with path.open("xb") as file:
        file.write(data)
        file.flush()
        os.fsync(file.fileno())


def save_json(path, value):
    durable_write(path, (json.dumps(value, indent=2, allow_nan=False) + "\n").encode())


class RecordingJob:
    def __init__(self, native_job, folder, kill):
        self.job = native_job
        self.folder = folder
        self.kill = kill
        self.streams = {}
        self.captured = {}
        self.capture_error = None
        self.marker = None
        self.captured_marker = None
        self.drain_ns = None

    def launch(self, argv, creationflags, *, stdin, stdout, stderr):
        if self.kill:
            require(stdin == stdout == stderr == subprocess.DEVNULL,
                    "kill stdio differs from the archived runner")
            require(argv[-3] == "mark" and argv[-1] == "30", "unexpected kill marker argument")
            self.marker = Path(argv[-2])
            require(self.marker.parent == self.folder.parent / "tmp"
                    and self.marker.name.startswith("ptg-kill-")
                    and self.marker.suffix == ".marker", "marker is outside fresh attempt temp")
            for label in EXPECTED:
                self.streams[label] = (self.folder / f"{label}.arm.bin").open("xb")
            stdout, stderr = self.streams["stdout"], self.streams["stderr"]
        return self.job.launch(argv, creationflags, stdin=stdin, stdout=stdout, stderr=stderr)

    def snapshot(self, label, path):
        with Path(path).open("rb") as source:
            data = source.read(MAX_STREAM_BYTES + 1)
        kept = data[:MAX_STREAM_BYTES]
        durable_write(self.folder / f"{label}.before-cleanup.bin", kept)
        self.captured[label] = {"bytes": len(kept), "sha256": sha256(kept).hexdigest(),
                                "truncated": len(data) > MAX_STREAM_BYTES}

    def snapshot_marker(self):
        require(self.marker is not None and self.marker == self.marker.resolve(strict=True),
                "fixture marker missing or redirected")
        child = self.marker.with_name(self.marker.name + ".child")
        with self.marker.open("rb") as file:
            raw = file.read(65)
        durable_write(self.folder / "grandchild.before-cleanup.marker", raw)
        require(len(raw) <= 64, "fixture marker exceeds its size bound")
        self.captured_marker = {
            "path": str(self.marker), "bytes": len(raw), "sha256": sha256(raw).hexdigest(),
            "child_marker_present": child.exists() or child.is_symlink(),
        }
        if self.captured_marker["child_marker_present"]:
            require(child == child.resolve(strict=True), "unexpected child marker was redirected")
            with child.open("rb") as file:
                durable_write(self.folder / "child.before-cleanup.marker", file.read(65))

    def drain(self):
        try:
            if self.kill:
                for label, stream in self.streams.items():
                    self.snapshot(label, stream.name)
                self.snapshot_marker()
        except (OSError, ValueError) as error:
            self.capture_error = str(error)
        finally:
            drained = self.job.drain()
            self.drain_ns = time.perf_counter_ns()
        return drained

    def close(self):
        try:
            self.job.close()
        finally:
            for stream in self.streams.values():
                stream.close()


class ProbeRecorder:
    def __init__(self, module):
        self.module = module
        self.receipt = None

    def __getattr__(self, name):
        return getattr(self.module, name)

    def run(self, argv, *, timeout, capture_output):
        expected = [sys.executable, *isolated_args(), str(PROBE)]
        require(self.receipt is None and len(argv) == len(expected) + 1
                and argv[:-1] == expected and argv[-1].isdigit()
                and 0 < int(argv[-1]) <= 0xFFFFFFFF
                and timeout == 10.0 and capture_output is True, "actual probe invocation differs")
        require_fresh_prefix()
        self.receipt = {"argv": argv, "exit": None}
        result = self.module.run(argv, timeout=timeout, capture_output=capture_output)
        self.receipt.update(exit=result.returncode, stdout_sha256=sha256(result.stdout).hexdigest(),
                            stderr_sha256=sha256(result.stderr).hexdigest())
        require_fresh_prefix()
        return result


def observe_case(folder, mode, slot, config, runner, job_type):
    began = time.perf_counter_ns()
    observer = RecordingJob(job_type(), folder, slot.path == "kill")
    original_observe = runner._observe_output
    original_subprocess = runner.subprocess
    probe = ProbeRecorder(original_subprocess)

    def capture_fast(record, expected, out_path, err_path):
        observer.snapshot("stdout", out_path)
        observer.snapshot("stderr", err_path)
        original_observe(record, expected, out_path, err_path)

    try:
        runner._observe_output = capture_fast
        runner.subprocess = probe
        row = runner._run_slot(slot, config, observer, None)
    finally:
        runner._observe_output = original_observe
        runner.subprocess = original_subprocess
        observer.close()
    row["qualification_mode"] = mode
    row["before_cleanup_streams"] = observer.captured
    row["capture_error"] = observer.capture_error
    row["before_cleanup_marker"] = observer.captured_marker
    row["isolated_probe"] = probe.receipt
    row["setup_started_ns"] = began
    row["job_settled_ns"] = observer.drain_ns
    save_json(folder / "slot.json", row)
    return row


def validate_case(folder, row, scenario):
    require(row["capture_error"] is None and set(row["before_cleanup_streams"]) == set(EXPECTED),
            "incomplete before-cleanup streams")
    data = {}
    for label, meta in row["before_cleanup_streams"].items():
        raw = (folder / f"{label}.before-cleanup.bin").read_bytes()
        require(meta == {"bytes": len(raw), "sha256": sha256(raw).hexdigest(), "truncated": False},
                f"{label} evidence differs or was truncated")
        data[label] = raw
    argv = list(row["argv"])
    if row["path"] == "kill":
        require(isinstance(row["tree_marker"], str) and argv.count(row["tree_marker"]) == 1,
                "exact marker path missing from kill argv")
        argv[argv.index(row["tree_marker"])] = "<slot-marker>"
    require(argv == scenario["argv"], "executed argv differs")
    job = row["slot_job"]
    require(job["active_before"] == 0 and job["active_after"] == 0 and job["terminated"] is False,
            "slot Job did not settle naturally at zero")
    began, settled = row["setup_started_ns"], row["job_settled_ns"]
    require(type(began) is int and type(settled) is int and 0 <= settled - began < MAX_SLOT_NS,
            "20-second setup-to-Job-settlement correctness bound failed")
    mode = row["qualification_mode"]
    if row["path"] == "fast":
        require(row["before_cleanup_marker"] is None and row["isolated_probe"] is None,
                "unexpected fast marker or probe")
        require(row["exit_code"] == 0 and data["stdout"] == EXPECTED["stdout"],
                "fast status or stdout mismatch")
        for label in EXPECTED:
            require(row[f"output_{label}_sha256"] == sha256(data[label]).hexdigest(),
                    f"runner {label} digest differs from retained bytes")
        if mode == "warn":
            require(row["outcome"] == "ok" and data["stderr"] == EXPECTED["stderr"],
                    "explicit WARN output contract failed")
        else:
            require(row["outcome"] == "output-mismatch"
                    and EXPECTED["stderr"] in data["stderr"]
                    and b"Running command with timeout" in data["stderr"],
                    "default logging control did not reproduce the expected mismatch")
    else:
        require(row["exit_code"] == 124 and row["survivor"] is False and row["outcome"] == "ok",
                "kill status or pre-drain survivor verdict differs")
        pid = row["grandchild_pid"]
        require(row["child_pid"] is None and type(pid) is int and 0 < pid <= 0xFFFFFFFF
                and pid != row["arm_pid"], "unexpected fixture PID identities")
        raw = (folder / "grandchild.before-cleanup.marker").read_bytes()
        require(raw == str(pid).encode("ascii") and row["before_cleanup_marker"] == {
            "path": row["tree_marker"], "bytes": len(raw), "sha256": sha256(raw).hexdigest(),
            "child_marker_present": False,
        }, "retained marker does not match the exact parsed fixture PID")
        probe = row["isolated_probe"]
        require(probe["argv"] == [sys.executable, *isolated_args(), str(PROBE), str(pid)]
                and probe["exit"] == 0 and probe["stdout_sha256"] == sha256(b"").hexdigest()
                and probe["stderr_sha256"] == sha256(b"").hexdigest(),
                "isolated survivor probe receipt differs from the captured marker")
        timed_out_diagnostic = b"Command timed out" in data["stderr"]
        require(timed_out_diagnostic == (mode == "default"), "kill INFO diagnostic control differs")
        if mode == "default":
            require(b"reliability" in data["stderr"], "default reliability diagnostic missing")


def capture(out, config, runner, slot_type, job_type, slots):
    require(out.is_absolute() and out.parent == HERE and out == out.resolve()
            and not out.exists() and not out.is_symlink(), "output must be a fresh direct scratch child")
    require_fresh_prefix(out)
    for name in list(os.environ):
        if name.upper() == "RUST_LOG":
            del os.environ[name]
    require(not any(name.upper() == "RUST_LOG" for name in os.environ), "RUST_LOG is still present")
    out.mkdir()
    temp = out / "tmp"
    temp.mkdir()
    for name in list(os.environ):
        if name.upper() in ("TEMP", "TMP"):
            del os.environ[name]
    os.environ.update(TEMP=str(temp), TMP=str(temp))
    tempfile.tempdir = None
    require(Path(tempfile.gettempdir()) == temp, "controller temp is outside the fresh attempt")
    terminal = {"state": "RUNNING", "expected": len(slots), "completed": 0, "error": None}
    save_json(out / "plan.json", {
        "slots": slots, "rust_log_present": False, "no_latency_verdict": True,
        "cwd": str(Path.cwd()), "temp": str(temp), "tmp": str(temp),
        "pycache_prefix": sys.pycache_prefix, "guarded_argv": guarded_argv(out),
        "probe_argv_prefix": [sys.executable, *isolated_args(), str(PROBE)],
        "kill_output_capture": "regular files in both diagnostic modes",
        "pin_sha256": {str(path): digest(path) for path in PINS},
    })
    save_json(out / "started.json", terminal)
    try:
        for i, scenario in enumerate(slots):
            folder = out / f"{i:02d}"
            folder.mkdir()
            save_json(folder / "planned.json", scenario)
            context, path, mode = (scenario[key] for key in ("context", "path", "mode"))
            slot = slot_type("control", "sysprims", path, context, i)
            case_config = configured(config, mode, path)
            row = observe_case(folder, mode, slot, case_config, runner, job_type)
            validate_case(folder, row, scenario)
            require_fresh_prefix(out)
            require(Path.cwd() == TESTS and Path(tempfile.gettempdir()) == temp,
                    "controller CWD or temp changed")
            terminal["completed"] += 1
        for path, expected in PINS.items():
            require(digest(path) == expected, f"terminal pin differs: {path}")
        terminal["state"] = "COMPLETE"
    except BaseException as error:
        terminal.update(state="REFUSED", error=repr(error))
        raise
    finally:
        save_json(out / "terminal.json", terminal)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--inspect", action="store_true", help="verify pins and plan without launching slots")
    modes.add_argument("--capture", type=Path, metavar="FRESH_OUTPUT_DIRECTORY")
    args = parser.parse_args()
    require(sys.platform == "win32" and sys.flags.isolated and sys.dont_write_bytecode,
            "use pinned Windows Python -I -B -X pycache_prefix=<fresh>")
    require(Path.cwd() == TESTS, "fixed canonical tests CWD required")
    require_fresh_prefix()
    config = pinned_inputs()
    sys.path.insert(0, str(CAMPAIGN))
    from plan import Slot
    import runner
    from windows_slot_job import CLEANUP_TIMEOUT_S, SlotJob

    require(CLEANUP_TIMEOUT_S == 5.0, "slot Job cleanup deadline differs")
    slots = verify_plan(config, runner, Slot)
    if args.inspect:
        print(json.dumps({
            "state": "VALIDATED_NO_LAUNCH", "slots": slots, "cases": len(slots),
            "cwd": str(Path.cwd()), "pycache_prefix": sys.pycache_prefix,
            "probe_argv_prefix": [sys.executable, *isolated_args(), str(PROBE)],
            "guard_sha256": PINS[GUARD], "outer_seconds": OUTER_SECONDS,
            "archived_sysprims_kill_slots_with_grandchild_only": 198,
        }, indent=2))
        return
    capture(args.capture, config, runner, Slot, SlotJob, slots)


if __name__ == "__main__":
    main()
