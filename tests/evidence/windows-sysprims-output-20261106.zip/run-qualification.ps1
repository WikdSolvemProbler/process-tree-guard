param(
    [Parameter(Mandatory)][string]$Manifest,
    [Parameter(Mandatory)][string]$ManifestSha256,
    [Parameter(Mandatory)][string]$Approval,
    [Parameter(Mandatory)][string]$ApprovalSha256
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false

function Digest([string]$Path) {
    (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

function Read-Record([string]$Path) {
    Get-Content -LiteralPath $Path -Raw -Encoding utf8 | ConvertFrom-Json -AsHashtable
}

if ((Digest $Manifest) -cne $ManifestSha256 -or (Digest $Approval) -cne $ApprovalSha256) {
    throw 'Manifest or approval digest mismatch'
}
$plan = Read-Record $Manifest
$review = Read-Record $Approval
if ($plan.schema -cne 'ptg-sysprims-output-v2' -or $review.schema -cne $plan.schema -or
    $review.state -cne 'APPROVED' -or $review.manifest_sha256 -cne $ManifestSha256 -or
    $review.unresolved_objections -ne 0 -or
    ($review.reviewers -join ',') -cne 'sysprims_review_method,sysprims_review_critic') {
    throw 'The exact diagnostic has not passed both independent reviews'
}
$invocation = $plan.invocation
if ($Manifest -cne $invocation.manifest -or $Approval -cne $invocation.approval -or
    $invocation.primary_timeout_seconds -ne 110 -or
    $plan.assets.wrapper.path -cne $PSCommandPath) {
    throw 'Wrapper or invocation differs from the manifest'
}
foreach ($path in @($invocation.attempt, $invocation.pycache_prefix, $invocation.receipt)) {
    if (Test-Path -LiteralPath $path) { throw "Attempt paths must be fresh: $path" }
}
$guard = $plan.assets.outer_guard.path
$argv = @(
    '--timeout', '110', '--', $plan.assets.controller_python.path, '-I', '-B',
    '-X', "pycache_prefix=$($invocation.pycache_prefix)", $plan.assets.driver.path,
    '--capture', $invocation.attempt
)
if (($argv -join [char]0) -cne ($invocation.primary_argv -join [char]0)) {
    throw 'Primary guard argv differs from the manifest'
}

$assets = [ordered]@{}
foreach ($role in $plan.assets.Keys) { $assets[$role] = $plan.assets[$role] }
$assets.manifest = @{path=$Manifest;sha256=$ManifestSha256}
$assets.approval = @{path=$Approval;sha256=$ApprovalSha256}
$held = [System.Collections.Generic.List[System.IO.FileStream]]::new()
try {
    foreach ($role in $assets.Keys) {
        $binding = $assets[$role]
        $stream = [IO.File]::Open($binding.path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
        $held.Add($stream)
        $actual = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()
        if ($actual -cne $binding.sha256) { throw "Held input differs: $role" }
    }
    New-Item -ItemType Directory -Path $invocation.receipt -ErrorAction Stop | Out-Null
    $stdout = Join-Path $invocation.receipt 'stdout.log'
    $stderr = Join-Path $invocation.receipt 'stderr.log'
    Set-Location -LiteralPath $invocation.cwd
    $started = [DateTimeOffset]::UtcNow.ToString('o')
    & $guard @argv 1> $stdout 2> $stderr
    $code = $LASTEXITCODE
    $finished = [DateTimeOffset]::UtcNow.ToString('o')
    $terminalPath = Join-Path $invocation.attempt 'terminal.json'
    $terminal = $null
    $terminalSha = $null
    $terminalReadError = $null
    if (Test-Path -LiteralPath $terminalPath -PathType Leaf) {
        $terminalSha = Digest $terminalPath
        try { $terminal = Read-Record $terminalPath } catch { $terminalReadError = $_.Exception.Message }
    }
    $heldOk = $true
    foreach ($role in $assets.Keys) {
        $binding = $assets[$role]
        if ((Digest $binding.path) -cne $binding.sha256) { $heldOk = $false }
    }
    $receipt = [ordered]@{
        schema = 'ptg-sysprims-wrapper-v2'
        manifest_sha256 = $ManifestSha256
        approval_sha256 = $ApprovalSha256
        primary_guard = $guard
        primary_guard_sha256 = $plan.assets.outer_guard.sha256
        primary_argv = $argv
        primary_exit = $code
        cwd = $invocation.cwd
        started_utc = $started
        finished_utc = $finished
        held_inputs_verified = $heldOk
        stdout_sha256 = Digest $stdout
        stderr_sha256 = Digest $stderr
        terminal_sha256 = $terminalSha
        terminal_read_error = $terminalReadError
    }
    $bytes = [Text.Encoding]::UTF8.GetBytes(($receipt | ConvertTo-Json -Depth 8) + [Environment]::NewLine)
    $pending = Join-Path $invocation.receipt 'wrapper.pending.json'
    $stream = [IO.File]::Open($pending, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
    } finally {
        $stream.Dispose()
    }
    [IO.File]::Move($pending, (Join-Path $invocation.receipt 'wrapper.json'))
    if ($code -ne 0) { exit $code }
    if (!$heldOk -or $null -eq $terminal -or $terminal.state -cne 'COMPLETE' -or
        $terminal.expected -ne 8 -or $terminal.completed -ne 8) { exit 125 }
    exit 0
} finally {
    foreach ($stream in $held) { $stream.Dispose() }
}
