# Linux native Rust supervision proof

The Ubuntu ARM64 guest received the proof through a Tailscale SSH connection to its Mac host. The Windows launch was inside an isolated 66-second Job Object. The Mac imposed a 50-second deadline plus a 3-second kill grace on the SSH command's guest entry point. The guest used a 42-second systemd user scope for preparation and a separate root-owned 30-second system scope for the proof. Both guest scopes used control-group SIGKILL.

The guest caller compiled the source with Rust 1.99.0. The privileged recipe verified the SHA-256 of the executable after copying it into root-owned storage. The guest recipes and transcripts preserve the exact inner commands and toolchain. The independent cleanup check verified both scopes and scratch directories were absent.

The proof uses fixed fixture credentials and only synthetic workloads. The archive captures prototype behavior on this guest.