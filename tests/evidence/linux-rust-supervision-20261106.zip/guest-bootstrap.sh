set -eu
umask 077
[ "$(/usr/bin/id -u)" = 501 ]
[ "$(/usr/bin/id -g)" = 1000 ]
[ "$(/usr/bin/cat /proc/$$/cgroup)" = "0::/user.slice/user-501.slice/user@501.service/app.slice/ptg-linux-rust-bootstrap-20261106-e52a60a2.scope" ]
/usr/bin/grep -E '^(Uid|Gid|Groups|CapEff|NoNewPrivs):' /proc/$$/status
groups=$(/usr/bin/awk '$1=="Groups:" && NF==3 {print $2 " " $3; exit}' /proc/$$/status)
[ "$groups" = '999 1000' ]
/usr/bin/systemctl --user show ptg-linux-rust-bootstrap-20261106-e52a60a2.scope --property=RuntimeMaxUSec,KillMode,KillSignal
build=/tmp/ptg-linux-rust-build-20261106-e52a60a2
/usr/bin/mkdir -m 700 -- "$build"
cleanup_build() {
    result=$?
    trap - EXIT
    if /usr/bin/rm -f -- "$build/proof.rs" "$build/proof" && /usr/bin/rmdir -- "$build" && [ ! -e "$build" ]; then
        printf 'user_build_removed=%s\n' "$build"
    else
        result=93
    fi
    exit "$result"
}
trap cleanup_build EXIT
printf '%s' 'H4sIAAAAAAAACs1dfVPcyNH/n08x3lRx2pxYdgHbZ3HrKx+sbSocuMDJJUVRKiGNQEErKdIshgDf/anunldJu6wveaqyyeGVNC89PT093b/u0W5vv2InkcjuODvOisU9E7wRrOHRnKVlzcQNZ3VZiq3yW8ETVtVlzJtmS9Scw0WZjjb+9OoiTq+9KM89EdXXXIRlw6ZskENzA59FxYN6ENXxDTyK4MubvYHPWg/uf3oTvtkbDIfDy42NRcNZI5IgSNMsCB4PzkWdFdc+i8P4Jqrh36wQ8E9e0u2FvL4rs+R536rfBMFjw/PUZx+znPvstOLFaSWysmjsclmpy/1eZ4Lbz+Z8HgRN9m8elql1u2yCIE2C4PFDcxZ9+5j47GNdzuXXU+AZfMHr51a1RZHdy7GdNueint2L/hJA/W9cREkkotm9cMif3Qu73SoSN0Hw+CUSNz6Dv78uUue5qK2r5qGIgyAS5TyLYQj45Wh3x2endcKB2XZdkc15EDweLuoIuvbZUdGIqID+N+KyaAQ7P/r0l6Pj44Bluztsyt7tm/tfjr7M1P3JrvXg4PPxYcAWb/bgwVv14OD4dPb32YGqMS53wvF4DP+pEienH0+Pj09/N0X23AJfPnz9HH48NM8n+Ngucnh0Njv4enr2D6sft8TH8PCvXz4ehi16JuNdXWR2dPL1TD3Y03cPPh/BwFR5fd9mxO6Ovn1yOjv5qu7r219Oj4+PTgKWTd5AK/btz3/9ou+/sdh28Jfw19PTr1+PftPdaK6e/+M8/HJ0+PEwPJ+dHIbnR59OPhwHcgEB9Tt73aKnX2Yndpldp8zB8enJbNd5/rr1/HwWnn04+TRzCr3Z39j400XNq9o7GF5uNKJexIJ9KfP8Y8IeWZpAaVzO/I4XosGx+qy2rtiz3cKfLkBi77h3kJcF99lBWT347JCn0SIXpoev2Zw3FY/ZI2t4XBYJtPVmz2dFVJT03W1X1jsC6a/PqWZWCF7fRXmgm/PZXZQvuLmxhLgOPUjth/q6YY8bjDGW5tF1g+vBZ1WWAB/we3yT5UkoMnVdRTUvhHWD32cibLLrAsiCO9hcI6L4VpbA7yGoMHlD5KqnhttNySu7aHxdl4tKNvy8sbEomijljN8LXhdscDBQ5BeseWhi2AuKxfyK12rSfTYajYZs67283lfF07K+9eSDrBD6fpVVfMeDvwH783whlDhIBuFVX7Uyz70UZhUrkUD5LC4XhQjYAobkM5jLciGWt1LzKPEsGQTNq8mA3cVnOS9ke1g/g2+6/jfYPXoaoHWxVhNxXjZWEz1EJotq1ytz00nBvwVrsimNCwF80uXjcj6PCnNtZsuu9i3KRJUlXpWZko2IxELxe73e47yMb8NrLmAiPLzSzcl1hK2pxdTTBC7HNAnjmkei3cYL3au6jSTAYoNd09BC02ZUgM+Q7UijudvTE61HTy1L2exNVCQ5LA0z9/jNCHEdi9wrcYfXtaL6esespqi+3nWu9pyr1+qqjygucDU3nrsq6KYlpWBO9deveXOdJV7NaVRkd/E05TEYkuZWE91xZO7Kphb/jaauueDQkHy0aD+7XvKsihYN71NA/J7Hd9xDi8rwhCzPqL6+0zdbz3ix5FFPH/N5VHlRktRLlYsPVrZYIp+W4JZp2nCB+xf2YzVneoOmeCy+o8c+mhfFi1T3VAthg/KUsjCNv9qH/UQ8VJyd8WaRi5+/vmdTBqa4vtZ2z+zk8Ojkk7bW9P3jDwczY2yp22ez49mHc/NAm1UHH04OZsfH5ok2SD8enRydfzYP9vY3NkBh3fD41gNzIaM1eVWWuc/mvGmiax6wzUbQ9EqSveF7uSFmKdPV2CM7vfW84ZA9M543nD2yWV17MNRZXZd1EJTihteebBbKbTxD92UTlree1EZqhmVX2Zs9qy8sw95P2Zg6w+vl/eVRA95ayOHSMx3y+ygWIWy+njMs7dDIL3qYORcMRIEXCfh+F1uTfbZzSZNP1Gdv9oIgrcu5J22HR7nFQ5VR1ITzhQgrUXtDX1n/Q/Y8HP5CjZzemnqKDGovrKNvYZpgOxfjy6Emrufx5BLGOKRBZkW1EKj8pbtGm/QmjONi8dOlPXKUaj3YsqzkVzX2gk2Zpk9aD9SgM7RRHDUCRohPcl4gz2mEcgYLNXs1F4u6gIEXLGrkutpnz06/OHFyufTPqdM43hsBR0wB9mrKzss599CRGZqeQVawjO5VieNC9HOuzTWzDF5imTKYDM/+KL9oqRqWsenUqu2zQXNT1oKR04siSJ0P/jd4C/ZriFr+Z+nnSpX6nqzaC+T4Pju5tMzYbHfHZvtFNnkDJdqLs2JTlibNCNT3U5o82e6W8bPI57RcrTF7liNtzWKWmglEu7tqreMTTSOooI5cV0QJL0T98MTwn5Hsdfi/MRuwkqOrnHty380mb5DRoP6BbXCXbTKPeMaelGeOXY0ZzWhU33Jpe7xij5KJFufIANlnz/A/1L4F2EMwlYHW8rs771ULSOA8EvENo1LWlJzeyi12yKbvTR/25jtkz+QbwseMHMo/Ml7VWSHy4pU3QHRvSwF+xP5H/OcZ1kqr7XdjmGKHeeDZhbiTOJsIDIU2p6Ubg/QJQfvDOkbxft5QLvNnnoPMog+SAVgFikjqfPa8kc2rXJZRtkfBv5HL0loo5zxP1SKBD+mOKkvYezb22SAr7qI8S9gNtFZlyUDtRkoo04RN5f6miVf+r4ugKJhSDrXKkqHPxjA6Zac/02BpfdsTClTSeGmouqfefS5NcCKGciaUv5d4mwBs0uihCwRA8nSUJrBoZeWhqZEDXGHVsTS64pNWVd6FbMobXvpsPPwFlO7F+NJnA2Tdl6NDFuWwmB4Qp+DJwOrpNsvzJT1pNrzIYwvQarFakzZsPZBo5dCshmWfStRBUCzyPAh+JmP3vdczfc6secPWFNQ8qpAYn+XRFc+7ViOtjJY0ahW0jN2T1+Px8BeyfAy7kyxhRSmY4PU8KyLY31qyCzsCaQQypd1uzc4sXX7sEmVw09SEyWbPMNvmMdGQZDWPBcFW2AZLoyyHiW+RIVXYVLYYxmXClaYyJY1aekTmPcNymD4+y1rTR2rmeeBrSqzap8BGeD609VO3Q6MgwPo3myf575pGtsnG929Taj9L9WPa32Rb7P179tMQi6apMcAnOz+xH1UNIATdC0AvHCWpkI/2Fk72/VQjI0GQEKKotr+lOtXFXFygWM6pchZso5vuEcMSHiV5VvAQIQ/Pxk9t2qVaskm39GQPaS0sp02b4w20VKRufA2luN/LScl7OWK8O5IjYz+CXONXU1cxgU1fwoStuZFQkqLhRU4YZMpWzj6b+GxTEeAbtQQ2F1rG9sylCUwbzNucAxLb3GSV3gUBL654LABS2YQ40RKznQtwXwWYZGA8NkEA+igUZdhgMM5Ly3oeiVfeYBsshe3HKkuetwktHmhqcA0t0jS7Z1Pd8QhaqMKq5ml27w22m4dmO210XbANwXDruMeqUe2TI3UjUWfzECynISxETdY4CLYfUS1g/6Mka6o8esDdYEB9Wfxh86xBy0qrKaN4rFKoe2CkDNChKbavh2V60FMBewGuIKC2LnMv51EqGQ+Rh3kPhACBSjUNVrwvCMCYGY7IYRL1gg9H8aIR5VzuDSouNhyVFS+wp9E/y6zwoBtFR83/tchqHvJ5JR5sapaLwaIQGahAGfQLgqL85g3Zj0zFA+WKa3jceJN+hwHlQESC98uSoVXOzIicASNISuFCGyNYBI03HEF8+QkunhgtzCkbVGW1yCPBEzYeDC0K3ClN6ijDqDbNItO1puMBwFlR2plN9TFejPPI+Cwkni1u/UxsNKKHFGid4myOFHO9AR4FQZNzXnktVs+zPM8abzJWFMiNDQyqECL0rpyB1oNHAQbB+2canpNshWBfXQ0mmqauzEhhgnBRs7gC+4aDl9XX7nIMCKHu3Teo28b0/5Yi06snqcsqzBJeiEw8LOkIRIyAbICh3r1757PJeDx+EYpCMvbe+myvl4ylFQ2YTv8omEFeKSBj3bYksA4kE+H09zuqAwb+ejzxmfqzVl05DT+9OA3KCfsEOzWivzprYLhPvhc8cn2vVT4X7sd8XtYP9i6OwHhrf/OZTL8Igp91p2iI7/psfL8z8dkWUO8gRLQMZQfgSyIm9GqKRQfNTVTzhF0DxdDlMiMVC0wZ0C7bksiUtfQ17VB4NJYaWhNKilsi2C68cXrrQZ2Wv4BKzvKLNnVTNnqw+We0d8fa+ZaoRVgW+cN6XlWPOOhIATWuYbhlE+AImSUvSimhXBzWZYU5Ra6AwKr2yKdAYq3ByVDDWkQQgAISSrjZh7PfekICn2cmKcMkX1iZHToScHh6ohModMbD2ezg9G8zky+iUx1+nX08PZuFmPQRUr7Iua6u0zNOTs9+g4SLFlHQfzg7Ozs965B2+vvJ7Cw8Pj3/2iVw9uHw+KiHyPO/fpmd/e3o/NStqGn9/cPXg8+Hp5+cp618jDWzKU5KmEkQVYiCoF35DcwnCG7iFfp/6jsAXfJ7wkWU5fLCcr4IAGt4kYRFKUPoEmOG64BtQpfLVT8gvbYeoTSnPIu55RBUUS0a0i50j6cetD7sETHoDqRLm+4K+yZMWttTMc/ueItmxylC842aazt1UItNkZkdf+77BoWK0gwMrnBlrTs6hcur0IgcpFzYiLZLL9fYPydlYeISCn0HRKDdi8beUUSS8prYVgmtbgHsAnwWyW2ZqstZi81LlrYmYvjLqLwNyzoE79t7emKdWNtgnjVNVlz3EGVvdweUHoE7ZXldR/OA6XRECgb/jcc/y1vvfXZT5kl4xdOy5iF4tpDMQVFDhVDqFh2QEoPN0l6LaoCcNy/AM7h8aQuVZLGpoov2G2gQjJCyASMbjOUmvHoQYDf34UEwFDZldzx+dSFbHMWgAbyhtKCQ2LKGkiwrkEb2iPVG1aK58Zze/xzV18Nf2nudwjOpfeLfMo6lEcAmGs0kfzaPFkV8EwLO5Emxtcxc2EoDtgmbjJXWsin57bMKEDGh1QqikvoK8e1GXW7YXAdI2V65lLnKpn3eGUYAe5wzmZPInkzqIXtiPS6b7Tlj6AZSwRhYLRkkDapHyP5pJ4kMJ4kiFuN7zJzEpMYxe2Lje7QqDbBGOWY9OgOfDDGOprLJ4OPkmcn8TfNU5YkRcxxkud3QaKTJtrQeTbQZIQGIK0F2SkGUcIhW6JvAG0fZ6e5I4+nYglZusi9UcJrM7W329YZjVvQW2FQMCUVxbTA7WtSLBhxNUUfzqkQP9FsmblgmGpYVNxzMwATibgxmd2T7sVI6R32yj5EhihzZ6wcQDsoFlOUhTQVFhiRfi7zPLkjSpYgr2b40zqJR2CReEKAD1xT4tKsR5Axc2DwneejBRSiSuiVrITSCBCJEmxJQkiYQM1I63g7gYNF14hpSHDG0QVhKLxfWVgNONHX3cgkOb0FnlD9N4bAgwGwikh9CCtorFm2iROVC7Er1CarTy6D3IahPiMZmhSjDTIDrPOLFYs5rsPtt0IKausguV4GoKqPPb+csgwdJEbQufPrcRxR1twZdS2nBzEQgZZf9yDLdZ29iB5GwenmrDGKfvTEhF58twKv67cPf7Xv9MRl0yYxbpG63AIXWDJp9PYSMJLVYca+TfMH4dVRfP0Fh4+yP4jLPwX2SMm+2R+3SatcRY9sF7LoX8QD2h+n2oqm3r7IigD8D3arP4sHxQfjh+Hh6YN+1mrx0bNQ9n10NzvSKtSMBDff2tFrRewyqCyBEwSWuObgrwwRUbkmzu7pZtBZfTdmEPT2ptl9N2cXVD59+uIR7OCnk5Q5HeRklnjp1EAQfYrT6MI6u0rgsyTPW52TntaPPNDkyfU/NmrJmDN9wUswlL8yVwxpe10W5MvGglWawtskJJFLzBuGUc/faZ5v4ZCTKsOBtmw0H/tY2UH9HtwtssWZR8foua8paWzVwdsdcYZBBXilrVFdX1igir4Qf+DT/Tv2+tBMPdSHYuA7IQEE+CP1OWSeGaYiVgTskVX5HQmXvJt2lbbeiWwnzk5p0DewPQqLsse0OW3up/cHwXLeJCTZhvPDvq72DtZWjvqruI2SLOBi3HBYYI5ub7FWrZdiwXFTbRIsfKPq+z/YgAL8oVGQCuU8T6wBcjnHuYb9kM7j9WXCOI3RHMD1rCR64crwROlnD2OLqRi+DZIjY2Oh3oLJjbkQYM9PJffs+IyC+iYqCwzEIayhLTAGQNYDHcSswYRyN5Y/goWYsegggv2zajpu+scsQXAJGfP8KVhQ6K0WyVT+Ti0YubPzHTerYX4Y3GPAG8TILvllh7oxGLahCdWBwG02amiyfbaJXbw3dw9xhJW4oGjwZsqniCUV/TFOyjBsR3Zq0t23lMQAuYUx7ZzXp3to49EIwUd7ywt4EzeKibXA1PZu6DcqCmUB/sk3c/I5/uLQyi8iVVQQ5y1LpNZcbhHD/MrISNtzhuVoB+YxLOMwK6QmEmI83dZJ8rX51NdzOsBp9W68aZn9MHR+91zvRbCQd4HCxXw20lYIcist/Tap9u00nQs6SLeVC2ANshflAZkdKomAwkFniFnnRj+uMBhvFZcem/cix28P3LS31ee7OaBwVMc+lGHRXmpKTZSusLZnUXJcbrbUGO1KXCSvXW9+666fuxfV2huutih7AwtRObVTPncWmPo5NGpdzOGYX8nvg+TVX0RtfHjgwx2TRYD0D1nZN2F5h1tkNT2GfhVgtrvKsuZGJh5L2KBW8lkzPMQ7sBsZ7xQsCHv8NaeqRoaqsRVeIlNZ4SYheEqQlwgSd9kiTLVEqU5hMoG6rJn2WBKufYhQsSo39ZUmH8BkDkWt5MlPLk4Fc25VKzplDcJn7h/GfzefSuaUcze7cogJcNaH2x7LLqV09i9Q8e5TxMJMcJ8tZhnD7029Cw2dMCczLd02geDS2sbT2Z2/NeaHgFQwNAAgEqbSLJtPIV3OGgiRWU266se0XrslkE0L8I7wLYeBWLnyPQopqkUW5RRpL62jOB8Mlu3W3M/eOe6V2WIz+gJR1UmroL23cbQusY0yoXVymiCGPICHfZwMd5rmJGlaUKj82J0465jsogPKq4fUdX25PShF+ejK3zFxYwuSoiEaUNffUWTN70zjjOY8a7p5lAGKQM9Ich4WJHBuJ6NaF5OBj0WzXAvyr8jQDtjBfJ9mSu8sA4jRtnst1uWoQ+ijd8lFQY25Sko/XVmBx6RhtvPG7BiY3yr4haoBq9ZyR+JheZbeAvPhsgEsB8kUWNWdzgOprlpeNQOBfBQVoCBTg1sJF3TsqHrIN6CFZnHpjXDRS6FRxytem/YuKaT06fa9ZtDYGpYwL0MlgTrxoe2s0Y/qeTXb2fFIek53X3+8Eymm3z6D01Sb3X9V1zx+tPuYD79p44ZgP/D299cYqVxaEJ4ySshLqzE4/EvDH0iGViwrnrk3WfU+W5LLkfAz1Zk7Cs0rQhz3OSc2HpBxHj8iDLW3gCIn5EfNR7PsmwmOgB7W2JIOsRFiVh4+ptt1Mflu3aLQM6Pm5Sw/Z/OuirXpZ0htXYGUCkUyRiCuw5kVnKzUYMnKgS2EfWUvzOZ3u6MBDb1bnH8zsNMKqDi/oOfk+xEtCRxCCay91CPQBrIeBbIPRGbhNHfrtXxWtNFBrI72K4ttFtT5uNn8A+BecF54nFFJfikY5gJIEHQCykF+XYxZYgcwFrCC/vlCBdJHEUvDr6gq0Vu2TcEb34TMXsiH7hvjlOxNij8gmVtORFbasUOicFKjCFhVQ68qihTUS36WBLwUF/5G3NH5r8VkhuIaTG33QrWFWC67RwqW+9QNBliKDCLiD9i6FltxIN/GWxiiHp5lqCUBrai3NrU1HWzDhoFHLZpSYnlRLliDu94fbyJYx4ucWs4VAFbbvLc+0h5SDKbvQ8uFyXo1Gzq3dJBbkKcU3w7LGrUW+3ywIdCt2ShAGyjBZ343ypEnT9hW3t9kH9s9FIyhlwEmciCMIPwPIDlAai1hcVg+sTOk1dHRSDPNq65HbHiWk8MRMEqU0zBeNYAW/4zVDbQ9BbRaxKzj0A+aPbBNUsZOZQWO5GF+yTXkgmk70dtFVCaY7aWq9LO+gaMYLlFYgmYHgIeNdCcXDfTpYp/zDFB2WpVl0bgd6nslK7u7lqsCAADTHSaJ0aIU8lfMq54Q7Ld1LLTO191iEHSTTTB6C/9S+jaG3ly2SNMpzUJhbUvyI93CaQ41Cns9Rnemvk8uWn769DZlUDUdpa8oc3m/FYxYtxE1ZZ+KBEbQL21iagdt4bUqiLFtFk4xbEvXHnSf1Ie1FykS6fUplycs2dG2iS3WoTcnl0qA8By0PWwmPhDkIpT5tP442q75IgDKJpi2juqdozePyjkMqfjsspTKurcgULgaZTOzkMq8VN1CZx5Ick3082Xmt85VbfGsBUsZH6d202KYezvJ1YvIWXlwfGEXe+C7sHApYGh1TOPr0O4WGvQFGhkUdxbeU02bXhaQvt3UbPLVKrgDmu6CahOtauxtiLD3Y0QT40oqiLQfr9KFQZ7m86BIniyrPYjibQPX60fVljqtODHfZcDU47hxAazX1H/qw34u89fLz01r8dPTNd/CzJpW2kqEvRF5kwEUh6OuFXkYZppW9wP/1p/LTyqn8/5nO/gnsv9u98zKyq4wKsxXYi7KD7z73uKNLTot8Icx49q/h5QYkELKDCNEqdEaS8vpLzXG79fUd9Er11ewe3rQHf2dFyeElZ2c8yic7b312romlKuCZ1r/S7qzy67EzpBFTxq947pmzVD+ApGUxa0RtzSgpNnQ+3WmGlPUgaBMOvDWwY1VzsGgbPvBX1MXcV6cewN0Dv1UMRu0WA1Okt2XDIKwA5bY4XutWJd/wObxob2uy87a3LZevWN4yERxKbZZDOXSotshCstp2QAtoIGyyq1yd9u05ddxOs6e4r88Ez/P/sqNNYXDXswRV1sbH+kALwCIA0XUOy4471tL35w+rj1RCMOy2GjI5nc5wkEMtDE9mkJvpGHo9XrFV00rhWOnkQrTLtjw6kfoeawDqWFF6asIK0kvJQAMIznYbxBwDj/hGGisDEuNEMhc8argHrynXONhVVkT1g768zQAGA50AJwKwm4BtwgiXnyWDWQHjtSwFnUqHRkakSRQT4RQ7vbYiTLLa22xngsuDowDHybMh1kNcMuEqybVK0LGr9pEA3YwzX7raUmgiS5El0CwwxdEirYNFkYAKxM8RnGwI0yznIbxOwBvc8TpLM0CErxpeiC2JwdgWI0kGMKp5mOdZcRvO5bvMvU1ofDiCPAg4xp+E4oYX3hN/Yry1gVowL74puxN1dJJqFwLsZ7Vy7VcPNfA2AWvxSFyU2Ibk+Gzz4nL4y0YvEOwUJ5ZA+cHWVprdiwVovi5rlfZ9ZAPQuybcPQCQY8CedXdysshq7U0mmrbabm9JFlQppyKEsWtwLER1tQrhVC6NrKcvX6r4h5BOhyqrM+h72NLMFuKNy8xnm4T7bRLDNKbnDrw1gB5IcJ3yuJYXUb1SL6K/FqKl7IzEVoWmdFTPpXNsIUeqCfclJ1jUoESYqgkalO6bY0s2dEPNt7EhCxRwRkItySeqsLx0Fa+OjNfZNeBQYW++pSultq1ghXMRWsa3f+nIaHvByV3QkZMeB6uVEi43sJWctcuGKgzbobxj8j32J+yZRQ0JV90XEOAGpifQ6nNzkzY3C+xTbLfepgW2JWJRfViffUzOzCi2iredpFJMG3AmtGWmUAl60VfbLunMOWpk6mS/ZUUjH11LaglLn1oPlOmp+CAlxNX4VKVrr+Ii7a+CvlDXfVtHxD71JuIoaXm1chO1P6glcIN6eem3PyRIqrYRJkhdoKwq+UTrAyMCdKqv4VtlsVyO+obWWQjomCz3gV0J6QGa8ijGF+7IjIyuKLY/LSnY/w+zjey4P+IaSG0fiN+vik355Uu2jcwzdcTMUcPqWIYBZ1dYDvDXBM7dUq1F8Mgmu7rwo52ZQSOgFUL4r7SQcq6jAWaXlfGAFplgphukALJG2tktaEWgdEqUVr3tAYyHXt3wPXqhfVM5yp4Bil1MmE0sW7GzTKEmBF18KwPIl7/G0qlnudGyEiXeQEZ+u2xXM8kqreNIfXVbrrWsaA4hmTrOxNqyKflv3ZFTYd3RszJdMl+2+hzkWcrjhzjnDF6JVTb0RvOyloW7b057UU5bW6RaQ8sks6yrm6joC1fRExMQo1ymZSbFitdqKhLMi0zlazWtFT2nV4aB3moldNlZbLQnApbobplrkUG6s0OEakpu9i+Q4u5MjgXWsryck+D0aOkcwFPJ+cnuWyAKnc8451EBb+3rfVeYY0dI79tV/CayB548BO/KhYjLOZ8+okg+SymbPtK/Jt+opZ6eVfvTCDpgVdQ008mAAICW727eaZUWDB3Zh1C6cfAqStTZUd4sedEYHJpOEzgvvTsaTV93ZrbnYDYkZGHC0+bm+qdJteP7ruvzmtcLNCKqxaLSLm/Cm7jOKoFq3JYM+a6Q2Ow6PS/iky9zBCB0u6Xd8aw4+P7mjYd4aPxC0+YN/polwcBng9fjCbP+Gwx95g0+yYfwGgrm/hlYI/QGn+jnSKDsu3fvVAHmDQ6iapam+GDc+rgtHETVl3q+rCAVOCpu1mvpw/xqRUsn5Qn/9qXO7ojgiap+2UJTolgs8E2y1hzoFxmmWZGEeKTcvM3QfUumfIejLQTrZ3oS9MiMaLM0A0TXicpIhxPJHDVVnonw200meFNFMUVm8GR7EPxMB+Pfe0P5ykY2QFlVUgEmp+mpszu4q14uO/YIA3xmelXrt0Y8d1dsvShWJWjS23P06X1EX+GnWQJ4EJbA79Yp/SzFSvQGPxjKLvnY15AqgG+VNDCPNa2rNIf72kpsaoeaIuin/x0fyuk3pRGvtxNAiF3zMnGzC+348tue93y449uB8ZnX1ukf0FHnNMzP5uCdZ0ytRMVOIBBCo/CuBsHnrInLys2fXxSY3iQZCAfZ6RVELwmsjkhBi4wXcZlkxXXrbbLQJSTBZkKuEHq/qzcYSUK+sxtoye0C8Szop/Wi2kpcb+FPW25BjvfWGj19q+FX76gfasX0JHHzxMzK5C3uD8lInvkfQWzhKX5iMYQzoybOsvCG3yfZdQZHb+HkAVS7+mHrB3zFFnZzdMiam6g1IThdU/WzkPKlHa0X78IVjhleLzaQaxuY4xypQEw8joqyyOIoz/4NOzkQAffdM+fyPadRnkWui6BAYLkDdbFhaMvlknoGfAC0fQiM0jdd2dW3r/tvw9KBBti4HO/skCVpm7vERrRuABbRpK8X0OkhvmebNZEFFVWCDQFkY+W7bYs6hO2dF0kECU/OVqUpV5g3HHMhe5G6cCeBIGxHPcaLGn9ZkN8b84xGoAp3JUjM4YXNOBIQHrUj4C9IwP7ovIQAbsqOW/6wBu6XiQTVcqky1UAsIDRBcmHddyXDetAnBEAsasReQvuTnM17a+j33uTvnYLFZwdqpGkadgJLKvI1WBJVsis6WlAGzKZuZLW3PBhu6BOAsdbvcfs9Dnf7HgXl2360uqMC9F2Qps8F9LvOiW0vYVAPV5LP5NSTHe8zNULXtjWpaQ4HfB3Cbd1uJaC7cqX8lGWuUFYkvOIF7PVbevosx0jNTds1MkYPbh/mt5W3UOCm4LHAG2i1j4JHU+At7lEmDR5X8czuM3FQJsrFlT8Mg8bRst+F6W9A/V4GOQbwurafLM2y4pdicCD0czGdn4lZ2RX+aIycwOeN/wMcr/5+inoAAA==' | /usr/bin/base64 -d | /usr/bin/gzip -dc > "$build/proof.rs"
source_hash=$(/usr/bin/sha256sum "$build/proof.rs")
printf 'source_sha256 %s\n' "$source_hash"
[ "${source_hash%% *}" = 'c1ea1c8224805e87a772e143f6235860488cd4874a73d1bbadcfea1c3b7a97a5' ]
rustc=/home/petershiller1.guest/.rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu/bin/rustc
"$rustc" --version --verbose
TMPDIR="$build" "$rustc" --edition=2024 -D warnings -C panic=abort -C opt-level=1 -C strip=symbols -C linker=/usr/bin/gcc "$build/proof.rs" -o "$build/proof"
artifact=$(/usr/bin/sha256sum "$build/proof")
printf 'user_build_sha256 %s\n' "$artifact"
/usr/bin/sudo -n -- /usr/bin/systemd-run --system --scope --quiet --unit ptg-linux-rust-20261106-e52a60a2.scope --slice=system.slice -p Delegate=no -p RuntimeMaxSec=30s -p KillMode=control-group -p KillSignal=SIGKILL -p SendSIGKILL=yes -- /bin/sh -c 'set -eu
umask 077
unit=ptg-linux-rust-20261106-e52a60a2.scope
scope=/system.slice/ptg-linux-rust-20261106-e52a60a2.scope
root=/sys/fs/cgroup$scope
scratch=/tmp/ptg-linux-rust-20261106-e52a60a2
expected_hash=$1
case "$expected_hash" in *[!0-9a-f]*) exit 90;; esac
[ "${#expected_hash}" -eq 64 ]
[ "$(/usr/bin/id -u)" = 0 ]
[ "$(/usr/bin/id -g)" = 0 ]
[ "$(/usr/bin/cat /proc/$$/cgroup)" = "0::$scope" ]
[ "$(/usr/bin/realpath -e -- "$root")" = "$root" ]
[ "$(/usr/bin/stat -c '"'"'%u:%g'"'"' -- "$root")" = 0:0 ]
[ "$(/usr/bin/stat -f -c %T -- "$root")" = cgroup2fs ]
/usr/bin/grep -Fxq '"'"'nr_descendants 0'"'"' "$root/cgroup.stat"
properties=$(/usr/bin/systemctl --system show "$unit" --property=Delegate,ControlGroup,RuntimeMaxUSec,KillMode,KillSignal,SendSIGKILL,ActiveState)
printf '"'"'%s\n'"'"' "$properties"
for exact in Delegate=no "ControlGroup=$scope" RuntimeMaxUSec=30s KillMode=control-group KillSignal=9 SendSIGKILL=yes ActiveState=active; do
    printf '"'"'%s\n'"'"' "$properties" | /usr/bin/grep -Fxq -- "$exact"
done
/usr/bin/uname -srvmo
/usr/bin/mkdir -m 700 -- "$scratch"
cleanup() {
    result=$?
    trap - EXIT
    for leaf in owner-before supervisor-held real-127 exec-enoent watchdog-exec watchdog-held watchdog-pre-close sibling; do
        target="$root/$leaf"
        if [ -d "$target" ]; then
            if /usr/bin/grep -Fxq '"'"'populated 1'"'"' "$target/cgroup.events"; then
                printf '"'"'1'"'"' > "$target/cgroup.kill" || result=91
                attempt=0
                while /usr/bin/grep -Fxq '"'"'populated 1'"'"' "$target/cgroup.events" && [ "$attempt" -lt 20 ]; do
                    /usr/bin/sleep 0.025
                    attempt=$((attempt+1))
                done
            fi
            if /usr/bin/rmdir -- "$target"; then printf '"'"'removed cgroup=%s\n'"'"' "$target"; else result=91; fi
        fi
    done
    if /usr/bin/rm -f -- "$scratch/proof" && /usr/bin/rmdir -- "$scratch" && [ ! -e "$scratch" ]; then
        printf '"'"'root_scratch_removed=%s\n'"'"' "$scratch"
    else
        result=92
    fi
    /usr/bin/cat "$root/cgroup.stat"
    exit "$result"
}
trap cleanup EXIT
/usr/bin/cat > "$scratch/proof"
root_hash=$(/usr/bin/sha256sum "$scratch/proof")
printf '"'"'root_copy_sha256 %s\n'"'"' "$root_hash"
[ "${root_hash%% *}" = "$expected_hash" ]
/usr/bin/chmod 0755 -- "$scratch" "$scratch/proof"
"$scratch/proof" "$unit"
' ptg-rust-root "${artifact%% *}" < "$build/proof"
