"""Independently verify the accepted path of a sealed quiet-launch receipt."""

from collections.abc import Mapping
from dataclasses import fields
import json
import math
import re

from quiet_gate import Cpu, INTERVALS, Job, NS_PER_SECOND, Sample, SECONDS, verdict, window

PERIOD = SECONDS * NS_PER_SECOND
TRANSITION = 50_000_000
UTC_TOLERANCE = NS_PER_SECOND


class InvalidReceipt(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise InvalidReceipt(reason)


def same(actual, expected, reason):
    # Python's equality treats booleans as integers. Compare JSON types too.
    require(json.dumps(actual, sort_keys=True, allow_nan=False)
            == json.dumps(expected, sort_keys=True, allow_nan=False), reason)


def integers(row, schema):
    require(isinstance(row, Mapping) and set(row) == {f.name for f in fields(schema)},
            f"invalid {schema.__name__} fields")
    require(all(type(value) is int and value >= 0 for value in row.values()),
            f"invalid {schema.__name__} counter")
    return schema(**row)


def sample_from_raw(row, during):
    require(isinstance(row, Mapping) and set(row) == {f.name for f in fields(Sample)},
            "invalid Sample fields")
    raw = dict(row)
    for name in ("before", "after"):
        raw[name] = integers(raw[name], Cpu)
        require(raw[name].idle <= raw[name].kernel, "idle exceeds kernel")
    if during:
        raw["job"] = integers(raw["job"], Job)
        require(raw["job"].active_processes <= raw["job"].total_processes,
                "invalid Job census")
    else:
        require(raw["job"] is None, "outside sample carried Job accounting")
    for name in set(raw) - {"job", "before", "after"}:
        require(type(raw[name]) is int and raw[name] >= 0, f"invalid {name}")
    return Sample(**raw)


def replay(rows, *, argv, max_during_seconds, binding):
    """Return accepted replay facts or raise InvalidReceipt. No process access."""
    require(type(max_during_seconds) in (int, float)
            and math.isfinite(max_during_seconds)
            and max_during_seconds >= INTERVALS * SECONDS, "invalid sealed duration")
    source = iter(rows)
    end = object()
    require(isinstance(binding, str) and re.fullmatch(r"[0-9a-f]{64}", binding),
            "invalid sealed manifest digest")
    last_utc = None
    first_clock = None

    def take(kind):
        nonlocal last_utc
        row = next(source, None)
        require(isinstance(row, dict) and row.get("kind") == kind, f"expected {kind}")
        utc = row.get("utc_ns")
        require(type(utc) is int and 946_684_800 * NS_PER_SECOND <= utc < 4_102_444_800 * NS_PER_SECOND
                and (last_utc is None or utc >= last_utc), f"invalid or discontinuous {kind} UTC")
        last_utc = utc
        return {key: value for key, value in row.items() if key not in ("kind", "utc_ns")}

    def clock(monotonic):
        nonlocal first_clock
        require(type(monotonic) is int and monotonic >= 0, "invalid monotonic clock")
        if first_clock is None:
            first_clock = (monotonic, last_utc)
        first_monotonic, first_utc = first_clock
        require(abs((last_utc - first_utc) - (monotonic - first_monotonic))
                <= UTC_TOLERANCE, "UTC/monotonic discontinuity")

    def sample(phase):
        row = take("sample")
        require(set(row) == {"phase", "endpoint", "raw"} and row["phase"] == phase
                and type(row["endpoint"]) is bool, f"invalid {phase} sample")
        require(phase == "during" or not row["endpoint"], "outside endpoint")
        result = sample_from_raw(row["raw"], phase == "during")
        clock(result.monotonic_ns)
        return result, row["endpoint"]

    def transition(previous, current):
        require(0 <= current.monotonic_ns - previous.monotonic_ns <= TRANSITION,
                "phase transition gap")

    def outside(phase, after=None):
        first, _ = sample(phase)
        if after is not None:
            transition(after, first)
        previous = first
        scores = []
        for index in range(1, INTERVALS + 1):
            current, _ = sample(phase)
            require(current.monotonic_ns >= first.monotonic_ns + index * PERIOD,
                    f"{phase} sampled before absolute boundary")
            score = window(previous, current)
            same(take("window"), {"phase": phase, **score}, f"{phase} arithmetic")
            scores.append(score)
            previous = current
        result = verdict(scores)
        same(take("phase_decision"), {"phase": phase, **result}, f"{phase} verdict")
        require(result["candidate_pass"], f"{phase} rejected")
        return previous

    same(take("started"), {"argv": list(argv), "max_during_seconds": max_during_seconds,
                           "binding": binding},
         "manifest mismatch")
    pre = outside("pre")
    first, endpoint = sample("during")
    require(not endpoint and first.job == Job(0, 0, 0, 0), "invalid Job baseline")
    transition(pre, first)
    launched = take("launched")
    require(set(launched) == {"pid", "dispatch_ns", "monotonic_ns"}
            and type(launched["pid"]) is int
            and launched["pid"] > 0, "invalid launch receipt")
    dispatch = launched["dispatch_ns"]
    launch_time = launched["monotonic_ns"]
    require(type(dispatch) is int and 0 <= dispatch - first.monotonic_ns <= TRANSITION,
            "baseline/dispatch transition gap")
    clock(launch_time)
    require(dispatch <= launch_time < first.monotonic_ns + PERIOD,
            "CreateProcess return outside first sampling window")
    deadline = first.monotonic_ns + int(max_during_seconds * NS_PER_SECOND)
    target = first.monotonic_ns + PERIOD
    scores = []
    previous = first
    last_start = None
    while True:
        current, endpoint = sample("during")
        elapsed = current.monotonic_ns - previous.monotonic_ns
        require(elapsed > 0 and launch_time <= current.monotonic_ns
                and current.monotonic_ns + current.read_ns < deadline, "during sample time")
        if not endpoint:
            require(current.monotonic_ns >= target, "during sample before boundary")
        partial = endpoint and NS_PER_SECOND <= elapsed < 4_500_000_000
        merge = endpoint and elapsed < NS_PER_SECOND and last_start is not None
        score = window(last_start if merge else previous, current, during=True)
        if partial and "sample_gap" in score["errors"]:
            score["errors"].remove("sample_gap")
        if merge:
            tail = window(previous, current, during=True)
            score["errors"].extend(
                f"short_tail:{reason}" for reason in tail["errors"]
                if reason not in ("sample_gap", "system_counter_capacity")
            )
        same(take("window"), {"phase": "during", "final_partial": partial,
                              "replaces_window": len(scores) if merge else None, **score},
             "during arithmetic or replacement index")
        value = score["residual_cpu_upper_pct"]
        preceding = scores[:-1] if merge else scores
        require(not score["errors"] and value is not None and value <= 25
                and (not preceding or min(value, preceding[-1]["residual_cpu_upper_pct"]) <= 15),
                "during immediate rejection")
        if merge:
            scores[-1] = score
        else:
            scores.append(score)
        last_start, previous = previous, current
        if endpoint:
            require(current.job.active_processes == 0 and current.job.total_processes > 0,
                    "invalid endpoint Job census")
            break
        target += PERIOD
    drain = take("drain")
    drained = drain.pop("monotonic_ns", None)
    clock(drained)
    require(previous.monotonic_ns + previous.read_ns <= drained < deadline,
            "natural drain time")
    same(drain, {"active_before": 0, "terminated": False, "active_after": 0},
         "Job did not drain naturally")
    result = verdict(scores, during=True)
    require(len(scores) - int(partial) >= INTERVALS and result["candidate_pass"],
            "during coverage or verdict")
    same(take("phase_decision"), {"phase": "during", "code": 0, **result},
         "during verdict or exit code")
    post = outside("post", previous)
    same(take("terminal"), {"accepted": True, "problems": []}, "terminal rejected")
    clock(post.monotonic_ns)
    require(next(source, end) is end, "rows after terminal")
    return {"pid": launched["pid"], "during_windows": len(scores),
            "endpoint_monotonic_ns": previous.monotonic_ns}
