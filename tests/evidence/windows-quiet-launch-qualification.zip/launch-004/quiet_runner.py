"""Draft capture watcher. A sealed manifest loader must supply the launch input."""

import json
import math
import subprocess
from dataclasses import asdict

from quiet_gate import (
    DURING_MAX_CPU, DURING_PAIRED_CPU, INTERVALS, MAX_READ_NS, NS_PER_SECOND, SECONDS,
    Job, verdict, window,
)

PERIOD = SECONDS * NS_PER_SECOND
MIN_PARTIAL = NS_PER_SECOND
MAX_TRANSITION = 50_000_000
EMPTY = {"active_before": 0, "terminated": False, "active_after": 0}


class Rejected(RuntimeError):
    pass


def capture(argv, output, *, max_during_seconds, make_job, stamp, now_ns,
            sleep, stdin, stdout, stderr, on_sample=None, utc_ns=None, binding=None):
    """Write one exclusive JSONL receipt and return whether all gates passed.

    Production adapters are SlotJob, quiet_sampler.stamp, perf_counter_ns
    and time.sleep. The caller supplies already-open dedicated output handles.
    """
    if (not isinstance(argv, tuple) or not argv
            or any(not isinstance(arg, str) or "\0" in arg for arg in argv)
            or not argv[0]):
        raise ValueError("a sealed nonempty argument tuple is required")
    if not math.isfinite(max_during_seconds) or max_during_seconds < INTERVALS * SECONDS:
        raise ValueError("finite during limit must allow at least twelve windows")
    with output.open("x", encoding="utf-8") as stream:
        def emit(kind, **fields):
            if utc_ns is not None:
                fields["utc_ns"] = utc_ns()
            print(json.dumps({"kind": kind, **fields}, allow_nan=False),
                  file=stream, flush=True)

        def read(phase, job=None, *, endpoint=False):
            sample = stamp(job)
            emit("sample", phase=phase, endpoint=endpoint, raw=asdict(sample))
            if on_sample is not None:
                on_sample(phase, sample, job)
            return sample

        def sleep_until(target):
            remaining = target - now_ns()
            if remaining > 0:
                sleep(remaining / NS_PER_SECOND)

        def outside(phase, after=None):
            first = previous = read(phase)
            if after is not None and not 0 <= first.monotonic_ns - after.monotonic_ns <= MAX_TRANSITION:
                raise Rejected("during/post transition gap")
            rows = []
            for index in range(1, INTERVALS + 1):
                sleep_until(first.monotonic_ns + index * PERIOD)
                current = read(phase)
                row = window(previous, current)
                rows.append(row)
                emit("window", phase=phase, **row)
                previous = current
            result = verdict(rows)
            emit("phase_decision", phase=phase, **result)
            if not result["candidate_pass"]:
                raise Rejected(f"{phase} rejected")
            return previous

        job = child = None
        problems = []
        phase = "pre"
        emit("started", argv=argv, max_during_seconds=max_during_seconds, binding=binding)
        try:
            pre_end = outside("pre")
            phase = "during"
            job = make_job()
            first = previous = read("during", job)
            if first.job != Job(0, 0, 0, 0):
                raise Rejected("enclosing Job did not start empty")
            if not 0 <= first.monotonic_ns - pre_end.monotonic_ns <= MAX_TRANSITION:
                raise Rejected("pre/during transition gap")
            deadline = first.monotonic_ns + int(max_during_seconds * NS_PER_SECOND)
            if not 0 <= first.read_ns <= MAX_READ_NS:
                raise Rejected("during baseline counter read span")
            dispatch = now_ns()
            if not 0 <= dispatch - first.monotonic_ns <= MAX_TRANSITION:
                raise Rejected("baseline/dispatch transition gap")
            child = job.launch(argv, 0, stdin=stdin, stdout=stdout, stderr=stderr)
            launched = now_ns()
            emit("launched", pid=child.pid, dispatch_ns=dispatch, monotonic_ns=launched)
            if not dispatch <= launched < first.monotonic_ns + PERIOD:
                raise Rejected("CreateProcess returned outside the first sampling window")
            rows = []
            last_start = None
            target = first.monotonic_ns + PERIOD
            while True:
                now = now_ns()
                if now >= deadline:
                    raise Rejected("during deadline reached")
                wait_until = min(target, deadline)
                try:
                    code = child.wait(max(0, wait_until - now) / NS_PER_SECOND)
                except subprocess.TimeoutExpired:
                    code = None
                endpoint = code is not None
                if endpoint:
                    exited_child, child = child, None
                    exited_child.close()
                else:
                    # Windows waits round to milliseconds. Align an early
                    # timeout with the same absolute sampling boundary.
                    sleep_until(wait_until)
                if now_ns() >= deadline:
                    raise Rejected("during deadline reached")
                current = read("during", job, endpoint=endpoint)
                if current.monotonic_ns >= deadline or now_ns() >= deadline:
                    raise Rejected("during deadline reached while sampling")
                elapsed = current.monotonic_ns - previous.monotonic_ns
                if elapsed <= 0:
                    raise Rejected("non-increasing during sample clock")
                partial = endpoint and MIN_PARTIAL <= elapsed < 4.5 * NS_PER_SECOND
                merge = endpoint and elapsed < MIN_PARTIAL and last_start is not None
                row = window(last_start if merge else previous, current, during=True)
                if partial and "sample_gap" in row["errors"]:
                    row["errors"].remove("sample_gap")
                if merge:
                    # Check adjacent counters independently so a reset at the
                    # endpoint cannot disappear inside the longer interval.
                    tail = window(previous, current, during=True)
                    row["errors"].extend(
                        f"short_tail:{reason}" for reason in tail["errors"]
                        if reason not in ("sample_gap", "system_counter_capacity")
                    )
                emit("window", phase="during", final_partial=partial,
                     replaces_window=len(rows) if merge else None, **row)
                value = row["residual_cpu_upper_pct"]
                preceding = rows[:-1] if merge else rows
                if (row["errors"] or value is None or value > DURING_MAX_CPU
                        or (preceding and min(value, preceding[-1]["residual_cpu_upper_pct"])
                            > DURING_PAIRED_CPU)):
                    raise Rejected("during window rejected")
                if merge:
                    rows[-1] = row
                else:
                    rows.append(row)
                last_start, previous = previous, current
                if endpoint:
                    if current.job.active_processes != 0:
                        raise Rejected("campaign exit left live Job members")
                    drain = job.drain()
                    emit("drain", monotonic_ns=now_ns(), **drain)
                    if now_ns() >= deadline:
                        raise Rejected("during deadline reached while draining")
                    if drain != EMPTY:
                        raise Rejected("campaign Job did not drain naturally")
                    break
                target += PERIOD
            # A partial window is scored for contamination, but cannot buy
            # minimum full-window coverage or a successful campaign exit.
            result = verdict(rows, during=True)
            if len(rows) - int(partial) < INTERVALS:
                result["candidate_pass"] = False
                result["reasons"].append("full_window_coverage")
            emit("phase_decision", phase="during", code=code, **result)
            if code or not result["candidate_pass"]:
                raise Rejected("during phase rejected")
            phase = "post"
            outside("post", previous)
        except BaseException as error:
            problems.append(f"{phase}: {type(error).__name__}: {error}")
            if not isinstance(error, Exception):
                raise
        finally:
            if child is not None:
                try:
                    child.close()
                except Exception as error:
                    problems.append(f"child close: {error}")
            if job is not None:
                try:
                    if problems:
                        emit("abort_drain", **job.drain())
                except Exception as error:
                    problems.append(f"abort drain: {error}")
                finally:
                    try:
                        job.close()
                    except Exception as error:
                        problems.append(f"Job close: {error}")
            emit("terminal", accepted=not problems, problems=problems)
        return not problems
