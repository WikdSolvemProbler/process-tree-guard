"""Replay a real earlier package without allowing any child process."""

import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
CHECKOUT = HERE.with_name("issue7-quiet-campaign-inputs-001") / "checkout"
OLD = HERE.with_name("issue7-captures") / "run-20261106T050618Z-s20261029"
REPO = HERE.parents[2]
sys.path[:0] = [str(HERE), str(CHECKOUT / "tests/campaign")]

import harness
from audit_package import audit_complete
from quiet_launch import validate_manifest


def forbid(*args, **kwargs):
    raise AssertionError("offline audit attempted a subprocess")


def must_refuse(call, reason):
    try:
        call()
    except ValueError as error:
        if reason not in str(error):
            raise
        return
    raise AssertionError(f"expected audit refusal containing {reason!r}")


with patch.object(subprocess, "Popen", forbid), patch.object(subprocess, "run", forbid):
    old = json.loads((OLD / "run.json").read_bytes())
    expected = {
        "run_id": OLD.name,
        "config": REPO / "tests/campaign.json",
        "config_sha": "d94850b7bff763719a384f686e1469a47ec12daf00ae5140ff30e0e695c043b4",
        "seed": 20261029,
        "fingerprints": {arm: dict(row, path=Path(row["path"]))
                         for arm, row in old["fingerprints"].items()},
    }
    result = audit_complete(harness, OLD, **expected)
    assert result["slots"] == 1940 and result["standing_loss_count"] == 44
    assert result["campaign_status"] == "incomplete"
    must_refuse(lambda: audit_complete(harness, OLD, **dict(expected, seed=1)), "seed")
    must_refuse(lambda: audit_complete(harness, OLD, **dict(expected, run_id="forged")), "namespace")
    must_refuse(lambda: audit_complete(
        harness, OLD, **dict(expected, config_sha="0" * 64)), "sealed identity")
    changed = dict(expected["fingerprints"])
    changed["guard"] = dict(changed["guard"], sha256="0" * 64)
    must_refuse(lambda: audit_complete(
        harness, OLD, **dict(expected, fingerprints=changed)), "executable identity")
    must_refuse(lambda: validate_manifest(HERE / "manifest.json", "0" * 64),
                "explicitly approved digest")
    print(json.dumps({"historical_complete_slots": result["slots"],
                      "historical_campaign_status": result["campaign_status"],
                      "standing_losses_preserved": result["standing_loss_count"],
                      "bound_files": len(result["file_sha256"]),
                      "refusal_controls": 5, "live_benchmark_slots": 0}, indent=2))