# Linux generic request transport qualification

This standalone fixture exercises the PTGEX2 request packet over an anonymous nonblocking Unix SOCK_SEQPACKET pair in one ordinary-user process. Both sockets and the originating pidfd are close-on-exec. The receiver enables SO_PASSCRED before the send. It compares the kernel SCM_CREDENTIALS record to the SO_PEERCRED socket identity, adopts one transferred descriptor with MSG_CMSG_CLOEXEC, verifies its process identity in procfs, and polls it without waiting. Only then does it call the existing bounded argument decoder.

The receive buffer uses the decoder's 131,072-byte packet cap. The aligned 64-byte control buffer fits the credential record and more than one rights descriptor. The receiver adopts every delivered SCM_RIGHTS descriptor before checking message flags or admitting the packet. OwnedFd closes the received descriptors on all refusals. Linux constructs the received rights records and can install a partial set while reporting MSG_CTRUNC. [Linux SCM_RIGHTS delivery](https://github.com/torvalds/linux/blob/v6.8/net/core/scm.c#L290-L335)

The live positive case checks the real PID, UID and GID, a distinct received close-on-exec pidfd, native argument bytes, an empty argument and the decoded deadline. A second positive case reaches the packet cap exactly. The seven negative cases cover payload truncation at cap plus one, absent rights, duplicate rights, ancillary truncation with twelve rights, a socket substituted for a pidfd, a well-transported frame with trailing bytes and peer EOF. Each checks its specific refusal and verifies that the process descriptor count returns to baseline. The source uses nonblocking sockets, a zero-timeout poll and no subprocesses.

For the native test, preserve these repository-relative paths in an isolated directory and run in the approved finite ordinary-user scope:

```text
rustc --edition=2021 --test -D warnings -C linker=/usr/bin/gcc target/codex-security/issue2-linux-request-transport-001/transport.rs -o transport-tests
./transport-tests --test-threads=1 --nocapture
```

| Input | SHA-256 |
| --- | --- |
| target/codex-security/issue2-linux-request-transport-001/transport.rs | 2b8ce5cd6f83d17df3a5b6f7fa80dcf95a0010b6514b7ac56cf0e4c7e111baee |
| target/codex-security/issue2-linux-generic-request-001/request.rs | 6531478a6cb85c31ba4639c01c144c789968178df57b64d3d128073a8d91b4c4 |
| src/deadline.rs | 56252eb28270b4743d73e17e05ae933d3fad8168e7b4ba34405e859be9c85c53 |

The layout matches the archived external admission probe's 64-bit Linux ABI. The archived privileged listener and this one-process fixture cover different scopes. Credential transitions and sender replacement on a public rendezvous, generic payload execution, launch authority, cgroup lifecycle and the Linux 5.14 floor need separate qualification. The local Windows check built metadata for a derivative that replaces Unix descriptor types with placeholders. The compiled native source and actual kernel receipts are the qualification.
