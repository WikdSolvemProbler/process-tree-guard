from copy import deepcopy
import unittest
from validate_image_rows import validate_rows


def rows():
    signature = {"volume": 8, "file_id_128": "11" * 16, "size": 4, "allocation": 4096,
                 "links": 1, "creation_ticks": 1, "write_ticks": 2, "change_ticks": 3,
                 "attributes": 32, "directory": False, "delete_pending": False}
    digest = "a" * 64
    evidence = {"schema": 2, "path": "C:/python.exe", "begin_ns": 110, "end_ns": 190,
                "scope": "two fixed held-file read consistency; not atomic or loaded-byte proof",
                "read_first": {"begin_ns": 120, "end_ns": 130, "sha256": digest},
                "rewind": {"begin_ns": 140, "end_ns": 150, "position": 0},
                "read_second": {"begin_ns": 160, "end_ns": 170, "sha256": digest},
                "sha256": digest}
    for name in ("named_before", "held_before", "held_after", "named_after"):
        evidence[name] = deepcopy(signature)
    return [{"pid": 9, "created_ticks": 10, "snapshot_upper_ticks": 20,
             "state": "pinned_enclosing_guard"},
            {"pid": 11, "created_ticks": 12, "snapshot_upper_ticks": 20,
             "state": "unclassified_background", "alive_after": True,
             "image_path": "C:/python.exe", "image_sha256": digest, "image_file": evidence}]


class ValidationTests(unittest.TestCase):
    def test_complete_evidence_and_exited_exact_process_are_valid(self):
        value = rows()
        self.assertEqual(validate_rows(value, 100, 200, 9, 10), [])
        value[1]["alive_after"] = False
        self.assertEqual(validate_rows(value, 100, 200, 9, 10), [])

    def test_realistic_forged_evidence_is_refused(self):
        for name, mutate in (
            ("second digest", lambda x: x["read_second"].update(sha256="b" * 64)),
            ("high ID bits", lambda x: x["named_after"].update(file_id_128="11" * 8 + "22" * 8)),
            ("volume", lambda x: x["held_after"].update(volume=9)),
            ("rewind", lambda x: x["rewind"].update(position=1)),
            ("backwards", lambda x: x["read_second"].update(begin_ns=125)),
            ("outside census", lambda x: x.update(end_ns=201)),
            ("bool counter", lambda x: x["held_before"].update(size=True)),
            ("oversized ID volume", lambda x: x["held_after"].update(volume=2**64)),
            ("schema float", lambda x: x.update(schema=2.0)),
            ("hidden error", lambda x: x["read_second"].update(error="query failed")),
        ):
            with self.subTest(name=name):
                value = rows()
                mutate(value[1]["image_file"])
                self.assertTrue(validate_rows(value, 100, 200, 9, 10))

    def test_missing_file_digest_binding_and_guard_forgery_are_refused(self):
        for mutate in (
            lambda x: x[1].pop("image_file"),
            lambda x: x[1].update(image_sha256="b" * 64),
            lambda x: x[0].update(created_ticks=11),
            lambda x: x[1].update(created_ticks=21),
            lambda x: x[1].update(state="membership_unverified"),
            lambda x: x[1].update(reason="native query failed"),
        ):
            value = rows()
            mutate(value)
            self.assertTrue(validate_rows(value, 100, 200, 9, 10))


if __name__ == "__main__":
    unittest.main()
