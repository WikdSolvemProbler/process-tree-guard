import unittest
from unittest.mock import patch
from pathlib import Path
import inventory_gate


class ErrorEvidenceTests(unittest.TestCase):
    def test_partial_native_failure_evidence_survives_wrapper(self):
        for error in (ValueError("changed file"), OSError("native query failed")):
            with self.subTest(error=error):
                error.evidence = {"schema": 2, "read_first": {"begin_ns": 1, "end_ns": 2}}
                row = {}
                with patch.object(inventory_gate, "inspect_image", side_effect=error):
                    with self.assertRaises(type(error)):
                        inventory_gate.image_digest(Path("C:/fixture.exe"), row)
                self.assertIs(row["image_file"], error.evidence)

    def test_unavailable_evidence_is_not_invented(self):
        row = {}
        with patch.object(inventory_gate, "inspect_image", side_effect=OSError("open failed")):
            with self.assertRaises(OSError):
                inventory_gate.image_digest(Path("C:/fixture.exe"), row)
        self.assertNotIn("image_file", row)

    def test_successful_evidence_and_digest_are_preserved(self):
        observed = {"schema": 2, "sha256": "a" * 64}
        row = {}
        with patch.object(inventory_gate, "inspect_image", return_value=("a" * 64, observed)):
            self.assertEqual(inventory_gate.image_digest(Path("C:/fixture.exe"), row), "a" * 64)
        self.assertIs(row["image_file"], observed)


if __name__ == "__main__":
    unittest.main()
