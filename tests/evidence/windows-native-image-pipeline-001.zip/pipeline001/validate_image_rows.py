"""Independent structural replay of successful native image observations."""
import re
import ntpath

SIGNATURE_KEYS = {"volume", "file_id_128", "size", "allocation", "links",
                  "creation_ticks", "write_ticks", "change_ticks", "attributes",
                  "directory", "delete_pending"}
SHA = re.compile(r"[0-9a-f]{64}\Z")
FILE_ID = re.compile(r"[0-9a-f]{32}\Z")


def integer(value, low, high):
    return type(value) is int and low <= value <= high


def validate_rows(rows, begin_ns, end_ns, guard_pid, guard_created, image_policy, compiler_names):
    errors = []
    veto = image_policy.get("veto_sha256")
    if not isinstance(veto, list) or any(not isinstance(item, str) or SHA.fullmatch(item) is None for item in veto):
        return ["invalid frozen veto policy"]
    veto = set(veto)
    if not (integer(begin_ns, 0, 2**63-1) and integer(end_ns, begin_ns, 2**63-1)):
        return ["invalid census bounds"]
    if not isinstance(rows, list) or not rows:
        return ["empty or invalid inventory"]
    guard_count = 0
    seen_pids = set()
    previous_end = begin_ns
    for index, row in enumerate(rows):
        prefix = f"row {index}: "
        try:
            if not isinstance(row, dict):
                raise ValueError("not an object")
            if not integer(row.get("pid"), 1, 2**32-1) or row["pid"] in seen_pids:
                raise ValueError("invalid/duplicate process ID")
            seen_pids.add(row["pid"])
            upper, created = row.get("snapshot_upper_ticks"), row.get("created_ticks")
            if not integer(upper, 0, 2**64-1) or not integer(created, 1, upper):
                raise ValueError("invalid process creation/snapshot bound")
            if row.get("state") == "pinned_enclosing_guard":
                guard_count += 1
                if row["pid"] != guard_pid or created != guard_created:
                    raise ValueError("incorrect pinned guard identity")
                if "image_file" in row or "image_sha256" in row:
                    raise ValueError("unexpected guard file observation")
                continue
            if row.get("state") != "unclassified_background":
                raise ValueError("outside-sample row is not allowed background")
            if any(key in row for key in ("error", "reason", "winerror")):
                raise ValueError("allowed row contains inspection failure")
            if type(row.get("alive_after")) is not bool:
                raise ValueError("missing process liveness observation")
            digest = row.get("image_sha256")
            if not isinstance(digest, str) or SHA.fullmatch(digest) is None:
                raise ValueError("invalid row digest")
            if digest in veto or row.get("name") in compiler_names:
                raise ValueError("row classification conflicts with sealed policy")
            if not isinstance(row.get("name"), str) or row["name"] != row["name"].casefold():
                raise ValueError("invalid canonical image basename")
            observed = row.get("image_file")
            if (not isinstance(observed, dict) or type(observed.get("schema")) is not int
                    or observed["schema"] != 2):
                raise ValueError("missing native two-read evidence")
            expected_fields = {"schema", "path", "begin_ns", "end_ns", "scope", "named_before",
                               "held_before", "held_after", "named_after", "read_first",
                               "read_second", "rewind", "sha256"}
            if set(observed) != expected_fields:
                raise ValueError("invalid successful observation fields")
            if observed["scope"] != "two fixed held-file read consistency; not atomic or loaded-byte proof":
                raise ValueError("incorrect observed-consistency scope")
            if observed.get("path") != row.get("image_path") or not isinstance(row.get("image_path"), str):
                raise ValueError("image path differs")
            if ntpath.basename(row["image_path"]).casefold() != row["name"]:
                raise ValueError("retained image path basename differs from snapshot")
            signatures = [observed.get(name) for name in
                          ("named_before", "held_before", "held_after", "named_after")]
            for signature in signatures:
                if not isinstance(signature, dict) or set(signature) != SIGNATURE_KEYS:
                    raise ValueError("invalid file signature fields")
                if not integer(signature["volume"], 0, 2**64-1):
                    raise ValueError("invalid full volume identity")
                identity = signature["file_id_128"]
                if not isinstance(identity, str) or FILE_ID.fullmatch(identity) is None or int(identity, 16) == 0:
                    raise ValueError("invalid full 128-bit file identity")
                for key in ("size", "allocation"):
                    if not integer(signature[key], 0, 2**63-1):
                        raise ValueError("invalid file extent")
                for key in ("links", "attributes"):
                    if not integer(signature[key], 0, 2**32-1):
                        raise ValueError("invalid DWORD metadata")
                for key in ("creation_ticks", "write_ticks", "change_ticks"):
                    if not integer(signature[key], -2**63, 2**63-1):
                        raise ValueError("invalid native timestamp")
                if (signature["directory"] is not False or signature["delete_pending"] is not False
                        or signature["attributes"] & 0x10):
                    raise ValueError("not a stable regular-file observation")
            if any(value != signatures[0] for value in signatures[1:]):
                raise ValueError("file identity/metadata changed")
            first, rewind, second = (observed.get(name) for name in
                                     ("read_first", "rewind", "read_second"))
            if any(not isinstance(value, dict) for value in (first, rewind, second)):
                raise ValueError("missing read/rewind bounds")
            if (set(first) != {"begin_ns", "end_ns", "sha256"}
                    or set(second) != {"begin_ns", "end_ns", "sha256"}
                    or set(rewind) != {"begin_ns", "end_ns", "position"}):
                raise ValueError("invalid successful read/rewind fields")
            times = [observed.get("begin_ns"), first.get("begin_ns"), first.get("end_ns"),
                     rewind.get("begin_ns"), rewind.get("end_ns"),
                     second.get("begin_ns"), second.get("end_ns"), observed.get("end_ns")]
            if any(not integer(value, begin_ns, end_ns) for value in times):
                raise ValueError("image observation outside census bounds")
            if times != sorted(times) or times[0] < previous_end:
                raise ValueError("image read/rewind ordering invalid")
            if type(rewind.get("position")) is not int or rewind["position"] != 0:
                raise ValueError("rewind did not return zero")
            if first.get("sha256") != digest or second.get("sha256") != digest or observed.get("sha256") != digest:
                raise ValueError("two digests disagree with row")
            previous_end = times[-1]
        except (KeyError, TypeError, ValueError) as error:
            errors.append(prefix + str(error))
    if guard_count != 1:
        errors.append("expected exactly one retained enclosing guard row")
    return errors
