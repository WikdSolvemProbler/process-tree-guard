"""Three fixed no-workload observer pipeline qualification snapshots."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
FIXED = HERE.with_name("issue7-quiet-launch-013")
INPUTS = HERE.with_name("issue7-quiet-campaign-inputs-002")
MANIFEST_SHA = "313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae"
NEW_PINS = {"native_image.py": "8adc1aa23a2298c3adab9ca561b621e8dccca4e78e59407aea39b9b08a2b9440",
            "inventory_gate.py": "cc50304a5a99f4de0b5c92e0b351f8986fa7dbb96ac146c867234f0b1802a783",
            "validate_image_rows.py": "54c7f1fec41ef5bc83133917bbe53c1e376d9af86d00c00a4584a69800989061"}


def read_checked(path, expected):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError("source differs: " + str(path))
    return raw


def loaded(name, path, raw):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def source_bytes():
    raw = read_checked(FIXED / "manifest.json", MANIFEST_SHA)
    manifest = json.loads(raw)
    frozen = {name: read_checked(FIXED / name, digest)
              for name, digest in manifest["file_sha256"].items()}
    candidate = {name: read_checked(HERE / name, digest) for name, digest in NEW_PINS.items()}
    inputs_raw = read_checked(INPUTS / "inputs.json", manifest["input_manifest_sha256"])
    inputs = json.loads(inputs_raw)
    slot_name = "tests/campaign/windows_slot_job.py"
    slot = read_checked(INPUTS / "checkout" / slot_name, inputs["file_sha256"][slot_name])
    hashes = {"manifest.json": MANIFEST_SHA, "inputs.json": manifest["input_manifest_sha256"],
              **{"013/" + name: hashlib.sha256(data).hexdigest() for name, data in frozen.items()},
              **{"candidate/" + name: hashlib.sha256(data).hexdigest() for name, data in candidate.items()},
              slot_name: hashlib.sha256(slot).hexdigest()}
    for group in ("tools", "fingerprints"):
        for name, pin in manifest[group].items():
            content = read_checked(Path(pin["path"]), pin["sha256"])
            hashes[group + "/" + name] = hashlib.sha256(content).hexdigest()
    if not Path(sys.executable).samefile(manifest["tools"]["python"]["path"]):
        raise ValueError("unsealed Python interpreter")
    return manifest, frozen, candidate, slot, hashes


def main():
    manifest, frozen, candidate, slot, before = source_bytes()
    loaded("image_policy", FIXED / "image_policy.py", frozen["image_policy.py"])
    math_gate = loaded("quiet_gate", FIXED / "quiet_gate.py", frozen["quiet_gate.py"])
    loaded("windows_slot_job", INPUTS / "checkout/tests/campaign/windows_slot_job.py", slot)
    loaded("native_image", HERE / "native_image.py", candidate["native_image.py"])
    gate = loaded("inventory_gate", HERE / "inventory_gate.py", candidate["inventory_gate.py"])
    sampler = loaded("quiet_sampler", FIXED / "quiet_sampler.py", frozen["quiet_sampler.py"])
    validator = loaded("validate_image_rows", HERE / "validate_image_rows.py",
                       candidate["validate_image_rows.py"])
    from image_policy import ALLOWED
    deadline = time.perf_counter_ns() + 35_000_000_000
    original_snapshot = gate.create_snapshot
    snapshots = []
    completed = 0
    code = 0
    qualified = []
    raw_native_valid = []

    def measured_snapshot(*args):
        begin = time.perf_counter_ns()
        value = original_snapshot(*args)
        snapshots.append({"begin_ns": begin, "end_ns": time.perf_counter_ns(),
                          "native_return_valid": bool(value) and value != gate.INVALID_HANDLE})
        return value

    with (
        (HERE / "pipeline-001.jsonl").open("x", encoding="utf-8") as output,
        (HERE / "raw-sample-001.jsonl").open("x", encoding="utf-8") as raw_output,
    ):
        def emit(kind, **values):
            print(json.dumps({"kind": kind, **values}, allow_nan=False), file=output, flush=True)
        emit("context", source_sha256=before, snapshots=3, spacing_seconds=5,
             inner_seconds=35, manifest_sha256=MANIFEST_SHA, benchmark_slots=0,
             scope="observer census cost/evidence qualification only; not a twelve-window quiet phase or campaign",
             instrumentation="stage/Snapshot QPC only; no added process CPU queries; independent validation after measured finished boundary",
             census_budget_ns=50_000_000)
        try:
            with gate.enclosing_guard(manifest["tools"]["outer_guard"]["path"]) as guard:
                sampler.warm_job_query()
                gate.create_snapshot = measured_snapshot
                origin = time.perf_counter_ns()
                for index in range(3):
                    remaining = origin + index * 5_000_000_000 - time.perf_counter_ns()
                    if remaining > 0:
                        time.sleep(remaining / 1e9)
                    if time.perf_counter_ns() >= deadline:
                        raise TimeoutError("35-second diagnostic deadline")
                    snapshots.clear()
                    stamp_begin = time.perf_counter_ns()
                    sample = sampler.stamp()
                    stamp_end = time.perf_counter_ns()
                    emit_begin = time.perf_counter_ns()
                    print(json.dumps({"kind": "sample", "phase": "pre", "endpoint": False,
                                      "raw": asdict(sample), "utc_ns": time.time_ns()},
                                     allow_nan=False), file=raw_output, flush=True)
                    emit_end = time.perf_counter_ns()
                    inventory_begin = time.perf_counter_ns()
                    rows = gate.inventory(guard, None, manifest["image_policy"])
                    finished = time.perf_counter_ns()
                    validation_begin = time.perf_counter_ns()
                    evidence_errors = validator.validate_rows(rows, inventory_begin, finished,
                                                              guard[0], guard[2])
                    native_errors = math_gate.sample_errors(sample, during=False)
                    validation_end = time.perf_counter_ns()
                    disallowed = [row for row in rows if row["state"] not in ALLOWED]
                    budget_ok = 0 <= finished - sample.monotonic_ns <= 50_000_000
                    case_qualified = budget_ok and not disallowed and not evidence_errors and not native_errors
                    qualified.append(case_qualified)
                    raw_native_valid.append(not native_errors)
                    emit("sample", index=index, source_monotonic_ns=sample.monotonic_ns,
                         stamp_begin_ns=stamp_begin, stamp_end_ns=stamp_end,
                         raw_emit_begin_ns=emit_begin, raw_emit_end_ns=emit_end,
                         inventory_begin_ns=inventory_begin, finished_ns=finished,
                         snapshot_calls=list(snapshots), rows=rows,
                         all_allowed=not disallowed, disallowed_rows=disallowed,
                         evidence_errors=evidence_errors, native_sample_errors=native_errors,
                         independent_validation_begin_ns=validation_begin,
                         independent_validation_end_ns=validation_end,
                         whole_bracket_ns=finished - sample.monotonic_ns,
                         time_budget_pass=budget_ok, observer_snapshot_qualified=case_qualified)
                    completed += 1
                    if time.perf_counter_ns() >= deadline:
                        raise TimeoutError("35-second deadline after pipeline/validation")
        except BaseException as error:
            code = 1
            emit("error", type=type(error).__name__, error=str(error),
                 winerror=getattr(error, "winerror", None),
                 evidence=getattr(error, "evidence", None),
                 partial_snapshot_calls=list(snapshots))
        finally:
            gate.create_snapshot = original_snapshot
            try:
                after = source_bytes()[-1]
                unchanged = before == after
            except BaseException as error:
                code = 1
                after, unchanged = None, False
                emit("source_error", type=type(error).__name__, error=str(error))
            if time.perf_counter_ns() >= deadline:
                code = 1
                emit("deadline", stage="terminal")
            emit("terminal", code=code, completed=completed, source_sha256=after,
                 sources_unchanged=unchanged,
                 observer_pipeline_qualified=(code == 0 and unchanged and completed == 3 and all(qualified)),
                 raw_native_valid=raw_native_valid, benchmark_slots=0,
                 scope="diagnostic exit0 alone is not admission; no phase/campaign or performance result")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
