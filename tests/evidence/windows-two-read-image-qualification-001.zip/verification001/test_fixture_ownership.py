import tempfile
from pathlib import Path
import unittest
import native_image_control as control


class OwnershipTests(unittest.TestCase):
    def test_preexisting_directory_and_contents_untouched(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "fixture"
            path.mkdir()
            marker = path / "target"
            marker.write_bytes(b"foreign")
            fixture = control.OwnedFixture(path)
            with self.assertRaises(FileExistsError):
                fixture.create()
            self.assertEqual(fixture.cleanup(), [])
            self.assertEqual(marker.read_bytes(), b"foreign")

    def test_replacement_updates_owned_identity_and_cleans_only_own_files(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "fixture"
            fixture = control.OwnedFixture(path)
            fixture.create()
            fixture.write("target", b"old")
            fixture.write("replacement", b"new")
            fixture.replace("replacement", "target")
            self.assertEqual((path / "target").read_bytes(), b"new")
            self.assertEqual(fixture.cleanup(), [])
            self.assertFalse(path.exists())

    def test_replaced_foreign_entry_is_quarantined(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "fixture"
            fixture = control.OwnedFixture(path)
            fixture.create()
            fixture.write("target", b"own")
            other = path / "foreign"
            other.write_bytes(b"foreign")
            control.os.replace(other, path / "target")
            errors = fixture.cleanup()
            self.assertTrue(errors)
            self.assertEqual((path / "target").read_bytes(), b"foreign")

    def test_unknown_entry_is_never_removed(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "fixture"
            fixture = control.OwnedFixture(path)
            fixture.create()
            fixture.write("target", b"own")
            (path / "unknown").write_bytes(b"foreign")
            self.assertTrue(fixture.cleanup())
            self.assertFalse((path / "target").exists())
            self.assertEqual((path / "unknown").read_bytes(), b"foreign")


if __name__ == "__main__":
    unittest.main()
