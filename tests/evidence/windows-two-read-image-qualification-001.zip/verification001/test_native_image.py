import ctypes
import hashlib
from pathlib import Path
import unittest
from unittest.mock import patch

EXPECTED = "8adc1aa23a2298c3adab9ca561b621e8dccca4e78e59407aea39b9b08a2b9440"
if hashlib.sha256(Path(__file__).with_name("native_image.py").read_bytes()).hexdigest() != EXPECTED:
    raise RuntimeError("native image source differs before importing controls")
import native_image as image


def signature():
    return {"volume": 9, "file_id_128": "11" * 16, "size": 4,
            "allocation": 4096, "links": 1, "creation_ticks": 100,
            "write_ticks": 200, "change_ticks": 300, "attributes": 32,
            "directory": False, "delete_pending": False}


class ImageTests(unittest.TestCase):
    def setUp(self):
        self.seek = patch.object(image, "set_pointer", return_value=1).start()
        self.addCleanup(patch.stopall)

    def inspect(self, signatures):
        with (
            patch.object(image, "create_file", side_effect=[101, 102, 103]) as opened,
            patch.object(image, "close_handle", return_value=1) as closed,
            patch.object(image, "metadata", side_effect=signatures),
            patch.object(image, "held_digest", return_value="a" * 64) as digest,
        ):
            result = image.inspect_image(Path("C:/fixture/python.exe"))
        return result, opened, closed, digest

    def test_per_row_named_and_held_checks_and_nonblocking_shares(self):
        result, opened, closed, digest = self.inspect([signature() for _ in range(4)])
        self.assertEqual(result[0], "a" * 64)
        self.assertEqual([call.args[1] for call in opened.call_args_list],
                         [image.FILE_READ_ATTRIBUTES,
                          image.GENERIC_READ | image.FILE_READ_ATTRIBUTES,
                          image.FILE_READ_ATTRIBUTES])
        for call in opened.call_args_list:
            self.assertEqual(call.args[2:5], (7, None, image.OPEN_EXISTING))
        self.assertEqual(sorted(call.args[0] for call in closed.call_args_list), [101, 102, 103])
        self.assertEqual([call.args for call in digest.call_args_list], [(102, 4), (102, 4)])
        self.assertEqual(self.seek.call_count, 1)
        seek_args = self.seek.call_args.args
        self.assertEqual((seek_args[0], seek_args[1], seek_args[3]), (102, 0, 0))
        self.assertEqual(result[1]["read_first"]["sha256"], result[1]["read_second"]["sha256"])
        self.assertLessEqual(result[1]["read_first"]["end_ns"], result[1]["rewind"]["begin_ns"])
        self.assertLessEqual(result[1]["rewind"]["end_ns"], result[1]["read_second"]["begin_ns"])
        self.assertEqual(result[1]["held_before"], result[1]["named_after"])

    def test_full_high_128_bits_and_each_metadata_drift_refuse(self):
        for field, changed in (
            ("file_id_128", "11" * 8 + "22" * 8), ("volume", 10),
            ("size", 5), ("creation_ticks", 101), ("write_ticks", 201),
            ("change_ticks", 301), ("attributes", 0), ("links", 2),
        ):
            with self.subTest(field=field):
                states = [signature() for _ in range(4)]
                states[2][field] = changed
                with (
                    patch.object(image, "create_file", side_effect=[101, 102, 103]),
                    patch.object(image, "close_handle", return_value=1) as close,
                    patch.object(image, "metadata", side_effect=states),
                    patch.object(image, "held_digest", return_value="a" * 64),
                ):
                    with self.assertRaisesRegex(ValueError, "changed"):
                        image.inspect_image(Path("C:/fixture/python.exe"))
                self.assertEqual(close.call_count, 3)

    def test_native_query_error_closes_owned_handle(self):
        with (
            patch.object(image, "create_file", return_value=101),
            patch.object(image, "close_handle", return_value=1) as close,
            patch.object(image, "file_info", return_value=0),
        ):
            with self.assertRaises(OSError):
                image.inspect_image(Path("C:/fixture/python.exe"))
        close.assert_called_once_with(101)

    def test_late_metadata_read_and_open_failures_close_all_owned_handles(self):
        for failing_index, expected in ((1, [101, 102]), (2, [101, 102]), (3, [101, 102, 103])):
            with self.subTest(failing_index=failing_index):
                states = [signature() for _ in range(4)]
                states[failing_index] = OSError("injected query failure")
                with (
                    patch.object(image, "create_file", side_effect=[101, 102, 103]),
                    patch.object(image, "close_handle", return_value=1) as close,
                    patch.object(image, "metadata", side_effect=states),
                    patch.object(image, "held_digest", return_value="a" * 64),
                ):
                    with self.assertRaises(OSError):
                        image.inspect_image(Path("C:/fixture/python.exe"))
                self.assertEqual(sorted(call.args[0] for call in close.call_args_list), expected)
        with (
            patch.object(image, "create_file", side_effect=[101, 102]),
            patch.object(image, "close_handle", return_value=1) as close,
            patch.object(image, "metadata", side_effect=[signature(), signature()]),
            patch.object(image, "held_digest", side_effect=OSError("read failed")),
        ):
            with self.assertRaises(OSError):
                image.inspect_image(Path("C:/fixture/python.exe"))
        self.assertEqual(sorted(call.args[0] for call in close.call_args_list), [101, 102])
        with (
            patch.object(image, "create_file", side_effect=[101, 102, image.INVALID_HANDLE_VALUE]),
            patch.object(image, "close_handle", return_value=1) as close,
            patch.object(image, "metadata", side_effect=[signature()] * 3),
            patch.object(image, "held_digest", return_value="a" * 64),
        ):
            with self.assertRaises(OSError):
                image.inspect_image(Path("C:/fixture/python.exe"))
        self.assertEqual(sorted(call.args[0] for call in close.call_args_list), [101, 102])


    def test_identical_metadata_different_fixed_reads_refuses_with_evidence(self):
        with (
            patch.object(image, "create_file", side_effect=[101, 102, 103]),
            patch.object(image, "close_handle", return_value=1) as close,
            patch.object(image, "metadata", side_effect=[signature()] * 4),
            patch.object(image, "held_digest", side_effect=["a" * 64, "b" * 64]),
        ):
            with self.assertRaisesRegex(image.ImageVerificationError, "digests differ") as caught:
                image.inspect_image(Path("C:/fixture/python.exe"))
        self.assertEqual(close.call_count, 3)
        evidence = caught.exception.evidence
        self.assertEqual(evidence["read_first"]["sha256"], "a" * 64)
        self.assertEqual(evidence["read_second"]["sha256"], "b" * 64)
        self.assertEqual(evidence["held_before"], evidence["named_after"])

    def test_seek_error_or_nonzero_position_refuses_and_closes(self):
        def nonzero(handle, offset, position, origin):
            position._obj.value = 1
            return 1
        for seek in (lambda *args: 0, nonzero):
            with self.subTest(seek=seek):
                with (
                    patch.object(image, "create_file", side_effect=[101, 102]),
                    patch.object(image, "close_handle", return_value=1) as close,
                    patch.object(image, "metadata", side_effect=[signature()] * 2),
                    patch.object(image, "held_digest", return_value="a" * 64) as reads,
                    patch.object(image, "set_pointer", side_effect=seek),
                ):
                    with self.assertRaises((OSError, image.ImageVerificationError)) as caught:
                        image.inspect_image(Path("C:/fixture/python.exe"))
                self.assertEqual(close.call_count, 2)
                reads.assert_called_once_with(102, 4)
                self.assertIn("end_ns", caught.exception.evidence["rewind"])

    def test_first_and_second_short_excess_and_native_read_error_preserve_cleanup(self):
        for phase in (0, 1):
            for error in (ValueError("image ended before its initial size"),
                          ValueError("image exceeds its initial size"), OSError("ReadFile failure")):
                with self.subTest(phase=phase, error=error):
                    results = ["a" * 64] * phase + [error]
                    with (
                        patch.object(image, "create_file", side_effect=[101, 102]),
                        patch.object(image, "close_handle", return_value=1) as close,
                        patch.object(image, "metadata", side_effect=[signature()] * 2),
                        patch.object(image, "held_digest", side_effect=results),
                    ):
                        with self.assertRaises((ValueError, OSError)) as caught:
                            image.inspect_image(Path("C:/fixture/python.exe"))
                    self.assertEqual(close.call_count, 2)
                    read = caught.exception.evidence["read_first" if phase == 0 else "read_second"]
                    self.assertIn("begin_ns", read)
                    self.assertIn("end_ns", read)
                    self.assertNotIn("sha256", read)

    def test_bounded_content_read_and_excess_refusal(self):
        requested = []

        def read(handle, buffer, amount, count, overlapped):
            requested.append(amount)
            if len(requested) == 1:
                ctypes.memmove(buffer, b"data", 4)
                count._obj.value = 4
            else:
                count._obj.value = 1
            return 1
        with patch.object(image, "read_file", read):
            with self.assertRaisesRegex(ValueError, "exceeds"):
                image.held_digest(102, 4)
        self.assertEqual(requested, [4, 1])

    def test_short_content_refuses(self):
        def read(handle, buffer, amount, count, overlapped):
            count._obj.value = 0
            return 1
        with patch.object(image, "read_file", read):
            with self.assertRaisesRegex(ValueError, "ended"):
                image.held_digest(102, 4)


if __name__ == "__main__":
    unittest.main()
