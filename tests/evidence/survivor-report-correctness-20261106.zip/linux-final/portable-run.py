import base64
import io
import json
from pathlib import Path
import sys
import tarfile
import time
sys.path.insert(0, "tests")
import run_tests

class Immediate(run_tests.CertificateResult):
    def startTest(self, test):
        super().startTest(test)
        print(f"START {test.id()} ns={time.monotonic_ns()}", flush=True)

    def addSuccess(self, test):
        super().addSuccess(test)
        print(f"PASS {test.id()}", flush=True)

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        print(f"SKIP {test.id()} reason={reason}", flush=True)

    def addFailure(self, test, err):
        super().addFailure(test, err)
        print(f"FAIL {test.id()}\n{self._exc_info_to_string(err, test)}", flush=True)

    def addError(self, test, err):
        super().addError(test, err)
        print(f"ERROR {test.id()}\n{self._exc_info_to_string(err, test)}", flush=True)

    def addExpectedFailure(self, test, err):
        super().addExpectedFailure(test, err)
        print(f"SKIP {test.id()} reason=expected_failure", flush=True)

    def addUnexpectedSuccess(self, test):
        super().addUnexpectedSuccess(test)
        print(f"FAIL {test.id()} reason=unexpected_success", flush=True)

run_tests.CertificateResult = Immediate
result = run_tests.main(["--tree-sha", "74629530534669ced29978b0f5a5a423586c404a"])
folder = Path("tests/certificates")
index = json.loads((folder / "index.json").read_text(encoding="utf-8"))
print("CERTIFICATE_INDEX " + json.dumps(index, sort_keys=True), flush=True)
buf = io.BytesIO()
with tarfile.open(fileobj=buf, mode="w:gz") as archive:
    for path in sorted(folder.glob("*.json")):
        archive.add(path, arcname=path.name, recursive=False)
print("CERTIFICATE_ARCHIVE_B64 " + base64.b64encode(buf.getvalue()).decode("ascii"), flush=True)
sys.exit(result)
