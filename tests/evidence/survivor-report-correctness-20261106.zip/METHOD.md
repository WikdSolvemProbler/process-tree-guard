# Correctness after the survivor report repair

The first full runs tested exact commit 88f5a6d. They preserved 648
certificates each and failed the repository's census assertions.
The Windows run had three failures and the Linux run had four. The
first Windows preflight stopped before tests due to a mistyped
expected hash and is also included.

The final report regression uses the same assertions within an
existing test, restoring the 647-case census. The native Windows
x64 run checked exact 7f4f32e with the verified staged MSVC binaries.
The Linux portable run checked exact 7462953 on ARM64 under a
finite user cgroup deadline. Both completed with zero failures or
errors. Native macOS ARM64 checked the amended report test and the
four count checks from 7462953. It passed all five targeted checks.
Remote cleanup receipts are included.

The full benchmark archive is a separate artifact. These are
correctness test results and support no speed or native backend claim.
