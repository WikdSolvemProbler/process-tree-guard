// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

// Read-only host admission probe. The limit applies to this process only.
// The exclusive-UID positive case requires a separately provisioned lease.
#include <errno.h>
#include <poll.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>

static int wait_exit(pid_t pid) {
    int status = 0;
    pid_t done;
    do {
        done = waitpid(pid, &status, 0);
    } while (done < 0 && errno == EINTR);
    if (done != pid || !WIFEXITED(status)) {
        return -1;
    }
    return WEXITSTATUS(status);
}

static int trial_fork(void) {
    pid_t child = fork();
    if (child < 0) {
        return errno;
    }
    if (child == 0) {
        _exit(0);
    }
    return wait_exit(child) == 0 ? 0 : EIO;
}

// Success means a second process was charged to the verifier's real UID.
// The caller must separately prove exclusive ownership of that UID.
static int uid_witness(bool *bound_verified) {
    const struct rlimit bound = { .rlim_cur = 2, .rlim_max = 2 };
    struct rlimit actual;
    if (setrlimit(RLIMIT_NPROC, &bound) != 0) {
        return errno;
    }
    if (getrlimit(RLIMIT_NPROC, &actual) != 0) {
        return errno;
    }
    if (actual.rlim_cur != bound.rlim_cur || actual.rlim_max != bound.rlim_max) {
        return EIO;
    }
    *bound_verified = true;
    return trial_fork();
}

int main(void) {
    if (getuid() == 0 || getuid() != geteuid()) {
        fputs("The verifier requires a non-root real and effective UID.\n", stderr);
        return 125;
    }
    const int baseline = trial_fork();
    if (baseline != 0) {
        fprintf(stderr, "baseline fork failed errno=%d\n", baseline);
        return 125;
    }
    int release[2];
    if (pipe(release) != 0) {
        perror("pipe");
        return 125;
    }
    pid_t peer = fork();
    if (peer < 0) {
        perror("peer fork");
        close(release[0]);
        close(release[1]);
        return 125;
    }
    if (peer == 0) {
        close(release[1]);
        struct pollfd watch = { .fd = release[0], .events = POLLIN };
        int ready = poll(&watch, 1, 5000);
        close(release[0]);
        _exit(ready == 1 && (watch.revents & POLLHUP) ? 0 : 73);
    }
    close(release[0]);
    int status;
    bool bound_verified = false;
    const bool peer_before = waitpid(peer, &status, WNOHANG) == 0;
    const int result = peer_before ? uid_witness(&bound_verified) : EIO;
    const bool peer_after = peer_before && waitpid(peer, &status, WNOHANG) == 0;
    close(release[1]);
    const int peer_exit = peer_after ? wait_exit(peer) : -1;
    printf("uid=%u baseline_fork_errno=%d peer_pid=%d peer_live_before=%d "
           "peer_live_after=%d limit=2 bound_verified=%d witness_errno=%d peer_exit=%d\n",
           (unsigned)getuid(), baseline, (int)peer, peer_before, peer_after,
           bound_verified, result, peer_exit);
    return peer_before && peer_after && bound_verified && result == EAGAIN && peer_exit == 0
        ? 0 : 125;
}
