# macOS detached fork churn

The exact source compiled as an ordinary user on the Tailscale Mac. The
privileged runtime fixtures ran on disposable hosted arm64 macOS VMs with two
dedicated disabled identities and independent deadlines. The parked regression
passed all 20 rounds.

The first churn attempt drained the worker and peer, then stopped on a missed
overlap in the first round. The next version collected all 20 outcomes under
the same overlap rule. All 20 rounds observed the independent empty-UID
witness, exact detached anchor SIGKILL, and a live peer. Three recorded a
successful fork fully inside sweep dispatch-to-reap, and zero recorded one
after the pre-kill marker. The overlap qualification failed. The kernel's
internal snapshot boundary was unobserved.

The collected source changes when the overlap score is evaluated. The
teardown method and all-round success requirement are unchanged.
