#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <linux/capability.h>
#include <linux/magic.h>
#include <linux/sched.h>
#include <limits.h>
#include <poll.h>
#include <sched.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/syscall.h>
#include <sys/timerfd.h>
#include <time.h>
#include <sys/wait.h>
#include <unistd.h>

#define MOUNT "/sys/fs/cgroup"
#define SCOPE_PREFIX "/system.slice/"
#define MAX_PATH PATH_MAX

static void need(int ok, const char *operation)
{
    if (!ok) {
        int error = errno;
        fprintf(stderr, "invalid operation=%s errno=%d (%s)\n",
                operation, error, strerror(error));
        exit(90);
    }
}

static void join(char output[MAX_PATH], const char *base, const char *name)
{
    int count = snprintf(output, MAX_PATH, "%s/%s", base, name);
    need(count >= 0 && count < MAX_PATH, "join path");
}

static void procfile(char output[MAX_PATH], pid_t pid, const char *name)
{
    int count = snprintf(output, MAX_PATH, "/proc/%ld/%s", (long)pid, name);
    need(count >= 0 && count < MAX_PATH, "proc path");
}

static void read_text(const char *path, char *buffer, size_t size)
{
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    need(fd >= 0, path);
    ssize_t n = read(fd, buffer, size - 1);
    need(n >= 0 && (size_t)n < size - 1, "read text");
    buffer[n] = '\0';
    close(fd);
}

static void read_ns(const char *path, char output[128])
{
    ssize_t n = readlink(path, output, 127);
    need(n > 0 && n < 127, "read namespace link");
    output[n] = '\0';
}

static int put(const char *label, const char *path, const char *value)
{
    int fd = open(path, O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) {
        int error = errno;
        printf("%s stage=open errno=%d path=%s\n", label, error, path);
        return error;
    }
    size_t size = strlen(value);
    ssize_t n = write(fd, value, size);
    int error = n < 0 ? errno : 0;
    close(fd);
    need(n < 0 || (size_t)n == size, "control short write");
    printf("%s stage=write errno=%d path=%s\n", label, error, path);
    return error;
}

static int cg_put(const char *label, const char *cg, const char *name, const char *value)
{
    char path[MAX_PATH];
    join(path, cg, name);
    return put(label, path, value);
}

static void member(const char *label, pid_t pid, const char *suffix)
{
    char path[MAX_PATH], actual[MAX_PATH], expected[MAX_PATH];
    procfile(path, pid, "cgroup");
    read_text(path, actual, sizeof(actual));
    int n = snprintf(expected, sizeof(expected), "0::%s\n", suffix);
    need(n > 0 && (size_t)n < sizeof(expected), "membership expectation");
    printf("%s pid=%ld membership=%s", label, (long)pid, actual);
    need(strcmp(actual, expected) == 0, "membership mismatch");
}

static void no_processes(const char *cg)
{
    char path[MAX_PATH], events[128];
    join(path, cg, "cgroup.events");
    read_text(path, events, sizeof(events));
    printf("drain path=%s %s", cg, events);
    need(strstr(events, "populated 0\n") != NULL, "nonempty dedicated cgroup");
}

static int reap(int fd, pid_t pid, const char *label)
{
    siginfo_t result = {0};
    need(waitid(P_PIDFD, (id_t)fd, &result, WEXITED) == 0, "waitid pidfd");
    need(result.si_pid == pid, "wrong pidfd result");
    printf("%s held_pid=%ld si_code=%d si_status=%d\n",
           label, (long)pid, result.si_code, result.si_status);
    close(fd);
    return result.si_code == CLD_EXITED ? result.si_status : 128 + result.si_status;
}

static void still_held(int pidfd)
{
    struct pollfd pfd = {.fd = pidfd, .events = POLLIN};
    need(poll(&pfd, 1, 0) == 0, "expected held live process");
}


static const uid_t payload_uid = 501;
static const gid_t payload_gid = 1000;
static const gid_t payload_groups[] = {999, 1000};

struct held {
    pid_t pid;
    int fd;
};

static void verify_ids(const char *label)
{
    uid_t ru, eu, su;
    gid_t rg, eg, sg, groups[2];
    need(getresuid(&ru, &eu, &su) == 0 && getresgid(&rg, &eg, &sg) == 0,
         "read saved credentials");
    need(getgroups(2, groups) == 2, "read exact supplementary groups");
    printf("%s uid=%u/%u/%u gid=%u/%u/%u groups=%u,%u\n",
           label, ru, eu, su, rg, eg, sg, groups[0], groups[1]);
    need(ru == payload_uid && eu == payload_uid && su == payload_uid &&
         rg == payload_gid && eg == payload_gid && sg == payload_gid &&
         groups[0] == payload_groups[0] && groups[1] == payload_groups[1],
         "credential parity");
    struct __user_cap_header_struct header = {.version = _LINUX_CAPABILITY_VERSION_3};
    struct __user_cap_data_struct caps[2] = {0};
    need(syscall(SYS_capget, &header, caps) == 0, "read capabilities");
    int nnp = prctl(PR_GET_NO_NEW_PRIVS, 0L, 0L, 0L, 0L);
    printf("%s caps_eff=%08x%08x caps_prm=%08x%08x caps_inh=%08x%08x nnp=%d\n",
           label, caps[1].effective, caps[0].effective, caps[1].permitted,
           caps[0].permitted, caps[1].inheritable, caps[0].inheritable, nnp);
    need(!(caps[0].effective || caps[1].effective || caps[0].permitted ||
           caps[1].permitted || caps[0].inheritable || caps[1].inheritable) &&
         nnp == 1, "unprivileged no-new-privileges payload");
}

static void drop_to_guest(void)
{
    need(prctl(PR_CAP_AMBIENT, PR_CAP_AMBIENT_CLEAR_ALL, 0L, 0L, 0L) == 0,
         "clear ambient capabilities");
    need(setgroups(2, payload_groups) == 0, "set supplementary groups");
    need(setresgid(payload_gid, payload_gid, payload_gid) == 0, "drop gid");
    need(setresuid(payload_uid, payload_uid, payload_uid) == 0, "drop uid");
    need(prctl(PR_SET_NO_NEW_PRIVS, 1L, 0L, 0L, 0L) == 0, "lock no new privileges");
    verify_ids("child-pre-exec");
}

static void root_owned(const char *path, int directory)
{
    struct stat info;
    need(lstat(path, &info) == 0 && (directory ? S_ISDIR(info.st_mode) : S_ISREG(info.st_mode)) &&
         info.st_uid == 0 && info.st_gid == 0 && !(info.st_mode & (S_IWGRP | S_IWOTH)),
         "root-owned controller path");
    printf("ownership mode=%04o uid=%u gid=%u path=%s\n", info.st_mode & 07777,
           info.st_uid, info.st_gid, path);
}


static void pipe_pair(int pair[2])
{
    need(pipe2(pair, O_CLOEXEC) == 0, "make pipe");
}

static void emit_bytes(int fd, const void *data, size_t size)
{
    need(write(fd, data, size) == (ssize_t)size, "write complete handshake");
}

static void take_bytes(int fd, void *data, size_t size)
{
    need(read(fd, data, size) == (ssize_t)size, "read complete handshake");
}

static int pidfd_for(pid_t pid)
{
    int fd = (int)syscall(SYS_pidfd_open, pid, 0);
    need(fd >= 0, "pidfd_open");
    return fd;
}

static void send_kill(int fd)
{
    need(syscall(SYS_pidfd_send_signal, fd, SIGKILL, NULL, 0) == 0,
         "signal exact held test process");
}

static void held_status(struct held process, const char *label, int expected)
{
    need(reap(process.fd, process.pid, label) == expected, "wrong held process status");
}

static long long boottime(void)
{
    struct timespec now;
    need(clock_gettime(CLOCK_BOOTTIME, &now) == 0, "boottime");
    return (long long)now.tv_sec * 1000000000LL + now.tv_nsec;
}

static int arm_timer(int seconds, long long *deadline)
{
    int fd = timerfd_create(CLOCK_BOOTTIME, TFD_CLOEXEC | TFD_NONBLOCK);
    need(fd >= 0, "deadline timerfd");
    *deadline = boottime() + (long long)seconds * 1000000000LL;
    struct itimerspec value = {.it_value = {.tv_sec = *deadline / 1000000000LL,
                                          .tv_nsec = *deadline % 1000000000LL}};
    need(timerfd_settime(fd, TFD_TIMER_ABSTIME, &value, NULL) == 0, "arm absolute deadline");
    return fd;
}

static void drain(const char *leaf)
{
    char path[MAX_PATH], events[128];
    join(path, leaf, "cgroup.events");
    const struct timespec pause_time = {.tv_nsec = 10000000};
    for (int attempt = 0; attempt < 100; ++attempt) {
        read_text(path, events, sizeof(events));
        if (strstr(events, "populated 0\n")) {
            no_processes(leaf);
            return;
        }
        nanosleep(&pause_time, NULL);
    }
    need(0, "watchdog drain timed out");
}


enum gate { PENDING, READY, RELEASED, CANCELLED, FINISHED };
enum trigger { NO_EVENT, SUPERVISOR_LOST, OWNER_LOST, DEADLINE, NORMAL, PROTOCOL, INPUT };
enum stage { ARMED, PLACED, DONE };
enum plan { OWNER_BEFORE, DEADLINE_BEFORE, SUPERVISOR_BETWEEN, NORMAL_EXEC };
_Static_assert(ATOMIC_INT_LOCK_FREE == 2, "test requires lock-free process-shared int");

struct note {
    enum stage stage;
    enum trigger trigger;
    pid_t watcher, payload;
    int clone_attempts, exec_markers, payload_status, supervisor_status;
};

static enum trigger poll_event(int supervisor, int owner, int timer, int input, int timeout)
{
    struct pollfd p[4] = {
        {.fd = supervisor, .events = POLLIN},
        {.fd = owner, .events = POLLIN},
        {.fd = timer, .events = POLLIN},
        {.fd = input, .events = POLLIN},
    };
    int n = poll(p, 4, timeout);
    need(n >= 0, "poll watchdog");
    if (p[0].revents & POLLIN) return SUPERVISOR_LOST;
    if (p[1].revents & POLLIN) return OWNER_LOST;
    if (p[2].revents & POLLIN) return DEADLINE;
    if (p[3].revents & (POLLIN | POLLHUP)) return INPUT;
    need(n == 0, "unexpected watchdog fd event");
    return NO_EVENT;
}

static struct held clone_held(const char *binary, const char *leaf, atomic_int *gate,
                              int permission, int marker, int requested_status)
{
    int target = open(leaf, O_PATH | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    need(target >= 0, "open exact root-owned payload leaf");
    struct held held = {.fd = -1};
    struct clone_args args = {.flags = CLONE_INTO_CGROUP | CLONE_PIDFD,
                              .pidfd = (uintptr_t)&held.fd,
                              .cgroup = (uint64_t)target, .exit_signal = SIGCHLD};
    long child = syscall(SYS_clone3, &args, sizeof(args));
    int error = child < 0 ? errno : 0;
    if (child == 0) {
        close(target);
        member("atomic-placement-before-exec", getpid(), leaf + strlen(MOUNT));
        int high_permission = fcntl(permission, F_DUPFD_CLOEXEC, 10);
        int high_marker = fcntl(marker, F_DUPFD_CLOEXEC, 10);
        need(high_permission >= 10 && high_marker >= 10, "stage allowed child fds");
        need(dup2(high_marker, 3) == 3 && dup2(high_permission, 4) == 4,
             "install exact marker and permit fds");
        need(syscall(SYS_close_range, 5U, UINT_MAX, 0U) == 0, "remove all unrelated inherited fds");
        need(mprotect(gate, sizeof(*gate), PROT_READ) == 0, "child read-only gate");
        drop_to_guest();
        emit_bytes(3, "R", 1);
        char permission_byte;
        ssize_t count = read(4, &permission_byte, 1);
        close(4);
        int phase = atomic_load_explicit(gate, memory_order_acquire);
        printf("held-child-permit pid=%ld read=%ld phase=%d\n", (long)getpid(), (long)count, phase);
        if (count != 1 || permission_byte != 'G' || phase != RELEASED)
            _exit(125);
        char status[20];
        snprintf(status, sizeof(status), "%d", requested_status);
        char *const child_args[] = {(char *)binary, "--payload", status, NULL};
        char *const clean_env[] = {"PATH=/usr/bin:/bin", "LC_ALL=C", NULL};
        execve(binary, child_args, clean_env);
        need(0, "exec gated payload");
    }
    close(target);
    printf("watchdog-clone3 child=%ld pidfd=%d errno=%d\n", child, held.fd, error);
    need(child > 0 && held.fd >= 0, "clone3 with held identity");
    held.pid = (pid_t)child;
    return held;
}

static void watchdog(const char *binary, const char *leaf, atomic_int *gate, enum plan plan,
                     int requested_status, int supervisor_fd, int owner_fd,
                     int launch, int permission, int completion, int evidence)
{
    char path[MAX_PATH];
    join(path, leaf, "cgroup.kill");
    int kill_fd = open(path, O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    need(kill_fd >= 0, "preopen dedicated cgroup.kill");
    long long deadline;
    int timer = arm_timer(plan == DEADLINE_BEFORE ? 1 : 6, &deadline);
    struct note note = {.stage = ARMED, .watcher = getpid(), .payload_status = -1};
    printf("watchdog-armed pid=%ld deadline_boottime_ns=%lld\n", (long)note.watcher, deadline);
    emit_bytes(evidence, &note, sizeof(note));

    struct held child = {.fd = -1};
    int markers[2] = {-1, -1};
    int ready_consumed = 0;
    enum trigger trigger = poll_event(supervisor_fd, owner_fd, timer, launch, -1);
    if (trigger == INPUT) {
        char request;
        if (read(launch, &request, 1) != 1 || request != 'L') {
            trigger = PROTOCOL;
        } else {
            trigger = poll_event(supervisor_fd, owner_fd, timer, -1, 0);
        }
        if (trigger == NO_EVENT) {
            pipe_pair(markers);
            note.clone_attempts++;
            child = clone_held(binary, leaf, gate, permission, markers[1], requested_status);
            note.payload = child.pid;
            close(markers[1]);
            markers[1] = -1;
            trigger = poll_event(supervisor_fd, owner_fd, timer, markers[0], -1);
            if (trigger == INPUT) {
                char byte;
                if (read(markers[0], &byte, 1) == 1 && byte == 'R') {
                    ready_consumed = 1;
                    int phase = PENDING;
                    need(atomic_compare_exchange_strong_explicit(gate, &phase, READY,
                                                                 memory_order_acq_rel,
                                                                 memory_order_acquire),
                         "publish held payload");
                    note.stage = PLACED;
                    emit_bytes(evidence, &note, sizeof(note));
                    trigger = poll_event(supervisor_fd, owner_fd, timer, child.fd, -1);
                    if (trigger == INPUT) {
                        if (atomic_load_explicit(gate, memory_order_acquire) == RELEASED)
                            trigger = NORMAL;
                        else
                            trigger = poll_event(supervisor_fd, owner_fd, timer, -1, -1);
                    }
                } else {
                    trigger = PROTOCOL;
                }
            }
        }
    }
    close(launch);
    close(permission);
    if (trigger == NORMAL)
        atomic_store_explicit(gate, FINISHED, memory_order_release);
    else
        atomic_exchange_explicit(gate, CANCELLED, memory_order_acq_rel);
    long long event_time = boottime();
    need(trigger != DEADLINE || event_time >= deadline, "early deadline");
    printf("watchdog-terminal trigger=%d phase=%d clones=%d time=%lld deadline=%lld\n",
           trigger, atomic_load_explicit(gate, memory_order_acquire), note.clone_attempts,
           event_time, deadline);
    emit_bytes(kill_fd, "1", 1);
    close(kill_fd);
    drain(leaf);
    if (child.fd >= 0) {
        note.payload_status = reap(child.fd, child.pid, "watchdog-reaped-exact-payload");
        char byte;
        ssize_t count;
        while ((count = read(markers[0], &byte, 1)) == 1) {
            if (byte == 'R' && !ready_consumed) {
                ready_consumed = 1;
                continue;
            }
            need(byte == 'X' && note.exec_markers == 0, "unexpected exec marker");
            note.exec_markers++;
        }
        need(count == 0, "complete payload marker stream");
        close(markers[0]);
    }
    note.stage = DONE;
    note.trigger = trigger;
    note.supervisor_status = trigger == NORMAL ? note.payload_status :
                             (trigger == DEADLINE ? 124 : 125);
    emit_bytes(evidence, &note, sizeof(note));
    ssize_t n = write(completion, &note, sizeof(note));
    int error = n < 0 ? errno : 0;
    need(n == (ssize_t)sizeof(note) || (n < 0 && error == EPIPE),
         "send completion or observe supervisor closed");
    _exit(0);
}

static void supervisor(const char *binary, const char *leaf, atomic_int *gate, enum plan plan,
                       int requested_status, int owner_fd, int command, int evidence)
{
    int launch[2], permission[2], completion[2];
    pipe_pair(launch);
    pipe_pair(permission);
    pipe_pair(completion);
    int self = pidfd_for(getpid());
    pid_t watchdog_pid = fork();
    need(watchdog_pid >= 0, "fork independent clone authority");
    if (watchdog_pid == 0) {
        close(command);
        close(launch[1]);
        close(permission[1]);
        close(completion[0]);
        watchdog(binary, leaf, gate, plan, requested_status, self, owner_fd,
                 launch[0], permission[0], completion[1], evidence);
    }
    close(self);
    close(owner_fd);
    close(evidence);
    close(launch[0]);
    close(permission[0]);
    close(completion[1]);
    struct held watcher = {.pid = watchdog_pid, .fd = pidfd_for(watchdog_pid)};
    char byte;
    take_bytes(command, &byte, 1);
    need(byte == 'L', "controller launch request");
    ssize_t count = write(launch[1], "L", 1);
    int error = count < 0 ? errno : 0;
    printf("supervisor-launch-request result=%ld errno=%d gate=%d\n",
           (long)count, error, atomic_load_explicit(gate, memory_order_acquire));
    close(launch[1]);
    if (plan == OWNER_BEFORE || plan == DEADLINE_BEFORE) {
        need(count < 0 && error == EPIPE && atomic_load(gate) == CANCELLED,
             "launch request accepted after empty-leaf cancellation");
    } else if (count == 1) {
        take_bytes(command, &byte, 1);
        need(byte == 'G', "controller permit request");
        int phase = READY;
        int granted = atomic_compare_exchange_strong_explicit(gate, &phase, RELEASED,
                                                               memory_order_acq_rel,
                                                               memory_order_acquire);
        printf("supervisor-exec-commit granted=%d prior_gate=%d\n", granted, phase);
        if (granted)
            emit_bytes(permission[1], "G", 1);
    }
    close(command);
    close(permission[1]);
    struct note result;
    count = read(completion[0], &result, sizeof(result));
    close(completion[0]);
    if (count != (ssize_t)sizeof(result)) {
        atomic_exchange(gate, CANCELLED);
        need(cg_put("supervisor-watchdog-loss-fallback", leaf, "cgroup.kill", "1") == 0,
             "supervisor watchdog-loss cleanup");
        drain(leaf);
        _exit(125);
    }
    held_status(watcher, "supervisor-reaped-watchdog", 0);
    _exit(result.supervisor_status);
}

static void run_case(const char *binary, const char *root, const char *name,
                     enum plan plan, int requested_status, int sibling_fd)
{
    char leaf[MAX_PATH];
    join(leaf, root, name);
    need(mkdir(leaf, 0755) == 0, "create exact case leaf");
    root_owned(leaf, 1);
    atomic_int *gate = mmap(NULL, sizeof(*gate), PROT_READ | PROT_WRITE,
                           MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    need(gate != MAP_FAILED, "shared one-shot cancellation gate");
    atomic_init(gate, PENDING);
    pid_t owner_pid = fork();
    need(owner_pid >= 0, "fork held synthetic owner");
    if (owner_pid == 0) {
        close(sibling_fd);
        for (;;) pause();
    }
    struct held owner = {.pid = owner_pid, .fd = pidfd_for(owner_pid)};
    int command[2], evidence[2];
    pipe_pair(command);
    pipe_pair(evidence);
    pid_t supervisor_pid = fork();
    need(supervisor_pid >= 0, "fork supervisor");
    if (supervisor_pid == 0) {
        close(command[1]);
        close(evidence[0]);
        close(sibling_fd);
        supervisor(binary, leaf, gate, plan, requested_status, owner.fd, command[0], evidence[1]);
    }
    close(command[0]);
    close(evidence[1]);
    struct held guard = {.pid = supervisor_pid, .fd = pidfd_for(supervisor_pid)};
    struct note note;
    take_bytes(evidence[0], &note, sizeof(note));
    need(note.stage == ARMED && note.watcher > 0, "watchdog arm receipt");
    struct held watcher = {.pid = note.watcher, .fd = pidfd_for(note.watcher)};
    still_held(watcher.fd);
    still_held(guard.fd);
    still_held(owner.fd);
    if (plan == OWNER_BEFORE || plan == DEADLINE_BEFORE) {
        if (plan == OWNER_BEFORE) send_kill(owner.fd);
        take_bytes(evidence[0], &note, sizeof(note));
        need(note.stage == DONE && note.watcher == watcher.pid && note.clone_attempts == 0 &&
             note.payload == 0 && note.exec_markers == 0 && atomic_load(gate) == CANCELLED &&
             note.trigger == (plan == OWNER_BEFORE ? OWNER_LOST : DEADLINE),
             "empty-leaf cancellation");
        no_processes(leaf);
        emit_bytes(command[1], "L", 1);
        held_status(guard, "controller-reaped-late-launch-supervisor",
                    plan == OWNER_BEFORE ? 125 : 124);
        close(watcher.fd);
    } else {
        emit_bytes(command[1], "L", 1);
        take_bytes(evidence[0], &note, sizeof(note));
        need(note.stage == PLACED && note.watcher == watcher.pid && note.clone_attempts == 1 &&
             note.payload > 0 && atomic_load(gate) == READY, "placed but uncommitted child");
        struct held child = {.pid = note.payload, .fd = pidfd_for(note.payload)};
        still_held(child.fd);
        member("controller-verified-held-before-exec", child.pid, leaf + strlen(MOUNT));
        if (plan == SUPERVISOR_BETWEEN) {
            send_kill(guard.fd);
        } else {
            emit_bytes(command[1], "G", 1);
        }
        take_bytes(evidence[0], &note, sizeof(note));
        need(note.stage == DONE && note.watcher == watcher.pid && note.payload == child.pid &&
             note.clone_attempts == 1, "completed exact held child");
        if (plan == SUPERVISOR_BETWEEN) {
            need(note.trigger == SUPERVISOR_LOST && note.exec_markers == 0 &&
                 (note.payload_status == 125 || note.payload_status == 128 + SIGKILL) &&
                 atomic_load(gate) == CANCELLED, "supervisor loss before permit");
            held_status(guard, "controller-reaped-killed-supervisor", 128 + SIGKILL);
            held_status(watcher, "controller-reaped-orphan-watchdog", 0);
        } else {
            need(note.trigger == NORMAL && note.exec_markers == 1 &&
                 note.payload_status == requested_status && atomic_load(gate) == FINISHED,
                 "forward real payload exit status");
            held_status(guard, "controller-reaped-normal-supervisor", requested_status);
            close(watcher.fd);
        }
        struct pollfd original = {.fd = child.fd, .events = POLLIN};
        need(poll(&original, 1, 0) == 1 && (original.revents & POLLIN),
             "original held payload alive after drain");
        close(child.fd);
    }
    close(command[1]);
    close(evidence[0]);
    if (plan != OWNER_BEFORE) send_kill(owner.fd);
    held_status(owner, "controller-reaped-exact-owner", 128 + SIGKILL);
    still_held(sibling_fd);
    no_processes(leaf);
    printf("fence-case case=%s pass=1 clone_attempts=%d exec_markers=%d payload_status=%d "
           "supervisor_status=%d sibling_alive=1\n",
           name, note.clone_attempts, note.exec_markers, note.payload_status, note.supervisor_status);
    munmap(gate, sizeof(*gate));
}
static struct held start_sibling(const char *leaf)
{
    int ready[2];
    pipe_pair(ready);
    pid_t pid = fork();
    need(pid >= 0, "fork unrelated sibling canary");
    if (pid == 0) {
        close(ready[0]);
        need(cg_put("place-only-dedicated-canary", leaf, "cgroup.procs", "0") == 0, "place sibling");
        member("independent-canary-membership", getpid(), leaf + strlen(MOUNT));
        emit_bytes(ready[1], "R", 1);
        close(ready[1]);
        for (;;) pause();
    }
    close(ready[1]);
    struct held child = {.pid = pid, .fd = pidfd_for(pid)};
    char byte;
    take_bytes(ready[0], &byte, 1);
    close(ready[0]);
    need(byte == 'R', "unrelated sibling ready");
    still_held(child.fd);
    return child;
}


int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    if (argc == 3 && strcmp(argv[1], "--payload") == 0) {
        verify_ids("actual-exec-identity");
        char userns[128];
        read_ns("/proc/self/ns/user", userns);
        printf("actual-exec-user-namespace=%s\n", userns);
        need(fcntl(4, F_GETFD) < 0 && errno == EBADF, "no inherited startup authority");
        emit_bytes(3, "X", 1);
        close(3);
        return atoi(argv[2]);
    }
    need(argc == 2 && geteuid() == 0 && getegid() == 0, "dedicated root scope");
    const char *prefix = "ptg-linux-startup-fence-";
    size_t n = strlen(argv[1]);
    need(n > strlen(prefix) + 6 && n < 100 &&
         strncmp(argv[1], prefix, strlen(prefix)) == 0 &&
         strcmp(argv[1] + n - 6, ".scope") == 0 &&
         strspn(argv[1], "abcdefghijklmnopqrstuvwxyz0123456789.-") == n, "dedicated scope ID");
    char suffix[MAX_PATH], root[MAX_PATH], binary[MAX_PATH], expected[MAX_PATH], path[MAX_PATH];
    snprintf(suffix, sizeof(suffix), "%s%s", SCOPE_PREFIX, argv[1]);
    snprintf(root, sizeof(root), "%s%s%s", MOUNT, SCOPE_PREFIX, argv[1]);
    snprintf(expected, sizeof(expected), "/tmp/%.*s/proof", (int)n - 6, argv[1]);
    ssize_t len = readlink("/proc/self/exe", binary, sizeof(binary) - 1);
    need(len > 0 && (size_t)len < sizeof(binary) - 1, "read proof executable");
    binary[len] = '\0';
    need(strcmp(binary, expected) == 0, "exact trusted proof executable");
    member("verify-root-scope", getpid(), suffix);
    root_owned(root, 1);
    root_owned(binary, 0);
    struct statfs fs;
    need(statfs(root, &fs) == 0 && fs.f_type == CGROUP2_SUPER_MAGIC, "scope cgroup2");
    join(path, root, "cgroup.stat");
    char state[128];
    read_text(path, state, sizeof(state));
    need(strncmp(state, "nr_descendants 0\n", 17) == 0, "scope already has cgroups");
    need(prctl(PR_SET_CHILD_SUBREAPER, 1L, 0L, 0L, 0L) == 0, "controller subreaper");
    need(signal(SIGPIPE, SIG_IGN) != SIG_ERR, "observe closed pipes as EPIPE");
    umask(022);
    char sibling[MAX_PATH];
    join(sibling, root, "sibling");
    need(mkdir(sibling, 0755) == 0, "create independent sibling");
    root_owned(sibling, 1);
    struct held canary = start_sibling(sibling);
    run_case(binary, root, "owner-before", OWNER_BEFORE, 7, canary.fd);
    run_case(binary, root, "deadline-before", DEADLINE_BEFORE, 7, canary.fd);
    run_case(binary, root, "supervisor-between", SUPERVISOR_BETWEEN, 7, canary.fd);
    run_case(binary, root, "normal-7", NORMAL_EXEC, 7, canary.fd);
    run_case(binary, root, "normal-197", NORMAL_EXEC, 197, canary.fd);
    need(cg_put("cleanup-independent-sibling", sibling, "cgroup.kill", "1") == 0, "kill only sibling");
    held_status(canary, "reaped-independent-sibling", 128 + SIGKILL);
    no_processes(sibling);
    printf("startup-fence-proof=passed\n");
    return 0;
}
