# Linux013 object qualification

The one exact reviewed ordinary attempt passed: new installed-header terminal C bridge object and both normal/test Rust objects compiled with warnings denied on Linux ARM64. Six native compiler/version/dependency steps exited0 and stderr was empty.125 C dependencies matched before/after; actual compiler/source pins were checked before and after compilation. Objects are preserved unchanged.

This is compiler acceptance of the actual consuming controller graph and ownership API. It is not linking, ABI reporter execution, any test execution, waitid, context setup, child launch, guard-domain cgroup operation or terminal-controller runtime qualification. The copied historical fixtures are only compiled. No product backend was enabled. METHOD.md retains the full armer/entry/partial-arm settlement and runtime limitations.

The original held kill precedes fresh clocks/allocation/path validation; the original execution lease stays immutable. Separate cleanup is prearmed before any future child, may only narrow, and remains owned on errors. Drained controls stay held through exact direct/adopted reaping; removal is last. The first active poll EINTR conservatively cancels rather than introducing unbounded retries. These are reviewed source/typed control flow, not exercised native behavior in013.

49 exact artifacts were downloaded and hashed. Before removal, a verified122-member pre-removal ZIP was created (SHA370b47543e33c7cee74931dbae49eaa84b572632bd6feca2c77c423ced4f7f2c). Then the exact UID5010700 scratch dev64769/inode1111923 was removed through held no-follow descriptors after identity/hash checks. The original user scope/cgroup and all seven recorded compiler/controller PIDs were independently absent before and at removal. No process-name search or privileged cleanup was used. Raw queries and receipts are retained.

Unexecuted source drafts, the initial template-tail assembly error and both compile preparations remain preserved. The source candidate's review_pending field is historical frozen preparation metadata; REVIEW.json records later exact approvals without rewriting that source freeze. No rerun occurred.
