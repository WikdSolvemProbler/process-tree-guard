// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

use super::*;

const CLONE_PIDFD: u64 = 0x0000_1000;
const CLONE_INTO_CGROUP: u64 = 0x2_0000_0000;
const SIGCHLD: u64 = 17;

// Linux v5.14 include/uapi/linux/sched.h, CLONE_ARGS_SIZE_VER2.
#[repr(C, align(8))]
#[derive(Default)]
struct CloneArgs {
    flags: u64,
    pidfd: u64,
    child_tid: u64,
    parent_tid: u64,
    exit_signal: u64,
    stack: u64,
    stack_size: u64,
    tls: u64,
    set_tid: u64,
    set_tid_size: u64,
    cgroup: u64,
}

const _: () = {
    assert!(std::mem::size_of::<CloneArgs>() == 88);
    assert!(std::mem::align_of::<CloneArgs>() == 8);
    assert!(std::mem::offset_of!(CloneArgs, cgroup) == 80);
};

struct LeaseWatch<'a> {
    owner_pid: c_int,
    owner: &'a OwnedFd,
    timer: &'a OwnedFd,
    deadline_ns: u64,
    supervisor: &'a OwnedFd,
}

impl<'a> LeaseWatch<'a> {
    fn original(prepared: &'a PreparedRun, supervisor: &'a terminal_controller::DedicatedSupervisor) -> Self {
        Self {
            owner_pid: prepared.owner_pid,
            owner: &prepared.lease.owner,
            timer: &prepared.lease.timer,
            deadline_ns: prepared.lease.deadline_ns,
            supervisor: supervisor.self_pidfd(),
        }
    }
}

// The trusted provisioner supplies these from one verified fresh cgroup2
// domain. These are owned descriptors, never paths from the request.
struct DomainControls {
    directory: OwnedFd,
    watchdog_kill: OwnedFd,
    supervisor_kill: OwnedFd,
    events: OwnedFd,
    provenance: cgroup_authority::LeafProvenance,
}

struct ArmedDomain {
    controls: DomainControls,
    watchdog: DirectChild,
}

// These variants retain the actual factory/domain authorities. They describe
// the trusted port's obligations; there is no native arming implementation yet.
enum ArmFailure {
    // Contract: no domain, watchdog or payload resource has been created.
    BeforeProvision { error: String },
    // Retains the factory's actual optional CreatedLeaf after a partial mkdir.
    Provision(cgroup_authority::ProvisionFailure),
    // A watchdog may be created only after verified controls exist. If one
    // exists, its direct-child ownership must be returned even on readiness error.
    VerifiedDomain {
        controls: DomainControls,
        watchdog: Option<DirectChild>,
        error: String,
    },
}

struct ChildPlan<'a> {
    directory: &'a OwnedFd,
    identity: &'a VerifiedIdentity,
    exec: &'a request::ExecPlan,
}

impl ChildPlan<'_> {
    // The PID output address is valid only during the synchronous callback.
    // Only a successful native clone call may yield a new owned descriptor.
    fn with_clone_args<T>(&self, call: impl FnOnce(&CloneArgs) -> T) -> (T, c_int) {
        let mut pidfd = -1;
        let args = CloneArgs {
            flags: CLONE_INTO_CGROUP | CLONE_PIDFD,
            pidfd: ptr::addr_of_mut!(pidfd) as u64,
            exit_signal: SIGCHLD,
            cgroup: self.directory.as_raw_fd() as u64,
            ..CloneArgs::default()
        };
        (call(&args), pidfd)
    }
}

struct DirectChild {
    pid: c_int,
    pidfd: OwnedFd,
}

impl DirectChild {
    /// # Safety
    /// The trusted native port must supply the positive PID and newly owned
    /// pidfd from the same successful direct-child clone, with exclusive wait
    /// ownership. No caller-supplied PID/descriptor may enter this constructor.
    /// This record must remain owned until exact reaping; dropping it does not
    /// terminate or reap the child. The native clone path is not implemented here.
    unsafe fn from_successful_clone(pid: c_int, pidfd: OwnedFd) -> Self {
        Self { pid, pidfd }
    }
}

struct PlacedChild {
    identity: DirectChild,
    ready_permit: Probe<OwnedFd>,
    // The same child's trusted CLOEXEC writer reports a fixed exec-error frame.
    // Reader remains owned even when readiness/permit fails. EOF alone is not
    // proof that the permit completed execution.
    exec_report: terminal_controller::ExecReport,
}

struct PayloadChild {
    identity: DirectChild,
    exec_report: terminal_controller::ExecReport,
}

// No native implementation is supplied by this compile-only adapter.
// The port is inside the privileged trust boundary. It is not request input.
trait OneShotPort {
    // Apply the command policy to the original decoded plan before arming.
    // This check must create no domain or child resources.
    // The first native proof may authorize only the pinned absolute fixture.
    fn authorize(&mut self, identity: &VerifiedIdentity, exec: &request::ExecPlan) -> Probe<()>;

    // Arm the proof's watchdog with the original owner and timer, and return
    // only once both watchdog and independent supervisor kill paths own access
    // to the same verified domain. No payload may exist during arm. Every Err
    // retains any actual CreatedLeaf/controls and direct watchdog child. A bare
    // BeforeProvision relies on its no-resource contract; Provision retains
    // the factory's exact result, including whether a leaf was created.
    fn arm(
        &mut self,
        watch: LeaseWatch<'_>,
    ) -> std::result::Result<ArmedDomain, ArmFailure>;

    // Place atomically and retain the kernel-returned pidfd. An outer Err
    // means no clone succeeded. After a clone, return the exact child even
    // when readiness fails. A ready permit certifies trusted child readiness,
    // FD scrubbing and credential drop. A readiness error closes the writer.
    fn place_held(&mut self, domain: &ArmedDomain, child: ChildPlan<'_>) -> Probe<PlacedChild>;

    // Use the proof's held-to-released shared gate and its single permit byte.
    // An independent cancellation can win at either side of this observation.
    // Do not duplicate or retain the borrowed permit writer.
    fn commit_permit(
        &mut self,
        domain: &ArmedDomain,
        child: &DirectChild,
        permit_writer: &OwnedFd,
    ) -> Probe<()>;
}

struct ActiveRun {
    prepared: PreparedRun,
    domain: ArmedDomain,
    child: Option<PayloadChild>,
    cleanup: cgroup_authority::settlement::Deadline,
    supervisor: terminal_controller::DedicatedSupervisor,
}

impl ActiveRun {
    fn place_and_sample_release(&mut self, port: &mut impl OneShotPort) -> Probe<Decision> {
        self.domain.controls.revalidate()?;
        let decision = self.prepared.lease.sample()?.decision;
        if decision != Decision::Permit {
            return Ok(decision);
        }

        let PlacedChild {
            identity,
            ready_permit,
            exec_report,
        } = port.place_held(
            &self.domain,
            ChildPlan {
                directory: &self.domain.controls.directory,
                identity: &self.prepared.identity,
                exec: &self.prepared.plan,
            },
        )?;
        let child = self.child.insert(PayloadChild { identity, exec_report });
        let permit_writer = ready_permit?;

        // The original timer and owner remain live in the watchdog while the
        // supervisor samples them again at the last release boundary.
        let decision = self.prepared.lease.sample()?.decision;
        if decision == Decision::Permit {
            self.domain.controls.revalidate()?;
            port.commit_permit(&self.domain, &child.identity, &permit_writer)?;
        }
        drop(permit_writer);
        Ok(decision)
    }
}

#[must_use = "an armed activation requires watchdog settlement or supervisor fallback"]
struct PendingSettlement {
    active: ActiveRun,
    // Permit records gate release only. Exec and terminal outcome are independent.
    release: Probe<Decision>,
}

// The original request/identity/owner/timer remain owned on returned activation
// errors. Do not Debug/Display this value: it contains caller argv and identity.
// There is no automatic Drop settlement or claim of complete native custody.
enum ActivationFailure {
    BeforeArm {
        prepared: PreparedRun,
        supervisor: Option<terminal_controller::DedicatedSupervisor>,
        cleanup: Option<cgroup_authority::settlement::Deadline>,
        context_error: Option<terminal_controller::ContextFailure>,
        error: String,
    },
    Arming {
        prepared: PreparedRun,
        supervisor: terminal_controller::DedicatedSupervisor,
        cleanup: cgroup_authority::settlement::Deadline,
        failure: ArmFailure,
    },
}

/// # Safety
/// Caller is the dedicated one-shot supervisor entry point. No foreign child,
/// concurrent clone/waiter or thread may be introduced for its entire lifetime.
/// The trusted port may create only the returned watchdog/payload children.
/// This adapter remains unconnected to the product entry point.
unsafe fn activate(
    prepared: PreparedRun,
    port: &mut impl OneShotPort,
) -> std::result::Result<PendingSettlement, ActivationFailure> {
    let before_arm = (|| -> Probe<()> {
        port.authorize(&prepared.identity, &prepared.plan)?;
        check(
            prepared.lease.sample()?.decision == Decision::Permit,
            "owner or deadline inactive before cgroup arming",
        )
    })();
    if let Err(error) = before_arm {
        return Err(ActivationFailure::BeforeArm {
            prepared, supervisor: None, cleanup: None, context_error: None, error,
        });
    }
    let supervisor = match unsafe { terminal_controller::DedicatedSupervisor::establish() } {
        Ok(value) => value,
        Err(failure) => return Err(ActivationFailure::BeforeArm {
            prepared, supervisor: None, cleanup: None, context_error: Some(failure),
            error: "dedicated supervisor setup refused".into(),
        }),
    };
    let cleanup_until = match prepared.lease.deadline_ns.checked_add(terminal_controller::CLEANUP_GRACE_NS) {
        Some(value) => value,
        None => return Err(ActivationFailure::BeforeArm {
            prepared, supervisor: Some(supervisor), cleanup: None, context_error: None,
            error: "cleanup hard cutoff overflow".into(),
        }),
    };
    let cleanup = match cgroup_authority::settlement::Deadline::arm_before_placement(cleanup_until) {
        Ok(value) => value,
        Err(error) => return Err(ActivationFailure::BeforeArm {
            prepared, supervisor: Some(supervisor), cleanup: None, context_error: None, error,
        }),
    };
    let final_before_arm = (|| -> Probe<()> {
        cleanup.check()?;
        check(prepared.lease.sample()?.decision == Decision::Permit,
              "original owner/deadline inactive before native arming")
    })();
    if let Err(error) = final_before_arm {
        return Err(ActivationFailure::BeforeArm {
            prepared, supervisor: Some(supervisor), cleanup: Some(cleanup), context_error: None, error,
        });
    }
    // Original execution owner/timer/deadline are never retargeted. The cleanup
    // timer exists before arm can create a watchdog or place any payload.
    let domain = match port.arm(LeaseWatch::original(&prepared, &supervisor)) {
        Ok(domain) => domain,
        Err(failure) => return Err(ActivationFailure::Arming {
            prepared, supervisor, cleanup, failure,
        }),
    };
    let mut active = ActiveRun {
        prepared,
        domain,
        child: None,
        cleanup,
        supervisor,
    };
    let release = active.place_and_sample_release(port);
    // Even a placement, observation or permit error retains the original
    // lease and armed authorities for bounded drain and reap by the caller.
    Ok(PendingSettlement { active, release })
}

#[cfg(test)]
mod metadata_check {
    use super::*;

    struct RefusingPort;

    impl OneShotPort for RefusingPort {
        fn authorize(
            &mut self,
            _identity: &VerifiedIdentity,
            _exec: &request::ExecPlan,
        ) -> Probe<()> {
            Err("metadata-only port never authorizes".into())
        }

        fn arm(
            &mut self,
            watch: LeaseWatch<'_>,
        ) -> std::result::Result<ArmedDomain, ArmFailure> {
            let _ = (
                watch.owner_pid,
                watch.owner.as_raw_fd(),
                watch.timer.as_raw_fd(),
                watch.deadline_ns,
                watch.supervisor.as_raw_fd(),
            );
            Err(ArmFailure::BeforeProvision {
                error: "metadata-only port never arms".into(),
            })
        }

        fn place_held(&mut self, domain: &ArmedDomain, child: ChildPlan<'_>) -> Probe<PlacedChild> {
            let _ = (
                domain.controls.watchdog_kill.as_raw_fd(),
                domain.controls.supervisor_kill.as_raw_fd(),
                domain.controls.events.as_raw_fd(),
                domain.watchdog.pid,
                domain.watchdog.pidfd.as_raw_fd(),
                child.identity.uid,
                child.identity.gid,
                child.identity.groups.as_slice(),
                child.exec.program(),
                child.exec.argv(),
            );
            let _ = child.with_clone_args(|args| (args.flags, args.cgroup, args.pidfd));
            Err("metadata-only port never places".into())
        }

        fn commit_permit(
            &mut self,
            _domain: &ArmedDomain,
            child: &DirectChild,
            permit_writer: &OwnedFd,
        ) -> Probe<()> {
            let _ = (
                child.pid,
                child.pidfd.as_raw_fd(),
                permit_writer.as_raw_fd(),
            );
            Err("metadata-only port never releases".into())
        }
    }

    #[test]
    fn exact_adapter_signature() {
        let _: unsafe fn(PreparedRun, &mut RefusingPort)
            -> std::result::Result<PendingSettlement, ActivationFailure> = activate;
        let _: unsafe fn(c_int, OwnedFd) -> DirectChild = DirectChild::from_successful_clone;
        let _: fn(cgroup_authority::ProvisionFailure) -> ArmFailure = ArmFailure::Provision;
        let _: fn(PendingSettlement) -> (ActiveRun, Probe<Decision>) =
            |value| (value.active, value.release);
    }
}

#[path = "cgroup_authority.rs"]
mod cgroup_authority;

#[path = "child_reaper.rs"]
mod child_reaper;

#[path = "terminal_controller.rs"]
mod terminal_controller;
