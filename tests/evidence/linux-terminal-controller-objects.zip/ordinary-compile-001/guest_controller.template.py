"""Ordinary full-graph/C object compilation only; never controller/reaper/test execution."""
import base64
import hashlib
import json
import os
import re
from pathlib import Path
import selectors
import shlex
import stat
import subprocess
import sys
import tempfile

EXPECTED = @EXPECTED_JSON@
PAYLOAD_SHA256 = "@PAYLOAD_SHA256@"
UNIT = "ptg-terminal-controller-013.scope"
CONTROL_GROUP = "/user.slice/user-501.slice/user@501.service/app.slice/" + UNIT
COMPILER = "/home/petershiller1.guest/.rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu/bin/rustc"
COMPILER_SHA256 = "b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f"
C_COMPILER = "/usr/bin/gcc"
C_COMPILER_SHA256 = "a20520ee21543f243d40636a9181a142c45ecd989de31ab86b99a8ea5ada870d"

def demand(value, text):
    if not value:
        raise RuntimeError(text)

def write_all(fd, data):
    while data:
        n = os.write(fd, data)
        demand(n > 0, "short retained stream write")
        data = data[n:]

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for part in iter(lambda: f.read(65536), b""):
            h.update(part)
    return h.hexdigest()

def retained_inventory(root):
    rows = {}
    for path in sorted(root.rglob("*")):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            demand(info.st_uid == 501, "unexpected non-owned artifact directory")
            continue
        demand(stat.S_ISREG(info.st_mode) and info.st_uid == 501 and info.st_nlink == 1
               and info.st_size <= 32 * 1024 * 1024, "unexpected retained artifact type/size")
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            before = os.fstat(fd)
            value = hashlib.sha256()
            count = 0
            while count <= 32 * 1024 * 1024:
                part = os.read(fd, 65536)
                if not part: break
                count += len(part)
                value.update(part)
            after = os.fstat(fd)
            demand((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                   == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                   and [before.st_dev, before.st_ino] == [info.st_dev, info.st_ino] and count == info.st_size,
                   "retained artifact changed during snapshot")
            rows[str(path.relative_to(root))] = {"bytes": count, "sha256": value.hexdigest(),
                                                "device": before.st_dev, "inode": before.st_ino}
        finally:
            os.close(fd)
    return rows

tree = None
try:
    os.umask(0o077)
    demand(os.getuid() == 501 and os.geteuid() == 501, "ordinary UID501 required")
    demand(os.getgid() != 0 and os.getegid() != 0, "root group refused")
    demand(os.uname().machine == "aarch64", "ARM64 qualification only")
    scope = Path("/proc/self/cgroup").read_text().strip()
    demand(scope == "0::" + CONTROL_GROUP, "unexpected actual user scope")
    prop = subprocess.run(["/usr/bin/systemctl", "--user", "show", UNIT,
                           "-p", "RuntimeMaxUSec", "-p", "KillMode", "-p", "KillSignal",
                           "-p", "SendSIGKILL", "-p", "ControlGroup", "-p", "ActiveState"],
                          capture_output=True, text=True, timeout=3)
    print("SCOPE_PROPERTIES=" + json.dumps({"stdout": prop.stdout, "stderr": prop.stderr,
          "exit": prop.returncode, "actual_cgroup": scope}), flush=True)
    demand(prop.returncode == 0, "effective scope query refused")
    properties = dict(line.split("=", 1) for line in prop.stdout.splitlines())
    for key, value in {"RuntimeMaxUSec": "1min 10s", "KillMode": "control-group", "KillSignal": "9",
                       "SendSIGKILL": "yes", "ControlGroup": CONTROL_GROUP, "ActiveState": "active"}.items():
        demand(properties.get(key) == value, "effective finite scope property differs: " + key)
    packet = sys.stdin.buffer.read(1024 * 1024 + 1)
    demand(len(packet) <= 1024 * 1024 and hashlib.sha256(packet).hexdigest() == PAYLOAD_SHA256,
           "exact source payload differs")
    entries = json.loads(packet)["files"]
    demand(set(entries) == set(EXPECTED), "source member set differs")
    tree = Path(tempfile.mkdtemp(prefix="ptg-terminal-controller-013.", dir="/tmp"))
    held = tree.stat()
    demand(held.st_uid == 501 and stat.S_IMODE(held.st_mode) == 0o700, "scratch custody differs")
    print("ORDINARY_SCRATCH=" + json.dumps({"path": str(tree), "device": held.st_dev,
          "inode": held.st_ino, "uid": held.st_uid, "mode": stat.S_IMODE(held.st_mode),
          "controller_pid": os.getpid()}), flush=True)
    for name, pin in EXPECTED.items():
        data = base64.b64decode(entries[name], validate=True)
        demand(len(data) == pin["bytes"] and hashlib.sha256(data).hexdigest() == pin["sha256"],
               "source bytes differ: " + name)
        path = tree / name
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with path.open("xb") as f:
            f.write(data)
        demand(digest(path) == pin["sha256"], "staged source differs: " + name)
    os.environ["TMPDIR"] = str(tree)
    os.chdir(tree)
    tool_env = dict(os.environ)
    removed_environment = {}
    for key in ("CPATH", "C_INCLUDE_PATH", "CPLUS_INCLUDE_PATH", "OBJC_INCLUDE_PATH",
                "GCC_EXEC_PREFIX", "COMPILER_PATH", "LIBRARY_PATH", "GCC_SPECS",
                "LD_PRELOAD", "LD_LIBRARY_PATH", "LD_AUDIT", "LD_DEBUG",
                "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "RUSTFLAGS", "RUSTC_LOG",
                "CFLAGS", "CPPFLAGS", "LDFLAGS", "RUST_TEST_THREADS", "RUST_TEST_NOCAPTURE",
                "RUST_TEST_SHUFFLE", "RUST_TEST_SHUFFLE_SEED", "RUST_TEST_TIME_TESTS",
                "RUST_TEST_ENSURE_TIME", "RUST_TEST_TIME_UNIT"):
        if key in tool_env:
            removed_environment[key] = hashlib.sha256(tool_env.pop(key).encode("utf-8", "surrogateescape")).hexdigest()
    tool_env.update(PATH="/usr/bin:/bin", TMPDIR=str(tree), LC_ALL="C", LANG="C", TZ="UTC")
    print("TOOL_ENVIRONMENT=" + json.dumps({"removed_value_sha256": removed_environment,
          "PATH": tool_env["PATH"], "LC_ALL": tool_env["LC_ALL"], "TMPDIR": str(tree),
          "scope": "compiler subprocesses only; no prototype/test/reporter execution or host setting change"}), flush=True)

    def command(argv, tag, *, binary_stdout=False):
        print("NATIVE_ARGV=" + json.dumps({"tag": tag, "argv": argv}), flush=True)
        out_path = tree / (tag + (".stdout.bin" if binary_stdout else ".stdout.log"))
        err_path = tree / (tag + ".stderr.log")
        with out_path.open("xb") as out, err_path.open("xb") as err:
            child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, close_fds=True, env=tool_env)
            print("NATIVE_CHILD=" + json.dumps({"tag": tag, "pid": child.pid}), flush=True)
            with selectors.DefaultSelector() as selector:
                selector.register(child.stdout, selectors.EVENT_READ, (out, 1))
                selector.register(child.stderr, selectors.EVENT_READ, (err, 2))
                while selector.get_map():
                    for key, events in selector.select(timeout=0.1):
                        data = os.read(key.fileobj.fileno(), 4096)
                        if not data:
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                            continue
                        retained, transport = key.data
                        retained.write(data)
                        retained.flush()
                        if transport != 1 or not binary_stdout:
                            write_all(transport, data)
            code = child.wait()
        (tree / (tag + ".exit.txt")).write_text(str(code))
        print("NATIVE_EXIT=" + json.dumps({"tag": tag, "pid": child.pid, "exit": code,
              "stdout_sha256": digest(out_path), "stderr_sha256": digest(err_path)}), flush=True)
        demand(code == 0, "native step failed: " + tag)
        return out_path

    source_paths = {(tree / name).resolve(): pin for name, pin in EXPECTED.items()}
    installed_roots = [Path("/usr/include"), Path("/usr/lib/gcc"), Path("/usr/local/include")]

    def dependencies(path):
        text = path.read_text().replace("\\\n", " ")
        target, separator, tail = text.partition(":")
        demand(bool(separator) and bool(target.strip()), "invalid compiler dependency file")
        names = shlex.split(tail)
        demand(bool(names), "empty compiler dependency list")
        return {Path(name).resolve(strict=True) for name in names}

    def header_snapshot(paths):
        rows = {}
        for path in sorted(paths):
            before = path.stat()
            demand(stat.S_ISREG(before.st_mode), "compiler dependency is not regular")
            value = digest(path)
            after = path.stat()
            demand((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                   == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
                   "compiler dependency changed during hashing")
            if path in source_paths:
                pin = source_paths[path]
                demand(before.st_uid == 501 and before.st_size == pin["bytes"] and value == pin["sha256"],
                       "private compiler input differs")
                role = "pinned_source"
            else:
                demand(any(path.is_relative_to(root) for root in installed_roots)
                       and before.st_uid == 0 and before.st_mode & 0o022 == 0,
                       "compiler dependency is outside reviewed installed-header roots")
                role = "installed_header"
            rows[str(path)] = {"role": role, "bytes": before.st_size, "sha256": value,
                               "device": before.st_dev, "inode": before.st_ino,
                               "mtime_ns": before.st_mtime_ns, "ctime_ns": before.st_ctime_ns,
                               "uid": before.st_uid, "mode": stat.S_IMODE(before.st_mode)}
        return rows

    cflags = ["-std=c17", "-Wall", "-Wextra", "-Werror", "-O2", "-fno-common", "-fstack-protector-strong", "-D_FORTIFY_SOURCE=2", "-fPIE"]
    source_directory = "target/codex-security/issue2-linux-terminal-controller-013/"
    header_manifest = {}

    def compile_c(name, output, tag):
        source = source_directory + name
        pre = tree / (tag + ".pre.d")
        post = tree / (tag + ".d")
        command([C_COMPILER, *cflags, "-M", "-MF", str(pre), source], tag + "-dependencies")
        before_paths = dependencies(pre)
        before = header_snapshot(before_paths)
        command([C_COMPILER, *cflags, "-MD", "-MF", str(post), "-c", source, "-o", output], tag + "-compile")
        after_paths = dependencies(post)
        after = header_snapshot(after_paths)
        demand(before_paths == after_paths and before == after, "C header provenance changed across compilation")
        header_manifest[tag] = {"before": before, "after": after, "match": True}
        (tree / "header-provenance.json").write_text(json.dumps(header_manifest, indent=2) + "\n")
        print("C_HEADER_PROVENANCE=" + json.dumps({"tag": tag, "dependencies": len(before),
              "sha256": digest(tree / "header-provenance.json"), "before_after_match": True}), flush=True)

    demand(digest(Path(COMPILER)) == COMPILER_SHA256, "pinned native compiler differs")
    demand(digest(Path(C_COMPILER)) == C_COMPILER_SHA256, "pinned native C compiler differs")
    print("NATIVE_CONTEXT=" + json.dumps({"pid": os.getpid(), "uid": os.getuid(),
          "uname": list(os.uname()), "compiler": COMPILER, "compiler_sha256": digest(Path(COMPILER)),
          "gcc_sha256": digest(Path(C_COMPILER)), "payload_executions": 0,
          "root_fixture_executions": 0, "cgroup_writes": 0, "prototype_executions": 0}), flush=True)
    command([COMPILER, "--version", "--verbose"], "compiler-version")
    command([C_COMPILER, "--version"], "c-compiler-version")
    compile_c("terminal_bridge.c", "terminal-bridge.o", "terminal-bridge")
    for testing, output_name in ((False, "activation-main.o"), (True, "activation-tests.o")):
        args = [COMPILER, "--edition=2021", "-D", "warnings", "--emit=obj"]
        if testing:
            args.append("--test")
        args.extend([source_directory + "transport.rs", "-o", output_name])
        command(args, "compile-test-object" if testing else "compile-main-object")
        print("NATIVE_OBJECT=" + json.dumps({"path": str(tree / output_name),
              "test_object": testing, "sha256": digest(tree / output_name)}), flush=True)
    demand(digest(Path(COMPILER)) == COMPILER_SHA256 and digest(Path(C_COMPILER)) == C_COMPILER_SHA256,
           "compiler changed across object generation")
    for name, pin in EXPECTED.items():
        demand(digest(tree / name) == pin["sha256"], "source changed during object compilation: " + name)
    inventory = retained_inventory(tree)
    (tree / "ordinary-inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
    print("ORDINARY_COMPONENT_COMPLETE=" + json.dumps({"object_builds_passed": 2,
          "c_objects_passed": 1, "prototype_executions": 0, "fixture_children": 0,
          "selected_fixture_tests": 0, "abi_reporter_executions": 0,
          "header_provenance_sha256": digest(tree / "header-provenance.json"),
          "scratch_retained": str(tree), "scratch_identity": [held.st_dev, held.st_ino],
          "file_inventory": inventory, "payload_executions": 0, "root_fixture_executions": 0,
          "cgroup_writes": 0, "scope": "ordinary whole-graph normal/test Rust objects and installed-header C bridge object only; no linking or compiled prototype/test/reporter execution"}), flush=True)
except BaseException as error:
    partial_inventory = None
    inventory_error = None
    if tree is not None:
        try:
            partial_inventory = retained_inventory(tree)
        except BaseException as snapshot_error:
            inventory_error = type(snapshot_error).__name__ + ": " + str(snapshot_error)
    print("ORDINARY_COMPONENT_REFUSED=" + json.dumps({"error": type(error).__name__ + ": " + str(error),
          "scratch_retained": None if tree is None else str(tree),
          "file_inventory": partial_inventory, "inventory_error": inventory_error,
          "policy": "preserve raw failure and owned artifacts before exact identity cleanup; no retry/root fallback"}), flush=True)
    raise
