"""Package013 exact source, all drafts and raw object receipts; no remote action."""
import hashlib
import json
from pathlib import Path
import zipfile
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]
DEST=REPO/"tests/evidence/linux-terminal-controller-objects.zip"
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not DEST.exists(), "never overwrite a public evidence archive"
files={}
for p in sorted(HERE.rglob("*")):
    if p.is_file() and p.name!="archive-receipt.json" and "__pycache__" not in p.parts:
        files[p.relative_to(HERE).as_posix()]=p.read_bytes()
for name in ("src/deadline.rs","target/codex-security/issue2-linux-generic-request-001/request.rs"):
    files["dependencies/"+name]=(REPO/name).read_bytes()
index={n:{"bytes":len(b),"sha256":sha(b)} for n,b in files.items()}
with zipfile.ZipFile(DEST,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in files.items():z.writestr(n,b)
    z.writestr("INDEX.json",json.dumps(index,indent=2)+"\n")
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(index)|{"INDEX.json"}
    assert json.loads(z.read("INDEX.json"))==index
    for n,pin in index.items():
        b=z.read(n)
        assert len(b)==pin["bytes"] and sha(b)==pin["sha256"],n
receipt={"schema":1,"archive":str(DEST),"sha256":sha(DEST.read_bytes()),"bytes":DEST.stat().st_size,"members":len(index)+1,"crc_and_all_member_bytes_hashes":"passed","includes_exact_pre_removal_zip":True,"scope":"Native C/Rust objects only; no linking/runtime/children/cgroup/root/protection or performance verdict"}
with (HERE/"archive-receipt.json").open("x",encoding="utf-8") as f:f.write(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
