# Linux retained-owner release lease qualification

The archived one-shot proof samples owner liveness before asking a separate supervisor to release a placed child. The supervisor's release path checks the gate and writes the permit. The watchdog independently checks the owner and timer. A schedule in which the watchdog is delayed can let the gate-only decision pass after an earlier liveness sample has become stale. This is a source-order counterexample to a stronger release claim. The archived lifecycle results retain their observed scope. [Archived external admission source and evidence](https://github.com/WikdSolvemProbler/process-tree-guard/blob/e5c6159/tests/evidence/linux-external-admission-20261106.zip)

This standalone fixture first runs the four published cross-peer admission lanes. It then runs three release lanes using the same SO_PEERCRED, kernel SCM_CREDENTIALS and transferred pidfd receiver. In each new lane the controller authenticates an ordinary direct child, moves the received pidfd into the lease, arms a one-shot CLOCK_BOOTTIME timer at an absolute deadline derived from the decoded duration, observes native socket EOF and closes the authentication endpoint. A second direct child is a held sentinel. It stages its permit reader and receipt writer, closes other inherited control descriptors, then reports readiness.

The controller first samples a live owner and an unexpired lease. A one-shot release authority consumes the sole permit writer. It polls the retained owner pidfd and timer at zero timeout, then reads CLOCK_BOOTTIME and compares it with the same absolute deadline. It sends G only when the sample shows a live owner and an unexpired lease. Owner loss has precedence if both are observed. The sentinel reports a marker only after a real G. The two refusal lanes observe EOF instead. A synthetic gate-only predicate records the legacy disposition after the death or expiry barrier while leaving the permit pipe untouched.

| Lane | Barrier before the final sample | Required receipt |
| --- | --- | --- |
| Live | Owner stays held and timer remains unexpired | Permit and exactly one marker. Sentinel exits 7 |
| OwnerDead | Independently held owner pidfd signals while the child is unreaped | OwnerLost, retained owner pidfd ready, permit EOF and sentinel exit 125 |
| AbsoluteExpiry | Absolute timer becomes readable while the owner remains held | Deadline, timer ready and boot clock at or after the absolute timestamp, permit EOF and sentinel exit 125 |

The live and owner-death packets request five seconds. The expiry packet requests one second. Each lane has a shared three-second observation bound, plus one second per direct child for failed-lane cleanup. A successful lane requires transport EOF before the release decision, exact sentinel receipt EOF, exact child reaping, original owner exit 23 and descriptor baseline settlement. The controller verifies group and scope membership for both children and unlinks the original private listener after all lanes. The enclosing authorized scope provides an independent whole-tree deadline.

The result concerns the observations in the final release sample. The poll and boot-clock read establish observations of the two native conditions, and the subsequent permit write is separate. A production watchdog still needs to monitor the held pidfd and timer after this decision and contain and drain the payload if either changes before or after execution begins. This fixture uses a pipe marker as its only action after permission. Production activation, containment and concurrency remain separate.

Preserve the following paths when transferring the native sources. Run the standalone controller as the ordinary account inside the approved finite Linux scope. Its sole argument is the already-created canonical 0700 scratch directory.

```text
rustc --edition=2021 -D warnings -C linker=/usr/bin/gcc target/codex-security/issue2-linux-release-lease-002/transport.rs -o release-lease
umask 077
./release-lease "$tree"
```

| Input | SHA-256 |
| --- | --- |
| target/codex-security/issue2-linux-release-lease-002/transport.rs | 907472caaa18f3e4a288f323c8969d85b5b0e494bcfad2cbf65357d24185fee9 |
| target/codex-security/issue2-linux-release-lease-002/cross_peer.rs | dab5eb3884ff1711d4396aa422b795cf5747c06a8d647f731e4250028dcd4091 |
| target/codex-security/issue2-linux-release-lease-002/release_lease.rs | 68a1e0207dba91e74e450ac56278b8cc8388e0c7910c441f3f55e0b653361eff |
| target/codex-security/issue2-linux-generic-request-001/request.rs | 6531478a6cb85c31ba4639c01c144c789968178df57b64d3d128073a8d91b4c4 |
| src/deadline.rs | 56252eb28270b4743d73e17e05ae933d3fad8168e7b4ba34405e859be9c85c53 |

The Linux ABI is the same 64-bit GNU aarch64 or x86_64 ABI as the original receiver. transport.rs is unchanged. The cross-peer source changes only the entry point and module declaration. The original cross-peer source and the initial lease draft are preserved beside the native sources. Local metadata checking substituted Windows-safe placeholder types for Unix-only standard-library types. The native runtime supplies the qualification.

The first native compile refused the read and write declarations under the runtime ABI lint. The original 001 sources and compiler receipt remain preserved. This attempt uses the C void-pointer signatures and casts only the call-site byte pointers.
