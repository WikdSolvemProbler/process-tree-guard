// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

use super::*;

const CLOCK_BOOTTIME: c_int = 7;
const TFD_TIMER_ABSTIME: c_int = 1;
const POLLHUP: c_short = 0x10;
const F_DUPFD_CLOEXEC: c_int = 1030;
const SYS_CLOSE_RANGE: c_long = 436;
const NS_PER_SECOND: u64 = 1_000_000_000;
const OWNER_EXIT: c_int = 23;
const PERMITTED_EXIT: c_int = 7;
const REFUSED_EXIT: c_int = 125;

#[repr(C)]
#[derive(Default)]
struct Timespec {
    seconds: i64,
    nanoseconds: i64,
}

#[repr(C)]
struct ItimerSpec {
    interval: Timespec,
    value: Timespec,
}

unsafe extern "C" {
    fn clock_gettime(clock: c_int, time: *mut Timespec) -> c_int;
    fn timerfd_create(clock: c_int, flags: c_int) -> c_int;
    fn timerfd_settime(
        fd: c_int,
        flags: c_int,
        value: *const ItimerSpec,
        old: *mut ItimerSpec,
    ) -> c_int;
    fn pipe2(fds: *mut c_int, flags: c_int) -> c_int;
    fn dup3(old: c_int, new: c_int, flags: c_int) -> c_int;
    fn read(fd: c_int, bytes: *mut u8, len: usize) -> isize;
    fn write(fd: c_int, bytes: *const u8, len: usize) -> isize;
}

fn boottime_ns() -> Probe<u64> {
    let mut time = Timespec::default();
    native(os_result(
        unsafe { clock_gettime(CLOCK_BOOTTIME, &mut time) } as isize,
    ))?;
    let seconds = u64::try_from(time.seconds).map_err(|_| "negative boot time")?;
    let nanoseconds = u64::try_from(time.nanoseconds).map_err(|_| "negative boot fraction")?;
    check(nanoseconds < NS_PER_SECOND, "invalid boot fraction")?;
    seconds
        .checked_mul(NS_PER_SECOND)
        .and_then(|value| value.checked_add(nanoseconds))
        .ok_or_else(|| "boot time overflow".into())
}

struct RetainedLease {
    owner: OwnedFd,
    timer: OwnedFd,
    admitted_ns: u64,
    deadline_ns: u64,
}

impl RetainedLease {
    fn arm(admitted: Admitted) -> Probe<Self> {
        let admitted_ns = boottime_ns()?;
        let duration_ns = u64::try_from(admitted.plan.duration().as_nanos())
            .map_err(|_| "request duration overflow")?;
        check(duration_ns > 0, "decoded deadline became zero")?;
        let deadline_ns = admitted_ns
            .checked_add(duration_ns)
            .ok_or("absolute deadline overflow")?;
        let timer =
            fd_from_call(unsafe { timerfd_create(CLOCK_BOOTTIME, SOCK_NONBLOCK | SOCK_CLOEXEC) })?;
        native(close_on_exec(timer.as_raw_fd()))?;
        let value = ItimerSpec {
            interval: Timespec::default(),
            value: Timespec {
                seconds: (deadline_ns / NS_PER_SECOND) as i64,
                nanoseconds: (deadline_ns % NS_PER_SECOND) as i64,
            },
        };
        native(os_result(unsafe {
            timerfd_settime(
                timer.as_raw_fd(),
                TFD_TIMER_ABSTIME,
                &value,
                ptr::null_mut(),
            )
        } as isize))?;
        Ok(Self {
            owner: admitted.owner,
            timer,
            admitted_ns,
            deadline_ns,
        })
    }

    fn sample(&self) -> Probe<DecisionReceipt> {
        let mut watched = [
            PollFd {
                fd: self.owner.as_raw_fd(),
                events: POLLIN,
                revents: 0,
            },
            PollFd {
                fd: self.timer.as_raw_fd(),
                events: POLLIN,
                revents: 0,
            },
        ];
        let count = native(os_result(
            unsafe { poll(watched.as_mut_ptr(), watched.len(), 0) } as isize,
        ))?;
        let sampled_ns = boottime_ns()?;
        let owner_events = watched[0].revents;
        let timer_events = watched[1].revents;
        check(
            count == watched.iter().filter(|fd| fd.revents != 0).count()
                && owner_events & !(POLLIN | POLLHUP) == 0
                && timer_events & !POLLIN == 0,
            "unexpected release sample poll result",
        )?;
        let decision = if owner_events != 0 {
            Decision::OwnerLost
        } else if timer_events != 0 || sampled_ns >= self.deadline_ns {
            Decision::Deadline
        } else {
            Decision::Permit
        };
        Ok(DecisionReceipt {
            decision,
            owner_events,
            timer_events,
            sampled_ns,
        })
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Decision {
    Permit,
    OwnerLost,
    Deadline,
}

#[derive(Debug)]
struct DecisionReceipt {
    decision: Decision,
    owner_events: c_short,
    timer_events: c_short,
    sampled_ns: u64,
}

struct ReleaseAuthority {
    lease: RetainedLease,
    permit: OwnedFd,
}

impl ReleaseAuthority {
    fn decide(self) -> Probe<(RetainedLease, DecisionReceipt)> {
        let Self { lease, permit } = self;
        let receipt = lease.sample()?;
        if receipt.decision == Decision::Permit {
            write_byte(permit.as_raw_fd(), b'G')?;
        }
        drop(permit);
        Ok((lease, receipt))
    }
}

fn pipe() -> Probe<(OwnedFd, OwnedFd)> {
    let mut fds = [-1; 2];
    native(os_result(
        unsafe { pipe2(fds.as_mut_ptr(), SOCK_CLOEXEC | SOCK_NONBLOCK) } as isize,
    ))?;
    // Successful pipe2 installs two newly owned descriptors.
    let [reader, writer] = fds.map(|fd| unsafe { OwnedFd::from_raw_fd(fd) });
    native(close_on_exec(reader.as_raw_fd()))?;
    native(close_on_exec(writer.as_raw_fd()))?;
    Ok((reader, writer))
}

fn read_byte(fd: RawFd, until: Instant) -> Probe<Option<u8>> {
    wait_fd(fd, POLLIN | POLLHUP, until)?;
    let mut byte = 0;
    let count = native(os_result(unsafe { read(fd, &mut byte, 1) }))?;
    check(count <= 1, "short marker receipt shape differs")?;
    Ok((count == 1).then_some(byte))
}

fn write_byte(fd: RawFd, byte: u8) -> Probe<()> {
    check(
        native(os_result(unsafe { write(fd, &byte, 1) }))? == 1,
        "short marker write",
    )
}

fn synthetic_gate_only(placed: bool, request: u8) -> bool {
    placed && request == b'G'
}

fn marker(permit: RawFd, receipts: RawFd, until: Instant) -> Probe<c_int> {
    let permit_staged = native(os_result(
        unsafe { fcntl(permit, F_DUPFD_CLOEXEC, 10 as c_int) } as isize,
    ))? as RawFd;
    let receipt_staged = native(os_result(
        unsafe { fcntl(receipts, F_DUPFD_CLOEXEC, 10 as c_int) } as isize,
    ))? as RawFd;
    native(os_result(
        unsafe { dup3(permit_staged, 3, SOCK_CLOEXEC) } as isize
    ))?;
    native(os_result(
        unsafe { dup3(receipt_staged, 4, SOCK_CLOEXEC) } as isize
    ))?;
    native(os_result(unsafe {
        syscall(
            SYS_CLOSE_RANGE,
            5 as c_long,
            u32::MAX as c_long,
            0 as c_long,
        )
    } as isize))?;
    // Readiness follows closing every inherited permit writer and owner/control descriptor.
    write_byte(4, b'R')?;
    match read_byte(3, until)? {
        Some(b'G') => {
            write_byte(4, b'M')?;
            Ok(PERMITTED_EXIT)
        }
        None => {
            write_byte(4, b'E')?;
            Ok(REFUSED_EXIT)
        }
        Some(_) => Err("unexpected permit byte".into()),
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum LeaseLane {
    Live,
    OwnerDead,
    AbsoluteExpiry,
}

impl LeaseLane {
    fn seconds(self) -> f64 {
        if self == Self::AbsoluteExpiry {
            1.0
        } else {
            5.0
        }
    }

    fn expected(self) -> Decision {
        match self {
            Self::Live => Decision::Permit,
            Self::OwnerDead => Decision::OwnerLost,
            Self::AbsoluteExpiry => Decision::Deadline,
        }
    }
}

struct DirectChild {
    pid: c_int,
    pidfd: Option<OwnedFd>,
    reaped: bool,
}

impl DirectChild {
    fn new(pid: c_int) -> Self {
        Self {
            pid,
            pidfd: None,
            reaped: false,
        }
    }

    fn hold(&mut self, credentials: Credentials, group: c_int, scope: &str) -> Probe<()> {
        self.pidfd = Some(native(pidfd_for(self.pid))?);
        native(validate_pidfd(
            self.pidfd.as_ref().expect("held direct child"),
            Credentials {
                pid: self.pid,
                ..credentials
            },
            &mut NativeReceipt::default(),
        ))?;
        check(
            unsafe { getpgid(self.pid) } == group
                && io_result(fs::read_to_string(format!("/proc/{}/cgroup", self.pid)))? == scope,
            "held direct child moved out of the controller group or scope",
        )
    }

    fn fd(&self) -> Probe<RawFd> {
        self.pidfd
            .as_ref()
            .map(AsRawFd::as_raw_fd)
            .ok_or_else(|| "missing child pidfd".into())
    }

    fn reap(&mut self, until: Instant, expected: c_int) -> Probe<()> {
        wait_fd(self.fd()?, POLLIN, until)?;
        let status = reap_child(self.pid, until)?;
        self.reaped = true;
        check(
            status == expected << 8,
            "unexpected direct child exit status",
        )
    }

    fn settle(&self) -> Probe<()> {
        if !self.reaped {
            settle_failed_child(self.pid, self.pidfd.as_ref())?;
        }
        Ok(())
    }
}

fn owner_client(
    listener: &Rendezvous,
    lane: LeaseLane,
    mut gate: UnixStream,
    until: Instant,
) -> Probe<c_int> {
    if unsafe { close(listener.fd.as_raw_fd()) } != 0 {
        return Err("failed to close inherited listener".into());
    }
    gate_read(&mut gate, b'G', until)?;
    let connection = connect_client(&listener.path)?;
    let owner = native(pidfd_for(ordinary_credentials()?.pid))?;
    let frame = request::encode(lane.seconds(), &[b"/never-executed", b"", b"\xff release"])
        .map_err(|error| format!("{error:?}"))?;
    native(send_packet(
        connection.as_raw_fd(),
        &frame,
        &[owner.as_raw_fd()],
    ))?;
    drop((connection, owner));
    gate_read(&mut gate, b'Q', until)?;
    Ok(OWNER_EXIT)
}

fn child_exit(result: Probe<c_int>) -> ! {
    match result {
        Ok(status) => unsafe { _exit(status) },
        Err(error) => {
            eprintln!("lease child: {error}");
            unsafe { _exit(FAIL_EXIT) };
        }
    }
}

fn admitted_owner(
    listener: &Rendezvous,
    lane: LeaseLane,
    expected: Credentials,
    until: Instant,
) -> Probe<(RetainedLease, NativeReceipt)> {
    let connection = listener.accept(until)?;
    let fd = connection.as_raw_fd();
    wait_fd(fd, POLLIN, until)?;
    let mut receipt = NativeReceipt::default();
    let admitted = native(receive_observed(fd, &mut receipt))?;
    let arguments = admitted.plan.arguments();
    check(
        admitted.peer == expected
            && receipt.peer == Some(expected)
            && receipt.sender == Some(expected)
            && receipt.rights == 1
            && receipt.pidfd_cloexec
            && receipt.pidfd_pid == Some(expected.pid)
            && receipt.pidfd_revents == Some(0)
            && admitted.plan.duration() == Duration::from_secs_f64(lane.seconds())
            && admitted.plan.program().to_bytes() == b"/never-executed"
            && arguments.len() == 3
            && arguments[1].to_bytes().is_empty()
            && arguments[2].to_bytes() == b"\xff release",
        "admitted lease transport receipt differs",
    )?;
    let original_fd = admitted.owner.as_raw_fd();
    let lease = RetainedLease::arm(admitted)?;
    check(
        lease.owner.as_raw_fd() == original_fd,
        "lease replaced the transferred pidfd",
    )?;
    wait_fd(fd, POLLIN | POLLHUP, until)?;
    let mut eof = NativeReceipt::default();
    check(
        matches!(receive_observed(fd, &mut eof), Err(Refusal::EmptyPacket)) && eof.rights == 0,
        "authentication transport did not reach native EOF",
    )?;
    drop(connection);
    Ok((lease, receipt))
}

fn run_lane(
    listener: &Rendezvous,
    lane: LeaseLane,
    parent: Credentials,
    group: c_int,
    scope: &str,
) -> Probe<()> {
    let before = descriptor_count()?;
    let until = Instant::now() + LANE_BOUND;
    let (mut owner_gate, client_gate) = io_result(UnixStream::pair())?;
    for gate in [&owner_gate, &client_gate] {
        io_result(gate.set_nonblocking(true))?;
        native(close_on_exec(gate.as_raw_fd()))?;
    }
    let owner_pid = unsafe { fork() };
    native(os_result(owner_pid as isize))?;
    if owner_pid == 0 {
        drop(owner_gate);
        child_exit(owner_client(listener, lane, client_gate, until));
    }
    drop(client_gate);
    let mut owner = DirectChild::new(owner_pid);
    let mut marker_child = None;
    let verdict: Probe<()> = (|| {
        owner.hold(parent, group, scope)?;
        gate_write(&mut owner_gate, b'G')?;
        let expected = Credentials {
            pid: owner_pid,
            ..parent
        };
        let (lease, authentication) = admitted_owner(listener, lane, expected, until)?;
        let (permit_read, permit_write) = pipe()?;
        let (receipt_read, receipt_write) = pipe()?;
        let marker_pid = unsafe { fork() };
        native(os_result(marker_pid as isize))?;
        if marker_pid == 0 {
            child_exit(marker(
                permit_read.as_raw_fd(),
                receipt_write.as_raw_fd(),
                until,
            ));
        }
        marker_child = Some(DirectChild::new(marker_pid));
        let held_marker = marker_child.as_mut().expect("marker child recorded");
        drop((permit_read, receipt_write));
        held_marker.hold(parent, group, scope)?;
        let placed = read_byte(receipt_read.as_raw_fd(), until)? == Some(b'R');
        check(placed, "held child did not report readiness")?;
        let initial = lease.sample()?;
        check(
            initial.decision == Decision::Permit
                && initial.owner_events == 0
                && initial.timer_events == 0
                && initial.sampled_ns < lease.deadline_ns,
            "initial lease sample was not live and unexpired",
        )?;
        match lane {
            LeaseLane::Live => {}
            LeaseLane::OwnerDead => {
                gate_write(&mut owner_gate, b'Q')?;
                wait_fd(owner.fd()?, POLLIN, until)?;
            }
            LeaseLane::AbsoluteExpiry => {
                wait_fd(lease.timer.as_raw_fd(), POLLIN, until)?;
            }
        }
        let gate_only_would_emit = synthetic_gate_only(placed, b'G');
        check(gate_only_would_emit, "synthetic gate-only decision differs")?;
        let (lease, decision) = ReleaseAuthority {
            lease,
            permit: permit_write,
        }
        .decide()?;
        check(
            decision.decision == lane.expected(),
            "one-shot release disposition differs",
        )?;
        match lane {
            LeaseLane::Live => check(
                decision.owner_events == 0
                    && decision.timer_events == 0
                    && decision.sampled_ns < lease.deadline_ns,
                "live release sample differs",
            )?,
            LeaseLane::OwnerDead => check(
                decision.owner_events & POLLIN != 0
                    && decision.timer_events == 0
                    && decision.sampled_ns < lease.deadline_ns,
                "owner-death release sample differs",
            )?,
            LeaseLane::AbsoluteExpiry => check(
                decision.owner_events == 0
                    && decision.timer_events & POLLIN != 0
                    && decision.sampled_ns >= lease.deadline_ns,
                "absolute expiry release sample differs",
            )?,
        }
        let permitted = lane == LeaseLane::Live;
        let expected_byte = if permitted { b'M' } else { b'E' };
        let expected_exit = if permitted {
            PERMITTED_EXIT
        } else {
            REFUSED_EXIT
        };
        check(
            read_byte(receipt_read.as_raw_fd(), until)? == Some(expected_byte),
            "marker child disposition differs",
        )?;
        held_marker.reap(until, expected_exit)?;
        check(
            read_byte(receipt_read.as_raw_fd(), until)?.is_none(),
            "duplicate marker or unexpected receipt writer survived",
        )?;
        if lane != LeaseLane::OwnerDead {
            gate_write(&mut owner_gate, b'Q')?;
        }
        wait_fd(lease.owner.as_raw_fd(), POLLIN, until)?;
        owner.reap(until, OWNER_EXIT)?;
        println!("lease_lane={lane:?} authenticated={authentication:?} transport=eof_closed owner_pid={owner_pid} marker_pid={marker_pid} admitted_ns={} deadline_ns={} initial={initial:?} sample={decision:?} gate_only_would_emit={gate_only_would_emit} actual_marker={permitted} marker_exit={expected_exit} marker_receipt_eof=verified owner_exit={OWNER_EXIT}", lease.admitted_ns, lease.deadline_ns);
        Ok(())
    })();
    drop(owner_gate);
    let marker_cleanup = marker_child.as_ref().map(DirectChild::settle).transpose();
    let owner_cleanup = owner.settle();
    if marker_cleanup.is_err() || owner_cleanup.is_err() {
        return Err(format!("lease lane {lane:?} disposition={verdict:?} marker_cleanup={marker_cleanup:?} owner_cleanup={owner_cleanup:?}"));
    }
    drop((marker_child, owner));
    verdict?;
    check(
        descriptor_count()? == before,
        "lease lane descriptor baseline changed",
    )?;
    println!("lease_lane={lane:?} descriptors=settled");
    Ok(())
}

pub(super) fn run() -> Probe<()> {
    let args: Vec<_> = std::env::args_os().collect();
    check(args.len() == 2, "supply the exact lease scratch directory")?;
    let parent = ordinary_credentials()?;
    let group = unsafe { getpgrp() };
    let scope = io_result(fs::read_to_string("/proc/self/cgroup"))?;
    let before = descriptor_count()?;
    let listener = Rendezvous::create(Path::new(&args[1]), parent.uid)?;
    let verdict: Probe<()> = (|| {
        for lane in [
            LeaseLane::Live,
            LeaseLane::OwnerDead,
            LeaseLane::AbsoluteExpiry,
        ] {
            run_lane(&listener, lane, parent, group, &scope)?;
        }
        Ok(())
    })();
    verdict.and(listener.remove())?;
    check(
        descriptor_count()? == before,
        "lease controller descriptor baseline changed",
    )?;
    println!("release_lease=passed lanes=3 listener=unlinked descriptors=settled");
    Ok(())
}
