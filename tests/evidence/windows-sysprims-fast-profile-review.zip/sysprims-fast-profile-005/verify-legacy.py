"""Render legacy anchors and missing-anchor cases from their actual raw archives."""

from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
CONFIG = ROOT / "candidate/tests/campaign.json"
EVIDENCE = REPO / "tests/evidence"


def rows(raw):
    return [json.loads(line) for line in raw.splitlines() if line]


def emit(folder, tag, meta, records, probes):
    config = harness._package_plan_config(meta)
    expected = harness._package_expected_output(meta)
    evidence, _ = harness._verified_pricing_evidence(meta, probes)
    identity = harness._recomputed_identity_mismatches(meta)
    decisions = harness._recorded_decisions(meta)
    text = report.render(
        records, meta.get("plan_counts") or plan.check_plan(plan.build_plan()),
        meta.get("fingerprints") or {}, pricing=evidence, platform=meta.get("platform", ""),
        arm_versions=meta.get("arm_versions"), identity_losses=identity, decisions=decisions,
        reduced=bool(meta.get("reduced")), expected_output=expected, config=config)
    out = text.encode("utf-8")
    with (folder / f"{tag}.report.txt").open("xb") as stream:
        stream.write(out)
    problems = harness._recorded_run_field_problems(meta)
    return {"report_sha256": sha256(out).hexdigest(), "rows": len(records),
            "recorded_field_problems": problems,
            "unverified_legacy_footing": config is report.NO_VERIFIED_LEGACY_STUB_PLAN,
            "unverified_generic_footing": config is report.NO_VERIFIED_PLAN}


def main():
    folder = ROOT / f"legacy-{sys.argv[1]}"
    folder.mkdir()
    with ZipFile(EVIDENCE / "windows-campaign-20261106.zip") as archive:
        meta = json.loads(archive.read("complete/run.json"))
        observations = rows(archive.read("complete/observations.jsonl"))
        probes = rows(archive.read("complete/pricing-observations.jsonl"))
    assert sha256(CONFIG.read_bytes()).hexdigest() == meta["config_sha256"]
    known = dict(meta, config_path=str(CONFIG))
    missing = dict(meta, config_path=str(ROOT / "absent-legacy-config.json"))
    assert not Path(missing["config_path"]).exists()
    reduced = EVIDENCE / "reduced-run"
    reduced_meta = json.loads((reduced / "run.json").read_bytes())
    reduced_records = rows((reduced / "observations.jsonl").read_bytes())
    reduced_probes = rows((reduced / "pricing-observations.jsonl").read_bytes())
    with_no_anchor = deepcopy(reduced_meta)
    with_no_anchor["config_path"] = missing["config_path"]
    print(json.dumps({
        "archived_anchored": emit(folder, "archived_anchored", known, observations, probes),
        "archived_missing_anchor": emit(folder, "archived_missing_anchor", missing, observations, probes),
        "reduced_legacy_missing_anchor": emit(folder, "reduced_legacy_missing_anchor",
                                               with_no_anchor, reduced_records, reduced_probes),
    }, indent=2))


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in ("baseline", "candidate"):
        raise ValueError("select baseline or candidate")
    sys.path.insert(0, str(ROOT / sys.argv[1] / "tests/campaign"))
    import harness
    import plan
    import report
    main()
