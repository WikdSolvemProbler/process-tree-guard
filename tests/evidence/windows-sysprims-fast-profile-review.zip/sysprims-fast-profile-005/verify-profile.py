"""Targeted synthetic argv, scoring and package regressions. No arm runs."""

from contextlib import redirect_stderr, redirect_stdout
from copy import deepcopy
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "candidate/tests"
ALT = TREE / "campaign-sysprims-fast-warn.json"
sys.path[:0] = [str(TREE / "tests"), str(TREE / "campaign"), str(TREE)]
import arms
import harness
import report
import runner
from test_campaign_logic import complete_records, FULL_COUNTS


def assert_eq(actual, expected):
    if actual != expected:
        raise AssertionError(f"{actual!r} != {expected!r}")


def check(test, reason):
    if not test:
        raise AssertionError(reason)


def fast_gate(records, config):
    return {row["context"]: row["outcome"] for row in report.freeze_gate(records, config=config)
            if row["dimension"] == "fast-path latency"}


def resource(records, config, decisions):
    return next(row for row in report.profile_dimension_states(records, decisions, config=config)
                if row["dimension"] == report.DIM_RESOURCE)


def metadata(config, path, decisions):
    return {
        "config_path": str(path), "config_sha256": sha256(path.read_bytes()).hexdigest(),
        "config_templates": {arm: config["arms"][arm]["templates"] for arm in harness.PRODUCT_ARMS},
        "plan_counts": FULL_COUNTS, "profile_dimension_decisions": decisions,
        "competitor_identity_mismatches": [], "pricing_probe_observations": 0,
    }


def profiled(record):
    return record["arm"] == "sysprims" and record["path"] == "fast"


def naming_only(record, config):
    return [item for item in report._record_inconsistencies([record], config=config)
            if item["field"] == "fast_workload_argv"]


def strict_refuse(fn, reason):
    try:
        fn()
    except ValueError as error:
        check(reason in str(error), f"unexpected refusal {error!r}")
    else:
        raise AssertionError(f"no refusal naming {reason!r}")


def test_scope_and_environment(out):
    bad = json.loads(ALT.read_bytes())
    bad["arms"]["guard"]["templates"]["fast_workload"] = ["--invalid-other-arm"]
    path = out / "unsupported-arm.json"
    path.write_text(json.dumps(bad), encoding="utf-8")
    strict_refuse(lambda: harness.load_config(path), "only SysPrims")
    strict_refuse(lambda: arms.resolve_template("guard", "fast_workload", bad), "only supported for SysPrims")
    with patch.object(harness, "arm_versions", return_value={}):
        failures = harness.admission_failures(bad)
    check(any("guard: fast_workload is only supported for SysPrims" in problem for problem in failures),
          "direct admission did not name unsupported arm")
    args = SimpleNamespace(config=str(ALT), out=str(out / "never-created"), reduced=1, seed=None, run_id=None)
    with patch.dict(os.environ, {"RUST_LOG": "probe-marker"}), redirect_stderr(io.StringIO()) as stderr:
        assert_eq(harness.cmd_run(args), harness.EXIT_ADMISSION_FAILURE)
        assert_eq(os.environ["RUST_LOG"], "probe-marker")
    check("requires RUST_LOG to be absent" in stderr.getvalue(), "RUST_LOG refusal unnamed")
    check(not Path(args.out).exists(), "RUST_LOG refusal started a namespace")
    return {"unsupported_profile_refused": 3, "rust_log_refused_without_mutation": True}


def test_package(out, records, config, decisions, bad, meta):
    expected = report.expected_output_from_config(config)
    identity = harness._recomputed_identity_mismatches(meta)
    common = dict(identity_losses=identity, decisions=decisions,
                  expected_output=expected, config=config)
    first = harness.campaign_outcome(records, FULL_COUNTS, **common)
    meta.update({name: first[name] for name in (
        "campaign_status", "standing_loss_count", "freeze_gate_fail_count", "claim_ledger")})
    namespace = out / "synthetic-package"
    namespace.mkdir()
    (namespace / "report.txt").write_text(
        report.render(records, FULL_COUNTS, {}, **common), encoding="utf-8")
    (namespace / "claim-ledger.json").write_text(json.dumps({
        "config_sha256": meta["config_sha256"], "claims": first["claim_ledger"]}), encoding="utf-8")
    assert_eq(harness._report_verdict_problems(namespace, meta, records, []), [])
    assert_eq(harness._outcome_problems(meta, records, []), [])
    assert_eq(harness._claim_ledger_problems(namespace, meta, records), [])
    problems = harness._report_verdict_problems(namespace, meta, bad, [])
    for section in ("freeze gate", "evaluation profile", "claim ledger", "standing losses"):
        check(any(section in problem for problem in problems), f"tampered argv escaped package {section}")
    check(bool(harness._outcome_problems(meta, bad, [])), "tampered argv escaped package outcome")
    check(bool(harness._claim_ledger_problems(namespace, meta, bad)), "tampered argv escaped package ledger")
    (namespace / "argv-mutation-problems.json").write_text(json.dumps(problems, indent=2), encoding="utf-8")
    return {"clean_recomputed_report_outcome_and_ledger": True, "tamper_rejected_in_six_surfaces": True}


def test_scoring(out):
    config = harness.load_config(ALT)
    decisions = report.decisions_from_config(config)
    records = complete_records()
    expected = runner.fast_workload_argv("sysprims", config)
    for record in records:
        if profiled(record):
            record["argv"] = list(expected)
    assert_eq(fast_gate(records, config), {"NO_WINDOW": "PASS", "DETACHED": "PASS"})
    assert_eq(resource(records, config, decisions)["state"], "PASS")

    one = next(record for record in records if profiled(record)
               and record["kind"] == "measured" and record["context"] == "NO_WINDOW")
    mutations = (
        expected[:1] + expected[2:],
        [expected[0], "--log-level=info", *expected[2:]],
        [expected[0], expected[2], expected[1], *expected[3:]],
        [expected[0], expected[1], *expected[1:]],
        ["wrong-executable.exe", *expected[1:]],
        [*expected[:-1], "7"],
    )
    for argv in mutations:
        assert_eq(len(naming_only(dict(one, argv=argv), config)), 1)
    assert_eq(naming_only(one, config), [])
    warmup = next(record for record in records if profiled(record) and record["kind"] == "warmup")
    assert_eq(len(naming_only(dict(warmup, argv=mutations[0]), config)), 1)
    assert_eq(fast_gate([*records, dict(one, argv=mutations[0])], config),
              {"NO_WINDOW": "PASS", "DETACHED": "PASS"})

    bad = [dict(record, argv=mutations[0]) if record is one else record for record in records]
    assert_eq(fast_gate(bad, config), {"NO_WINDOW": "UNEVALUATED", "DETACHED": "PASS"})
    state = resource(bad, config, decisions)
    assert_eq(state["state"], "UNEVALUATED")
    check("sysprims on cpu_ms in fast/NO_WINDOW" in state["detail"], "missing bad cost-cell name")
    assert_eq(sum("SysPrims fast_workload argv differs" in loss for loss in
                  report.record_consistency_losses(bad, config=config)), 1)
    costs, unpaired, compared = report._paired_cost_comparison_full(bad, config)
    check(any("sysprims on cpu_ms in fast/DETACHED" in unit for unit in compared), "valid context lost")
    check(not any("sysprims on cpu_ms in fast/NO_WINDOW" in unit for unit in compared), "bad context compared")
    check(any("sysprims on cpu_ms in fast/NO_WINDOW" in unit for unit in unpaired), "bad context not unpaired")

    valid_rival = next(record for record in bad if record["arm"] == "processkit"
                       and record["kind"] == "measured" and record["path"] == "fast"
                       and record["context"] == "DETACHED")
    other_loss = [dict(record, cpu_ms=0.25) if record is valid_rival else record for record in bad]
    failed = resource(other_loss, config, decisions)
    assert_eq(failed["state"], "FAIL")
    check("processkit on cpu_ms in fast/DETACHED" in failed["detail"], "independent cost failure lost")

    meta = metadata(config, ALT, decisions)
    for claimed in (expected, ["--irrelevant-untrusted-value"], None):
        missing = deepcopy(meta)
        missing["config_path"] = str(out / "absent-profile-anchor.json")
        missing["config_templates"]["sysprims"]["fast_workload"] = claimed
        unverified = harness._package_plan_config(missing)
        assert_eq(unverified, report.NO_VERIFIED_SYSPRIMS_FAST_PLAN)
        assert_eq(fast_gate(records, unverified), {"NO_WINDOW": "UNEVALUATED", "DETACHED": "UNEVALUATED"})
        assert_eq(resource(records, unverified, decisions)["state"], "UNEVALUATED")
        check("without a verified profile" in naming_only(one, unverified)[0]["detail"],
              "untrusted metadata manufactured an expected argv")
    return {
        "measured_vector_mutations_named": len(mutations),
        "warmup_vector_mutation_named": True,
        "unplanned_duplicate_moves_no_gate": True,
        "measured_fast_cost_and_latency_unverified": True,
        "other_context_and_independent_cost_failure_preserved": True,
        "unanchored_values_only_degrade": True,
        **test_package(out, records, config, decisions, bad, meta),
    }


def forbid_child(*args, **kwargs):
    raise AssertionError("synthetic profile validation reached a process boundary")


def main():
    out = ROOT / "profile-regressions-002"
    out.mkdir()
    with patch.object(subprocess, "Popen", forbid_child), patch.object(subprocess, "run", forbid_child):
        receipt = {"state": "PASS", "live_slots": 0, **test_scope_and_environment(out), **test_scoring(out)}
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
