"""Verify the three no-process plan receipts and report the exact argv delta."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TOKEN = "--log-level=warn"
NAMES = ("baseline-shipped", "candidate-shipped", "candidate-alternate")


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def main():
    raw = {name: (ROOT / f"census-002-{name}.argv.json").read_bytes() for name in NAMES}
    baseline, fallback, profile = (json.loads(raw[name]) for name in NAMES)
    require(all(item["real_slots_launched"] == 0 and len(item["rows"]) == 1940
                for item in (baseline, fallback, profile)), "wrong launch scope or plan size")
    require(baseline["config_sha256"] == fallback["config_sha256"]
            and baseline["config_sha256"] != profile["config_sha256"], "configuration identity mismatch")
    require(baseline["rows"] == fallback["rows"], "shipped configuration fallback changed argv or flags")
    require(baseline["malformed_argv_budgets"] == fallback["malformed_argv_budgets"]
            == profile["malformed_argv_budgets"], "malformed argv budget changed")
    require(baseline["seed"] == fallback["seed"] == profile["seed"]
            and baseline["counts"] == fallback["counts"] == profile["counts"],
            "campaign schedule identity changed")
    require(profile["metadata_checks"] == {
        "correct_mapping_accepted": True, "omitted_override_rejected": True, "changed_override_rejected": True,
    }, "package template anchor was not checked")
    require(fallback["resolver_checks"] == profile["resolver_checks"] == {
        "legacy_fast_unchanged": True, "one_shot_override_stable": True,
    }, "direct resolver checks differ")

    changed = Counter()
    unchanged = Counter()
    malformed = Counter()
    for left, right in zip(baseline["rows"], profile["rows"], strict=True):
        require(left["slot"] == right["slot"] and left["creation_flags"] == right["creation_flags"],
                f"slot identity or native context changed: {left['slot']!r}")
        kind, arm, path, context, *_ = left["slot"]
        if arm == "sysprims" and path == "fast":
            expected = [left["argv"][0], TOKEN, *left["argv"][1:]]
            require(right["argv"] == expected and right["argv"].count(TOKEN) == 1,
                    f"unexpected SysPrims fast delta: {left['slot']!r}")
            changed[kind, context] += 1
        else:
            require(left["argv"] == right["argv"], f"unexpected other argv delta: {left['slot']!r}")
            unchanged[path] += 1
            if path == "malformed":
                malformed[left["slot"][-1], context] += 1

    require(changed == {
        ("warmup", "NO_WINDOW"): 9, ("warmup", "DETACHED"): 9,
        ("measured", "NO_WINDOW"): 90, ("measured", "DETACHED"): 90,
    }, "wrong changed population")
    require(unchanged.total() == 1742 and len(malformed) == 12,
            "wrong unchanged population or malformed coverage")
    require(baseline["counts"] == {"control": 36, "warmup": 224, "measured": 1680},
            "campaign decomposition differs")
    print(json.dumps({
        "state": "PLANNED_ONLY_PASS", "real_slots_launched": 0,
        "original_config_sha256": baseline["config_sha256"],
        "alternate_config_sha256": profile["config_sha256"],
        "shipped_rows_preserved": len(fallback["rows"]),
        "alternate_rows_changed": changed.total(), "alternate_rows_unchanged": unchanged.total(),
        "changed_by_kind_and_context": {"/".join(key): val for key, val in sorted(changed.items())},
        "unchanged_by_path": dict(sorted(unchanged.items())),
        "malformed_shape_context_census": {"/".join(key): val for key, val in sorted(malformed.items())},
        "malformed_argv_budgets": profile["malformed_argv_budgets"],
        "metadata_checks": profile["metadata_checks"], "resolver_checks": profile["resolver_checks"],
        "evidence_sha256": {name: sha256(data).hexdigest() for name, data in raw.items()},
    }, indent=2))


if __name__ == "__main__":
    main()
