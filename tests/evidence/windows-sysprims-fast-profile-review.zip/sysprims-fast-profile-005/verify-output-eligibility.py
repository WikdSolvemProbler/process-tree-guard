"""Exercise independent latency evidence against exact staged revisions."""

from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
revision = sys.argv[1]
if revision not in ("003", "004", "005"):
    raise ValueError("select revision 003, 004 or 005")
sys.path.insert(0, str(ROOT.with_name("sysprims-fast-profile-" + revision)))
from runpy import run_path

fixture = run_path(str(Path(sys.path[0]) / "verify-review.py"))
latency_fixture = fixture["latency_fixture"]
report = fixture["report"]
refuse_process = fixture["refuse_process"]


def measured(row, arm):
    return (row["arm"], row["path"], row["context"], row["kind"]) == (
        arm, "fast", "NO_WINDOW", "measured")


def latency(records, config, expected):
    return next(row for row in report.freeze_gate(records, expected, config)
                if row["dimension"] == "fast-path latency"
                and row["context"] == "NO_WINDOW")


def main():
    config, records = latency_fixture()
    expected = report.expected_output_from_config(config)
    for row in records:
        if row["path"] == "fast":
            pairs = expected["floor_spawn" if row["arm"] == "floor-spawn" else "fast"]
            for stream, pair in pairs.items():
                if pair is None:
                    continue
                digest, length = pair
                row[f"output_{stream}_sha256"] = digest
                row[f"output_{stream}_len"] = length
        if measured(row, "processkit"):
            row["elapsed_ms"] = 1.0

    valid = latency(records, config, expected)
    assert valid["outcome"] == "FAIL", valid
    assert "slower than processkit 1.000 ms" in valid["detail"], valid

    verdicts = {}
    for arm in ("guard", "processkit"):
        for stream in ("stdout", "stderr"):
            for field in ("sha256", "len"):
                mutant = deepcopy(records)
                row = next(item for item in mutant if measured(item, arm))
                key = f"output_{stream}_{field}"
                row[key] = "f" * 64 if field == "sha256" else row[key] + 1
                assert row[f"output_{stream}_match"] is True
                assert any(item["record"] is row and item["field"] == key
                           for item in report._record_inconsistencies(
                               mutant, expected, config))
                verdict = latency(mutant, config, expected)
                expected_verdict = "FAIL" if revision == "003" else "UNEVALUATED"
                assert verdict["outcome"] == expected_verdict, (arm, key, verdict)
                verdicts[f"{arm}/{key}"] = verdict["outcome"]
    for arm in ("guard", "processkit"):
        for stream in ("stdout", "stderr"):
            mutant = deepcopy(records)
            row = next(item for item in mutant if measured(item, arm))
            assert expected["fast"][stream] is not None
            for suffix in ("match", "sha256", "len"):
                row[f"output_{stream}_{suffix}"] = None
            assert not any(item["record"] is row and item["field"].startswith(
                f"output_{stream}_") for item in report._record_inconsistencies(
                    mutant, expected, config))
            verdict = latency(mutant, config, expected)
            expected_verdict = "UNEVALUATED" if revision == "005" else "FAIL"
            assert verdict["outcome"] == expected_verdict, (arm, stream, verdict)
            verdicts[f"{arm}/{stream}_unobserved"] = verdict["outcome"]

            optional = deepcopy(expected)
            optional["fast"][stream] = None
            verdict = latency(mutant, config, optional)
            assert verdict["outcome"] == "FAIL", (arm, stream, verdict)

    print(json.dumps({"revision": revision, "live_slots": 0,
                      "valid_loss": valid, "mutations": verdicts}, indent=2))


with patch.object(subprocess, "Popen", refuse_process), patch.object(
        subprocess, "run", refuse_process):
    main()
