"""Capture the actual runner's planned argv at a no-launch, in-memory boundary."""

import argparse
from copy import deepcopy
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
CONFIG_ROOT = ROOT / "candidate/tests"
TOKEN = "--log-level=warn"


class PlannedOnly(Exception):
    pass


class MemorySlot:
    def __init__(self, root):
        self.root = root
        self.serial = 0
        self.argv = None
        self.flags = None
        self.drained = False

    def location(self, prefix, suffix):
        self.serial += 1
        return str(self.root / f"{prefix}{self.serial:02d}{suffix}")

    def mkstemp(self, *, prefix, suffix=""):
        return -1, self.location(prefix, suffix)

    def mkdtemp(self, *, prefix):
        return self.location(prefix, "")

    def unlink(self, path, **kwargs):
        if not Path(path).is_relative_to(self.root):
            raise AssertionError(f"dry runner requested cleanup outside simulated slot: {path}")

    def launch(self, argv, *, creationflags, stdin, stdout, stderr):
        if self.argv is not None:
            raise AssertionError("dry runner attempted multiple launches")
        self.argv, self.flags = list(argv), creationflags
        raise PlannedOnly

    def drain(self):
        self.drained = True
        return {"active_before": 0, "active_after": 0, "terminated": False}


def refuse_process(*args, **kwargs):
    raise AssertionError("no-process census reached a real process boundary")


def planned_slot(runner, slot, config, ordinal):
    root = CONFIG_ROOT / "__in_memory_argv_census__" / f"{ordinal:04d}"
    job = MemorySlot(root)
    runner.tempfile = job
    runner.os = SimpleNamespace(path=os.path, close=lambda fd: None,
                                unlink=job.unlink, fdopen=lambda fd, mode: io.BytesIO())
    runner.shutil = SimpleNamespace(rmtree=job.unlink)
    runner.open = lambda path, mode: io.BytesIO()
    runner.subprocess = SimpleNamespace(DEVNULL=subprocess.DEVNULL, Popen=refuse_process, run=refuse_process)
    event_dir = str(root / "processkit-event") if slot.arm == "processkit" else None
    try:
        runner._run_slot(slot, config, job, event_dir)
    except PlannedOnly:
        pass
    else:
        raise AssertionError("planned slot did not reach the controlled launch boundary")
    if not job.drained or not job.argv:
        raise AssertionError("no-process launch boundary was not settled")
    return {"argv": job.argv, "creation_flags": job.flags}


def metadata_checks(harness, config, path):
    meta = {
        "config_path": str(path),
        "config_sha256": sha256(path.read_bytes()).hexdigest(),
        "config_templates": {
            arm: config.get("arms", {}).get(arm, {}).get("templates")
            for arm in harness.PRODUCT_ARMS
        },
    }
    problems = harness._recorded_run_field_problems(meta)
    if problems:
        raise AssertionError(f"correct template mapping refused: {problems}")
    checks = {"correct_mapping_accepted": True}
    if "fast_workload" in meta["config_templates"]["sysprims"]:
        removed = deepcopy(meta)
        removed["config_templates"]["sysprims"].pop("fast_workload")
        changed = deepcopy(meta)
        changed["config_templates"]["sysprims"]["fast_workload"][0] = "--log-level=debug"
        for label, value in (("omitted_override_rejected", removed), ("changed_override_rejected", changed)):
            failures = harness._recorded_run_field_problems(value)
            if not any("config_templates" in failure and "configuration" in failure for failure in failures):
                raise AssertionError(f"template anchor failed to reject {label}")
            checks[label] = True
    return checks


def resolver_checks(arms, config):
    original = arms.resolve_template("sysprims", "fast", config)
    altered = deepcopy(config)
    templates = altered["arms"]["sysprims"]["templates"]
    override = [TOKEN, *original]
    templates["fast_workload"] = iter(override)
    if not all(arms.resolve_template("sysprims", "fast_workload", altered) == override for _ in range(2)):
        raise AssertionError("one-shot explicit workload template changed between reads")
    if arms.resolve_template("sysprims", "fast", altered) != original:
        raise AssertionError("workload override mutated the original fast/malformed template")
    return {"legacy_fast_unchanged": True, "one_shot_override_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("tree", choices=("baseline", "candidate"))
    parser.add_argument("config", choices=("shipped", "alternate"))
    args = parser.parse_args()
    if not sys.flags.isolated or not sys.dont_write_bytecode or sys.platform != "win32":
        raise ValueError("use Windows Python -I -B")
    if not sys.pycache_prefix or Path(sys.pycache_prefix).exists():
        raise ValueError("explicit absent Python cache namespace required")
    sys.path.insert(0, str(ROOT / args.tree / "tests/campaign"))
    import arms
    import harness
    import plan
    import report
    import runner

    config_name = "campaign.json" if args.config == "shipped" else "campaign-sysprims-fast-warn.json"
    path = CONFIG_ROOT / config_name
    config = harness.load_config(path)
    seed = config.get("seed", plan.DEFAULT_SEED)
    slots = plan.build_plan(seed)
    counts = plan.check_plan(slots)
    if len(slots) != 1940:
        raise AssertionError("unexpected campaign length")

    metadata = metadata_checks(harness, config, path)
    budgets = {arm: report._plan_fast_argv_length(arm, config) for arm in plan.PRODUCT_ARMS}
    if any(value is None for value in budgets.values()):
        raise AssertionError("malformed argv budget could not be derived")
    rows = [{
        "slot": plan.slot_key(slot),
        **planned_slot(runner, slot, config, ordinal),
    } for ordinal, slot in enumerate(slots)]
    checks = resolver_checks(arms, config) if args.tree == "candidate" else {}
    print(json.dumps({
        "tree": args.tree, "configuration": args.config, "seed": seed, "counts": counts,
        "config_sha256": sha256(path.read_bytes()).hexdigest(),
        "metadata_checks": metadata, "resolver_checks": checks, "malformed_argv_budgets": budgets,
        "real_slots_launched": 0, "rows": rows,
    }, separators=(",", ":")))


if __name__ == "__main__":
    main()
