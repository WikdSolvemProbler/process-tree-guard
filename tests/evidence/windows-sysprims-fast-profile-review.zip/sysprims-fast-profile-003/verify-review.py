"""Reproduce the three reviewer blockers against the exact revision 003 source."""

import builtins
from contextlib import contextmanager, redirect_stderr, redirect_stdout
from copy import deepcopy
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "candidate/tests"
ALT = TREE / "campaign-sysprims-fast-warn.json"
SHIPPED = TREE / "campaign.json"
sys.path[:0] = [str(TREE / "tests"), str(TREE / "campaign"), str(TREE)]
import harness
import report
import runner
from test_campaign_logic import complete_records


def eq(left, right):
    if left != right:
        raise AssertionError(f"{left!r} != {right!r}")


class StopBeforeArm(Exception):
    pass


def refuse_process(*args, **kwargs):
    raise AssertionError("scratch test attempted to launch a process")


@contextmanager
def replace_config_after_first_read(path, first, second):
    path.write_bytes(first)
    modes = []

    @contextmanager
    def swapped(file, *args, **kwargs):
        modes.append(args[0] if args else kwargs.get("mode", "r"))
        with builtins.open(file, *args, **kwargs) as handle:
            yield handle
        if len(modes) == 1:
            path.write_bytes(second)

    def watched_open(file, *args, **kwargs):
        if Path(file).resolve() == path:
            return swapped(file, *args, **kwargs)
        return builtins.open(file, *args, **kwargs)

    with patch.object(harness, "open", watched_open, create=True):
        yield modes
    eq(path.read_bytes(), second)


def test_races(out):
    first = ALT.read_bytes()
    replacement = json.loads(SHIPPED.read_bytes())
    replacement["arms"]["sysprims"]["executable"] = "build\\replacement-sysprims.exe"
    replacement["children"]["fast"]["program"] = "fixture\\replacement.exe"
    replacement["children"]["fast"]["expected_stdout"] = "replacement output\n"
    second = (json.dumps(replacement) + "\n").encode()
    first_hash = sha256(first).hexdigest()
    path = out / "race-input.json"
    relative = os.path.relpath(path)
    namespace = out / "synthetic-run"
    namespace.mkdir()
    saved = {}

    def capture_meta(run_dir, meta):
        eq(Path(run_dir), namespace)
        saved["manifest"] = deepcopy(meta)

    def capture_config(slot, config):
        saved["config"] = deepcopy(config)
        raise StopBeforeArm

    with replace_config_after_first_read(path, first, second) as run_modes, \
            patch.dict(os.environ), \
            patch.object(harness, "namespace_run_dir", return_value=str(namespace)), \
            patch.object(harness, "_write_run_json", side_effect=capture_meta), \
            patch.object(harness, "run_slot", side_effect=capture_config), \
            redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
        os.environ.pop("RUST_LOG", None)
        args = SimpleNamespace(config=relative, out=str(out), reduced=1, seed=None, run_id="synthetic-run")
        try:
            harness.cmd_run(args)
        except StopBeforeArm:
            pass
        else:
            raise AssertionError("synthetic run did not reach the no-launch arm boundary")
    eq(run_modes, ["rb"])
    eq(saved["manifest"]["config_sha256"], first_hash)
    eq(saved["manifest"]["config_path"], str(path))
    eq(saved["manifest"]["config_templates"]["sysprims"]["fast_workload"][0], "--log-level=warn")
    eq(saved["config"]["arms"]["sysprims"]["executable"],
       str(path.parent / "build/competitors/sysprims.exe"))
    eq(saved["config"]["children"]["fast"]["program"], str(path.parent / "build/testkit.exe"))

    meta = {"config_path": relative, "config_sha256": first_hash}
    with replace_config_after_first_read(path, first, second) as anchor_modes:
        anchored = harness._anchored_config(meta)
    eq(anchor_modes, ["rb"])
    eq(anchored["arms"]["sysprims"], saved["config"]["arms"]["sysprims"])
    eq(anchored["children"]["fast"], saved["config"]["children"]["fast"])
    eq(harness._anchored_config(meta), None)

    with replace_config_after_first_read(path, first, second) as output_modes:
        actual = harness._package_expected_output(meta)
    eq(output_modes, ["rb"])
    eq(actual, report.expected_output_from_config(anchored))

    identity_configs = []

    def capture_identity(config, fingerprints, versions):
        identity_configs.append(config)
        return []

    with replace_config_after_first_read(path, first, second) as identity_modes, \
            patch.object(harness, "identity_mismatches", side_effect=capture_identity):
        eq(harness._recomputed_identity_mismatches(meta), [])
    eq(identity_modes, ["rb"])
    eq(identity_configs, [anchored])
    return {
        "cmd_run_reads_once_and_hashes_exact_parsed_bytes": True,
        "relative_paths_still_anchor_to_original_requested_directory": True,
        "anchored_config_identity_and_output_are_one_snapshot_each": True,
        "later_replacement_cannot_verify_under_original_hash": True,
    }


def entry(records, config, context="NO_WINDOW"):
    return next(row for row in report.freeze_gate(records, config=config)
                if row["dimension"] == "fast-path latency" and row["context"] == context)


def latency_fixture():
    config = harness.load_config(ALT)
    records = complete_records()
    expected = runner.fast_workload_argv("sysprims", config)
    for row in records:
        if row["arm"] == "sysprims" and row["path"] == "fast":
            row["argv"] = list(expected)
    bad = next(row for row in records if row["arm"] == "sysprims" and row["path"] == "fast"
               and row["context"] == "NO_WINDOW" and row["kind"] == "measured")
    bad["argv"].pop(1)
    return config, records


def test_latency_and_missing(out):
    config, records = latency_fixture()
    eq(entry(records, config)["outcome"], "UNEVALUATED")
    eq(entry(records, config, "DETACHED")["outcome"], "PASS")
    guard_bad = deepcopy(records)
    guard_row = next(row for row in guard_bad if row["arm"] == "guard" and row["path"] == "fast"
                     and row["context"] == "NO_WINDOW" and row["kind"] == "measured")
    guard_row["elapsed_ms"] = None
    fail = entry(guard_bad, config)
    eq(fail["outcome"], "FAIL")
    assert "carry no elapsed_ms" in fail["detail"]

    faster = deepcopy(records)
    fast_rivals = [row for row in faster if row["arm"] == "processkit" and row["path"] == "fast"
                   and row["context"] == "NO_WINDOW" and row["kind"] == "measured"]
    assert len(fast_rivals) == 90
    for row in fast_rivals:
        row["elapsed_ms"] = 1.0
    fail = entry(faster, config)
    eq(fail["outcome"], "FAIL")
    assert "slower than processkit 1.000 ms" in fail["detail"]
    assert "SysPrims fast argv cannot be verified" in fail["detail"]

    exact_meta = {
        "config_path": str(out / "nonexistent-config.json"),
        "config_sha256": sha256(ALT.read_bytes()).hexdigest(),
        "config_templates": {"sysprims": {"fast_workload": ["ignored"]}},
    }
    without_key = deepcopy(exact_meta)
    del without_key["config_templates"]["sysprims"]["fast_workload"]
    without_templates = dict(without_key)
    del without_templates["config_templates"]
    for meta in (exact_meta, without_key, without_templates):
        unverified = harness._package_plan_config(meta)
        eq(unverified, report.NO_VERIFIED_SYSPRIMS_FAST_PLAN)
        eq(entry(faster, unverified)["outcome"], "UNEVALUATED")
        eq(entry(records, unverified, "DETACHED")["outcome"], "UNEVALUATED")
        assert any("config" in item and "unverifiable" in item
                   for item in harness._recorded_run_field_problems(meta))
    eq(entry(guard_bad, unverified)["outcome"], "FAIL")

    fast_rivals[0]["elapsed_ms"] = None
    eq(entry(faster, config)["outcome"], "UNEVALUATED")
    generic = dict(without_templates, config_sha256=sha256(SHIPPED.read_bytes()).hexdigest())
    eq(harness._package_plan_config(generic), report.NO_VERIFIED_PLAN)
    return {
        "guard_timing_failure_preserved_in_invalid_profile_context": True,
        "verified_other_rival_median_failure_preserved_in_same_context": True,
        "other_rival_with_invalid_timing_does_not_mint_failure": True,
        "known_missing_profile_digest_degrades_without_key_or_templates": True,
        "unanchored_rival_not_treated_as_verified": True,
        "generic_legacy_missing_anchor_footing_preserved": True,
    }


def main():
    out = ROOT / "review-regressions-001"
    out.mkdir()
    with patch.object(subprocess, "Popen", refuse_process), patch.object(subprocess, "run", refuse_process):
        receipt = {"state": "PASS", "live_slots": 0, **test_races(out), **test_latency_and_missing(out)}
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
