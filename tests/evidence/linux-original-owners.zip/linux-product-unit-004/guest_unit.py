import base64,gzip,hashlib,json,os,pathlib,re,stat,subprocess,sys,tempfile,time
payload=json.loads(sys.stdin.buffer.read(65537))
if os.getuid()!=501 or os.geteuid()!=501: raise RuntimeError("ordinary UID501 required")
original=payload["build_root"]
rootfd=os.open(original["path"],os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
info=os.fstat(rootfd)
if (info.st_dev,info.st_ino,info.st_uid)!=(original["dev"],original["ino"],501): raise RuntimeError("original build identity differs")
buildfd=os.open("build",os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=rootfd)
binaryfd=os.open("linux_product_component",os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=buildfd)
bi=os.fstat(binaryfd)
if not stat.S_ISREG(bi.st_mode) or bi.st_uid!=501 or bi.st_size!=payload["binary_bytes"]: raise RuntimeError("binary metadata differs")
def digest():
    h=hashlib.sha256();offset=0
    while True:
        data=os.pread(binaryfd,1024*1024,offset)
        if not data: return h.hexdigest()
        h.update(data);offset+=len(data)
if digest()!=payload["binary_sha256"]: raise RuntimeError("binary pin differs")
out=pathlib.Path(tempfile.mkdtemp(prefix="ptg-linux-product-unit-004-"))
oi=os.stat(out,follow_symlinks=False)
print("ROOT="+json.dumps({"path":str(out),"dev":oi.st_dev,"ino":oi.st_ino,"uid":oi.st_uid,"pid":os.getpid(),"cgroup":pathlib.Path("/proc/self/cgroup").read_text()}),flush=True)
test_env=dict(os.environ)
(out/"fixtures").mkdir(mode=0o700)
test_env["TMPDIR"]=str(out/"fixtures")
records=[]
def run(index,args):
    argv=["/usr/bin/timeout","--signal=KILL","--kill-after=1s","15s","/proc/self/fd/"+str(binaryfd),*args]
    started=time.monotonic_ns()
    p=subprocess.run(argv,cwd=out,stdin=subprocess.DEVNULL,capture_output=True,pass_fds=(binaryfd,),env=test_env,timeout=18)
    (out/("step-"+str(index)+".stdout")).write_bytes(p.stdout);(out/("step-"+str(index)+".stderr")).write_bytes(p.stderr)
    records.append({"index":index,"argv":argv,"exit":p.returncode,"elapsed_ns":time.monotonic_ns()-started,"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest()})
    return p
listed=run(0,["--list"])
actual=[x[:-6] for x in listed.stdout.decode("utf-8").splitlines() if x.endswith(": test")]
executed=False;passed=False
if listed.returncode==0 and sorted(actual)==sorted(payload["expected_names"]):
    executed=True
    tested=run(1,["--test-threads=1","--nocapture"])
    passed=tested.returncode==0 and bool(re.search(rb"test result: ok[.] 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out",tested.stdout))
if digest()!=payload["binary_sha256"]: raise RuntimeError("binary changed during test")
receipt={"scope":"Seven parser/numeric tests plus actual ordinary seqpacket/selfpidfd/owned-file transport test; no product containment/privileged operation or activation.","candidate_sha256":payload["candidate_sha256"],"binary_sha256":payload["binary_sha256"],"build_root":original,"root":{"path":str(out),"dev":oi.st_dev,"ino":oi.st_ino,"uid":oi.st_uid},"listed_names":actual,"executed":executed,"all_pass":passed,"tests":8 if executed else 0,"passed":8 if passed else None,"failed":0 if passed else None,"ignored":0 if passed else None,"records":records,"limits":["Kernel socket/SCM_RIGHTS/selfpidfd and private file access operations exercised; no run_received/native-port/watchdog/payload/cgroup function executed.","This does not qualify Linux protection, trusted activation, supported kernel floor or full shared behavior."]}
(out/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
os.close(binaryfd);os.close(buildfd);os.close(rootfd)
files=[]
for path in sorted(out.rglob("*")):
    info=path.lstat()
    if stat.S_ISDIR(info.st_mode):continue
    if not stat.S_ISREG(info.st_mode):raise RuntimeError("unexpected artifact type")
    data=path.read_bytes();files.append({"path":path.relative_to(out).as_posix(),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"data_b64":base64.b64encode(data).decode()})
print("PRESERVED="+base64.b64encode(gzip.compress(json.dumps({"receipt":receipt,"files":files},separators=(",",":")).encode(),mtime=0)).decode(),flush=True)
sys.exit(0 if passed else 1)
