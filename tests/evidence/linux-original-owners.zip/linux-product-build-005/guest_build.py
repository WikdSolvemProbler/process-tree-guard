import base64,gzip,hashlib,json,os,pathlib,re,stat,subprocess,sys,tempfile,time
MAX=4*1024*1024
raw=sys.stdin.buffer.read(MAX+1)
if len(raw)>MAX: raise RuntimeError("source transfer exceeds bound")
payload=json.loads(raw)
if os.getuid()!=501 or os.geteuid()!=501: raise RuntimeError("ordinary UID501 required")
root=pathlib.Path(tempfile.mkdtemp(prefix="ptg-linux-product-build-005-"))
identity=os.stat(root,follow_symlinks=False)
print("ROOT="+json.dumps({"path":str(root),"dev":identity.st_dev,"ino":identity.st_ino,"uid":identity.st_uid,"pid":os.getpid(),"cgroup":pathlib.Path("/proc/self/cgroup").read_text()}),flush=True)
for row in payload["files"]:
    name=row["path"]; parts=pathlib.PurePosixPath(name).parts
    valid=(len(parts)==4 and parts[:3]==("src","sys","linux")) or name=="src/deadline.rs"
    if not valid or not re.fullmatch(r"[A-Za-z0-9_.-]+",parts[-1]): raise RuntimeError("noncanonical source name")
    data=base64.b64decode(row["data_b64"],validate=True)
    if len(data)!=row["bytes"] or hashlib.sha256(data).hexdigest()!=row["sha256"]: raise RuntimeError("source identity differs")
    target=root.joinpath(*parts);target.parent.mkdir(parents=True,exist_ok=True)
    with target.open("xb") as stream: stream.write(data)
(root/"entry.rs").write_text("#![allow(dead_code)]\n#[path=\"src/deadline.rs\"] mod deadline;\n#[path=\"src/sys/linux/mod.rs\"] mod linux;\ntype Policy = fn(u32,u32,&[u32],&std::ffi::CStr)->bool;\n#[used]\n#[unsafe(no_mangle)]\npub(crate) static PTG_LINUX_COMPONENT_ENTRY: unsafe fn(linux::VerifiedServiceScope,std::os::fd::OwnedFd,Policy)->linux::RunOutcome = linux::run_in_service;\n#[used]\n#[unsafe(no_mangle)]\npub(crate) static PTG_LINUX_UNQUALIFIED_ENTRY: unsafe fn(std::os::fd::OwnedFd,Policy)->linux::RunOutcome = linux::run_received;\n",encoding="utf-8")
gcc="/usr/bin/gcc";rust="/home/petershiller1.guest/.rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu/bin/rustc"
pins={gcc:"a20520ee21543f243d40636a9181a142c45ecd989de31ab86b99a8ea5ada870d",rust:"b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f"}
for tool,pin in pins.items():
    if hashlib.sha256(pathlib.Path(tool).read_bytes()).hexdigest()!=pin: raise RuntimeError("compiler pin differs")
commands=[]
for stem in ["kernel_signal_abi","native_arming","payload_bootstrap","terminal_bridge","waitid_bridge"]:
    commands.append([gcc,"-std=c11","-O2","-Wall","-Wextra","-Werror","-fstack-protector-strong","-MD","-MF",stem+".d","-c","src/sys/linux/"+stem+".c","-o",stem+".o"])
commands.append(["/usr/bin/ar","rcs","libptg_linux_native.a",*[(s+".o") for s in ["kernel_signal_abi","native_arming","payload_bootstrap","terminal_bridge","waitid_bridge"]]])
(root/"build").mkdir()
commands += [[rust,"--edition=2024","--crate-type=lib","--emit=obj","-Dwarnings","entry.rs","-o","normal.o"],[rust,"--edition=2024","--test","--emit=obj,link","-Dwarnings","entry.rs","-Lnative="+str(root),"-lstatic=ptg_linux_native","--crate-name","linux_product_component","--out-dir","build"]]
records=[]
for index,argv in enumerate(commands):
    started=time.monotonic_ns()
    result=subprocess.run(["/usr/bin/timeout","--signal=KILL","--kill-after=1s","25s",*argv],cwd=root,capture_output=True,timeout=28)
    (root/("step-"+str(index)+".stdout")).write_bytes(result.stdout)
    (root/("step-"+str(index)+".stderr")).write_bytes(result.stderr)
    row={"index":index,"argv":argv,"exit":result.returncode,"elapsed_ns":time.monotonic_ns()-started,"stdout_sha256":hashlib.sha256(result.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(result.stderr).hexdigest()}
    records.append(row);print("STEP="+json.dumps(row),flush=True)
for row in payload["files"]:
    if hashlib.sha256(root.joinpath(*pathlib.PurePosixPath(row["path"]).parts).read_bytes()).hexdigest()!=row["sha256"]: raise RuntimeError("source changed during compilation")
for tool,pin in pins.items():
    if hashlib.sha256(pathlib.Path(tool).read_bytes()).hexdigest()!=pin: raise RuntimeError("compiler changed during compilation")
receipt={"scope":"Compiler and static-library/link validation of actual canonical Linux graph; no reporter, product, test harness, child fixture, root or cgroup control operation executed.","candidate_sha256":payload["candidate_sha256"],"records":records,"all_pass":all(x["exit"]==0 for x in records),"root":{"path":str(root),"dev":identity.st_dev,"ino":identity.st_ino,"uid":identity.st_uid},"source_pins":{x["path"]:x["sha256"] for x in payload["files"]},"limits":["allow(dead_code) permits the unselected internal module; all other warnings are errors.","Never-called typed entry anchor forces real run_in_service monomorphization; objects/linking do not establish native ABI behavior, runtime or backend readiness.","Installed compiler hashes match before/after; header dependency files are preserved but header immutability/mapped-page identity is not established by this build."]}
(root/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
files=[];total=0
for path in sorted(root.rglob("*")):
    info=path.lstat()
    if stat.S_ISDIR(info.st_mode): continue
    if not stat.S_ISREG(info.st_mode): raise RuntimeError("unexpected artifact type")
    data=path.read_bytes();total+=len(data)
    if total>64*1024*1024: raise RuntimeError("artifact preservation bound exceeded")
    files.append({"path":path.relative_to(root).as_posix(),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"data_b64":base64.b64encode(data).decode()})
package=json.dumps({"receipt":receipt,"files":files},separators=(",",":")).encode()
print("PRESERVED="+base64.b64encode(gzip.compress(package,mtime=0)).decode(),flush=True)
sys.exit(0 if receipt["all_pass"] else 1)
