kernel_signal_abi.o: src/sys/linux/kernel_signal_abi.c \
 /usr/include/stdc-predef.h src/sys/linux/native_arming.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 src/sys/linux/owner_watch.h src/sys/linux/payload_bootstrap.h \
 /usr/include/aarch64-linux-gnu/asm/signal.h \
 /usr/include/asm-generic/signal.h /usr/include/linux/types.h \
 /usr/include/aarch64-linux-gnu/asm/types.h \
 /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
 /usr/include/aarch64-linux-gnu/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h \
 /usr/include/aarch64-linux-gnu/asm/posix_types.h \
 /usr/include/asm-generic/posix_types.h \
 /usr/include/asm-generic/signal-defs.h \
 /usr/include/aarch64-linux-gnu/asm/unistd.h \
 /usr/include/asm-generic/unistd.h /usr/include/errno.h \
 /usr/include/aarch64-linux-gnu/bits/errno.h /usr/include/linux/errno.h \
 /usr/include/aarch64-linux-gnu/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/include/aarch64-linux-gnu/bits/types/error_t.h \
 /usr/include/unistd.h /usr/include/aarch64-linux-gnu/bits/posix_opt.h \
 /usr/include/aarch64-linux-gnu/bits/environments.h \
 /usr/include/aarch64-linux-gnu/bits/confname.h \
 /usr/include/aarch64-linux-gnu/bits/getopt_posix.h \
 /usr/include/aarch64-linux-gnu/bits/getopt_core.h \
 /usr/include/aarch64-linux-gnu/bits/unistd.h \
 /usr/include/aarch64-linux-gnu/bits/unistd-decl.h \
 /usr/include/aarch64-linux-gnu/bits/unistd_ext.h \
 /usr/include/linux/close_range.h
