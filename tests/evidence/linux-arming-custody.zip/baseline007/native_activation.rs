// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

use super::*;

const CLONE_PIDFD: u64 = 0x0000_1000;
const CLONE_INTO_CGROUP: u64 = 0x2_0000_0000;
const SIGCHLD: u64 = 17;

// Linux v5.14 include/uapi/linux/sched.h, CLONE_ARGS_SIZE_VER2.
#[repr(C, align(8))]
#[derive(Default)]
struct CloneArgs {
    flags: u64,
    pidfd: u64,
    child_tid: u64,
    parent_tid: u64,
    exit_signal: u64,
    stack: u64,
    stack_size: u64,
    tls: u64,
    set_tid: u64,
    set_tid_size: u64,
    cgroup: u64,
}

const _: () = {
    assert!(std::mem::size_of::<CloneArgs>() == 88);
    assert!(std::mem::align_of::<CloneArgs>() == 8);
    assert!(std::mem::offset_of!(CloneArgs, cgroup) == 80);
};

struct LeaseWatch<'a> {
    owner_pid: c_int,
    owner: &'a OwnedFd,
    timer: &'a OwnedFd,
    deadline_ns: u64,
}

impl<'a> From<&'a PreparedRun> for LeaseWatch<'a> {
    fn from(prepared: &'a PreparedRun) -> Self {
        Self {
            owner_pid: prepared.owner_pid,
            owner: &prepared.lease.owner,
            timer: &prepared.lease.timer,
            deadline_ns: prepared.lease.deadline_ns,
        }
    }
}

// The trusted provisioner supplies these from one verified fresh cgroup2
// domain. These are owned descriptors, never paths from the request.
struct DomainControls {
    directory: OwnedFd,
    watchdog_kill: OwnedFd,
    supervisor_kill: OwnedFd,
    events: OwnedFd,
    provenance: cgroup_authority::LeafProvenance,
}

struct ArmedDomain {
    controls: DomainControls,
    watchdog_pidfd: OwnedFd,
}

struct ChildPlan<'a> {
    directory: &'a OwnedFd,
    identity: &'a VerifiedIdentity,
    exec: &'a request::ExecPlan,
}

impl ChildPlan<'_> {
    // The PID output address is valid only during the synchronous callback.
    // Only a successful native clone call may yield a new owned descriptor.
    fn with_clone_args<T>(&self, call: impl FnOnce(&CloneArgs) -> T) -> (T, c_int) {
        let mut pidfd = -1;
        let args = CloneArgs {
            flags: CLONE_INTO_CGROUP | CLONE_PIDFD,
            pidfd: ptr::addr_of_mut!(pidfd) as u64,
            exit_signal: SIGCHLD,
            cgroup: self.directory.as_raw_fd() as u64,
            ..CloneArgs::default()
        };
        (call(&args), pidfd)
    }
}

struct ChildIdentity {
    pid: c_int,
    pidfd: OwnedFd,
}

struct PlacedChild {
    identity: ChildIdentity,
    ready_permit: Probe<OwnedFd>,
}

// No native implementation is supplied by this compile-only adapter.
// The port is inside the privileged trust boundary. It is not request input.
trait OneShotPort {
    // Apply the command policy to the original decoded plan before arming.
    // The first native proof may authorize only the pinned absolute fixture.
    fn authorize(&mut self, identity: &VerifiedIdentity, exec: &request::ExecPlan) -> Probe<()>;

    // Arm the proof's watchdog with the original owner and timer, and return
    // only once both watchdog and independent supervisor kill paths own access
    // to the same verified domain. No child may exist if arming returns Err.
    fn arm(&mut self, watch: LeaseWatch<'_>) -> Probe<ArmedDomain>;

    // Place atomically and retain the kernel-returned pidfd. An outer Err
    // means no clone succeeded. After a clone, return the exact child even
    // when readiness fails. A ready permit certifies trusted child readiness,
    // FD scrubbing and credential drop. A readiness error closes the writer.
    fn place_held(&mut self, domain: &ArmedDomain, child: ChildPlan<'_>) -> Probe<PlacedChild>;

    // Use the proof's held-to-released shared gate and its single permit byte.
    // An independent cancellation can win at either side of this observation.
    // Do not duplicate or retain the borrowed permit writer.
    fn commit_permit(
        &mut self,
        domain: &ArmedDomain,
        child: &ChildIdentity,
        permit_writer: &OwnedFd,
    ) -> Probe<()>;
}

struct ActiveRun {
    prepared: PreparedRun,
    domain: ArmedDomain,
    child: Option<ChildIdentity>,
}

impl ActiveRun {
    fn place_and_sample_release(&mut self, port: &mut impl OneShotPort) -> Probe<Decision> {
        self.domain.controls.revalidate()?;
        let decision = self.prepared.lease.sample()?.decision;
        if decision != Decision::Permit {
            return Ok(decision);
        }

        let PlacedChild {
            identity,
            ready_permit,
        } = port.place_held(
            &self.domain,
            ChildPlan {
                directory: &self.domain.controls.directory,
                identity: &self.prepared.identity,
                exec: &self.prepared.plan,
            },
        )?;
        let child = self.child.insert(identity);
        let permit_writer = ready_permit?;

        // The original timer and owner remain live in the watchdog while the
        // supervisor samples them again at the last release boundary.
        let decision = self.prepared.lease.sample()?.decision;
        if decision == Decision::Permit {
            self.domain.controls.revalidate()?;
            port.commit_permit(&self.domain, child, &permit_writer)?;
        }
        drop(permit_writer);
        Ok(decision)
    }
}

#[must_use = "an armed activation requires watchdog settlement or supervisor fallback"]
struct PendingSettlement {
    active: ActiveRun,
    // Permit records gate release only. Exec and terminal outcome are independent.
    release: Probe<Decision>,
}

fn activate(prepared: PreparedRun, port: &mut impl OneShotPort) -> Probe<PendingSettlement> {
    port.authorize(&prepared.identity, &prepared.plan)?;
    check(
        prepared.lease.sample()?.decision == Decision::Permit,
        "owner or deadline inactive before cgroup arming",
    )?;
    let domain = port.arm(LeaseWatch::from(&prepared))?;
    let mut active = ActiveRun {
        prepared,
        domain,
        child: None,
    };
    let release = active.place_and_sample_release(port);
    // Even a placement, observation or permit error retains the original
    // lease and armed authorities for bounded drain and reap by the caller.
    Ok(PendingSettlement { active, release })
}

#[cfg(test)]
mod metadata_check {
    use super::*;

    struct RefusingPort;

    impl OneShotPort for RefusingPort {
        fn authorize(
            &mut self,
            _identity: &VerifiedIdentity,
            _exec: &request::ExecPlan,
        ) -> Probe<()> {
            Err("metadata-only port never authorizes".into())
        }

        fn arm(&mut self, watch: LeaseWatch<'_>) -> Probe<ArmedDomain> {
            let _ = (
                watch.owner_pid,
                watch.owner.as_raw_fd(),
                watch.timer.as_raw_fd(),
                watch.deadline_ns,
            );
            Err("metadata-only port never arms".into())
        }

        fn place_held(&mut self, domain: &ArmedDomain, child: ChildPlan<'_>) -> Probe<PlacedChild> {
            let _ = (
                domain.controls.watchdog_kill.as_raw_fd(),
                domain.controls.supervisor_kill.as_raw_fd(),
                domain.controls.events.as_raw_fd(),
                domain.watchdog_pidfd.as_raw_fd(),
                child.identity.uid,
                child.identity.gid,
                child.identity.groups.as_slice(),
                child.exec.program(),
                child.exec.argv(),
            );
            let _ = child.with_clone_args(|args| (args.flags, args.cgroup, args.pidfd));
            Err("metadata-only port never places".into())
        }

        fn commit_permit(
            &mut self,
            _domain: &ArmedDomain,
            child: &ChildIdentity,
            permit_writer: &OwnedFd,
        ) -> Probe<()> {
            let _ = (
                child.pid,
                child.pidfd.as_raw_fd(),
                permit_writer.as_raw_fd(),
            );
            Err("metadata-only port never releases".into())
        }
    }

    #[test]
    fn exact_adapter_signature() {
        let _: fn(PreparedRun, &mut RefusingPort) -> Probe<PendingSettlement> = activate;
        let _: fn(PendingSettlement) -> (ActiveRun, Probe<Decision>) =
            |value| (value.active, value.release);
    }
}

#[path = "cgroup_authority.rs"]
mod cgroup_authority;
