# Prepared ordinary008 full-graph object compilation

PREPARED ONLY. The root and independent critic approved exact source candidate
9bee01632ab358b700abcbf1e10ae3899a9a659cd933caf989ce3c70f54ece37
for one ordinary whole-graph object/test-object compilation attempt. This plan
executes the native compiler and its version query only. It does not link or run
a compiled prototype executable, test harness, arming path, payload or root fixture.

The unchanged007 bounded staging/receipt arrangement is reused: Linux ordinary
user scope70s (control-group/SIGKILL), separate guest waiting client75s/kill-after3s,
Mac gtimeout80s/kill-after3s and Windows Job100s. Actual UID501, non-root primary
group, ARM64, exact current scope membership and effective RuntimeMax/KillMode/
KillSignal/SendSIGKILL properties must match before staging. SSH uses BatchMode,
strict known hosts and an8s connect timeout. There is no sudo, admin authentication,
account change, cgroup provision/write, concurrency probe or persistent installation.

Exact plan/command/payload buffers are hashed once and then used. The guest checks
the payload digest, exact source member set and every source length/hash before
compilation inside a fresh private UID501 mode0700 scratch. The native Rust1.99
compiler must retain SHA
b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f,
as recorded by the previous ordinary007 qualification. Its version and native
environment are recorded. Object generation uses the real transport.rs module
graph, edition2021, -D warnings and --emit=obj, first without --test and then
with --test. The outputs are activation-main.o and activation-tests.o. There is
no executable or test invocation after these compiler commands.

Both compile commands must exit0 and produce hashed object receipts. Source
hashes are checked again after compilation. Streaming raw outputs/exits and a
complete retained-artifact inventory are preserved on success or failure. This
command does not clean scratch files; archive and hash-verify everything before
a separately bounded ordinary identity-checked cleanup. Do not retry under this
attempt ID or use root to recover from a compilation refusal.

The result can establish native compiler acceptance of the actual owning API and
updated signature checks. It cannot establish runtime ArmingFailure behavior,
watchdog/clone contracts, error-path reaping, populated settlement or production
readiness. No metadata signature check fabricates a PID, child or DomainControls.
The original007 runtime controls are merely compiled in the test object and are
not rerun or counted as008 runtime tests. Typed error custody holds on returned
paths by source/types; it is not automatic Drop or process-death protection.
