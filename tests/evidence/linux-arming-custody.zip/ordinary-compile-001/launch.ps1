param([Parameter(Mandatory=$true)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ApprovedPlanSha)
$ErrorActionPreference='Stop'
$directory=$PSScriptRoot
function Get-ByteSha([byte[]]$Bytes){
    [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($Bytes)).ToLowerInvariant()
}
$planBytes=[IO.File]::ReadAllBytes((Join-Path $directory 'plan.json'))
if((Get-ByteSha $planBytes) -ne $ApprovedPlanSha.ToLowerInvariant()){throw 'Reviewed exact plan differs'}
$plan=[Text.Encoding]::UTF8.GetString($planBytes) | ConvertFrom-Json -AsHashtable
$snapshots=@{}
foreach($name in $plan.files.Keys){
    $bytes=[IO.File]::ReadAllBytes((Join-Path $directory $name))
    if((Get-ByteSha $bytes) -ne $plan.files[$name]){throw "Reviewed exact bytes differ: $name"}
    $snapshots[$name]=$bytes
}
foreach($path in $plan.local_executable_sha256.Keys){
    if((Get-FileHash -LiteralPath $path).Hash -ne $plan.local_executable_sha256[$path]){
        throw "Reviewed local executable differs: $path"
    }
}
$command=[Text.Encoding]::UTF8.GetString($snapshots['linux-command.txt'])
[byte[]]$payload=$snapshots['payload.json']
$info=[Diagnostics.ProcessStartInfo]::new()
$info.FileName='C:/Windows/System32/OpenSSH/ssh.exe'
$info.UseShellExecute=$false
$info.CreateNoWindow=$true
$info.RedirectStandardInput=$true
$info.RedirectStandardOutput=$true
$info.RedirectStandardError=$true
foreach($argument in '-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8','peters-mac-mini',$command){
    $info.ArgumentList.Add($argument)
}
$out=[IO.File]::Open("$directory/linux.stdout.log",'CreateNew','Write','Read')
$err=[IO.File]::Open("$directory/linux.stderr.log",'CreateNew','Write','Read')
try {
    $process=[Diagnostics.Process]::Start($info)
    $copyOut=$process.StandardOutput.BaseStream.CopyToAsync($out)
    $copyErr=$process.StandardError.BaseStream.CopyToAsync($err)
    $transferError=$null
    try { $process.StandardInput.BaseStream.Write($payload,0,$payload.Length) }
    catch { $transferError=$_ }
    finally { $process.StandardInput.Close() }
    $process.WaitForExit()
    $copyOut.GetAwaiter().GetResult() | Out-Null
    $copyErr.GetAwaiter().GetResult() | Out-Null
    $result=$process.ExitCode
    [IO.File]::WriteAllText("$directory/linux.ssh-exit.txt",[string]$result)
    if($null -ne $transferError){
        [IO.File]::WriteAllText("$directory/transfer-error.txt",[string]$transferError)
        throw $transferError
    }
} finally {
    $out.Dispose()
    $err.Dispose()
}
exit $result
