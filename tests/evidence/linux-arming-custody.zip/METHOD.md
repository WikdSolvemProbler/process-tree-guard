# Typed arming-failure custody candidate008

SOURCE ONLY at preparation: no compiler, activation or runtime test has run for008.
This fresh graph copies007, including its termination-first settlement candidate
and corrected ARM64 authority constants. Only native_activation.rs changes in the
inherited Rust graph. All007 files and its qualification receipts remain intact.

OneShotPort::arm previously returned Probe<ArmedDomain>. A string error could not
retain the factory's actual CreatedLeaf, verified DomainControls or a newly created
watchdog child. activate used ? on that result, dropping its original PreparedRun,
including the original owner pidfd, lease timer, verified identity and owned argv.
This was an integration API gap; no production/native arming port existed or is
enabled by this change.

ArmFailure now has three resource-shaped variants:

* BeforeProvision holds an error only, under the explicit trusted-port contract
  that no domain, watchdog or payload resource has been created.
* Provision owns the actual cgroup_authority::ProvisionFailure, preserving its
  actual optional CreatedLeaf and diagnostic. A factory failure before creation
  may legitimately have created=None; the exact result is retained.
* VerifiedDomain owns the actual DomainControls, its diagnostic, and an optional
  DirectChild for a watchdog that has already been created. The port must not
  create that watchdog until it has verified controls. Readiness or later arming
  failures must return the actual child ownership with those controls.

ArmedDomain now owns a DirectChild watchdog rather than a bare pidfd. DirectChild
contains both the kernel child PID and its owned pidfd, and is shared with the
payload child record. Its private unsafe constructor is reserved for the trusted
future native clone path and requires the PID and newly owned pidfd from the same
successful direct-child clone, with exclusive wait/reap ownership. It accepts no
PID alone and is never called by these metadata checks. The constructor states
the native integration obligation; it is not a runtime identity-verification
implementation or evidence that every future native path satisfies it.

activate returns Result<PendingSettlement,ActivationFailure>. Both pre-arm and
arming errors retain the original PreparedRun. An arming error additionally owns
the entire actual ArmFailure. The explicit match on arm replaces the erasing ?.
Successful activation and release-error retention in PendingSettlement remain
unchanged. No error type derives Debug or implements Display for the retained
PreparedRun, avoiding incidental argv/credential-plan dumps.

The existing compile-only adapter signature check is updated to the new actual
types. It checks the activation return type, private clone constructor signature,
actual ProvisionFailure conversion, and PreparedRun+ArmFailure ownership together.
It does not create fake DomainControls, fake child identities, enum/string test
facsimiles or live arming resources. No new behavioral test is added, and the
four007 settlement controls remain byte-identical. A future qualification here
should compile ordinary and test object code for the full real native module
graph without executing any harness, payload, ignored root fixture or activation.

Limits are explicit. These types retain resources on returned error paths; they
do not prove that a nonexistent native implementation obeys the BeforeProvision
or clone contracts. Dropping either error closes its owned descriptors; no Drop
is presented as termination, reaping or automatic settlement. Panic/process death,
watchdog readiness, populated cleanup and exact child reaping still require native
integration and independent finite watchdog coverage. The next separate component
is a consuming PendingSettlement/arming-failure orchestration path that reaches a
verified terminal result or explicit retained quarantine. No production backend,
daemon, administrator test or rejected concurrency experiment is introduced.
