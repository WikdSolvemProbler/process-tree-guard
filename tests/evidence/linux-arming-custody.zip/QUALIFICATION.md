# Typed Linux arming custody: source and native compiler evidence

Candidate008 changes only native_activation.rs in the inherited007 Rust graph.
OneShotPort::arm now returns an owning ArmFailure: an explicit pre-provision
refusal, the actual ProvisionFailure with its actual optional CreatedLeaf, or the
actual verified controls with any already-created direct watchdog child. The
watchdog owns both PID and pidfd through DirectChild. The private unsafe clone
constructor requires a matching native clone result and exclusive reap ownership;
it is not called by these checks. activate explicitly retains the original
PreparedRun, owner pidfd, absolute timer, identity and argv with its typed error.
There is no automatic Drop cleanup or Debug/Display dump of the retained plan.

The root review and independent critic approved exact source-candidate.json
SHA9bee01632ab358b700abcbf1e10ae3899a9a659cd933caf989ce3c70f54ece37
for bounded ordinary full-graph/test-object compilation only. REVIEW.json records
the scope and remaining obligations. No objection remained for that narrow
compiler-acceptance scope. These approvals do not establish that any future
native arming implementation obeys the BeforeProvision or clone contracts.

Exactly one ordinary Linux ARM64 VM attempt ran under plan
6042d1566a7cb858e42c4e2984742d312d98dc24f0023a6d09dcdcae4e4a5413.
The environment was Linux6.8.0-147-generic. The Rust1.99 compiler retained SHA
b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f.
The actual current user scope was verified to use RuntimeMax70s, control-group
termination, KillSignal9 and SendSIGKILLyes before staging. Independent guest
waiting-client75s, Mac80s and Windows Job100s deadlines bounded the whole chain.
Every source length/hash was checked before compilation and again afterward.

The compiler queried its version and compiled the real transport.rs module graph
with edition2021, -D warnings and --emit=obj twice: ordinary and with --test. Both
commands returned0 with empty compiler stdout/stderr. No compiled prototype was
linked or invoked, and no test harness or activation path executed. The signature
checks were compiled, not run. The four007 runtime controls were merely included
in the test object; none is counted as an008 runtime test.

The preserved outputs are ELF64 little-endian relocatable ARM64 objects:

* activation-main.o:1,013,856bytes; SHA
  f51bfb540499019ec95fc29bf2cb2c389d8fb0d09f9c356ffced4598051daf7e.
* activation-tests.o:1,089,016bytes; SHA
  360a330b5600ad59e2a11b465f27788d02b508173b4985ccc97e9ba93505252b.

Local header inspection confirmed relocatable ELF type1 and machine183 for both
without executing either object. Raw native context, exact source/payload/tool
pins, commands, compiler version, child PIDs, exits, streams and both object bytes
are preserved. All13 reviewed candidate entries retain their exact hashes/lengths.
The source-only METHOD/source snapshot describe preparation chronology and remain
unchanged; RESULTS.json records the subsequent actual compilation and cleanup.
The original007 native_activation.rs is included as a baseline, and its full
qualified archive remains bound by SHA
eda65f3210dbdc12a72b9e0f9ec4ca76ab10f94aaf348b674e446d9075e5df12.

Before removal, an independently bounded ordinary check found the original unit
not loaded/inactive, its exact cgroup path absent and all four recorded controller/
compiler PIDs absent. It opened only the original private UID501 scratch
/tmp/ptg-authority-linux-008.aalggmx0, dev64769 inode1052343, through retained
no-follow descriptors. Every artifact matched the exact inventory, lengths,
completion hashes and recorded inodes. All24 remote files were downloaded and
locally hash-verified. PID absence is reported without inventing creation times.

A complete pre-removal ZIP was checked before cleanup: SHA
827aa1a47637d06945e8b823a2ee97ef6e0fa9d68d99b833566273a68272460e,
1,636,664bytes,63members. The subsequent ordinary cleanup repeated worker/scope
checks and compared exact held directory/file identities, sizes, hashes, modes
and complete preserved inventory. It unlinked only those24 files, removed only
their verified empty directories and confirmed the original scratch directory absent.
Every removal is recorded. There was no root, recursive guessed-path or process
termination cleanup. The local pre-removal ZIP is not nested in this public ZIP;
its evidence members appear directly with the later cleanup receipts.

The result establishes native compiler acceptance of the actual owning API, not
native error-path custody behavior. The port still has no native arming
implementation. BeforeProvision and successful-clone promises remain trusted
implementation contracts. Returned ownership does not ensure settlement if an
error is dropped or the process dies. A consuming owner for arming failures and
PendingSettlement, populated cgroup drainage, exact payload/watchdog reaping and
independent finite watchdog coverage remain open. No production backend was
enabled, no payload/root/cgroup-write test or rejected concurrency experiment ran,
and no performance or kernel-floor qualification is claimed.

INDEX.json records exact lengths and SHA-256 for every other public archive
member. Archive CRC, member set and exact bytes are verified. No tracked
documentation or Git history was changed by this task.
