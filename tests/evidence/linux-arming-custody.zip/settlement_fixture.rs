// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

use super::*;

const FIXED_ROOT: &CStr = c"process-tree-guard";
const FIXTURE_BUDGET_NS: u64 = 2_000_000_000;

enum LeafFailure {
    Provision(ProvisionFailure),
    Settle(SettlementQuarantine),
}

struct FixtureCustody {
    parent: Option<OwnedFd>,
    directory: Option<OwnedFd>,
    identity: Option<Identity>,
    created: bool,
    removed: bool,
    leaf: Option<LeafFailure>,
}

struct FixtureQuarantine {
    custody: FixtureCustody,
    stage: &'static str,
    error: String,
}

fn root_fixture() -> std::result::Result<(), FixtureQuarantine> {
    let mut custody = FixtureCustody {
        parent: None,
        directory: None,
        identity: None,
        created: false,
        removed: false,
        leaf: None,
    };
    let mut stage = "credentials";
    let result = (|| -> Probe<()> {
        check(
            unsafe { getuid() } == 0 && unsafe { geteuid() } == 0,
            "empty-domain fixture requires reviewed trusted root activation",
        )?;
        stage = "open-hierarchy";
        let root = directory(AT_FDCWD, c"/")?;
        let sys = directory(root.as_raw_fd(), c"sys")?;
        let fs = directory(sys.as_raw_fd(), c"fs")?;
        let hierarchy = directory(fs.as_raw_fd(), c"cgroup")?;
        require_cgroup2(&hierarchy)?;
        let _migration = control(&hierarchy, c"cgroup.procs", false)?;
        custody.parent = Some(hierarchy);

        stage = "exclusive-fixed-root";
        let parent = custody
            .parent
            .as_ref()
            .ok_or("missing hierarchy descriptor")?;
        native(os_result(
            unsafe { fd_mkdirat(parent.as_raw_fd(), FIXED_ROOT.as_ptr(), 0o700) } as isize,
        ))?;
        custody.created = true;
        // A preexisting name fails the exclusive mkdir. It is never adopted.
        stage = "bind-fixed-root";
        let held = directory(parent.as_raw_fd(), FIXED_ROOT)?;
        require_cgroup2(&held)?;
        let identity = require_root_mode(&descriptor_stat(&held)?, S_IFDIR)?;
        require_name_matches(parent.as_raw_fd(), FIXED_ROOT, &held)?;
        require_fresh(&held)?;
        custody.identity = Some(identity);
        custody.directory = Some(held);
        println!("fixture_root_created identity={identity:?} payload_executions=0");

        stage = "factory";
        let until = boottime_ns()?
            .checked_add(FIXTURE_BUDGET_NS)
            .ok_or("fixture deadline overflow")?;
        let controls = match provision() {
            Ok(controls) => controls,
            Err(error) => {
                println!(
                    "factory_refused created_leaf={} error={}",
                    error
                        .created
                        .as_ref()
                        .map_or(String::from("none"), |leaf| leaf
                            .name()
                            .to_string_lossy()
                            .into_owned()),
                    error.error,
                );
                custody.leaf = Some(LeafFailure::Provision(error));
                return Err("factory refused; root and any created leaf are quarantined".into());
            }
        };
        println!(
            "factory_bound leaf={} identity={:?}",
            controls.provenance.creation.name.to_string_lossy(),
            controls.provenance.identity,
        );
        stage = "settle-leaf";
        match controls.settle(until) {
            Ok(receipt) => println!("leaf_removed {receipt:?}"),
            Err(error) => {
                println!(
                    "leaf_quarantined stage={:?} removal_succeeded={} kill_outcome={:?} error={}",
                    error.stage, error.removal_succeeded, error.kill_outcome, error.error,
                );
                custody.leaf = Some(LeafFailure::Settle(error));
                return Err("leaf settlement refused; custody retained".into());
            }
        }

        stage = "remove-fixed-root";
        let deadline = Deadline::arm(
            boottime_ns()?
                .checked_add(FIXTURE_BUDGET_NS)
                .ok_or("root deadline overflow")?,
        )?;
        let parent = custody
            .parent
            .as_ref()
            .ok_or("missing retained hierarchy")?;
        let directory = custody
            .directory
            .as_ref()
            .ok_or("missing retained fixed root")?;
        let identity = custody.identity.ok_or("missing fixed-root identity")?;
        require_fresh(directory)?;
        deadline.check()?;
        unlink_exact(parent, FIXED_ROOT, directory, identity)?;
        custody.removed = true;
        stage = "confirm-fixed-root";
        require_name_absent(parent, FIXED_ROOT)?;
        deadline.check()?;
        println!(
            "fixture_complete root_removed=true root_identity={identity:?} \
             payload_executions=0 leaf_concurrency=0",
        );
        Ok(())
    })();
    result.map_err(|error| FixtureQuarantine {
        custody,
        stage,
        error,
    })
}

#[test]
fn settlement_api_typecheck() {
    let _: fn(DomainControls, u64) -> std::result::Result<RemovedDomain, SettlementQuarantine> =
        DomainControls::settle;
}

#[test]
#[ignore = "requires reviewed trusted disposable VM root; sequential empty-domain component only"]
fn root_empty_domain_settlement() {
    if let Err(failure) = root_fixture() {
        let leaf_state = match failure.custody.leaf.as_ref() {
            None => "none",
            Some(LeafFailure::Provision(error)) => {
                eprintln!("provision_quarantine_error={}", error.error);
                "created-leaf-token"
            }
            Some(LeafFailure::Settle(error)) => {
                eprintln!(
                    "settlement_quarantine_name={} stage={:?} kill_outcome={:?} error={}",
                    error.controls.provenance.creation.name.to_string_lossy(),
                    error.stage,
                    error.kill_outcome,
                    error.error,
                );
                "domain-controls"
            }
        };
        eprintln!(
            "fixture_refused stage={} root_created={} root_removed={} root_identity={:?} \
             leaf_custody={leaf_state} error={}",
            failure.stage,
            failure.custody.created,
            failure.custody.removed,
            failure.custody.identity,
            failure.error,
        );
        // This prepared test deliberately does not guess a path to remove on
        // error. Report uncertain directory artifacts and quarantine the VM.
        panic!("empty-domain fixture refused; directory quarantine reported");
    }
}
