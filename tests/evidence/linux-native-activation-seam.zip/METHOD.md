# Linux native activation seam

This scratch candidate compiles the authenticated launch adapter against the exact PreparedRun and lease definitions from the prior bridge. The only edit to the copied native fixture is a private module declaration. The existing executable entry point still runs the scripted probe. No adapter entry point is called by that fixture.

The adapter takes ownership of PreparedRun, asks the trusted port to apply command policy to the original decoded executable and argv, and checks the original owner and deadline before any cgroup arming. The port receives the original pidfd and absolute timer as borrowed descriptors. The adapter does not duplicate them, reopen by numeric PID, or construct a new deadline.

The proposed native port must acquire its directory, separate watchdog and supervisor kill controls, and events control from one fresh verified root-owned cgroup v2 domain. Those descriptors must come from trusted, descriptor-relative provisioning and must never originate in a client packet or be inherited by the eventual payload. Arming returns only after the watchdog is active with the original lease and the supervisor holds its independent recovery authority. All arm errors occur before any payload clone.

The clone plan borrows that exact directory descriptor and passes the original verified identity and owned argv through to the port. The clone3 argument image uses the Linux 5.14 version-two layout, CLONE_INTO_CGROUP and CLONE_PIDFD. The pidfd output slot is valid only during the immediate syscall callback. After a successful clone, even failed readiness must preserve the returned child pidfd and close the permit without release. A ready permit represents the trusted trampoline's placement, descriptor cleanup and credential checks. The supervisor samples the original lease again before a single shared-gate commit. The watchdog must keep monitoring across this sample and permit delivery.

Every post-arm outcome returns the owned controls and lease for settlement. A successful permit records only the gate outcome. The caller must separately observe exec or exec errno and terminal status. Drain requires verified cgroup.events populated=0, exact pidfd exit/reap, and a finite independent cleanup deadline. If proof is incomplete, the native implementation must refuse and quarantine the leaf. The adapter types express the data flow and preserve cleanup authority. They do not implement the root provisioner, watchdog, syscall, gate, terminal settlement, or enforce honest descriptor provenance on an untrusted port.

The archived fixed-command Linux ARM64 6.8 proof establishes the watchdog behavior in that fixture. It does not validate this generic bridge or the Linux 5.14 support floor. Preserve the previous alias denial and supervisor/watchdog failure controls for a later separately authorized native integration.

[Linux v5.14 clone3 UAPI](https://github.com/torvalds/linux/blob/v5.14/include/uapi/linux/sched.h#L42-L103) · [Linux v5.14 cgroup attachment](https://github.com/torvalds/linux/blob/v5.14/kernel/cgroup/cgroup.c#L5670-L5736) · [Linux v5.14 fork and kill interaction](https://github.com/torvalds/linux/blob/v5.14/kernel/cgroup/cgroup.c#L5895-L5925) · [Archived Linux lifecycle proof](https://github.com/WikdSolvemProbler/process-tree-guard/blob/f0b1e4e/tests/evidence/linux-rust-supervision-20261106.zip)

## Local verification

On Windows GNU, use the copied prior Unix API stand-ins and compile the real adapter module with the command below. Repeat with `--test` to type-check its instantiation with a port that always refuses. The stand-ins substitute the Unix standard-library descriptor and socket types only. No binary is linked and the test is not executed.

```text
rustc --edition=2021 -D warnings --emit=metadata transport-metadata-only.rs -o activation-seam.rmeta
rustc --edition=2021 -D warnings --test --emit=metadata transport-metadata-only.rs -o activation-seam-test.rmeta
rustfmt --edition 2021 --check native_activation.rs
```
