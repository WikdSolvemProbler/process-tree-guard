"""Three no-workload observer snapshots with explicit instrumentation overhead."""
from collections import Counter
from contextlib import contextmanager
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
FIXED = HERE.with_name("issue7-quiet-launch-013")
sys.path.insert(0, str(FIXED))
import inventory_gate as gate
from image_policy import ALLOWED
from quiet_sampler import stamp, warm_job_query

APPROVED = "313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae"
active = False
spans = []
stack = []
context = {"pid": None, "path": None}
fd_metadata = {}


def source_hashes(manifest):
    hashes = {}
    for name, expected in manifest["file_sha256"].items():
        actual = hashlib.sha256((FIXED / name).read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError(f"frozen source changed: {name}")
        hashes[name] = actual
    return hashes


@contextmanager
def measured(stage, **metadata):
    if not active:
        yield None
        return
    row = dict(stage=stage, parent=stack[-1] if stack else None,
               pid=context["pid"], image_path=context["path"], **metadata)
    index = len(spans)
    spans.append(row)
    stack.append(index)
    row["perf_begin_ns"] = time.perf_counter_ns()
    row["cpu_begin_ns"] = time.process_time_ns()
    try:
        yield row
    except BaseException as error:
        row["error"] = type(error).__name__
        raise
    finally:
        row["cpu_end_ns"] = time.process_time_ns()
        row["perf_end_ns"] = time.perf_counter_ns()
        stack.pop()


def wrap(owner, name, stage):
    original = getattr(owner, name)

    def call(*args, **kwargs):
        with measured(stage):
            return original(*args, **kwargs)
    setattr(owner, name, call)


def instrument():
    for name, stage in (
        ("create_snapshot", "snapshot_api"), ("first_process", "snapshot_first"),
        ("next_process", "snapshot_next"), ("precise_filetime", "snapshot_clock"),
        ("entries", "snapshot_enumeration"), ("identity", "process_identity"),
        ("process_image", "process_image_api"), ("process_times", "process_times_api"),
        ("is_alive", "process_liveness"), ("is_member", "process_membership"),
    ):
        wrap(gate, name, stage)
    original_open = gate.open_exact

    @contextmanager
    def process_open(pid):
        previous = context["pid"]
        context["pid"] = pid
        manager = original_open(pid)
        try:
            with measured("process_open"):
                handle = manager.__enter__()
            try:
                yield handle
            finally:
                with measured("process_close"):
                    manager.__exit__(*sys.exc_info())
        finally:
            context["pid"] = previous
    gate.open_exact = process_open

    original_digest = gate.image_digest

    def image_digest(image):
        previous = context["path"]
        context["path"] = str(image)
        try:
            with measured("image_digest"):
                return original_digest(image)
        finally:
            context["path"] = previous
    gate.image_digest = image_digest
    original_stat = Path.stat

    def path_stat(path, *args, **kwargs):
        with measured("path_metadata", path=str(path)) as row:
            result = original_stat(path, *args, **kwargs)
            if row is not None:
                row["file_identity"] = [result.st_dev, result.st_ino]
                row["bytes"] = result.st_size
            return result
    Path.stat = path_stat
    original_fstat = os.fstat

    def file_stat(fd):
        with measured("handle_metadata") as row:
            result = original_fstat(fd)
            if active:
                fd_metadata[fd] = (result.st_dev, result.st_ino, result.st_size)
            if row is not None:
                row["file_identity"] = [result.st_dev, result.st_ino]
                row["bytes"] = result.st_size
            return result
    os.fstat = file_stat
    original_path_open = Path.open

    def path_open(path, *args, **kwargs):
        with measured("path_open", path=str(path)):
            return original_path_open(path, *args, **kwargs)
    Path.open = path_open
    original_hash = hashlib.file_digest

    def file_hash(file, *args, **kwargs):
        with measured("content_hash") as row:
            if row is not None:
                device, inode, size = fd_metadata[file.fileno()]
                row["file_identity"] = [device, inode]
                row["bytes"] = size
            return original_hash(file, *args, **kwargs)
    hashlib.file_digest = file_hash


def summarize():
    totals = {}
    for index, row in enumerate(spans):
        elapsed = row["perf_end_ns"] - row["perf_begin_ns"]
        children = sum(child["perf_end_ns"] - child["perf_begin_ns"]
                       for child in spans if child["parent"] == index)
        values = totals.setdefault(row["stage"], {"calls": 0, "inclusive_ns": 0,
                                                  "exclusive_ns": 0, "cpu_ns": 0})
        values["calls"] += 1
        values["inclusive_ns"] += elapsed
        values["exclusive_ns"] += elapsed - children
        values["cpu_ns"] += row["cpu_end_ns"] - row["cpu_begin_ns"]
    hashes = [row for row in spans if row["stage"] == "content_hash"]
    return {
        "stages": totals,
        "hashed_bytes": sum(row["bytes"] for row in hashes),
        "unique_file_identities": len({tuple(row["file_identity"]) for row in hashes}),
        "image_path_counts": dict(Counter(row["image_path"] for row in hashes)),
        "slowest_leaf_spans": sorted(
            [row for row in spans if row["stage"] in (
                "snapshot_api", "process_image_api", "process_times_api", "path_open",
                "path_metadata", "handle_metadata", "content_hash", "raw_json_emit_flush")],
            key=lambda row: row["perf_end_ns"] - row["perf_begin_ns"], reverse=True)[:12],
    }


def main():
    global active, spans
    raw = (FIXED / "manifest.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != APPROVED:
        raise ValueError("manifest differs before no-workload diagnostic")
    manifest = json.loads(raw)
    before = source_hashes(manifest)
    origin = time.perf_counter_ns()
    deadline = origin + 35_000_000_000
    records = []
    code = 0
    with (HERE / "profile-001.jsonl").open("x", encoding="utf-8") as output, +            (HERE / "raw-sample-001.jsonl").open("x", encoding="utf-8") as samples:
        print(json.dumps({"kind": "context", "manifest_sha256": APPROVED,
                          "source_sha256": before, "snapshots": 3, "spacing_seconds": 5,
                          "instrumented": True, "benchmark_slots": 0,
                          "scope": "observer pipeline diagnostic; instrumentation adds cost",
                          "cpu_measurement": "process_time_ns, native quantization retained"}),
              file=output, flush=True)
        try:
            with gate.enclosing_guard(manifest["tools"]["outer_guard"]["path"]) as guard:
                warm_job_query()
                instrument()
                origin = time.perf_counter_ns()
                for index in range(3):
                    target = origin + index * 5_000_000_000
                    remaining = target - time.perf_counter_ns()
                    if remaining > 0:
                        time.sleep(remaining / 1e9)
                    if time.perf_counter_ns() >= deadline:
                        raise TimeoutError("35-second absolute diagnostic budget")
                    spans = []
                    active = True
                    start = time.perf_counter_ns()
                    cpu_start = time.process_time_ns()
                    try:
                        with measured("stamp"):
                            sample = stamp()
                        with measured("raw_json_emit_flush"):
                            print(json.dumps({"kind": "sample", "phase": "pre",
                                              "endpoint": False, "raw": asdict(sample),
                                              "utc_ns": time.time_ns()}),
                                  file=samples, flush=True)
                        inventory_begin = time.perf_counter_ns()
                        with measured("inventory"):
                            rows = gate.inventory(guard, None, manifest["image_policy"])
                        finished = time.perf_counter_ns()
                    finally:
                        active = False
                    record = {
                        "kind": "profile", "index": index, "perf_begin_ns": start,
                        "finished_ns": finished, "process_cpu_ns": time.process_time_ns() - cpu_start,
                        "counter_read_ns": sample.read_ns,
                        "sample_to_inventory_begin_ns": inventory_begin - sample.monotonic_ns,
                        "inventory_ns": finished - inventory_begin,
                        "whole_bracket_ns": finished - sample.monotonic_ns,
                        "rows": rows, "all_allowed": all(row["state"] in ALLOWED for row in rows),
                        "stage_summary": summarize(), "spans": spans,
                    }
                    records.append(record)
                    print(json.dumps(record), file=output, flush=True)
        except BaseException as error:
            code = 1
            active = False
            print(json.dumps({"kind": "error", "error": f"{type(error).__name__}: {error}",
                              "partial_spans": spans}), file=output, flush=True)
        finally:
            after = source_hashes(manifest)
            print(json.dumps({"kind": "terminal", "code": code, "snapshots": len(records),
                              "frozen_sources_unchanged": before == after,
                              "source_sha256": after, "benchmark_slots": 0}),
                  file=output, flush=True)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
