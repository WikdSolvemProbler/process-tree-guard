# Rejected exploratory Windows laptop capture 011

This archive preserves the complete saved capture and source of attempt 011, its exact input manifests and harness source, the preregistered index and receipt, and independent forensic and cleanup records. All original capture files, including provisional run metadata, remain byte-for-byte unchanged. No missing result was synthesized and no benchmark slot was repeated.

The original terminal record rejects the attempt with "Rejected: live telemetry capture refused", telemetry_pass=false and package_complete=false. The final during window records system_cpu_counter_order. Its paired GetSystemTimes values decrease by 156250 FILETIME ticks for both idle and kernel, with unchanged user ticks. The recorded rejection is this counter-order error. The source and raw samples are preserved for diagnosis.

## Persisted progress

The saved metadata and observation file agree on 91 of 1940 planned slots. The complete saved prefix contains all 36 controls and 55 warmups, with 14 fast, 14 malformed, 11 scaling and 16 kill warmups. It contains zero measured slots. Every persisted slot matches its position in the saved seeded order.

There are 1849 planned slots without persisted observations. The next planned slot, numbered 92, is a Nuewframe kill warmup in DETACHED context with rep 5. The last inventory contains its timeout PID 51652 and fixture children 2208 and 61228 inside the campaign Job. That slot has no observation and is retained as an interrupted slot. Later planned slots have no persisted completion evidence.

The original run.json remains provisional=true and campaign_status=incomplete, with pricing_probe_observations=0 and null standing-loss and freeze-gate counts. The capture directory has no finalized report, pricing result or claim ledger. It must not be used for latency, parity, ranking, campaign completion or strict quiet-host conclusions.

## Raw non-ok records

There are 85 ok outcomes and six descendant-survived outcomes. All six non-ok records are Nuewframe warmups. The full original rows, including argv, process markers, native exit, resources and per-slot Job receipt, are retained in observations.jsonl and in the separately derived non-ok-slots.json.

| One-based slot | Path | Context | Rep |
| --- | --- | --- | --- |
| 41 | scale | DETACHED | 2 |
| 59 | kill | NO_WINDOW | 1 |
| 65 | kill | DETACHED | 8 |
| 70 | scale | NO_WINDOW | 2 |
| 77 | kill | NO_WINDOW | 7 |
| 89 | kill | DETACHED | 6 |

Every one of the 91 persisted per-slot Job receipts records active_after=0. Twenty-three record explicit termination before reaching zero. The during-capture abort receipt records active_before=5, terminated=true and active_after=0. These recorded outcomes remain observations from a rejected partial run.

## Independent cleanup

A separate finite Windows Job invocation performed read-only native checks against all 174 exact identities recorded as pinned_enclosing_guard or campaign_member. For each recorded PID and integer creation FILETIME it used OpenProcess with query/synchronize rights, GetProcessTimes when available and a zero-time native wait. All 174 returned ERROR_INVALID_PARAMETER (87) from OpenProcess, indicating the numeric PID was absent at inspection. The exact recorded guard is PID 30116 with creation FILETIME 134384941592640944. The campaign worker is PID 45692 with creation FILETIME 134384942198668980. Values were parsed as Python integers to preserve all bits.

The binding records observer PID 54416 without a creation FILETIME. It was therefore excluded from the exact-identity conclusion. The original outer-session terminal exit 1 is recorded as parent-reported context, with session ID 72267. The native cleanup results and the original campaign Job zero receipt provide the stated process-tree evidence. No process was signalled, terminated or matched by a general process name during the independent check.

The forensic script verified manifest-bound source and terminal-bound capture digests, then re-read every original source and capture file to verify that inspection had not changed them. The packaging script repeats that check and verifies every archived byte.

## Reproduction and anchors

The capture's binding and manifest retain exact arguments, source hashes, executable fingerprints, configuration, seed, environment hashes, finite deadlines and collection policy. The original full capture had a 6900-second outer guard deadline and a 6600-second during deadline. The later forensic check used a separate 45-second Job deadline.

The frozen protocol archive is windows-laptop-exploratory-protocol-011.zip with SHA-256 f8770781e11b87c2ed592ab8e56ae6487a86c56e9ce11c4de738965bb53cf5a0. Its original INDEX.json and PREREGISTRATION.json are included here, along with the current post-packaging preregistration receipt. The benchmark executables remain in that existing protocol archive and are referenced by their original content hashes, keeping this preservation package small. All pinned non-executable campaign inputs, source.tar, input checker and input manifest are included.

The top-level INDEX.json lists archive paths, byte lengths and SHA-256 hashes for every other member. Original files retain their repository-relative paths. Derived inspection files are stored separately under target/codex-security/issue7-attempt-011-forensics-001. Strict protocol 007 and issue #7 remain open.
