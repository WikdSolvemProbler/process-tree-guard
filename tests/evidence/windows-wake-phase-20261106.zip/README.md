# Windows Wake startup phase diagnostic

The observed-load diagnostic on 6 November 2026 completed all 324 launches.
Calibration failed in seven places. The untouched-fixture main-minus-Wake
p90 contrast was +2.6335 ms, below the preregistered +3.9079 to +11.9079 ms
anchor range, and the second-half contrast was -2.6100 ms. Five arm-level p90
perturbation checks also failed. No dominant phase was established. This
diagnostic does not change the earlier 16-contrast result or complete the
separate quiet-host acceptance.

`phase/` contains the exact protocol, schedule, sources, manifests, admissions,
raw captures and external terminal receipts. The first attempt stopped
before row zero because its admission omitted the protocol hash. The completed
attempt and its original analysis are retained without edits. The archive
also contains the fixture build provenance, native qualification, and
manifest-bound support and experimental executables. The public environment
summary retains the sanitized block digest and launch-context difference.
Private per-key probes and raw environment values are omitted.

## Replay on Windows

Extract the full archive to a short path. Use a finite whole-process guard
and choose a fresh output outside the package. The frozen analyzer
independently hashes the historical Python and PowerShell images. These two
runtime executables are not redistributed. Supply exact local copies with
`--python-image` and `--pwsh-image`. If the executing interpreter itself
matches the recorded digest, `--python-image` can be omitted. The expected
hashes are in `replay-paths.json` under `external_images`.

```powershell
process-tree-guard --timeout 180 -- python -B .\replay.py --pwsh-image C:\path\pwsh.exe --out C:\Temp\wake-phase-replay.json
```

The wrapper verifies all SHA-256 inventory entries and executes the unchanged
analysis using its historical path identities. Only exact bound evidence file
reads are redirected to local copies. Replay verifies the admission and raw
receipts for the completed attempt and compares its result byte for byte with
the archived analysis. It starts no workloads.
