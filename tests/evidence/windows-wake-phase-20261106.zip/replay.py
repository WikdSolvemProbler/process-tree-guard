"""Replay the unchanged Windows phase analyzer against extracted evidence."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verify_inventory():
    seen = set()
    for line in (HERE / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        path = (HERE / relative).resolve()
        if path == HERE or not path.is_relative_to(HERE) or path in seen or sha(path) != expected:
            raise ValueError(f"package checksum mismatch: {relative}")
        seen.add(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--python-image", type=Path, default=Path(sys.executable))
    parser.add_argument("--pwsh-image", type=Path, required=True)
    args = parser.parse_args()
    if os.name != "nt":
        parser.error("the frozen analyzer verifies Windows-native historical paths")
    out = args.out.resolve()
    if out.is_relative_to(HERE) or out.exists():
        parser.error("choose a fresh destination outside the evidence package")
    verify_inventory()
    index = json.loads((HERE / "replay-paths.json").read_bytes())
    key = lambda path: os.path.normcase(os.fspath(path))
    redirects = {key(old): HERE / relative for old, relative in index["historical_paths"].items()}
    for role, image in (("python", args.python_image), ("bootstrap_shell", args.pwsh_image)):
        entry = index["external_images"][role]
        image = image.resolve()
        if sha(image) != entry["sha256"]:
            raise ValueError(f"{role} executable digest differs from the frozen manifest")
        redirects[key(entry["path"])] = image
    locations = index["replay_inputs"]
    historical_source = Path(locations["analysis"]["path"])
    exact_source = redirects[key(historical_source)].read_bytes()
    if hashlib.sha256(exact_source).hexdigest() != locations["analysis"]["sha256"]:
        raise ValueError("frozen analyzer source digest differs")
    argv = [str(historical_source)]
    for role in ("manifest", "admission", "capture", "terminal"):
        location = locations[role]
        argv.extend((f"--{role}", location["path"], f"--{role}-sha256", location["sha256"]))
    argv.extend(("--out", str(out)))
    original_read, original_stat = Path.read_bytes, Path.stat
    original_iterdir, original_resolve = Path.iterdir, Path.resolve
    original_argv = sys.argv

    def mapped(path):
        return redirects.get(key(path), path)

    def read_bound(path):
        return original_read(mapped(path))

    def stat_bound(path, *args, **kwargs):
        return original_stat(mapped(path), *args, **kwargs)

    def iterdir_bound(path):
        return original_iterdir(mapped(path))

    def resolve_bound(path, *args, **kwargs):
        return path if key(path) in redirects else original_resolve(path, *args, **kwargs)

    # Keep historical path identity in the original analysis and its argv.
    # Redirect only exact archived paths and the two separately verified images.
    try:
        Path.read_bytes, Path.stat = read_bound, stat_bound
        Path.iterdir, Path.resolve = iterdir_bound, resolve_bound
        sys.argv = argv
        exec(compile(exact_source, str(historical_source), "exec"),
             {"__name__": "__main__", "__file__": str(historical_source)})
    finally:
        sys.argv = original_argv
        Path.read_bytes, Path.stat = original_read, original_stat
        Path.iterdir, Path.resolve = original_iterdir, original_resolve
    expected = HERE / "phase/phase-analysis-002.json"
    if out.read_bytes() != expected.read_bytes():
        raise ValueError("frozen replay differs from the archived analysis bytes")
    print("Verified package and reproduced the phase analysis byte for byte.")


if __name__ == "__main__":
    main()
