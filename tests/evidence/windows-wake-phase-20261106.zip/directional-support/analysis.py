"""Analyze a complete MSVC development capture. Never launches a process."""

import argparse
from collections import defaultdict
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import random
import sys

_schedule_path = Path(__file__).with_name("schedule.py")
_schedule_source = _schedule_path.read_bytes()
_schedule_spec = importlib.util.spec_from_file_location("analysis_bound_schedule", _schedule_path)
schedule = importlib.util.module_from_spec(_schedule_spec)
exec(compile(_schedule_source, str(_schedule_path), "exec"), schedule.__dict__)
SCHEDULE_SOURCE_SHA = hashlib.sha256(_schedule_source).hexdigest()


LENGTHS = (4, 2, 8)
REPLICATES = 100_000
SEED_DOMAIN = b"wake-msvc-directional-mbb-v1"
STRATA = tuple((mode, workload) for mode in schedule.MODES for workload in schedule.WORKLOADS)
ENDPOINTS = ("raw_q50", "raw_q90", "overhead_q50", "overhead_q90")
CONTROL_IDS = ("exit-zero", "exit-seven", "exit-dword", "natural-leak", "forced-timeout")
CLEANUP_EXIT = 0xE0000071
BLOCKS = schedule.MACROBLOCKS
LANE_BITS = 8
DOT_SHIFT = LANE_BITS * (BLOCKS - 1)
LANE_MASK = (1 << LANE_BITS) - 1


def require(condition, message):
    if not condition:
        raise ValueError(message)


def positive_integer(value):
    return type(value) is int and value > 0


def is_int(value, expected):
    return type(value) is int and value == expected


def distinct_keys(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"duplicate JSON key: {key}")
        result[key] = value
    return result


def parse(raw):
    def reject_constant(value):
        raise ValueError(f"nonfinite JSON constant: {value}")

    def finite_float(value):
        parsed = float(value)
        require(math.isfinite(parsed), f"nonfinite JSON number: {value}")
        return parsed

    return json.loads(raw, object_pairs_hook=distinct_keys, parse_constant=reject_constant, parse_float=finite_float)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canon(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def valid_sha(value):
    return isinstance(value, str) and len(value) == 64 and all(
        char in "0123456789abcdef" for char in value)


def verify_admission(raw, expected_sha, manifest_sha):
    require(valid_sha(expected_sha) and sha(raw) == expected_sha, "admission digest mismatch")
    admission = parse(raw)
    require(admission.get("manifest_sha256") == manifest_sha
            and admission.get("timed_capture_authorized") is True, "no exact capture admission")
    critics = admission["critics"]
    require(type(critics) is list and len(critics) == 2
            and all(isinstance(row.get("reviewer"), str) and row["reviewer"] and row.get("objections") == []
                    for row in critics)
            and len({row["reviewer"] for row in critics}) == 2, "two exact zero-objection reviews required")


def verify_outer_receipt(manifest, capture):
    launch = manifest["launch"]
    outer = capture["outer_guards"]
    tail = capture["controller_argv"]
    require(type(tail) is list and len(tail) > 3 and all(isinstance(item, str) for item in tail)
            and tail[1] == "-B", "controller argv receipt is malformed")
    root = outer["root"]
    backup = outer["backup"]
    require(positive_integer(root.get("pid")) and positive_integer(backup.get("pid"))
            and root["pid"] != backup["pid"] and is_int(root.get("parent_pid"), backup["pid"])
            and positive_integer(root.get("creation_filetime")) and positive_integer(backup.get("creation_filetime"))
            and root["creation_filetime"] >= backup["creation_filetime"], "outer process lineage receipt mismatch")
    for role, observed in (("root", root), ("backup", backup)):
        seconds = launch[f"{role}_seconds"]
        image = launch[f"{role}_path"]
        tail = [image, "--timeout", str(seconds), "--", *tail]
        require(observed.get("argv") == tail and observed.get("sha256") == launch[f"{role}_sha256"]
                and is_int(observed.get("timeout_seconds"), seconds)
                and str(Path(observed["path"])).casefold() == str(Path(image)).casefold(),
                f"{role} outer receipt differs from manifest")


def verify_asset_holds(manifest, capture):
    bindings = manifest["runtime_hold_bindings"]
    receipt = capture["asset_hold"]
    require(receipt.get("share_mode") == "FILE_SHARE_READ", "runtime share-mode receipt mismatch")
    before, after = receipt["before"], receipt["after"]
    require(set(before) == set(after) == set(bindings), "runtime hold role population mismatch")
    for role, expected in bindings.items():
        initial = before[role]
        require(initial.get("path") == expected["path"]
                and isinstance(initial.get("final_path"), str)
                and initial["final_path"].casefold() == expected["path"].casefold()
                and valid_sha(expected["sha256"]) and initial.get("sha256") == expected["sha256"]
                and type(initial.get("volume")) is int and initial["volume"] >= 0
                and positive_integer(initial.get("file_id")) and positive_integer(initial.get("size")),
                f"{role} initial held bytes or identity mismatch")
        require(canon(after[role]) == canon({"held": initial, "reopened_path": initial}),
                f"{role} retained/reopened runtime file evidence differs")


def validate_control(row, control):
    root = row["root_before_cleanup"]
    final = row["root_after_cleanup"]
    expect_exit = {"exit-zero": 0, "exit-seven": 7, "exit-dword": 0xffffffff, "natural-leak": 0}
    require(row["streams_before_cleanup"] == {"stdout_hex": "", "stderr_hex": ""},
            "control emitted unexpected output")
    require(is_int(final.get("native_wait"), 0) and
            (root["pid"], root["creation_filetime"]) == (final["pid"], final["creation_filetime"]),
            "control original process final identity mismatch")
    if control == "forced-timeout":
        require(is_int(row.get("wait_ms"), 250) and is_int(root.get("native_wait"), 258)
                and root.get("member") is True and is_int(final.get("exit_code_u32"), CLEANUP_EXIT),
                "forced timeout did not prove the live original and trusted cleanup exit")
    else:
        require(is_int(root.get("native_wait"), 0) and is_int(root.get("exit_code_u32"), expect_exit[control]),
                "control native exit mismatch")
    if control == "natural-leak":
        child, gone = row["child_before_cleanup"], row["child_after_cleanup"]
        require(child["pid"] != root["pid"] and child.get("member") is True
                and child["creation_filetime"] >= root["creation_filetime"]
                and is_int(child.get("native_wait"), 258) and is_int(gone.get("native_wait"), 0)
                and is_int(gone.get("exit_code_u32"), CLEANUP_EXIT)
                and (child["pid"], child["creation_filetime"]) == (gone["pid"], gone["creation_filetime"]),
                "known leak did not prove its live and drained held identity")
    needed = control in ("forced-timeout", "natural-leak")
    require(row.get("trusted_cleanup_requested", False) is needed, "control cleanup action mismatch")
    accounting = row["accounting_at_cleanup"]["values"]["active_processes"]
    require(type(accounting) is int and (accounting > 0 if needed else accounting == 0),
            "control pre-cleanup accounting mismatch")


def validate_argv(row, manifest, output):
    plan = row["scheduled"]
    assets = manifest["assets"]
    if plan["phase"] == "control":
        kit = assets["testkit"]["path"]
        control = row["control_id"]
        marker = str(output / f"{plan['index']:04}" / "leak.pid")
        argv = {
            "exit-zero": [kit, "exit", "0"],
            "exit-seven": [kit, "exit", "7"],
            "exit-dword": [kit, "exit", str(0xffffffff)],
            "forced-timeout": [kit, "sleep", "5"],
            "natural-leak": [kit, "spawn-marked", "0", marker, "2", kit, "mark", marker, "5"],
        }[control]
    else:
        verb, value = ("exit", "0") if plan["workload"] == "startup" else ("wait", "50")
        argv = [assets["fixture"]["path"], verb, value, row["token"]]
        if plan["arm"] != "bare":
            mode = ["auto"] if plan["mode"] == "auto" else []
            argv = [assets[plan["arm"]]["path"], *mode, "--timeout", "2", "--", *argv]
    require(row.get("argv") == argv, "row argv differs from bound fixture/arm recipe")


def verify_raw_rows(directory, rows):
    for row in rows:
        folder = directory / f"{row['scheduled']['index']:04}"
        require(canon(parse((folder / "final.json").read_bytes())) == canon(row),
                f"{folder.name} final receipt differs from the aggregate capture")
        for stream in ("stdout", "stderr"):
            path = folder / f"{stream}.bin"
            require(path.stat().st_size <= 65536 and
                    path.read_bytes().hex() == row["streams_before_cleanup"][f"{stream}_hex"],
                    f"{folder.name} {stream} bytes differ from the pre-cleanup receipt")


def telemetry_flags(origin, observations, policy):
    keys = ("monotonic_ns", "wall_ns", "tick_ms", "awake_100ns",
            "idle_100ns", "kernel_100ns", "user_100ns")
    require(all(positive_integer(policy.get(key)) for key in
                ("suspend_threshold_ms", "clock_drift_threshold_ms")), "telemetry thresholds are not bound")
    require(all(positive_integer(origin.get(key)) for key in keys), "telemetry origin is malformed")
    prior = origin
    drifted = suspended = False
    for observation in observations:
        require(all(positive_integer(observation.get(key)) for key in keys), "telemetry sample is malformed")
        require(all(observation[key] >= prior[key] for key in keys if key != "wall_ns"),
                "telemetry counters moved backwards")
        elapsed = observation["monotonic_ns"] - origin["monotonic_ns"]
        wall_elapsed = observation["wall_ns"] - origin["wall_ns"]
        unaccounted_100ns = ((observation["tick_ms"] - origin["tick_ms"]) * 10_000 -
                             (observation["awake_100ns"] - origin["awake_100ns"]))
        drifted |= abs(wall_elapsed - elapsed) > policy["clock_drift_threshold_ms"] * 1_000_000
        suspended |= unaccounted_100ns > policy["suspend_threshold_ms"] * 10_000
        prior = observation
    return {"suspend_resume": suspended, "major_instrumentation_drift": drifted}


def checkpoint_indexes(rows):
    indexes = []
    previous = None
    for row in rows:
        block = (row["phase"], row.get("checkpoint"), row.get("macroblock"))
        if block != previous:
            indexes.append(row["index"])
            previous = block
    return [*indexes, len(rows)]


def verify_armed_deadline(row, budget_seconds, label):
    armed, deadline = row.get("armed_ns"), row.get("armed_deadline_ns")
    start, end = row.get("start_ns"), row.get("measurement_end_ns")
    require(positive_integer(armed) and is_int(row.get("deadline_seconds"), budget_seconds)
            and is_int(deadline, armed + budget_seconds * 1_000_000_000) and armed <= start
            and is_int(row.get("native_wait_observed_ns"), end), f"{label} armed deadline receipt mismatch")
    require(end <= deadline, f"{label} native wait endpoint crossed the armed deadline")


def validate(schedule_raw, manifest_raw, manifest_sha, capture):
    """Check the final driver's evidence envelope before extracting measurements."""
    require(valid_sha(manifest_sha) and sha(manifest_raw) == manifest_sha, "manifest digest mismatch")
    manifest = parse(manifest_raw)
    require(is_int(manifest.get("schema"), 1), "manifest schema mismatch")
    plan = parse(schedule_raw)
    require(schedule.schedule_bytes(plan["seed_hex"]) == schedule_raw, "schedule is not the canonical generated plan")
    schedule_sha = sha(schedule_raw)
    require(manifest.get("schedule_sha256") == schedule_sha, "manifest does not bind schedule")
    require(manifest.get("schedule_generator_sha256") == SCHEDULE_SOURCE_SHA,
            "manifest does not bind the schedule generator")
    require(manifest.get("analysis_sha256") == sha(Path(__file__).read_bytes()), "manifest does not bind analysis")
    arm_shas = manifest["arm_sha256"]
    require(set(arm_shas) == set(schedule.ARMS) and all(map(valid_sha, arm_shas.values())),
            "manifest must bind all arm executable digests")
    controls = manifest["control_ids"]
    require(type(controls) is list and tuple(controls) == CONTROL_IDS,
            "manifest does not bind the five qualified ordered controls")
    require(is_int(capture.get("schema"), 1) and capture.get("manifest_sha256") == manifest_sha
            and capture.get("schedule_sha256") == schedule_sha, "capture identity mismatch")
    require(valid_sha(manifest.get("driver_sha256"))
            and capture.get("driver_sha256") == manifest["driver_sha256"], "capture driver digest mismatch")
    require(capture.get("complete") is True, "capture is not complete")
    output = Path(capture["output_directory"])
    require(output.is_absolute(), "capture output path is not absolute")
    host = capture["host_stability"]
    flags = ("interrupted", "suspend_resume", "major_instrumentation_drift")
    require(all(type(host.get(flag)) is bool for flag in flags), "missing host stability observations")
    require(host["interrupted"] is False, "interrupted capture is invalid")
    observations = capture["telemetry"]
    require([row.get("index") for row in observations] == checkpoint_indexes(plan["rows"]),
            "host telemetry checkpoints do not match the schedule")
    telemetry = telemetry_flags(capture["host_telemetry_origin"], observations, manifest["telemetry"])
    require(all(host[key] is observed for key, observed in telemetry.items()), "host flags disagree with telemetry")
    reasons = [flag for flag in flags if host[flag]]
    rows = capture["rows"]
    require(type(rows) is list and len(rows) == len(plan["rows"]) == 2967, "row population mismatch")
    measured = defaultdict(dict)
    previous_settled = 0
    seen_identities = set()
    seen_tokens = set()
    for expected, row in zip(plan["rows"], rows):
        label = f"row {expected['index']}"
        require(canon(row["scheduled"]) == canon(expected), f"{label} differs from the exact plan")
        require(row.get("status") == "PASS" and row["oracle"].get("passed") is True,
                f"{label} was rejected by the capture driver")
        require(is_int(row["cleanup"].get("active_after"), 0), f"{label} has no Job drain proof")
        require(is_int(row["accounting_after_cleanup"]["values"].get("active_processes"), 0),
                f"{label} native Job accounting does not confirm drain")
        start, end, settled = row.get("start_ns"), row.get("measurement_end_ns"), row.get("settled_ns")
        require(all(map(positive_integer, (start, end, settled)))
                and previous_settled < start < end < settled, f"{label} overlaps or has invalid chronology")
        verify_armed_deadline(row, 10 if expected.get("workload") == "wait50" else 3, label)
        previous_settled = settled
        suspended = row["suspended"]
        pid, created_at = suspended.get("pid"), suspended.get("creation_filetime")
        identity = (pid, created_at)
        require(positive_integer(pid) and positive_integer(created_at) and identity not in seen_identities,
                f"{label} has invalid or reused original process identity")
        seen_identities.add(identity)
        require(row.get("watchdog_fired") is False and is_int(suspended.get("native_wait"), 258)
                and suspended.get("member") is True and is_int(row.get("resume_previous_suspend_count"), 1),
                f"{label} does not prove suspended atomic admission")
        require(row.get("watchdog_owns_distinct_job_handle") is True and
                row.get("watchdog_handle_closed") is True, f"{label} lacks owned watchdog handle receipts")
        create = row["create"]
        require(is_int(create.get("pid"), pid) and is_int(create.get("native_return"), 1)
                and positive_integer(create.get("process_handle")), f"{label} native launch mismatch")
        before_cleanup = row["root_before_cleanup"]
        require(is_int(before_cleanup.get("pid"), pid) and is_int(before_cleanup.get("creation_filetime"), created_at),
                f"{label} pre-cleanup identity mismatch")
        require(row.get("cwd") == manifest["cwd"] and
                row["environment"].get("utf16_sha256") == manifest["child_environment_sha256"]
                and is_int(row.get("creation_flags"), 0x08080404), f"{label} native context mismatch")
        if expected["phase"] == "control":
            require(row.get("control_id") == controls[expected["control_slot"]], f"{label} control identity mismatch")
            validate_argv(row, manifest, output)
            validate_control(row, row["control_id"])
            continue
        require(row.get("arm_sha256") == arm_shas[expected["arm"]], f"{label} arm digest mismatch")
        token = row.get("token")
        require(isinstance(token, str) and len(token) == 32 and token not in seen_tokens and all(
            char in "0123456789abcdef" for char in token), f"{label} missing or reused exact nonce")
        seen_tokens.add(token)
        validate_argv(row, manifest, output)
        verb, value = ("exit", "0") if expected["workload"] == "startup" else ("wait", "50")
        stdout = f"BENCHMARK_DONE {verb} {value} {token}\n".encode("ascii").hex()
        require(row["streams_before_cleanup"] == {"stdout_hex": stdout, "stderr_hex": ""}
                and not row.get("trusted_cleanup_requested", False), f"{label} output or survivor mismatch")
        before, after = row["identity_before"], row["identity_after"]
        require(is_int(before.get("pid"), pid) and is_int(before.get("creation_time"), created_at)
                and canon(before) == canon(after), f"{label} held process identity mismatch")
        wait, exit_receipt = row["wait"], row["exit"]
        handle = create.get("process_handle")
        require(positive_integer(handle) and is_int(create.get("pid"), before["pid"])
                and is_int(create.get("native_return"), 1)
                and is_int(wait.get("process_handle"), handle)
                and is_int(wait.get("native_return"), 0)
                and is_int(exit_receipt.get("process_handle"), handle)
                and is_int(exit_receipt.get("native_return"), 1)
                and is_int(exit_receipt.get("exit_code_u32"), 0), f"{label} original process evidence mismatch")
        elapsed = row.get("elapsed_ns")
        budget = 3_000_000_000 if expected["workload"] == "startup" else 10_000_000_000
        require(positive_integer(elapsed) and elapsed <= budget and positive_integer(start)
                and is_int(end, start + elapsed) and is_int(wait.get("query_end_ns"), end)
                and row.get("watchdog_fired") is False, f"{label} elapsed/deadline mismatch")
        if expected["phase"] == "measured":
            key = (expected["mode"], expected["workload"], expected["macroblock"], expected["triplet"])
            measured[key][expected["position"]] = (expected["arm"], elapsed)
    result = {stratum: [[] for _ in range(BLOCKS)] for stratum in STRATA}
    for (mode, workload, block, _), values in measured.items():
        ordered = [values[position] for position in range(3)]
        permutation = tuple(arm for arm, _ in ordered)
        elapsed = dict(ordered)
        result[mode, workload][block].append((permutation, elapsed))
    require(all(len(block) == 6 for blocks in result.values() for block in blocks),
            "measured strata are not complete")
    for sample in observations:
        index, stamp = sample["index"], sample["monotonic_ns"]
        left = rows[index - 1]["settled_ns"] if index else capture["host_telemetry_origin"]["monotonic_ns"]
        right = rows[index]["start_ns"] if index < len(rows) else stamp
        require(left <= stamp <= right, f"telemetry sample {index} crosses its row boundary")
    return result, reasons


def nearest_rank(size, numerator, denominator):
    return (size * numerator + denominator - 1) // denominator


def series(triplet):
    _, values = triplet
    main, wake, bare = (values[arm] for arm in schedule.ARMS)
    return main, wake, main - bare, wake - bare


def contrasts(marginals):
    return tuple(
        marginals[main][rank] - marginals[main + 1][rank]
        for main in (0, 2) for rank in (0, 1))


def point(triplets):
    ranks = [nearest_rank(len(triplets), p, 10) - 1 for p in (5, 9)]
    marginals = []
    for column in zip(*(series(t) for t in triplets)):
        ordered = sorted(column)
        marginals.append(tuple(ordered[index] for index in ranks))
    return contrasts(marginals)


class WeightedRanks:
    """Rank a resampled marginal using packed macroblock prefix counts."""

    def __init__(self, entries):
        self.values = []
        self.prefixes = []
        prefix = 0
        for value, block in sorted(entries):
            self.values.append(value)
            prefix += 1 << (LANE_BITS * block)
            self.prefixes.append(prefix)
        require(len(entries) <= LANE_MASK, "packed rank lanes would carry")
        self.ranks = tuple(nearest_rank(len(entries), p, 10) for p in (5, 9))

    def at(self, packed_weights, rank):
        # Reversing the weight lanes makes the middle convolution lane the
        # exact weighted count. Every lane is at most 40 blocks * 6 values,
        # so the base-256 product has no carries between lanes.
        left, right = 0, len(self.prefixes) - 1
        while left < right:
            middle = (left + right) // 2
            count = (self.prefixes[middle] * packed_weights >> DOT_SHIFT) & LANE_MASK
            if count < rank:
                left = middle + 1
            else:
                right = middle
        return self.values[left]

    def pair(self, packed_weights):
        return tuple(self.at(packed_weights, rank) for rank in self.ranks)


def packed_draw(rng, length):
    limit = BLOCKS - length + 1
    counts = [0] * BLOCKS
    for _ in range(BLOCKS // length):
        start = rng.getrandbits(6)
        while start >= limit:
            start = rng.getrandbits(6)
        for block in range(start, start + length):
            counts[block] += 1
    return int.from_bytes(bytes(reversed(counts)), "little")


def bootstrap(data, points, length, repeats):
    rankers = {}
    for stratum in STRATA:
        entries = [[] for _ in range(4)]
        for index, block in enumerate(data[stratum]):
            for triplet in block:
                for column, value in enumerate(series(triplet)):
                    entries[column].append((value, index))
        rankers[stratum] = [WeightedRanks(marginal) for marginal in entries]
    samples = {stratum: [[] for _ in ENDPOINTS] for stratum in STRATA}
    seed = int.from_bytes(hashlib.sha256(SEED_DOMAIN + bytes([length])).digest(), "big")
    rng = random.Random(seed)
    for _ in range(repeats):
        weights = packed_draw(rng, length)
        for stratum in STRATA:
            values = contrasts([ranker.pair(weights) for ranker in rankers[stratum]])
            for column, value in zip(samples[stratum], values):
                column.append(value)
    lo = nearest_rank(repeats, 1, 640) - 1
    hi = nearest_rank(repeats, 639, 640) - 1
    intervals = {}
    for stratum in STRATA:
        intervals[stratum] = []
        for estimate, column in zip(points[stratum], samples[stratum]):
            column.sort()
            intervals[stratum].append([2 * estimate - column[hi], 2 * estimate - column[lo]])
    return intervals


def classify(interval):
    lower, upper = interval
    if upper < 0:
        return "win"
    if lower > 0:
        return "slower"
    return "unresolved"


def paired_description(data):
    output = []
    for mode, workload in STRATA:
        differences = sorted(values["main"] - values["wake"]
                             for block in data[mode, workload] for _, values in block)
        q50, q90 = (differences[nearest_rank(len(differences), p, 10) - 1] for p in (5, 9))
        output.append(dict(mode=mode, workload=workload, q50_ns=q50, q90_ns=q90))
    return output


def summarize(data, host_reasons, repeats):
    points = {stratum: point([triplet for block in data[stratum] for triplet in block])
              for stratum in STRATA}
    intervals = {length: bootstrap(data, points, length, repeats) for length in LENGTHS} if not host_reasons else {}
    output = []
    for stratum in STRATA:
        blocks = data[stratum]
        triplets = [triplet for block in blocks for triplet in block]
        half_points = [point([triplet for block in half for triplet in block])
                       for half in (blocks[:BLOCKS // 2], blocks[BLOCKS // 2:])]
        permutation_points = {"/".join(order): point([t for t in triplets if t[0] == order])
                              for order in schedule.PERMUTATIONS}
        for index, endpoint in enumerate(ENDPOINTS):
            record = dict(mode=stratum[0], workload=stratum[1], endpoint=endpoint,
                          estimate_ns=points[stratum][index],
                          half_estimate_ns=[half[index] for half in half_points],
                          permutation_estimate_ns={k: v[index] for k, v in permutation_points.items()},
                          intervals_ns={}, interval_classification={}, reasons=list(host_reasons),
                          verdict="unresolved")
            if intervals:
                for length in LENGTHS:
                    key = f"L{length}"
                    interval = intervals[length][stratum][index]
                    record["intervals_ns"][key] = interval
                    record["interval_classification"][key] = classify(interval)
                primary = record["interval_classification"]["L4"]
                if any(value != primary for value in record["interval_classification"].values()):
                    record["reasons"].append("block_length_classification_differs")
                diagnostics = [*record["half_estimate_ns"], *record["permutation_estimate_ns"].values()]
                if (primary == "win" and any(value > 0 for value in diagnostics)) or (
                        primary == "slower" and any(value < 0 for value in diagnostics)):
                    record["reasons"].append("opposite_half_or_permutation_sign")
                if not record["reasons"]:
                    record["verdict"] = primary
            output.append(record)
    return output


def self_check():
    # Synthetic shifts have a closed-form answer at every rank and resample.
    data = {}
    for stratum in STRATA:
        data[stratum] = [
            [(order, {"main": 100 + block + offset, "wake": 107 + block + offset,
                       "bare": 10 + block - offset})
             for offset, order in enumerate(schedule.PERMUTATIONS)]
            for block in range(BLOCKS)
        ]
    results = summarize(data, [], 13)
    require(len(results) == 16 and all(r["estimate_ns"] == -7 and r["verdict"] == "win"
            and set(map(tuple, r["intervals_ns"].values())) == {(-7, -7)} for r in results),
            "synthetic constant shift did not survive all resampling and diagnostics")
    require(all(row["q50_ns"] == row["q90_ns"] == -7 for row in paired_description(data)),
            "descriptive paired ranks differ")
    require(all(r["verdict"] == "unresolved" and not r["intervals_ns"]
                for r in summarize(data, ["suspend_resume"], 13)), "host gate failed closed")
    counts = [0] * BLOCKS
    counts[0], counts[3], counts[-1] = 5, 22, 13
    entries = [(block - 19 if offset % 2 else 4, block)
               for block in range(BLOCKS) for offset in range(6)]
    plain = sorted(value for value, block in entries for _ in range(counts[block]))
    ranker = WeightedRanks(entries)
    require(ranker.pair(int.from_bytes(bytes(reversed(counts)), "little")) ==
            tuple(plain[rank - 1] for rank in ranker.ranks), "packed ranks differ from explicit expansion")
    require([classify(bounds) for bounds in ((-2, -1), (1, 2), (-1, 0), (0, 1))] ==
            ["win", "slower", "unresolved", "unresolved"], "direction boundary check failed")

    seed = "5a" * 32
    schedule_raw = schedule.schedule_bytes(seed)
    arm_shas = {arm: sha(arm.encode()) for arm in schedule.ARMS}
    controls = list(CONTROL_IDS)
    driver_sha = "6b" * 32
    assets = {name: {"path": str(Path(__file__).resolve().parent / name)}
              for name in ("testkit", "fixture", "wake", "main")}
    output = Path(__file__).resolve().parent / "synthetic"
    manifest = dict(schema=1, schedule_sha256=sha(schedule_raw), arm_sha256=arm_shas,
                    control_ids=controls, driver_sha256=driver_sha,
                    assets=assets, cwd=str(output), child_environment_sha256="7c" * 32,
                    telemetry={"suspend_threshold_ms": 1000, "clock_drift_threshold_ms": 1000},
                    analysis_sha256=sha(Path(__file__).read_bytes()),
                    schedule_generator_sha256=sha(Path(schedule.__file__).read_bytes()))
    manifest_raw = canon(manifest).encode()
    capture = dict(schema=1, schedule_sha256=sha(schedule_raw), manifest_sha256=sha(manifest_raw),
                   driver_sha256=driver_sha, complete=True, rows=[], output_directory=str(output),
                   host_stability=dict(interrupted=False, suspend_resume=False,
                                       major_instrumentation_drift=False))
    plan = parse(schedule_raw)["rows"]
    origin = {key: 10 for key in ("monotonic_ns", "wall_ns", "tick_ms", "awake_100ns",
                                 "idle_100ns", "kernel_100ns", "user_100ns")}
    origin.update(monotonic_ns=20_000_000_010, wall_ns=20_000_000_010)
    capture["host_telemetry_origin"] = origin
    capture["telemetry"] = [dict(origin, index=index, monotonic_ns=20_000_000_000 + 1000 * (index + 1) - 10,
                                 wall_ns=20_000_000_000 + 1000 * (index + 1) - 10)
                            for index in checkpoint_indexes(plan)]
    for planned in plan:
        row = dict(scheduled=planned, status="PASS", oracle={"passed": True}, cleanup={"active_after": 0},
                   accounting_after_cleanup={"values": {"active_processes": 0}})
        start = 20_000_000_000 + 1000 * (planned["index"] + 1)
        pid = planned["index"] + 1
        held = dict(pid=pid, creation_filetime=10, member=True, native_wait=258, exit_code_u32=259)
        budget = 10 if planned.get("workload") == "wait50" else 3
        row.update(start_ns=start, measurement_end_ns=start + 100, settled_ns=start + 110, watchdog_fired=False,
                   armed_ns=start - 10, armed_deadline_ns=start - 10 + budget * 1_000_000_000,
                   deadline_seconds=budget, native_wait_observed_ns=start + 100,
                   suspended=held, resume_previous_suspend_count=1, create=dict(process_handle=5, pid=pid, native_return=1),
                   root_before_cleanup=dict(held, native_wait=0, exit_code_u32=0),
                   cwd=manifest["cwd"], environment={"utf16_sha256": manifest["child_environment_sha256"]},
                   creation_flags=0x08080404, watchdog_owns_distinct_job_handle=True, watchdog_handle_closed=True)
        if planned["phase"] == "control":
            row["control_id"] = controls[planned["control_slot"]]
            root = row["root_before_cleanup"]
            final = dict(root)
            needs_cleanup = row["control_id"] in ("natural-leak", "forced-timeout")
            row.update(root_after_cleanup=final,
                       streams_before_cleanup=dict(stdout_hex="", stderr_hex=""),
                       trusted_cleanup_requested=needs_cleanup,
                       accounting_at_cleanup={"values": {"active_processes": int(needs_cleanup)}})
            if row["control_id"] == "exit-seven":
                root["exit_code_u32"] = final["exit_code_u32"] = 7
            elif row["control_id"] == "exit-dword":
                root["exit_code_u32"] = final["exit_code_u32"] = 0xffffffff
            elif row["control_id"] == "forced-timeout":
                root["native_wait"] = 258
                final["exit_code_u32"] = CLEANUP_EXIT
                row["wait_ms"] = 250
            elif row["control_id"] == "natural-leak":
                row["child_before_cleanup"] = dict(root, pid=9999, native_wait=258)
                row["child_after_cleanup"] = dict(final, pid=9999, exit_code_u32=CLEANUP_EXIT)
        else:
            identity = dict(pid=planned["index"] + 1, creation_time=10)
            token = f"{planned['index']:032x}"
            verb, value = ("exit", "0") if planned["workload"] == "startup" else ("wait", "50")
            row.update(arm_sha256=arm_shas[planned["arm"]], identity_before=identity, identity_after=dict(identity),
                       create=dict(process_handle=5, pid=identity["pid"], native_return=1),
                       wait=dict(process_handle=5, native_return=0, query_end_ns=start + 100),
                       exit=dict(process_handle=5, native_return=1, exit_code_u32=0),
                       elapsed_ns=100, token=token,
                       streams_before_cleanup=dict(
                           stdout_hex=f"BENCHMARK_DONE {verb} {value} {token}\n".encode().hex(), stderr_hex=""))
        if planned["phase"] == "control":
            kit = assets["testkit"]["path"]
            marker = str(output / f"{planned['index']:04}" / "leak.pid")
            row["argv"] = {
                "exit-zero": [kit, "exit", "0"], "exit-seven": [kit, "exit", "7"],
                "exit-dword": [kit, "exit", str(0xffffffff)], "forced-timeout": [kit, "sleep", "5"],
                "natural-leak": [kit, "spawn-marked", "0", marker, "2", kit, "mark", marker, "5"],
            }[row["control_id"]]
        else:
            payload = [assets["fixture"]["path"], verb, value, token]
            prefix = [assets[planned["arm"]]["path"], *(["auto"] if planned["mode"] == "auto" else []),
                      "--timeout", "2", "--"] if planned["arm"] != "bare" else []
            row["argv"] = prefix + payload
        capture["rows"].append(row)
    complete, reasons = validate(schedule_raw, manifest_raw, sha(manifest_raw), capture)
    require(not reasons and all(len(blocks) == BLOCKS for blocks in complete.values()), "synthetic capture rejected")
    capture["rows"][5]["wait"]["process_handle"] = 6
    try:
        validate(schedule_raw, manifest_raw, sha(manifest_raw), capture)
    except ValueError as error:
        require("original process evidence mismatch" in str(error), "unexpected synthetic rejection")
    else:
        raise ValueError("mismatched held process accepted")
    capture["rows"][5]["wait"]["process_handle"] = 5
    original = capture["rows"][5]["suspended"]
    capture["rows"][5]["suspended"] = capture["rows"][0]["suspended"]
    try:
        validate(schedule_raw, manifest_raw, sha(manifest_raw), capture)
    except ValueError as error:
        require("reused original process identity" in str(error), "unexpected reused-identity rejection")
    else:
        raise ValueError("reused held process accepted")
    late = capture["rows"][5]
    late["suspended"] = original
    late["armed_deadline_ns"] = late["start_ns"] + 50
    late["armed_ns"] = late["armed_deadline_ns"] - late["deadline_seconds"] * 1_000_000_000
    try:
        validate(schedule_raw, manifest_raw, sha(manifest_raw), capture)
    except ValueError as error:
        require("endpoint crossed the armed deadline" in str(error), "unexpected late-endpoint rejection")
    else:
        raise ValueError("short elapsed accepted after the armed deadline")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-check", action="store_true")
    parser.add_argument("--schedule", type=Path)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--manifest-sha256")
    parser.add_argument("--capture", type=Path)
    parser.add_argument("--capture-sha256")
    parser.add_argument("--admission", type=Path)
    parser.add_argument("--admission-sha256")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    if args.self_check:
        self_check()
        print("analysis synthetic self-check passed")
        return
    if any(value is None for value in (args.schedule, args.manifest, args.manifest_sha256, args.capture,
                                       args.capture_sha256, args.admission, args.admission_sha256, args.out)):
        parser.error("analysis requires exact schedule, manifest, admission, capture and their applicable digests")
    capture_raw = args.capture.read_bytes()
    require(valid_sha(args.capture_sha256) and sha(capture_raw) == args.capture_sha256, "capture digest mismatch")
    schedule_raw = args.schedule.read_bytes()
    manifest_raw = args.manifest.read_bytes()
    capture = parse(capture_raw)
    verify_admission(args.admission.read_bytes(), args.admission_sha256, args.manifest_sha256)
    require(capture.get("admission_sha256") == args.admission_sha256, "capture admission receipt mismatch")
    manifest = parse(manifest_raw)
    verify_outer_receipt(manifest, capture)
    verify_asset_holds(manifest, capture)
    require(capture.get("qualification_receipts") == manifest["qualification_receipts"],
            "capture native qualification bindings differ")
    for binding in manifest["qualification_receipts"].values():
        require(sha(Path(binding["path"]).read_bytes()) == binding["sha256"], "qualification receipt digest mismatch")
    data, host_reasons = validate(schedule_raw, manifest_raw, args.manifest_sha256, capture)
    verify_raw_rows(args.capture.resolve().parent, capture["rows"])
    endpoints = summarize(data, host_reasons, REPLICATES)
    output = dict(schema=1, scope="directional development only under observed laptop load",
                  schedule_sha256=sha(schedule_raw), manifest_sha256=args.manifest_sha256,
                  capture_sha256=args.capture_sha256, admission_sha256=args.admission_sha256, python_version=sys.version,
                  bootstrap=dict(replicates=REPLICATES, primary_length=4, sensitivity_lengths=[2, 8],
                                 tail="1/640", interval="Bonferroni basic, nearest rank",
                                 prng="CPython Random.getrandbits; SHA256 domain and length seed",
                                 assumption="nominal conditional inference assuming stationary weak dependence across 40 chronological macroblocks"),
                  evidence_scope="Recomputes plan, chronology, native receipts, nonce output and sampled host-drift flags. Cross-checks individual receipts and raw streams. Interruption status is a capture-driver observation.",
                  paired_differences_descriptive_only=paired_description(data),
                  endpoints=endpoints)
    with args.out.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(output, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
