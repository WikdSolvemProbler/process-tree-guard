"""Externally admitted, observed-load Windows phase diagnostic controller."""

import argparse
import ctypes as C
from ctypes import wintypes as W
import hashlib
import importlib.util
import os
from pathlib import Path
import sys
import time
import uuid


HERE = Path(__file__).resolve().parent
SOURCE = Path(__file__).resolve()
COMMON = HERE / "phase_common.py"
BASE = HERE.parent / "wake-msvc-driver-dev-001"


def load_common():
    raw = COMMON.read_bytes()
    spec = importlib.util.spec_from_file_location("phase_common_capture", COMMON)
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(COMMON), "exec"), module.__dict__)
    return module, hashlib.sha256(raw).hexdigest()


M, COMMON_SHA = load_common()


def inspect_ancestor(S, pid):
    """Inspect the launcher shell or bootstrap through a held original handle."""
    import _winapi

    class Basic(C.Structure):
        _fields_ = [("status", C.c_void_p), ("peb", C.c_void_p), ("affinity", C.c_void_p),
                    ("priority", C.c_void_p), ("pid", C.c_size_t), ("parent_pid", C.c_size_t)]

    class UnicodeString(C.Structure):
        _fields_ = [("length", W.USHORT), ("maximum", W.USHORT), ("buffer", C.c_void_p)]

    query = C.WinDLL("ntdll").NtQueryInformationProcess
    query.argtypes = (W.HANDLE, W.ULONG, C.c_void_p, W.ULONG, C.POINTER(W.ULONG))
    query.restype = W.LONG
    parse_argv = C.WinDLL("shell32", use_last_error=True).CommandLineToArgvW
    parse_argv.argtypes = (W.LPCWSTR, C.POINTER(C.c_int))
    parse_argv.restype = C.POINTER(W.LPWSTR)
    free = S.bind("LocalFree", [C.c_void_p], C.c_void_p)

    M.require(M.integer(pid), "invalid ancestor PID")
    handle = _winapi.OpenProcess(S.SYNC_QUERY, False, pid)
    try:
        M.require(_winapi.WaitForSingleObject(handle, 0) == 258, "launcher ancestor is already terminal")
        image_size = W.DWORD(32768)
        image = C.create_unicode_buffer(image_size.value)
        S.native_ok(S.image_name(handle, 0, image, C.byref(image_size)))
        basic = Basic()
        M.require(query(handle, 0, C.byref(basic), C.sizeof(basic), None) == 0 and basic.pid == pid,
                  "launcher ancestor identity differs")
        storage = C.create_string_buffer(65536)
        returned = W.ULONG()
        M.require(query(handle, 60, storage, C.sizeof(storage), C.byref(returned)) == 0,
                  "launcher ancestor command line unavailable")
        command = UnicodeString.from_buffer(storage)
        start = C.addressof(storage)
        M.require(command.length > 0 and command.length % 2 == 0 and command.buffer is not None
                  and start <= command.buffer <= start + len(storage) - command.length, "invalid command buffer")
        argc = C.c_int()
        argv = parse_argv(C.wstring_at(command.buffer, command.length // 2), C.byref(argc))
        S.native_ok(argv)
        try:
            words = [argv[index] for index in range(argc.value)]
        finally:
            free(C.cast(argv, C.c_void_p))
        times = [W.FILETIME() for _ in range(4)]
        S.native_ok(S.process_times(handle, *(C.byref(value) for value in times)))
        birth = (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime
        return dict(pid=pid, parent_pid=basic.parent_pid, path=image.value, argv=words, creation_filetime=birth)
    finally:
        _winapi.CloseHandle(handle)


def verify_launch(base, S, manifest, expected):
    actual_controller = [sys.executable, "-B", str(SOURCE), *sys.argv[1:]]
    M.require(actual_controller == expected["controller"] and os.getcwd().casefold()
              == manifest["launch"]["working_directory"].casefold(), "actual controller argv or cwd differs")
    base.controller_argv = lambda: actual_controller
    observed, cutoff = base.guard_chain(S, manifest)
    observed["shell"] = inspect_ancestor(S, observed["backup"]["parent_pid"])
    observed["bootstrap"] = inspect_ancestor(S, observed["shell"]["parent_pid"])
    bindings = manifest["bindings"]
    for role in ("root", "backup", "shell", "bootstrap"):
        binding = bindings["bootstrap_shell" if role == "shell" else role + "_guard"]
        observed[role]["sha256"] = M.sha(M.bound_bytes(binding))
    M.verify_launch_receipt(manifest, expected, observed)
    epoch_ns = 11_644_473_600_000_000_000
    remaining = 180 - (time.time_ns() + epoch_ns - observed["bootstrap"]["creation_filetime"] * 100) / 1e9
    M.require(15 < remaining <= 180, "bootstrap deadline origin differs")
    return observed, min(cutoff, time.monotonic() + remaining - 15)


def host_sample(base, S, N, clock, index):
    native = base.telemetry(S)
    del native["monotonic_ns"]
    native["qpc"] = clock.read()
    native["available_physical"] = N.admission()["available_physical"]
    native["index"] = index
    return native


def prepare(manifest):
    bindings = manifest["bindings"]
    local = dict(driver=SOURCE, common=COMMON, native_derivative=HERE / "phase_native.py",
                 analysis=HERE / "analysis.py", protocol=HERE / "PROTOCOL-002.md",
                 schedule=HERE / "schedule-002.json", schedule_generator=HERE / "schedule.py",
                 base_driver=BASE / "capture.py", base_analysis=BASE / "analysis.py",
                 base_schedule=BASE / "schedule.py", base_suspended=BASE / "qualify-suspended.py",
                 python=Path(sys.executable))
    for role, expected in local.items():
        M.require(bindings[role]["path"] == str(expected), f"{role} path differs")
    M.require(bindings["common"]["sha256"] == COMMON_SHA, "loaded shared source differs")
    for binding in bindings.values():
        M.bound_bytes(binding)
    base = M.load_source("base_capture", bindings["base_driver"])
    M.require(base.ANALYSIS_SHA == bindings["base_analysis"]["sha256"]
              and base.A.SCHEDULE_SOURCE_SHA == bindings["base_schedule"]["sha256"], "loaded base dependencies differ")
    D = M.load_source("base_suspended", bindings["base_suspended"])
    for role, (path, digest) in D.INPUTS.items():
        M.require(bindings[role] == dict(path=str(path), sha256=digest), f"qualified native {role} differs")
    M.require(str(D.CWD) == manifest["cwd"] and D.CWD.is_dir(), "neutral cwd differs")
    phase = M.load_source("phase_native", bindings["native_derivative"])
    return base, D, phase


def verify_preflight_inputs(manifest):
    bindings = manifest["bindings"]
    build = M.parse(M.bound_bytes(bindings["fixture_build"]))
    qualification = M.parse(M.bound_bytes(bindings["fixture_qualification"]))
    environment = M.parse(M.bound_bytes(bindings["environment_receipt"]))
    M.require(build.get("passed") is True and build.get("protocol_sha256") == M.PROTOCOL_SHA
              and build.get("diagnostic_fixture_sha256") == bindings["diagnostic_fixture"]["sha256"]
              and all(build.get(role + "_sha256") == bindings[role]["sha256"]
                      for role in ("fixture_source", "fixture_patch", "fixture_manifest", "fixture_lockfile")),
              "fixture build proof differs")
    M.require(qualification.get("passed") is True and qualification.get("protocol_sha256") == M.PROTOCOL_SHA
              and qualification.get("candidate_arms_executed") is False
              and qualification.get("qualified_conditions") == ["A", "B", "C"]
              and qualification.get("native_derivative_sha256") == bindings["native_derivative"]["sha256"]
              and qualification.get("diagnostic_fixture_sha256") == bindings["diagnostic_fixture"]["sha256"]
              and qualification.get("child_environment_sha256") == manifest["child_environment_sha256"],
              "fixture-only qualification differs")
    M.require(environment.get("child_environment_sha256") == manifest["child_environment_sha256"],
              "environment receipt differs")


def capture_row(D, N, P, S, phase, clock, manifest, row, folder):
    def stdout_oracle(stdout, partial):
        partial["fixture_marker"] = M.decode_marker(stdout, partial, clock.frequency)
        return True

    phase.arm(D, N, P, S, clock, row, folder, row["argv"], 3, 0, stdout_oracle, capture=True,
              expected_env_sha256=manifest["child_environment_sha256"])


def run(args, out):
    receipt = dict(schema=1, protocol_sha256=M.PROTOCOL_SHA, manifest_sha256=args.manifest_sha256,
                   admission_sha256=args.admission_sha256, output_directory=str(out), complete=False, rows=[],
                   schedule_sha256=M.SCHEDULE_SHA, telemetry=[])
    hold = None
    try:
        M.require(os.name == "nt" and C.sizeof(C.c_void_p) == 8, "expected Windows x64")
        manifest, plan = M.read_manifest(args.manifest, args.manifest_sha256)
        M.read_admission(args.admission, args.admission_sha256, args.manifest_sha256)
        M.require(manifest["output_directory"] == str(out) and manifest["admission_path"] == str(args.admission),
                  "requested output or external admission is outside the frozen recipe")
        M.write(out / "attempt.json", {**receipt, "planned_rows": plan})
        base, D, phase = prepare(manifest)
        hold = base.RuntimeHold(manifest["bindings"])
        receipt["asset_hold"] = dict(share_mode="FILE_SHARE_READ", before=hold.acquire())
        verify_preflight_inputs(manifest)
        S, N, P = (D.load(role) for role in ("support", "native", "policy"))
        context, _ = P.environment(dict(os.environ))
        forbidden = {"PROCESS_GUARD_TRACE", "PROCESS_TREE_GUARD_TRACE", "PROCESS_GUARD_TIMING_NONCE",
                     "PROCESS_TREE_GUARD_TIMING_NONCE", "PROCESS_TREE_GUARD_CHANNEL",
                     "CODEX_TOOL_CALL_ID", "CODEX_THREAD_ID"}
        M.require(not (forbidden & {key.upper() for key in context})
                  and D.environment_block(P)[1]["utf16_sha256"] == manifest["child_environment_sha256"],
                  "sanitized environment differs before capture")
        recipe = M.invocation(manifest, args.manifest, args.manifest_sha256, args.admission, args.admission_sha256, out)
        receipt["launch"], cutoff = verify_launch(base, S, manifest, recipe)
        clock = phase.Clock()
        receipt["qpc_frequency"] = clock.frequency
        M.write(out / "preflight.json", receipt)
        seen, tokens, previous = set(), set(), 0
        for expected in plan:
            M.require(time.monotonic() < cutoff, "outer guard admission reserve reached")
            index = expected["index"]
            if index in M.BLOCK_BOUNDARIES:
                sample = host_sample(base, S, N, clock, index)
                M.require(previous <= sample["qpc"], "host sample precedes prior settlement")
                receipt["telemetry"].append(sample)
                M.verify_telemetry(receipt["telemetry"], clock.frequency)
            folder = out / f"{index:04d}"
            folder.mkdir()
            token = uuid.uuid4().hex
            M.require(token not in tokens, "duplicate fixture nonce")
            tokens.add(token)
            row = dict(scheduled=expected, status="INCOMPLETE", oracle_passed=False, token=token,
                       argv=M.row_argv(manifest, expected, token))
            receipt["rows"].append(row)
            M.write(folder / "prepared.json", row)
            try:
                capture_row(D, N, P, S, phase, clock, manifest, row, folder)
                row.update(status="PASS", oracle_passed=True)
                identity = M.verify_row(row, expected, manifest, clock.frequency, previous)
                if index in M.BLOCK_BOUNDARIES:
                    M.require(receipt["telemetry"][-1]["qpc"] <= row["start_tick"], "host sample follows block start")
                M.require(identity not in seen, "original process identity reused")
                seen.add(identity)
                previous = row["settled_tick"]
            except BaseException as error:
                row.update(status="FAIL", oracle_passed=False, error=repr(error))
                raise
            finally:
                M.write(folder / "final.json", row)
        receipt["telemetry"].append(host_sample(base, S, N, clock, len(plan)))
        M.verify_telemetry(receipt["telemetry"], clock.frequency, receipt["rows"])
        receipt["asset_hold"]["after"] = hold.verify()
        M.verify_holds(manifest, receipt)
        M.verify_raw_rows(out, receipt["rows"])
        receipt["complete"] = True
    except BaseException as error:
        receipt.update(error=repr(error), interrupted=isinstance(error, (KeyboardInterrupt, SystemExit)))
    finally:
        try:
            M.write(out / "capture.json", receipt)
        finally:
            if hold is not None:
                hold.resources.close()
    return 0 if receipt["complete"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--admission", type=Path, required=True)
    parser.add_argument("--admission-sha256", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    M.require(out.parent == HERE, "choose a fresh adjacent output directory")
    out.mkdir(exist_ok=False)
    return run(args, out)


if __name__ == "__main__":
    sys.exit(main())
