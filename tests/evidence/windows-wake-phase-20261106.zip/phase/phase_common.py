"""Shared byte recipes and fail-closed evidence checks for the phase diagnostic."""

import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re


HERE = Path(__file__).resolve().parent
PROTOCOL_SHA = "3b3249d91c284adccb249185b39371765e1a113642d23dccb24e0af2cb1b183c"
SCHEDULE_SHA = "9afb78e5b2660e72df5f30ac4d3d9acf93add40478cc52df928f27cb16d80b73"
ENV_SHA = "89686df12aa8805d2405f807737ab631ad0e575517782a4c0821d4b727cbf4a4"
GUARD_SHA = "1899137f687541256fb89749b2fe6a2940f2e420faaf2330fc84f32cfd7fae43"
ORIGINAL = {
    "main": "f7f6e1fca2533e651ece4b44f6a484e6903612252d3aa466870314b920dc2e02",
    "wake": "50f73d903f03ab580d4dbe1335a055febcd2aef4a79d04c5a5a179d358324770",
    "fixture": "81678345d3b1bb31bbeaee1872580764386274d64f98129b538c80b20ed058d0",
}
QUALIFIED = {
    "base_driver": "9b2586e765222da108d726e8ae1702fb413810046ed1a0c78436ae00e50f9fff",
    "base_analysis": "4a1707fb42ccfa84151bbd2cb6f01d5cacda2eb7240d8c082711bb1d681cba53",
    "base_schedule": "2f80bcc0ca933f216b0477545bb1b81d71ef4783b9e904d9728616e89bc169ba",
    "base_suspended": "e11cd48dce9f4b3612323f870dd539bdf7c5fc8ffc643a879410151bb0695523",
    "schedule_generator": "7b6dec1d06e411435419976e40ecd7dd8b8dc5274a4b148956575c3fc186192f",
    "fixture_base_source": "b42f15eb89ff60c0b730b17ab926d448ac81f6eb0248024feb39a1d4c050d712",
    "python": "4d6f5f81a4bca11191c4c7c6b43632694d0a4ce74e068619d8fdc161d469859a",
    "bootstrap_shell": "362a356ce7f0940ec74f73a8fc2c990a2cc24a38a11c90bbd8eca947110ad139",
}
ROLES = {*ORIGINAL, *QUALIFIED, "protocol", "driver", "common", "analysis", "native_derivative",
         "schedule", "python", "support", "native", "policy", "build_receipt", "testkit", "fixture_source",
         "fixture_patch", "fixture_manifest", "fixture_lockfile", "diagnostic_fixture", "fixture_build",
         "fixture_qualification", "environment_receipt",
         "root_guard", "backup_guard", "bootstrap_guard", "bootstrap_shell"}
ARM_ORDER = ("main", "wake", "bare")
MARKER = re.compile(rb"PTG_FIXTURE_PHASE_V1 ([0-9a-f]{32}) ([01]) ([0-9]{10}) ([0-9]{20}) "
                    rb"([0-9]{20}) ([0-9]{20}) ([0-9]{20})\n")
BLOCK_BOUNDARIES = (0, 54, 108, 162, 216, 270, 324)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, minimum=1):
    return type(value) is int and value >= minimum


def exact_integer(value, expected):
    return type(value) is int and value == expected


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def is_sha(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def parse(raw):
    def fields(pairs):
        result = {}
        for name, value in pairs:
            require(name not in result, f"duplicate JSON key {name}")
            result[name] = value
        return result

    def finite(value):
        result = float(value)
        require(math.isfinite(result), "nonfinite JSON number")
        return result

    return json.loads(raw, object_pairs_hook=fields, parse_float=finite, parse_constant=finite)


def canonical(value):
    return json.dumps(value, sort_keys=True, allow_nan=False, separators=(",", ":"))


def write(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def bound_bytes(binding):
    path = Path(binding["path"])
    require(path.is_absolute() and str(path) == binding["path"], "binding path must be canonical and absolute")
    raw = path.read_bytes()
    require(is_sha(binding["sha256"]) and sha(raw) == binding["sha256"], f"changed binding {path}")
    return raw


def load_source(name, binding):
    raw = bound_bytes(binding)
    path = Path(binding["path"])
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def read_manifest(path, digest):
    raw = bound_bytes(dict(path=str(path), sha256=digest))
    value = parse(raw)
    require(type(value.get("schema")) is int and value["schema"] == 1
            and value.get("state") == "FROZEN_PENDING_EXTERNAL_ADMISSION", "manifest is not frozen")
    binds = value["bindings"]
    require(set(binds) == ROLES, "wrong runtime binding role population")
    for role, expected in {**ORIGINAL, **QUALIFIED, "protocol": PROTOCOL_SHA, "schedule": SCHEDULE_SHA,
                           **dict.fromkeys(("root_guard", "backup_guard", "bootstrap_guard"), GUARD_SHA)}.items():
        require(binds[role]["sha256"] == expected, f"{role} differs from the reviewed source or binary")
    require(value["child_environment_sha256"] == ENV_SHA, "environment needs a reviewed protocol amendment")
    launch = value["launch"]
    require(canonical({key: launch[key] for key in ("root_seconds", "backup_seconds", "bootstrap_seconds",
                                                  "reserve_seconds", "shell_login")})
            == canonical(dict(root_seconds=150, backup_seconds=165, bootstrap_seconds=180,
                              reserve_seconds=15, shell_login=False)), "launch bounds differ from protocol")
    require(launch["root_path"] == binds["root_guard"]["path"] and launch["root_sha256"] == GUARD_SHA
            and launch["backup_path"] == binds["backup_guard"]["path"] and launch["backup_sha256"] == GUARD_SHA,
            "guard path bindings differ")
    require(launch["shell_flags"] == ["-NoProfile", "-NonInteractive", "-Command"]
            and launch["launcher_process_unset"] == ["CODEX_TOOL_CALL_ID", "CODEX_THREAD_ID"]
            and Path(launch["working_directory"]).is_absolute(), "launcher context differs")
    schedule_raw = bound_bytes(binds["schedule"])
    generator = load_source("bound_phase_schedule", binds["schedule_generator"])
    require(generator.schedule_bytes() == schedule_raw, "scheduled rows differ from the reviewed generator")
    plan = parse(schedule_raw)
    require(plan["protocol_sha256"] == PROTOCOL_SHA and len(plan["rows"]) == 324, "schedule binding mismatch")
    return value, plan["rows"]


def read_admission(path, digest, manifest_sha):
    record = parse(bound_bytes(dict(path=str(path), sha256=digest)))
    reviewers = record["critics"]
    require(record.get("manifest_sha256") == manifest_sha and record.get("protocol_sha256") == PROTOCOL_SHA
            and record.get("timed_capture_authorized") is True and type(reviewers) is list and len(reviewers) == 2
            and all(isinstance(item.get("reviewer"), str) and item["reviewer"] and item.get("objections") == []
                    for item in reviewers)
            and len({item["reviewer"] for item in reviewers}) == 2, "exact external admission is absent")


def invocation(manifest, manifest_path, manifest_sha, admission_path, admission_sha, output):
    binds = manifest["bindings"]
    recipe = [binds["python"]["path"], "-B", binds["driver"]["path"], "--manifest", str(manifest_path),
              "--manifest-sha256", manifest_sha, "--admission", str(admission_path),
              "--admission-sha256", admission_sha, "--out", str(output)]
    root = [binds["root_guard"]["path"], "--timeout", "150", "--", *recipe]
    backup = [binds["backup_guard"]["path"], "--timeout", "165", "--", *root]
    quoted = " ".join("'" + word.replace("'", "''") + "'" for word in backup)
    command = "$env:CODEX_TOOL_CALL_ID = $null; $env:CODEX_THREAD_ID = $null; & " + quoted + "; exit $LASTEXITCODE"
    shell = [binds["bootstrap_shell"]["path"], "-NoProfile", "-NonInteractive", "-Command", command]
    bootstrap = [binds["bootstrap_guard"]["path"], "--timeout", "180", "--", *shell]
    return dict(controller=recipe, root=root, backup=backup, shell=shell, bootstrap=bootstrap)


def verify_launch_receipt(manifest, recipe, observed):
    roles = ("root", "backup", "shell", "bootstrap")
    require(set(observed) == set(roles), "launcher ancestry roles differ")
    bindings = manifest["bindings"]
    seen = set()
    younger = None
    for role in roles:
        row = observed[role]
        binding = bindings["bootstrap_shell" if role == "shell" else role + "_guard"]
        require(integer(row["pid"]) and row["pid"] not in seen and integer(row["creation_filetime"])
                and row["path"].casefold() == binding["path"].casefold()
                and row["sha256"] == binding["sha256"] and row["argv"] == recipe[role],
                f"{role} actual launcher identity or argv differs")
        if younger is not None:
            require(younger["parent_pid"] == row["pid"] and row["creation_filetime"] <= younger["creation_filetime"],
                    "launcher lineage or birth chronology differs")
        seen.add(row["pid"])
        younger = row


def verify_holds(manifest, receipt):
    bindings = manifest["bindings"]
    hold = receipt["asset_hold"]
    require(hold["share_mode"] == "FILE_SHARE_READ" and set(hold["before"]) == set(hold["after"]) == set(bindings),
            "runtime hold coverage differs")
    for role, binding in bindings.items():
        item = hold["before"][role]
        require(item["path"] == binding["path"] and item["final_path"].casefold() == binding["path"].casefold()
                and item["sha256"] == binding["sha256"] and integer(item["file_id"])
                and integer(item["size"]) and integer(item["volume"], 0)
                and canonical(hold["after"][role]) == canonical(dict(held=item, reopened_path=item)),
                f"runtime held and reopened identity differs for {role}")


def verify_raw_rows(directory, rows):
    require({path.name for path in directory.iterdir() if path.is_dir()}
            == {f"{row['scheduled']['index']:04d}" for row in rows}, "raw row directories differ")
    for row in rows:
        folder = directory / f"{row['scheduled']['index']:04d}"
        require(canonical(parse((folder / "final.json").read_bytes())) == canonical(row), "raw final row differs")
        prepared = {name: row[name] for name in ("scheduled", "token", "argv")}
        prepared.update(status="INCOMPLETE", oracle_passed=False)
        require(canonical(parse((folder / "prepared.json").read_bytes())) == canonical(prepared), "prepared row differs")
        require((folder / "stdin.bin").stat().st_size == 0, "raw stdin differs")
        for stream in ("stdout", "stderr"):
            path = folder / f"{stream}.bin"
            require(path.stat().st_size <= 65536
                    and path.read_bytes().hex() == row["streams_before_cleanup"][stream + "_hex"], "raw output differs")


def row_argv(manifest, scheduled, token):
    condition, arm = scheduled["condition"], scheduled["arm"]
    binds = manifest["bindings"]
    fixture = "fixture" if condition == "A" else "diagnostic_fixture"
    payload = [binds[fixture]["path"], "exit", "0", token]
    if condition != "A":
        payload.append("phase0" if condition == "B" else "phase1")
    if arm != "bare":
        return [binds[arm]["path"], "--timeout", "2", "--", *payload]
    return payload


def decode_marker(stdout, row, frequency):
    scheduled, token = row["scheduled"], row["token"]
    require(isinstance(token, str) and re.fullmatch(r"[0-9a-f]{32}", token) is not None, "bad row nonce")
    prefix = f"BENCHMARK_DONE exit 0 {token}\n".encode("ascii")
    condition = scheduled["condition"]
    require(stdout.startswith(prefix), "original fixture nonce line differs")
    if condition == "A":
        require(stdout == prefix, "untouched fixture emitted additional bytes")
        return None
    match = MARKER.fullmatch(stdout[len(prefix):])
    require(match is not None and match[1] == token.encode("ascii"), "phase record or nonce differs")
    phase, pid, birth, freq, entry, flushed = map(int, match.groups()[1:])
    require(phase == (0 if condition == "B" else 1) and 0 < pid < 2**32
            and 0 < birth < 2**64 and freq == frequency, "phase identity or frequency differs")
    held = row["identity_before"]
    if scheduled["arm"] == "bare":
        require((pid, birth) == (held["pid"], held["creation_time"]), "bare marker differs from held process")
    else:
        require(pid != held["pid"], "guarded fixture marker used the guard identity")
    if condition == "B":
        require(entry == flushed == 0, "placeholder contains timestamps")
    else:
        require(entry - row["start_tick"] > 1 and entry <= flushed
                and row["measurement_end_tick"] - flushed > 1, "fixture QPC phase chronology is ambiguous")
    return dict(phase=phase, pid=pid, creation_filetime=birth, frequency=freq, entry_tick=entry,
                post_flush_tick=flushed, identity_source="held_match" if scheduled["arm"] == "bare" else "fixture_report")


def verify_row(row, expected, manifest, frequency, previous):
    require(canonical(row["scheduled"]) == canonical(expected) and row["status"] == "PASS"
            and row["oracle_passed"] is True, "missing, failed, or reordered row")
    require(row["argv"] == row_argv(manifest, expected, row["token"]) and row["cwd"] == manifest["cwd"]
            and row["environment"]["utf16_sha256"] == manifest["child_environment_sha256"], "launch context differs")
    require(exact_integer(row["creation_flags"], 0x08080404) and exact_integer(row["deadline_seconds"], 3)
            and exact_integer(row["expected_exit_u32"], 0), "row bounds or flags differ")
    free = row["admission"]["available_physical"]
    require(integer(free, 896 * 1024 * 1024) and row["admission"]["admitted"] is True
            and integer(row["disk_free_bytes"], 256 * 1024 * 1024), "row admission receipt differs")
    armed, deadline, start, end, settled = (row[name] for name in
        ("armed_tick", "armed_deadline_tick", "start_tick", "measurement_end_tick", "settled_tick"))
    require(all(map(integer, (armed, deadline, start, end, settled))) and deadline == armed + 3 * frequency
            and armed <= start < end <= deadline and previous < start and end < settled
            and row["elapsed_ticks"] == end - start and row["native_wait_observed_tick"] == end,
            "row QPC or armed deadline chronology differs")
    identity = row["identity_before"]
    pid, birth = identity["pid"], identity["creation_time"]
    require(integer(pid) and integer(birth) and canonical(identity) == canonical(row["identity_after"]),
            "held process identity changed")
    suspended, before, after = (row[name] for name in ("suspended", "root_before_cleanup", "root_after_cleanup"))
    require(all(exact_integer(item["pid"], pid) and exact_integer(item["creation_filetime"], birth)
                for item in (suspended, before, after))
            and suspended["member"] is True and exact_integer(suspended["native_wait"], 258)
            and all(exact_integer(item["native_wait"], 0) and exact_integer(item["exit_code_u32"], 0)
                    for item in (before, after))
            and exact_integer(row["resume_previous_suspend_count"], 1), "held native lifecycle evidence differs")
    create, wait, exit_code, cpu = (row[name] for name in ("create", "wait", "exit", "root_cpu"))
    handle = create["process_handle"]
    require(integer(handle) and all(exact_integer(item["process_handle"], handle) for item in (wait, exit_code, cpu))
            and exact_integer(create["native_return"], 1) and exact_integer(create["pid"], pid)
            and exact_integer(wait["native_return"], 0) and exact_integer(wait["query_end_tick"], end)
            and exact_integer(exit_code["native_return"], 1) and exact_integer(exit_code["exit_code_u32"], 0)
            and exact_integer(cpu["native_return"], 1) and exact_integer(cpu["pid"], pid)
            and exact_integer(cpu["creation_filetime"], birth)
            and integer(cpu["exit_filetime"], birth) and integer(cpu["kernel_100ns"], 0)
            and integer(cpu["user_100ns"], 0), "original handle or CPU evidence differs")
    require(row["watchdog_fired"] is False and row["watchdog_owns_distinct_job_handle"] is True
            and row["watchdog_handle_closed"] is True and row.get("trusted_cleanup_requested", False) is False
            and canonical(row["held_close"]) == canonical(dict(process=1, thread=1))
            and row["cleanup"]["active_after"] == 0 and all(row[key]["values"]["active_processes"] == 0
                for key in ("accounting_before_cleanup", "accounting_at_cleanup", "accounting_after_cleanup")),
            "watchdog or whole Job drain evidence differs")
    streams = row["streams_before_cleanup"]
    require(streams["stderr_hex"] == "" and len(streams["stdout_hex"]) <= 131072, "stream oracle differs")
    require(canonical(decode_marker(bytes.fromhex(streams["stdout_hex"]), row, frequency))
            == canonical(row["fixture_marker"]), "phase marker differs from captured stdout")
    return pid, birth


def verify_telemetry(samples, frequency, rows=None):
    require(0 < len(samples) <= len(BLOCK_BOUNDARIES) and (rows is None or len(samples) == len(BLOCK_BOUNDARIES)),
            "host sample count differs")
    origin = previous = samples[0]
    counters = ("qpc", "tick_ms", "awake_100ns", "idle_100ns", "kernel_100ns", "user_100ns")
    cpu = []
    for index, sample in zip(BLOCK_BOUNDARIES, samples):
        require(sample["index"] == index and integer(sample["wall_ns"]) and integer(sample["available_physical"])
                and all(integer(sample[k]) and sample[k] >= previous[k] for k in counters), "host counters differ")
        if rows is not None:
            if index:
                require(rows[index - 1]["settled_tick"] <= sample["qpc"], "host sample precedes prior row settlement")
            if index < len(rows):
                require(sample["qpc"] <= rows[index]["start_tick"], "host sample follows block start")
        require(abs((sample["wall_ns"] - origin["wall_ns"]) * frequency
                    - (sample["qpc"] - origin["qpc"]) * 1_000_000_000) <= 250_000_000 * frequency,
                "host wall/QPC drift crossed 250 ms")
        require((sample["tick_ms"] - origin["tick_ms"]) * 10_000
                - (sample["awake_100ns"] - origin["awake_100ns"]) <= 2_500_000, "host suspension crossed 250 ms")
        if index:
            total = sum(sample[key] - previous[key] for key in ("kernel_100ns", "user_100ns"))
            idle = sample["idle_100ns"] - previous["idle_100ns"]
            require(idle <= total, "host idle exceeds combined CPU counters")
            cpu.append(dict(macroblock=len(cpu), busy_ticks=total - idle, total_ticks=total))
        previous = sample
    return cpu
