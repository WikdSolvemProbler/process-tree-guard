"""Offline replay of one complete PROTOCOL-002 phase capture. Never launches a process."""

import argparse
from collections import defaultdict
import hashlib
import importlib.util
from pathlib import Path


SOURCE = Path(__file__).resolve()
COMMON = SOURCE.with_name("phase_common.py")
PHASES = ("pre", "body", "post")


def load_common():
    raw = COMMON.read_bytes()
    spec = importlib.util.spec_from_file_location("phase_common_replay", COMMON)
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(COMMON), "exec"), module.__dict__)
    return module, hashlib.sha256(raw).hexdigest()


M, COMMON_SHA = load_common()


def quantiles(values, count):
    M.require(len(values) == count, "cell population differs")
    ordered = sorted(values)
    return {f"p{p}": ordered[(count * p + 99) // 100 - 1] for p in (50, 90)}


def durations(rows, half=None):
    cells = defaultdict(list)
    for row in rows:
        slot = row["scheduled"]
        if half is None or slot["macroblock"] // 3 == half:
            cells[slot["condition"], slot["arm"]].append(row["elapsed_ticks"])
    return {condition: {arm: quantiles(cells[condition, arm], 36 if half is None else 18)
                        for arm in M.ARM_ORDER} for condition in "ABC"}


def calibration(cells, halves, frequency):
    def contrast(view, condition):
        return view[condition]["main"]["p90"] - view[condition]["wake"]["p90"]

    deltas = {condition: contrast(cells, condition) for condition in "ABC"}
    half_deltas = [{condition: contrast(view, condition) for condition in "ABC"} for view in halves]
    anchor, anchor_tolerance, perturbation = 7_907_900, 4_000_000, 2_000_000
    anchor_pass = abs(deltas["A"] * 1_000_000_000 - anchor * frequency) <= anchor_tolerance * frequency
    checks = [dict(check="anchor_magnitude", observed_ticks=deltas["A"], anchor_ns=anchor,
                   tolerance_ns=anchor_tolerance, passed=anchor_pass)]
    checks.extend(dict(check="anchor_half_positive", half=half, observed_ticks=view["A"], passed=view["A"] > 0)
                  for half, view in enumerate(half_deltas))
    checks.extend(dict(check="marker_direction_positive", condition=condition, observed_ticks=deltas[condition],
                       passed=deltas[condition] > 0) for condition in "BC")

    def perturbation_check(check, before, after, before_ticks, after_ticks, **labels):
        difference = after_ticks - before_ticks
        return dict(check=check, before=before, after=after, before_ticks=before_ticks, after_ticks=after_ticks,
                    difference_ticks=difference, tolerance_ns=perturbation,
                    passed=abs(difference) * 1_000_000_000 <= perturbation * frequency, **labels)

    for before, after in ("AB", "BC"):
        for arm in M.ARM_ORDER:
            for rank in ("p50", "p90"):
                checks.append(perturbation_check("arm_perturbation", before, after, cells[before][arm][rank],
                                                cells[after][arm][rank], arm=arm, quantile=rank))
        checks.append(perturbation_check("contrast_perturbation", before, after, deltas[before], deltas[after]))
    return dict(passed=all(check["passed"] for check in checks), contrast_ticks=deltas,
                half_contrast_ticks=half_deltas, checks=checks)


def phases(row):
    start, end = row["start_tick"], row["measurement_end_tick"]
    entry, flushed = (row["fixture_marker"][field] for field in ("entry_tick", "post_flush_tick"))
    spans = dict(pre=entry - start, body=flushed - entry, post=end - flushed)
    M.require(sum(spans.values()) == row["elapsed_ticks"], "phase spans do not sum to total")
    return spans


def paired_tail(rows, blocks, calibrated):
    grouped = defaultdict(dict)
    for row in rows:
        plan = row["scheduled"]
        if plan["condition"] == "C":
            grouped[plan["triplet"]][plan["arm"]] = row
    M.require(len(grouped) == 36 and all(set(arms) == set(M.ARM_ORDER) for arms in grouped.values()),
              "C triplet population differs")
    pairs = []
    for triplet, arms in grouped.items():
        spans = {arm: phases(row) for arm, row in arms.items()}
        totals = {arm: row["elapsed_ticks"] for arm, row in arms.items()}
        difference = {key: spans["main"][key] - spans["wake"][key] for key in PHASES}
        total = totals["main"] - totals["wake"]
        M.require(sum(difference.values()) == total, "paired phases do not sum to total contrast")
        earliest = min(row["scheduled"]["index"] for row in arms.values())
        block = arms["main"]["scheduled"]["macroblock"]
        pairs.append(dict(triplet=triplet, first_row=earliest, macroblock=block, phase_ticks=spans,
                          total_ticks=totals, phase_contrast_ticks=difference, total_contrast_ticks=total,
                          host_cpu=blocks[block], held_cpu={arm: row["root_cpu"] for arm, row in arms.items()}))
    order = sorted(pairs, key=lambda pair: (-pair["total_contrast_ticks"], pair["first_row"]))
    selected = order[:4]
    halves = [[pair for pair in order if pair["macroblock"] // 3 == half][:2] for half in (0, 1)]
    evidence = {}
    for phase in PHASES:
        positive_majorities = sum(pair["total_contrast_ticks"] > 0
                                  and 2 * pair["phase_contrast_ticks"][phase] > pair["total_contrast_ticks"]
                                  for pair in selected)
        positive_both_halves = all(pair["phase_contrast_ticks"][phase] > 0 for half in halves for pair in half)
        evidence[phase] = dict(positive_majority_pairs=positive_majorities,
                               positive_in_both_selected_pairs_per_half=positive_both_halves,
                               qualifies=positive_majorities >= 3 and positive_both_halves)
    candidates = [phase for phase, record in evidence.items() if record["qualifies"]]
    dominant = candidates[0] if calibrated and len(candidates) == 1 else None
    reasons = []
    if not calibrated:
        reasons.append("calibration_failed")
    if len(candidates) != 1:
        reasons.append("no_unique_dominant_phase")
    phase_quantiles = {arm: {phase: quantiles([pair["phase_ticks"][arm][phase] for pair in pairs], 36)
                             for phase in PHASES} for arm in M.ARM_ORDER}
    return dict(estimand="conditional C within-triplet tail, distinct from the frozen marginal p90 contrast",
                phase_quantile_ticks=phase_quantiles, pairs=pairs,
                selected_triplets=[pair["triplet"] for pair in selected],
                half_selected_triplets=[[pair["triplet"] for pair in half] for half in halves],
                dominance_checks=evidence, dominant_phase=dominant, unresolved_reasons=reasons)


def verify_terminal(terminal, args, recipe):
    process = terminal["process"]
    M.require(type(process["exit_code"]) is int and process["exit_code"] == 0
              and isinstance(process["terminal_chunk_id"], str) and process["terminal_chunk_id"]
              and process["argv"] == recipe["bootstrap"] and terminal["capture_sha256"] == args.capture_sha256
              and terminal["manifest_sha256"] == args.manifest_sha256
              and terminal["admission_sha256"] == args.admission_sha256
              and terminal["complete"] is True and type(terminal["rows"]) is int and terminal["rows"] == 324,
              "external terminal or bootstrap recipe differs")


def replay(args):
    manifest, planned = M.read_manifest(args.manifest, args.manifest_sha256)
    M.read_admission(args.admission, args.admission_sha256, args.manifest_sha256)
    bindings = manifest["bindings"]
    M.require(bindings["analysis"]["path"] == str(SOURCE) and bindings["common"]["path"] == str(COMMON)
              and bindings["common"]["sha256"] == COMMON_SHA, "loaded replay implementation differs")
    for binding in bindings.values():
        M.bound_bytes(binding)
    capture = M.parse(M.bound_bytes(dict(path=str(args.capture), sha256=args.capture_sha256)))
    terminal = M.parse(M.bound_bytes(dict(path=str(args.terminal), sha256=args.terminal_sha256)))
    directory = args.capture.parent
    M.require(args.capture.name == "capture.json" and str(directory) == manifest["output_directory"]
              and capture["output_directory"] == str(directory) and str(args.admission) == manifest["admission_path"],
              "capture path or admission path differs")
    M.require(capture["complete"] is True and capture.get("interrupted", False) is False
              and capture.get("error") is None and capture["protocol_sha256"] == M.PROTOCOL_SHA
              and capture["schedule_sha256"] == M.SCHEDULE_SHA and capture["manifest_sha256"] == args.manifest_sha256
              and capture["admission_sha256"] == args.admission_sha256 and M.integer(capture["qpc_frequency"]),
              "capture is incomplete, interrupted, or from a different admission")
    recipe = M.invocation(manifest, args.manifest, args.manifest_sha256, args.admission, args.admission_sha256, directory)
    verify_terminal(terminal, args, recipe)
    M.verify_launch_receipt(manifest, recipe, capture["launch"])
    M.verify_holds(manifest, capture)
    attempt = M.parse((directory / "attempt.json").read_bytes())
    M.require(attempt["complete"] is False and attempt["rows"] == []
              and attempt["manifest_sha256"] == args.manifest_sha256 and attempt["admission_sha256"] == args.admission_sha256
              and M.canonical(attempt["planned_rows"]) == M.canonical(planned), "prospective attempt differs")
    rows = capture["rows"]
    M.require(type(rows) is list and len(rows) == len(planned) == 324, "no-loss population differs")
    frequency = capture["qpc_frequency"]
    identities, tokens, previous = set(), set(), 0
    for row, expected in zip(rows, planned):
        identity = M.verify_row(row, expected, manifest, frequency, previous)
        token = row["token"]
        M.require(identity not in identities and token not in tokens, "original identity or nonce reused")
        identities.add(identity)
        tokens.add(token)
        previous = row["settled_tick"]
    blocks = M.verify_telemetry(capture["telemetry"], frequency, rows)
    M.verify_raw_rows(directory, rows)
    whole, halves = durations(rows), [durations(rows, half) for half in (0, 1)]
    checks = calibration(whole, halves, frequency)
    return dict(schema=1, scope="observed-load laptop phase diagnostic only", protocol_sha256=M.PROTOCOL_SHA,
                schedule_sha256=M.SCHEDULE_SHA, manifest_sha256=args.manifest_sha256, admission_sha256=args.admission_sha256,
                capture_sha256=args.capture_sha256, terminal_sha256=args.terminal_sha256, qpc_frequency=frequency,
                total_quantile_ticks=whole, half_total_quantile_ticks=halves, calibration=checks,
                block_cpu=blocks, paired_tail=paired_tail(rows, blocks, checks["passed"]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("manifest", "admission", "capture", "terminal", "out"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    for name in ("manifest", "admission", "capture", "terminal"):
        parser.add_argument(f"--{name}-sha256", required=True)
    args = parser.parse_args()
    M.write(args.out, replay(args))


if __name__ == "__main__":
    main()
