# Manual startup phase diagnostic

This preregistration covers one bounded Windows x64 development diagnostic. Its question is which observed span carries the manual startup tail difference between consolidated process-tree-guard and Windows-repaired Wake when both executables run unchanged on the same laptop. The diagnostic distinguishes the period before fixture entry, the fixture's original body, and the period after the original stdout flush. It cannot attribute any span to a single API or isolate scheduler, loader, and application work within that span.

The anchor is directional capture 002, which completed 2,967 rows under observed load. Manual startup nearest-rank p90 was 107.1302 ms for main and 99.2223 ms for Wake, a +7.9079 ms contrast with L4 interval [2.6032, 17.0082] ms. Use the original retained bytes. [Capture terminal](C:/Users/Peter/process-tree-guard/target/codex-security/wake-msvc-driver-dev-001/directional-capture-002-terminal.json) · [Analysis](C:/Users/Peter/process-tree-guard/target/codex-security/wake-msvc-driver-dev-001/analysis-002.json)

| Anchor | SHA-256 |
|---|---|
| Operational manifest 003 | `c980b1ebd3407baee2852d3f6e9fc4db2d883887a5690547b9efca4e311d2118` |
| Raw capture 002 | `d92ccdb12c51eadc703674d1f1758f09d71624f12b5cedd5b4968ee5667d0258` |
| Analysis 002 | `5f8186357f43872f82bbce7a7c9f2b7c97f23a1d322b3f8c829ddf946012931e` |

## Binaries and launch conditions

| Role | Exact input |
|---|---|
| `main` | Candidate commit `8bf828a467e03d9f5f249a9da76b5845df53d057`, executable SHA-256 `f7f6e1fca2533e651ece4b44f6a484e6903612252d3aa466870314b920dc2e02` |
| `wake` | Wake origin `681ad2300ff86826c600eeccadc4063dedb46b66`, Windows repair `9c6f0df93cee92dcaca0e89ebc3f09134eeab53d`, executable SHA-256 `50f73d903f03ab580d4dbe1335a055febcd2aef4a79d04c5a5a179d358324770` |
| Original fixture | Executable SHA-256 `81678345d3b1bb31bbeaee1872580764386274d64f98129b538c80b20ed058d0` at the operational manifest's exact fixture path |
| Diagnostic fixture | One new executable for both marker modes. Derive it from fixture source SHA-256 `b42f15eb89ff60c0b730b17ab926d448ac81f6eb0248024feb39a1d4c050d712`, retain the patch, and bind its build inputs and final executable before timing. |

Reuse the original manual `--timeout 2 --` guard invocation, neutral working directory, Windows `NO_WINDOW` context, and real file handles for stdin, stdout, and stderr. Start the original process suspended with flags `0x08080404` and admit it atomically to a private Job with flags `0x2208`, a 384 MiB Job memory cap, and an active-process limit of eight. Keep the production guard's owner observation, deadline, console behavior, and cleanup active. The `bare` arm launches the same condition's fixture directly through the same controller and outer Job. Require `PROCESS_GUARD_TRACE`, `PROCESS_TREE_GUARD_TRACE`, `PROCESS_GUARD_TIMING_NONCE`, `PROCESS_TREE_GUARD_TIMING_NONCE`, and extension channels to be absent. Use the same sanitized environment in all rows and bind its exact UTF-16 block digest before launch. The reference environment digest is `89686df12aa8805d2405f807737ab631ad0e575517782a4c0821d4b727cbf4a4`. Any required environment amendment must be reviewed and recorded before timing. [Operational manifest](C:/Users/Peter/process-tree-guard/target/codex-security/wake-msvc-driver-dev-001/capture-manifest-operational-003.json)

The original `exit` branch already samples QPC at Rust main entry and publishes no timestamp. Preserve its original `BENCHMARK_DONE exit 0 TOKEN\n` bytes, flush and exit. Keep the diagnostic patch local to the `exit 0 TOKEN phase0|phase1` form and use the exact same executable and absolute path for B and C. Capture no output from the other fixture verbs. [Fixture source](C:/Users/Peter/HerrNest/benchmark-lab-20261025/harness/fixture/src/main.rs:382)

| Condition | Exact fixture arguments | Required stdout after the original nonce line |
|---|---|---|
| A | `exit 0 TOKEN` on the original executable | Empty |
| B | `exit 0 TOKEN phase0` on the diagnostic executable | One fixed-width record with placeholder timestamp fields |
| C | `exit 0 TOKEN phase1` on the same diagnostic executable | The same record shape with actual timestamp fields |

`TOKEN` is a unique 32-character lowercase hexadecimal nonce per launch. B and C take the same entry QPC, post-flush QPC, process identity, and frequency reads. Both write and flush exactly one extra ASCII record to the existing stdout file after the original nonce line has flushed. The record consists of `PTG_FIXTURE_PHASE_V1 TOKEN PHASE PID CREATION FREQ ENTRY POST_FLUSH` followed by LF. Use one space between fields, a single `0` or `1` for `PHASE`, 10 zero-padded decimal digits for `PID`, and 20 zero-padded decimal digits for each remaining numeric field. B replaces `ENTRY` and `POST_FLUSH` with 20 zeros each. No other output is permitted and stderr stays empty. Both branches leave through the original native exit-zero path. A to B measures the combined perturbation from the diagnostic executable, its path and arguments, and extra marker work. B to C checks the additional effect of selecting and reporting the timestamp values under the matched workload.

## Exact schedule and bounds

Run 6 chronological macroblocks indexed from 0. Each contains 3 condition groups of 6 consecutive triplets, with 3 launches per triplet. There are 108 triplets and **324 planned launches**, with 36 triplets per condition and 36 launches per condition/arm cell. Keep every planned launch. Any fixture-only and guard safety qualification is a separate, untimed run with a separate output namespace. The diagnostic has no discarded prefix.

| Macroblock | Condition groups in order |
|---|---|
| 0 | A, B, C |
| 1 | B, C, A |
| 2 | C, A, B |
| 3 | C, B, A |
| 4 | B, A, C |
| 5 | A, C, B |

Use the following base arm order list, with positions indexed from zero.

1. `main, wake, bare`
2. `main, bare, wake`
3. `wake, main, bare`
4. `wake, bare, main`
5. `bare, main, wake`
6. `bare, wake, main`

In macroblock `b` and condition `c`, use cyclic left rotation `(b + c) mod 6`, with condition indices A=0, B=1, C=2. A triplet is an unbroken serial sequence of its three arms. Require zero active Job members and held-handle cleanup for one row before admitting the next. Emit the explicit full row schedule and freeze its bytes and digest before launch. Preserve condition, macroblock, triplet, permutation, position, and row index for every receipt.

Keep the guard's explicit 2-second payload timeout and use a separate 3-second private whole-Job arm watchdog. Require at least 896 MiB available physical memory and 256 MiB free disk at each row's admission. Set independent outer whole-tree deadlines of 150 seconds for root, 165 seconds for backup, and 180 seconds for bootstrap. Stop admitting rows 15 seconds before the conservative root or backup cutoff, whichever comes first. Deadline exhaustion invalidates the run and preserves its partial evidence. Verify actual wrapper image, command line, ancestry, finite deadline, and output paths before admitting rows. Retain external terminal receipts and distinguish an outer process exit from a complete diagnostic capture.

## Clock and raw receipts

Use raw native `QueryPerformanceCounter` ticks for all four phase stamps and the per-arm armed deadline. Use one positive `QueryPerformanceFrequency` for the controller and require an identical fixture-reported frequency. Keep stamps and durations as integers. Compute comparisons in ticks or with exact rational conversion, and round only for display. A difference of one tick or less across threads is ambiguous. [Microsoft QPC guidance](https://learn.microsoft.com/en-us/windows/win32/sysinfo/acquiring-high-resolution-time-stamps)

| Stamp | Location |
|---|---|
| `T0` | Controller QPC immediately before the original `CreateProcessW` call |
| `T1` | Existing fixture QPC near the entry of Rust `main`, before argument parsing |
| `T2` | Fixture QPC immediately after the original nonce line has flushed, before marker construction or publication |
| `T3` | Controller QPC immediately after the first native `WaitForSingleObject` return on the original retained process handle |

Bind outer create, wait, exit code, identity, and post-wait `GetProcessTimes` CPU data to the original handle and same PID and creation FILETIME. The fixture marker binds the trusted fixture's self-reported PID and creation FILETIME to its launch nonce. For bare rows in B and C, require those values to equal the held original process identity. For guarded rows, require a nonzero fixture PID distinct from the guard's PID and retain the fixture identity as self-reported. Keep process FILETIME values separate from raw QPC and use user/kernel CPU times only as corroboration. [Microsoft GetProcessTimes](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getprocesstimes)

For every row require `armed_tick <= T0 < T3 <= armed_deadline_tick` and `armed_deadline_tick = armed_tick + 3 × FREQ`. Require native wait zero, exit DWORD zero, the expected stdout and empty stderr, and no watchdog or external cleanup intervention. For C additionally require `T1 - T0 > 1`, `T1 <= T2`, and `T3 - T2 > 1`. Stamp `settled_tick` after Job drain and held-handle cleanup. Require `T3 < settled_tick`, `previous settled_tick < T0`, and unique original PID and creation FILETIME pairs. Keep all phase stamps, signed paired contrasts, raw accounting, and native oracle returns. Use explicit signed integers for phase contrasts.

The C spans are `pre = T1 - T0`, `body = T2 - T1`, and `post = T3 - T2`. They sum exactly to `total = T3 - T0`. `pre` includes outer launch instrumentation, guard loading and setup, fixture creation, and scheduling before fixture entry. `body` includes the fixture work up to its original stdout flush. `post` includes marker I/O, fixture exit, guard cleanup and exit, and controller wake. The diagnostic has no separate timestamp for native fixture exit, guard exit, or a particular cleanup API.

Record wall time in nanoseconds, raw QPC, `GetTickCount64` milliseconds, `QueryUnbiasedInterruptTime` 100 ns ticks, physical RAM, and `GetSystemTimes` idle/kernel/user counters before each macroblock and after the final one. Validate samples against the surrounding rows in the QPC clock. Require nondecreasing QPC, uptime, awake, idle, kernel and user counters. Relative to the first host sample, invalidate if `abs(Δwall_ns × FREQ − Δqpc × 1,000,000,000) > 250,000,000 × FREQ` or if `Δuptime_ms × 10,000 − Δawake_100ns > 2,500,000`. Retain per-block busy CPU as `(Δkernel + Δuser − Δidle) / (Δkernel + Δuser)` when the denominator is positive. Run on the laptop under observed load, with no agent build or correctness workload overlapping the diagnostic. General laptop activity is part of the observation. Block CPU and bare phases describe the host context without establishing its cause.

## Preregistered calculations and acceptance

Report all 9 condition/arm cells with nearest-rank p50 and p90 of `total`. Use ascending rank `ceil(n × p)` for each quantile, so p50 and p90 use ranks 18 and 33 with 36 observations per cell. For the first and second three-block halves separately, use ranks 9 and 17 with 18 observations. Define `D_A`, `D_B`, and `D_C` as each condition's main p90 minus Wake p90, and keep separate values for the two chronological halves. This is a contrast of two marginal quantiles.

An interpretable localization requires every capture gate and all of the following prospective checks.

1. `D_A > 0` overall and in both chronological halves. This establishes the descriptive direction for the untouched-fixture lane in this diagnostic.
2. `D_B > 0` and `D_C > 0` overall. A marker condition that changes the whole-lifetime direction fails the perturbation check.
3. `abs(D_B - D_A) <= 2.000 ms` and `abs(D_C - D_B) <= 2.000 ms`, inclusive, before display rounding. Two milliseconds is about a quarter of the original +7.9079 ms tail contrast. It bounds perturbation for this localization question and carries no equivalence inference.

For C report p50 and p90 of all three phase spans per arm, together with each triplet's signed `main − Wake` vector and its exact summed total. Keep the bare phase vector for that triplet beside it. The phase percentiles are descriptive and must never be added to explain a marginal p90 contrast.

To inspect the paired tail, sort the 36 C triplets by descending `main total − Wake total`, breaking ties by the earliest scheduled row of the triplet. Select the first 4 before examining components. Also select the first 2 within each chronological half under the same rule. Record the selected indices and all components. A phase earns the descriptive label **dominant in the paired tail** only if at least 3 of the 4 full-sample selected pairs have a strictly positive total contrast and that same phase contributes strictly more than half of that pair's total contrast, and the phase contrast is strictly positive in both selected pairs within each half. Evaluate integer inequalities in raw ticks. If no phase qualifies, or more than one qualifies because other phase contrasts are negative, report the localization as inconclusive and retain the phase estimates.

Inspect whether the contemporaneous bare phase and block load co-move with the selected slow rows, and whether the held guard's user/kernel CPU shifts with its wall time. A shared pattern suggests host investigation. A repeatable excess confined to one span suggests inspecting the corresponding guard and OS paths. Neither observation establishes a causal attribution. The paired-tail diagnostic is a different estimand from the frozen marginal p90 contrast.

## Evidence retention and scope

Before launch freeze the protocol, exact binaries and source hashes, build receipts, driver, analysis, explicit schedule, environment receipt, fixture-only qualification, and exact finite launch recipe in an externally digested manifest. Verify held read-share-only handles and terminal reopened identities for the protected runtime inputs. Require two independent reviewers to approve the exact manifest with zero unresolved objections before timed execution. Preserve this preregistration as written and keep any amendment as a new dated artifact with its own review.

Keep the controller's prepared and final receipts, stdout and stderr bytes, partial rows and timeout receipts, host telemetry, external process terminal, and all analysis output in an exclusive fresh namespace. No missing, failed, repeated, substituted, reordered, trimmed, or censored row can enter the complete analysis. Stop at the first invalid row, preserve the entire attempted prefix and planned suffix, and write an incomplete disposition. An interrupted or incomplete attempt has no phase verdict. No automatic rerun or deadline extension is allowed. Preserve the completed raw digest before replay and require independent recomputation from the raw rows.

A calibration failure or lack of a dominant phase leaves localization unresolved. Even a dominant-phase result is a hypothesis for follow-up under this laptop's observed load. This diagnostic supplies no equivalence, noninferiority, production acceptance, quiet-hardware speed record, or cross-host claim. The frozen 16-endpoint result remains the performance evidence for its original scope. [Issue #7](https://github.com/WikdSolvemProbler/process-tree-guard/issues/7)
