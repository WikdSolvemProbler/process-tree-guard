"""Canonical 324-row order for PROTOCOL-002.md."""

import hashlib
import json
from pathlib import Path
import sys


PROTOCOL_SHA256 = "3b3249d91c284adccb249185b39371765e1a113642d23dccb24e0af2cb1b183c"
GROUPS = ("ABC", "BCA", "CAB", "CBA", "BAC", "ACB")
ORDERS = (
    ("main", "wake", "bare"),
    ("main", "bare", "wake"),
    ("wake", "main", "bare"),
    ("wake", "bare", "main"),
    ("bare", "main", "wake"),
    ("bare", "wake", "main"),
)


def make_schedule():
    rows = []
    triplet = 0
    for block, groups in enumerate(GROUPS):
        for condition in groups:
            rotation = (block + "ABC".index(condition)) % len(ORDERS)
            for offset in range(len(ORDERS)):
                permutation = (rotation + offset) % len(ORDERS)
                for position, arm in enumerate(ORDERS[permutation]):
                    rows.append(dict(
                        index=len(rows), macroblock=block, condition=condition,
                        triplet=triplet, permutation=permutation, position=position,
                        arm=arm,
                    ))
                triplet += 1
    return dict(schema=1, protocol_sha256=PROTOCOL_SHA256, rows=rows)


def schedule_bytes():
    return (json.dumps(make_schedule(), sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


if __name__ == "__main__":
    protocol = Path(__file__).resolve().with_name("PROTOCOL-002.md")
    if hashlib.sha256(protocol.read_bytes()).hexdigest() != PROTOCOL_SHA256:
        raise SystemExit("frozen protocol digest mismatch")
    sys.stdout.buffer.write(schedule_bytes())
