"""Bounded, fixture-only qualification of the exact PROTOCOL-002 launcher."""

import argparse
from copy import deepcopy
import hashlib
import importlib.util
import os
from pathlib import Path
import sys
import time


HERE = Path(__file__).resolve().parent
SOURCE = Path(__file__).resolve()
DRIVER = HERE / "capture.py"
DRIVER_SHA = "4fea0484a35b5d3a43d8d531983d7c62b9eeea279ff0edc87c4f8820d31856b6"
BUILD_SHA = "d0f3318aee9a458f879c2081ac4eefdbbf9c42b626ad887dfb894ef36268a45f"
REQUIREMENTS_SHA = "d04abca9d2e690d029f51b2fc104e51112de14540ffa0a7059a1ce78026f9d4d"
DIAGNOSTIC_SHA = "51674ae180a14f7745e07757377b970d6dffd26374d4f225aa97555c6ce871a8"
TOOLCHAIN_SHA = "ef9ab505f499d76808868bc5e0d61c90985463637666576556c2d9aaae105e5b"


def load_driver():
    raw = DRIVER.read_bytes()
    if hashlib.sha256(raw).hexdigest() != DRIVER_SHA:
        raise ValueError("qualification capture source digest changed")
    spec = importlib.util.spec_from_file_location("fixture_proof_capture", DRIVER)
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(DRIVER), "exec"), module.__dict__)
    return module


C = load_driver()
M = C.M


def expected_recipe(inputs, input_path, digest, out):
    binds = inputs["bindings"]
    controller = [binds["python"]["path"], "-B", str(SOURCE), "--inputs", str(input_path),
                  "--inputs-sha256", digest, "--out", str(out)]
    root = [binds["root_guard"]["path"], "--timeout", "150", "--", *controller]
    backup = [binds["backup_guard"]["path"], "--timeout", "165", "--", *root]
    quoted = " ".join("'" + word.replace("'", "''") + "'" for word in backup)
    command = "$env:CODEX_TOOL_CALL_ID = $null; $env:CODEX_THREAD_ID = $null; & " + quoted + "; exit $LASTEXITCODE"
    shell = [binds["bootstrap_shell"]["path"], "-NoProfile", "-NonInteractive", "-Command", command]
    bootstrap = [binds["bootstrap_guard"]["path"], "--timeout", "180", "--", *shell]
    return dict(controller=controller, root=root, backup=backup, shell=shell, bootstrap=bootstrap)


def verify_launch(base, S, inputs, recipe):
    actual = [sys.executable, "-B", str(SOURCE), *sys.argv[1:]]
    M.require(actual == recipe["controller"] and os.getcwd().casefold()
              == inputs["launch"]["working_directory"].casefold(), "fixture controller argv or cwd differs")
    base.controller_argv = lambda: actual
    observed, cutoff = base.guard_chain(S, inputs)
    observed["shell"] = C.inspect_ancestor(S, observed["backup"]["parent_pid"])
    observed["bootstrap"] = C.inspect_ancestor(S, observed["shell"]["parent_pid"])
    for role in ("root", "backup", "shell", "bootstrap"):
        binding = inputs["bindings"]["bootstrap_shell" if role == "shell" else role + "_guard"]
        observed[role]["sha256"] = M.sha(M.bound_bytes(binding))
    M.verify_launch_receipt(inputs, recipe, observed)
    epoch_ns = 11_644_473_600_000_000_000
    age = (time.time_ns() + epoch_ns - observed["bootstrap"]["creation_filetime"] * 100) / 1e9
    M.require(0 <= age < 165, "bootstrap deadline is inconsistent")
    return observed, min(cutoff, time.monotonic() + 165 - age)


def verify_build(binds):
    projected = M.parse(M.bound_bytes(binds["fixture_build"]))
    raw_binding, req_binding = binds["raw_build"], binds["build_requirements"]
    raw = M.parse(M.bound_bytes(raw_binding))
    requirements = M.parse(M.bound_bytes(req_binding))
    paths = dict(fixture_source="fixture_source_sha256", fixture_patch="patch_sha256",
                 fixture_manifest="cargo_toml_sha256", fixture_lockfile="cargo_lock_sha256")
    exe = binds["diagnostic_fixture"]
    M.require(raw_binding["sha256"] == BUILD_SHA and req_binding["sha256"] == REQUIREMENTS_SHA
              and exe["sha256"] == DIAGNOSTIC_SHA and raw["requirements_sha256"] == REQUIREMENTS_SHA
              and raw["toolchain_manifest_sha256"] == requirements["matched_inputs_sha256"] == TOOLCHAIN_SHA
              and binds["matched_toolchain"]["sha256"] == TOOLCHAIN_SHA, "fixture build anchor differs")
    M.require(M.exact_integer(raw["exit_code"], 0) and raw["executable"] == exe["path"]
              and raw["executable_sha256"] == exe["sha256"] and raw["source_sha256"] == binds["fixture_source"]["sha256"]
              and raw["cwd"] == str(Path(binds["fixture_manifest"]["path"]).parent)
              and raw["argv"] == [requirements["tools"][1]["path"], "-vv", *requirements["config_arguments"],
                                  *requirements["build_arguments"]]
              and requirements["target"] == "x86_64-pc-windows-msvc", "raw fixture build identity differs")
    for role, field in paths.items():
        M.require(requirements[field] == projected[role + "_sha256"] == binds[role]["sha256"],
                  f"{role} build input differs")
    for stream in ("stdout", "stderr"):
        binding = projected["build_logs"][stream]
        M.require(M.sha(M.bound_bytes(binding)) == raw[stream + "_sha256"], f"raw build {stream} differs")
    M.require(projected["passed"] is True and projected["protocol_sha256"] == M.PROTOCOL_SHA
              and projected["diagnostic_fixture_sha256"] == DIAGNOSTIC_SHA
              and projected["raw_build_receipt"] == raw_binding and projected["requirements"] == req_binding
              and projected["matched_toolchain"] == binds["matched_toolchain"], "normalized build projection differs")
    return projected


def prepare(inputs):
    binds = inputs["bindings"]
    extras = {"qualification_driver", "raw_build", "build_requirements", "matched_toolchain"}
    M.require(set(binds) == (M.ROLES - {"fixture_qualification"}) | extras, "fixture proof binding roles differ")
    M.require(binds["qualification_driver"]["path"] == str(SOURCE) and binds["driver"]["path"] == str(DRIVER)
              and binds["driver"]["sha256"] == DRIVER_SHA and binds["common"]["sha256"] == C.COMMON_SHA
              and binds["python"]["path"] == sys.executable, "loaded qualifier, Python, or driver source differs")
    expected = {**M.ORIGINAL, **M.QUALIFIED, "protocol": M.PROTOCOL_SHA, "schedule": M.SCHEDULE_SHA,
                **dict.fromkeys(("root_guard", "backup_guard", "bootstrap_guard"), M.GUARD_SHA)}
    for role, digest in expected.items():
        M.require(binds[role]["sha256"] == digest, f"exact fixture proof input differs for {role}")
    for binding in binds.values():
        M.bound_bytes(binding)
    M.require(inputs["child_environment_sha256"] == M.ENV_SHA, "proof environment differs from the frozen protocol")
    generator = M.load_source("fixture_proof_schedule", binds["schedule_generator"])
    schedule_raw = M.bound_bytes(binds["schedule"])
    M.require(generator.schedule_bytes() == schedule_raw, "frozen schedule reconstruction differs")
    selected = {}
    for row in M.parse(schedule_raw)["rows"]:
        if row["arm"] == "bare":
            selected.setdefault(row["condition"], row)
    M.require(tuple(selected) == tuple("ABC") and [row["index"] for row in selected.values()] == [2, 19, 38],
              "fixture-only row selection differs")
    base = M.load_source("fixture_proof_base", binds["base_driver"])
    M.require(base.ANALYSIS_SHA == binds["base_analysis"]["sha256"]
              and base.A.SCHEDULE_SOURCE_SHA == binds["base_schedule"]["sha256"], "loaded frozen support differs")
    D = M.load_source("fixture_proof_suspended", binds["base_suspended"])
    for role, (path, digest) in D.INPUTS.items():
        M.require(binds[role] == dict(path=str(path), sha256=digest), f"qualified native {role} differs")
    M.require(inputs["cwd"] == str(D.CWD) and D.CWD.is_dir(), "neutral fixture cwd differs")
    phase = M.load_source("fixture_proof_phase_native", binds["native_derivative"])
    return base, D, phase, selected


def verify_child_environment(D, P, inputs):
    context, _ = P.environment(dict(os.environ))
    forbidden = {"PROCESS_GUARD_TRACE", "PROCESS_TREE_GUARD_TRACE", "PROCESS_GUARD_TIMING_NONCE",
                 "PROCESS_TREE_GUARD_TIMING_NONCE", "PROCESS_TREE_GUARD_CHANNEL", "CODEX_TOOL_CALL_ID", "CODEX_THREAD_ID"}
    evidence = D.environment_block(P)[1]
    M.require(not (forbidden & {key.upper() for key in context}) and evidence["utf16_sha256"] == M.ENV_SHA,
              "fixture-only launch environment differs")
    persisted = M.parse(M.bound_bytes(inputs["bindings"]["environment_receipt"]))
    M.require(persisted["child_environment_sha256"] == M.ENV_SHA, "bound environment receipt differs")
    return evidence


def fixture_rows(root, selected, D, N, P, S, phase, clock, inputs, cutoff, receipt):
    root.mkdir()
    identities, previous = set(), 0
    for condition, scheduled in selected.items():
        M.require(time.monotonic() < cutoff and scheduled["arm"] == "bare", "bare fixture admission refused")
        folder = root / f"{scheduled['index']:04d}"
        folder.mkdir()
        token = {"A": "a", "B": "b", "C": "c"}[condition] * 32
        row = dict(scheduled=scheduled, token=token, argv=M.row_argv(inputs, scheduled, token),
                   status="INCOMPLETE", oracle_passed=False)
        receipt["fixture_rows"].append(row)
        fixture_role = "fixture" if condition == "A" else "diagnostic_fixture"
        M.require(row["argv"][0] == inputs["bindings"][fixture_role]["path"], "candidate launch refused")
        M.write(folder / "prepared.json", row)
        try:
            C.capture_row(D, N, P, S, phase, clock, inputs, row, folder)
            row.update(status="PASS", oracle_passed=True)
            identity = M.verify_row(row, scheduled, inputs, clock.frequency, previous)
            M.require(identity not in identities, "fixture original identity reused")
            identities.add(identity)
            previous = row["settled_tick"]
        except BaseException as error:
            row.update(status="FAIL", oracle_passed=False, error=repr(error))
            raise
        finally:
            M.write(folder / "final.json", row)
    M.verify_raw_rows(root, receipt["fixture_rows"])


def qualification_controls(root, base, D, N, P, S, phase, clock, inputs, cutoff, receipt):
    root.mkdir()
    for name in ("forced-timeout", "asynchronous-watchdog"):
        M.require(time.monotonic() < cutoff, "control admission cutoff reached")
        folder = root / name
        folder.mkdir()
        argv = [inputs["bindings"]["testkit"]["path"], "sleep", "5"]
        row = dict(name=name, argv=argv, passed=False)
        receipt["controls"].append(row)
        M.write(folder / "prepared.json", row)
        try:
            asynchronous = name == "asynchronous-watchdog"
            phase.arm(D, N, P, S, clock, row, folder, argv, 3, D.WATCHDOG_EXIT if asynchronous else None,
                      b"", capture=not asynchronous, expect_watchdog=asynchronous, expected_env_sha256=M.ENV_SHA)
            M.require(row["armed_deadline_tick"] == row["armed_tick"] + 3 * clock.frequency
                      and row["watchdog_owns_distinct_job_handle"] is True and row["watchdog_handle_closed"] is True
                      and M.canonical(row["held_close"]) == M.canonical(dict(process=1, thread=1))
                      and M.exact_integer(row["accounting_after_cleanup"]["values"]["active_processes"], 0),
                      "control deadline or handle/Job drain proof differs")
            if asynchronous:
                ended, final = row["root_before_cleanup"], row["root_after_cleanup"]
                original = row["suspended"]
                M.require(row["watchdog_fired"] is True and M.exact_integer(row["watchdog_terminate_return"], 1)
                          and not row.get("trusted_cleanup_requested")
                          and row["armed_deadline_tick"] <= row["watchdog_fired_tick"] <= row["native_wait_observed_tick"]
                          and all(M.exact_integer(item["native_wait"], 0)
                                  and M.exact_integer(item["exit_code_u32"], D.WATCHDOG_EXIT)
                                  and (item["pid"], item["creation_filetime"]) ==
                                      (original["pid"], original["creation_filetime"]) for item in (ended, final)),
                          "asynchronous control did not prove terminal original and watchdog exit")
            else:
                base.A.validate_control(row, "forced-timeout")
            row["passed"] = True
        except BaseException as error:
            row["error"] = repr(error)
            raise
        finally:
            M.write(folder / "final.json", row)


def marker_bytes(row, **updates):
    data = {**row["fixture_marker"], **updates}
    token = updates.get("token", row["token"])
    return (f"BENCHMARK_DONE exit 0 {row['token']}\nPTG_FIXTURE_PHASE_V1 {token} {data['phase']} "
            f"{data['pid']:010d} {data['creation_filetime']:020d} {data['frequency']:020d} "
            f"{data['entry_tick']:020d} {data['post_flush_tick']:020d}\n").encode("ascii")


def synthetic_negatives(receipt, inputs, frequency):
    a, b, c = receipt["fixture_rows"]
    cases = receipt["synthetic_negatives"]

    def reject(name, expected, check):
        try:
            check()
        except ValueError as error:
            cases.append(dict(name=name, expected=expected, observed=str(error), passed=expected in str(error)))
            M.require(cases[-1]["passed"], f"wrong rejection for {name}")
        else:
            cases.append(dict(name=name, expected=expected, passed=False))
            raise ValueError(f"synthetic {name} was accepted")

    plain = bytes.fromhex(a["streams_before_cleanup"]["stdout_hex"])
    good = marker_bytes(c)
    reject("A_extra_record", "additional bytes", lambda: M.decode_marker(plain + b"extra\n", a, frequency))
    reject("C_malformed_width", "record or nonce", lambda: M.decode_marker(good[:-2] + b"\n", c, frequency))
    reject("C_stale_nonce", "record or nonce", lambda: M.decode_marker(marker_bytes(c, token="0" * 32), c, frequency))
    reject("C_wrong_frequency", "identity or frequency", lambda: M.decode_marker(marker_bytes(c, frequency=frequency + 1), c, frequency))
    reject("C_wrong_bare_pid", "held process", lambda: M.decode_marker(marker_bytes(c, pid=c["fixture_marker"]["pid"] + 1), c, frequency))
    reject("B_nonzero_placeholder", "placeholder contains", lambda: M.decode_marker(marker_bytes(b, entry_tick=1), b, frequency))
    reject("C_entry_within_one_tick", "chronology is ambiguous", lambda: M.decode_marker(marker_bytes(c, entry_tick=c["start_tick"] + 1), c, frequency))
    reject("C_flush_within_one_tick", "chronology is ambiguous", lambda: M.decode_marker(marker_bytes(c, post_flush_tick=c["measurement_end_tick"] - 1), c, frequency))
    reject("C_entry_after_flush", "chronology is ambiguous", lambda: M.decode_marker(marker_bytes(c, entry_tick=c["fixture_marker"]["post_flush_tick"] + 1), c, frequency))
    late = deepcopy(c)
    late["armed_deadline_tick"] = late["measurement_end_tick"] - 1
    late["armed_tick"] = late["armed_deadline_tick"] - 3 * frequency
    reject("C_native_endpoint_after_armed_deadline", "armed deadline chronology", lambda: M.verify_row(late, c["scheduled"], inputs, frequency, 0))
    wrong_wait = deepcopy(c)
    wrong_wait["wait"]["native_return"] = 258
    reject("C_endpoint_wait_is_liveness_result", "original handle or CPU evidence", lambda: M.verify_row(wrong_wait, c["scheduled"], inputs, frequency, 0))


def run(args, out):
    receipt = dict(schema=1, scope="untimed fixture-only qualification", passed=False,
                   protocol_sha256=M.PROTOCOL_SHA, input_sha256=args.inputs_sha256,
                   candidate_arms_executed=False, qualified_conditions=[], fixture_rows=[], controls=[], synthetic_negatives=[])
    hold = None
    try:
        inputs = M.parse(M.bound_bytes(dict(path=str(args.inputs), sha256=args.inputs_sha256)))
        M.require(inputs["state"] == "FIXTURE_ONLY_NOT_ADMITTED" and inputs["output_directory"] == str(out)
                  and inputs["timed_capture_authorized"] is False, "expected fixture-only inputs and fresh output")
        base, D, phase, selected = prepare(inputs)
        binds = inputs["bindings"]
        hold = base.RuntimeHold(binds)
        receipt["asset_hold"] = dict(share_mode="FILE_SHARE_READ", before=hold.acquire())
        projection = verify_build(binds)
        receipt.update(native_derivative_sha256=binds["native_derivative"]["sha256"],
                       diagnostic_fixture_sha256=DIAGNOSTIC_SHA, child_environment_sha256=M.ENV_SHA,
                       build_projection=binds["fixture_build"], raw_build_receipt=projection["raw_build_receipt"],
                       qualification_driver_sha256=binds["qualification_driver"]["sha256"])
        S, N, P = (D.load(role) for role in ("support", "native", "policy"))
        recipe = expected_recipe(inputs, args.inputs, args.inputs_sha256, out)
        receipt["recipe"] = recipe
        receipt["launch"], cutoff = verify_launch(base, S, inputs, recipe)
        receipt["environment"] = verify_child_environment(D, P, inputs)
        clock = phase.Clock()
        receipt["qpc_frequency"] = clock.frequency
        receipt["host_start"] = C.host_sample(base, S, N, clock, 0)
        M.write(out / "preflight.json", receipt)
        fixture_rows(out / "rows", selected, D, N, P, S, phase, clock, inputs, cutoff, receipt)
        qualification_controls(out / "controls", base, D, N, P, S, phase, clock, inputs, cutoff, receipt)
        synthetic_negatives(receipt, inputs, clock.frequency)
        receipt["host_end"] = C.host_sample(base, S, N, clock, len(selected))
        M.require(receipt["host_start"]["qpc"] <= receipt["fixture_rows"][0]["start_tick"]
                  and receipt["fixture_rows"][-1]["settled_tick"] <= receipt["host_end"]["qpc"],
                  "fixture-only host clock chronology differs")
        verify_build(binds)
        receipt["asset_hold"]["after"] = hold.verify()
        M.verify_holds(inputs, receipt)
        receipt.update(passed=True, qualified_conditions=list(selected))
    except BaseException as error:
        receipt["error"] = repr(error)
    finally:
        try:
            M.write(out / "receipt.json", receipt)
        finally:
            if hold is not None:
                hold.resources.close()
    return 0 if receipt["passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--inputs-sha256", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    M.require(out.parent == HERE and out.name == "fixture-qualification-001", "choose the exact fresh fixture namespace")
    out.mkdir(exist_ok=False)
    return run(args, out)


if __name__ == "__main__":
    sys.exit(main())
