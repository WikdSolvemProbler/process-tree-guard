"""Raw-QPC derivative of the reviewed suspended Windows Job launcher.

Original arm source: qualify-suspended.py, SHA-256
e11cd48dce9f4b3612323f870dd539bdf7c5fc8ffc643a879410151bb0695523.
The derivative changes the clock, adds held CPU data after the endpoint, and
accepts an exact stdout predicate for fixture-generated markers.
"""

from contextlib import ExitStack
import ctypes as C
from ctypes import wintypes as W
import os
import shutil
import subprocess
import threading
import time
from types import SimpleNamespace

import _winapi


class Clock:
    def __init__(self):
        kernel = C.WinDLL("kernel32", use_last_error=True)
        frequency = kernel.QueryPerformanceFrequency
        self.counter = kernel.QueryPerformanceCounter
        for function in (frequency, self.counter):
            function.argtypes = (C.POINTER(C.c_int64),)
            function.restype = W.BOOL
        result = C.c_int64()
        if not frequency(C.byref(result)) or result.value <= 0:
            raise RuntimeError("native QPC frequency unavailable")
        self.frequency = result.value

    def read(self):
        value = C.c_int64()
        if not self.counter(C.byref(value)) or value.value <= 0:
            raise RuntimeError("native QPC counter unavailable")
        return value.value


def cpu_receipt(S, handle, pid):
    times = [W.FILETIME() for _ in range(4)]
    ok = S.process_times(handle, *(C.byref(value) for value in times))
    S.native_ok(ok)
    creation, exit_time, kernel, user = [
        (value.dwHighDateTime << 32) | value.dwLowDateTime for value in times
    ]
    return dict(process_handle=int(handle), pid=pid, native_return=int(ok),
                creation_filetime=creation, exit_filetime=exit_time,
                kernel_100ns=kernel, user_100ns=user)


def arm(D, N, P, S, clock, row, folder, argv, budget, expected_exit, expected_stdout,
        marker=None, observe=None, expected_stderr=b"", capture=False, expected_env_sha256=None,
        expect_watchdog=False):
    require, environment_block, stream_bytes = D.require, D.environment_block, D.stream_bytes
    CWD, FLAGS, WAIT_LIVE = D.CWD, D.FLAGS, D.WAIT_LIVE
    WATCHDOG_EXIT, CLEANUP_EXIT = D.WATCHDOG_EXIT, D.CLEANUP_EXIT
    qpc, frequency = clock.read, clock.frequency
    require(not expect_watchdog or (not capture and expected_exit == WATCHDOG_EXIT),
            "watchdog observation grace is only for untimed synthetic qualification")
    row.update(argv=argv, creation_flags=FLAGS, cwd=str(CWD), deadline_seconds=budget,
               expected_exit_u32=expected_exit, admission=N.admission())
    require(row["admission"]["admitted"], "RAM below 896 MiB")
    row["disk_free_bytes"] = shutil.disk_usage(folder).free
    require(row["disk_free_bytes"] >= 256 * 1024 * 1024, "disk below 256 MiB")
    block, row["environment"] = environment_block(P)
    if expected_env_sha256 is not None:
        require(row["environment"]["utf16_sha256"] == expected_env_sha256, "sanitized environment changed")
    job = N.Job()
    snapshot_job = SimpleNamespace(_handle=job.handle)
    pi = N.PROCESS_INFORMATION()
    child = None
    extra_handles = {}
    alarm = None
    stop = threading.Event()
    expired = threading.Event()
    lock = threading.Lock()

    def watchdog():
        with lock:
            owned_handle = handoff.pop() if handoff else None
        if owned_handle is None:
            return
        try:
            while True:
                remaining_ticks = armed_deadline_tick - qpc()
                if remaining_ticks <= 0:
                    break
                if stop.wait(remaining_ticks / frequency):
                    return
            with lock:
                if stop.is_set():
                    return
                row["watchdog_fired_tick"] = qpc()
                expired.set()
            row["watchdog_terminate_return"] = int(N.TerminateJobObject(owned_handle, WATCHDOG_EXIT))
        except Exception as error:
            row["watchdog_error"] = repr(error)
        finally:
            row["watchdog_handle_closed"] = bool(N.CloseHandle(owned_handle))

    try:
        with ExitStack() as resources:
            paths = [folder / name for name in ("stdin.bin", "stdout.bin", "stderr.bin")]
            streams = [resources.enter_context(path.open("w+b", buffering=0)) for path in paths]
            handles = (N.HANDLE * 3)(*(N.msvcrt.get_osfhandle(item.fileno()) for item in streams))
            jobs = (N.HANDLE * 1)(job.handle)
            size = N.SIZE_T()
            N.InitializeProcThreadAttributeList(None, 2, 0, C.byref(size))
            require(size.value, "attribute list size unavailable")
            storage = C.create_string_buffer(size.value)
            N.checked(N.InitializeProcThreadAttributeList(storage, 2, 0, C.byref(size)), "attributes")
            resources.callback(N.DeleteProcThreadAttributeList, storage)
            N.checked(N.UpdateProcThreadAttribute(storage, 0, 0x20002, handles, C.sizeof(handles), None, None), "stdio")
            N.checked(N.UpdateProcThreadAttribute(storage, 0, 0x2000D, jobs, C.sizeof(jobs), None, None), "atomic Job")
            for handle in handles:
                resources.callback(os.set_handle_inheritable, handle, os.get_handle_inheritable(handle))
                os.set_handle_inheritable(handle, True)
            si = N.STARTUPINFOEX()
            si.info.cb, si.info.flags, si.info.show = C.sizeof(si), 0x101, 0
            si.info.stdin, si.info.stdout, si.info.stderr = handles
            si.attributes = C.cast(storage, C.c_void_p)
            command = C.create_unicode_buffer(subprocess.list2cmdline(argv))
            current = _winapi.GetCurrentProcess()
            watchdog_handle = _winapi.DuplicateHandle(
                current, job.handle, current, 0, False, _winapi.DUPLICATE_SAME_ACCESS)
            require(watchdog_handle != job.handle, "watchdog Job handle was not distinct")
            handoff = [watchdog_handle]
            row["watchdog_owns_distinct_job_handle"] = True
            try:
                alarm = threading.Thread(target=watchdog, daemon=True)
                armed_tick = qpc()
                armed_deadline_tick = armed_tick + budget * frequency
                row.update(armed_tick=armed_tick, armed_deadline_tick=armed_deadline_tick)
                alarm.start()
            except BaseException:
                stop.set()
                with lock:
                    unclaimed = handoff.pop() if handoff else None
                if unclaimed is not None:
                    N.CloseHandle(unclaimed)
                    alarm = None
                raise
            app, cwd = argv[0], str(CWD)
            startup, process_info = C.byref(si.info), C.byref(pi)
            if capture:
                start_tick = qpc()
            created = int(N.CreateProcessW(app, command, None, None, True, FLAGS,
                                           block, cwd, startup, process_info))
            row["create"] = (dict(native_return=created, pid=int(pi.pid), process_handle=int(pi.process or 0))
                             if capture else created)
            if capture:
                row["start_tick"] = start_tick
            N.checked(created, "CreateProcessW")
            row["suspended"] = S.snapshot(pi.process, snapshot_job)
            require(row["suspended"]["pid"] == pi.pid and row["suspended"]["member"]
                    and row["suspended"]["native_wait"] == WAIT_LIVE, "suspended identity/membership not verified")
            with lock:
                require(not expired.is_set() and qpc() < armed_deadline_tick,
                        "deadline elapsed before resume")
                row["resume_previous_suspend_count"] = int(N.ResumeThread(pi.thread))
            require(row["resume_previous_suspend_count"] == 1, "unexpected suspend count")
            if observe is not None:
                remaining = max(0, armed_deadline_tick - qpc()) / frequency
                observe(pi.process, snapshot_job, time.monotonic() + remaining, extra_handles, row)
            signal_deadline_tick = armed_deadline_tick + ((frequency // 2) if expect_watchdog else 0)
            wait_ms = min(250 if expected_exit is None else int((budget + 0.5) * 1000),
                          max(0, ((signal_deadline_tick - qpc()) * 1000) // frequency))
            row["wait_ms"] = wait_ms
            handle = pi.process
            native_wait = N.WaitForSingleObject(handle, wait_ms)
            end_tick = qpc()
            if capture:
                row.update(measurement_end_tick=end_tick, elapsed_ticks=end_tick - start_tick,
                           wait=dict(process_handle=int(handle), native_return=int(native_wait),
                                     query_end_tick=end_tick))
            row["native_wait_observed_tick"] = end_tick
            row["native_wait"] = int(native_wait)
            require(expect_watchdog or end_tick <= armed_deadline_tick,
                    "native wait endpoint crossed the armed deadline")
            row["root_before_cleanup"] = S.snapshot(pi.process, snapshot_job)
            require(row["root_before_cleanup"]["pid"] == row["suspended"]["pid"]
                    and row["root_before_cleanup"]["creation_filetime"] == row["suspended"]["creation_filetime"],
                    "held root identity changed")
            if capture:
                status = W.DWORD()
                exit_ok = N.GetExitCodeProcess(handle, C.byref(status))
                row["exit"] = dict(process_handle=int(handle), native_return=int(exit_ok),
                                   exit_code_u32=int(status.value))
                row["identity_before"] = dict(pid=row["suspended"]["pid"],
                                              creation_time=row["suspended"]["creation_filetime"])
                row["identity_after"] = dict(pid=row["root_before_cleanup"]["pid"],
                                             creation_time=row["root_before_cleanup"]["creation_filetime"])
                N.checked(exit_ok, "GetExitCodeProcess")
                require(int(status.value) == row["root_before_cleanup"]["exit_code_u32"],
                        "native exit queries differ")
            if expected_exit is None:
                require(wait_ms == 250 and row["native_wait"] == WAIT_LIVE
                        and row["root_before_cleanup"]["native_wait"] == WAIT_LIVE, "forced 250 ms timeout not observed")
            else:
                require(row["native_wait"] == 0 and row["root_before_cleanup"]["exit_code_u32"] == expected_exit,
                        "natural native exit mismatch")
            if capture and native_wait == 0:
                row["root_cpu"] = cpu_receipt(S, handle, int(pi.pid))
            if marker is not None:
                child_pid = int(marker.read_text(encoding="ascii"))
                child = _winapi.OpenProcess(S.SYNC_QUERY, False, child_pid)
                row["child_before_cleanup"] = S.snapshot(child, snapshot_job)
                child_before = row["child_before_cleanup"]
                require(child_before["pid"] == child_pid != pi.pid and child_before["member"]
                        and child_before["creation_filetime"] >= row["suspended"]["creation_filetime"]
                        and child_before["native_wait"] == WAIT_LIVE, "intended leak was not live in the Job")
            stdout, stderr = stream_bytes(paths[1]), stream_bytes(paths[2])
            row["streams_before_cleanup"] = {"stdout_hex": stdout.hex(), "stderr_hex": stderr.hex()}
            stdout_ok = expected_stdout(stdout, row) if callable(expected_stdout) else stdout == expected_stdout
            require(stdout_ok and (expected_stderr is None or stderr == expected_stderr),
                    "pre-cleanup output oracle mismatch")
            observe_deadline_tick = min(signal_deadline_tick, qpc() + (frequency // 2))
            needs_cleanup = expected_exit is None or marker is not None
            while True:
                row["accounting_before_cleanup"] = job.accounting()
                active = row["accounting_before_cleanup"]["values"]["active_processes"]
                if (active > 0) == needs_cleanup or qpc() >= observe_deadline_tick:
                    break
                time.sleep(0.005)
            require((active > 0) == needs_cleanup, "pre-cleanup Job accounting mismatch")
    finally:
        try:
            stop.set()
            if alarm is not None:
                alarm.join(0.5)
                require(not alarm.is_alive(), "native watchdog still outstanding; independent outer guard owns cleanup")
                require(row.get("watchdog_handle_closed") is True and not row.get("watchdog_error"),
                        "watchdog did not safely close its owned Job handle")
            row["watchdog_fired"] = expired.is_set()
            row["accounting_at_cleanup"] = job.accounting()
            if row["accounting_at_cleanup"]["values"]["active_processes"]:
                job.kill()
                row["trusted_cleanup_requested"] = True
            cleanup_deadline = time.monotonic() + 0.5
            while True:
                row["accounting_after_cleanup"] = job.accounting()
                if not row["accounting_after_cleanup"]["values"]["active_processes"]:
                    break
                require(time.monotonic() < cleanup_deadline, "Job drain deadline exceeded")
                time.sleep(0.005)
            for name, handle in (("root", pi.process), ("child", child), *extra_handles.items()):
                if handle:
                    remaining_ms = max(0, int((cleanup_deadline - time.monotonic()) * 1000))
                    require(N.WaitForSingleObject(handle, remaining_ms) == 0, f"held {name} did not signal")
                    after = S.snapshot(handle, snapshot_job)
                    row[f"{name}_after_cleanup"] = after
                    before = row.get(f"{name}_before_cleanup")
                    if before is not None:
                        require((after["pid"], after["creation_filetime"]) ==
                                (before["pid"], before["creation_filetime"]), f"held {name} identity changed")
                        if before["native_wait"] == WAIT_LIVE:
                            require(after["exit_code_u32"] == CLEANUP_EXIT, f"held {name} cleanup exit mismatch")
            require(row["watchdog_fired"] is expect_watchdog, "unexpected hard arm deadline outcome")
            if expect_watchdog:
                require(row.get("watchdog_terminate_return") == 1 and not row.get("trusted_cleanup_requested"),
                        "asynchronous watchdog did not independently settle the Job")
                require(armed_deadline_tick <= row["watchdog_fired_tick"] <= row["native_wait_observed_tick"],
                        "watchdog firing and endpoint chronology mismatch")
        finally:
            closing = (("process", pi.process), ("thread", pi.thread), ("child", child), *extra_handles.items())
            try:
                row["held_close"] = {name: int(N.CloseHandle(handle)) for name, handle in closing if handle}
            finally:
                job.close()
            require(all(row["held_close"].values()), "held handle close failed")
    if capture:
        row["cleanup"] = {"active_after": row["accounting_after_cleanup"]["values"]["active_processes"]}
        row["settled_tick"] = qpc()
