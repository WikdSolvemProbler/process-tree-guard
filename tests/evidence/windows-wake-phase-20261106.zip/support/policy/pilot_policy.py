"""Small pilot oracle and budget/environment predicates; no OS calls or process launches."""
import hashlib

CLEAR_KEYS = frozenset((
    "PROCESS_GUARD_TRACE", "PROCESS_GUARD_TIMING_NONCE", "PROCESS_TREE_GUARD_CHANNEL",
    "PROCESS_TREE_GUARD_AUTO_TIMEOUT", "PROCESS_GUARD_AUTO_TIMEOUT", "HARNESS_AUTO_TIMEOUT",
    "PROCESS_TREE_GUARD_REQUIRE_WINDOW_STATION", "GUARD_BENCH_OBSERVER_PID",
    "PROCESS_TREE_GUARD_UNIT_TEST_CONSOLE_BEGIN_CHILD", "PROCESS_TREE_GUARD_UNIT_TEST_HIDDEN_STATION_CHILD",
    "PROCESS_TREE_GUARD_UNIT_TEST_JOB_CHILD", "PROCESS_TREE_GUARD_UNIT_TEST_OWNER_WINDOW_CHILD",
    "PROCESS_TREE_GUARD_UNIT_TEST_PANIC_HOOK_CHILD",
))

def integer(value,low=0):return type(value) is int and value>=low

def environment(inherited):
    """Copy only; publish names/digests, never channel/nonce/secret values."""
    if not isinstance(inherited,dict) or not all(isinstance(k,str) and isinstance(v,str) for k,v in inherited.items()):
        raise ValueError("string environment mapping required")
    cleared=[];child={};seen=set()
    for key,value in inherited.items():
        folded=key.upper()
        if folded in CLEAR_KEYS:
            cleared.append(key);continue
        if folded in seen:raise ValueError("duplicate casefold environment key")
        seen.add(folded);child[key]=value
    return child,dict(cleared_names=sorted(cleared,key=str.upper),policy="PRIVATE_PILOT_KNOWN_TRACE_CHANNEL_AND_DEADLINE_KEYS_REMOVED_V1",
        key_count=len(child),selected_value_sha256={k:hashlib.sha256(v.encode("utf8")).hexdigest()
            for k,v in child.items() if k.upper() in ("SYSTEMROOT","WINDIR","COMSPEC","PATH")})

def remaining_wait_ms(start_ns,now_ns,budget_ns=2_000_000_000):
    if not integer(start_ns) or not integer(now_ns,start_ns) or not integer(budget_ns,1):
        raise ValueError("native wait budget chronology malformed")
    return max(0,min(2000,(start_ns+budget_ns-now_ns+999_999)//1_000_000))

def expected_output(token):
    if not isinstance(token,str) or len(token)!=32 or any(c not in "0123456789abcdef" for c in token):
        raise ValueError("32 lower-case ASCII hexadecimal token required")
    return ("BENCHMARK_DONE exit 0 "+token+"\n").encode("ascii")

def oracle(row,stdout,stderr,expected):
    reasons=[]
    if type(stdout) is not bytes or type(stderr) is not bytes or type(expected) is not bytes:
        return dict(passed=False,reasons=["RAW_BYTES_REQUIRED"])
    create=row.get("create",{});wait=row.get("wait",{});code=row.get("exit",{})
    handle=create.get("process_handle");ident=row.get("identity_before",{});after=row.get("identity_after",{})
    for value in (handle,wait.get("process_handle"),code.get("process_handle")):
        if not integer(value,1):reasons.append("NATIVE_HANDLE_TYPE")
    if wait.get("process_handle")!=handle or code.get("process_handle")!=handle:reasons.append("NATIVE_HANDLE_BINDING")
    if (not integer(ident.get("pid"),1) or not integer(ident.get("creation_time"),1)
            or not integer(after.get("pid"),1) or not integer(after.get("creation_time"),1)
            or after!=ident or type(create.get("pid")) is not int or create.get("pid")!=ident.get("pid")):
        reasons.append("ORIGINAL_IDENTITY")
    if type(create.get("native_return")) is not int or create["native_return"]!=1:reasons.append("CREATE_FAILED")
    if type(wait.get("native_return")) is not int or wait["native_return"]!=0:reasons.append("NOT_ORIGINAL_NATIVE_ZERO")
    if type(code.get("native_return")) is not int or code["native_return"]!=1:reasons.append("EXIT_QUERY_FAILED")
    if type(code.get("exit_code_u32")) is not int or code["exit_code_u32"]!=0:reasons.append("NATIVE_EXIT_MISMATCH")
    if stdout!=expected:reasons.append("STDOUT_MISMATCH")
    if stderr:reasons.append("STDERR_NOT_EMPTY")
    if b"PROCESS_GUARD_NATIVE_TIMING_V1" in stderr or b"PROCESS_GUARD_NATIVE_TIMING_V1" in stdout:
        reasons.append("TRACE_OR_TIMING_NOT_OFF")
    start=row.get("start_ns");end=row.get("measurement_end_ns")
    if not integer(start) or not integer(end,start) or end-start>2_000_000_000:reasons.append("ARM_DEADLINE")
    if row.get("watchdog_fired") is not False:reasons.append("WATCHDOG_OR_UNOBSERVED")
    cleanup=row.get("cleanup_started_ns")
    if not integer(cleanup,end if integer(end) else 0):reasons.append("CLEANUP_BEFORE_MEASUREMENT")
    if row.get("instrument_error") or row.get("cleanup_errors"):reasons.append("INSTRUMENT_OR_CLEANUP_ERROR")
    membership=row.get("membership_before_resume",{})
    if (type(membership.get("native_return")) is not int or membership["native_return"]!=1
            or type(membership.get("output_value")) is not int or membership["output_value"]!=1
            or row.get("job_list_attribute_installed") is not True):
        reasons.append("PRIVATE_JOB_NOT_VERIFIED")
    if row.get("suspended_native_wait")!=258 or type(row.get("suspended_native_wait")) is not int:
        reasons.append("NOT_SUSPENDED_LIVE")
    if type(row.get("resume_return")) is not int or row["resume_return"]!=1:reasons.append("RESUME_COUNT")
    return dict(passed=not reasons,reasons=sorted(set(reasons)),scope="STARTUP_DEVELOPMENT_ONLY_NOT_DURABILITY_OR_FINAL_WIN")
