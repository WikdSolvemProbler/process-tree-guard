//! Independently authored, finite-lifetime workload for process-guard experiments.
//! No guard implementation or test helper is reused here.
use std::os::windows::io::AsRawHandle;
use std::os::windows::process::CommandExt;
use std::sync::{
    atomic::{AtomicBool, Ordering},
    OnceLock,
};
use std::{
    env, fs,
    io::{self, Read, Write},
    path::{Path, PathBuf},
    process::{self, Command},
    thread,
    time::{Duration, Instant},
};
static ENTRY: OnceLock<Instant> = OnceLock::new();
static ENTRY_QPC: OnceLock<i64> = OnceLock::new();
static EXPIRY_ARMED: AtomicBool = AtomicBool::new(false);

#[repr(C)]
struct FileTime {
    low: u32,
    high: u32,
}
#[link(name = "kernel32")]
extern "system" {
    fn GetCurrentProcess() -> isize;
    fn GetProcessTimes(
        p: isize,
        c: *mut FileTime,
        e: *mut FileTime,
        k: *mut FileTime,
        u: *mut FileTime,
    ) -> i32;
    fn QueryPerformanceCounter(v: *mut i64) -> i32;
    fn QueryPerformanceFrequency(v: *mut i64) -> i32;
    fn ExitProcess(code: u32) -> !;
    fn OpenProcess(access: u32, inherit: i32, pid: u32) -> isize;
    fn DuplicateHandle(
        source: isize,
        handle: isize,
        target: isize,
        copy: *mut isize,
        access: u32,
        inherit: i32,
        options: u32,
    ) -> i32;
    fn CloseHandle(handle: isize) -> i32;
}
fn qpc() -> i64 {
    let mut v = 0;
    unsafe {
        QueryPerformanceCounter(&mut v);
    }
    v
}
fn expiry(ms: u64) {
    if EXPIRY_ARMED.swap(true, Ordering::SeqCst) {
        return;
    }
    let deadline = *ENTRY.get().unwrap() + Duration::from_millis(ms);
    thread::spawn(move || {
        thread::sleep(deadline.saturating_duration_since(Instant::now()));
        unsafe { ExitProcess(95) }
    });
}
fn creation() -> u64 {
    let mut a = FileTime { low: 0, high: 0 };
    let mut b = FileTime { low: 0, high: 0 };
    let mut c = FileTime { low: 0, high: 0 };
    let mut d = FileTime { low: 0, high: 0 };
    assert_ne!(
        unsafe { GetProcessTimes(GetCurrentProcess(), &mut a, &mut b, &mut c, &mut d) },
        0
    );
    ((a.high as u64) << 32) | (a.low as u64)
}
fn child_creation(child: &std::process::Child) -> u64 {
    let mut a = FileTime { low: 0, high: 0 };
    let mut b = FileTime { low: 0, high: 0 };
    let mut c = FileTime { low: 0, high: 0 };
    let mut d = FileTime { low: 0, high: 0 };
    assert_ne!(
        unsafe {
            GetProcessTimes(
                child.as_raw_handle() as isize,
                &mut a,
                &mut b,
                &mut c,
                &mut d,
            )
        },
        0
    );
    ((a.high as u64) << 32) | (a.low as u64)
}
fn parent_records(dir: &Path, children: &[std::process::Child], token: &str) {
    fs::create_dir_all(dir).unwrap();
    let body = children
        .iter()
        .map(|c| {
            format!(
                "{{\"pid\":{},\"creation_time\":{},\"parent_pid\":{},\"parent_creation_time\":{},\"token\":{}}}",
                c.id(),
                child_creation(c),
                process::id(),
                creation(),
                esc(token)
            )
        })
        .collect::<Vec<_>>()
        .join(",");
    fs::write(
        dir.join(format!(
            "{}-{}.parent-records.json",
            process::id(),
            creation()
        )),
        format!("[{}]", body),
    )
    .unwrap();
}
fn transfer_child_handle(dir: &Path, child: &std::process::Child, token: &str, wave: u64) {
    let observer = env::var("GUARD_BENCH_OBSERVER_PID")
        .unwrap()
        .parse::<u32>()
        .unwrap();
    let target = unsafe { OpenProcess(0x40, 0, observer) };
    assert_ne!(target, 0);
    let mut handle = 0isize;
    assert_ne!(
        unsafe {
            DuplicateHandle(
                GetCurrentProcess(),
                child.as_raw_handle() as isize,
                target,
                &mut handle,
                0,
                0,
                2,
            )
        },
        0
    );
    unsafe {
        CloseHandle(target);
    }
    let record=format!("{{\"pid\":{},\"creation_time\":{},\"parent_pid\":{},\"parent_creation_time\":{},\"token\":{},\"role\":\"churn-leaf\",\"observer_handle\":{},\"wave\":{},\"registered_qpc\":{}}}",child.id(),child_creation(child),process::id(),creation(),esc(token),handle,wave,qpc());
    fs::write(
        dir.join(format!(
            "{}-{}.transferred-handle.json",
            child.id(),
            child_creation(child)
        )),
        record,
    )
    .unwrap();
}
// Retain the actual returned creation handle without suspending or gating the child.
// A missing receipt is not absence evidence: the parent can die during publication.
fn transfer_late_child_handle(
    dir: &Path,
    child: &std::process::Child,
    token: &str,
    origin_qpc: i64,
    requested_delay_ms: u64,
    spawn_start_qpc: i64,
    spawn_return_qpc: i64,
) {
    let child_created = child_creation(child);
    let parent_created = creation();
    let observer = env::var("GUARD_BENCH_OBSERVER_PID")
        .unwrap()
        .parse::<u32>()
        .unwrap();
    let duplicate_start_qpc = qpc();
    let target = unsafe { OpenProcess(0x40, 0, observer) };
    assert_ne!(target, 0);
    let mut handle = 0isize;
    let duplicated = unsafe {
        DuplicateHandle(
            GetCurrentProcess(),
            child.as_raw_handle() as isize,
            target,
            &mut handle,
            0,
            0,
            2,
        )
    };
    let duplicate_end_qpc = qpc();
    unsafe {
        CloseHandle(target);
    }
    assert_ne!(duplicated, 0);
    let receipt_constructed_qpc = qpc();
    let record = format!(
        r#"{{"schema":1,"evidence_kind":"late-child-creation-handle","pid":{},"creation_time":{},"parent_pid":{},"parent_creation_time":{},"token":{},"role":"late-grandchild","observer_pid":{},"observer_handle":{},"origin_qpc":{},"requested_delay_ms":{},"spawn_start_qpc":{},"spawn_return_qpc":{},"duplicate_start_qpc":{},"duplicate_end_qpc":{},"receipt_constructed_qpc":{}}}"#,
        child.id(),
        child_created,
        process::id(),
        parent_created,
        esc(token),
        observer,
        handle,
        origin_qpc,
        requested_delay_ms,
        spawn_start_qpc,
        spawn_return_qpc,
        duplicate_start_qpc,
        duplicate_end_qpc,
        receipt_constructed_qpc,
    );
    let stem = format!("{}-{}", child.id(), child_created);
    let temporary = dir.join(format!("{}.late-birth.tmp", stem));
    fs::write(&temporary, record).unwrap();
    fs::rename(
        temporary,
        dir.join(format!("{}.transferred-handle.json", stem)),
    )
    .unwrap();
}
fn wait_from_qpc(origin: i64, ms: u64) {
    let mut f = 0i64;
    unsafe {
        QueryPerformanceFrequency(&mut f);
    }
    let target = origin + (ms as i64 * f) / 1000;
    while qpc() < target {
        thread::sleep(Duration::from_millis(1));
    }
}
fn esc(s: &str) -> String {
    let mut o = String::from("\"");
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            '\r' => o.push_str("\\r"),
            '\t' => o.push_str("\\t"),
            c if c < ' ' => o.push_str(&format!("\\u{:04x}", c as u32)),
            c => o.push(c),
        }
    }
    o.push('"');
    o
}
fn number(s: &str, max: u64) -> u64 {
    let n = s.parse::<u64>().expect("integer required");
    assert!(n <= max, "finite bound exceeded");
    n
}
fn identity(dir: &Path, token: &str, role: &str) {
    // Publish immutable identity once. Replacing a file while an independent
    // observer has it open can fail with ERROR_ACCESS_DENIED on Windows.
    if dir
        .join(format!("{}-{}.identity.json", process::id(), creation()))
        .is_file()
    {
        return;
    }
    fs::create_dir_all(dir).unwrap();
    let p = process::id();
    let body = format!(
        "{{\"pid\":{},\"creation_time\":{},\"entry_qpc\":{},\"qpc\":{},\"token\":{},\"role\":{}}}",
        p,
        creation(),
        ENTRY_QPC.get().unwrap(),
        qpc(),
        esc(token),
        esc(role)
    );
    let tmp = dir.join(format!("{}.tmp", p));
    fs::write(&tmp, body).unwrap();
    fs::rename(tmp, dir.join(format!("{}-{}.identity.json", p, creation()))).unwrap();
}
fn live_for(ms: u64, dir: &Path, token: &str, role: &str) {
    expiry(ms);
    identity(dir, token, role);
    let end = *ENTRY.get().unwrap() + Duration::from_millis(ms);
    let p = process::id();
    let mut seq = 0u64;
    while Instant::now() < end {
        seq += 1;
        fs::write(
            dir.join(format!("{}.heartbeat", p)),
            format!(
                "{{\"token\":{},\"pid\":{},\"creation_time\":{},\"sequence\":{},\"qpc\":{}}}",
                esc(token),
                p,
                creation(),
                seq,
                qpc()
            ),
        )
        .unwrap();
        thread::sleep(Duration::from_millis(
            env::var("GUARD_BENCH_HEARTBEAT_MS")
                .unwrap_or_else(|_| "20".to_owned())
                .parse::<u64>()
                .unwrap()
                .clamp(1, 1000),
        ));
    }
}
fn ready_count(dir: &Path) -> usize {
    fs::read_dir(dir)
        .unwrap()
        .filter_map(Result::ok)
        .filter(|x| x.file_name().to_string_lossy().ends_with(".identity.json"))
        .count()
}
fn tree(shape: &str, count: u64, mode: &str, ms: u64, dir: &Path, token: &str, flags: u32) {
    assert!((1..=128).contains(&count));
    identity(dir, token, "root");
    let exe = env::current_exe().unwrap();
    if shape == "fan" {
        let mut children = Vec::new();
        for _ in 0..count {
            children.push(
                Command::new(&exe)
                    .args([
                        "sleep",
                        &ms.to_string(),
                        dir.to_str().unwrap(),
                        token,
                        "leaf",
                    ])
                    .creation_flags(flags)
                    .spawn()
                    .unwrap(),
            );
        }
        parent_records(dir, &children, token);
    } else if shape == "deep" && count > 1 {
        let child = Command::new(&exe)
            .args([
                "chain",
                &(count - 1).to_string(),
                &ms.to_string(),
                dir.to_str().unwrap(),
                token,
            ])
            .creation_flags(flags)
            .spawn()
            .unwrap();
        parent_records(dir, &[child], token);
    } else if shape != "deep" {
        panic!("unknown tree shape");
    }
    let expected = if shape == "fan" {
        count as usize + 1
    } else {
        count as usize
    };
    let deadline = Instant::now() + Duration::from_secs(8);
    while ready_count(dir) < expected && Instant::now() < deadline {
        thread::sleep(Duration::from_millis(5));
    }
    if ready_count(dir) < expected {
        eprintln!("FIXTURE_READINESS_FAILED");
        process::exit(91);
    }
    fs::write(
        dir.join("ready.json"),
        format!(
            "{{\"token\":{},\"expected\":{},\"qpc\":{}}}",
            esc(token),
            expected,
            qpc()
        ),
    )
    .unwrap();
    if mode == "exit" {
        process::exit(7);
    }
    assert_eq!(mode, "wait");
    live_for(ms, dir, token, "root");
}
fn main() {
    ENTRY.set(Instant::now()).unwrap();
    ENTRY_QPC.set(qpc()).unwrap();
    let a: Vec<String> = env::args().collect();
    let cmd = a.get(1).map(|x| x.as_str()).unwrap_or("");
    let location = match cmd {
        "sleep" | "branch" | "pressure-tree" | "pressure-branch" | "pressure-leaf" => Some((3, 4)),
        "race-tree" | "late" | "chain" => Some((4, 5)),
        "tree" | "churn" => Some((6, 7)),
        "late-branch" | "owner-chain" => Some((5, 6)),
        _ => None,
    };
    let panic_target =
        location.and_then(|(d, t)| Some((PathBuf::from(a.get(d)?), a.get(t)?.clone())));
    std::panic::set_hook(Box::new(move |info| {
        eprintln!("BENCHMARK_FIXTURE_PANIC {}", info);
        if let Some((dir, token)) = &panic_target {
            let _ = fs::create_dir_all(dir);
            let _ = fs::write(
                dir.join(format!(
                    "{}-{}.fixture-panic.json",
                    process::id(),
                    creation()
                )),
                format!(
                    "{{\"pid\":{},\"creation_time\":{},\"token\":{},\"message\":{}}}",
                    process::id(),
                    creation(),
                    esc(token),
                    esc(&format!("{}", info))
                ),
            );
        }
    }));
    match cmd {
        "wait" => {
            thread::sleep(Duration::from_millis(number(&a[2], 120_000)));
            if let Some(token) = a.get(3) {
                io::stdout()
                    .write_all(format!("BENCHMARK_DONE wait 50 {}\n", token).as_bytes())
                    .unwrap();
                io::stdout().flush().unwrap();
            }
        }
        "exit" => {
            if let Some(token) = a.get(3) {
                io::stdout()
                    .write_all(format!("BENCHMARK_DONE exit 0 {}\n", token).as_bytes())
                    .unwrap();
                io::stdout().flush().unwrap();
            }
            unsafe { ExitProcess(number(&a[2], u32::MAX as u64) as u32) }
        }
        "argv" => {
            println!(
                "[{}]",
                a[2..].iter().map(|s| esc(s)).collect::<Vec<_>>().join(",")
            );
        }
        "relay" => {
            let mut b = Vec::new();
            io::stdin().read_to_end(&mut b).unwrap();
            io::stdout().write_all(&b).unwrap();
            io::stdout().flush().unwrap();
            io::stderr().write_all(b"error-stream\n").unwrap();
            io::stderr().flush().unwrap();
            unsafe { ExitProcess(number(&a[2], u32::MAX as u64) as u32) }
        }
        "flood" => {
            let n = number(&a[2], 64 * 1024 * 1024) as usize;
            let t = thread::spawn(move || {
                let mut o = io::stderr().lock();
                let buf = [b'B'; 8192];
                let mut remain = n;
                while remain > 0 {
                    let k = remain.min(buf.len());
                    o.write_all(&buf[..k]).unwrap();
                    remain -= k;
                }
            });
            let mut o = io::stdout().lock();
            let buf = [b'A'; 8192];
            let mut remain = n;
            while remain > 0 {
                let k = remain.min(buf.len());
                o.write_all(&buf[..k]).unwrap();
                remain -= k;
            }
            drop(o);
            t.join().unwrap();
        }
        "sleep" => {
            let ms = number(&a[2], 120_000);
            live_for(
                ms,
                Path::new(&a[3]),
                &a[4],
                a.get(5).map(String::as_str).unwrap_or("leaf"),
            );
        }
        "tree" => {
            let count = number(&a[3], 128);
            let ms = number(&a[5], 120_000);
            let flags = a
                .get(8)
                .map(|s| number(s, u32::MAX as u64) as u32)
                .unwrap_or(0);
            tree(&a[2], count, &a[4], ms, Path::new(&a[6]), &a[7], flags);
        }
        "chain" => {
            let count = number(&a[2], 128);
            let ms = number(&a[3], 120_000);
            let dir = PathBuf::from(&a[4]);
            identity(&dir, &a[5], "chain");
            if count > 1 {
                let child = Command::new(env::current_exe().unwrap())
                    .args([
                        "chain",
                        &(count - 1).to_string(),
                        &ms.to_string(),
                        &a[4],
                        &a[5],
                    ])
                    .spawn()
                    .unwrap();
                parent_records(&dir, &[child], &a[5]);
            }
            live_for(ms, &dir, &a[5], "chain");
        }
        // The first substantive root action is process creation: there is no
        // identity, marker, directory creation, flush or readiness I/O first.
        "race-tree" => {
            let mode = &a[2];
            let ms = number(&a[3], 120_000);
            let dir = Path::new(&a[4]);
            let token = &a[5];
            let exe = env::current_exe().unwrap();
            let mut children = Vec::new();
            for _ in 0..2 {
                children.push(
                    Command::new(&exe)
                        .args(["branch", &ms.to_string(), &a[4], token])
                        .spawn()
                        .unwrap(),
                );
            }
            parent_records(dir, &children, token);
            identity(dir, token, "root");
            if mode == "wait" {
                live_for(ms, dir, token, "root");
            } else {
                let stop = Instant::now() + Duration::from_secs(8);
                while ready_count(dir) < 7 && Instant::now() < stop {
                    thread::sleep(Duration::from_millis(2));
                }
                if ready_count(dir) < 7 {
                    process::exit(91);
                }
                fs::write(
                    dir.join("ready.json"),
                    format!(
                        "{{\"token\":{},\"expected\":7,\"qpc\":{},\"root_exit_barrier_ms\":50}}",
                        esc(token),
                        qpc()
                    ),
                )
                .unwrap();
                thread::sleep(Duration::from_millis(50));
                unsafe { ExitProcess(number(mode, u32::MAX as u64) as u32) }
            }
        }
        "branch" => {
            let ms = number(&a[2], 120_000);
            let dir = Path::new(&a[3]);
            let token = &a[4];
            let mut children = Vec::new();
            for _ in 0..2 {
                children.push(
                    Command::new(env::current_exe().unwrap())
                        .args(["sleep", &ms.to_string(), &a[3], token, "grandchild"])
                        .spawn()
                        .unwrap(),
                );
            }
            parent_records(dir, &children, token);
            identity(dir, token, "branch");
            live_for(ms, dir, token, "branch");
        }
        "late" => {
            let delay = number(&a[2], 10_000);
            let ms = number(&a[3], 120_000);
            let dir = Path::new(&a[4]);
            let token = &a[5];
            let origin = *ENTRY_QPC.get().unwrap();
            identity(dir, token, "root");
            let child = Command::new(env::current_exe().unwrap())
                .args([
                    "late-branch",
                    &origin.to_string(),
                    &delay.to_string(),
                    &ms.to_string(),
                    &a[4],
                    token,
                ])
                .spawn()
                .unwrap();
            parent_records(dir, &[child], token);
            live_for(ms, dir, token, "root");
        }
        "late-branch" => {
            let origin = a[2].parse::<i64>().unwrap();
            let delay = number(&a[3], 10_000);
            let ms = number(&a[4], 120_000);
            let dir = Path::new(&a[5]);
            let token = &a[6];
            identity(dir, token, "late-parent");
            wait_from_qpc(origin, delay);
            let requested = qpc();
            let child = Command::new(env::current_exe().unwrap())
                .args(["sleep", &ms.to_string(), &a[5], token, "late-grandchild"])
                .spawn()
                .unwrap();
            let spawn_return_qpc = qpc();
            transfer_late_child_handle(
                dir,
                &child,
                token,
                origin,
                delay,
                requested,
                spawn_return_qpc,
            );
            parent_records(dir, &[child], token);
            fs::write(dir.join("late-spawn.json"),format!("{{\"origin_qpc\":{},\"spawn_start_qpc\":{},\"spawn_end_qpc\":{},\"requested_delay_ms\":{},\"parent_pid\":{}}}",origin,requested,qpc(),delay,process::id())).unwrap();
            live_for(ms, dir, token, "late-parent");
        }
        // Owners are passive instruments: they neither cascade on child exit
        // nor hold a cleanup job. Only their explicit finite lifetime ends them.
        "owner-chain" => {
            let depth = number(&a[2], 32);
            let index = number(&a[3], 32);
            let ms = number(&a[4], 120_000);
            let meta = Path::new(&a[5]);
            let token = &a[6];
            fs::create_dir_all(meta).unwrap();
            let child = if depth > 1 {
                let mut c = Command::new(env::current_exe().unwrap());
                c.args([
                    "owner-chain",
                    &(depth - 1).to_string(),
                    &(index + 1).to_string(),
                    &ms.to_string(),
                    &a[5],
                    token,
                ]);
                c.args(&a[7..]);
                c.spawn().unwrap()
            } else {
                Command::new(&a[7]).args(&a[8..]).spawn().unwrap()
            };
            fs::write(meta.join(format!("{}.owner.json",index)),format!("{{\"index\":{},\"pid\":{},\"creation_time\":{},\"token\":{},\"child_pid\":{},\"child_creation_time\":{}}}",index,process::id(),creation(),esc(token),child.id(),child_creation(&child))).unwrap();
            if depth == 1 {
                fs::write(
                    meta.join("sut.json"),
                    format!(
                        "{{\"pid\":{},\"creation_time\":{},\"owner_pid\":{},\"owner_creation_time\":{},\"token\":{}}}",
                        child.id(),
                        child_creation(&child),
                        process::id(),
                        creation(),
                        esc(token)
                    ),
                )
                .unwrap();
            }
            expiry(ms);
            thread::sleep(
                (*ENTRY.get().unwrap() + Duration::from_millis(ms))
                    .saturating_duration_since(Instant::now()),
            );
        }
        "churn" => {
            let waves = number(&a[2], 16);
            let width = number(&a[3], 8);
            let child_ms = number(&a[4], 1000);
            let ms = number(&a[5], 120_000);
            let dir = Path::new(&a[6]);
            let token = &a[7];
            expiry(ms);
            identity(dir, token, "root");
            let exe = env::current_exe().unwrap();
            let mut births = Vec::new();
            for wave in 0..waves {
                let mut children = Vec::new();
                for _ in 0..width {
                    let child = Command::new(&exe)
                        .args(["sleep", &child_ms.to_string(), &a[6], token, "churn-leaf"])
                        .spawn()
                        .unwrap();
                    transfer_child_handle(dir, &child, token, wave);
                    children.push(child);
                }
                for mut child in children {
                    let created = child_creation(&child);
                    child.wait().unwrap();
                    births.push(format!(
                        "{{\"wave\":{},\"pid\":{},\"creation_time\":{},\"parent_pid\":{},\"parent_creation_time\":{},\"token\":{},\"reaped_qpc\":{}}}",
                        wave,
                        child.id(),
                        created,
                        process::id(),
                        creation(),
                        esc(token),
                        qpc()
                    ));
                }
                fs::write(
                    dir.join(format!("wave-{}.json", wave)),
                    format!(
                        "{{\"wave\":{},\"total_births\":{},\"qpc\":{}}}",
                        wave,
                        births.len(),
                        qpc()
                    ),
                )
                .unwrap();
            }
            fs::write(
                dir.join("churn-births.json"),
                format!("[{}]", births.join(",")),
            )
            .unwrap();
            live_for(ms, dir, token, "root");
        }
        "pressure-tree" => {
            let ms = number(&a[2], 120_000);
            let dir = Path::new(&a[3]);
            let token = &a[4];
            let exe = env::current_exe().unwrap();
            let mut children = Vec::new();
            for _ in 0..2 {
                children.push(
                    Command::new(&exe)
                        .args(["pressure-branch", &ms.to_string(), &a[3], token])
                        .spawn()
                        .unwrap(),
                );
            }
            parent_records(dir, &children, token);
            identity(dir, token, "root");
            live_for(ms, dir, token, "root");
        }
        "pressure-branch" => {
            let ms = number(&a[2], 120_000);
            let dir = Path::new(&a[3]);
            let token = &a[4];
            let exe = env::current_exe().unwrap();
            let children = vec![
                Command::new(&exe)
                    .args(["pressure-leaf", &ms.to_string(), &a[3], token])
                    .spawn()
                    .unwrap(),
                Command::new(&exe)
                    .args(["sleep", &ms.to_string(), &a[3], token, "grandchild"])
                    .spawn()
                    .unwrap(),
            ];
            parent_records(dir, &children, token);
            identity(dir, token, "branch");
            live_for(ms, dir, token, "branch");
        }
        "pressure-leaf" => {
            let ms = number(&a[2], 120_000);
            let dir = Path::new(&a[3]);
            let token = &a[4];
            expiry(ms);
            identity(dir, token, "pressure-writer");
            let t = thread::spawn(|| {
                let mut e = io::stderr().lock();
                let buf = [b'B'; 8192];
                for _ in 0..128 {
                    e.write_all(&buf).unwrap();
                }
            });
            let mut o = io::stdout().lock();
            let buf = [b'A'; 8192];
            for _ in 0..128 {
                o.write_all(&buf).unwrap();
            }
            drop(o);
            t.join().unwrap();
            fs::write(dir.join(format!("{}-{}.pressure-complete.json",process::id(),creation())),format!("{{\"pid\":{},\"creation_time\":{},\"token\":{},\"stdout_bytes\":1048576,\"stderr_bytes\":1048576,\"completed_qpc\":{}}}",process::id(),creation(),esc(token),qpc())).unwrap();
            live_for(ms, dir, token, "pressure-writer");
        }
        _ => {
            eprintln!("fixture: exit CODE | argv ARGS | relay CODE | flood BYTES | sleep MS DIR TOKEN [ROLE] | tree fan|deep COUNT wait|exit MS DIR TOKEN [FLAGS]");
            process::exit(90);
        }
    }
}
