set -eu
platform=$1
attempt=$2
[[ "$attempt" =~ ^[0-9a-f]{8}$ ]]
work=/tmp/ptg-refusal-$platform-$attempt
[ ! -e "$work" ] && [ ! -L "$work" ]
printf 'absent=%s\n' "$work"
if [ "$platform" = linux ]; then
    group=/sys/fs/cgroup/user.slice/user-501.slice/user@501.service/app.slice/ptg-refusal-linux-$attempt.scope
    [ ! -e "$group" ] && [ ! -L "$group" ]
    printf 'absent=%s\n' "$group"
fi
