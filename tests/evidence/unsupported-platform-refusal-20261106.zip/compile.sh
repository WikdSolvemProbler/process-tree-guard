set -eu
umask 077
platform=$1
attempt=$2
expected=$3
[[ "$attempt" =~ ^[0-9a-f]{8}$ && "$expected" =~ ^[0-9a-f]{64}$ ]]
[ "$(/usr/bin/id -u)" != 0 ]
work=/tmp/ptg-refusal-$platform-$attempt
case "$platform" in
 linux)
    [ "$(/usr/bin/uname -s)" = Linux ]
    [ "$(/usr/bin/uname -m)" = aarch64 ]
    [ "$(/usr/bin/id -u)" = 501 ]
    unit=ptg-refusal-linux-$attempt.scope
    group=/user.slice/user-501.slice/user@501.service/app.slice/$unit
    [ "$(/usr/bin/cat /proc/$$/cgroup)" = "0::$group" ]
    props=$(/usr/bin/systemctl --user show "$unit" --property=ControlGroup,RuntimeMaxUSec,KillMode,KillSignal,SendSIGKILL,ActiveState)
    printf '%s\n' "$props"
    for exact in "ControlGroup=$group" RuntimeMaxUSec=42s KillMode=control-group KillSignal=9 SendSIGKILL=yes ActiveState=active; do
        printf '%s\n' "$props" | /usr/bin/grep -Fxq -- "$exact"
    done
    triple=aarch64-unknown-linux-gnu
    ;;
 macos)
    [ "$(/usr/bin/uname -s)" = Darwin ]
    [ "$(/usr/bin/uname -m)" = arm64 ]
    [ "$(/usr/sbin/sysctl -n hw.optional.arm64)" = 1 ]
    translated=$(/usr/sbin/sysctl -in sysctl.proc_translated 2>/dev/null || :)
    [ "$translated" != 1 ]
    model=$(/usr/sbin/sysctl -n hw.model)
    case "$model" in VirtualMac*) exit 84;; esac
    pgid=$(/bin/ps -o pgid= -p "$$" | /usr/bin/tr -d '[:space:]')
    [ "$pgid" = "$PPID" ]
    printf 'native_model=%s translated=%s compiler_group=%s timeout_parent=%s\n' "$model" "$translated" "$pgid" "$PPID"
    triple=aarch64-apple-darwin
    ;;
 *) exit 84;;
esac
/usr/bin/uname -a
/bin/mkdir -m 700 -- "$work"
cleanup() {
    code=$?
    trap - EXIT
    if [ -L "$work" ] || [ ! -d "$work" ]; then
        printf 'cleanup_path_changed=%s\n' "$work"
        exit 89
    fi
    if /bin/rm -rf -- "$work" && [ ! -e "$work" ] && [ ! -L "$work" ]; then
        printf 'scratch_removed=%s\n' "$work"
    else
        printf 'cleanup_failed=%s\n' "$work"
        exit 89
    fi
    exit "$code"
}
trap cleanup EXIT
printf 'scratch=%s\n' "$work"
/bin/cat > "$work/source.tar"
case "$platform" in
 linux) actual=$(/usr/bin/sha256sum "$work/source.tar" | /usr/bin/awk '{print $1}');;
 macos) actual=$(/usr/bin/shasum -a 256 "$work/source.tar" | /usr/bin/awk '{print $1}');;
esac
printf 'archive_sha256=%s\n' "$actual"
[ "$actual" = "$expected" ]
/usr/bin/tar -xf "$work/source.tar" -C "$work"
[ -f "$work/Cargo.toml" ] && [ -f "$work/Cargo.lock" ] && [ -f "$work/build.rs" ] && [ -f "$work/src/sys/mod.rs" ]
toolchain=
if [ "$platform" = linux ]; then
    candidate="$HOME/.rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu/bin"
    if [ -x "$candidate/cargo" ] && [ -x "$candidate/rustc" ]; then toolchain=$candidate; fi
else
    for candidate in "$HOME"/.rustup/toolchains/*-aarch64-apple-darwin/bin /opt/homebrew/opt/rust/bin; do
        if [ -x "$candidate/cargo" ] && [ -x "$candidate/rustc" ]; then toolchain=$candidate; break; fi
    done
fi
if [ -z "$toolchain" ]; then
    printf 'installed_native_cargo_pair_missing=%s\n' "$triple"
    exit 87
fi
printf 'toolchain=%s\n' "$toolchain"
"$toolchain/cargo" --version
rust_identity=$("$toolchain/rustc" -vV)
printf '%s\n' "$rust_identity"
printf '%s\n' "$rust_identity" | /usr/bin/grep -Fxq "host: $triple"
/bin/mkdir -m 700 -- "$work/cargo-home" "$work/target" "$work/tmp"
cd "$work"
status=0
printf 'PTG_CARGO_JSON_BEGIN\n'
/usr/bin/env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS -u RUSTC_WRAPPER -u RUSTC_WORKSPACE_WRAPPER \
    RUSTC="$toolchain/rustc" CARGO_HOME="$work/cargo-home" CARGO_TARGET_DIR="$work/target" TMPDIR="$work/tmp" \
    "$toolchain/cargo" check --locked --offline --lib --message-format=json --target "$triple" || status=$?
printf 'PTG_CARGO_JSON_END\nCARGO_EXIT=%s\n' "$status"
[ "$status" -eq 101 ]
