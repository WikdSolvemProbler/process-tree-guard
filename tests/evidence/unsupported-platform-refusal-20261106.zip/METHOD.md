# Unsupported platform build qualification

The source archive used Cargo.lock, Cargo.toml, build.rs, and src from
64207388b8f1e1fd4310527bb4997b9f286ee113. Its SHA-256 is recorded in
verification.json. Each host checked the digest before extraction.

Both hosts ran the native ARM64 library check with the installed Rust 1.99.0
toolchain, offline and locked. Linux used a finite unprivileged cgroup scope.
The physical Mac used a finite native process group for the compiler tree.
The SSH transport went through the existing Mac route. Independent checks
verified the Linux cgroup, Mac process group, and both scratch directories
were gone. No guarded workload was launched.

The Cargo JSON is preserved separately from transport output. Operator
directory names in transport logs are redacted. Original logs are retained
locally. The checker accepts precisely the unsupported-backend diagnostic
from the library selector and reports every other build result as a failure.
