"""Read-only validation of the staged source and launch inputs for issue #7."""

import hashlib
import json
import os
import shutil
import sys
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
MANIFEST_SHA = "0826dc5baff96d28d24f78184b53df03d7f248f3c970344bac86929d89e2f9b0"
EXPECTED_CONFIG = "tests/campaign-sysprims-fast-warn.json"
EXPECTED_SEED = 20261029
FORBIDDEN_ENV = {"RUST_LOG", "PYTHONHOME", "PYTHONPATH", "PYTHONSTARTUP"}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def staged_file(root, relative):
    parts = PurePosixPath(relative).parts
    if not parts or any(part in (".", "..", "/") or ":" in part or "\\" in part
                        for part in parts):
        raise ValueError(f"noncanonical staged path {relative!r}")
    path = root.joinpath(*parts)
    if not path.is_file() or path.resolve() != path:
        raise ValueError(f"not a canonical staged file: {relative!r}")
    return path


def check_inputs():
    manifest_path = HERE / "inputs.json"
    raw = manifest_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != MANIFEST_SHA:
        raise ValueError("draft inputs manifest SHA-256 differs")
    manifest = json.loads(raw)
    if manifest["config"] != EXPECTED_CONFIG or manifest["seed"] != EXPECTED_SEED:
        raise ValueError("unexpected staged configuration or seed")
    if digest(HERE / "source.tar") != manifest["source_tar_sha256"]:
        raise ValueError("draft source archive SHA-256 differs")
    checkout = HERE / "checkout"
    staged = manifest["file_sha256"]
    actual = set()
    for directory, dirs, files in (checkout / "tests").walk(follow_symlinks=False):
        for name in dirs:
            path = directory / name
            if path.is_symlink() or path.is_junction():
                raise ValueError(f"redirected staged directory {path}")
        actual.update((directory / name).relative_to(checkout).as_posix() for name in files)
    if actual != set(staged):
        raise ValueError("staged file census differs")
    for name, expected in staged.items():
        if digest(staged_file(checkout, name)) != expected:
            raise ValueError(f"staged file SHA-256 differs: {name}")
    config = staged_file(checkout, EXPECTED_CONFIG)
    if digest(config) != manifest["config_sha256"]:
        raise ValueError("draft configuration SHA-256 differs")
    for name, tool in manifest["tools"].items():
        path = Path(tool["path"])
        if not path.is_absolute() or digest(path) != tool["sha256"]:
            raise ValueError(f"tool identity differs: {name}")
    if not Path(sys.executable).samefile(manifest["tools"]["python"]["path"]):
        raise ValueError("current interpreter does not match the pinned executable")
    for name in ("python", "cmd"):
        found = shutil.which(name)
        if found is None or not Path(found).samefile(manifest["tools"][name]["path"]):
            raise ValueError(f"ambient {name} resolution differs")
    return {
        "scope": "staged input check only",
        "manifest_sha256": MANIFEST_SHA, "source_commit": manifest["commit"],
        "files": len(staged), "benchmark_slots": 0,
        "host_build": sys.getwindowsversion().build,
        "python_version": sys.version,
        "ambient_launch_refusals": sorted(FORBIDDEN_ENV.intersection(os.environ)),
    }


if __name__ == "__main__":
    if not sys.flags.isolated or not sys.dont_write_bytecode:
        raise SystemExit("requires -I -B")
    print(json.dumps(check_inputs(), indent=2))