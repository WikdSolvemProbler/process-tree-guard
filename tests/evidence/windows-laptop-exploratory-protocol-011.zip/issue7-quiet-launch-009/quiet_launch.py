"""Sealed launch boundary for one issue #7 attempt."""

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
INPUTS = HERE.with_name("issue7-quiet-campaign-inputs-002")
CHECKOUT = INPUTS / "checkout"
CAPTURE = HERE / "capture"
RUN_ID = "issue7-quiet-20261107-009-s20261029"
SEED = 20261029
DURING_SECONDS = 6600
OUTER_SECONDS = 6900
BOUND_FILES = ("quiet_launch.py", "quiet_runner.py", "quiet_gate.py", "quiet_sampler.py",
               "inventory_gate.py", "image_policy.py", "audit_package.py", "replay.py", "METHOD.md")
ARM_FILES = {
    "guard": "tests/build/process-tree-guard.exe",
    "nuewframe": "tests/build/competitors/timeout.exe",
    "processkit": "tests/build/competitors/processkit-cli.exe",
    "sysprims": "tests/build/competitors/sysprims.exe",
}
ENV_NAMES = ("PATH", "PATHEXT", "SYSTEMROOT", "COMSPEC", "TEMP", "TMP")
FORBIDDEN_ENV = {"PYTHONHOME", "PYTHONPATH", "PYTHONSTARTUP"}
VOLATILE_ENV = ("CODEX_TOOL_CALL_ID",)


def hash_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def hash_file(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def environment_hashes():
    return {name: None if name not in os.environ else hash_bytes(os.environ[name].encode())
            for name in ENV_NAMES}


def effective_environment_sha256():
    # Keep raw environment values private and bind the whole child block.
    effective = {key: value for key, value in os.environ.items() if key not in {"RUST_LOG", *VOLATILE_ENV}}
    return hash_bytes(json.dumps(effective, sort_keys=True, ensure_ascii=True).encode())


def worker_args(tools):
    return (
        tools["python"]["path"], "-I", "-B", "-X", "utf8", "-c",
        "import sys;sys.path.insert(0,sys.argv.pop(1));from harness import main;"
        "raise SystemExit(main(sys.argv[1:]))",
        str(CHECKOUT / "tests/campaign"), "run",
        "--config", str(CHECKOUT / "tests/campaign-sysprims-fast-warn.json"),
        "--out", str(CAPTURE / "campaign"),
        "--seed", str(SEED), "--run-id", RUN_ID,
    )


def description(expected_checker_sha=None):
    input_check = INPUTS / "check_inputs.py"
    checker_raw = input_check.read_bytes()
    checker_sha = hash_bytes(checker_raw)
    if expected_checker_sha is not None and checker_sha != expected_checker_sha:
        raise ValueError("input checker differs from the frozen manifest")
    checked = {"__file__": str(input_check), "__name__": "pinned_input_check"}
    exec(compile(checker_raw, str(input_check), "exec"), checked)
    inputs_receipt = checked["check_inputs"]()
    inputs = json.loads((INPUTS / "inputs.json").read_bytes())
    if CHECKOUT.resolve() != CHECKOUT or {entry.name for entry in CHECKOUT.iterdir()} != {"tests"}:
        raise ValueError("checkout root contains unpinned paths")
    if not Path(os.environ.get("COMSPEC", "")).samefile(inputs["tools"]["cmd"]["path"]):
        raise ValueError("COMSPEC does not match the pinned command processor")
    environment = environment_hashes()
    if FORBIDDEN_ENV.intersection(os.environ):
        raise ValueError("forbidden Python environment variable inherited")
    fingerprints = {}
    for arm, filename in ARM_FILES.items():
        path = CHECKOUT / filename
        fingerprints[arm] = {
            "path": str(path), "size": path.stat().st_size,
            "sha256": inputs["file_sha256"][filename],
        }
    return {
        "schema": "issue7-quiet-launch-v1",
        "purpose": "exploratory aggregate-CPU-gated laptop capture; strict007 and issue7 remain open",
        "input_manifest_sha256": inputs_receipt["manifest_sha256"],
        "input_checker_sha256": checker_sha,
        "source_commit": inputs_receipt["source_commit"],
        "windows_build": inputs_receipt["host_build"],
        "python_version": inputs_receipt["python_version"],
        "file_sha256": {name: hash_file(HERE / name) for name in BOUND_FILES},
        "tools": inputs["tools"],
        "os_wait_image": {
            "path": str(Path(os.environ["SYSTEMROOT"]) / "System32/timeout.exe"),
            "sha256": hash_file(Path(os.environ["SYSTEMROOT"]) / "System32/timeout.exe"),
        },
        "config_sha256": inputs["config_sha256"],
        "cwd": str(CHECKOUT),
        "destination": str(CAPTURE),
        "run_id": RUN_ID, "seed": SEED,
        "worker_argv": list(worker_args(inputs["tools"])),
        "environment_sha256": environment,
        "effective_environment_sha256": effective_environment_sha256(),
        "volatile_environment_keys": list(VOLATILE_ENV),
        "rust_log": "removed from the observer and worker environment only",
        "stdio": "DEVNULL input, exclusive binary output files, worker UTF-8 mode",
        "outer_argv_template": [
            inputs["tools"]["outer_guard"]["path"], "--timeout", str(OUTER_SECONDS), "--",
            inputs["tools"]["python"]["path"], "-I", "-B", str(HERE / "quiet_launch.py"),
            "execute", "--approved-sha", "<SHA256 of this exact manifest>",
        ],
        "outer_deadline_seconds": OUTER_SECONDS,
        "during_deadline_seconds": DURING_SECONDS,
        "fingerprints": fingerprints,
        "image_policy": {
            "scope": "known compiler and runtime names plus pinned basenames only; arbitrary renames uninspected",
            "background": "unclassified; all CPU remains in system residual",
            "membership_priority": "held enclosing guard, exact campaign Job, compiler name, pinned content, background",
            "sampled_names_source": "bound inventory_gate.py COMPILERS and WORKLOADS plus pinned_basenames",
            "content_scope": "sampled on-disk bytes through retained process image path; original loaded bytes not established",
            "veto_sha256": sorted({row["sha256"] for row in fingerprints.values()}
                                  | {inputs["tools"]["outer_guard"]["sha256"]}),
            "pinned_basenames": sorted({Path(row["path"]).name.casefold() for row in fingerprints.values()}
                                       | {Path(inputs["tools"]["outer_guard"]["path"]).name.casefold()}),
        },
    }


def validate_manifest(path, approved_sha256):
    raw = path.read_bytes()
    binding = hash_bytes(raw)
    if len(approved_sha256) != 64 or binding != approved_sha256:
        raise ValueError("manifest differs from the explicitly approved digest")
    manifest = json.loads(raw)
    if manifest != description(manifest["input_checker_sha256"]):
        raise ValueError("current launch inputs differ from the frozen manifest")
    return manifest, binding


def write_json(path, data):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2, allow_nan=False)
        stream.write("\n")


def read_jsonl(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def verify_inventory(samples, inventory_rows, guard, image_policy):
    from image_policy import ALLOWED, classify
    from inventory_gate import COMPILERS
    expected = [(event["phase"], event["raw"]["monotonic_ns"]) for event in samples]
    actual = [(row["phase"], row["monotonic_ns"]) for row in inventory_rows]
    if actual != expected:
        raise ValueError("process inventory is not one-to-one with raw telemetry")
    pid, _, created = guard
    for row in inventory_rows:
        records = row["rows"]
        pinned = [entry for entry in records if entry["state"] == "pinned_enclosing_guard"]
        if (len(pinned) != 1 or pinned[0]["pid"] != pid or pinned[0]["created_ticks"] != created
                or row["finished_ns"] < row["monotonic_ns"]
                or row["finished_ns"] - row["monotonic_ns"] > 50_000_000):
            raise ValueError("process inventory identity or bracket differs")
        allowed = set(ALLOWED) - {"campaign_member"}
        for entry in records:
            if entry["state"] != "pinned_enclosing_guard":
                expected_state = classify(
                    entry["name"], entry["image_sha256"], enclosing=False,
                    member=entry["state"] == "campaign_member",
                    compiler_names=COMPILERS, veto_sha256=set(image_policy["veto_sha256"]),
                )
                if entry["state"] != expected_state:
                    raise ValueError("image classification differs")
        if row["phase"] == "during":
            allowed.add("campaign_member")
        if any(entry["state"] not in allowed for entry in records):
            raise ValueError("process inventory contains an unverified or competing workload")


def execute(path, approved_sha256):
    # The operator supplies the exact digest approved by both reviewers.
    # The program checks that digest and never issues a review approval itself.
    manifest, binding = validate_manifest(path, approved_sha256)
    os.environ.pop("RUST_LOG", None)
    if "RUST_LOG" in os.environ:
        raise ValueError("RUST_LOG remained present in the worker environment")
    sys.path[:0] = [str(HERE), str(CHECKOUT / "tests/campaign")]
    import harness
    if Path(harness.__file__).resolve() != CHECKOUT / "tests/campaign/harness.py":
        raise ValueError("campaign imported a different harness")
    from audit_package import audit_complete
    from inventory_gate import enclosing_guard, inventory
    from quiet_runner import Rejected, capture
    from quiet_sampler import SlotJob, stamp, warm_job_query
    from replay import replay

    argv = tuple(manifest["worker_argv"])
    os.chdir(CHECKOUT)
    with enclosing_guard(manifest["tools"]["outer_guard"]["path"]) as guard:
        CAPTURE.mkdir()
        write_json(CAPTURE / "binding.json", {"manifest_sha256": binding, "manifest": manifest,
                                              "observer_pid": os.getpid(), "utc_ns": time.time_ns(),
                                              "volatile_environment_sha256": {
                                                  name: hash_bytes(os.environ[name].encode())
                                                  for name in VOLATILE_ENV if name in os.environ},
                                              "enclosing_guard_pid": guard[0],
                                              "enclosing_guard_created_ticks": guard[2]})
        final = {"manifest_sha256": binding, "telemetry_pass": False, "package_complete": False,
                 "scope": "exploratory aggregate-CPU-gated laptop capture; strict007 and issue7 remain open"}
        try:
            print(json.dumps({"stage": "capture_started", "manifest_sha256": binding,
                              "scope": manifest["purpose"]}), flush=True)
            warm_job_query()
            with (CAPTURE / "inventory.jsonl").open("x", encoding="utf-8") as census, \
                    (CAPTURE / "stdout.log").open("xb") as stdout, \
                    (CAPTURE / "stderr.log").open("xb") as stderr:
                sample_counts = {}
                def on_sample(phase, sample, job):
                    from image_policy import ALLOWED
                    rows = inventory(guard, None if job is None else job._handle,
                                     manifest["image_policy"])
                    finished = time.perf_counter_ns()
                    sample_counts[phase] = sample_counts.get(phase, 0) + 1
                    if sample_counts[phase] % 12 == 0:
                        print(json.dumps({"stage": phase, "samples": sample_counts[phase],
                                          "utc_ns": time.time_ns()}), flush=True)
                    print(json.dumps({"phase": phase, "monotonic_ns": sample.monotonic_ns,
                                      "finished_ns": finished, "utc_ns": time.time_ns(),
                                      "rows": rows}), file=census, flush=True)
                    if finished - sample.monotonic_ns > 50_000_000 or any(
                        row["state"] not in ALLOWED
                        for row in rows
                    ):
                        raise Rejected("competing or unverified process inventory")

                import subprocess
                accepted = capture(argv, CAPTURE / "telemetry.jsonl",
                                   max_during_seconds=DURING_SECONDS,
                                   make_job=SlotJob, stamp=stamp, now_ns=time.perf_counter_ns,
                                   sleep=time.sleep, stdin=subprocess.DEVNULL,
                                   stdout=stdout, stderr=stderr, on_sample=on_sample,
                                   utc_ns=time.time_ns, binding=binding)
            if not accepted:
                raise Rejected("live telemetry capture refused")
            telemetry = read_jsonl(CAPTURE / "telemetry.jsonl")
            replay(telemetry, argv=argv, max_during_seconds=DURING_SECONDS, binding=binding)
            verify_inventory([row for row in telemetry if row["kind"] == "sample"],
                             read_jsonl(CAPTURE / "inventory.jsonl"), guard, manifest["image_policy"])
            final["telemetry_pass"] = True
            validate_manifest(path, binding)
            run_dir = CAPTURE / "campaign" / RUN_ID
            audited = audit_complete(
                harness, run_dir, run_id=RUN_ID,
                config=CHECKOUT / "tests/campaign-sysprims-fast-warn.json",
                config_sha=manifest["config_sha256"], seed=SEED,
                fingerprints={arm: dict(info, path=Path(info["path"]))
                              for arm, info in manifest["fingerprints"].items()},
            )
            final.update(package_complete=True, audit=audited)
        except BaseException as error:
            final["error"] = f"{type(error).__name__}: {error}"
            raise
        finally:
            final["utc_ns"] = time.time_ns()
            final["file_sha256"] = {
                name: hash_file(CAPTURE / name)
                for name in ("binding.json", "telemetry.jsonl", "inventory.jsonl", "stdout.log", "stderr.log")
                if (CAPTURE / name).is_file()
            }
            write_json(CAPTURE / "terminal.json", final)
            print(json.dumps({"stage": "terminal", "telemetry_pass": final["telemetry_pass"],
                              "package_complete": final["package_complete"],
                              "error": final.get("error")}), flush=True)
    return 0


def main():
    if not sys.flags.isolated or not sys.dont_write_bytecode or sys.platform != "win32":
        raise SystemExit("Windows Python -I -B is required")
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("describe", "validate", "execute"))
    parser.add_argument("--approved-sha")
    args = parser.parse_args()
    path = HERE / "manifest.json"
    if args.mode == "describe":
        print(json.dumps(description(), indent=2, allow_nan=False))
        return 0
    if not args.approved_sha:
        parser.error("--approved-sha is required")
    if args.mode == "validate":
        _, binding = validate_manifest(path, args.approved_sha)
        print(json.dumps({"validated": binding, "benchmark_slots": 0}))
        return 0
    return execute(path, args.approved_sha)


if __name__ == "__main__":
    raise SystemExit(main())
