"""Read-only image digest control. It never launches inspected executables."""
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from inventory_gate import image_digest


def main():
    manifest_path, git_path, git_sha, output = map(str, sys.argv[1:])
    manifest = json.loads(Path(manifest_path).read_bytes())
    images = {name: row for name, row in manifest["fingerprints"].items()
              if name in ("guard", "sysprims")}
    images.update(python=manifest["tools"]["python"],
                  outer_guard=manifest["tools"]["outer_guard"],
                  git={"path": git_path, "sha256": git_sha})
    receipts = []
    for name, row in images.items():
        image = Path(row["path"])
        actual = image_digest(image)
        if actual != row["sha256"]:
            raise ValueError(f"pinned image digest differs: {name}")
        receipts.append({"name": name, "path": str(image), "sha256": actual})
    with Path(output).open("x", encoding="utf-8") as stream:
        json.dump({"state": "PASS", "scope": "read-only native image metadata control",
                   "benchmark_slots": 0, "images": receipts}, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
