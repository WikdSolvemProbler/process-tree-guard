import hashlib
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from inventory_gate import image_digest


def info(ctime, **changes):
    values = dict(st_dev=1, st_ino=2, st_size=7, st_mtime_ns=4, st_ctime_ns=ctime)
    values.update(changes)
    return SimpleNamespace(**values)


class MetadataTests(unittest.TestCase):
    def digest(self, paths, handles):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "image"
            path.write_bytes(b"fixture")
            wrapped = Mock()
            wrapped.open.side_effect = path.open
            wrapped.stat.side_effect = paths
            with patch("inventory_gate.os.fstat", side_effect=handles):
                return image_digest(wrapped)

    def test_interface_ctime_difference_is_allowed_if_each_stays_stable(self):
        self.assertEqual(self.digest([info(100), info(100)], [info(200), info(200)]),
                         hashlib.sha256(b"fixture").hexdigest())

    def test_each_interface_ctime_drift_refuses(self):
        for paths, handles in (
            ([info(100), info(101)], [info(200), info(200)]),
            ([info(100), info(100)], [info(200), info(201)]),
        ):
            with self.subTest(paths=paths, handles=handles):
                with self.assertRaisesRegex(ValueError, "changed"):
                    self.digest(paths, handles)

    def test_native_identity_or_metadata_disagreement_refuses(self):
        for field in ("st_dev", "st_ino", "st_size", "st_mtime_ns"):
            with self.subTest(field=field):
                with self.assertRaisesRegex(ValueError, "differ"):
                    self.digest([info(100)], [info(200, **{field: 999})])


if __name__ == "__main__":
    unittest.main()
