import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from inventory_gate import enclosing_guard, inventory

manifest = json.loads((HERE / "manifest.json").read_bytes())
refusals = 0
durations = []
with (HERE / "native-census.jsonl").open("x", encoding="utf-8") as output, \
        enclosing_guard(manifest["tools"]["outer_guard"]["path"]) as guard:
    for index in range(10):
        start = time.perf_counter_ns()
        rows = inventory(guard, image_policy=manifest["image_policy"])
        elapsed = time.perf_counter_ns() - start
        durations.append(elapsed)
        refusals += sum(row["state"] == "membership_unverified" for row in rows)
        print(json.dumps({"sample": index, "elapsed_ns": elapsed, "rows": rows}), file=output, flush=True)
        time.sleep(0.1)
print(json.dumps({"scope": "read-only native census control", "samples": 10,
                  "unverified": refusals, "max_ns": max(durations), "benchmark_slots": 0}))
raise SystemExit(0 if not refusals and max(durations) <= 50_000_000 else 1)