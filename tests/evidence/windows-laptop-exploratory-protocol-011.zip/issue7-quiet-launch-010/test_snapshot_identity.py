from contextlib import nullcontext
from pathlib import Path
import unittest
from unittest.mock import patch

import inventory_gate as gate

POLICY = {"veto_sha256": ["a" * 64], "pinned_basenames": ["timeout.exe"]}


class SnapshotTests(unittest.TestCase):
    def inventory(self, created=200, after=None):
        image = Path("C:/fixture/python.exe")
        snapshot = {10: gate.Entry(10, 1, "process-tree-guard.exe"),
                    20: gate.Entry(20, 1, "python.exe")}
        with patch.object(gate, "entries", return_value=(snapshot, 200)) as entries, \
                patch.object(gate.os, "getpid", return_value=99), \
                patch.object(gate, "open_exact", return_value=nullcontext(123)), \
                patch.object(gate, "identity", side_effect=[(image, created), after or (image, created)]), \
                patch.object(gate, "image_digest", return_value="b" * 64), \
                patch.object(gate, "is_alive", side_effect=[True, False]):
            rows = gate.inventory((10, 111, 50), image_policy=POLICY)
            entries.assert_called_once_with(capture_upper=True)
            return rows[-1]

    def test_birth_after_old_presnapshot_clock_within_upper_is_valid(self):
        row = self.inventory()
        self.assertEqual(row["state"], "unclassified_background")
        self.assertEqual(row["created_ticks"], row["snapshot_upper_ticks"])
        self.assertFalse(row["alive_after"])

    def test_birth_after_snapshot_upper_refuses_and_preserves_identity(self):
        row = self.inventory(created=201)
        self.assertEqual(row["state"], "membership_unverified")
        self.assertEqual(row["created_ticks"], 201)
        self.assertEqual(row["image_path"], str(Path("C:/fixture/python.exe")))
        self.assertIn("precise snapshot upper", row["reason"])

    def test_retained_identity_change_still_refuses(self):
        row = self.inventory(after=(Path("C:/fixture/python.exe"), 201))
        self.assertEqual(row["state"], "membership_unverified")
        self.assertIn("identity changed", row["reason"])

    def test_snapshot_image_name_mismatch_refuses(self):
        with self.assertRaisesRegex(ValueError, "image name"):
            gate.snapshot_identity(gate.Entry(20, 1, "python.exe"),
                                   Path("C:/fixture/other.exe"), 100, 200)


if __name__ == "__main__":
    unittest.main()
