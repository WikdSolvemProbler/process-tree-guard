from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
REPO = ROOT.parents[2]
OUT = REPO / "tests/evidence/windows-laptop-exploratory-protocol-011.zip"
assert not (ROOT / "capture").exists(), "preregistration must precede any benchmark slot"
binding = sha256((ROOT / "manifest.json").read_bytes()).hexdigest()
assert binding == "fa64410ae847be10735cdf5a69ce71acb7213a2d9bbe3b7695c83a8f15df454a"
manifest = json.loads((ROOT / "manifest.json").read_bytes())
for name, digest in manifest["file_sha256"].items():
    assert sha256((ROOT / name).read_bytes()).hexdigest() == digest

files = {}
for revision in range(8, 12):
    folder = BASE / f"issue7-quiet-launch-{revision:03}"
    for item in sorted(folder.iterdir()):
        if item.is_file() and item.suffix in (".py", ".json", ".jsonl", ".md", ".log") \
                and not item.name.startswith("env-digests-"):
            files[f"{folder.name}/{item.name}"] = item.read_bytes()
    for attempt in sorted(folder.glob("smoke-*")):
        if attempt.is_dir():
            for item in sorted(attempt.iterdir()):
                if item.is_file():
                    files[f"{folder.name}/{attempt.name}/{item.name}"] = item.read_bytes()

inputs = BASE / "issue7-quiet-campaign-inputs-002"
inputs_meta = json.loads((inputs / "inputs.json").read_bytes())
for name in ("inputs.json", "check_inputs.py", "source.tar"):
    files[f"{inputs.name}/{name}"] = (inputs / name).read_bytes()
for name, digest in inputs_meta["file_sha256"].items():
    item = inputs / "checkout" / name
    raw = item.read_bytes()
    assert sha256(raw).hexdigest() == digest
    files[f"{inputs.name}/checkout/{name}"] = raw

smoke = BASE / "issue7-quiet-launch-010/smoke-001"
events = [json.loads(line) for line in (smoke / "telemetry.jsonl").read_bytes().splitlines()]
assert events[-1]["kind"] == "terminal" and events[-1]["accepted"] is True
assert [row["phase"] for row in events if row["kind"] == "phase_decision"] == ["pre", "during", "post"]
assert all(row["candidate_pass"] for row in events if row["kind"] == "phase_decision")
assert [row for row in events if row["kind"] == "drain"] == [
    next(row for row in events if row["kind"] == "drain")]
assert all(row[key] == value for row in events if row["kind"] == "drain"
           for key, value in {"active_before": 0, "terminated": False, "active_after": 0}.items())
groups = {"test_quiet_runner": 6, "test_terminal_population": 6, "test_image_policy": 4,
          "test_image_metadata": 3, "test_snapshot_identity": 4, "test_saved_inventory": 3}
for name, count in groups.items():
    log = (ROOT / f"{name}.stderr.log").read_bytes()
    assert f"Ran {count} tests".encode() in log and log.rstrip().endswith(b"OK")
summary = {
    "scope": manifest["purpose"],
    "approved_manifest_sha256": binding,
    "source_review": {
        "profile_verified_method": "approved exact 011 with zero unresolved objections",
        "profile_verified_critic": "approved exact 011 with zero unresolved material objections",
    },
    "native_lifecycle_source": "issue7-quiet-launch-010",
    "verifier_correction": "distinct local names for held guard and inspected process creation times",
    "offline_tests_passed": sum(groups.values()),
    "approved_full_attempts": 1,
    "full_benchmark_attempts_started": 0,
    "strict_issue7_complete": False,
}
files["PREREGISTRATION.json"] = (json.dumps(summary, indent=2) + "\n").encode()
files["INDEX.json"] = (json.dumps({name: sha256(raw).hexdigest() for name, raw in files.items()},
                                 indent=2) + "\n").encode()
with ZipFile(OUT, "x", compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in sorted(files.items()):
        archive.writestr(name, raw)
with ZipFile(OUT) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(files)
    assert all(archive.read(name) == raw for name, raw in files.items())
print(json.dumps({"sha256": sha256(OUT.read_bytes()).hexdigest(),
                  "bytes": OUT.stat().st_size, "members": len(files)}, indent=2))