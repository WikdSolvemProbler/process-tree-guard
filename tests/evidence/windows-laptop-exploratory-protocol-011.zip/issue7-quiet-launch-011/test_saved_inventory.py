"""Replay immutable native 010 receipts using corrected 011 verification."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from quiet_launch import read_jsonl, verify_inventory
from replay import replay

OLD = HERE.with_name("issue7-quiet-launch-010")
SMOKE = OLD / "smoke-001"
GUARD = (60932, None, 134384926065127495)


class SavedInventoryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.telemetry = read_jsonl(SMOKE / "telemetry.jsonl")
        cls.samples = [row for row in cls.telemetry if row["kind"] == "sample"]
        cls.inventory = read_jsonl(SMOKE / "inventory.jsonl")
        cls.policy = json.loads((OLD / "manifest.json").read_bytes())["image_policy"]

    def test_actual_saved_lifecycle_and_inventory(self):
        binding_raw = (SMOKE / "smoke-binding.json").read_bytes()
        binding = json.loads(binding_raw)
        replay(self.telemetry, argv=tuple(binding["argv"]),
               max_during_seconds=binding["during_seconds"],
               binding=hashlib.sha256(binding_raw).hexdigest())
        verify_inventory(self.samples, self.inventory, GUARD, self.policy)
        self.assertEqual({row["phase"] for row in self.samples}, {"pre", "during", "post"})
        self.assertTrue(self.telemetry[-1]["accepted"])

    def test_forged_pinned_identity_on_later_snapshot_refuses(self):
        for field in ("pid", "created_ticks"):
            with self.subTest(field=field):
                rows = copy.deepcopy(self.inventory)
                pinned = next(row for row in rows[-1]["rows"]
                              if row["state"] == "pinned_enclosing_guard")
                pinned[field] += 1
                with self.assertRaisesRegex(ValueError, "identity or bracket"):
                    verify_inventory(self.samples, rows, GUARD, self.policy)

    def test_creation_after_native_snapshot_refuses(self):
        rows = copy.deepcopy(self.inventory)
        background = next(row for census in rows for row in census["rows"]
                          if row["state"] == "unclassified_background")
        background["created_ticks"] = background["snapshot_upper_ticks"] + 1
        with self.assertRaisesRegex(ValueError, "snapshot upper"):
            verify_inventory(self.samples, rows, GUARD, self.policy)


if __name__ == "__main__":
    unittest.main()
