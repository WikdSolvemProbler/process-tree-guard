from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path(__file__).resolve().parent
base = root.parent
out = root.parents[2] / "tests/evidence/windows-quiet-launch-qualification.zip"
files = {}
for number in range(1, 8):
    directory = base / f"issue7-quiet-launch-{number:03}"
    for path in sorted(directory.iterdir()):
        if not path.is_file() or path.name.startswith("env-digests-"):
            continue
        if path.suffix in (".py", ".json", ".jsonl", ".log"):
            files[f"launch-{number:03}/{path.name}"] = path.read_bytes()
    for directory in sorted(directory.glob("smoke-*")):
        if directory.is_dir():
            for path in sorted(directory.iterdir()):
                if path.is_file():
                    files[f"launch-{number:03}/{directory.name}/{path.name}"] = path.read_bytes()

inputs = base / "issue7-quiet-campaign-inputs-002"
for name in ("check_inputs.py", "inputs.json", "source.tar"):
    files[f"inputs-002/{name}"] = (inputs / name).read_bytes()
binding = sha256((root / "manifest.json").read_bytes()).hexdigest()
assert binding == "9b266034df2c79fd1614926b843864b135aa8c39e01a20c3fb9af17992dfd100"
manifest = json.loads((root / "manifest.json").read_bytes())
for name, expected in manifest["file_sha256"].items():
    assert sha256((root / name).read_bytes()).hexdigest() == expected
audit = json.loads((root / "audit-binding.stdout.log").read_bytes())
assert audit == {
    "historical_complete_slots": 1940, "historical_campaign_status": "incomplete",
    "standing_losses_preserved": 44, "bound_files": 473, "refusal_controls": 7,
    "live_benchmark_slots": 0,
}
for name in ("test_quiet_runner", "test_terminal_population"):
    assert b"Ran 6 tests" in files[f"launch-007/{name}.stderr.log"]
    assert files[f"launch-007/{name}.stderr.log"].rstrip().endswith(b"OK")
refusals = {}
for name in ("smoke-001", "smoke-002", "smoke-003"):
    result = json.loads(files[f"launch-007/{name}/result.json"])
    assert not result["accepted"] and result["benchmark_slots"] == 0
    assert result["terminal"]["problems"] == [
        "pre: Rejected: competing or unverified process inventory"]
    refusals[name] = result["terminal"]
for edge in ("before", "after"):
    path = base / "issue7-quiet-launch-004" / f"edge-{edge}.jsonl"
    rows = [json.loads(line) for line in path.read_bytes().splitlines()]
    windows = [row for row in rows if row["kind"] == "interval"]
    assert len(windows) == 3 and all(row["pass_control"] and row["job_minus_exact_ticks"] == 0
                                   for row in windows)
    assert rows[-1]["valid"] and rows[-1]["benchmark_slots"] == 0

summary = {
    "scope": "strict quiet-campaign launcher qualification",
    "manifest_sha256": binding,
    "source_review": {
        "profile_verified_method": "approved exact 007, conditional on complete natural lifecycle",
        "profile_verified_critic": "approved exact 007, conditional on complete natural lifecycle",
    },
    "native_lifecycle_passed": False,
    "benchmark_slots": 0,
    "strict_preflight_refusals": refusals,
    "scheduled_window_median_controls": 12,
    "historical_complete_audit": audit,
    "boundary_control_windows": 6,
    "scope_objection": "Generic external Python/timeout names do not prove competing test work. A refined census requires a new protocol and review.",
}
files["qualification.json"] = (json.dumps(summary, indent=2) + "\n").encode()
files["manifest.json"] = (json.dumps({
    "members_sha256": {name: sha256(raw).hexdigest() for name, raw in files.items()}
}, indent=2) + "\n").encode()
with ZipFile(out, "x", compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in sorted(files.items()):
        archive.writestr(name, raw)
with ZipFile(out) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(files)
    assert all(archive.read(name) == raw for name, raw in files.items())
print(json.dumps({"sha256": sha256(out.read_bytes()).hexdigest(),
                  "bytes": out.stat().st_size, "members": len(files)}, indent=2))