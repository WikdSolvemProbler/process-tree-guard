import unittest

from image_policy import classify

PINNED = "a" * 64
OTHER = "b" * 64


class PolicyTests(unittest.TestCase):
    def classify(self, name, digest, member=False, enclosing=False):
        return classify(name, digest, enclosing=enclosing, member=member,
                        compiler_names={"rustc.exe"}, veto_sha256={PINNED})

    def test_same_basename_different_binary_is_background(self):
        self.assertEqual(self.classify("timeout.exe", OTHER), "unclassified_background")

    def test_copied_competitor_content_vetoes_any_inspected_basename(self):
        self.assertEqual(self.classify("python.exe", PINNED), "pinned_workload_outside_job")
        self.assertEqual(self.classify("timeout.exe", PINNED), "pinned_workload_outside_job")

    def test_job_and_held_guard_identity_take_priority(self):
        self.assertEqual(self.classify("timeout.exe", PINNED, member=True), "campaign_member")
        self.assertEqual(self.classify("rustc.exe", None, member=True), "campaign_member")
        self.assertEqual(self.classify("process-tree-guard.exe", PINNED, enclosing=True),
                         "pinned_enclosing_guard")

    def test_compiler_name_and_generic_runtime(self):
        self.assertEqual(self.classify("rustc.exe", None), "compiler_present")
        self.assertEqual(self.classify("python.exe", OTHER), "unclassified_background")


if __name__ == "__main__":
    unittest.main()
