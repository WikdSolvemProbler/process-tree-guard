import hashlib
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from inventory_gate import enclosing_guard, image_digest, inventory

manifest = json.loads((HERE / "manifest.json").read_bytes())
checks = {}
for name, path in {
    "python": manifest["tools"]["python"]["path"],
    "git_timeout": "C:/Program Files/Git/usr/bin/timeout.exe",
    "guard": manifest["fingerprints"]["guard"]["path"],
    "sysprims": manifest["fingerprints"]["sysprims"]["path"],
}.items():
    image = Path(path)
    digest = image_digest(image)
    with image.open("rb") as stream:
        assert digest == hashlib.file_digest(stream, "sha256").hexdigest()
    checks[name] = digest
with enclosing_guard(manifest["tools"]["outer_guard"]["path"]) as guard:
    start = time.perf_counter_ns()
    before = time.process_time_ns()
    rows = inventory(guard, image_policy=manifest["image_policy"])
    elapsed = time.perf_counter_ns() - start
    cpu = time.process_time_ns() - before
print(json.dumps({"scope": "read-only native image checks", "benchmark_slots": 0,
                  "wall_ns": elapsed, "observer_cpu_ns": cpu,
                  "image_sha256": checks, "inventory": rows}, indent=2))