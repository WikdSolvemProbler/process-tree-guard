import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from quiet_gate import Cpu, Job, Sample
from quiet_runner import capture

NS = 1_000_000_000


class Fake:
    pid = 123

    def __init__(self, fault=None):
        self.t = 0
        self.launched = None
        self.fault = fault
        self.calls = []
        self.duration = (60.5 if fault == "short" else 62) * NS
        self.waits = []
        self.closed = False

    def now(self):
        return self.t

    def sleep(self, seconds):
        self.t += round(seconds * NS)

    def stamp(self, job):
        awake = self.t // 100
        # One processor, all idle except for the requested dirty window.
        dirty = 0
        if job and self.launched is not None and self.fault == "dirty":
            dirty = min(5 * NS, self.t - self.launched) // 100
        if job and self.launched is not None and self.fault == "adjacent":
            dirty = min(10 * NS, self.t - self.launched) // 500
        if job and self.launched is not None and self.fault == "read_error":
            raise OSError("synthetic counter failure")
        cpu = Cpu(awake - dirty, awake, 0)
        done = self.launched is not None and self.t >= self.launched + self.duration
        if done and job:
            assert self.closed
        counters = Job(0, 0, int(self.launched is not None),
                       int(self.launched is not None and not done))
        stamp = self.t - 2 * NS if done and job and self.fault == "zero" else self.t
        if done and job and self.fault == "backward":
            stamp = self.t - 2 * NS - 1
        return Sample(stamp, awake, awake, 0, 0, 1, 1, 8 << 30, 1, 0,
                      cpu, cpu, counters if job else None)

    def launch(self, argv, flags, **streams):
        self.calls.append(("launch", argv, flags))
        self.launched = self.t
        return self

    def wait(self, timeout):
        self.waits.append(timeout)
        self.t = min(self.t + round(timeout * NS), self.launched + int(self.duration))
        if self.t < self.launched + self.duration:
            raise subprocess.TimeoutExpired(("fixture",), timeout)
        return 0

    def drain(self):
        live = int(self.launched is not None and self.t < self.launched + self.duration)
        self.calls.append(("drain", live))
        return {"active_before": live, "terminated": bool(live), "active_after": 0}

    def close(self):
        self.closed = True
        self.calls.append(("close",))


class RunnerTests(unittest.TestCase):
    def run_fake(self, fault=None):
        fake = Fake(fault)
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "receipt.jsonl"
            result = capture(("fixture", ""), output, max_during_seconds=80,
                             make_job=lambda: fake, stamp=fake.stamp,
                             now_ns=fake.now, sleep=fake.sleep, stdin=None,
                             stdout=None, stderr=None)
            return result, [json.loads(row) for row in output.read_text().splitlines()], fake

    def test_complete(self):
        result, rows, fake = self.run_fake()
        self.assertTrue(result)
        self.assertEqual(fake.calls, [
            ("launch", ("fixture", ""), 0), ("close",), ("drain", 0), ("close",),
        ])
        self.assertEqual(fake.waits, [5.0] * 13)
        self.assertEqual([row["phase"] for row in rows if row["kind"] == "phase_decision"],
                         ["pre", "during", "post"])
        self.assertEqual(sum(row.get("final_partial", False) for row in rows), 1)
        self.assertEqual(rows[-1], {"kind": "terminal", "accepted": True, "problems": []})

    def test_during_violation_aborts_owned_job(self):
        result, rows, fake = self.run_fake("dirty")
        self.assertFalse(result)
        self.assertIn(("drain", 1), fake.calls)
        self.assertTrue(next(row for row in rows if row["kind"] == "abort_drain")["terminated"])
        self.assertFalse(rows[-1]["accepted"])

    def test_adjacent_high_windows_abort_even_under_maximum(self):
        result, rows, fake = self.run_fake("adjacent")
        self.assertFalse(result)
        self.assertEqual([row["residual_cpu_upper_pct"] for row in rows
                          if row["kind"] == "window" and row["phase"] == "during"],
                         [20.0, 20.0])
        self.assertIn(("drain", 1), fake.calls)

    def test_immediate_short_endpoint_replaces_last_complete_window(self):
        result, rows, fake = self.run_fake("short")
        self.assertTrue(result)
        endpoint = next(row for row in rows if row.get("endpoint"))
        self.assertEqual(endpoint["raw"]["monotonic_ns"], 120_500_000_000)
        during = [row for row in rows if row["kind"] == "window" and row["phase"] == "during"]
        self.assertEqual(len(during), 13)
        self.assertEqual(during[-1]["replaces_window"], 12)
        self.assertEqual(during[-1]["system_total_lower_ticks"], 55_000_000)
        self.assertIn(("drain", 0), fake.calls)

    def test_nonincreasing_endpoint_is_retained_and_rejected(self):
        for fault in ("zero", "backward"):
            with self.subTest(fault=fault):
                result, rows, fake = self.run_fake(fault)
                self.assertFalse(result)
                self.assertTrue(any(row.get("endpoint") for row in rows))
                self.assertIn("non-increasing", rows[-1]["problems"][0])
                self.assertEqual(fake.calls.count(("close",)), 2)

    def test_counter_exception_retains_terminal_and_aborts(self):
        result, rows, fake = self.run_fake("read_error")
        self.assertFalse(result)
        self.assertIn(("drain", 1), fake.calls)
        self.assertIn("synthetic counter failure", rows[-1]["problems"][0])


if __name__ == "__main__":
    unittest.main()
