"""Exercise the exact watcher, sampler and inventory with one bounded sleeper."""

import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from quiet_launch import description, hash_bytes, read_jsonl, verify_inventory, write_json
from inventory_gate import enclosing_guard, inventory
from quiet_runner import Rejected, capture
from quiet_sampler import SlotJob, stamp, warm_job_query
from replay import replay
from image_policy import ALLOWED

out = HERE / "smoke-001"
out.mkdir()
campaign = description()
argv = (sys.executable, "-I", "-B", "-c", "import time; time.sleep(62.4)")
bound = {
    "scope": "exploratory aggregate-CPU-gated laptop lifecycle; strict007 and issue7 remain open", "argv": argv, "during_seconds": 90,
    "outer_seconds": 230, "launch_code_sha256": campaign["file_sha256"],
    "source_commit": campaign["source_commit"], "benchmark_slots": 0,
}
write_json(out / "smoke-binding.json", bound)
binding = hash_bytes((out / "smoke-binding.json").read_bytes())
with enclosing_guard(campaign["tools"]["outer_guard"]["path"]) as guard:
    warm_job_query()
    with (out / "inventory.jsonl").open("x", encoding="utf-8") as census, \
            (out / "fixture.stdout").open("xb") as stdout, \
            (out / "fixture.stderr").open("xb") as stderr:
        def on_sample(phase, sample, job):
            rows = inventory(guard, None if job is None else job._handle,
                             campaign["image_policy"])
            finished = time.perf_counter_ns()
            print(json.dumps({"phase": phase, "monotonic_ns": sample.monotonic_ns,
                              "finished_ns": finished, "utc_ns": time.time_ns(),
                              "rows": rows}), file=census, flush=True)
            if finished - sample.monotonic_ns > 50_000_000 or any(
                row["state"] not in ALLOWED for row in rows
            ):
                raise Rejected("competing or unverified process inventory")

        accepted = capture(argv, out / "telemetry.jsonl", max_during_seconds=90,
                           make_job=SlotJob, stamp=stamp, now_ns=time.perf_counter_ns,
                           sleep=time.sleep, stdin=subprocess.DEVNULL, stdout=stdout,
                           stderr=stderr, on_sample=on_sample, utc_ns=time.time_ns, binding=binding)
    telemetry = read_jsonl(out / "telemetry.jsonl")
    result = {"accepted": accepted, "terminal": telemetry[-1], "benchmark_slots": 0,
              "scope": "exploratory aggregate-CPU-gated laptop lifecycle; strict007 and issue7 remain open"}
    if accepted:
        replay(telemetry, argv=argv, max_during_seconds=90, binding=binding)
        samples = [row for row in telemetry if row["kind"] == "sample"]
        verify_inventory(samples, read_jsonl(out / "inventory.jsonl"), guard, campaign["image_policy"])
        result.update(replay=True, samples=len(samples))
    write_json(out / "result.json", result)
    print(json.dumps(result, indent=2))
raise SystemExit(0 if accepted else 1)
