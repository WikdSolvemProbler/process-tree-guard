"""No-process regression of terminal contamination and scheduled medians."""

import copy
from dataclasses import replace
import json
from pathlib import Path
import tempfile
import unittest

from quiet_gate import Cpu, verdict
from quiet_runner import capture
from replay import InvalidReceipt, replay
from test_quiet_runner import Fake, NS

BINDING = "a" * 64
UTC = 1_794_000_000_000_000_000


class Rates(Fake):
    def __init__(self, rates, duration, tail_rate=0):
        super().__init__()
        self.rates = rates
        self.duration = int(duration * NS)
        self.tail_rate = tail_rate

    def stamp(self, job):
        sample = super().stamp(job)
        if job and self.launched is not None:
            elapsed = self.t - self.launched
            busy = 0
            for index, rate in enumerate(self.rates):
                span = max(0, min(5 * NS, elapsed - index * 5 * NS))
                busy += span * rate // 10_000
            tail = max(0, elapsed - len(self.rates) * 5 * NS)
            busy += tail * self.tail_rate // 10_000
            cpu = Cpu(sample.before.total - busy, sample.before.total, 0)
            sample = replace(sample, before=cpu, after=cpu)
        return sample


class PopulationTests(unittest.TestCase):
    def fixture(self, rates, duration, tail_rate=0):
        fake = Rates(rates, duration, tail_rate)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "receipt.jsonl"
            accepted = capture(
                ("fixture", ""), path, max_during_seconds=80,
                make_job=lambda: fake, stamp=fake.stamp, now_ns=fake.now,
                sleep=fake.sleep, stdin=None, stdout=None, stderr=None,
                utc_ns=lambda: UTC + fake.now(), binding=BINDING,
            )
            return accepted, [json.loads(line) for line in path.read_text().splitlines()]

    def replay(self, rows):
        return replay(rows, argv=("fixture", ""), max_during_seconds=80, binding=BINDING)

    def test_six_nine_and_six_twelve_with_one_second_idle_tail(self):
        accepted, rows = self.fixture([9] * 6 + [12] * 6, 61)
        self.assertFalse(accepted)
        scores = [row for row in rows if row["kind"] == "window" and row["phase"] == "during"]
        self.assertEqual([row["residual_cpu_upper_pct"] for row in scores], [9] * 6 + [12] * 6 + [0])
        self.assertTrue(verdict(scores, during=True)["candidate_pass"])
        decision = next(row for row in rows if row["kind"] == "phase_decision" and row["phase"] == "during")
        self.assertEqual(decision["complete_windows"], 12)
        self.assertIn("median_cpu", decision["reasons"])
        with self.assertRaises(InvalidReceipt):
            self.replay(rows)

    def test_merged_tail_cannot_replace_last_median_sample(self):
        accepted, rows = self.fixture([9] * 6 + [12] * 6, 60.5)
        self.assertFalse(accepted)
        decision = next(row for row in rows if row["kind"] == "phase_decision" and row["phase"] == "during")
        self.assertEqual(decision["complete_windows"], 12)
        self.assertIn("median_cpu", decision["reasons"])
        scores = [row for row in rows if row["kind"] == "window" and row["phase"] == "during"]
        self.assertTrue(verdict(scores[:-2] + scores[-1:], during=True)["candidate_pass"])
        with self.assertRaises(InvalidReceipt):
            self.replay(rows)

    def test_endpoint_at_boundary_does_not_buy_coverage(self):
        for duration, expected in ((60, 11), (60.5, 12), (61, 12), (65, 12)):
            with self.subTest(duration=duration):
                accepted, rows = self.fixture([0] * 13, duration)
                self.assertEqual(accepted, duration != 60)
                decision = next(row for row in rows if row["kind"] == "phase_decision" and row["phase"] == "during")
                self.assertEqual(decision["complete_windows"], expected)
                if accepted:
                    self.assertEqual(self.replay(rows)["during_windows"], expected)
                else:
                    with self.assertRaises(InvalidReceipt):
                        self.replay(rows)

    def test_terminal_high_cpu_still_rejects(self):
        accepted, rows = self.fixture([0] * 12, 61, tail_rate=30)
        self.assertFalse(accepted)
        self.assertIn("during window rejected", rows[-1]["problems"][0])

    def test_terminal_adjacency_still_rejects(self):
        accepted, rows = self.fixture([0] * 11 + [16], 61, tail_rate=16)
        self.assertFalse(accepted)
        self.assertIn("during window rejected", rows[-1]["problems"][0])

    def test_replay_rejects_population_tampering(self):
        accepted, rows = self.fixture([0] * 12, 61)
        self.assertTrue(accepted)
        forged = copy.deepcopy(rows)
        decision = next(row for row in forged if row["kind"] == "phase_decision" and row["phase"] == "during")
        decision["complete_windows"] = 13
        with self.assertRaises(InvalidReceipt):
            self.replay(forged)


if __name__ == "__main__":
    unittest.main()
