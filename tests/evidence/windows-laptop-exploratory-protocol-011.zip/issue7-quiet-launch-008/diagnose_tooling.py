import json
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from inventory_gate import entries, identity, open_exact

for index in range(3):
    snapshot = entries()
    interested = {os.getpid()} | {pid for pid, row in snapshot.items() if row.name == "timeout.exe"}
    selected = set()
    for first in interested:
        pid = first
        seen = set()
        for _ in range(12):
            if pid not in snapshot or pid in seen:
                break
            seen.add(pid)
            selected.add(pid)
            pid = snapshot[pid].parent_pid
    output = []
    for pid in sorted(selected):
        row = snapshot[pid]
        result = {"pid": pid, "parent": row.parent_pid, "name": row.name,
                  "observer": pid == os.getpid()}
        try:
            with open_exact(pid) as handle:
                image, created = identity(handle)
                result.update(image=str(image), created_ticks=created)
        except OSError as error:
            result["error"] = error.winerror
        output.append(result)
    print(json.dumps({"sample": index, "utc_ns": time.time_ns(), "processes": output}), flush=True)
    time.sleep(1)