"""Bounded IOCP feasibility probe. Launches a testkit and the pinned bare fixture only."""

import argparse
import ctypes as C
from ctypes import wintypes as W
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import _winapi


TESTKIT_SHA = "d55d6b947c921b9d28e803a5057dac51e8df044fbdd7106b88880292c4c47a2f"
FIXTURE_SHA = "81678345d3b1bb31bbeaee1872580764386274d64f98129b538c80b20ed058d0"
PORT_KEY = 0x49504350
ASSOCIATE_PORT = 7
NEW_PROCESS = 6
WAIT_TIMEOUT = 258
SYNC_QUERY = 0x00101000
NO_WINDOW = 0x08000000

kernel = C.WinDLL("kernel32", use_last_error=True)


def bind(name, types, result):
    func = getattr(kernel, name)
    func.argtypes = types
    func.restype = result
    return func


class Association(C.Structure):
    _fields_ = [("key", C.c_void_p), ("port", W.HANDLE)]


create_port = bind("CreateIoCompletionPort", [W.HANDLE, W.HANDLE, C.c_size_t, W.DWORD], W.HANDLE)
get_packet = bind("GetQueuedCompletionStatus",
                  [W.HANDLE, C.POINTER(W.DWORD), C.POINTER(C.c_size_t), C.POINTER(C.c_void_p), W.DWORD],
                  W.BOOL)
put_packet = bind("PostQueuedCompletionStatus", [W.HANDLE, W.DWORD, C.c_size_t, C.c_void_p], W.BOOL)
query_image = bind("QueryFullProcessImageNameW",
                   [W.HANDLE, W.DWORD, W.LPWSTR, C.POINTER(W.DWORD)], W.BOOL)
query_pid = bind("GetProcessId", [W.HANDLE], W.DWORD)
is_member = bind("IsProcessInJob", [W.HANDLE, W.HANDLE, C.POINTER(W.BOOL)], W.BOOL)
times = bind("GetProcessTimes", [W.HANDLE, *([C.POINTER(W.FILETIME)] * 4)], W.BOOL)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def checked(value):
    if not value:
        raise C.WinError(C.get_last_error())
    return value


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def identity(handle, job, terminal):
    image = None
    member = None
    if not terminal:
        size = W.DWORD(32768)
        image_buf = C.create_unicode_buffer(size.value)
        checked(query_image(handle, 0, image_buf, C.byref(size)))
        image = image_buf.value
        in_job = W.BOOL()
        checked(is_member(handle, job._handle, C.byref(in_job)))
        member = bool(in_job.value)
    stamp = [W.FILETIME() for _ in range(4)]
    checked(times(handle, *(C.byref(item) for item in stamp)))
    fields = [(item.dwHighDateTime << 32) | item.dwLowDateTime for item in stamp]
    return {
        "pid": checked(query_pid(handle)),
        "image": image,
        "member": member,
        "created": fields[0],
        "exited": fields[1] if terminal else None,
    }


def next_packet(port, milliseconds):
    message, key, value = W.DWORD(), C.c_size_t(), C.c_void_p()
    if not get_packet(port, C.byref(message), C.byref(key), C.byref(value), milliseconds):
        error = C.get_last_error()
        if error == WAIT_TIMEOUT:
            return None
        raise C.WinError(error)
    require(key.value == PORT_KEY, "unexpected completion key")
    return message.value, value.value


def associate(native, job):
    require(job._active_processes() == 0, "Job must be empty before port association")
    port = checked(create_port(C.c_void_p(-1), None, 0, 1))
    try:
        config = Association(PORT_KEY, port)
        checked(native.SetInformationJobObject(job._handle, ASSOCIATE_PORT,
                                              C.byref(config), C.sizeof(config)))
        return port
    except BaseException:
        _winapi.CloseHandle(port)
        raise


def member_from_packet(pid, job):
    handle = _winapi.OpenProcess(SYNC_QUERY, False, pid)
    try:
        info = identity(handle, job, terminal=False)
        require(info["pid"] == pid and info["created"] > 0, "process identity differs from packet")
        if info["member"]:
            return handle, info
        return None, info
    finally:
        if "info" not in locals() or not info["member"]:
            _winapi.CloseHandle(handle)


def negative(native):
    with_owned = native.SlotJob()
    port = None
    try:
        port = associate(native, with_owned)
        checked(put_packet(port, NEW_PROCESS, PORT_KEY, C.c_void_p(os.getpid())))
        event = next_packet(port, 100)
        require(event == (NEW_PROCESS, os.getpid()), "negative packet did not arrive")
        handle, info = member_from_packet(event[1], with_owned)
        require(handle is None and not info["member"], "synthetic packet admitted outsider")
        return {"event": event, "identity": info, "accepted": False}
    finally:
        with_owned.close()
        if port is not None:
            _winapi.CloseHandle(port)


def same_path(observed, expected):
    return os.path.normcase(observed) == os.path.normcase(str(expected))


def run_case(native, args, folder, row):
    job = native.SlotJob()
    port = None
    parent = None
    children = {}
    tag = f"{row['index']:032x}"
    verb, value = row["verb"], row["value"]
    argv = [str(args.testkit), "spawn", str(NO_WINDOW), "0.24",
            str(args.fixture), verb, value, tag]
    row.update(argv=argv, events=[], open_errors=[])
    try:
        port = associate(native, job)
        with (folder / "stdout.bin").open("wb") as stdout, (folder / "stderr.bin").open("wb") as stderr:
            parent = job.launch(argv, NO_WINDOW, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
            initial = identity(parent._handle, job, terminal=False)
            require(initial["member"] and same_path(initial["image"], args.testkit), "wrong held fixture parent")
            row["root_initial"] = initial
            deadline = time.monotonic() + 1.2
            while time.monotonic() < deadline:
                event = next_packet(port, 20)
                if event is None:
                    if _winapi.WaitForSingleObject(parent._handle, 0) == 0:
                        break
                    continue
                row["events"].append(event)
                kind, pid = event
                if kind != NEW_PROCESS or pid in (None, parent.pid) or pid in children:
                    continue
                require(len(children) < 8, "fixture Job admission exceeded eight held objects")
                try:
                    handle, data = member_from_packet(pid, job)
                except OSError as error:
                    row["open_errors"].append({"pid": pid, "winerror": error.winerror})
                    continue
                if handle is not None:
                    children[pid] = (handle, data)
            require(parent.wait(max(0.0, deadline - time.monotonic())) == 0, "fixture parent did not exit zero")
            end = identity(parent._handle, job, terminal=True)
            require((initial["pid"], initial["created"]) == (end["pid"], end["created"]),
                    "fixture parent identity changed")
            row["root_final"] = end
            observed = []
            for handle, before in children.values():
                if not same_path(before["image"], args.fixture):
                    continue
                require(_winapi.WaitForSingleObject(handle, 100) == 0, "held fixture child did not exit")
                after = identity(handle, job, terminal=True)
                require(after["pid"] == before["pid"] and after["created"] == before["created"],
                        "held fixture identity changed")
                require(_winapi.GetExitCodeProcess(handle) == 0, "held fixture child exited nonzero")
                require(end["created"] <= after["created"] <= after["exited"] <= end["exited"],
                        "invalid native process lifetime chronology")
                observed.append({"before": before, "after": after})
            row["fixture_handles"] = observed
            require(len(observed) == 1, "missing or duplicate held fixture observation")
        expected = f"BENCHMARK_DONE {verb} {value} {tag}\n".encode()
        require((folder / "stdout.bin").read_bytes() == expected and not (folder / "stderr.bin").read_bytes(),
                "original bare fixture streams differ")
        require(any(kind == NEW_PROCESS and pid == parent.pid for kind, pid in row["events"]),
                "missing original parent NEW_PROCESS packet")
        row["passed"] = True
    finally:
        try:
            row["drain"] = job.drain()
        finally:
            for handle, _ in children.values():
                _winapi.CloseHandle(handle)
            if parent is not None:
                parent.close()
            job.close()
            if port is not None:
                _winapi.CloseHandle(port)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--testkit", type=Path, required=True)
    parser.add_argument("--fixture", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    args = parser.parse_args()
    require(args.testkit.is_absolute() and args.fixture.is_absolute(), "pinned absolute executable paths required")
    sys.path.insert(0, str(args.repo / "tests" / "campaign"))
    import windows_slot_job as native
    args.out.mkdir(exist_ok=False)
    report = {"scope": "synthetic Job notifications, no candidate guard arms", "rows": []}
    try:
        require(digest(args.testkit) == TESTKIT_SHA and digest(args.fixture) == FIXTURE_SHA,
                "fixture digest changed")
        report["outsider_control"] = negative(native)
        for index, (verb, value) in enumerate([("exit", "0")] * 24 + [("wait", "50")] * 4):
            row = dict(index=index, verb=verb, value=value, passed=False)
            folder = args.out / f"{index:02}"
            folder.mkdir()
            try:
                run_case(native, args, folder, row)
            except (OSError, ValueError, subprocess.TimeoutExpired) as error:
                row["error"] = repr(error)
            report["rows"].append(row)
            (folder / "receipt.json").write_text(json.dumps(row, indent=2) + "\n", encoding="utf-8")
        require(digest(args.testkit) == TESTKIT_SHA and digest(args.fixture) == FIXTURE_SHA,
                "fixture changed during the proof")
        report["passed"] = all(row["passed"] and row["drain"]["active_after"] == 0 for row in report["rows"])
    except BaseException as error:
        report["passed"] = False
        report["error"] = repr(error)
    (args.out / "receipt.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "passed": report["passed"], "cases": len(report["rows"]),
        "failures": [(row["index"], row.get("error")) for row in report["rows"] if not row["passed"]],
        "error": report.get("error"),
    }))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
