# Windows Job event feasibility

The Windows x64 probe associated a private completion port with each empty Job.
It atomically launched the original parent into that Job. The completion packet
supplied a PID. A separate native query checked Job membership and the image
while holding the opened process, and the held handle supplied exact terminal
identity and FILETIME timestamps. Each successful arm verified the original
bare fixture's stdout, exit and chronology. The synthetic wrong-Job packet was
rejected. Every slot ended with zero active Job members.

The complete testkit fixture and nested isolated-launcher fixture each observed
28 children, including 24 immediate exits and four 50 ms waits. The assets are
pinned by SHA-256 in source and named in each receipt. Both successful lanes
ran under a 55-second isolated outer Job with finite per-case waits.

The first attempt tried image and membership queries on the terminal handle
and failed. The corrected observer verifies those properties while the process
is live and reads terminal times from the same held handle. The first two
nested attempts captured their raw rows, then failed in the final digest check
because of stale source names. All receipts are preserved.

This is an observer feasibility check. Windows Job completion notifications
can be lost, so missing or ambiguous observations must fail any future phase
experiment. The nested launcher is a fixture here. These observations make no
performance comparison and provide no kernel thread-dispatch timestamps.
