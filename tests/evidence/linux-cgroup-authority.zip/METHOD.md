# Linux cgroup authority source and native evidence

This archive preserves the source, command scripts, compiler receipts and native output for a real descriptor-relative cgroup authority candidate. Extract at a repository root to retain the original Rust module paths. The shared request decoder and deadline module are included. No product backend was enabled by these experiments.

## Attempts and observed outcomes

- 001 preserves the initial source and Windows GNU metadata checks. The original local module-resolution error was corrected before those saved checks. It has no native runtime receipt.
- 002 preserves the failed ordinary-user native ARM64 test. Its generic/x86 O_DIRECTORY and O_NOFOLLOW values were wrong for ARM64. The test followed a fixture symlink and failed. The raw failure, exact input tar, commands and source are retained.
- 003 pins the two architecture-specific open flags, validates the exact returned descriptor type at every opener boundary, and retains the original rejection test. The native test passed on Linux 6.8.0-147-generic aarch64. A separately compiled C program using the guest fcntl.h printed the same six open flags as the Rust source. Additional controls observed a raw O_PATH symlink inode, rejected it at the safe opener, rejected a regular file requested as a directory and rejected a directory requested as a regular file. Its installation factory still contains the earlier process-tree-guard-lab literal. The ordinary-user test did not reach that factory path.
- 004 changes only that installation-root source literal to process-tree-guard. It repeats the same single native test and independent C-header comparison for exact-source continuity. The test passed. Its installation root was not opened, created or qualified by this ordinary-user test.

003 and 004 each report one selected test passed, zero failed, and ten other tests filtered out. Their stderr streams are empty and SSH exit status is zero. 002 records the failing selected test and nonzero exit. These are the complete selected runtime outcomes for this authority experiment.

The ordinary test opens and reads a private temporary fixture. It exercises actual openat, statx and fstatfs calls, rejects a plain filesystem as cgroup2, rejects ordinary ownership as root authority, rejects a mismatched named inode and symlinks, and observes the early nonroot provision refusal with no created cgroup. Native receipts state payload_runs=0 and cgroup_writes=0.

## ABI scope

Native runtime evidence covers Linux ARM64 only. Local Windows x86-64 GNU checks compile the real adapter through the saved Unix standard-library type stand-ins and provide type evidence only. The source uses explicit ARM64 and x86-64 flag definitions and compile refusal for other architectures. Fixed-width Linux v5.14 statx, statfs and clone3 layouts have compile-time size and offset assertions. Linux 5.14 runtime compatibility has not been tested.

The native C receipt and Rust receipt both select O_DIRECTORY=16384, O_NOFOLLOW=32768, O_PATH=2097152, O_CLOEXEC=524288, O_NONBLOCK=2048 and O_WRONLY=1 on ARM64. O_PATH with O_NOFOLLOW may return the symlink itself, so the safe helper checks the held descriptor type.

[ARM64 Linux v5.14 open flags](https://github.com/torvalds/linux/blob/v5.14/arch/arm64/include/uapi/asm/fcntl.h#L21-L25) · [Generic flags](https://github.com/torvalds/linux/blob/v5.14/include/uapi/asm-generic/fcntl.h#L17-L82) · [statx layout](https://github.com/torvalds/linux/blob/v5.14/include/uapi/linux/stat.h#L94-L126)

## Containment and independent cleanup

The saved native commands use an ordinary-user systemd scope with RuntimeMaxSec=70s, KillMode=control-group, KillSignal=SIGKILL and SendSIGKILL=yes. The Mac-side limactl call has an 85-second gtimeout and a three-second kill grace. The Windows launch script requires a separately chosen finite whole-tree Job deadline when invoked. The 004 run used the isolated Windows guard with a 110-second deadline.

Independent Tailscale SSH checks used another ordinary-user scope with a 15-second limit inside a 30-second Mac-side limit and a 45-second Windows Job deadline. The first check found exact scratch paths /tmp/ptg-authority-linux-002.XouDSxz0 and /tmp/ptg-authority-linux-003.mYRH3CP0 absent, their exact cgroup scopes absent, and no fixture executable at those paths. The second check repeated both checks and included /tmp/ptg-authority-linux-004.joadISOj and ptg-authority-linux-004.scope. All three scratch paths, scopes and exact fixture workers were absent. Cleanup commands, stdout, stderr and exit codes are retained.

## Qualification that remains open

The implemented factory self-opens a fixed administrative root and exclusively creates a random fresh leaf. It checks cgroup2 filesystem identity, root ownership, non-user-write modes, directory/name/mount/inode binding, domain type, empty subtree controls, empty events and independent kill controls. The private provenance token is revalidated by the activation seam. Positive root-owned provisioning and installation-root provenance remain unqualified. The trusted one-shot root launcher must originate outside caller-controlled user and mount namespaces.

The next production integration must retain or settle CreatedLeaf on every arm error, enforce ownership of PendingSettlement through terminal cleanup, and connect these checked controls to the real clone3 and one-shot watchdog path. The existing must_use marker alone cannot enforce cleanup. The native port must preserve the original owner pidfd, absolute timer, verified credential values and owned argv. It must close privileged descriptors before payload execution, preserve exec-error and normal-exit behavior, and prove cgroup drain and exact reaping through every failure path.

Earlier archived ARM64 Rust lifecycle prototypes also used the old generic/x86 no-follow and directory flag values. Their raw controlled-path lifecycle outcomes remain preserved, but they do not establish the intended no-follow or directory-open properties. Reuse must carry the corrected flag and descriptor-type checks.

Safe activation policy, environment and stdio semantics, kernel-floor runtime checks, concurrent lifecycle qualification and the shared behavior/escape acceptance tests remain open. This archive qualifies the stated read-only denial boundary only.

## Reproducing the selected checks

Every source directory contains its exact native command and launcher where a native run occurred. The input tarballs preserve the deployed module tree. The selected native test name is

cross_peer::release_lease::prepared_run::native_activation::cgroup_authority::native_read_only::ordinary_readonly_denials

The command compiles transport.rs with rustc --edition=2021 -D warnings --test -C linker=/usr/bin/gcc, creates an owner-only temporary fixture with distinct private control-a and control-b files and control-link symlink, and supplies PTG_AUTHORITY_FIXTURE only for that invocation. It uses --exact --nocapture --test-threads=1.

Local metadata commands are

rustc --edition=2021 -D warnings --emit=metadata transport-metadata-only.rs -o authority.rmeta

rustc --edition=2021 -D warnings --test --emit=metadata transport-metadata-only.rs -o authority-test.rmeta

rustfmt --edition 2021 --check native_activation.rs

Use a finite whole-process-tree deadline for each replay. The INDEX.json contains hashes and byte lengths for every other archive member. ZIP container timestamps do not represent experimental timing.
