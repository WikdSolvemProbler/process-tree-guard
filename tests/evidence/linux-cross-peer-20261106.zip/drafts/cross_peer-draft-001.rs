// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

use super::*;
use std::io::{Read, Write};
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{FileTypeExt, MetadataExt};
use std::os::unix::net::UnixStream;
use std::path::{Path, PathBuf};
use std::process::ExitCode;
use std::time::{Duration, Instant};

const WNOHANG: c_int = 1;
const SIGKILL: c_int = 9;
const SYS_PIDFD_SEND_SIGNAL: c_long = 424;
const CLIENT_EXIT: c_int = 23;
const FAIL_EXIT: c_int = 90;
const LANE_BOUND: Duration = Duration::from_secs(3);
const CLEANUP_BOUND: Duration = Duration::from_secs(1);

type Probe<T> = std::result::Result<T, String>;

#[repr(C)]
struct Address {
    family: u16,
    path: [u8; 108],
}

unsafe extern "C" {
    fn socket(domain: c_int, kind: c_int, protocol: c_int) -> c_int;
    fn bind(fd: c_int, addr: *const Address, len: u32) -> c_int;
    fn connect(fd: c_int, addr: *const Address, len: u32) -> c_int;
    fn listen(fd: c_int, backlog: c_int) -> c_int;
    fn accept4(fd: c_int, addr: *mut c_void, len: *mut u32, flags: c_int) -> c_int;
    fn fork() -> c_int;
    fn _exit(status: c_int) -> !;
    fn close(fd: c_int) -> c_int;
    fn waitpid(pid: c_int, status: *mut c_int, options: c_int) -> c_int;
    fn getpgrp() -> c_int;
    fn getpgid(pid: c_int) -> c_int;
}

fn native<T>(result: super::Result<T>) -> Probe<T> {
    result.map_err(|error| format!("{error:?}"))
}

fn io_result<T>(result: io::Result<T>) -> Probe<T> {
    result.map_err(|error| error.to_string())
}

fn check(condition: bool, message: &str) -> Probe<()> {
    if !condition {
        return Err(message.into());
    }
    Ok(())
}

fn fd_from_call(value: c_int) -> Probe<OwnedFd> {
    let fd = native(os_result(value as isize))? as RawFd;
    // The successful socket or accept syscall returns a newly owned fd.
    Ok(unsafe { OwnedFd::from_raw_fd(fd) })
}

fn addr(path: &Path) -> Probe<(Address, u32)> {
    let raw = path.as_os_str().as_bytes();
    let mut value = Address { family: AF_UNIX as u16, path: [0; 108] };
    check(raw.len() < value.path.len() && !raw.contains(&0), "invalid socket path")?;
    value.path[..raw.len()].copy_from_slice(raw);
    Ok((value, (size_of::<u16>() + raw.len() + 1) as u32))
}

fn make_socket() -> Probe<OwnedFd> {
    let fd = fd_from_call(unsafe { socket(AF_UNIX, SOCK_SEQPACKET | SOCK_NONBLOCK | SOCK_CLOEXEC, 0) })?;
    native(close_on_exec(fd.as_raw_fd()))?;
    Ok(fd)
}

fn connect_client(path: &Path) -> Probe<OwnedFd> {
    let fd = make_socket()?;
    let (address, len) = addr(path)?;
    native(os_result(unsafe { connect(fd.as_raw_fd(), &address, len) } as isize))?;
    Ok(fd)
}

struct Rendezvous {
    fd: OwnedFd,
    path: PathBuf,
    identity: (u64, u64),
}

impl Rendezvous {
    fn create(scratch: &Path, uid: u32) -> Probe<Self> {
        check(scratch.is_absolute() && io_result(scratch.canonicalize())? == scratch,
              "scratch must be an absolute canonical directory")?;
        let dir = io_result(fs::symlink_metadata(scratch))?;
        check(dir.is_dir() && dir.uid() == uid && dir.mode() & 0o777 == 0o700,
              "scratch is not an owned 0700 directory")?;
        let path = scratch.join("cross-peer.sock");
        let (address, len) = addr(&path)?;
        let fd = make_socket()?;
        native(os_result(unsafe {
            setsockopt(fd.as_raw_fd(), SOL_SOCKET, SO_PASSCRED, &1, size_of::<c_int>() as u32)
        } as isize))?;
        // bind refuses an existing path. The outer scope has its own exact scratch cleanup.
        native(os_result(unsafe { bind(fd.as_raw_fd(), &address, len) } as isize))?;
        let file = io_result(fs::symlink_metadata(&path))?;
        check(file.file_type().is_socket() && file.uid() == uid && file.mode() & 0o077 == 0,
              "socket path is not owner-only")?;
        native(os_result(unsafe { listen(fd.as_raw_fd(), 1) } as isize))?;
        Ok(Self { fd, path, identity: (file.dev(), file.ino()) })
    }

    fn accept(&self, until: Instant) -> Probe<OwnedFd> {
        wait_fd(self.fd.as_raw_fd(), POLLIN, until)?;
        let fd = fd_from_call(unsafe {
            accept4(self.fd.as_raw_fd(), ptr::null_mut(), ptr::null_mut(), SOCK_NONBLOCK | SOCK_CLOEXEC)
        })?;
        native(close_on_exec(fd.as_raw_fd()))?;
        let mut passcred: c_int = 0;
        let expected = size_of::<c_int>() as u32;
        let mut len = expected;
        native(os_result(unsafe {
            getsockopt(fd.as_raw_fd(), SOL_SOCKET, SO_PASSCRED,
                       (&mut passcred as *mut c_int).cast(), &mut len)
        } as isize))?;
        check(len == expected && passcred == 1, "accepted endpoint did not inherit SO_PASSCRED")?;
        Ok(fd)
    }

    fn remove(self) -> Probe<()> {
        let Self { fd, path, identity } = self;
        drop(fd);
        let file = io_result(fs::symlink_metadata(&path))?;
        check(file.file_type().is_socket() && (file.dev(), file.ino()) == identity,
              "socket node identity changed")?;
        io_result(fs::remove_file(&path))?;
        check(matches!(fs::symlink_metadata(&path), Err(error) if error.kind() == io::ErrorKind::NotFound),
              "socket node remained after unlink")
    }
}

fn wait_fd(fd: RawFd, events: c_short, until: Instant) -> Probe<c_short> {
    loop {
        let remaining = until.checked_duration_since(Instant::now())
            .ok_or("descriptor deadline expired")?;
        let timeout = remaining.as_millis().max(1) as c_int;
        let mut watched = PollFd { fd, events, revents: 0 };
        let count = unsafe { poll(&mut watched, 1, timeout) };
        if count < 0 && io::Error::last_os_error().kind() == io::ErrorKind::Interrupted {
            continue;
        }
        native(os_result(count as isize))?;
        if count == 0 {
            continue;
        }
        check(Instant::now() <= until, "descriptor event crossed deadline")?;
        check(watched.revents & events != 0, "unexpected descriptor event")?;
        return Ok(watched.revents);
    }
}

fn gate_read(gate: &mut UnixStream, wanted: u8, until: Instant) -> Probe<()> {
    wait_fd(gate.as_raw_fd(), POLLIN, until)?;
    let mut byte = [0];
    io_result(gate.read_exact(&mut byte))?;
    check(byte[0] == wanted, "unexpected gate token")
}

fn gate_write(gate: &mut UnixStream, byte: u8) -> Probe<()> {
    io_result(gate.write_all(&[byte]))
}

fn descriptor_count() -> Probe<usize> {
    Ok(io_result(io_result(fs::read_dir("/proc/self/fd"))?.collect::<io::Result<Vec<_>>>())?.len())
}

fn ordinary_credentials() -> Probe<Credentials> {
    let uid = unsafe { getuid() };
    let gid = unsafe { getgid() };
    check(uid != 0 && gid != 0 && unsafe { geteuid() } == uid && unsafe { getegid() } == gid,
          "ordinary matching real and effective IDs required")?;
    Ok(Credentials { pid: std::process::id() as c_int, uid, gid })
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Lane {
    Live,
    WrongPidfd,
    DeadQueued,
    InheritedEndpoint,
}

fn client(
    lane: Lane, path: &Path, inherited: Option<OwnedFd>, parent_pidfd: RawFd,
    mut gate: UnixStream, until: Instant,
) -> Probe<()> {
    gate_read(&mut gate, b'G', until)?;
    let connection = match inherited {
        Some(fd) => fd,
        None => connect_client(path)?,
    };
    let me = ordinary_credentials()?;
    let own_pidfd = native(pidfd_for(me.pid))?;
    let source = if lane == Lane::WrongPidfd { parent_pidfd } else { own_pidfd.as_raw_fd() };
    let frame = request::encode(2.25, &[b"/never-executed", b"", b"\xff with spaces"])
        .map_err(|error| format!("{error:?}"))?;
    native(send_packet(connection.as_raw_fd(), &frame, &[source]))?;
    if lane != Lane::DeadQueued {
        gate_read(&mut gate, b'Q', until)?;
    }
    Ok(())
}

fn reap_child(pid: c_int, until: Instant) -> Probe<c_int> {
    loop {
        check(Instant::now() < until, "direct child reap deadline expired")?;
        let mut status = 0;
        let result = unsafe { waitpid(pid, &mut status, WNOHANG) };
        if result == pid {
            return Ok(status);
        }
        if result < 0 && io::Error::last_os_error().kind() == io::ErrorKind::Interrupted {
            continue;
        }
        native(os_result(result as isize))?;
        check(result == 0, "unexpected waitpid result")?;
        std::thread::sleep(Duration::from_millis(1));
    }
}

fn settle_failed_child(pid: c_int, held: Option<&OwnedFd>) -> Probe<()> {
    let until = Instant::now() + CLEANUP_BOUND;
    if let Some(held) = held {
        // This handle was obtained for the still-gated direct child.
        let result = unsafe {
            syscall(SYS_PIDFD_SEND_SIGNAL, held.as_raw_fd(), SIGKILL, ptr::null::<c_void>(), 0 as c_int)
        };
        if result < 0 && io::Error::last_os_error().raw_os_error() != Some(3) {
            return Err(format!("direct child cleanup signal: {}", io::Error::last_os_error()));
        }
    }
    reap_child(pid, until)?;
    Ok(())
}

fn assert_plan(admitted: &Admitted, child: Credentials) -> Probe<()> {
    let arguments = admitted.plan.arguments();
    check(
        admitted.peer == child
            && admitted.plan.duration() == Duration::from_millis(2250)
            && admitted.plan.program().to_bytes() == b"/never-executed"
            && arguments.len() == 3
            && arguments[1].to_bytes().is_empty()
            && arguments[2].to_bytes() == b"\xff with spaces"
            && admitted.plan.argv().last().is_some_and(|pointer| pointer.is_null()),
        "admitted plan bytes differ",
    )
}

fn evaluate(
    lane: Lane, outcome: super::Result<Admitted>, receipt: &NativeReceipt,
    parent: Credentials, child: Credentials,
) -> Probe<Option<OwnedFd>> {
    let connected = if lane == Lane::InheritedEndpoint { parent } else { child };
    check(receipt.peer == Some(connected) && receipt.sender == Some(child) && receipt.rights == 1,
          "native connection and message identities do not match the intended lane")?;
    match (lane, outcome) {
        (Lane::Live, Ok(admitted)) => {
            check(receipt.pidfd_cloexec && receipt.pidfd_pid == Some(child.pid)
                    && receipt.pidfd_revents == Some(0), "live transferred pidfd receipt differs")?;
            assert_plan(&admitted, child)?;
            Ok(Some(admitted.owner))
        }
        (Lane::WrongPidfd, Err(Refusal::WrongPidfd)) => {
            check(receipt.pidfd_cloexec && receipt.pidfd_pid == Some(parent.pid)
                    && receipt.pidfd_revents.is_none(), "wrong transferred pidfd receipt differs")?;
            Ok(None)
        }
        (Lane::DeadQueued, Err(Refusal::DeadPidfd)) => {
            check(receipt.pidfd_cloexec && receipt.pidfd_pid == Some(child.pid)
                    && receipt.pidfd_revents.is_some_and(|events| events & POLLIN != 0),
                  "queued dead transferred pidfd receipt differs")?;
            Ok(None)
        }
        (Lane::InheritedEndpoint, Err(Refusal::PeerCredentials)) => {
            check(receipt.pidfd_pid.is_none() && receipt.pidfd_revents.is_none(),
                  "stale endpoint reached pidfd validation")?;
            Ok(None)
        }
        (_, unexpected) => Err(format!("{lane:?} unexpected disposition: {unexpected:?}")),
    }
}

fn run_lane(
    listener: &Rendezvous, lane: Lane, parent: Credentials, parent_pidfd: &OwnedFd,
    parent_group: c_int, parent_scope: &str,
) -> Probe<()> {
    let before = descriptor_count()?;
    let until = Instant::now() + LANE_BOUND;
    let (mut parent_gate, child_gate) = io_result(UnixStream::pair())?;
    for gate in [&parent_gate, &child_gate] {
        io_result(gate.set_nonblocking(true))?;
        native(close_on_exec(gate.as_raw_fd()))?;
    }
    let inherited = if lane == Lane::InheritedEndpoint {
        Some(connect_client(&listener.path)?)
    } else {
        None
    };
    // The standalone entry point checked there is one thread before any fork.
    let pid = unsafe { fork() };
    native(os_result(pid as isize))?;
    if pid == 0 {
        drop(parent_gate);
        // The child will exit directly, so this inherited Rust owner is never dropped twice.
        if unsafe { close(listener.fd.as_raw_fd()) } != 0 {
            unsafe { _exit(FAIL_EXIT) };
        }
        match client(lane, &listener.path, inherited, parent_pidfd.as_raw_fd(), child_gate, until) {
            Ok(()) => unsafe { _exit(CLIENT_EXIT) },
            Err(error) => {
                eprintln!("client {lane:?}: {error}");
                unsafe { _exit(FAIL_EXIT) };
            }
        }
    }
    drop((child_gate, inherited));
    let child = Credentials { pid, ..parent };
    let mut held = None;
    let mut reaped = false;
    let verdict = (|| {
        held = Some(native(pidfd_for(pid))?);
        let owner = held.as_ref().expect("direct child held").as_raw_fd();
        native(validate_pidfd(held.as_ref().expect("direct child held"),
                              child, &mut NativeReceipt::default()))?;
        check(unsafe { getpgid(pid) } == parent_group
                && io_result(fs::read_to_string(format!("/proc/{pid}/cgroup")))? == parent_scope,
              "direct child did not remain in the controller group and scope")?;
        gate_write(&mut parent_gate, b'G')?;
        let connection = listener.accept(until)?;
        let connection = connection.as_raw_fd();
        wait_fd(connection, POLLIN, until)?;
        if lane == Lane::DeadQueued {
            // Keep the child unreaped so fdinfo still names the original PID.
            wait_fd(owner, POLLIN, until)?;
        }
        let mut receipt = NativeReceipt::default();
        let outcome = receive_observed(connection, &mut receipt);
        let result = format!("{outcome:?}");
        let received_owner = evaluate(lane, outcome, &receipt, parent, child)?;
        if lane != Lane::DeadQueued {
            gate_write(&mut parent_gate, b'Q')?;
        }
        let owner_exit = wait_fd(owner, POLLIN, until)?;
        let received_exit = received_owner.as_ref().map(|fd| wait_fd(fd.as_raw_fd(), POLLIN, until))
            .transpose()?;
        let status = reap_child(pid, until)?;
        reaped = true;
        check(status == CLIENT_EXIT << 8, "direct client did not exit 23 naturally")?;
        let mut eof = NativeReceipt::default();
        check(matches!(receive_observed(connection, &mut eof), Err(Refusal::EmptyPacket))
                && eof.rights == 0, "native EOF after child exit differs")?;
        println!("lane={lane:?} child={pid} group={parent_group} native={receipt:?} owner_exit={owner_exit:#x} received_exit={received_exit:?} exit=23 eof=verified result={result}");
        Ok(())
    })();
    drop(parent_gate);
    if !reaped {
        if let Err(error) = settle_failed_child(pid, held.as_ref()) {
            return Err(format!("lane={lane:?} disposition={verdict:?} cleanup={error}"));
        }
    }
    drop(held);
    verdict?;
    check(descriptor_count()? == before, "parent descriptor baseline changed")?;
    println!("lane={lane:?} descriptors=settled");
    Ok(())
}

fn run() -> Probe<()> {
    let args: Vec<_> = std::env::args_os().collect();
    check(args.len() == 2, "supply the exact private scratch path")?;
    check(io_result(io_result(fs::read_dir("/proc/self/task"))?.collect::<io::Result<Vec<_>>>())?.len() == 1,
          "controller must be single threaded before fork")?;
    let parent = ordinary_credentials()?;
    let group = unsafe { getpgrp() };
    let scope = io_result(fs::read_to_string("/proc/self/cgroup"))?;
    let before = descriptor_count()?;
    let parent_pidfd = native(pidfd_for(parent.pid))?;
    native(close_on_exec(parent_pidfd.as_raw_fd()))?;
    let listener = Rendezvous::create(Path::new(&args[1]), parent.uid)?;
    let verdict = (|| {
        for lane in [Lane::Live, Lane::WrongPidfd, Lane::DeadQueued, Lane::InheritedEndpoint] {
            run_lane(&listener, lane, parent, &parent_pidfd, group, &scope)?;
        }
        Ok(())
    })();
    let cleanup = listener.remove();
    drop(parent_pidfd);
    verdict.and(cleanup)?;
    check(descriptor_count()? == before, "final parent descriptor baseline changed")?;
    println!("cross_peer=passed lanes=4 listener=unlinked descriptors=settled");
    Ok(())
}

pub(super) fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("cross_peer=failed {error}");
            ExitCode::FAILURE
        }
    }
}
