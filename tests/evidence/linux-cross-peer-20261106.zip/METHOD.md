# Linux cross-process request admission qualification

The standalone fixture exercises the published PTGEX2 transport with a distinct ordinary-user sender. A controller creates one owner-only pathname SOCK_SEQPACKET listener inside its fresh canonical 0700 scratch directory. It sets SO_PASSCRED before listen and verifies the option on every accepted descriptor. Each lane forks exactly one direct child from the single-threaded controller. A private gate holds the child while the controller acquires its pidfd and confirms matching process group and scope membership. The socket sender supplies only SCM_RIGHTS. Linux supplies the separate packet credentials.

Linux takes the accepted endpoint's peer identity from the connecting process. A client socket inherited across fork therefore keeps the original connection identity while a subsequent packet carries the sender's actual credentials. The accepted descriptor inherits SO_PASSCRED from the listener. [Linux connection credentials](https://github.com/torvalds/linux/blob/v6.8/net/unix/af_unix.c#L1509-L1515) · [Linux accept flags](https://github.com/torvalds/linux/blob/v6.8/net/unix/af_unix.c#L1592-L1642) · [Linux packet credentials](https://github.com/torvalds/linux/blob/v6.8/net/unix/af_unix.c#L1743-L1765)

| Lane | Socket peer | Packet sender | Passed pidfd | Required disposition |
| --- | --- | --- | --- | --- |
| Live | Child | Child | Live child | Admit the exact duration and argument bytes, with an empty argument and final null pointer |
| WrongPidfd | Child | Child | Live controller | Refuse WrongPidfd after recording the controller's PID from the transferred fd |
| DeadQueued | Child | Child | Exited child | Refuse DeadPidfd on a queued valid packet after the trusted child pidfd signaled, before reaping |
| InheritedEndpoint | Controller | Child | Child | Refuse PeerCredentials after recording both native credential records, before pidfd validation |

Each lane requires its original child to exit naturally with status 23 and be reaped exactly, followed by native EOF with zero received descriptors. The live lane observes the same accepted owner pidfd signaling after the child exits. The parent verifies descriptor counts after every lane. At the end it unlinks the original socket node by checked device and inode and verifies the final descriptor count.

Each lane shares a three-second monotonic observation budget. The gate and rendezvous sockets are nonblocking and pidfd waits are finite. On a failed lane the controller closes its gate, sends SIGKILL only through the held direct-child pidfd if available, and attempts reaping within one additional second. The authorized external scope separately bounds the controller and descendants. The ordinary account, filesystem node, process group and scope all remain local to the test. Execution scope covers the controller and its direct test children. The command strings are decoded into a plan for inspection.

The queued-dead lane waits for the independently held pidfd before reading the packet and defers reaping. This lets the received pidfd retain the original PID in fdinfo while reporting process exit through poll. [Linux pidfd identity and polling](https://github.com/torvalds/linux/blob/v6.8/kernel/fork.c#L1923-L1968)

The derivative keeps the prior receiver and request decoder. Its changes expose native credential and pidfd receipts, make the existing getsockopt declaration accept both socket option types, and condition the anonymous-socket helpers on the old test mode. The standalone controller resides separately in cross_peer.rs. Both exact drafts are preserved in scratch. The local Windows check compiled metadata for derivatives with Unix descriptor and filesystem traits replaced by placeholders. Native GNU Linux execution supplies the runtime result.

For a native run, preserve the following repository-relative paths and run within the approved finite ordinary-user scope. The directory supplied as the sole argument must be the already-created private scratch directory.

```text
rustc --edition=2021 -D warnings -C linker=/usr/bin/gcc target/codex-security/issue2-linux-cross-peer-001/transport.rs -o cross-peer
umask 077
./cross-peer "$tree"
```

| Input | SHA-256 |
| --- | --- |
| target/codex-security/issue2-linux-cross-peer-001/transport.rs | 907472caaa18f3e4a288f323c8969d85b5b0e494bcfad2cbf65357d24185fee9 |
| target/codex-security/issue2-linux-cross-peer-001/cross_peer.rs | 5834aac242a510dcb6bea3c67089efef10cb0afb17592a7df93e0745cef2cbad |
| target/codex-security/issue2-linux-generic-request-001/request.rs | 6531478a6cb85c31ba4639c01c144c789968178df57b64d3d128073a8d91b4c4 |
| src/deadline.rs | 56252eb28270b4743d73e17e05ae933d3fad8168e7b4ba34405e859be9c85c53 |

This qualifies the private ordinary-user transport with sequential same-UID clients. Production launch authorization, activation, owner lifetime through release, payload containment, kernel-floor and concurrent lifecycle qualification remain separate.
