#!/usr/bin/env python3
"""Regenerate ~/workspace/pgl-gauntlet/dependency-graph.md from the tree.

Mechanical, no hand edits: every row is a file on disk with its line
count; edges are (a) `mod` declarations (parent -> child) and (b) textual
`crate::<top-module>` references in the file. The `sys` coupling is
counted as well as named: a production file that reaches the Windows
declarations only through its parent's glob import names no `crate::sys`
in its own text, so each production file also carries its direct-sys-call
census — the count of call sites of the functions declared in the
production `extern` blocks of `src/sys.rs`, matched by name
(`\\bNAME\\s*\\(`) over the file's production text. Production text is
the file with its `#[cfg(test)]` items and modules removed (see
strip_cfg_test below): one production definition for the whole gate
suite, the same one the design gate's production-line counter applies.
A file whose only `mod` declaration in its parent chain is
`#[cfg(test)]`-gated is not a production file at all (seam round 4,
protest P3): the production definition sees the parents'
declarations, not only each file's own text (see is_production
below), so `src/auth/seam.rs` — declared only under `#[cfg(test)]`
in `src/auth.rs` — is test code, outside this census entirely.
The declarations are resolved to their ACTUAL target files (seam
round 5, protest P6): a `#[path = "..."]` attribute on a
declaration (or on an enclosing inline module) is honoured — its
presence is read on the blanked text and its target from the raw
text at the same offset, the blanker having erased the string's
contents there — so a file with any ungated declaration, by
whatever path, is production, and a file is test-gated only when
every declaration that resolves to it is gated. File-module
children declared inside an inline module resolve under that
inline module's directory, and a `src/bin/*.rs` crate root
resolves its file modules beside the root, as `src/main.rs`
does (seam round 5, W4's base rules).
Re-run after any seam move; tools/design-gate.sh (D4) fails while the
recorded graph is stale.

The pinned pure set at the end is computed, never written by hand.
A production file is pure when its production code carries no sys
reference of any kind, judged on its code text (see code_text below:
comments and the contents of string and character literals are
blanked first, so a name mentioned in prose — a doc comment that
mentions `wide()`, say — is not a reference, and a name inside a
literal is not code):

  - no `sys::` path and no `crate::sys` import;
  - no whole-word naming of any name `sys` declares — the extended
    mint extracted mechanically below: the `extern` names, every
    `pub type`, `pub const`, `pub struct` and `pub enum`, the owned
    wrapper functions defined in `src/sys.rs` itself, and the
    `sys/rng.rs` re-export — outside the recorded exclusions in
    EXCLUSIONS. The exclusions are judged by occurrence, not by
    word (seam round 3, protests P3/P4): `slot` in a call shape
    (`slot::<`, `slot(`) is sys's v-table accessor and is never
    exempt in any file, and a bare `Bool` (not the `Json::Bool`
    path) outside its enum home in `src/hook/json.rs` is sys's
    alias and is never exempt; the occurrences that ARE exempt
    are pinned per file in design gate D43, and any new
    occurrence there fails until argued;
  - no use of a wrapper that itself reaches `sys` — the
    transitive half of the criterion, one hop, uniform over
    homes, spellings, and function/method kind (seam round 3,
    protests P1/P2; completed by seam round 4, protests
    P1/P2/P4). The wrappers are derived, not listed: every
    production function and method defined anywhere in the crate
    whose own production body reaches `sys` — it names a `sys::`
    path, OR it calls a declared extern name unqualified (the
    direct census applied per body), OR it names an
    extended-mint item, OR — judged by occurrence, as the
    exclusions are — its item text (signature and body) carries
    a `slot` call shape or a bare `Bool`. A free wrapper is used
    where its name is called or named as a value (not at its
    own definition, not in a `use` statement — a re-export is
    not a home and not a call — and not where the file itself
    defines or `let`-binds that name, where the name is the
    file's own); a method wrapper is used where it is called by
    its defining type's associated path (`Process::open`), or
    by a receiver call `.name(` whose receiver's type is
    determinable from declared types, resolved to a fixed point
    (seam round 5, protest P1): a function parameter typed
    `Type`/`&Type`/`&mut Type`, a `Self` receiver inside
    `impl Type`, or a binding annotated with the type — a
    pattern binding destructuring a determinable declared
    type binds each variable with its position's declared
    type — as
    before; a field receiver, through the field's declared
    type in its defining struct; a chained receiver, through
    the inner callee's declared return type; and an unannotated
    binding initialised by such a call or field access, which
    takes the callee's declared return type — multi-hop fields
    and chains fall out of the iteration — when `(Type, name)`
    is a derived method wrapper. A type that carries any
    derived wrapper method (constructors and `Drop` included)
    is itself a wrapper type, and the set is closed two ways
    more (seam round 5, protests P2/P3): under by-value field
    containment — a type with a field whose type is a wrapper
    type, transitively through other containers, is itself a
    wrapper type (reference and pointer fields do not contain,
    and neither do payloads of the non-dropping heads
    ManuallyDrop, MaybeUninit and PhantomData)
    — and under production type aliases — an alias in whose
    target a wrapper type occurs by value anywhere,
    transitively through aliases, is itself a wrapper type,
    with its home recorded as the alias's file.
    A file naming such a type whole-word in production
    code — type position, associated path with any method
    name, or value construction — uses it and is not pure,
    exactly as with a wrapper function; a type the file itself
    defines is its own, and a same-named enum variant path
    (`Method::Console`, naming the variant, not the type) is
    not the type — both exclusions in the recorded-exclusion
    idiom of the gate, and both computed under Rust's own scoping (seam round 6, protest P5): a definition exempts a use only where Rust makes it the name's meaning — in the use's own scope (function bodies are scopes), imported into it from an ancestor module, or brought in by the file's own `use` of an item from a descendant or sibling scope,
    for the defined types and the defined names alike. A
    pinned file's by-value generic parameter that the file
    owns to a scope exit is also a wrapper use when any
    production instantiation of that item — supply computed
    to a fixed point through generic-to-generic hops —
    supplies a wrapper type, computed at the call sites with
    the same determinable-type machinery (seam round 5,
    protest P5, arm (a)). A file that uses a wrapper reaches
    `sys` through it and is not pure, exactly as a file that
    names `sys` itself is not. One hop only: calling a caller
    of a wrapper is not itself a reach. The recorded limit of
    the computation, stated here as in `src/lib.rs` and in the
    graph: a receiver call whose receiver's type arrives
    through a generic parameter, a trait object, or an
    expression with no declared type in the crate is not
    counted as a wrapper use; and a bare name with more than
    one production definition is not determinable either —
    the recorded limit's fourth member.
    Seam round 7 completes the computation
    once more (protests P1\u2013P4, P6, P7): use statements also yield
    per-scope rename maps, and every arm resolves a spelled local
    name through its scope's map before lookup; const and static
    items whose initialiser is a wrapper path are wrapper VALUES,
    and naming one is a wrapper use; production `include!` is
    refused by name — included text stands in no file list this
    computation walks; receiver resolution takes a Deref step
    (in-tree `impl Deref`/`DerefMut` targets computed from the
    tree, the std smart-pointer heads recorded as rules beside
    the non-dropping heads) and binds `for` loop variables and
    closure parameters from the declared types that bind them;
    the std-platform channel (`std::os::<platform>` paths) is
    censused per file, and inside the pure set it stands only as
    the one pinned occurrence (environment.rs's
    `std::os::windows::ffi::OsStrExt`, for the file's UTF-16
    encoding logic); and name supply is textual and local to
    each file — the `crate::sys::*` glob roots are gone, every
    production file imports the sys names it uses from
    `crate::sys` explicitly in its own text, and D43 ties each
    file's import list to the set of sys names this census
    records for it, so the compiler and the census check each
    other.
    Seam round 11 completes the computation once more (protests
    P1-P10): the yield derivation runs over methods, blanket-impl
    trait defaults are keyed by their trait, struct-field carriage
    and returned closures yield, both value closures follow calls
    in initialiser position, the module map gains inline modules
    with binding reads scoped to the declaring module, the macro
    census reads sys's own definitions, re-export bindings are
    derivation sources, and a module declaration whose target
    file is absent from the tree is refused by name.
"""
import json, pathlib, posixpath, re, sys

# --- SSOT manifest (Phase 5 design \S3.6; E0.5 mode M) -------------------
# This reader's one bootstrap literal: the manifest beside this file,
# resolved against this file's own location. Every other home this
# reader judges by is named as a key in that manifest; reader code
# names keys, never paths. Reader duties (\S3.6): an unknown
# meta.schema, a missing key, and a keyed home that does not exist
# each fail by name, before any census work runs.
_LAYOUT_PATH = pathlib.Path(__file__).with_name("layout.json")
_LAYOUT_KEYS = (
    "meta.schema", "meta.comment",
    "tree.root", "tree.src", "tree.lib", "tree.cargo", "tree.tests",
    "tree.sys_root", "tree.sys_prefix", "tree.sys_declaration",
    "tree.sys_rng", "tree.cli", "tree.hook_core", "tree.integrations_root",
    "tree.antigravity_test", "tree.testkit", "tree.extend",
    "pins.pure_set", "pins.import_files", "pins.std_platform_file",
    "pins.bool_home", "pins.extern_homes",
    "gate.disposition_files", "gate.ceiling_files", "gate.cap_scan_set",
    "tools.root", "tools.generator", "tools.gate",
    "graph.output", "suite.home", "suite.campaign_config",
)
_LAYOUT_USED_HOMES = (
    "tree.root", "tree.src", "tree.lib", "tree.sys_declaration",
    "tree.sys_prefix", "tree.sys_rng", "tree.testkit",
    "pins.pure_set", "pins.import_files", "pins.std_platform_file",
    "pins.bool_home", "tools.generator", "tools.gate", "graph.output",
)

def _layout_fail(message):
    sys.exit("layout.json: " + message)

def _layout_get(data, dotted):
    cur = data
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            _layout_fail(f"missing key: {dotted}")
        cur = cur[part]
    return cur

def _load_layout():
    try:
        raw = _LAYOUT_PATH.read_text()
    except OSError:
        _layout_fail(f"manifest file missing: {_LAYOUT_PATH} (no layout.json beside the generator; key meta.schema is unreadable)")
    try:
        data = json.loads(raw)
    except ValueError as exc:
        _layout_fail(f"manifest file is not valid JSON: {_LAYOUT_PATH}: {exc}")
    if not isinstance(data, dict):
        _layout_fail("manifest root is not an object (key: meta.schema unreadable)")
    schema = _layout_get(data, "meta.schema")
    if schema != "ptg-layout/1":
        _layout_fail(f"unknown meta.schema: {schema!r} (this reader knows 'ptg-layout/1' only)")
    for dotted in _LAYOUT_KEYS:
        value = _layout_get(data, dotted)
        if dotted.startswith("meta."):
            if not isinstance(value, str):
                _layout_fail(f"key {dotted} is not a string")
        elif dotted in ("pins.extern_homes", "gate.cap_scan_set"):
            if not (isinstance(value, list) and all(isinstance(v, str) for v in value)):
                _layout_fail(f"key {dotted} is not an array of key-name strings")
            for name in value:
                _layout_get(data, name)
        elif isinstance(value, list):
            if not all(isinstance(v, str) for v in value):
                _layout_fail(f"key {dotted} is not a string or an array of strings")
        elif not isinstance(value, str):
            _layout_fail(f"key {dotted} is not a string or an array of strings")
    return data

_LAYOUT = _load_layout()
_LAYOUT_ANCHOR = _LAYOUT_PATH.parent.parent

def _layout_path(dotted):
    return _layout_get(_LAYOUT, dotted)

def _layout_treerel(dotted):
    # A keyed home as this census names it: relative to tree.root.
    value = _layout_path(dotted)
    root = _layout_path("tree.root")
    if value == root:
        return "."
    prefix = root + "/"
    if value.startswith(prefix):
        return value[len(prefix):]
    _layout_fail(f"key {dotted}: home {value!r} is not under tree.root {root!r}")

def _layout_resolve_keyname(name):
    # A key-name set member (pins.extern_homes) resolved to its home,
    # named relative to tree.root.
    return _layout_treerel(name)

# Optional arguments: argv[1] = workspace root, argv[2] = output path.
# Both are caller-stated overrides only, carrying no default home:
# the workspace defaults to the manifest anchor (the root that
# contains the sibling manifest's tools/ home) and the output to
# the manifest's graph.output home under that workspace, so a plain
# run regenerates in place exactly as before. tools/design-gate.sh
# passes a scratch output path to compare a fresh regeneration
# against the recorded graph without touching it.
WS = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else _LAYOUT_ANCHOR
OUT = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else WS / _layout_path("graph.output")
TREE = WS / _layout_path("tree.root")
SRC = WS / _layout_path("tree.src")

# Keyed homes this reader judges by, resolved once from the manifest.
SYS_DECL_REL = _layout_treerel("tree.sys_declaration")
SYS_PREFIX_REL = _layout_treerel("tree.sys_prefix")
TESTKIT_REL = _layout_treerel("tree.testkit")
LIB_REL = _layout_treerel("tree.lib")
STD_PLATFORM_FILE_REL = _layout_treerel("pins.std_platform_file")
BOOL_HOME_REL = _layout_treerel("pins.bool_home")
PURE_SET = [_layout_treerel_member for _layout_treerel_member in
            [posixpath.relpath(v, _layout_path("tree.root")) for v in _layout_path("pins.pure_set")]]
IMPORT_FILES = {posixpath.relpath(v, _layout_path("tree.root")) for v in _layout_path("pins.import_files")}
DECL_FILE = WS / _layout_path("tree.sys_declaration")
LIB_FILE = WS / _layout_path("tree.lib")
GEN_TOOL_FILE = WS / _layout_path("tools.generator")
GATE_TOOL_FILE = WS / _layout_path("tools.gate")

# Reader duty: a keyed home this reader uses that does not exist
# fails by name, naming the key and the path.
for _dotted in _LAYOUT_USED_HOMES:
    _value = _layout_path(_dotted)
    _values = _value if isinstance(_value, list) else [_value]
    for _home in _values:
        if not (WS / _home).exists():
            _layout_fail(f"key {_dotted}: home does not exist: {_home} (resolved {(WS / _home)})")

# ---------------------------------------------------------------- text forms
# Three forms of a file's text are used, all offset-preserving (every
# blanked character becomes a space, newlines are kept), so a span
# found in one form cuts the same span in another:
#   raw text          — what is on disk;
#   code text         — comments and literal contents blanked: prose
#                       and string text are not code and cannot carry
#                       a reference;
#   production text   — either of the above with every #[cfg(test)]
#                       item or module removed: the tree's own
#                       production definition.

CHAR_LITERAL = re.compile(r"'(?:\\(?:x[0-9a-fA-F]{2}|u\{[0-9a-fA-F]+\}|.)|[^\\'])'")

def blank_comments_and_literals(text):
    out = list(text)
    i, n = 0, len(text)

    def blank(a, b):
        for k in range(a, b):
            if out[k] != "\n":
                out[k] = " "

    while i < n:
        ch = text[i]
        nxt = text[i + 1] if i + 1 < n else ""
        if ch == "/" and nxt == "/":
            j = text.find("\n", i)
            j = n if j < 0 else j
            blank(i, j)
            i = j
        elif ch == "/" and nxt == "*":
            depth, j = 1, i + 2
            while j < n and depth:
                if text[j] == "/" and j + 1 < n and text[j + 1] == "*":
                    depth += 1
                    j += 2
                elif text[j] == "*" and j + 1 < n and text[j + 1] == "/":
                    depth -= 1
                    j += 2
                else:
                    j += 1
            blank(i, j)
            i = j
        elif ch == "r" and (nxt == '"' or nxt == "#") and (i == 0 or not (text[i - 1].isalnum() or text[i - 1] == "_")):
            # A raw string: r"...", r#"..."#. The raw BYTE string
            # (br"...", br#"..."#) is the next branch: its b is part
            # of the token, and the guard above would reject its r
            # (the predecessor b is alphanumeric), leaving the
            # string's opening quote to flip quote parity for the
            # rest of the file (seam round 3, protest P4).
            j = i + 1
            hashes = 0
            while j < n and text[j] == "#":
                hashes += 1
                j += 1
            if j < n and text[j] == '"':
                close = '"' + "#" * hashes
                k = text.find(close, j + 1)
                k = n if k < 0 else k + len(close)
                blank(i, k)
                i = k
            else:
                i += 1
        elif ch == "b" and nxt == "r" and i + 2 < n and text[i + 2] in '"#' and (i == 0 or not (text[i - 1].isalnum() or text[i - 1] == "_")):
            # A raw byte string: br"...", br#"..."# — the optional
            # b prefix is part of the raw-string token.
            j = i + 2
            hashes = 0
            while j < n and text[j] == "#":
                hashes += 1
                j += 1
            if j < n and text[j] == '"':
                close = '"' + "#" * hashes
                k = text.find(close, j + 1)
                k = n if k < 0 else k + len(close)
                blank(i, k)
                i = k
            else:
                i += 1
        elif ch == "c" and nxt == "r" and i + 2 < n and text[i + 2] in '"#' and (i == 0 or not (text[i - 1].isalnum() or text[i - 1] == "_")):
            # A raw C string: cr"...", cr#"..."# — the c prefix is
            # part of the raw-string token. With the r branch and
            # the br branch above, the prefix set recognised here
            # is now the language's whole set of raw-string
            # prefixes (r, br, cr) (seam round 4, protest P5).
            j = i + 2
            hashes = 0
            while j < n and text[j] == "#":
                hashes += 1
                j += 1
            if j < n and text[j] == '"':
                close = '"' + "#" * hashes
                k = text.find(close, j + 1)
                k = n if k < 0 else k + len(close)
                blank(i, k)
                i = k
            else:
                i += 1
        elif ch == "c" and nxt == '"' and (i == 0 or not (text[i - 1].isalnum() or text[i - 1] == "_")):
            # A plain C string: c"..." — an ordinary string whose
            # c prefix is part of the token.
            j = i + 2
            while j < n:
                if text[j] == "\\":
                    j += 2
                elif text[j] == '"':
                    j += 1
                    break
                else:
                    j += 1
            blank(i, min(j, n))
            i = j
        elif ch == '"':
            j = i + 1
            while j < n:
                if text[j] == "\\":
                    j += 2
                elif text[j] == '"':
                    j += 1
                    break
                else:
                    j += 1
            blank(i, min(j, n))
            i = j
        elif ch == "'":
            # A character literal ('x', '\n', '\u{1F600}', b'x' — the b
            # is an identifier character, scanned before) blanks; a
            # lifetime ('a, 'static) does not match this shape and is
            # left alone.
            m = CHAR_LITERAL.match(text, i)
            if m:
                blank(i, m.end())
                i = m.end()
            else:
                i += 1
        else:
            i += 1
    return "".join(out)


def cfg_test_spans(code):
    """The spans of `code` (comment/literal-blanked text) that are
    #[cfg(test)] items or modules: from the attribute through the end
    of the item it gates — a `mod name;` or const/type/use item ends
    at its semicolon, any other item at the closing brace of its
    first brace block, with further attributes between the
    #[cfg(test)] and the item skipped. Brace counting runs on the
    blanked text, so braces in comments and literals cannot move it.
    """
    spans = []
    for m in re.finditer(r"#\[\s*cfg\s*\(\s*test\s*\)\s*\]", code):
        i = m.end()
        # Skip whitespace and any further attributes on the same item.
        while True:
            while i < len(code) and code[i].isspace():
                i += 1
            am = re.match(r"#\[[^\]]*\]", code[i:])
            if am:
                i += am.end()
            else:
                break
        # The item ends at its first top-level semicolon, or at the
        # close of its first brace block, whichever comes first.
        depth = 0
        j = i
        end = None
        while j < len(code):
            c = code[j]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    end = j + 1
                    break
            elif c == ";" and depth == 0:
                end = j + 1
                break
            j += 1
        if end is not None:
            spans.append((m.start(), end))
    return spans


def apply_spans(text, spans):
    if not spans:
        return text
    out = list(text)
    for a, b in spans:
        for k in range(a, b):
            if out[k] != "\n":
                out[k] = " "
    return "".join(out)


RAW_BY_REL35 = {}  # file -> its raw text, for the cfg readings that recover spelled values from the raw span (seam round 35, protests P1/P2)
CODE_BY_REL35 = {}  # file -> its census (code) text, offset-aligned with the raw text above (seam round 35, protests P1/P2/P3)


def _cfg_dead_spans35(code, raw):
    """The spans of census text that do not exist on the
    crate's one denotation target (seam round 35, protests
    P1/P2): every `#[cfg(...)]` attribute in the blanked
    text whose RAW content — recovered from the raw text
    at the same offset, as a `#[path]` target already is —
    evaluates FALSE against the target (target_os =
    "windows"), together with the item, block or statement
    it gates, read with cfg_test_spans' own end rule (the
    gated text ends at its first top-level semicolon or
    at the close of its first brace block, further
    attributes between the cfg and its item skipped).
    Existence is computed here, once, for the whole
    enclosing chain at every position that can carry a
    cfg — fn item, impl block, module, block statement,
    let and struct field alike (seam round 36, protest
    P1: a field's span ends at the field's own comma, so
    a cfg-duplicated field is decided by its cfg truth,
    never by declaration order) — so every arm reads text from which
    non-existent code is already absent, exactly as
    #[cfg(test)] code is already absent from production
    text. A cfg the target facts do not decide removes
    nothing here: it stands in the census text, where
    _cfg_audit35 and the binding arm refuse it BY NAME."""
    if raw is None or len(raw) != len(code):
        return []
    spans = []
    _structs36 = []
    for _sm36 in re.finditer(r"\b(?:struct|enum|union)\s+\w+", code):
        _j36 = _sm36.end()
        while _j36 < len(code) and code[_j36].isspace():
            _j36 += 1
        if _j36 < len(code) and code[_j36] == "<":
            _j36 = _angle_match(code, _j36)
        if _j36 < len(code) and code[_j36] == "(":
            # A tuple struct's body (seam round 37,
            # protest P2): the declaration's parentheses
            # are its fields' body, recorded beside the
            # brace bodies so a tuple field's span is
            # computed from its own cfg chain and its own
            # position, as a named field's is.
            _structs36.append((_j36, _delim_match(code, _j36, "(", ")")))
            continue
        _b36 = code.find("{", _j36)
        _s36 = code.find(";", _j36)
        if _b36 >= 0 and (_s36 < 0 or _b36 < _s36):
            _structs36.append((_b36, _brace_match(code, _b36)))
    for m in re.finditer(r"#\[\s*cfg\s*\(", code):
        open_idx = code.find("(", m.start())
        end = _delim_match(code, open_idx, "(", ")")
        if end < 0 or code[end:end + 1] != "]":
            continue
        if raw[open_idx + 1:end - 1].strip() == "test":
            continue
        if _cfg_eval34(raw[open_idx + 1:end - 1]) is not False:
            continue
        i = end + 1
        while True:
            while i < len(code) and code[i].isspace():
                i += 1
            am = re.match(r"#\[[^\]]*\]", code[i:])
            if am:
                i += am.end()
            else:
                break
        _fld36 = False
        for _o36, _c36 in _structs36:
            if _o36 < m.start() < _c36:
                # The field position at the depth the
                # field actually stands at (seam round
                # 37, protest P1): a named field of an
                # enum variant's struct body stands at
                # brace depth 1 inside the enum's
                # recorded body, a tuple field inside
                # the declaration's recorded parentheses
                # — the field end rule reads both, as it
                # reads a struct field at depth 0.
                _fld36 = True
                break
        if _fld36:
            _pd36 = _bd36 = _kd36 = _ad36 = 0
            _j36 = i
            _e36 = None
            while _j36 < len(code):
                _c236 = code[_j36]
                if _c236 == "-" and code[_j36 + 1:_j36 + 2] == ">":
                    _j36 += 2
                    continue
                if _c236 == "(":
                    _pd36 += 1
                elif _c236 == ")":
                    if _pd36 == 0 and _bd36 == 0 and _kd36 == 0 and _ad36 == 0:
                        # The closing parenthesis of the
                        # tuple body itself (seam round
                        # 37, protest P2): the last
                        # field's span ends before it, so
                        # removing one field never
                        # truncates its neighbour or the
                        # declaration's terminator.
                        _e36 = _j36
                        break
                    _pd36 -= 1
                elif _c236 == "[":
                    _bd36 += 1
                elif _c236 == "]":
                    _bd36 -= 1
                elif _c236 == "<":
                    _ad36 += 1
                elif _c236 == ">":
                    _ad36 -= 1
                elif _c236 == "{":
                    _kd36 += 1
                elif _c236 == "}":
                    if _kd36 == 0 and _pd36 == 0 and _bd36 == 0:
                        _e36 = _j36
                        break
                    _kd36 -= 1
                elif _c236 == "," and _pd36 == 0 and _bd36 == 0 and _kd36 == 0 and _ad36 == 0:
                    _e36 = _j36 + 1
                    break
                _j36 += 1
            if _e36 is not None:
                spans.append((m.start(), _e36))
            continue
        depth = 0
        j = i
        e2 = None
        while j < len(code):
            c = code[j]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    e2 = j + 1
                    break
                if depth < 0:
                    break
            elif c == ";" and depth == 0:
                e2 = j + 1
                break
            j += 1
        if e2 is not None:
            spans.append((m.start(), e2))
    return spans


def _cfg_audit35(code, raw, rel):
    """The refusal by name for a cfg the target facts do
    not decide (seam round 35, protests P1/P2): any
    `#[cfg(...)]` still standing in a file's census text
    whose raw content _cfg_eval34 cannot decide — a false
    one already stands removed by _cfg_dead_spans35 and a
    true one stands decided — refuses BY NAME, naming the
    cfg as spelled and the file, in the CHASE_FAILURES
    idiom, at whatever position it stands (item, block or
    binding alike)."""
    if raw is None or len(raw) != len(code):
        return
    for m in re.finditer(r"#\[\s*cfg\s*\(", code):
        open_idx = code.find("(", m.start())
        end = _delim_match(code, open_idx, "(", ")")
        if end < 0 or code[end:end + 1] != "]":
            continue
        content = raw[open_idx + 1:end - 1]
        if content.strip() == "test":
            continue
        if _cfg_eval34(content) is None:
            _mn36 = None
            if "$" in content:
                _mfn36 = globals().get("_macro_name_at36")
                _mn36 = _mfn36(code, m.start()) if _mfn36 is not None else None
            msg = ("cfg existence undecidable: the cfg `#[cfg(" + re.sub(r"\s+", " ", content.strip()) + ")]` in " + str(rel)
                   + ((" — inside the definition of the macro `" + _mn36 + "`, where the cfg's value arrives by macro substitution and stands decided only at an invocation (seam round 36, protest P7)") if _mn36 else "")
                   + ", whose truth the crate's one denotation target (target_os = \"windows\") does not decide, gates text the census must judge; "
                   + "the computation refuses by name rather than count the gated text as standing (seam round 35, protests P1/P2)")
            if msg not in CHASE_FAILURES:
                CHASE_FAILURES.append(msg)
    # A cfg_attr condition is a cfg value position under
    # another spelling (seam round 37, protest P8): its
    # truth is decided here as every spelled cfg's is,
    # and a condition the target facts do not decide —
    # a metavariable standing in it included — refuses
    # BY NAME, naming the condition, the macro that
    # carries it where one does, and the file.
    for m in re.finditer(r"#\[\s*cfg_attr\s*\(", code):
        open_idx = code.find("(", m.start())
        end = _delim_match(code, open_idx, "(", ")")
        if end < 0 or code[end:end + 1] != "]":
            continue
        _full37 = raw[open_idx + 1:end - 1]
        _d37 = 0
        _cut37 = len(_full37)
        for _i37, _ch37 in enumerate(_full37):
            if _ch37 in "([{":
                _d37 += 1
            elif _ch37 in ")]}":
                _d37 -= 1
            elif _ch37 == "," and _d37 == 0:
                _cut37 = _i37
                break
        content = _full37[:_cut37]
        if _cfg_eval34(content) is None:
            _mn37 = None
            if "$" in content:
                _mfn37 = globals().get("_macro_name_at36")
                _mn37 = _mfn37(code, m.start()) if _mfn37 is not None else None
            msg = ("cfg existence undecidable: the cfg_attr condition `#[cfg_attr(" + re.sub(r"\s+", " ", content.strip()) + ", ...)]` in " + str(rel)
                   + ((" — inside the definition of the macro `" + _mn37 + "`, where the cfg's value arrives by macro substitution and stands decided only at an invocation (seam round 36, protest P7; seam round 37, protest P8)") if _mn37 else "")
                   + ", whose truth the crate's one denotation target (target_os = \"windows\") does not decide, gates an attribute payload the census must judge; "
                   + "the computation refuses by name rather than read the payload as standing (seam round 37, protest P8)")
            if msg not in CHASE_FAILURES:
                CHASE_FAILURES.append(msg)


def production_text(raw):
    """The census text: raw text with its #[cfg(test)] items and
    modules removed (comments and literals left in place — the census
    is the round-1 name-match, scoped to production)."""
    return apply_spans(raw, cfg_test_spans(blank_comments_and_literals(raw)))


def code_text(raw):
    """The reference text: comments and literal contents blanked and
    #[cfg(test)] items and modules removed. A sys reference is a fact
    about production code; prose and literal text are neither."""
    code = blank_comments_and_literals(raw)
    spans = cfg_test_spans(code)
    _dead35 = globals().get("_cfg_dead_spans35")
    if _dead35 is not None:
        spans = spans + _dead35(code, raw)
    return apply_spans(code, spans)


# ---------------------------------------------------------------- the mint
# The direct-sys-call census: the names declared in the production
# `extern` blocks of src/sys.rs. A name-match census, as the seam
# round 1 verdict defines it: a same-named local function would count.
def extern_block_bodies(text):
    bodies = []
    for m in re.finditer(r'extern\s+"system"\s*\{', text):
        depth = 1
        i = m.end()
        start = i
        while i < len(text) and depth:
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
            i += 1
        bodies.append(text[start:i - 1])
    return bodies

sys_text = (DECL_FILE).read_text()
SYS_NAMES = sorted({
    name
    for body in extern_block_bodies(sys_text)
    for name in re.findall(r"(?:pub\s+)?fn\s+(\w+)\s*\(", re.sub(r"//[^\n]*", "", body))
})
SYS_PATTERNS = [re.compile(r"\b" + re.escape(n) + r"\s*\(") for n in SYS_NAMES]

# The extended mint: every name `sys` declares that a file in the
# crate can name through the glob — the extern names above, every
# public type, constant, struct and enum, the owned wrapper functions
# defined in sys.rs itself (the `pub fn` items at its top level; the
# extern declarations are indented inside their blocks and are not
# matched by the anchored pattern), and the re-export of
# sys/rng.rs's secure_random_16. Private items of sys (its `library`
# and `function` helpers and the `guid` constructor) are not in the
# mint: no other module can name them, so a pinned file using the
# word names its own item, never sys's.
EXTENDED_MINT = sorted(set().union(
    SYS_NAMES,
    re.findall(r"(?m)^pub type (\w+)", sys_text),
    re.findall(r"(?m)^pub const (\w+)", sys_text),
    re.findall(r"(?m)^pub struct (\w+)", sys_text),
    re.findall(r"(?m)^pub enum (\w+)", sys_text),
    re.findall(r"(?m)^pub (?:unsafe )?fn (\w+)", sys_text),
    re.findall(r"(?m)^pub(?:\(crate\))? use rng::(\w+);", sys_text),
))

# The recorded exclusions from the extended mint, each argued here
# and recorded again in design gate D43, whose set check ties the
# two records together (a name dropped or added on one side alone
# moves the computed set and fails there). Seam round 3 (protest
# P3): the exclusions are judged by OCCURRENCE, not by word — the
# shapes that can name sys's items are never exempt (a `slot` call
# shape anywhere; a bare `Bool` outside src/hook/json.rs), and the
# occurrences that are exempt are pinned per file in D43, so any
# new occurrence fails there until it wins its argument:
#   Bool — the word is taken inside the pinned set itself:
#     src/hook/json.rs defines its own `Bool` variant of its `Json`
#     value enum (the JSON literal kind), and the pinned set's
#     occurrences of the word are that variant's definition and
#     its `Json::Bool` path uses in that one file. sys's `Bool`
#     is its alias for `i32`; a bare `Bool` in any other pinned
#     file can only be that alias in a type position, so it is
#     not exempt and fails (see reference_facts below).
#   slot — the hook's ordinary word for a watcher's position: the
#     pinned set's occurrences are local bindings (the scanner's
#     probe slots), never a call. sys's `slot` is its unsafe
#     v-table accessor; a `slot` call shape (`slot::<`, `slot(`)
#     in any pinned file can only be that accessor, so it is not
#     exempt and fails (see reference_facts below).
EXCLUSIONS = {"Bool", "slot"}
MINT_PATTERNS = [
    (n, re.compile(r"\b" + re.escape(n) + r"\b"))
    for n in EXTENDED_MINT if n not in EXCLUSIONS
]
MINT_RE = re.compile(r"\b(" + "|".join(
    re.escape(n) for n in sorted((n for n in EXTENDED_MINT if n not in EXCLUSIONS), key=len, reverse=True)
) + r")\b")
EXTERN_CALL_RE = re.compile(r"\b(" + "|".join(
    re.escape(n) for n in sorted(SYS_NAMES, key=len, reverse=True)
) + r")\s*\(")
SLOT_CALL_RE = re.compile(r"\bslot\s*(?:::|::\s*<|\()")
BOOL_WORD_RE = re.compile(r"\bBool\b")

# The sys-reaching wrappers, derived over the whole crate (seam
# round 3, protests P1/P2): every production function and method
# defined anywhere in the crate whose own production body reaches
# `sys` — it names a `sys::` path, OR it calls a declared extern
# name unqualified (the direct census applied per body), OR it
# names an extended-mint item. A `pub use` re-export is not a
# home: the derivation reads definitions, so a wrapper defined in
# src/diagnostics.rs is found there, not at its re-export in
# src/lib.rs. Function and method extents are found on the code
# text (braces in comments and literals already blanked); a
# method's defining type is the type of the `impl` block that
# holds it (`impl Trait for Type` attributes to Type).
def impl_spans(code):
    spans = []
    for m in re.finditer(r"\bimpl\b", code):
        brace = code.find("{", m.end())
        semi = code.find(";", m.end())
        if brace < 0 or (0 <= semi < brace):
            continue
        header = code[m.end():brace]
        if " for " in header:
            header = header.split(" for ")[-1]
        header = re.sub(r"<[^>]*>", "", header).strip()
        words = re.findall(r"(\w+)", header)
        if not words:
            continue
        depth, j = 1, brace + 1
        while j < len(code) and depth:
            if code[j] == "{":
                depth += 1
            elif code[j] == "}":
                depth -= 1
            j += 1
        spans.append((brace, j, words[-1]))
    return spans

def _fn_body_brace(code, start):
    """The opening brace of a function item's body, or -1 for
    a declaration without one (seam round 13, protest P6;
    seam round 14, protest P10): the first `{` at parenthesis
    depth zero after the `fn` name — a destructuring parameter
    pattern's brace stands inside the parameter list's parens
    and is not the body brace, and a `;` at depth zero first
    is a declaration. Bracket depth is tracked as parenthesis
    depth is, so an array return type's `;` opens nothing;
    and a `{` standing inside a generic argument list — a
    const-generic argument, `Wrap<{ 2 }>` — is an argument,
    not the body: the angle depth is tracked with it, the
    `>` of a `->` return arrow never counting."""
    depth = 0
    brack = 0
    angle = 0
    j = start
    while j < len(code):
        c = code[j]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        elif c == "[":
            brack += 1
        elif c == "]":
            brack -= 1
        elif c == "<" and depth == 0 and brack == 0:
            k = j - 1
            while k >= start and code[k].isspace():
                k -= 1
            if k >= start and (code[k].isalnum() or code[k] in "_>:"):
                angle += 1
        elif c == ">" and angle > 0 and depth == 0 and brack == 0:
            if code[j - 1] != "-":
                angle -= 1
        elif c == "{" and depth == 0 and brack == 0:
            if angle > 0:
                j = _brace_match(code, j)
                continue
            return j
        elif c == ";" and depth == 0 and brack == 0 and angle == 0:
            return -1
        j += 1
    return -1

def typed_bodies(code):
    """Every function and method definition in `code` as
    (name, defining type or None for a free function, body)."""
    spans = impl_spans(code)
    out = []
    for m in re.finditer(r"\bfn\s+(\w+)", code):
        name = m.group(1)
        brace = _fn_body_brace(code, m.end())
        if brace < 0:
            continue
        depth, j = 1, brace + 1
        while j < len(code) and depth:
            if code[j] == "{":
                depth += 1
            elif code[j] == "}":
                depth -= 1
            j += 1
        tname = None
        for a, b, t in spans:
            if a < m.start() < b:
                tname = t
                break
        out.append((name, tname, code[brace:j]))
    return out

def typed_items(code):
    """Every function and method definition in `code` as
    (name, defining type or None for a free function, signature
    text, body text, body offset): the signature is the text
    from the `fn` keyword to the opening brace, the body the
    brace block, and the body offset the index of that brace in
    `code`, so a position inside the body can be attributed to
    its place in the file (the scope computation below)."""
    spans = impl_spans(code)
    out = []
    for m in re.finditer(r"\bfn\s+(\w+)", code):
        name = m.group(1)
        brace = _fn_body_brace(code, m.end())
        if brace < 0:
            continue
        depth, j = 1, brace + 1
        while j < len(code) and depth:
            if code[j] == "{":
                depth += 1
            elif code[j] == "}":
                depth -= 1
            j += 1
        tname = None
        for a, b, t in spans:
            if a < m.start() < b:
                tname = t
                break
        out.append((name, tname, code[m.start():brace], code[brace:j], brace))
    return out

def bare_bool(text):
    """A bare `Bool` in `text`: a whole-word `Bool` that is not a
    `::`-path segment (the `Json::Bool` path is not sys's alias)."""
    for m in BOOL_WORD_RE.finditer(text):
        if text[max(0, m.start() - 2):m.start()] != "::":
            return True
    return False

def body_reaches_sys(body, item=None):
    # The sys:: path, the extern calls and the extended mint are
    # judged on the body, as before. The two occurrence-judged
    # exclusion shapes (seam round 4, protest P4) are judged over
    # the whole item text — signature and body — because a helper
    # can reach sys through its signature alone (a bare `Bool`
    # return type is sys's alias, exactly as a `slot` call in its
    # body is sys's accessor): a `slot` call shape and a bare
    # `Bool` in an item are a sys reach. The scanner-shaped local
    # binding named `slot` is not a call shape, and the
    # `Json::Bool` path is not bare, so neither is a reach.
    text = body if item is None else item
    return (
        "sys::" in body
        or EXTERN_CALL_RE.search(body) is not None
        or MINT_RE.search(body) is not None
        or SLOT_CALL_RE.search(text) is not None
        or bare_bool(text)
    )

# The derivation runs where wrappers can live: every production
# file. (The production file set is the census set computed
# below; the derivation is filled in after the census loop, and
# reference_facts — its only consumer — runs after that.)
WRAPPERS_FREE = {}  # free wrapper name -> the file that defines it
WRAPPERS_METH = {}  # (defining type, method name) -> defining file
WRAPPER_WORD_RE = None  # combined whole-word pattern over free names
WRAPPER_TYPES = set()  # types carrying any derived method wrapper
WRAPPER_TYPE_HOME = {}  # wrapper type -> the file that defines the type

# The declared-type tables (seam round 5): every production
# type's fields, every production item's declared return type,
# and every production type alias, collected mechanically over
# the production files. These are the declarations the receiver
# fixed point (P1), the containment and alias closures (P2/P3)
# and the generic-instantiation computation (P5) read — the
# same declared types the crate itself resolves through.
RETURN_FREE = {}  # free function name -> declared return type text
RETURN_FREE_QUAL = {}  # (file, qualified module path) -> declared return type text, per free definition (seam round 32, protest P4)
RETURN_METH = {}  # (defining type, method name) -> return type text
STRUCT_FIELDS = {}  # type name -> ({field: type text}, [positional type texts])
STRUCT_PARAMS = {}  # type identity -> [generic parameter names in declaration order, lifetimes and const parameters included]
TYPE_DEFS = {}  # type name -> the file that defines it
ALIASES = {}  # alias name -> (head type name or None, defining file)
GENERIC_USES = {}  # file -> [(display, home)] generic-instantiation uses (P5)
RETURN_PROJECTIONS = {}  # (defining file, module path within the file, defining type or None, impl kind or None, item name) -> [(field-wrapper hit, packaging path)] projections standing in the item's return packaging, keyed by the item's identity, never by bare name (seam round 20, protest P5; seam round 22, protest P5; seam round 23, protest P5)
PROJECTION_IDENTITIES = {}  # item name -> {(defining file, module path, defining type or None, impl kind or None)} of every production definition of the name, entry or none (seam round 23, protest P5)
BLANKET_PROJECTION_IDENTITIES = {}  # item name -> {(defining file, module path, generic parameter, impl kind)} of blanket-impl definitions whose bound no concrete production type satisfies, so no concrete identity can be recorded for them (seam round 24, protest P4)


# The D45 judged set's second home (seam round 6, protest P9):
# the (struct, field) pairs of src/sys.rs D45 judges
# pointer-carrying, recorded here so the dependency graph's
# prose can stand as the set's second home — D45's check
# compares its own pin against the graph's list on every run,
# so retiring a pair takes coordinated visible edits in both
# records. The pairs are D45's judgement, transcribed; the
# counts (72 names over 77 pairs) are its summary.
JUDGED_RECORD = [
    ("AssociateCompletionPort", "key"),
    ("AssociateCompletionPort", "port"),
    ("BasicLimitInformation", "affinity"),
    ("BasicLimitInformation", "maximum_working_set_size"),
    ("BasicLimitInformation", "minimum_working_set_size"),
    ("Com", "0"),
    ("ConsoleApi", "expunge"),
    ("ConsoleApi", "handler"),
    ("ConsoleApi", "prompt"),
    ("CredUiInfoW", "banner"),
    ("CredUiInfoW", "caption"),
    ("CredUiInfoW", "message"),
    ("CredUiInfoW", "parent"),
    ("DesktopApi", "free"),
    ("DesktopApi", "prompt"),
    ("DesktopApi", "protected"),
    ("DesktopApi", "unpack"),
    ("DesktopApi", "unprotect"),
    ("ExtendedLimitInformation", "job_memory_limit"),
    ("ExtendedLimitInformation", "peak_job_memory_used"),
    ("ExtendedLimitInformation", "peak_process_memory_used"),
    ("ExtendedLimitInformation", "process_memory_limit"),
    ("HString", "delete"),
    ("HString", "raw"),
    ("HelloApi", "create"),
    ("HelloApi", "delete"),
    ("HelloApi", "factory"),
    ("HelloApi", "initialize"),
    ("HelloApi", "uninitialize"),
    ("LogonApi", "logon"),
    ("LogonApi", "lookup"),
    ("Msg", "l"),
    ("Msg", "w"),
    ("Msg", "window"),
    ("NameApi", "name"),
    ("Overlapped", "event"),
    ("Overlapped", "internal"),
    ("Overlapped", "internal_high"),
    ("ProcessBasicInformation", "affinity"),
    ("ProcessBasicInformation", "parent_process_id"),
    ("ProcessBasicInformation", "peb"),
    ("ProcessBasicInformation", "unique_process_id"),
    ("ProcessEntry32W", "default_heap_id"),
    ("ProcessInformation", "process"),
    ("ProcessInformation", "thread"),
    ("SecurityAttributes", "descriptor"),
    ("StartupInfoExW", "attribute_list"),
    ("StartupInfoW", "desktop"),
    ("StartupInfoW", "reserved"),
    ("StartupInfoW", "reserved2"),
    ("StartupInfoW", "std_error"),
    ("StartupInfoW", "std_input"),
    ("StartupInfoW", "std_output"),
    ("StartupInfoW", "title"),
    ("WindowApi", "create"),
    ("WindowApi", "default_procedure"),
    ("WindowApi", "destroy"),
    ("WindowApi", "dispatch"),
    ("WindowApi", "peek"),
    ("WindowApi", "register"),
    ("WindowApi", "unregister"),
    ("WindowApi", "wait"),
    ("WindowStationApi", "close_desktop"),
    ("WindowStationApi", "information"),
    ("WindowStationApi", "input_desktop"),
    ("WindowStationApi", "station"),
    ("WindowStationApi", "thread_desktop"),
    ("WndClassExW", "background"),
    ("WndClassExW", "class_name"),
    ("WndClassExW", "cursor"),
    ("WndClassExW", "icon"),
    ("WndClassExW", "icon_small"),
    ("WndClassExW", "instance"),
    ("WndClassExW", "menu"),
    ("WndClassExW", "procedure"),
    ("WtsApi", "free"),
    ("WtsApi", "query"),
]

def _split_top_commas(text):
    """Split on commas at bracket depth zero — (), [], {} and
    <> all nest — the split_params idiom design gate D45 uses
    for extern signatures, applied to declaration bodies. A
    function pointer's `->` is read as two neutral characters,
    not an angle close (seam round 22, protest P3): without
    that reading a field typed `Result<fn(...) -> !, ()>`
    ended its own declaration at the arrow's `>`, the comma
    inside the container split the declaration there, and
    every field standing after such a field in the same
    declaration stood in no field table — the carriage
    derivation records every carrying field of a
    construction only when the declaration's fields all
    stand in the table this split feeds."""
    parts, depth, cur = [], 0, ""
    prev = ""
    brace = 0
    angle = 0
    for ch in text:
        if brace > 0 and ch in "<>":
            pass
        elif ch in "([{[":
            depth += 1
            if ch == "{":
                brace += 1
        elif ch == "<":
            angle += 1
        elif ch in ")]>}":
            if ch == "}":
                brace -= 1
                depth -= 1
            elif ch == ">":
                # A function pointer's `->` never closes an
                # angle bracket, and a `>` at angle depth
                # zero is a comparison or a shift, never a
                # close (seam round 23, protest P3).
                if prev != "-" and angle > 0:
                    angle -= 1
            else:
                depth -= 1
        if ch == "," and depth == 0 and angle == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
        prev = ch
    if cur.strip():
        parts.append(cur)
    return parts

def _delim_match(code, open_idx, open_ch, close_ch):
    depth, j = 1, open_idx + 1
    while j < len(code) and depth:
        if code[j] == open_ch:
            depth += 1
        elif code[j] == close_ch:
            depth -= 1
        j += 1
    return j

def _strip_field_segment(seg):
    seg = seg.strip()
    while seg.startswith("#["):
        seg = seg[_delim_match(seg, 1, "[", "]"):].strip()
    return re.sub(r"^pub(?:\s*\([^)]*\))?\s+", "", seg)

def struct_declarations(code):
    """Every struct, enum and union declaration in `code` as
    (name, named_fields, positional_types): named_fields is a
    list of (field name, field type text) and positional_types
    a list of type texts (an enum contributes its variants'
    fields and payloads). Extraction is by STRUCTURE — brace
    matching on the blanked text, for named and positional
    declarations alike, fields split on top-level commas
    depth-aware — not by line shape (seam round 5, protest P7's
    repair, in the form the census applies it to src/sys.rs,
    applied here crate-wide for protests P1 and P2). The body
    is reached as Rust lays a declaration out (seam round 6,
    protest P8): after the name and generics, a where clause
    is skipped properly — the scan runs at bracket depth
    zero to the grammar's body position (the named body's
    `{`, the tuple body's `(` or the unit `;`), treating the
    where clause's own bracketed predicates as depth, so an
    array-length predicate's `;` and a function-pointer
    bound's `(` inside a where clause open nothing. A field
    named with a raw identifier (`r#name`) extracts as the
    field `name`."""
    out = []
    for m in re.finditer(r"\b(struct|enum|union)\s+(\w+)", code):
        kind, name = m.group(1), m.group(2)
        i = m.end()
        while i < len(code) and code[i].isspace():
            i += 1
        if i < len(code) and code[i] == "<":
            i = _delim_match(code, i, "<", ">")
        # Skip an optional where clause and find the body: the
        # first `{`, `(` or `;` the grammar can place at the
        # body position — at bracket depth zero once any where
        # clause's bracketed predicates are counted as depth.
        in_where = False
        if code.startswith("where", i) and (i + 5 >= len(code) or not (code[i + 5].isalnum() or code[i + 5] == "_")):
            in_where = True
            i += 5
        paren = brack = 0
        body_at = None
        j = i
        while j < len(code):
            c = code[j]
            if in_where and paren == 0 and brack == 0 and c in "{;":
                body_at = j
                break
            if c == "(":
                if not in_where and paren == 0 and brack == 0:
                    body_at = j
                    break
                paren += 1
            elif c == ")":
                paren -= 1
            elif c == "[":
                brack += 1
            elif c == "]":
                brack -= 1
            elif c == "{" and not in_where and paren == 0 and brack == 0:
                body_at = j
                break
            elif c == ";" and not in_where and paren == 0 and brack == 0:
                body_at = j
                break
            j += 1
        i = body_at if body_at is not None else len(code)
        named, positional = [], []
        if i < len(code) and code[i] == "{":
            end = _brace_match(code, i)
            body = code[i + 1:end - 1]
            for seg in _split_top_commas(body):
                seg = _strip_field_segment(seg)
                if not seg:
                    continue
                if kind == "enum":
                    vm = re.match(r"(?:r#)?(\w+)\s*(.*)$", seg, re.S)
                    if not vm:
                        continue
                    rest = vm.group(2).strip()
                    if rest.startswith("("):
                        inner = rest[1:_delim_match(rest, 0, "(", ")") - 1]
                        positional.extend(_strip_field_segment(p) for p in _split_top_commas(inner))
                    elif rest.startswith("{"):
                        inner = rest[1:_brace_match(rest, 0) - 1]
                        for fseg in _split_top_commas(inner):
                            fm = re.match(r"(?:r#)?(\w+)\s*:\s*(.+)$", _strip_field_segment(fseg), re.S)
                            if fm:
                                named.append((fm.group(1), re.sub(r"\s+", " ", fm.group(2).strip())))
                else:
                    fm = re.match(r"(?:r#)?(\w+)\s*:\s*(.+)$", seg, re.S)
                    if fm:
                        named.append((fm.group(1), re.sub(r"\s+", " ", fm.group(2).strip())))
            out.append((name, named, positional))
        elif i < len(code) and code[i] == "(":
            end = _delim_match(code, i, "(", ")")
            inner = code[i + 1:end - 1]
            positional = [_strip_field_segment(p) for p in _split_top_commas(inner)]
            out.append((name, named, positional))
        else:
            out.append((name, named, positional))
    return out

def _angle_match(text, open_idx):
    """The offset one past the `>` matching the `<` at
    open_idx, a function pointer's `->` read as two neutral
    characters, not an angle close (seam round 18, protest
    P2)."""
    depth, j = 1, open_idx + 1
    while j < len(text) and depth:
        if text[j:j + 2] == "->":
            j += 2
            continue
        if text[j] == "<":
            depth += 1
        elif text[j] == ">":
            depth -= 1
        j += 1
    return j

def _decl_generic_params(code, pos):
    """The generic parameter names a struct / enum / union
    declaration at `pos` declares, in declaration order —
    type, const and lifetime parameters alike (seam round
    18, protest P2): the names an instantiation's arguments
    stand in for, position for position."""
    m = re.match(r"(?:struct|enum|union)\s+\w+", code[pos:])
    if not m:
        return []
    i = pos + m.end()
    while i < len(code) and code[i].isspace():
        i += 1
    if i >= len(code) or code[i] != "<":
        return []
    end = _angle_match(code, i)
    out = []
    for part in _split_top_commas(code[i + 1:end - 1]):
        part = part.strip()
        if not part:
            continue
        if part.startswith("const "):
            pm = re.match(r"const\s+(\w+)", part)
        elif part.startswith("'"):
            pm = re.match(r"('\w+)", part)
        else:
            pm = re.match(r"(\w+)", part)
        if pm:
            out.append(pm.group(1))
    return out

def _type_names_by_value(ttext):
    """The type names a field type contains BY VALUE: every
    capitalised name in the type text except one governed
    directly by a reference or raw-pointer marker (`&`,
    `*mut`, `*const`), and except a payload governed by a
    non-dropping head (seam round 6, protest P4):
    `ManuallyDrop`, `MaybeUninit` and `PhantomData` — the
    language's whole set of std heads whose documented
    semantics are that dropping the head does NOT drop the
    payload — govern their payload as `&` and `*` already
    do, spelled with or without their `std::mem::` path.
    Dropping the field drops the remaining names' values
    and runs their `Drop`; it does not drop the pointees of
    its references and pointers, nor the payloads of those
    heads, which is why the containment closure is over
    exactly this set."""
    names = []
    stack = []
    last_name = None
    for m in re.finditer(r"\b[A-Z]\w*|<|>", ttext):
        tok = m.group(0)
        if tok == "<":
            stack.append(last_name)
            last_name = None
            continue
        if tok == ">":
            if stack:
                stack.pop()
            last_name = None
            continue
        governed = any(h in NON_DROPPING_HEADS for h in stack)
        before = ttext[:m.start()].rstrip()
        last_name = tok
        if governed:
            continue
        if re.search(r"(?:\*|&)\s*(?:'\w+\s*)?(?:mut\s+|const\s+)?$", before):
            continue
        names.append(tok)
    return names

def _return_type(sig):
    # The return separator is the arrow at bracket depth
    # zero after the parameter list (seam round 16,
    # protest P2): an arrow inside the return type itself
    # — a function pointer's — is part of the type, as in
    # _fn_body_brace and _split_top, never the separator
    # the earlier last-arrow reading took it for.
    depth, prev, close = 0, "", -1
    for j, c in enumerate(sig):
        if c == "(" and depth == 0 and close < 0:
            depth = 1
            prev = c
            k, d2, p2 = j + 1, 1, c
            while k < len(sig) and d2:
                c2 = sig[k]
                if c2 in "(<[{":
                    d2 += 1
                elif c2 in ")>]}":
                    if not (c2 == ">" and p2 == "-"):
                        d2 -= 1
                p2 = c2
                k += 1
            close = k
            break
        if c in "(<[{":
            depth += 1
        elif c in ")>]}":
            if not (c == ">" and prev == "-"):
                depth -= 1
        prev = c
    if close < 0:
        return None
    depth, prev = 0, ""
    j = close
    while j < len(sig):
        c = sig[j]
        if c == "-" and sig[j + 1:j + 2] == ">" and depth == 0:
            if re.search(r"\bwhere\b", sig[close:j]):
                return None
            rt = re.sub(r"\s+", " ", sig[j + 2:]).strip()
            # The return type ends at a depth-zero `where`
            # clause (seam round 18, protest P7): the clause
            # bounds the parameters — it is not part of the
            # type. A `where` inside the type's own brackets
            # (a function pointer's parameter list, a generic
            # argument) is part of the type and stands.
            depth, prev, cut = 0, "", len(rt)
            i2 = 0
            while i2 < len(rt):
                if rt[i2:i2 + 2] == "->":
                    prev = ">"
                    i2 += 2
                    continue
                c = rt[i2]
                if c in "(<[{":
                    depth += 1
                elif c in ")>]}":
                    if not (c == ">" and prev == "-"):
                        depth -= 1
                elif depth == 0 and rt.startswith("where", i2) and (i2 == 0 or not (rt[i2 - 1].isalnum() or rt[i2 - 1] == "_")) and (i2 + 5 >= len(rt) or not (rt[i2 + 5].isalnum() or rt[i2 + 5] == "_")):
                    cut = i2
                    break
                prev = c
                i2 += 1
            rt = rt[:cut].strip()
            return rt or None
        if c in "(<[{":
            depth += 1
        elif c in ")>]}":
            if not (c == ">" and prev == "-"):
                depth -= 1
        prev = c
        j += 1
    return None

def derive_wrappers(raws_by_rel, production_rels):
    global WRAPPER_WORD_RE
    codes = {rel: code_text(raws_by_rel[rel]) for rel in production_rels}
    for _rel35 in production_rels:
        RAW_BY_REL35[_rel35] = raws_by_rel[_rel35]
        CODE_BY_REL35[_rel35] = codes[_rel35]
    RAW_BY_REL35[SYS_DECL_REL] = raws_by_rel[SYS_DECL_REL]
    CODE_BY_REL35[SYS_DECL_REL] = code_text(raws_by_rel[SYS_DECL_REL])
    _audit35 = globals().get("_cfg_audit35")
    if _audit35 is not None:
        for _rel35 in production_rels:
            _audit35(codes[_rel35], raws_by_rel[_rel35], _rel35)
    _fill_sys_kinds(code_text(raws_by_rel[SYS_DECL_REL]))
    _build_type_locs(codes, production_rels, raws_by_rel)
    _inject_macro_expansions(codes, production_rels, code_text(raws_by_rel[SYS_DECL_REL]))
    _build_trait_overrides(codes, production_rels)
    _expand_macro_exprs(codes, production_rels, code_text(raws_by_rel[SYS_DECL_REL]))

    # The Deref targets (seam round 7, protest P4): every in-tree
    # `impl Deref` / `DerefMut` declaration's associated Target,
    # computed from the tree as the receiver fixed point's step.
    for rel in sorted(codes):
        code = codes[rel]
        for m in re.finditer(r"\bimpl\s*(?:<[^;{]*?>)?\s*(?:\w+\s*::\s*)*Deref(?:Mut)?\s+for\s+((?:\w+\s*::\s*)*\w+)", code):
            brace = code.find("{", m.end())
            if brace < 0:
                continue
            end = _brace_match(code, brace)
            tm = re.search(r"\btype\s+Target\s*=\s*([^;]+);", code[brace:end])
            if not tm:
                continue
            tsegs = [s.strip() for s in m.group(1).split("::")]
            tident = _type_ident_at(rel, code, tsegs[-1], m.start()) if len(tsegs) == 1 else _ident_of(tsegs[-1], tsegs[:-1])
            target = _det_id(tm.group(1), rel=rel)
            if tident is not None and target is not None:
                DEREF_TARGETS.setdefault(tident, target)
                _gm36 = re.match(r"impl\s*<([^;{]*?)>", code[m.start():])
                _ip36 = []
                if _gm36:
                    for _pp36 in _split_top(_gm36.group(1)):
                        _pm36 = re.match(r"(?:const\s+)?('?\w+)", _pp36.strip())
                        if _pm36:
                            _ip36.append(_pm36.group(1))
                _fa36 = []
                _fp36 = m.end()
                while _fp36 < len(code) and code[_fp36].isspace():
                    _fp36 += 1
                if _fp36 < len(code) and code[_fp36] == "<":
                    _fe36 = _angle_match(code, _fp36)
                    _fa36 = [p.strip() for p in _split_top(code[_fp36 + 1:_fe36 - 1])]
                DEREF_TARGET_TEXT36.setdefault(tident, (re.sub(r"\s+", " ", tm.group(1).strip()), _fa36, _ip36))
    for rel in production_rels:
        code = codes[rel]
        decl_positions = [m.start() for m in re.finditer(r"\b(?:struct|enum|union)\s+(\w+)", code)]
        for (dname, named, positional), dpos in zip(struct_declarations(code), decl_positions):
            TYPE_DEFS.setdefault(dname, rel)
            STRUCT_FIELDS.setdefault(_type_ident_at(rel, code, dname, dpos), (dict(named), list(positional)))
            STRUCT_PARAMS.setdefault(_type_ident_at(rel, code, dname, dpos), _decl_generic_params(code, dpos))
        for m in re.finditer(r"\btype\s+(\w+)\s*(?:<[^;{]*>)?\s*=\s*([^;]+);", code):
            ALIASES.setdefault(m.group(1), (_det_type(m.group(2)), rel))
        tspans = trait_spans(code)
        _bpairs = _blanket_impl_pairs(code)
        for _tr, _ty in impl_trait_pairs(code):
            if _tr is not None and (_tr, _ty) not in _bpairs:
                TRAIT_IMPLS.setdefault(_ty, set()).add(_tr)
        for _vm in re.finditer(r"\b(?:const|static)\s+(?:mut\s+)?(\w+)\s*:\s*([^=;]+)=", code):
            _vt = _det_id(_vm.group(2), rel=rel)
            if _vt is not None:
                VALUE_TYPES.setdefault(_vm.group(1), _vt)
        for _vm33 in re.finditer(r"\b(?:const|static)\s+(?:mut\s+)?(\w+)\s*:\s*([^=;]+?)\s*=\s*([^;]+);", code):
            CONST_ITEMS33.setdefault(_vm33.group(1), []).append((rel, re.sub(r"\s+", " ", _vm33.group(2).strip()), re.sub(r"\s+", " ", _vm33.group(3).strip())))
        for _bt in _blanket_traits(code):
            BLANKET_TRAITS.add(_bt)
        for name, tname, sig, body, _off in typed_items(code):
            rt = _return_type(sig)
            tident = _type_ident_at(rel, code, tname, _off) if tname is not None else None
            trait_of = None
            for _ta, _tb, _tn in tspans:
                if _ta < _off < _tb:
                    trait_of = _tn
                    break
            if trait_of is not None:
                if rt is not None:
                    TRAIT_METH_RETURN33.setdefault((trait_of, name), rt)
                # A trait default method (seam round 10,
                # protest P2): a method wrapper OF ITS TRAIT,
                # never a free wrapper — the receiver arm
                # reaches it through the types that implement
                # the trait.
                if body_reaches_sys(body, sig + body):
                    TRAIT_WRAPPERS.setdefault((trait_of, name), rel)
                continue
            if rt is not None:
                if tname is None:
                    RETURN_FREE.setdefault(name, rt)
                    _qual32 = "::".join(p for p in [FILE_DECLARED_PATHS.get(rel) or _file_module_path(rel), *_mod_chain_at(code, _off), name] if p)
                    RETURN_FREE_QUAL.setdefault((rel, _qual32), rt)
                else:
                    RETURN_METH.setdefault((tident, name), rt)
            if tname is None:
                FREE_FN_DEFS.add((rel, name))
                FN_BODIES[(rel, name)] = body
                PARAMS_FREE.setdefault(name, [pt for _pn, pt in _param_list(sig)])
                GENERIC_PARAMS_FREE.setdefault(name, _generic_params(sig, name))
            else:
                PARAMS_METH.setdefault((tident, name), [pt for _pn, pt in _param_list(sig)])
                GENERIC_PARAMS_METH.setdefault((tident, name), _generic_params(sig, name))
                METH_BODIES.setdefault((tident, name), (rel, body))
            if not body_reaches_sys(body, sig + body):
                continue
            if tname is None:
                WRAPPERS_FREE.setdefault(name, rel)
            else:
                WRAPPERS_METH.setdefault((tident, name), rel)
    if WRAPPERS_FREE:
        WRAPPER_WORD_RE = re.compile(r"\b(" + "|".join(
            re.escape(n) for n in sorted(WRAPPERS_FREE, key=len, reverse=True)
        ) + r")\b")
    # A type that carries any derived wrapper method — constructors
    # and Drop included, both being method wrappers like any other —
    # is a wrapper type (seam round 4, protest P2). Its home is the
    # file that defines the type itself.
    WRAPPER_TYPES.update(t for (t, _n) in WRAPPERS_METH)
    for tname in list(WRAPPER_TYPES):
        for r, qual, _ch, _kind, _sk in TYPE_LOCS.get(_disp(tname), []):
            if (tname if len(TYPE_LOCS[_disp(tname)]) == 1 else qual) == tname:
                WRAPPER_TYPE_HOME.setdefault(tname, r)
    # The wrapper-type set is closed under by-value field
    # containment (seam round 5, protest P2) and under production
    # type aliases (seam round 5, protest P3), transitively, the
    # two steps iterated together to their fixed point: a type
    # that owns a wrapper type by value in a field — through
    # other containers included — drops the wrapper's handles
    # with its own drop glue, and an alias whose target's head
    # is a wrapper type names that type by its second name,
    # with its home recorded as the alias's file.
    changed = True
    while changed:
        changed = False
        for tname, (named, positional) in list(STRUCT_FIELDS.items()):
            if tname in WRAPPER_TYPES:
                continue
            field_types = list(named.values()) + list(positional)
            home_rel = TYPE_DEFS.get(_disp(tname))
            if any(_resolve_bare(n, home_rel) in WRAPPER_TYPES for ft in field_types for n in _type_names_by_value(ft)):
                WRAPPER_TYPES.add(tname)
                WRAPPER_TYPE_HOME.setdefault(tname, TYPE_DEFS.get(_disp(tname), "?"))
                changed = True
        for aident, atext in ALIAS_TEXT.items():
            if aident in WRAPPER_TYPES:
                continue
            by_value = any(_resolve_bare(n, _alias_home(aident)) in WRAPPER_TYPES for n in _type_names_by_value(atext))
            head = _det_id(atext, expand=False, rel=_alias_home(aident))
            if by_value or (head is not None and head in WRAPPER_TYPES):
                WRAPPER_TYPES.add(aident)
                for r, qual, _ch, _kind, _sk in TYPE_LOCS.get(_disp(aident), []):
                    if (aident if len(TYPE_LOCS[_disp(aident)]) == 1 else qual) == aident:
                        WRAPPER_TYPE_HOME.setdefault(aident, r)
                changed = True

    # The wrapper VALUES (seam round 7, protest P2): a production
    # const or static whose initialiser is a wrapper path — a
    # free wrapper, a wrapper method's path (`Type::name`), a
    # path resolving to one, or another wrapper value — is
    # itself a wrapper value, iterated to a fixed point so a
    # value holding a value counts. Naming one is a wrapper use
    # (see wrapper_uses). Seam round 9 (protest P6): the wrapper
    # path may stand in any expression position that yields it
    # — a whole initialiser, an array / slice / tuple element,
    # a position under a reference or a cast — not only as the
    # whole initialiser.
    changed = True
    while changed:
        changed = False
        for rel in production_rels:
            code = codes[rel]
            for name, _init_text in _value_inits(code):
                if name in WRAPPER_VALUES:
                    continue
                init = re.sub(r"\s+", " ", _init_text.strip())
                hit = False
                # Every path the initialiser spells, in every
                # expression position that yields it (seam
                # round 9, protest P6): the whole initialiser,
                # an array / slice / tuple element, a position
                # under a reference or a cast. A call-shaped
                # occurrence (`path(` / `path::<`) yields the
                # callee's return value, not the wrapper
                # itself, and does not count.
                for pm in re.finditer(r"((?:\w+\s*::\s*)*)(\w+)", init):
                    segs = [s.strip() for s in pm.group(1).split("::") if s.strip()]
                    last = pm.group(2)
                    tail = init[pm.end():].lstrip()
                    if tail.startswith("(") or tail.startswith("::<"):
                        continue
                    if segs:
                        tident = _ident_of(segs[-1], segs[:-1])
                        if tident is not None and (tident, last) in WRAPPERS_METH:
                            hit = True
                    if not hit and not segs and (last in WRAPPERS_FREE or last in WRAPPER_VALUES):
                        hit = True
                    if not hit and segs:
                        desc = _resolve_item(rel, segs + [last])
                        if desc is not None and desc[0] in ("free", "value") and (desc[1] in WRAPPERS_FREE or desc[1] in WRAPPER_VALUES):
                            hit = True
                    if hit:
                        break
                if not hit and _call_yields_wrapper(init, rel):
                    hit = True
                if hit:
                    WRAPPER_VALUES[name] = rel
                    changed = True

    # The sys-derived names (seam round 10, protest P1): a
    # production type alias whose target resolves into `sys`,
    # and a production const/static whose initialiser resolves
    # into `sys`, join the census universe as sys-derived
    # names under their own names — the mint closed under
    # production renaming, iterated to a fixed point with the
    # alias chain. Both derivation closures of rounds 5/7 key
    # on wrapper-ness, which `sys`'s own items never acquire;
    # this derivation keys on the sys resolution itself.
    changed = True
    while changed:
        changed = False
        for aident, atext in list(ALIAS_TEXT.items()):
            if aident in SYS_DERIVED_TYPES:
                continue
            if _names_sys_item(atext) or any(n in SYS_DERIVED_TYPES for n in re.findall(r"\b\w+\b", atext)):
                SYS_DERIVED_TYPES.add(aident)
                SYS_DERIVED_TYPE_HOME[aident] = _alias_home(aident)
                changed = True
        for rel in production_rels:
            code = codes[rel]
            for name, _init_text in _value_inits(code):
                if name in SYS_DERIVED_VALUES or name in WRAPPER_VALUES:
                    continue
                init = re.sub(r"\s+", " ", _init_text.strip())
                if _names_sys_item(init) or any(n in SYS_DERIVED_VALUES for n in re.findall(r"\b\w+\b", init)) or _call_derives_sys(init, rel):
                    SYS_DERIVED_VALUES[name] = rel
                    changed = True
        # Re-export bindings are derivation sources of the same
        # kind (seam round 11, protest P8): a production `use`
        # binding that RENAMES its target — `pub use ... as`
        # included — whose target resolves into `sys`, or to a
        # sys-derived name, makes the binding's own name a
        # sys-derived name of the target's kind, recorded in
        # the binding's home and chaseable by path and by bare
        # name, so a renaming is a renaming in every spelling
        # Rust offers: alias, const copy, or `use ... as`. (A
        # plain import, local name equal to the target's, is
        # already a mint name and derives nothing new.)
        for rel in production_rels:
            for local, scope, segs, _is_pub in FILE_BINDINGS_RAW.get(rel, []):
                if local == "*" or not segs or local == segs[-1]:
                    continue
                kind = _binding_sys_kind(rel, segs)
                if kind == "type":
                    mp = SCOPE_MODPATH.get((rel, scope)) or FILE_MODULES.get(rel, "")
                    ident = "::".join(p for p in [mp, local] if p) if local in TYPE_LOCS else local
                    if ident not in SYS_DERIVED_TYPES:
                        SYS_DERIVED_TYPES.add(ident)
                        SYS_DERIVED_TYPE_HOME[ident] = rel
                        changed = True
                elif kind == "value":
                    if local not in SYS_DERIVED_VALUES and local not in WRAPPER_VALUES:
                        SYS_DERIVED_VALUES[local] = rel
                        changed = True
                elif kind == "fn":
                    if local not in SYS_DERIVED_FNS:
                        SYS_DERIVED_FNS[local] = rel
                        changed = True
    # The wrapper-yielding functions AND METHODS (seam round 10,
    # protest P8; methods seam round 11, protest P3): a free
    # function or a method whose return expression yields a
    # wrapper — the yield principle of the wrapper-value
    # derivation, extended from const/static initialisers to
    # return positions and iterated to the same fixed point.
    # The criterion's own text has always named both item kinds
    # ("a free function or method"); round 10's derivation ran
    # over free functions alone, so a method returning the
    # wrapper as a value was derived as nothing. An item that
    # itself reaches `sys` is a wrapper, not a yielding item,
    # and is not re-derived here. Seam round 11 (protest P5): a
    # returned closure is a yield of the same kind — a function
    # or method whose return expression is a closure whose body
    # reaches a wrapper yields that wrapper, the closure being
    # the wrapper's behaviour in an unnamed item, attached here
    # to the item that defines it.
    changed = True
    while changed:
        changed = False
        for rel in production_rels:
            code = codes[rel]
            tspans = trait_spans(code)
            for name, tname, sig, body, _off in typed_items(code):
                if any(_ta < _off < _tb for _ta, _tb, _tn in tspans):
                    continue
                if body_reaches_sys(body, sig + body):
                    continue
                if tname is None:
                    if name in WRAPPER_YIELD_FREE or name in WRAPPERS_FREE:
                        continue
                    if _return_yields(body, rel):
                        WRAPPER_YIELD_FREE[name] = rel
                        changed = True
                else:
                    tident = _type_ident_at(rel, code, tname, _off)
                    if tident is None or (tident, name) in WRAPPER_YIELD_METH or (tident, name) in WRAPPERS_METH:
                        continue
                    if _return_yields(body, rel):
                        WRAPPER_YIELD_METH[(tident, name)] = rel
                        changed = True
    # The yield derivation over trait default methods (seam
    # round 12, protest P5): a trait default whose return
    # expressions yield a wrapper is a wrapper-yielding trait
    # method, keyed by (trait, method) beside the blanket-impl
    # keying of round 11 — the yield loop above skips trait
    # items entirely, and the trait-wrapper derivation records
    # only defaults whose bodies reach `sys`, so a default
    # yielding a WRAPPER stood in neither table.
    for rel in production_rels:
        code = codes[rel]
        tspans = trait_spans(code)
        if not tspans:
            continue
        for name, tname, sig, body, _off in typed_items(code):
            trait_of = None
            for _ta, _tb, _tn in tspans:
                if _ta < _off < _tb:
                    trait_of = _tn
                    break
            if trait_of is None or (trait_of, name) in TRAIT_YIELD or (trait_of, name) in TRAIT_WRAPPERS:
                continue
            if body_reaches_sys(body, sig + body):
                continue
            if _return_yields(body, rel):
                TRAIT_YIELD[(trait_of, name)] = rel
            elif _trait_default_ctor_yield33(body, sig, rel):
                TRAIT_YIELD[(trait_of, name)] = rel
    # The macro channel (seam round 10, protest P10): a
    # production `macro_rules!` definition whose expansion
    # reaches `sys` — its body names a `sys::` path, an extern
    # or mint name, a wrapper, or a wrapper value — is
    # recorded by name; an invocation of it in a pinned file
    # is named as an unmodelled channel in wrapper_uses, in
    # the refusal idiom `include!` already stands in.
    for rel in production_rels:
        code = codes[rel]
        for mname, mbody in _macro_defs(code):
            if body_reaches_sys(mbody, mbody) or (WRAPPER_WORD_RE is not None and WRAPPER_WORD_RE.search(mbody) is not None) or any(n in WRAPPER_VALUES for n in re.findall(r"\b\w+\b", mbody)):
                MACRO_REACHING.setdefault(mname, rel)
    # `sys`'s OWN macros join the same census (seam round 11,
    # protest P7): round 10 read macro definitions from the
    # production files alone, and `src/sys.rs` is excluded
    # from that set by the production definition itself, so
    # the declarations home's own macros — a `sys` item in the
    # strongest form, exported crate-wide — stood in no table.
    # A `macro_rules!` defined in `src/sys.rs` whose expansion
    # reaches `sys` is recorded exactly as a production one
    # is, and its invocation is refused in the same idiom.
    for mname, mbody in _macro_defs(code_text(raws_by_rel[SYS_DECL_REL])):
        if body_reaches_sys(mbody, mbody) or (WRAPPER_WORD_RE is not None and WRAPPER_WORD_RE.search(mbody) is not None) or any(n in WRAPPER_VALUES for n in re.findall(r"\b\w+\b", mbody)):
            MACRO_REACHING.setdefault(mname, SYS_DECL_REL)
    # Braces as expansions denote (seam round 34, protest
    # P1): every production `macro_rules!` definition's
    # brace behaviour, recorded beside the reaching census
    # above, for the binding-in-force computation, which
    # reads enclosures over the text as the compiler's
    # first passes leave it.
    for rel in production_rels:
        for mname, mbody in _macro_defs(codes[rel]):
            MACRO_BRACE34.setdefault(mname, _macro_brace_kind34(mbody))
    for mname, mbody in _macro_defs(code_text(raws_by_rel[SYS_DECL_REL])):
        MACRO_BRACE34.setdefault(mname, _macro_brace_kind34(mbody))
    # Keyed as name resolution keys it (seam round 35,
    # protest P3): every definition also stands recorded
    # under its own file, in standing order, over the
    # cfg-decided census text, for _macro_kind35, which
    # reads the definition in force at an invocation —
    # never the bare-name first-seen the table above
    # records for its other readers.
    for rel in production_rels:
        MACRO_DEFS35[rel] = _macro_defs_at35(codes[rel])
    MACRO_DEFS35[SYS_DECL_REL] = _macro_defs_at35(code_text(raws_by_rel[SYS_DECL_REL]))
    # The definition bodies (seam round 36, protest P6):
    # a closure value standing in an expansion is typed at
    # its invocation site from the definition's own text,
    # which the brace and standing tables do not carry.
    for rel in production_rels:
        for (_mn36, _mb36), _at37 in zip(_macro_defs(codes[rel]), _macro_defs_at35(codes[rel])):
            MACRO_BODIES36.setdefault((rel, _mn36), []).append((_at37[0], _at37[3], _mb36, "#[macro_export]" in codes[rel][max(0, _at37[0] - 200):_at37[0]]))
    _sys37 = code_text(raws_by_rel[SYS_DECL_REL])
    for (_mn36, _mb36), _at37 in zip(_macro_defs(_sys37), _macro_defs_at35(_sys37)):
        MACRO_BODIES36.setdefault((SYS_DECL_REL, _mn36), []).append((_at37[0], _at37[3], _mb36, True))
    # Struct-field carriage (seam round 11, protest P4): a
    # struct one of whose fields is initialised from a wrapper
    # in a constructor — a function or method body, or a
    # const/static initialiser — carries that wrapper in the
    # field: the constructor yields the wrapper for that field,
    # and a call through a projection of the field is a use of
    # the wrapper (see wrapper_uses). Whole-value holders were
    # already modelled by the wrapper-value derivation; the
    # field is the carrier this derivation runs over.
    # The carriage derivation runs to a fixed point
    # (seam round 16, protest P4), as the wrapper-value,
    # yield and sys-derived closures above already do:
    # a field initialised by a projection of a field a
    # later file's pass records is itself recorded, at
    # whatever chain length the constructors spell.
    _carriage_changed = True
    while _carriage_changed:
        _carriage_changed = False
        for rel in production_rels:
            code = codes[rel]
            texts = [(body, tname, _off) for _n, tname, _s, body, _off in typed_items(code)]
            texts += [(_init_text, None, 0) for _name, _init_text in _value_inits(code)]
            for text, tname, _off in texts:
                for ttext, fields in _struct_literals(text):
                    if ttext == "Self":
                        tident = _type_ident_at(rel, code, tname, _off) if tname else None
                    else:
                        tsegs = ttext.split("::")
                        tident = _ident_of(tsegs[-1], tsegs[:-1]) if len(tsegs) > 1 else _det_id(ttext, rel=rel)
                        if tident is None and len(tsegs) > 1:
                            # A variant literal (seam round 12,
                            # protest P4): the construction is keyed
                            # by the ENUM it denotes, whose declared
                            # fields the variant's fields are.
                            tident = _ident_of(tsegs[-2], tsegs[:-2])
                    if tident is None or tident not in STRUCT_FIELDS:
                        continue
                    named = STRUCT_FIELDS[tident][0]
                    for fname, fexpr in fields:
                        if fname not in named or (tident, fname) in FIELD_WRAPPERS:
                            continue
                        hit = _field_init_wrapper(fexpr, rel)
                        if hit is not None:
                            FIELD_WRAPPERS[(tident, fname)] = hit
                            _carriage_changed = True
                # Tuple constructions (seam round 12, protest P3):
                # a tuple struct's (or tuple variant's) positional
                # argument initialised from a wrapper carries it at
                # that index, keyed by the index as the receiver
                # machinery already keys positional fields.
                for ttext, args in _tuple_constructions(text):
                    if ttext == "Self":
                        tident = _type_ident_at(rel, code, tname, _off) if tname else None
                    else:
                        tsegs = ttext.split("::")
                        tident = _ident_of(tsegs[-1], tsegs[:-1]) if len(tsegs) > 1 else _det_id(ttext, rel=rel)
                        if tident is None and len(tsegs) > 1:
                            tident = _ident_of(tsegs[-2], tsegs[:-2])
                    if tident is None or tident not in STRUCT_FIELDS:
                        continue
                    positional = STRUCT_FIELDS[tident][1]
                    for idx, aexpr in enumerate(args):
                        if idx >= len(positional) or (tident, str(idx)) in FIELD_WRAPPERS:
                            continue
                        hit = _field_init_wrapper(aexpr, rel)
                        if hit is not None:
                            FIELD_WRAPPERS[(tident, str(idx))] = hit
                            _carriage_changed = True
    _build_rename_maps(codes, production_rels)
    compute_generic_uses(codes, production_rels)
    compute_return_projections(codes, production_rels)

def blank_use_statements(code):
    """`code` with every `use ...;` statement blanked: a use
    statement names a path — it is not a call of the item, and a
    `pub use` re-export is not a use of the wrapper's body."""
    out = list(code)
    for m in re.finditer(r"\buse\s+[^;]*;", code):
        for k in range(m.start(), m.end()):
            if out[k] != "\n":
                out[k] = " "
    return "".join(out)

def _det_type(ttext):
    """The type named by a simple type text — `Type`, `&Type`,
    `&mut Type`, with an optional lifetime or path prefix — or
    None when the type is not textually determinable in that
    simple form (a generic, a tuple, a function pointer)."""
    m = re.match(r"^(?:&\s*(?:'\w+\s+)?(?:mut\s+)?)?(?:\w+::)*(\w+)$", ttext.strip())
    return m.group(1) if m else None

def _split_top(text):
    parts, depth, cur = [], 0, ""
    prev = ""
    brace = 0
    angle = 0
    for ch in text:
        if brace > 0 and ch in "<>":
            pass
        elif ch in "([{[":
            depth += 1
            if ch == "{":
                brace += 1
        elif ch == "<":
            angle += 1
        elif ch in ")]>}":
            if ch == "}":
                brace -= 1
                depth -= 1
            elif ch == ">":
                # A function pointer's `->` never closes an
                # angle bracket, and a `>` at angle depth
                # zero is a comparison or a shift, never a
                # close (seam round 23, protest P3).
                if prev != "-" and angle > 0:
                    angle -= 1
            else:
                depth -= 1
        if ch == "," and depth == 0 and angle == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
        prev = ch
    if cur.strip():
        parts.append(cur)
    return parts

def _receiver_types(tname, sig, body, rel=None):
    """The receiver variable -> type map of one item, from the
    textually determinable forms (seam round 4, protest P1): a
    function parameter typed `Type`/`&Type`/`&mut Type`, the
    `Self` receiver inside `impl Type`, and a binding annotated
    with the type (`let name: Type = ...`). Types resolve to
    their identities with aliases expanded (seam round 6,
    protests P1/P10). Anything else — an unannotated binding,
    a field, an expression — is not in the map: its receiver
    type is undeterminable in this file, the computation's
    recorded limit."""
    out = {}
    i = sig.find("(")
    if i >= 0:
        depth, j = 1, i + 1
        while j < len(sig) and depth:
            if sig[j] == "(":
                depth += 1
            elif sig[j] == ")":
                depth -= 1
            j += 1
        for part in _split_top(sig[i + 1:j - 1]):
            part = part.strip()
            if not part:
                continue
            if re.match(r"^(?:&\s*(?:mut\s+)?|mut\s+)?self\b", part):
                if tname:
                    out["self"] = tname
                continue
            pm = re.match(r"^(?:mut\s+)?(\w+)\s*:\s*(.+)$", part, re.S)
            if pm:
                t = _det_id_deref(pm.group(2), rel=rel)
                if t:
                    out[pm.group(1)] = t
    for lm in re.finditer(r"\blet\s+(?:mut\s+)?(\w+)\s*:\s*([^=;]+)", body):
        t = _det_id_deref(lm.group(2), rel=rel)
        if t:
            out.setdefault(lm.group(1), t)
    return out

# ------------------------------------------------------- seam round 6: type
# identity (protest P10), alias expansion in receiver resolution
# (protest P1), pattern bindings (protest P2) and the Rust scope
# model for the self-defined exclusions (protest P5). Declared-type
# tables are keyed by a type's IDENTITY: its bare name when the
# crate's production text defines that name exactly once, and its
# qualified module path (file module plus inline-module chain)
# when it does not. A bare name with more than one production
# definition is NOT determinable — it joins the recorded limit —
# while a spelled path resolves to the definition it denotes.
TYPE_LOCS = {}  # bare name -> [(file, qualified, module chain, kind)]
FN_LOCS = {}  # bare name -> [(file, qualified, module chain, scope key)] of every production free function (seam round 32, protest P4)
ALIAS_TEXT = {}  # alias identity -> target type text
ALIAS_PARAMS = {}  # alias identity -> [generic parameter names in declaration order] (seam round 26, protest P1)
ALIAS_IDENTS = set()  # identities that are type aliases
NON_DROPPING_HEADS = {"ManuallyDrop", "MaybeUninit", "PhantomData"}
# ------------------------------------------------------- seam round 7: the
# rename maps (protest P1), the wrapper values (protest P2), the
# include! refusal (protest P3), the Deref step and the std Deref
# heads (protest P4), the std-platform channel (protest P6) and
# the per-file sys import census (protest P7). A descriptor is a
# (kind, key, home) tuple: ("free", original name, defining file)
# for a free function, ("type", identity, defining file) for a
# type, ("value", name, defining file) for a wrapper value.
WRAPPER_VALUES = {}  # wrapper value name -> the file that defines it
FREE_FN_DEFS = set()  # (file, name) of every production free function
PARAMS_FREE = {}  # free function name -> [parameter type texts]
PARAMS_METH = {}  # (defining type identity, method name) -> [parameter type texts]
GENERIC_PARAMS_FREE = {}  # free function name -> [generic type parameter names in declaration order] (seam round 24, protest P1)
GENERIC_PARAMS_METH = {}  # (defining type identity, method name) -> [generic type parameter names in declaration order] (seam round 24, protest P1)
DEREF_TARGETS = {}  # type identity -> its Deref/DerefMut target's identity
DEREF_TARGET_TEXT36 = {}  # type identity -> (recorded Target text, the impl's for-type generic arguments, the impl's generic parameters), for the substitution the Deref step performs (seam round 36, protest P4)
FILE_BINDINGS_RAW = {}  # file -> [(local name, scope key, segments, is_pub)]
FILE_RENAMES = {}  # file -> [(local name, scope key, descriptor)]
RENAME_CTX = {}  # local name -> descriptor, for the item being resolved
STD_BIND_CTX = {}  # local name -> the std hand-out path it denotes (seam round 28)
STD_CTX_REL = {}  # the file whose bindings STD_BIND_CTX records (seam round 30)
MOD_BIND_CTX = {}  # local name -> the module path segments it denotes (seam round 29)
MODULE_BINDINGS_CACHE = {}  # file -> its module bindings (seam round 29)
STD_CHASE_CACHE = {}  # (file, path) -> the std path it denotes through re-exports, or "" (seam round 29)


def _set_std_bind_ctx(rel):
    """The file's std hand-out bindings (seam round 28,
    protest P1): the local names the file's own `use`
    bindings bind to the std hand-out items — `std::mem`'s
    `take` and `replace`, and the `Deref` carriers `Box`,
    `Rc` and `Arc` under their std paths — recorded as the
    absolute path each denotes, so a call spelled through
    the binding (a bare `take(...)` after `use
    std::mem::take;`, a renamed carrier's `Mine::new(...)`)
    is read at the item it denotes, exactly as the same
    call spelled by its full path already is. Set for the
    file whose items are being resolved, beside
    RENAME_CTX; a file with no such binding leaves the
    context empty and every bare spelling unread, as
    before."""
    STD_BIND_CTX.clear()
    MOD_BIND_CTX.clear()
    STD_CTX_REL["rel"] = rel
    if rel is None:
        return
    MOD_BIND_CTX.update(_module_bindings(rel))
    for local, _scope, segs, _pub in FILE_BINDINGS_RAW.get(rel, []):
        if not segs:
            continue
        if segs[0] in ("std", "core", "alloc"):
            joined = "::".join(segs)
        elif local == "*":
            continue
        else:
            # The binding's resolved definition (seam round
            # 29, protest P4): a binding whose target is the
            # crate's own re-export of a std item denotes the
            # std item exactly as the direct binding does —
            # the context is recorded by the definition the
            # re-export chase reaches, not by the spelled
            # first segment of the consumer's own `use`.
            joined = _chase_std_path(rel, segs)
            if joined is None:
                continue
        if joined in ("std::mem::take", "std::mem::replace") or joined.rsplit("::", 1)[-1] in ("Box", "Rc", "Arc"):
            STD_BIND_CTX[local] = joined


def _std_ctx_rel():
    """The file whose items are being resolved, as
    _set_std_bind_ctx last recorded it (seam round 30,
    protest P3): the file a path-spelled call stands in,
    whose own module the re-export chase of the spelled
    path is anchored at, as the binding chase is anchored
    at the file whose context is set."""
    return STD_CTX_REL.get("rel")


def _chase_std_path(from_rel, segs, seen=()):
    """The std path the spelled path `segs` denotes through
    the production re-exports standing along it (seam round
    29, protest P4): an absolute std path denotes itself;
    any other path is followed through the `pub use`
    bindings of the files standing at its module path —
    root-confined, as _resolve_item is, and bounded by the
    recorded chase depth bound — until it reaches a std
    path or denotes no std item. Top-level results are
    cached per spelling file and path, as the chase is
    consulted for every binding of every file whose
    context is set."""
    if not segs:
        return None
    if segs[0] in ("std", "core", "alloc"):
        return "::".join(segs)
    if from_rel is None or len(seen) > CHASE_DEPTH_BOUND:
        return None
    if not seen:
        _hit29 = STD_CHASE_CACHE.get((from_rel, tuple(segs)))
        if _hit29 is not None:
            return _hit29 or None
    item = segs[-1]
    modpath = _resolve_modpath(from_rel, segs[:-1])
    out = None
    for cand in _candidate_files(modpath, from_rel):
        if out is not None:
            break
        for local, scope, bsegs, is_pub in FILE_BINDINGS_RAW.get(cand, []):
            if not is_pub or not _binding_stands_at(cand, scope, modpath):
                continue
            if local == item:
                anchors = [bsegs]
                if bsegs and bsegs[0] not in ("crate", "self", "super"):
                    anchors.append(["self"] + bsegs)
                for anchor in anchors:
                    key = (cand, tuple(anchor))
                    if key in seen:
                        continue
                    out = _chase_std_path(cand, anchor, seen + (key,))
                    if out is not None:
                        break
            elif local == "*":
                # A name defined in the glob's own module
                # is that module's item, never the glob's
                # import (seam round 31, protest P5): the
                # glob supplies the name only where the
                # module defines none.
                if any(r == cand and "::".join(qual.split("::")[:-1]) == modpath and _loc_module_scope32(_s31) for (r, qual, _c31, _k31, _s31) in TYPE_LOCS.get(item, [])):
                    continue
                # The stop completed to functions (seam
                # round 32, protest P4): a free function
                # defined in the glob's own module is that
                # module's item, never the glob's import,
                # exactly as a type standing there is.
                if any(r == cand and "::".join(qual.split("::")[:-1]) == modpath and _loc_module_scope32(_s32) for (r, qual, _c32, _s32) in FN_LOCS.get(item, [])):
                    continue
                # The glob branch carries its anchor (seam
                # round 31, protest P6): the glob's target
                # is resolved at the module the glob stands
                # in — the `self` anchor the named branch
                # keeps — exactly as the receiver chase
                # resolves the same link, so the two chases
                # agree at glob links.
                for anchor in (list(bsegs) + [item], ["self"] + list(bsegs) + [item]):
                    key = (cand, tuple(anchor))
                    if key in seen:
                        continue
                    out = _chase_std_path(cand, anchor, seen + (key,))
                    if out is not None:
                        break
            if out is not None:
                break
    if not seen:
        STD_CHASE_CACHE[(from_rel, tuple(segs))] = out or ""
    return out


def _module_bindings(rel):
    """The file's module bindings (seam round 29, protest
    P3): local name -> the module path segments the name
    denotes, for every `use` binding of the file whose
    target is a module. A crate module is known by the
    module map — a path standing in it (a declared file,
    an inline module, a file's own module path, a declared
    path) is a module's path, and a spelled path whose
    whole resolution is that path denotes the module,
    never an item standing in it; a std / core / alloc
    path whose last segment is a module's (lowercase)
    name denotes the external module it spells.
    Computed once per file and cached, beside the rename
    maps the same bindings feed."""
    if rel in MODULE_BINDINGS_CACHE:
        return MODULE_BINDINGS_CACHE[rel]
    out = {}
    if rel is not None:
        _mods29 = set(FILE_MODULES.values()) | set(MODULE_FILE) | set(INLINE_MOD_HOME) | set(FILE_DECLARED_PATHS.values())
        for local, _scope, segs, _pub in FILE_BINDINGS_RAW.get(rel, []):
            if local == "*" or not segs:
                continue
            denoted = None
            _cands29 = []
            _mp29 = _resolve_modpath(rel, segs)
            if _mp29:
                _cands29.append(_mp29)
            if segs[0] not in ("crate", "self", "super"):
                _mp29 = _resolve_modpath(rel, ["self"] + segs)
                if _mp29 and _mp29 not in _cands29:
                    _cands29.append(_mp29)
            for _cand29 in _cands29:
                if _cand29 in _mods29:
                    denoted = _cand29
                    break
            if denoted is None and segs[0] in ("std", "core", "alloc") and segs[-1][:1].islower():
                denoted = "::".join(segs)
            if denoted is not None:
                out.setdefault(local, denoted.split("::"))
    MODULE_BINDINGS_CACHE[rel] = out
    return out


def _expand_module_segs(rel, segs):
    """Path segments with the file's module bindings
    substituted at the segment position they stand in
    (seam round 29, protest P3): the first segment past
    any crate / self / super anchor that the file binds
    to a module stands at the module the binding denotes,
    as an item rename already substitutes at the last
    segment. With no file (`rel` None), the standing
    MOD_BIND_CTX — the module bindings of the file whose
    items are being resolved, set beside STD_BIND_CTX —
    supplies the substitutions."""
    if not segs:
        return segs
    segs = list(segs)
    _binds29 = _module_bindings(rel) if rel is not None else MOD_BIND_CTX
    for _pass29 in range(4):
        i = 0
        while i < len(segs) and segs[i] in ("crate", "self", "super"):
            i += 1
        if i >= len(segs):
            break
        _den29 = _binds29.get(segs[i])
        if _den29 is None or list(_den29) == segs[i:]:
            break
        segs = segs[:i] + list(_den29) + segs[i + 1:]
    return segs
TEXTS_BY_RMAP = {}  # id(receiver map) -> (the map itself, its item's declared type texts) (seam round 27, protest P1)
# ------------------------------------------------------- seam round 10: the
# sys-derived names (protest P1), the trait default method wrappers
# (protest P2), the wrapper-yielding functions (protest P8), the
# macro channel (protest P10) and the declared module paths
# (protest P9).
TRAIT_WRAPPERS = {}  # (trait name, method name) -> defining file
TRAIT_IMPLS = {}  # receiver type bare name -> {trait bare names it implements}
SYS_DERIVED_TYPES = set()  # alias identities whose target resolves into sys
SYS_DERIVED_TYPE_HOME = {}  # sys-derived type identity -> the alias's file
SYS_DERIVED_VALUES = {}  # const/static name -> home; initialiser resolves into sys
WRAPPER_YIELD_FREE = {}  # free function name -> home; a return expression yields a wrapper
MACRO_REACHING = {}  # macro name -> defining file; its expansion reaches sys / a wrapper
FILE_DECLARED_PATHS = {}  # rel -> the module path its `mod` declaration places it at
# ------------------------------------------------------- seam round 11: the
# yield derivation over methods (protest P3) and returned closures
# (protest P5), struct-field carriage (protest P4), blanket-impl
# trait defaults keyed by trait (protest P2), calls in initialiser
# position (protest P6), sys's own macros (protest P7), re-export
# bindings as derivation sources (protest P8), the inline-module
# module map (protests P1/P10) and the generated-module refusal
# (protest P9).
WRAPPER_YIELD_METH = {}  # (defining type identity, method name) -> home; a return expression yields a wrapper
FIELD_WRAPPERS = {}  # (struct identity, field name) -> (wrapper display, wrapper home) the field is initialised from
BLANKET_TRAITS = set()  # trait names a blanket impl supplies to every type
SYS_DERIVED_FNS = {}  # re-export binding name -> home; the binding renames a sys function
SYS_KINDS = {}  # sys item name -> "type" / "value" / "fn", from sys's own declarations
INLINE_MOD_HOME = {}  # inline module path -> the file that declares the module
SCOPE_MODPATH = {}  # (file, scope key) -> the module path bindings standing in that scope stand at
FN_BODIES = {}  # (file, free function name) -> body text, for the initialiser-call derivation
MISSING_MOD_TARGETS = {}  # file -> [module names it declares whose target file is absent from the tree]
# ------------------------------------------------------- seam round 12: the
# initialiser-call derivation over associated functions (protest
# P2) and the yield derivation over trait default methods
# (protest P5).
METH_BODIES = {}  # (type identity, method name) -> (defining file, body text), for the initialiser-call derivation
TRAIT_YIELD = {}  # (trait name, method name) -> defining file; a trait default whose return yields a wrapper
# ------------------------------------------------------- seam round 13: trait
# overrides and blanket-impl bounds (protest P8).
TRAIT_OVERRIDES = {}  # (receiver type bare name, trait name, method name) -> defining file; the receiver type's own impl defines the method
BLANKET_BOUNDS = {}  # blanket trait name -> {bound trait bare names its blanket impl requires}
SUPERTRAITS = {}  # trait bare name -> {supertrait bare names its declaration names} (seam round 14, protest P11)
VALUE_TYPES = {}  # const/static name -> the identity its declared type denotes (seam round 14, protest P4)
CONST_ITEMS33 = {}  # const/static name -> [(file, declared type text, initialiser text)] of every production const or static item, associated ones included (seam round 33, protest P3)
TRAIT_METH_RETURN33 = {}  # (trait name, method name) -> the declared return type text of a trait method standing with a default body (seam round 33, protest P3)
FN_IN_FN33 = {}  # (file, qualified path) -> whether the free definition stands inside a function body (seam round 33, protest P2)
FN_VALUE_FROM = {}  # const/static name -> the declared return type text of its fn-shaped declared type, where its initialiser is a `from` path value (seam round 31, protest P7)
FREE_FN_FROM = {}  # (file, free function name) -> (denoted Self text, the fn type's declared return text) where a return expression is a `from` path value (seam round 32, protest P2)
FIELD_FROM = {}  # (struct identity, field name) -> (denoted Self text, the field fn type's declared return text) where a construction initialises the field from a `from` path value (seam round 32, protest P2)

SYS_MINT_NAMES = list(EXTENDED_MINT)
# The std heads whose Deref target is their first generic argument
# (seam round 7, protest P4), recorded beside the non-dropping
# heads above: the language's smart pointers and lock guards,
# whose documented semantics are that the value derefs to its
# payload.
STD_DEREF_HEADS = {"Box", "Arc", "Rc", "Cow", "ManuallyDrop", "MutexGuard", "RwLockReadGuard", "RwLockWriteGuard"}
INCLUDE_RE = re.compile(r"\binclude\s*!")
STD_PLATFORM_RE = re.compile(r"\bstd::os::\w+(?:::\w+)*")
# The pure set's pinned std-platform occurrences (seam round 7,
# protest P6), in the exclusions idiom: environment.rs's UTF-16
# encoding logic names std's Windows OsStrExt — the one
# occurrence that stands, with its reason recorded in src/lib.rs
# and in the graph; any other std-platform occurrence in a
# pinned file fails by name.
STD_PLATFORM_PINNED = {STD_PLATFORM_FILE_REL: ["std::os::windows::ffi::OsStrExt"]}

# ------------------------------------------------------- seam round 9: the
# own-extern census (protest P3), the arch channel (protest P7) and
# the glob-root name tables for the resolution censuses (protests
# P4/P7). An extern declaration is censused in its own right
# outside the two recorded declaration homes; the arch channel
# stands beside the std-platform channel with an empty pin — the
# tree carries no live arch occurrence in any production file.
EXTERN_DECL_HOMES = {_layout_resolve_keyname(_name) for _name in _layout_path("pins.extern_homes")}
ARCH_RE = re.compile(r"\b(?:std|core)::arch::\w+(?:::\w+)*")
ARCH_PINNED = {}
STD_OS_GLOB_NAMES = {
    "std": ["os"],
    "std::os": ["windows", "unix", "linux", "android", "ios", "macos", "freebsd", "netbsd", "openbsd", "dragonfly", "solaris", "illumos", "haiku", "redox", "fuchsia", "wasi", "emscripten", "hermit", "uefi", "vxworks", "aix", "hurd"],
    "std::os::windows": ["ffi", "fs", "io", "net", "process", "thread"],
    "std::os::unix": ["ffi", "fs", "io", "net", "process", "thread"],
}
ARCH_GLOB_NAMES = {
    "std::arch": ["x86", "x86_64", "aarch64", "arm", "arm64ec", "riscv32", "riscv64", "loongarch32", "loongarch64", "wasm32", "powerpc", "powerpc64", "s390x", "sparc64", "mips64", "hexagon"],
    "core::arch": ["x86", "x86_64", "aarch64", "arm", "arm64ec", "riscv32", "riscv64", "loongarch32", "loongarch64", "wasm32", "powerpc", "powerpc64", "s390x", "sparc64", "mips64", "hexagon"],
}

# ------------------------------------------------------- seam round 8: the
# glob rename entries (protest P1), the std-platform census by
# resolution (protest P2) and the re-export chase bound, recorded
# and failing closed (protest P3). The chase that resolves a
# spelled path follows at most CHASE_DEPTH_BOUND re-export hops
# and enumerates at most CHASE_VARIANT_BOUND module-path
# variants; exhausting either bound where it decides a
# resolution is recorded in CHASE_FAILURES and both computations
# refuse with the recorded messages (see _record_chase_failure)
# — never a silent None read as "not a wrapper". The deepest
# live re-export chain in the tree measures 2 hops.
CHASE_DEPTH_BOUND = 8
CHASE_VARIANT_BOUND = 16
CHASE_FAILURES = []
_VARIANT_HITS = []
_EXPORT_NAMES_CACHE = {}


def _file_module_path(rel):
    parts = rel[:-3].split("/") if rel.endswith(".rs") else rel.split("/")
    if parts in (["src", "lib"], ["src", "main"]):
        return ""
    if parts and parts[0] == "src":
        parts = parts[1:]
    if parts and parts[-1] == "mod":
        parts = parts[:-1]
    return "::".join(parts)

def _inline_mods(code):
    """The inline modules of `code` as (name, brace, end)."""
    out = []
    for m in re.finditer(r"\bmod\s+(\w+)\s*\{", code):
        brace = m.end() - 1
        out.append((m.group(1), brace, _brace_match(code, brace)))
    return out

def _mod_chain_at(code, pos):
    chain = [(a, n) for n, a, b in _inline_mods(code) if a < pos < b]
    chain.sort()
    return tuple(n for _a, n in chain)

def _build_type_locs(codes, production_rels, raws=None):
    TYPE_LOCS.clear()
    FN_LOCS.clear()
    ALIAS_TEXT.clear()
    ALIAS_PARAMS.clear()
    ALIAS_IDENTS.clear()
    FILE_MODULES.clear()
    MODULE_FILE.clear()
    FILE_USES.clear()
    REACHABLE.clear()
    for rel in production_rels:
        FILE_MODULES[rel] = _file_module_path(rel)
        MODULE_FILE[_file_module_path(rel)] = rel
        FILE_USES[rel] = _use_paths(codes[rel])
        FILE_BINDINGS_RAW[rel] = _rename_bindings(codes[rel], _scope_spans(codes[rel]))
    # The inline modules (seam round 11, protests P1/P10):
    # an inline `mod` stands at a module path no file stands
    # at, so the module map is built from declarations, not
    # only from files — every inline module is recorded as a
    # candidate home at its path, and every scope's module
    # path is recorded with it: a module scope stands at its
    # own path, a function scope at the path of the module
    # that encloses it.
    # The declared module paths (seam round 10, protest P9):
    # a file's module path is also the path its `mod`
    # declaration places it at — the declaration resolved
    # exactly as the production definition resolves it,
    # `#[path]` honoured, file-module children of an inline
    # module standing under that module — recorded beside
    # the location path, which the filename alone gives.
    FILE_DECLARED_PATHS.clear()
    loaded = _path_loaded_files(raws) if raws is not None else set()
    if raws is not None:
        prod = set(production_rels)
        for prel in production_rels:
            rawp = raws.get(prel)
            if rawp is None:
                continue
            codep = blank_comments_and_literals(rawp)
            base = _compiler_child_base(prel, loaded)
            mods = _module_decls(codep)
            inlines = [(n, s, sp) for n, k, s, sp in mods if k == "inline"]

            def ctx_dir(pos, _inlines=inlines, _base=base, _raw=rawp, _code=codep, _fdir=posixpath.dirname(prel)):
                chain = [iv for iv in _inlines if iv[2][0] < pos < iv[2][1]]
                chain.sort(key=lambda iv: iv[2][1] - iv[2][0], reverse=True)
                ctx = _base
                for i2, (n, s, _sp) in enumerate(chain):
                    pv = _path_attr_value(_raw, _code, s)
                    if pv is not None and i2 == 0:
                        # A #[path] on an inline module (seam
                        # round 12, protest P7) resolves
                        # relative to the directory containing
                        # the declaring FILE, as Rust resolves
                        # it — not to the file's module
                        # directory.
                        ctx = _fdir + "/" + pv
                    else:
                        ctx = ctx + "/" + (pv if pv is not None else n)
                return ctx

            def ctx_path(pos, _inlines=inlines, _prel=prel):
                chain = [iv for iv in _inlines if iv[2][0] < pos < iv[2][1]]
                chain.sort(key=lambda iv: iv[2][1] - iv[2][0], reverse=True)
                _droot = FILE_DECLARED_PATHS.get(_prel)
                segs = [s for s in (_droot.split("::") if _droot else _file_module_path(_prel).split("::")) if s]
                return segs + [iv[0] for iv in chain]

            for name, kind, start, _sp in mods:
                if kind != "file":
                    continue
                pv = _path_attr_value(rawp, codep, start)
                ctx = ctx_dir(start)
                targets = _mod_decl_targets(prel, name, pv, ctx, not any(sp[0] < start < sp[1] for _n2, _s2, sp in inlines))
                declared = "::".join(ctx_path(start) + [name])
                for cand in targets:
                    if cand in prod:
                        FILE_DECLARED_PATHS.setdefault(cand, declared)
        for prel in production_rels:
            rawp = raws.get(prel)
            if rawp is None:
                continue
            codep = blank_comments_and_literals(rawp)
            base = _compiler_child_base(prel, loaded)
            mods = _module_decls(codep)
            inlines = [(n, s, sp) for n, k, s, sp in mods if k == "inline"]

            def ctx_dir(pos, _inlines=inlines, _base=base, _raw=rawp, _code=codep, _fdir=posixpath.dirname(prel)):
                chain = [iv for iv in _inlines if iv[2][0] < pos < iv[2][1]]
                chain.sort(key=lambda iv: iv[2][1] - iv[2][0], reverse=True)
                ctx = _base
                for i2, (n, s, _sp) in enumerate(chain):
                    pv = _path_attr_value(_raw, _code, s)
                    if pv is not None and i2 == 0:
                        # A #[path] on an inline module (seam
                        # round 12, protest P7) resolves
                        # relative to the directory containing
                        # the declaring FILE, as Rust resolves
                        # it — not to the file's module
                        # directory.
                        ctx = _fdir + "/" + pv
                    else:
                        ctx = ctx + "/" + (pv if pv is not None else n)
                return ctx

            def ctx_path(pos, _inlines=inlines, _prel=prel):
                chain = [iv for iv in _inlines if iv[2][0] < pos < iv[2][1]]
                chain.sort(key=lambda iv: iv[2][1] - iv[2][0], reverse=True)
                _droot = FILE_DECLARED_PATHS.get(_prel)
                segs = [s for s in (_droot.split("::") if _droot else _file_module_path(_prel).split("::")) if s]
                return segs + [iv[0] for iv in chain]

            for name, kind, start, _sp in mods:
                if kind != "file":
                    continue
                pv = _path_attr_value(rawp, codep, start)
                ctx = ctx_dir(start)
                targets = _mod_decl_targets(prel, name, pv, ctx, not any(sp[0] < start < sp[1] for _n2, _s2, sp in inlines))
                declared = "::".join(ctx_path(start) + [name])
                for cand in targets:
                    if cand in prod:
                        FILE_DECLARED_PATHS[cand] = declared
        for drel, dpath in FILE_DECLARED_PATHS.items():
            MODULE_FILE.setdefault(dpath, drel)
    INLINE_MOD_HOME.clear()
    SCOPE_MODPATH.clear()
    for rel in production_rels:
        code = codes[rel]
        spans = _scope_spans(code)
        base = FILE_DECLARED_PATHS.get(rel) or _file_module_path(rel)
        modpaths = {}
        for s in spans:
            if s["kind"] != "mod":
                continue
            chain = _mod_chain_at(code, s["start"] + 1)
            modpaths[s["key"]] = "::".join(p for p in [base, *chain] if p)
        for mp, home_rel in ((mp, rel) for mp in modpaths.values()):
            INLINE_MOD_HOME.setdefault(mp, home_rel)
        for s in spans:
            if s["key"] in modpaths:
                SCOPE_MODPATH[(rel, s["key"])] = modpaths[s["key"]]
                continue
            enc = [o for o in spans if o["kind"] == "mod" and o["start"] < s["start"] < o["end"]]
            if enc:
                enc.sort(key=lambda o: o["end"] - o["start"])
                SCOPE_MODPATH[(rel, s["key"])] = modpaths[enc[0]["key"]]
    for name, locs in list(TYPE_LOCS.items()):
        pass
    for rel in production_rels:
        code = codes[rel]
        base = FILE_DECLARED_PATHS.get(rel) or _file_module_path(rel)
        spans = _scope_spans(code)
        for _fn32, _ft32, _fs32, _fb32, _fo32 in typed_items(code):
            if _ft32 is not None:
                continue
            _fchain32 = _mod_chain_at(code, _fo32)
            _fqual32 = "::".join(p for p in [base, *_fchain32, _fn32] if p)
            FN_LOCS.setdefault(_fn32, []).append((rel, _fqual32, _fchain32, _scope_key_of(spans, _fo32)))
            FN_IN_FN33[(rel, _fqual32)] = any(_s33["kind"] == "fn" for _s33 in _scopes_at(spans, _fo32))
        for m in re.finditer(r"\b(?:struct|enum|union)\s+(\w+)", code):
            name = m.group(1)
            chain = _mod_chain_at(code, m.start())
            qual = "::".join(p for p in [base, *chain, name] if p)
            TYPE_LOCS.setdefault(name, []).append((rel, qual, chain, "type", _scope_key_of(spans, m.start())))
        for m in re.finditer(r"\btype\s+(\w+)\s*(?:<[^;{]*>)?\s*=\s*([^;]+);", code):
            name = m.group(1)
            chain = _mod_chain_at(code, m.start())
            qual = "::".join(p for p in [base, *chain, name] if p)
            TYPE_LOCS.setdefault(name, []).append((rel, qual, chain, "alias", _scope_key_of(spans, m.start())))
    for name, locs in TYPE_LOCS.items():
        for rel, qual, chain, kind, _skey in locs:
            if kind != "alias":
                continue
            ident = name if len(locs) == 1 else qual
            ALIAS_IDENTS.add(ident)
    for locs in TYPE_LOCS.values():
        for r, qual, _c, _k, _s in locs:
            MODULE_FILE.setdefault("::".join(qual.split("::")[:-1]), r)
    # Alias target texts, keyed by the alias's identity.
    for rel in production_rels:
        code = codes[rel]
        base = FILE_DECLARED_PATHS.get(rel) or _file_module_path(rel)
        for m in re.finditer(r"\btype\s+(\w+)\s*(?:<[^;{]*>)?\s*=\s*([^;]+);", code):
            name = m.group(1)
            locs = TYPE_LOCS.get(name, [])
            chain = _mod_chain_at(code, m.start())
            qual = "::".join(p for p in [base, *chain, name] if p)
            ident = name if len(locs) == 1 else qual
            ALIAS_TEXT[ident] = re.sub(r"\s+", " ", m.group(2).strip())
            _gm26 = re.match(r"type\s+\w+\s*(?:<([^;{]*?)>)?\s*=", code[m.start():])
            _gps26 = []
            if _gm26 and _gm26.group(1):
                for _part26 in _split_top(_gm26.group(1)):
                    _part26 = _part26.strip()
                    _pm26 = re.match(r"(?:const\s+)?(\w+)", _part26)
                    if _pm26 and not _part26.startswith("'"):
                        _gps26.append(_pm26.group(1))
            ALIAS_PARAMS[ident] = _gps26

def _loc_module_scope32(scope_key):
    """Whether a definition's recorded scope key stands at
    a module — the file's top level (None) or an inline
    module — rather than inside a function body (seam
    round 32, the wsGlobLocal32 joint, executed): a
    definition inside a function body is that body's
    item, keyed by its scope, and no module path denotes
    it, so it neither stops a glob chase nor answers a
    spelled module path."""
    return scope_key is None or (isinstance(scope_key, tuple) and len(scope_key) > 0 and scope_key[0] == "mod")


def _ident_of(name, pathsegs):
    """The identity a spelled type denotes: `name` with the
    path segments spelled before it (crate/self/super segments
    are resolution noise for the suffix match). A bare name
    with exactly one production definition is that definition;
    a bare name with more than one is NOT determinable (None);
    a spelled path denotes the definition whose qualified
    path it suffix-matches, when exactly one matches."""
    locs = TYPE_LOCS.get(name, [])
    if not locs:
        return None
    segs = [s for s in pathsegs if s not in ("crate", "self", "super")]
    if segs:
        cand = []
        for rel, qual, chain, kind, _sk in locs:
            if not _loc_module_scope32(_sk):
                continue
            qsegs = qual.split("::") if qual else []
            if len(qsegs) >= len(segs) + 1 and qsegs[-1] == name and qsegs[-len(segs) - 1:-1] == segs:
                cand.append(name if len(locs) == 1 else qual)
        return cand[0] if len(cand) == 1 else None
    if len(locs) == 1:
        return name
    return None

def _disp(ident):
    return ident.split("::")[-1] if ident else ident

FILE_MODULES = {}  # rel -> the module path of the file's root
MODULE_FILE = {}   # module path -> rel of the file standing at it
FILE_USES = {}     # rel -> the file's use paths, as segment lists
REACHABLE = {}     # rel -> set of module paths its bare names can reach

def _use_paths(code):
    """Every `use` path in the file, braces expanded, as a list
    of segment lists (seam round 6 completion: the scope model
    reads use statements to know what a bare name can denote)."""
    paths = []
    def rec(prefix, text):
        text = text.strip()
        if text.startswith("{"):
            end = text.rfind("}")
            for part in _split_top(text[1:end]):
                rec(prefix, part)
            return
        segs = [s.strip() for s in text.split("::") if s.strip()]
        segs = [s for s in segs if s != "as" ]
        if segs:
            paths.append(prefix + segs)
    for m in re.finditer(r"\buse\s+([^;]+);", code):
        rec([], m.group(1))
    return paths

def _resolve_use(file_mod, segs):
    """(module path, is_glob) a use path resolves against the
    file's own module path: the module the named item lives in,
    or the glob-imported module itself."""
    glob = bool(segs) and segs[-1] == "*"
    core = segs[:-1] if glob else list(segs)
    if not core:
        return None
    fm = file_mod.split("::") if file_mod else []
    if core[0] == "crate":
        base, rest = [], core[1:]
    elif core[0] == "self":
        base, rest = fm, core[1:]
    elif core[0] == "super":
        base, rest = list(fm), core
        while rest and rest[0] == "super":
            base = base[:-1]
            rest = rest[1:]
    else:
        base, rest = [], core
    if glob:
        return "::".join(base + rest), True
    return "::".join(base + rest[:-1]), False

def _reachable_modules(rel):
    """The module paths whose definitions a bare name in file
    `rel` can denote: its own module, the modules its use
    statements name items from, and — transitively — the glob
    targets of glob-imported modules (a glob import carries
    the target's own glob re-exports with it). A definition in
    a module outside this set cannot be meant by a bare name
    in the file at all (seam round 6, protest P10 as
    adjudicated: in the extend subtree the bare name Token
    denotes the codec alias, the only Token its imports
    supply — never the credential Token of auth::secrets)."""
    if rel in REACHABLE:
        return REACHABLE[rel]
    own = FILE_MODULES.get(rel, "")
    reach = {own}
    glob_frontier = []
    for segs in FILE_USES.get(rel, []):
        r = _resolve_use(own, segs)
        if r is None:
            continue
        reach.add(r[0])
        if r[1]:
            glob_frontier.append(r[0])
    seen = set(glob_frontier)
    while glob_frontier:
        nxt = []
        for mod in glob_frontier:
            frel = MODULE_FILE.get(mod)
            if frel is None:
                continue
            fmod = FILE_MODULES.get(frel, "")
            for segs in FILE_USES.get(frel, []):
                r = _resolve_use(fmod, segs)
                if r is not None and r[1] and r[0] not in seen:
                    seen.add(r[0])
                    reach.add(r[0])
                    nxt.append(r[0])
        glob_frontier = nxt
    REACHABLE[rel] = reach
    return reach

def _resolve_bare(name, rel):
    """The identity a bare naming of `name` in file `rel`
    denotes, or None when it is not determinable there: the
    file's own definition when it has one, else the unique
    definition in a module the file's imports reach, else
    nothing. A name with no production definition denotes
    itself (its identity is its name)."""
    if rel is not None:
        # A renamed use binding decides (seam round 28,
        # protest P2): the file's own `use ... as Mine`
        # binds the name to the item the binding denotes
        # exactly as a plain binding does — the rename map
        # is read from the file's own text, so the identity
        # it records is the name's meaning in this file,
        # ahead of any reachability reading. Two bindings
        # of the name to different identities decide
        # nothing: the recorded bare-name limit stands.
        _ren28 = {desc[1] for local, _scope, desc in FILE_RENAMES.get(rel, [])
                  if local == name and desc[0] == "type"}
        if len(_ren28) == 1:
            return _ren28.pop()
        if len(_ren28) > 1:
            return None
    locs = TYPE_LOCS.get(name, [])
    if not locs:
        return name
    if len(locs) == 1:
        return name
    own = [qual for (r, qual, _c, _k, _s) in locs if r == rel]
    if len(own) == 1:
        return own[0]
    if rel is None:
        return None
    reach = _reachable_modules(rel)
    cand = [qual for (r, qual, _c, _k, _s) in locs
            if "::".join(qual.split("::")[:-1]) in reach]
    if len(cand) == 1:
        return cand[0]
    return None

def _alias_home(ident):
    locs = TYPE_LOCS.get(_disp(ident), [])
    for r, qual, _c, _k, _s in locs:
        if (ident if len(locs) == 1 else qual) == ident:
            return r
    return None

def _det_id(ttext, expand=True, rel=None):
    """The identity denoted by a simple type text — `Type`,
    `&Type`, `&mut Type`, with an optional lifetime or path
    prefix — or None when the text is not determinable in that
    simple form (a tuple, a function pointer, or a bare
    name with more than one production definition). A
    generic instantiation is determinable in the two forms
    seam round 16 records (protests P1/P2): a crate-defined
    head denotes its defining type, and a `Result` /
    `Option` instantiation denotes its whole text, so the
    payload step can be taken on it. With expansion (the default, seam round 6
    protest P1), an alias identity resolves through ALIASES
    to its head, transitively."""
    if ttext is None:
        return None
    t = re.sub(r"\s+", " ", ttext.strip())
    t = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", t).strip()
    t = re.sub(r"<\s*(?:'\w+|'_)(?:\s*,\s*(?:'\w+|'_))*\s*>", "", t).strip()
    gm = re.match(r"^((?:\w+\s*::\s*)*)(\w+)\s*<", t)
    if gm and t.endswith(">"):
        # A generic instantiation (seam round 16, protests
        # P1 and P2): a crate-defined head's identity is its
        # defining type — `Wrap<2>` and `GenScalar<fn...>`
        # denote the types their heads name, exactly as the
        # bare spelling does — while a `Result` / `Option`
        # instantiation keeps its whole text as its
        # identity, so the payload step (unwrap / expect /
        # as_ref / as_mut / ok / `?`) can be taken on it in _method_return,
        # _meth_return_text and _expr_type_at. Any other
        # generic head is not determinable in this form.
        gsegs = [s.strip() for s in gm.group(1).split("::") if s.strip()]
        gname = gm.group(2)
        if rel is not None:
            gsegs = _expand_module_segs(rel, gsegs)
        if gname in TYPE_LOCS:
            ident = _ident_of(gname, gsegs) if gsegs else _resolve_bare(gname, rel)
        elif rel is not None and gsegs and (_desc30 := _resolve_item(rel, gsegs + [gname])) is not None and _desc30[0] == "type":
            ident = _desc30[1]
        elif gname in ("Result", "Option"):
            return re.sub(r"\s+", " ", t)
        else:
            return None
    else:
        m = re.match(r"^((?:\w+\s*::\s*)*)(\w+)$", t)
        if not m:
            return None
        segs = [s.strip() for s in m.group(1).split("::") if s.strip()]
        if rel is not None:
            segs = _expand_module_segs(rel, segs)
        ident = _ident_of(m.group(2), segs) if segs else _resolve_bare(m.group(2), rel)
        if ident is None and rel is not None and segs:
            # A re-export name standing as the type (seam
            # round 30, protest P4): the spelled name is no
            # definition's name — it is a link in a re-export
            # chain, in whichever module the link stands —
            # and the type it denotes is the definition the
            # chase reaches, as a receiver arriving through
            # a root link already was read.
            _desc30 = _resolve_item(rel, segs + [m.group(2)])
            if _desc30 is not None and _desc30[0] == "type":
                ident = _desc30[1]
    if ident is None or not expand:
        return ident
    seen = set()
    while ident in ALIAS_IDENTS and ident not in seen:
        seen.add(ident)
        nxt = _det_id(ALIAS_TEXT.get(ident, ""), expand=False, rel=_alias_home(ident))
        if nxt is None:
            break
        ident = nxt
    return ident

def _type_ident_at(rel, code, name, pos):
    """The identity of the definition of `name` standing in
    file `rel` at the declaration containing pos — the table
    key for a definition read in its own file."""
    locs = TYPE_LOCS.get(name, [])
    if not locs:
        return name
    if len(locs) == 1:
        return name
    chain = _mod_chain_at(code, pos)
    for r, qual, ch, kind, _sk in locs:
        if r == rel and ch == chain:
            return qual
    for r, qual, ch, kind, _sk in locs:
        if r == rel:
            return qual
    return name

def _result_option_parts(ttext):
    """The (head, argument texts) of a `Result<...>` /
    `Option<...>` type text or identity, or None (seam round
    16, protest P1): the two std heads whose payload step
    the use arms read — a reference prefix is stripped, a
    path prefix on the head is resolution noise. Argument
    splitting is top-level, with a function pointer's `->`
    read as two neutral characters, not an angle close."""
    if ttext is None:
        return None
    t = re.sub(r"\s+", " ", ttext.strip())
    t = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", t).strip()
    m = re.match(r"^(?:\w+\s*::\s*)*(Result|Option)\s*<(.+)>$", t, re.S)
    if not m:
        return None
    inner = m.group(2)
    parts, depth, cur = [], 0, ""
    brace = 0
    angle = 0
    i = 0
    while i < len(inner):
        if inner[i:i + 2] == "->":
            cur += "->"
            i += 2
            continue
        ch = inner[i]
        if brace > 0 and ch in "<>":
            pass
        elif ch in "([{[":
            depth += 1
            if ch == "{":
                brace += 1
        elif ch == "<":
            angle += 1
        elif ch in ")]>}":
            if ch == "}":
                brace -= 1
                depth -= 1
            elif ch == ">":
                if angle > 0:
                    angle -= 1
            else:
                depth -= 1
        if ch == "," and depth == 0 and angle == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
        i += 1
    if cur.strip():
        parts.append(cur)
    return m.group(1), [p.strip() for p in parts]

def _payload_text(ttext):
    """The payload type text of a Result/Option type text —
    its first generic argument — or None."""
    parts = _result_option_parts(ttext)
    return parts[1][0] if parts and parts[1] else None

def _as_ref_text(ttext):
    """The type text `as_ref` returns on a Result/Option
    type text — the same head over references to its
    arguments — or None."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    if head == "Result" and len(args) >= 2:
        return "Result<&" + args[0] + ", &" + args[1] + ">"
    if head == "Option" and args:
        return "Option<&" + args[0] + ">"
    return None

def _as_mut_text(ttext):
    """The type text `as_mut` returns on a Result/Option
    type text — the same head over mutable references to
    its arguments — or None (seam round 18, protest P8):
    `as_ref`'s mutable twin, declared in the same place,
    over the same payload."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    if head == "Result" and len(args) >= 2:
        return "Result<&mut " + args[0] + ", &mut " + args[1] + ">"
    if head == "Option" and args:
        return "Option<&mut " + args[0] + ">"
    return None

def _ok_text(ttext):
    """The type text `ok` returns on a Result type text —
    the payload under the sibling container `Option`, the
    error discarded as `unwrap` discards it — or None
    (seam round 18, protest P8)."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    if head == "Result" and args:
        return "Option<" + args[0] + ">"
    return None

def _copied_text(ttext):
    """The type text `copied` / `cloned` returns on a
    Result/Option type text (seam round 20, protest P1):
    the same head over the payload VALUES — the container
    holds references to its payloads, and the step returns
    the payloads themselves, made by copying, exactly as
    `Clone` copies — except that the step is declared on
    the container and opens it, which is the separation
    the rider now states. A non-reference argument stands
    as written."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts

    def unref(a):
        return re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", a.strip()).strip()

    if head == "Result" and len(args) >= 2:
        return "Result<" + unref(args[0]) + ", " + unref(args[1]) + ">"
    if head == "Option" and args:
        return "Option<" + unref(args[0]) + ">"
    return None


def _deref_target_text(ttext):
    """The text of what a type text's value dereferences
    to (seam round 20, protest P1): a reference's target,
    a std Deref head's first generic argument, or a crate
    type's recorded Deref target — or None."""
    if ttext is None:
        return None
    t = re.sub(r"\s+", " ", ttext.strip())
    _ref30 = t.startswith("&")
    t = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", t).strip()
    m = re.match(r"^(?:\w+\s*::\s*)*(\w+)\s*<", t)
    if m and m.group(1) in STD_DEREF_HEADS:
        arg = _generic_arg(t, 0)
        if arg is not None:
            return arg.strip()
    ident = _det_id(t)
    if ident is not None and ident in DEREF_TARGETS and DEREF_TARGETS[ident] is not None:
        _rec36 = (globals().get("DEREF_TARGET_TEXT36") or {}).get(ident)
        if _rec36 is not None and _rec36[1] and "<" in t:
            # The substitution (seam round 36, protest P4):
            # the recorded Target stands in the impl's own
            # parameters; at a holder standing instantiated,
            # each for-type argument naming an impl parameter
            # is replaced by the holder's argument at that
            # position, simultaneously, as a field's declared
            # type is read through its holder — for in-tree
            # recorded targets as for the std heads above.
            _tt36, _fa36, _ip36 = _rec36
            _lt36 = t.find("<")
            _gt36 = _angle_match(t, _lt36)
            _ha36 = [p.strip() for p in _split_top(t[_lt36 + 1:_gt36 - 1])] if _gt36 > _lt36 else []
            _map36 = {}
            for _i36, _f36 in enumerate(_fa36):
                if _i36 < len(_ha36) and _f36 in _ip36:
                    _map36[_f36] = _ha36[_i36]
            if _map36:
                _pat36 = re.compile("|".join(re.escape(p) + r"\b" if p.startswith("'") else r"\b" + re.escape(p) + r"\b" for p in _map36))
                return _pat36.sub(lambda _m36: _map36[_m36.group(0)], _tt36)
        return _disp(DEREF_TARGETS[ident])
    if _ref30 and ident is not None:
        # A plain reference (seam round 30, protest P1):
        # `*&T` is `T` itself — the reference the caller
        # spelled is the whole of the deref, and its target
        # is the text it references, as the explicit-deref
        # arm already reads a reference operand.
        return t
    return None


def _as_deref_text(ttext, mutable=False):
    """The type text `as_deref` / `as_deref_mut` returns
    on a Result/Option type text (seam round 20, protest
    P1): the same head over references to what each
    argument dereferences to — the payload exposed by
    reference, through the payload's own Deref — or
    None."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    ref = "&mut " if mutable else "&"

    def dref(a):
        d = _deref_target_text(a)
        return ref + d if d is not None else None

    if head == "Result" and len(args) >= 2:
        t1, t2 = dref(args[0]), dref(args[1])
        if t1 is None or t2 is None:
            return None
        return "Result<" + t1 + ", " + t2 + ">"
    if head == "Option" and args:
        t1 = dref(args[0])
        if t1 is None:
            return None
        return "Option<" + t1 + ">"
    return None


def _transpose_text(ttext):
    """The type text `transpose` returns on a
    Result/Option type text (seam round 20, protest P1):
    the same payload under the two containers swapped —
    `Option<Result<T, E>>` reads as `Result<Option<T>,
    E>` and back, the `ok` clause's sibling-container
    move taken twice — or None."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    if head == "Option" and args:
        inner = _result_option_parts(args[0])
        if inner and inner[0] == "Result" and len(inner[1]) >= 2:
            return "Result<Option<" + inner[1][0] + ">, " + inner[1][1] + ">"
    if head == "Result" and len(args) >= 2:
        inner = _result_option_parts(args[0])
        if inner and inner[0] == "Option" and inner[1]:
            return "Option<Result<" + inner[1][0] + ", " + args[1] + ">>"
    return None


def _self_text(ttext):
    """The receiver's own type text, reference prefix
    stripped (seam round 22, protest P1): the text the
    container-returning steps of the payload ring return —
    `or`, `or_else`, `and`, `take` and `replace` each return
    a container of the receiver's own head and payload, and
    `clone` on a container receiver returns a second value
    of the container's own type."""
    if ttext is None:
        return None
    t = re.sub(r"\s+", " ", ttext.strip())
    t = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", t).strip()
    return t


def _ok_or_text(ttext):
    """The type text `ok_or` / `ok_or_else` returns on an
    Option type text (seam round 22, protest P1): the
    payload under the sibling container `Result`, the `ok`
    step's converse — the error is the caller's own value
    and carries nothing, so it stands as `()` in the text."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    if head == "Option" and args:
        return "Result<" + args[0] + ", ()>"
    return None


def _map_err_text(ttext):
    """The type text `map_err` returns on a Result type
    text (seam round 22, protest P1): the same head over
    the same payload — only the error is replaced, and it
    stands as `()` in the text, as in `ok_or`."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    if head == "Result" and args:
        return "Result<" + args[0] + ", ()>"
    return None


def _flatten_text(ttext):
    """The type text `flatten` returns on a Result/Option
    type text (seam round 22, protest P1): the payload
    itself, when the payload is itself a container — the
    outer container opened and the inner one left standing
    in its place."""
    parts = _result_option_parts(ttext)
    if not parts or not parts[1]:
        return None
    payload = parts[1][0]
    return payload if _result_option_parts(payload) is not None else None


def _zip_text(ttext):
    """The type text `zip` returns on an Option type text
    (seam round 22, protest P1): the same head over the
    paired payload — the receiver's payload stands as the
    pair's first element, and the argument's payload,
    which the receiver's text cannot name, stands as
    `()` in the second."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    if head == "Option" and args:
        return "Option<(" + args[0] + ", ())>"
    return None


def _and_text(ttext):
    """The type text `and` records where the argument's
    container text is not determinable at the call (seam
    round 23, protest P1): the whole result payload stands
    as `()` — the receiver's payload is discarded for the
    argument's, so no part of it may stand as the result's;
    the error of a `Result` is the receiver's own and
    stands as written."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    if head == "Result" and len(args) >= 2:
        return "Result<(), " + args[1] + ">"
    if head == "Option" and args:
        return "Option<()>"
    return None


def _and_arg_text(ttext, argtext):
    """The type text `and` returns where the argument's
    container text IS determinable at the call (seam round
    23, protest P1): the argument's container itself — its
    payload is the result's payload, by the step's own
    declaration — or the whole-payload `()` record where
    it is not."""
    if argtext is not None and _result_option_parts(argtext) is not None:
        t = re.sub(r"\s+", " ", argtext.strip())
        t = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", t).strip()
        return t
    return _and_text(ttext)


def _zip_arg_text(ttext, argtext):
    """The type text `zip` returns where the argument's
    container text IS determinable at the call (seam round
    23, protest P1): the pair at BOTH elements — the
    receiver's payload first and the argument's payload
    second, the position the caller's `.1` reaches — or
    the second element as `()` where it is not."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    if head != "Option" or not args:
        return None
    aparts = _result_option_parts(argtext) if argtext is not None else None
    if aparts and aparts[0] == "Option" and aparts[1]:
        return "Option<(" + args[0] + ", " + aparts[1][0] + ")>"
    return _zip_text(ttext)


def _err_text(ttext):
    """The type text `err` returns on a Result type text
    (seam round 23, protest P2's sweep): the ERROR payload
    under the sibling container `Option`, the success
    payload discarded — `ok`'s mirror on the second
    payload."""
    parts = _result_option_parts(ttext)
    if not parts:
        return None
    head, args = parts
    if head == "Result" and len(args) >= 2:
        return "Option<" + args[1] + ">"
    return None


def _ctor_container_text(arg, rmap, texts=None):
    """The container type text a container-constructor
    argument denotes (seam round 23, protest P1): `Ok(x)`
    is a `Result` over x's declared type (its error
    standing as `()`, which no step past the payload
    reads), `Err(x)` a `Result` over x's error type, and
    `Some(x)` an `Option` over x's type — or None where
    the argument is not such a constructor or its
    argument's type is not determinable."""
    if arg is None:
        return None
    a = arg.strip()
    while a.startswith("(") and _delim_match(a, 0, "(", ")") == len(a):
        a = a[1:-1].strip()
    # A constructor spelled with its turbofish (seam round
    # 24, protest P1): `Ok::<Built, ()>(...)` is the same
    # constructor as `Ok(...)`, the segment standing on the
    # constructor's head as it stands on a step's head in
    # the sibling arms — the pattern reads past it, and the
    # segment's own arguments stand as the payload type
    # where the argument expression's type is not
    # determinable.
    targs = None
    hm = re.match(r"^((?:\w+\s*::\s*)*(?:Ok|Err|Some))\s*::<", a)
    if hm:
        lt = a.index("<")
        end = _angle_match(a, lt)
        if end < 0:
            return None
        targs = [p.strip() for p in _split_top(a[lt + 1:end - 1])]
        a = hm.group(1) + a[end:]
    m = re.match(r"^(?:\w+\s*::\s*)*(Ok|Err|Some)\s*\((.*)\)$", a, re.S)
    if not m or _delim_match(a, a.index("("), "(", ")") != len(a):
        return None
    inner = m.group(2).strip()
    ident = _expr_type_at(inner, len(inner), rmap)
    if ident is None:
        # The constructor's argument read at the text level
        # (seam round 27, protest P3): a projection of a local
        # bound at a composite text — `Some(p.0)` where `p`
        # stands at a tuple text — is typed by the text arms
        # where the identity arms hold no entry for it, as the
        # sibling arms read such a projection.
        _tt27 = _expr_type_text_at(inner, len(inner), rmap, _texts_of(rmap, texts))
        if _tt27 is not None:
            ident = _det_id(_tt27) or _tt27
    if ident is None:
        # A tuple-literal argument (seam round 26, protest
        # P2's sweep): the constructor's argument stands as
        # its tuple shape where no declared text names the
        # whole — the literal-shape reading the inference
        # walk already takes — so `Some((b, 0))` is the
        # container over the pair, as `Some(b)` is over its
        # element.
        _inn26 = inner.strip()
        if _inn26.startswith("(") and _delim_match(_inn26, 0, "(", ")") == len(_inn26):
            _parts26 = _split_top(_inn26[1:-1])
            if len(_parts26) > 1:
                _elems26 = []
                for _part26 in _parts26:
                    _et26 = _arg_shape_text(_part26, rmap, texts)
                    _elems26.append(_et26 if _et26 is not None else "_")
                ident = "(" + ", ".join(_elems26) + ")"
    if ident is None and targs:
        if m.group(1) == "Err":
            ident = targs[1] if len(targs) > 1 else None
        else:
            ident = targs[0] if targs else None
    if ident is None:
        return None
    if m.group(1) == "Ok":
        return "Result<" + ident + ", ()>"
    if m.group(1) == "Err":
        return "Result<(), " + ident + ">"
    return "Option<" + ident + ">"


def _first_arg_text(text, open_idx):
    """The first argument's text of the call whose argument
    list opens at open_idx, or None (seam round 23,
    protest P1): the argument the `and`/`zip` steps take
    their result's payload from."""
    close = _delim_match(text, open_idx, "(", ")")
    if close < 0:
        return None
    inner = text[open_idx + 1:close - 1]
    if not inner.strip():
        return None
    parts = _split_top(inner)
    return parts[0].strip() if parts else None


def _qualified_self_text(head_text):
    """The Self type text a qualified head spells (seam
    round 28, protests P1 and P4): `<Self as Trait<...>>::
    name` and `<Self>::name` denote Self — the part of the
    head's closing angle group before any ` as ` at its own
    depth, the group itself read to its matching close, so
    a nested generic in Self or in the trait's arguments
    cannot cut it. Any other head shape is None."""
    ht = head_text.rstrip()
    if not ht.endswith("::"):
        return None
    ht = ht[:-2].rstrip()
    if not ht.endswith(">"):
        return None
    depth, j = 1, len(ht) - 2
    while j >= 0 and depth:
        if ht[j] == ">":
            depth += 1
        elif ht[j] == "<":
            depth -= 1
        j -= 1
    if depth:
        return None
    inner = ht[j + 2:-1]
    depth = 0
    for i, c in enumerate(inner):
        if c in "<([{":
            depth += 1
        elif c in ">)]}":
            depth -= 1
        elif depth == 0 and inner.startswith(" as ", i):
            return inner[:i].strip()
    return inner.strip()


def _from_self_text(head_text, text, j):
    """The Self a `from` head denotes (seam round 29,
    protest P2): a qualified head (`<Self as Trait>::from`,
    `<Self>::from`) denotes its Self, as
    _qualified_self_text reads it; a plain turbofish head
    (`Option::<T>::from`) denotes the head over its
    turbofish group — the group is the head's arguments,
    not Self itself, the reading the qualified-only check
    missed; and a plain head denotes the head itself, a
    name standing as its own type, which no container
    argument's type can equal, so the identity check that
    reads this cannot misfire onto a container selection
    at the same head."""
    ht2 = head_text.rstrip()
    if ht2.endswith("::"):
        ht2 = ht2[:-2].rstrip()
    if ht2.endswith(">"):
        depth, k = 1, len(ht2) - 2
        while k >= 0 and depth:
            if ht2[k] == ">":
                depth += 1
            elif ht2[k] == "<":
                depth -= 1
            k -= 1
        if depth == 0:
            prefix = ht2[:k + 1].rstrip()
            if prefix.endswith("::"):
                # The turbofish group: the `::` before its
                # `<` is the discriminator — a qualified
                # group's `<` stands at the head itself, a
                # turbofish group's stands on a path. The
                # head is the path's trailing segments, the
                # expression's own leading characters (a
                # parenthesis, an operator) standing before
                # it read past.
                _hm29 = re.search(r"((?:\w+\s*::\s*)*\w+)\s*$", prefix[:-2].rstrip())
                args = ht2[k + 2:-1].strip()
                if _hm29 and args:
                    return _hm29.group(1) + "<" + args + ">"
                return None
            return _qualified_self_text(head_text)
    segs = _expand_module_segs(None, _path_segs_before(text, j))
    if segs:
        return segs[-1]
    return None


def _canon_type_text(ttext):
    """A type text canonicalised for comparison (seam round
    28, protest P4): aliases expanded, a container's
    arguments recursed, and every remaining head read
    through the identity it denotes — so two spellings of
    one type (the caller's `Option<crate::hook::Built>`
    against the callee's declared `Option<Built>`) compare
    equal exactly when they denote one type, the agreement
    the blanket identity impl is selected on."""
    if ttext is None:
        return None
    t = re.sub(r"\s+", " ", _expand_alias_text(ttext.strip()))
    parts = _result_option_parts(t)
    if parts:
        return parts[0] + "<" + ", ".join(_canon_type_text(p) for p in parts[1]) + ">"
    _gm29 = re.match(r"^(?:\w+\s*::\s*)*(\w+)\s*<(.+)>$", t, re.S)
    if _gm29:
        # A generic head beyond the two containers (seam
        # round 29, protest P2): the head read through the
        # name it denotes and its arguments canonicalised
        # in turn, as the container arguments above are —
        # `Vec<crate::hook::Built>` and `Vec<Built>` are
        # two spellings of one type.
        return _gm29.group(1) + "<" + ", ".join(_canon_type_text(p) for p in _split_top(_gm29.group(2))) + ">"
    ident = _det_id(t)
    if ident is not None:
        return ident
    m = re.match(r"^(?:\w+\s*::\s*)*(\w+)$", t)
    return m.group(1) if m else t


def _container_step_result_text(text, open_idx, rmap, seg, recv_text):
    """The type text a closure step's RESULT stands at on
    an `Option` / `Result` receiver (seam round 28, protest
    P1): `map` returns the container over its closure's
    return, `and_then` returns the closure's return itself
    (a container, as its signature binds it), and `filter`
    / `inspect` return the receiver's own container — the
    result the step returns, the container a following step
    stands on, read from the receiver's container text and
    the closure standing at the call, as the closure arm
    reads the parameter the step hands it. A receiver that
    is no container, or a closure whose return nothing
    determines, is None."""
    parts = _result_option_parts(recv_text)
    if parts is None or not parts[1]:
        return None
    if seg in ("filter", "inspect"):
        return recv_text
    arg = _first_arg_text(text, open_idx)
    if arg is None:
        return None
    crt = _closure_return_text(arg, parts[1][0], rmap)
    if crt is None:
        return None
    if seg == "and_then":
        return crt if _result_option_parts(crt) is not None else None
    if parts[0] == "Option":
        return "Option<" + crt + ">"
    err = parts[1][1] if len(parts[1]) >= 2 else "()"
    return "Result<" + crt + ", " + err + ">"


def _find_map_call_text(text, open_idx, rmap, recv_text):
    """The type text iterator `find_map`'s result stands at,
    at the call (seam round 29, protest P1): the step's
    closure returns an `Option`, and the step returns that
    `Option` itself — the `Option` over the closure's
    returned payload, as `filter_map`'s element is its
    closure return's payload and `map`'s result is its
    closure's return under the container. A receiver with
    no determinable element, or a closure whose return
    nothing determines, is None."""
    elem = _iter_elem_of(recv_text) or _iter_element_text(recv_text)
    if elem is None:
        return None
    arg = _first_arg_text(text, open_idx)
    if arg is None:
        return None
    crt = _closure_return_text(arg, elem, rmap)
    if crt is None:
        return None
    parts = _result_option_parts(crt)
    if parts and parts[0] == "Option" and parts[1]:
        return crt
    return None


def _unzip_call_text(text, open_idx, rmap, recv_text):
    """The type text iterator `unzip`'s result stands at,
    at the call (seam round 28, protest P1): the pair of
    the two collections its turbofish spells —
    `unzip::<A, B, FromA, FromB>` collects into `(FromA,
    FromB)`, as `collect` constructs the type its
    turbofish spells — or, with no turbofish, the pair of
    `Vec`s of the element pair's two positions, the
    collections `unzip` declares where the caller names
    none."""
    head = text[:open_idx].rstrip()
    if head.endswith(">"):
        depth, j = 1, len(head) - 2
        while j >= 0 and depth:
            if head[j] == ">":
                depth += 1
            elif head[j] == "<":
                depth -= 1
            j -= 1
        if depth == 0:
            targs = [p.strip() for p in _split_top(head[j + 2:-1])]
            if len(targs) == 4:
                return "(" + targs[2] + ", " + targs[3] + ")"
    elem = _iter_elem_of(recv_text) or _iter_element_text(recv_text)
    if elem is not None:
        e = elem.strip()
        if e.startswith("(") and e.endswith(")"):
            pair = _split_top(e[1:-1])
            if len(pair) == 2:
                return "(Vec<" + pair[0].strip() + ">, Vec<" + pair[1].strip() + ">)"
    return None


def _explicit_deref_text(text, open_idx, end, rmap, texts):
    """The type text of an explicit deref `(*expr)` (seam
    round 28, protest P1): the parenthesised expression is
    no call — where its content opens with `*`, the value
    stands at the operand's Deref target, as the autoderef
    spelling of a payload step on the same binding is
    already read through the receiver's chain."""
    k = open_idx + 1
    while k < end and text[k].isspace():
        k += 1
    if k >= end or text[k] != "*":
        return None
    k += 1
    while k < end and text[k].isspace():
        k += 1
    op_end = end - 1
    while op_end > k and text[op_end - 1].isspace():
        op_end -= 1
    if op_end <= k:
        return None
    tt = _expr_type_text_at(text, op_end, rmap, texts)
    if tt is None:
        tt = _expr_type_at(text, op_end, rmap)
    if tt is None:
        return None
    return _deref_target_text(tt)


def _as_slice_text(ttext, mutable=False):
    """The type text `as_slice` / `as_mut_slice` returns on
    a Result/Option type text (seam round 24, protest P2):
    the held payload under a slice head, by reference
    (mutable for `as_mut_slice`) — the payload standing as
    the slice's element, the position the index step the
    bound-local and caller arms already read stands on."""
    parts = _result_option_parts(ttext)
    if not parts or not parts[1]:
        return None
    return ("&mut [" if mutable else "&[") + parts[1][0] + "]"


def _unzip_text(ttext):
    """The type text `unzip` returns on an Option type text
    (seam round 24, protest P2's census): the payload is a
    pair, and each element stands under the sibling
    container in its own position of the returned pair."""
    parts = _result_option_parts(ttext)
    if not parts or parts[0] != "Option" or not parts[1]:
        return None
    payload = parts[1][0].strip()
    if not (payload.startswith("(") and payload.endswith(")")):
        return None
    elems = _split_top(payload[1:-1])
    if len(elems) != 2:
        return None
    return "(Option<" + elems[0].strip() + ">, Option<" + elems[1].strip() + ">)"


def _get_or_insert_text(ttext):
    """The type text `get_or_insert` returns on an Option
    type text (seam round 22, protest P1): a mutable
    reference to the held payload itself."""
    parts = _result_option_parts(ttext)
    if not parts or not parts[1]:
        return None
    return "&mut " + parts[1][0]


def _statement_end(text, start):
    """The offset of the `;` ending the statement that starts at
    `start`, bracket-depth aware, or None."""
    depth = 0
    j = start
    while j < len(text):
        c = text[j]
        if c in "(<[{":
            depth += 1
        elif c in ")>]}":
            depth -= 1
        elif c == ";" and depth == 0:
            return j
        j += 1
    return None


def _value_inits(code):
    """Every const/static initialiser in `code`, as
    (name, initialiser text) (seam round 16, protest P6):
    the initialiser ends at its statement `;` at bracket
    depth zero — a `;` inside the initialiser's own
    brackets (a block-expression macro template's statement
    separator, an array repeat's separator) does not end
    it, so the value closures that follow an expanded
    template read the whole initialiser it expands to.
    Seam round 18 (protest P6): the item HEAD is read at
    the same breadth — `static mut` stands in the item
    forms beside `static` and `const`, and a declared type
    is read to its depth-zero `=`, as the initialiser is
    read to its depth-zero `;`: a `;` inside the type's
    own brackets (an array type's repeat count) does not
    end the type, where the earlier capture's type group
    stopped at it and dropped the item whole."""
    out = []
    for m in re.finditer(r"(?<!['*])\b(?:const|static)\b", code):
        j = m.end()
        while j < len(code) and code[j].isspace():
            j += 1
        if code.startswith("mut", j) and not (j + 3 < len(code) and (code[j + 3].isalnum() or code[j + 3] == "_")):
            j += 3
            while j < len(code) and code[j].isspace():
                j += 1
        nm = re.match(r"\w+", code[j:])
        if not nm:
            continue
        name = nm.group(0)
        j += nm.end()
        while j < len(code) and code[j].isspace():
            j += 1
        if j < len(code) and code[j] == ":":
            j += 1
            depth, prev, eq = 0, "", -1
            while j < len(code):
                if code[j:j + 2] == "->":
                    prev = ">"
                    j += 2
                    continue
                c = code[j]
                if c in "(<[{":
                    depth += 1
                elif c in ")>]}":
                    if not (c == ">" and prev == "-"):
                        depth -= 1
                elif c == "=" and depth == 0:
                    eq = j
                    break
                elif c == ";" and depth == 0:
                    break
                prev = c
                j += 1
            if eq < 0:
                continue
            j = eq
        if j >= len(code) or code[j] != "=" or code[j + 1:j + 2] == "=":
            continue
        start = j + 1
        while start < len(code) and code[start].isspace():
            start += 1
        end = _statement_end(code, start)
        if end is None:
            continue
        out.append((name, code[start:end]))
    return out

def _generic_arg(ttext, idx):
    """The idx-th top-level generic argument of a type text
    `Head<...>`, or None."""
    if ttext is None:
        return None
    lt = ttext.find("<")
    if lt < 0 or not ttext.rstrip().endswith(">"):
        return None
    parts = _split_top(ttext[lt + 1:ttext.rstrip().rfind(">")])
    return parts[idx].strip() if idx < len(parts) else None

def _path_segs_before(text, j):
    """The path segments spelled before the segment that
    starts at `j` in `text`, outermost first (seam round
    18, protest P3): the backward `::` walk the
    associated-path arms share, reading a turbofish
    segment standing in the path (`Type::<args>::name`)
    as standing on its head — the segment the walk records
    is the head, and the arguments are read past, exactly
    as the plain spelling's walk records the head."""
    segs = []
    k = j
    while k >= 2 and text[k - 2:k] == "::":
        e = k - 2
        if e > 0 and text[e - 1] == ">":
            depth, q = 1, e - 2
            while q >= 0 and depth:
                if text[q] == ">":
                    depth += 1
                elif text[q] == "<":
                    depth -= 1
                q -= 1
            if depth:
                break
            lt = q + 1
            e = lt - 2 if lt >= 2 and text[lt - 2:lt] == "::" else lt
        s = e
        while s > 0 and (text[s - 1].isalnum() or text[s - 1] == "_"):
            s -= 1
        if s == e:
            break
        segs.insert(0, text[s:e])
        k = s
    return segs

def _strip_turbofish(text):
    """`text` with every turbofish segment (`::<args>`)
    removed (seam round 18, protest P3): the segment
    stands on its head, and the arms that read a spelled
    path's NAMES — a call's targets, a bare path's
    denoted wrapper — read the path the head stands in."""
    out = []
    i = 0
    while i < len(text):
        if text[i:i + 3] == "::<":
            i = _angle_match(text, i + 2)
            continue
        out.append(text[i])
        i += 1
    return "".join(out)

def _expand_alias_text(ttext):
    """A type text with its head production type alias expanded
    to the alias's target, the alias's own parameters replaced
    by the spelled arguments position for position (seam round
    26, protest P1): `Wrap<T>` where the crate declares
    `type Wrap<X> = Vec<X>` expands to `Vec<T>`, as the
    trait-path and wrapper-type arms already read an alias
    through to its defining type. Chained aliases expand in
    turn; a head that is no alias, whose alias the crate's
    tables cannot resolve, or whose expansion would cycle
    stands as written."""
    if ttext is None:
        return ttext
    t = re.sub(r"\s+", " ", ttext.strip())
    seen = set()
    while True:
        m = re.match(r"^((?:\w+\s*::\s*)*)(\w+)(?:\s*<(.+)>)?$", t, re.S)
        if not m:
            return t
        segs = [s.strip() for s in m.group(1).split("::") if s.strip()]
        head = m.group(2)
        ident = _ident_of(head, segs) if segs else (head if head in ALIAS_TEXT else None)
        if ident is None:
            cands = [k for k in ALIAS_TEXT if _disp(k) == head]
            ident = cands[0] if len(cands) == 1 else None
        if ident is None or ident not in ALIAS_TEXT or ident in seen:
            return t
        seen.add(ident)
        target = ALIAS_TEXT[ident]
        aparams = ALIAS_PARAMS.get(ident, [])
        if m.group(3) is not None and aparams:
            args = [x.strip() for x in _split_top(m.group(3))]
            if len(args) == len(aparams):
                mapping = dict(zip(aparams, args))
                pat = re.compile(r"\b(" + "|".join(re.escape(x) for x in mapping) + r")\b")
                target = pat.sub(lambda mm: mapping[mm.group(1)], target)
        t = re.sub(r"\s+", " ", target.strip())


def _infer_param_from(ptype, atext, params, mapping, blocked, fixed):
    """Infer generic parameters by walking a declared parameter
    type's STRUCTURE against the argument's type text (seam
    round 25, protest P1): a parameter standing inside a
    composite — a container's argument (`Vec<T>`), a tuple
    element (`(T, u32)`), an array element, a nested generic —
    is inferred at the position the structure gives, the
    simultaneous-substitution machinery of the field arms
    inverted at that position. A parameter two positions
    determine differently is ambiguous: it leaves the mapping
    and stands in `blocked`, the record's named limit for that
    form, rather than standing substituted by either. A
    parameter the call's turbofish already fixed (`fixed`) is
    never re-inferred."""
    if ptype is None or atext is None:
        return
    p = re.sub(r"\s+", " ", ptype.strip())
    a = re.sub(r"\s+", " ", atext.strip())
    p = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", p).strip()
    a = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", a).strip()
    if not p or not a or a == "_":
        return
    if p in params:
        if p in blocked or p in fixed:
            return
        if p in mapping and mapping[p] != a:
            del mapping[p]
            blocked.add(p)
        else:
            mapping[p] = a
        return
    # An alias head on either side (seam round 26, protest
    # P1): the declared type's structure lives in the alias's
    # target, so the walk reads through the expansion, at the
    # alias's own parameters substituted as the expansion
    # substitutes them; a differing pair determined through an
    # alias blocks the parameter exactly as a direct pair
    # does, the same conflict honesty.
    _xp = _expand_alias_text(p)
    if _xp != p:
        _infer_param_from(_xp, a, params, mapping, blocked, fixed)
        return
    _xa = _expand_alias_text(a)
    if _xa != a:
        _infer_param_from(p, _xa, params, mapping, blocked, fixed)
        return
    if p.startswith("(") and p.endswith(")"):
        if a.startswith("(") and a.endswith(")"):
            pparts = _split_top(p[1:-1])
            aparts = _split_top(a[1:-1])
            if len(pparts) == len(aparts):
                for pp, aa in zip(pparts, aparts):
                    _infer_param_from(pp, aa, params, mapping, blocked, fixed)
        return
    if p.startswith("["):
        if a.startswith("["):
            pe = p[1:p.rfind("]")].split(";")[0]
            ae = a[1:a.rfind("]")].split(";")[0]
            _infer_param_from(pe, ae, params, mapping, blocked, fixed)
        return
    fm = re.match(r"^(?:impl\s+)?(?:FnMut|FnOnce|Fn|fn)\s*\(", p)
    if fm:
        am = re.match(r"^(?:impl\s+)?(?:FnMut|FnOnce|Fn|fn)\s*\(", a)
        if am:
            pparts = _fn_param_types(p) or []
            aparts = _fn_param_types(a) or []
            if len(pparts) == len(aparts):
                for pp, aa in zip(pparts, aparts):
                    _infer_param_from(pp, aa, params, mapping, blocked, fixed)
        return
    pm = re.match(r"^(?:\w+\s*::\s*)*(\w+)\s*<(.+)>$", p, re.S)
    if pm:
        am = re.match(r"^(?:\w+\s*::\s*)*(\w+)\s*<(.+)>$", a, re.S)
        if am and am.group(1) == pm.group(1):
            pargs = _split_top(pm.group(2))
            aargs = _split_top(am.group(2))
            if len(pargs) == len(aargs):
                for pp, aa in zip(pargs, aargs):
                    _infer_param_from(pp, aa, params, mapping, blocked, fixed)
        return


def _texts_of(rmap, texts):
    """The declared type texts of the item `rmap` belongs to
    (seam round 27, protest P1): the texts the receiver arms
    consult for a bare local's annotation — threaded where the
    caller holds them, and otherwise recovered from the
    receiver map's own registration in TEXTS_BY_RMAP, which
    _receiver_types_full makes for every map it builds, as
    RENAME_CTX is recovered for names. The registration holds
    the map itself, so a recycled id can never attach a dead
    item's texts to a living map."""
    if texts is not None:
        return texts
    entry = TEXTS_BY_RMAP.get(id(rmap))
    return entry[1] if entry is not None and entry[0] is rmap else {}


def _literal_type31(a):
    """The type a literal expression denotes (seam round 31,
    protest P1): an integer literal at its suffix or at the
    inference default, a float at its suffix or the default,
    a char, a byte, a byte string, a string at the reference
    it denotes, a boolean — the literal forms whose type the
    shape arms otherwise leave unstated, read here so a
    constructor or range standing on a literal is typed by
    the literal's denotation, not left untyped."""
    a = a.strip()
    m = re.fullmatch(r"(\d[\d_]*)(i8|i16|i32|i64|i128|isize|u8|u16|u32|u64|u128|usize)?", a)
    if m:
        return m.group(2) or "i32"
    m = re.fullmatch(r"(\d[\d_]*\.\d[\d_]*)(f32|f64)?", a)
    if m:
        return m.group(2) or "f64"
    if re.fullmatch(r"'(\\.|[^\\'])'", a):
        return "char"
    if re.fullmatch(r"b'(\\.|[^\\'])'", a):
        return "u8"
    if a.startswith('b"'):
        return "&[u8]"
    if a.startswith('"'):
        return "&str"
    if a in ("true", "false"):
        return "bool"
    return None


def _range_iter_text31(a, rmap, texts=None):
    """The iterator type text a range expression denotes
    (seam round 31, protest P1): `start..end`, `start..` and
    `start..=end` are the language's range iterators over
    the start's type — a literal-shaped chain base, typed at
    its element as the `vec!` and array literal bases are
    typed at theirs. A range-to (`..end`) or a full range
    (`..`) denotes no iterator and is None here."""
    depth = 0
    i = 0
    cut = -1
    incl = False
    while i < len(a) - 1:
        c = a[i]
        if c in "(<[{":
            depth += 1
        elif c in ")>]}":
            depth -= 1
        elif c == "." and a[i + 1] == "." and depth == 0:
            cut = i
            incl = a[i + 2:i + 3] == "="
            break
        i += 1
    if cut <= 0:
        return None
    start = a[:cut].strip()
    rest = a[cut + 2 + (1 if incl else 0):].strip()
    if not start:
        return None
    if rest and len(_split_top(rest)) != 1:
        return None
    et = _expr_type_text_at(start, len(start), rmap, _texts_of(rmap, texts))
    if et is None:
        et = _literal_type31(start)
    if et is None and ".." not in start:
        et = _arg_shape_text(start, rmap, texts)
    if et is None:
        return None
    return "__Iter<" + et.strip() + ">"


def _arg_shape_text(arg, rmap, texts=None):
    """The type text an argument expression's own shape
    determines (seam round 25, protest P1): a `vec!` literal
    is a `Vec` of its element's type, a tuple literal a tuple
    of its elements' types, an array literal an array of its
    element's type, a reference a reference to its target's
    type, a container constructor its container text — the
    shapes whose element positions the inference walks where
    the argument is a literal the type arms do not type. An
    element whose type nothing determines stands as `_`, the
    inference placeholder, and determines nothing. Any other
    expression stands as its determinable type text."""
    if arg is None:
        return None
    a = arg.strip()
    while a.startswith("(") and _delim_match(a, 0, "(", ")") == len(a):
        inner = a[1:-1]
        parts = _split_top(inner) if inner.strip() else []
        if len(parts) > 1:
            elems = []
            for part in parts:
                et = _arg_shape_text(part, rmap, texts)
                elems.append(et if et is not None else "_")
            return "(" + ", ".join(elems) + ")"
        if parts:
            a = parts[0].strip()
            continue
        return None
    rm = re.match(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?(.+)$", a, re.S)
    if rm:
        inner = _arg_shape_text(rm.group(1), rmap, texts)
        return "&" + inner if inner is not None else None
    vm = re.match(r"^(?:\w+\s*::\s*)*vec\s*!\s*\[", a)
    if vm:
        open_idx = a.index("[")
        end = _delim_match(a, open_idx, "[", "]")
        if end != len(a):
            return None
        inner = a[open_idx + 1:end - 1]
        elem = _split_top(inner)[0] if inner.strip() else ""
        elem = elem.split(";")[0].strip()
        et = _arg_shape_text(elem, rmap, texts) if elem else None
        return "Vec<" + et + ">" if et is not None else None
    if a.startswith("[") and _delim_match(a, 0, "[", "]") == len(a):
        inner = a[1:-1]
        elem = _split_top(inner)[0] if inner.strip() else ""
        elem = elem.split(";")[0].strip()
        et = _arg_shape_text(elem, rmap, texts) if elem else None
        return "[" + et + "; 1]" if et is not None else None
    _rg31 = _range_iter_text31(a, rmap, texts)
    if _rg31 is not None:
        return _rg31
    ct = _ctor_container_text(a, rmap, texts)
    if ct is not None:
        return ct
    t = _expr_type_text_at(a, len(a), rmap, _texts_of(rmap, texts))
    if t is None:
        t = _expr_type_at(a, len(a), rmap)
    return t


def _call_generic_substitution(rt, text, open_idx, rmap, params, param_types):
    """A callee's declared return type text with the
    callee's generic type parameters substituted at the
    call site (seam round 24, protest P1): from the call's
    own turbofish where one is spelled, and from the
    argument expressions' determinable types where a
    parameter is inferred from the parameter it stands
    for — the record is computed, not read, as the
    field-instantiation arms substitute position for
    position. Simultaneous, as there: an inserted argument
    is a denotation in the caller's scope and is never
    rescanned. Where no source determines a parameter, the
    declared text stands as written."""
    if rt is None or not params:
        return rt
    mapping = {}
    head = text[:open_idx].rstrip()
    if head.endswith(">"):
        depth, j = 1, len(head) - 2
        while j >= 0 and depth:
            if head[j] == ">":
                depth += 1
            elif head[j] == "<":
                depth -= 1
            j -= 1
        if depth == 0:
            targs = [p.strip() for p in _split_top(head[j + 2:-1])]
            if len(targs) == len(params):
                mapping.update(zip(params, targs))
    if len(mapping) < len(params):
        args = _call_args(text, open_idx)
        offset = 1 if param_types and param_types[0].strip() == "Self" else 0
        fixed = set(mapping)
        blocked = set()
        for pi, ptype in enumerate(param_types or []):
            ai = pi - offset
            if not (0 <= ai < len(args)):
                continue
            if not any(re.search(r"\b" + re.escape(p) + r"\b", ptype) for p in params):
                continue
            atext = _expr_type_text_at(args[ai], len(args[ai]), rmap, _texts_of(rmap, None))
            if atext is None:
                atext = _expr_type_at(args[ai], len(args[ai]), rmap)
            if atext is not None:
                _infer_param_from(ptype, atext, params, mapping, blocked, fixed)
            shape = _arg_shape_text(args[ai], rmap)
            if shape is not None:
                _infer_param_from(ptype, shape, params, mapping, blocked, fixed)
    if not mapping:
        return rt
    pat = re.compile(r"\b(" + "|".join(re.escape(p) for p in mapping) + r")\b")
    return pat.sub(lambda m: mapping[m.group(1)], rt)


def _free_return_at(seg, text, open_idx, rmap):
    """_free_return with the generic substitution applied
    to the callee's return text at the call site (seam
    round 24, protest P1), as _callee_return_text's free
    arm applies it."""
    rt = _free_return_text(seg)
    if rt is None or rt == "Self":
        return None
    sub = _call_generic_substitution(rt, text, open_idx, rmap, GENERIC_PARAMS_FREE.get(seg), PARAMS_FREE.get(seg))
    return _det_id(sub if sub is not None else rt)


def _from_value_construct31(self_text, arg_text):
    """The type text a `from` path value constructs from
    an argument of type `arg_text` (seam round 31, protest
    P7): the denoted Self, expanded through the alias
    tables; the identity where the argument stands at the
    denoted Self — reference-sensitive, as the call head's
    agreement is; the container where the denoted Self is
    `Option` and the argument stands at its payload; and,
    where the argument is a reference to the container,
    the `Option` over a reference to the payload, as the
    `From<&Option<T>>` implementation declares. A bare
    `Option` head spells no argument: an argument already
    standing at the container is the identity's, as the
    agreement reads a spelled Self. Any other standing is
    None."""
    if self_text is None or arg_text is None:
        return None
    exp = _expand_alias_text(self_text).strip()
    at = arg_text.strip()
    if at.startswith("&") == exp.startswith("&") and _canon_type_text(at) == _canon_type_text(exp):
        return exp
    if exp == "Option":
        _p31 = _result_option_parts(at)
        if _p31 and _p31[0] == "Option":
            return at
        if at.startswith("&"):
            return None
        return "Option<" + at + ">"
    parts = _result_option_parts(exp)
    if parts and parts[0] == "Option" and parts[1]:
        if at.startswith("&"):
            inner = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", at).strip()
            ip = _result_option_parts(inner)
            if ip and ip[0] == "Option" and ip[1]:
                _refm31 = re.match(r"^&\s*(?:'\w+\s+)?(mut\s+)?", at)
                return "Option<&" + ("mut " if _refm31 and _refm31.group(1) else "") + ip[1][0] + ">"
            return None
        return "Option<" + at + ">"
    return None


def _from_path_value_return31(a, elem):
    """The return a `from` path standing as a VALUE hands
    its position (seam round 31, protest P7): the blanket
    identity implementation the path denotes, applied to
    the element the combinator hands it, exactly as the
    same path standing as a call head constructs (the
    _from_value_construct31 reading). The denoted Self
    is read from the spelling — a turbofish's type, or a
    path whose generic arguments stand before the `from`.
    A spelling with no determinable Self, or no element
    to construct from, is None."""
    if elem is None:
        return None
    a = a.strip()
    m = re.fullmatch(r"<(.+)>\s*::\s*from", a, re.S)
    if m:
        inner = m.group(1)
        asm = re.match(r"^(.+?)\s+as\s+(?:\w+\s*::\s*)*\w+$", inner, re.S)
        return _from_value_construct31(asm.group(1) if asm else inner, elem)
    m = re.fullmatch(r"((?:\w+\s*::\s*)*\w+)\s*::<(.+)>\s*::\s*from", a, re.S)
    if m:
        head = [s.strip() for s in m.group(1).split("::") if s.strip()][-1]
        return _from_value_construct31(head + "<" + m.group(2) + ">", elem)
    return None


def _closure_return_text(arg, elem, rmap, elem_idx=0, bind_types=None):
    """The type text a closure literal's body returns, with
    the closure's first parameter bound at `elem` (seam round
    26, protest P2): the body's own shape — a literal's
    container, a constructor's container, a call's declared
    return — read with the parameter in the receiver map, as
    the iterator-consumer arm binds that parameter when the
    closure is the chain's destination. A named function
    standing in the closure's place stands at its declared
    return. Anything else is None. Seam round 27 (protests
    P4 and P5): the function may stand spelled as a path — a
    qualified free path at its function's declared return, an
    associated path at its type's declared method return, a
    trait path at the type's method return — as the bare name
    does; and the element binds at the parameter position the
    calling adapter's signature states (`elem_idx`, with any
    other parameter's type supplied in `bind_types` — `scan`'s
    state, bound at its initial value's type), an annotated
    parameter binding at its annotation as before."""
    if arg is None:
        return None
    a = re.sub(r"^move\s+", "", arg.strip())
    m = re.match(r"^\|([^|]*)\|\s*(.+)$", a, re.S)
    if not m:
        if re.fullmatch(r"\w+", a):
            return _free_return_text(a)
        _fv31 = _from_path_value_return31(a, elem)
        if _fv31 is not None:
            return _fv31
        _tm27 = re.fullmatch(r"<(.+)>\s*::\s*(\w+)(?:\s*::<.+>)?", a, re.S)
        if _tm27:
            _inner27 = _tm27.group(1)
            _asm27 = re.match(r"^(.+?)\s+as\s+(?:\w+\s*::\s*)*\w+$", _inner27, re.S)
            _type27 = _asm27.group(1) if _asm27 else _inner27
            _ident27 = _det_id(_type27.strip())
            if _ident27 is not None:
                _rt27 = _meth_return_text(_ident27, _tm27.group(2))
                if _rt27 is not None:
                    return _rt27
            if _tm27.group(2) == "from":
                # A `from` path standing as a value in the
                # function's place (seam round 31, protest
                # P7): the path denotes the `From`
                # implementation it selects, and standing as
                # a combinator's argument it constructs what
                # the same path standing as a call head
                # constructs from the argument the combinator
                # hands it — the identity where the argument
                # stands at the denoted Self, the container
                # where it stands at the payload.
                _fv31 = _from_value_construct31(_type27.strip(), elem)
                if _fv31 is not None:
                    return _fv31
            return _free_return_text(_tm27.group(2))
        _pm27 = re.fullmatch(r"((?:\w+\s*::\s*)*)(\w+)(?:\s*::<.+>)?", a, re.S)
        if _pm27:
            _segs27 = [s.strip() for s in _pm27.group(1).split("::") if s.strip()]
            _name27 = _pm27.group(2)
            if _segs27 and _segs27[-1][:1].isupper():
                _ident27 = _ident_of(_segs27[-1], _segs27[:-1])
                if _ident27 is not None:
                    _rt27 = _meth_return_text(_ident27, _name27)
                    if _rt27 is not None:
                        return _rt27
            if _name27 == "from" and _segs27 and _segs27[-1][:1].isupper():
                _fv31 = _from_value_construct31(_segs27[-1], elem)
                if _fv31 is not None:
                    return _fv31
            return _free_return_text(_name27)
        return None
    params = [p.strip() for p in _split_top(m.group(1))]
    body = m.group(2).strip()
    out = dict(rmap)
    texts = {}
    for _idx27, p0 in enumerate(params):
        if not p0:
            continue
        pat, ptype = p0, (bind_types or {}).get(_idx27, elem if _idx27 == elem_idx else None)
        _depth, _colon = 0, -1
        for _ci, _cc in enumerate(p0):
            if _cc in "(<[{":
                _depth += 1
            elif _cc in ")>]}":
                _depth -= 1
            elif _cc == ":" and _depth == 0 and p0[_ci - 1] != ":" and p0[_ci + 1:_ci + 2] != ":":
                _colon = _ci
                break
        if _colon > 0:
            pat, ptype = p0[:_colon].strip(), p0[_colon + 1:].strip()
        if ptype is None:
            continue
        _bind_pattern(pat, ptype, out, texts)
        if re.fullmatch(r"\w+", pat):
            texts.setdefault(pat, ptype)
            _ident26 = _det_id(ptype)
            if _ident26 is not None:
                out.setdefault(pat, _ident26)
    exprs = _return_exprs(body) if body.startswith("{") else [body]
    for e in exprs:
        e = e.strip()
        if not e:
            continue
        shape = _arg_shape_text(e, out, texts)
        if shape is not None:
            return shape
        tt = _expr_type_text_at(e, len(e), out, texts)
        if tt is not None:
            return tt
        ident = _expr_type_at(e, len(e), out)
        if ident is not None:
            return ident
    return None


def _iter_adapter_return_text(text, open_idx, rmap, seg, recv_text, texts=None):
    """The iterator type text a transforming adapter call
    returns, at the call standing in `text` (seam round 26,
    protest P2): the element at the adapter's own yield — for
    `map`, its closure's return; for `filter_map` and
    `map_while`, that return's payload under `Option`; for
    `flat_map`, that return's element; for `enumerate`, the
    pair of the index and the element at its second position;
    for `zip`, the pair of the receiver's element and the
    argument iterator's element at theirs. Where the
    closure's return nothing determines, the element stands
    as the receiver's own, the identity breadth. A receiver
    that is no synthetic iterator text stands as None."""
    elem = _iter_elem_of(recv_text)
    if elem is None:
        return None
    if seg == "enumerate":
        return "__Iter<(usize, " + elem + ")>"
    if seg == "zip":
        elem2 = None
        arg = _first_arg_text(text, open_idx)
        if arg is not None:
            at = _expr_type_text_at(arg, len(arg), rmap, _texts_of(rmap, texts))
            if at is None:
                at = _arg_shape_text(arg, rmap)
            if at is not None:
                elem2 = _iter_elem_of(at) or _generic_arg(at, 0)
        return "__Iter<(" + elem + ", " + (elem2 or "()") + ")>"
    if seg in ("map", "filter_map", "flat_map", "map_while"):
        arg = _first_arg_text(text, open_idx)
        rt = _closure_return_text(arg, elem, rmap) if arg is not None else None
        if rt is None:
            return "__Iter<" + elem + ">"
        if seg == "map":
            newelem = rt
        elif seg in ("filter_map", "map_while"):
            parts = _result_option_parts(rt)
            newelem = parts[1][0] if parts and parts[0] == "Option" and parts[1] else rt
        else:
            newelem = _iter_elem_of(rt) or _generic_arg(rt, 0) or rt
        return "__Iter<" + newelem + ">"
    # The adapter census's remaining members (seam round 27,
    # protest P5): `scan`, whose yield is its closure's
    # `Option` payload with the closure's element at its
    # second parameter and its state at the initial value's
    # type; `flatten`, whose yield is the element's own
    # element, as `flat_map`'s is its closure return's; and
    # the element-preserving family the census counts —
    # `peekable`, `inspect`, `fuse`, `cycle`, `by_ref`,
    # `take_while`, `skip_while`, `chain`, `filter` and the
    # counted position steps — at the element itself, with
    # `cloned` / `copied` at the element one reference
    # stripped, as their step text already reads them.
    if seg == "scan":
        _close27 = _delim_match(text, open_idx, "(", ")")
        _inner27 = text[open_idx + 1:_close27 - 1] if _close27 > 0 else ""
        _d27, _a27, _i27, _cut27 = 0, 0, 0, -1
        while _i27 < len(_inner27):
            _c27 = _inner27[_i27]
            if _c27 == "|" and _d27 == 0 and _a27 == 0:
                _nxt27 = _inner27.find("|", _i27 + 1)
                if _nxt27 < 0:
                    break
                _i27 = _nxt27
            elif _c27 in "([{":
                _d27 += 1
            elif _c27 in ")]}":
                _d27 -= 1
            elif _c27 == "<":
                _a27 += 1
            elif _c27 == ">":
                if _a27 > 0 and _inner27[_i27 - 1] != "-":
                    _a27 -= 1
            elif _c27 == "," and _d27 == 0 and _a27 == 0:
                _cut27 = _i27
                break
            _i27 += 1
        if _cut27 < 0:
            return None
        _state27 = _inner27[:_cut27].strip()
        _clo27 = _inner27[_cut27 + 1:].strip()
        _st27 = _expr_type_text_at(_state27, len(_state27), rmap, _texts_of(rmap, texts))
        if _st27 is None:
            _st27 = _arg_shape_text(_state27, rmap)
        if _st27 is None:
            _lm27 = re.fullmatch(r"[\d_]+(?:\.[\d_]+)?(?:[eE][+-]?[\d_]+)?(i8|i16|i32|i64|i128|isize|u8|u16|u32|u64|u128|usize|f32|f64)", _state27)
            if _lm27:
                _st27 = _lm27.group(1)
        rt = _closure_return_text(_clo27, elem, rmap, elem_idx=1, bind_types={0: _st27} if _st27 else None)
        if rt is None:
            return "__Iter<" + elem + ">"
        parts = _result_option_parts(rt)
        newelem = parts[1][0] if parts and parts[0] == "Option" and parts[1] else rt
        return "__Iter<" + newelem + ">"
    if seg == "flatten":
        newelem = _iter_elem_of(elem) or _iter_element_text(elem) or elem
        return "__Iter<" + newelem + ">"
    if seg in ("peekable", "inspect", "fuse", "cycle", "by_ref", "take_while", "skip_while", "chain", "filter", "rev", "skip", "take", "step_by"):
        return "__Iter<" + elem + ">"
    if seg in ("cloned", "copied"):
        unref = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", elem.strip()).strip()
        return "__Iter<" + unref + ">"
    return None


def _std_ctor_call_text(text, open_idx, rmap, texts=None):
    """The container type text a trait-delivered constructor
    call constructs (seam round 26, protest P3): `Option`'s
    `From::from`, in the plain associated spelling
    (`Option::from(x)`) and the qualified spelling
    (`<Option<T> as From<T>>::from(x)`), constructs the
    `Option` over its argument's type — the argument's
    payload under the container, as `and`'s result holds its
    argument's; the `From<&Option<T>>` and
    `From<&mut Option<T>>` spellings construct the `Option`
    over a reference to the referenced container's payload —
    `Option<&T>`, `Option<&mut T>` — as those impls declare
    (seam round 27, protest P7: the reference the impl
    constructs stands in the text, not dropped from it).
    `from_iter` on `Option` / `Result` constructs
    the container over the collection of its iterator's
    container payloads, as `FromIterator` declares.
    `collect` constructs the type its turbofish spells.
    Any other call — a crate type's own `from`, a free
    `from`, a `collect` with no turbofish — is None here
    and stands judged by the ordinary arms. Seam round 27:
    the constructor's head is read at the type it denotes —
    a production type alias at the head expands by the alias
    tables, in the plain and the qualified spellings alike
    (protest P2); `sum` and `product` on an iterator of
    containers construct the collected container its
    turbofish spells, or the element container itself where
    no turbofish stands, as `Sum` / `Product` declare for
    `Option` / `Result` (protest P7); and the std hand-out
    calls are read at their signatures (protest P8) —
    `std::mem::take` and `std::mem::replace` hand the first
    argument's container itself out, and `Box::new` (with
    the `Rc` / `Arc` spellings at parity) constructs the
    `Deref` carrier over its argument. Seam round 28: the
    readings stand at the call's denotation in every
    spelling the round-27 paragraph's breadth implies —
    `sum` / `product` at their qualified spellings, the
    hand-out calls at a bare imported name the file's own
    bindings bind to them, the carriers at a renamed
    binding and at the qualified head, and `From::from`
    under the blanket identity impl where the argument
    already stands at the head's own type (protests P1
    and P4)."""
    end = open_idx
    while end > 0 and text[end - 1].isspace():
        end -= 1
    if end <= 0:
        return None
    turbo = None
    if text[end - 1] == ">":
        depth, j = 1, end - 2
        while j >= 0 and depth:
            if text[j] == ">":
                depth += 1
            elif text[j] == "<":
                depth -= 1
            j -= 1
        if depth:
            return None
        turbo = text[j + 2:end - 1].strip()
        end = j + 1
        while end > 0 and text[end - 1] == ":":
            end -= 1
    if end <= 0 or not (text[end - 1].isalnum() or text[end - 1] == "_"):
        return None
    j = end
    while j > 0 and (text[j - 1].isalnum() or text[j - 1] == "_"):
        j -= 1
    seg = text[j:end]
    if seg == "collect":
        if turbo and j >= 1 and text[j - 1] == ".":
            return turbo
        return None
    if seg in ("sum", "product"):
        if j >= 1 and text[j - 1] == ".":
            _rcv27 = _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, texts))
            if turbo:
                _exp27 = _expand_alias_text(turbo)
                if _result_option_parts(_exp27) or (_rcv27 and _iter_elem_of(_rcv27)):
                    return _exp27
                return None
            _el27 = _iter_elem_of(_rcv27) if _rcv27 else None
            if _el27 is not None and _result_option_parts(_el27):
                return _el27
            return None
        # The qualified spellings (seam round 28, protest
        # P1): `<Option<T> as Sum<Option<T>>>::sum(it)`
        # constructs the Self the head spells, and
        # `Iterator::sum::<T>(it)` constructs the container
        # its turbofish spells — the same collected
        # container the method spelling constructs, read at
        # the head the caller wrote, with the argument's
        # element standing as a container or undetermined
        # as the method arm requires of its receiver.
        if turbo:
            _exp28 = _expand_alias_text(turbo)
            if _result_option_parts(_exp28) and _path_segs_before(text, j)[-1:] == ["Iterator"]:
                return _exp28
            return None
        _self28 = _qualified_self_text(text[:j])
        if _self28 is not None:
            _exp28 = _expand_alias_text(_self28)
            if _result_option_parts(_exp28):
                _arg28 = _first_arg_text(text, open_idx)
                _at28 = None
                if _arg28 is not None:
                    _at28 = _expr_type_text_at(_arg28, len(_arg28), rmap, _texts_of(rmap, texts))
                    if _at28 is None:
                        _at28 = _arg_shape_text(_arg28, rmap)
                _el28 = (_iter_elem_of(_at28) or _iter_element_text(_at28)) if _at28 else None
                if _el28 is None or _result_option_parts(_el28):
                    return _exp28
            if _result_option_parts(_exp28) is None:
                # A non-container Self (seam round 29,
                # protest P5): `Sum` and `Product` declare
                # the method's result as Self for every
                # Self — a crate type's own impl returns
                # the type itself, the declared return the
                # method spelling is read at — so the
                # qualified spelling stands at Self exactly
                # as the method spelling does.
                return _exp28
        return None
    _ren29 = None
    _path30 = None
    if seg not in ("from", "from_iter", "new", "take", "replace"):
        # A bare hand-out call under a renamed binding
        # (seam round 29, protest P4): the segment is the
        # local name the file binds — through the crate's
        # own re-export, as STD_BIND_CTX now records it —
        # to std's `take` or `replace`, and the call is
        # read at that item, as the plain bare spelling is.
        if text[j - 2:j] != "::":
            _ren29 = STD_BIND_CTX.get(seg)
        if _ren29 not in ("std::mem::take", "std::mem::replace") and text[j - 2:j] == "::" and _std_ctx_rel() is not None:
            # A hand-out spelled by its re-export PATH
            # (seam round 30, protest P3): the call never
            # passes through a binding of the consumer's
            # own, so no binding context records it — the
            # spelled path itself is resolved through the
            # re-exports standing along it, at the path's
            # own module, to the std item it denotes, as a
            # binding spelling of the identical item
            # already is.
            _full30 = _expand_module_segs(None, _path_segs_before(text, j)) + [seg]
            _ch30 = _chase_std_path(_std_ctx_rel(), _full30)
            if _ch30 in ("std::mem::take", "std::mem::replace"):
                _ren29 = _ch30
                _path30 = _ch30
        if _ren29 not in ("std::mem::take", "std::mem::replace"):
            return None
        seg = _ren29.rsplit("::", 1)[-1]
    _bare28 = None
    if text[j - 2:j] != "::":
        # A bare spelling (seam round 28, protest P1): the
        # call stands at no path, so it is read only where
        # the file's own use bindings bind the spelled name
        # to the std hand-out item itself — `use
        # std::mem::take; take(&mut o)` denotes std's take
        # exactly as the path spelling does.
        _den28 = STD_BIND_CTX.get(seg)
        if _den28 in ("std::mem::take", "std::mem::replace"):
            _bare28 = _den28.rsplit("::", 1)[-1]
        elif _ren29 is not None:
            _bare28 = seg
        else:
            return None
    if seg in ("take", "replace") and _bare28 is None and _path30 is None and text[j - 2:j] == "::" and _std_ctx_rel() is not None:
        # The literal hand-out name spelled by a re-export
        # path (seam round 30, protest P3): a module's own
        # re-export of std's `take` under its own name,
        # called by path, denotes std's item as the
        # `std::mem` spelling does.
        _full30 = _expand_module_segs(None, _path_segs_before(text, j)) + [seg]
        if _chase_std_path(_std_ctx_rel(), _full30) == "std::mem::" + seg:
            _path30 = "std::mem::" + seg
    head_text = text[:j]
    qm = re.search(r"<\s*(?:\w+\s*::\s*)*(Option|Result)\s*<", head_text)
    if qm:
        head = qm.group(1)
    else:
        segs = _expand_module_segs(None, _path_segs_before(text, j))
        head = segs[-1] if segs and segs[-1] in ("Option", "Result") else None
    if head is None:
        # A production type alias at the constructor's head
        # (seam round 27, protest P2): the head the match
        # reads is the type the spelled head denotes, the
        # alias expanded by the same tables the sibling arms
        # use — the plain spelling's last segment, or the
        # qualified spelling's Self type.
        _cand27 = None
        _asm27 = re.search(r"<\s*((?:\w+\s*::\s*)*\w+)(?:\s*<.+>)?\s+as\s+", head_text, re.S)
        if _asm27:
            _cand27 = _asm27.group(1).split("::")[-1].strip()
        elif segs:
            _cand27 = segs[-1]
        if _cand27:
            _parts27 = _result_option_parts(_expand_alias_text(_cand27))
            if _parts27:
                head = _parts27[0]
        if head is None and seg not in ("new", "take", "replace", "from"):
            return None
    arg = _first_arg_text(text, open_idx)
    if arg is None:
        return None
    at = _expr_type_text_at(arg, len(arg), rmap, _texts_of(rmap, texts))
    if at is None:
        at = _arg_shape_text(arg, rmap)
    if at is None:
        at = _expr_type_at(arg, len(arg), rmap)
    if at is None:
        return None
    if seg == "new":
        _segs27 = _expand_module_segs(None, _path_segs_before(text, j))
        if _segs27 and _segs27[-1] in ("Box", "Rc", "Arc"):
            return _segs27[-1] + "<" + at.strip() + ">"
        if _segs27:
            # A renamed carrier binding (seam round 28,
            # protest P1): `use std::boxed::Box as Mine;
            # Mine::new(...)` constructs the carrier the
            # binding denotes, as the plain head does.
            _den28 = STD_BIND_CTX.get(_segs27[-1])
            if _den28 is not None and _den28.rsplit("::", 1)[-1] in ("Box", "Rc", "Arc"):
                return _den28.rsplit("::", 1)[-1] + "<" + at.strip() + ">"
            # A carrier spelled by its re-export PATH
            # (seam round 30, protest P3): the carrier's
            # path resolves through the re-export chain
            # standing along it to the std carrier, as a
            # binding spelling of the identical item
            # already does.
            if _std_ctx_rel() is not None:
                _ch30 = _chase_std_path(_std_ctx_rel(), list(_segs27))
                if _ch30 is not None and _ch30.rsplit("::", 1)[-1] in ("Box", "Rc", "Arc"):
                    return _ch30.rsplit("::", 1)[-1] + "<" + at.strip() + ">"
        # The qualified head (seam round 28, protest P1):
        # `<Box<Option<T>>>::new(...)` — the backward path
        # walk records no segments through the angle
        # group, so the carrier is read from the head the
        # caller spelled.
        _qm28 = re.search(r"<\s*(?:\w+\s*::\s*)*(Box|Rc|Arc)\s*<", head_text)
        if _qm28:
            return _qm28.group(1) + "<" + at.strip() + ">"
        return None
    if seg in ("take", "replace"):
        if _bare28 is not None or _path30 is not None:
            return re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", at.strip()).strip()
        _segs27 = _expand_module_segs(None, _path_segs_before(text, j))
        if _segs27 and _segs27[-1] == "mem":
            return re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", at.strip()).strip()
        return None
    if seg == "from":
        # The blanket identity impl (seam round 28, protest
        # P4; completed seam round 29, protest P2): `From<T>
        # for T` stands in the census beside the container
        # impls, and where the argument's determinable type
        # IS the denoted Self, that impl is the one the head
        # and the argument jointly select — the call
        # constructs Self itself, not Self over the
        # argument. Identity is a property of the impl, not
        # of the head's spelling: the agreement is checked
        # on the denoted Self of every head shape — the
        # qualified head, the plain and turbofish heads —
        # for a container Self, a non-container Self and a
        # reference Self alike, before the container gate
        # below; and the agreement is reference-sensitive,
        # so the `From<&Option<T>>` selection the reference
        # spellings below construct is not mistaken for it.
        _self29 = _from_self_text(head_text, text, j)
        if _self29 is not None:
            _exp29 = _expand_alias_text(_self29)
            _at29 = at
            if arg.strip().startswith("&") and not _at29.strip().startswith("&"):
                _sh29 = _arg_shape_text(arg, rmap)
                if _sh29 is not None and _sh29.strip().startswith("&"):
                    _at29 = _sh29
            if _at29.strip().startswith("&") == _exp29.strip().startswith("&") and \
                    _canon_type_text(_at29) == _canon_type_text(_exp29):
                return _exp29
        if head != "Option":
            return None
        if arg.strip().startswith("&") and not at.strip().startswith("&"):
            # The argument's reference stands in its shape
            # where the call-level text drops it (seam round
            # 27, protest P7): `From<&Option<T>>` is judged
            # at the reference the caller spelled.
            _sh27 = _arg_shape_text(arg, rmap)
            if _sh27 is not None and _sh27.strip().startswith("&"):
                at = _sh27
        _refm27 = re.match(r"^&\s*(?:'\w+\s+)?(mut\s+)?", at.strip())
        inner = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", at.strip()).strip()
        if inner != at.strip():
            parts = _result_option_parts(inner)
            if parts and parts[0] == "Option" and parts[1]:
                return "Option<&" + ("mut " if _refm27 and _refm27.group(1) else "") + parts[1][0] + ">"
        return "Option<" + at.strip() + ">"
    # from_iter: the argument is the iterator; its element is
    # a container whose payloads the result collects.
    elem = _iter_elem_of(at) or _generic_arg(at, 0)
    if elem is None:
        return None
    parts = _result_option_parts(elem)
    if head == "Option" and parts and parts[0] == "Option" and parts[1]:
        return "Option<Vec<" + parts[1][0] + ">>"
    if head == "Result" and parts and parts[0] == "Result" and len(parts[1]) >= 2:
        return "Result<Vec<" + parts[1][0] + ">, " + parts[1][1] + ">"
    return None


def _iter_chain_base31(text, open_idx):
    """Whether the call whose argument list opens at
    open_idx stands as a chain's base (seam round 31,
    protest P1): a method step follows its closing
    parenthesis — the position where the base's type is
    the judgement the chain stands on."""
    close = _delim_match(text, open_idx, "(", ")")
    if close < 0:
        return False
    k = close
    while k < len(text) and text[k].isspace():
        k += 1
    return k < len(text) and text[k] == "."


def _iter_base_refusal31(seg, eff, is_base):
    """The fail-closed-by-name refusal for a chain base
    whose denotation the std API census cannot determine
    (seam round 31, protest P1): where the call denotes a
    `std::iter` constructor but stands as no chain's base,
    the ordinary arms judge it and nothing is recorded;
    where it stands as a base, the census refuses, naming
    the base, rather than retain the chain by silence."""
    if not is_base:
        return
    msg = ("chain base with no determinable denotation: the call to `" + seg + "`"
           + ((" (denoting `std::iter::" + eff + "`)") if eff != seg else "")
           + " in " + str(_std_ctx_rel() or "the file being resolved") + " stands as a chain's base, and the std API census determines no element type for it; "
           + "the computation refuses by name rather than judge the chain by silence (seam round 31, protest P1)")
    if msg not in CHASE_FAILURES:
        CHASE_FAILURES.append(msg)


def _std_iter_ctor_text(text, open_idx, rmap, texts=None):
    """The iterator type text a standard iterator-constructor
    call constructs (seam round 30, protest P1): `std::iter`'s
    free constructors standing as a chain's base are typed at
    the element they yield — `once`, `repeat` and `repeat_n`
    at their first argument's type, `repeat_with` at its
    closure's return, `from_fn` at its closure's returned
    `Option`'s payload, `successors` at its first argument's
    type, `empty` at its turbofish — as `chain`'s argument
    already was typed where it stands as an argument. A call
    the spelled path does not denote as one of these
    constructors — a crate function of the name, a constructor
    of another module — is None here and stands judged by the
    ordinary arms."""
    end = open_idx
    while end > 0 and text[end - 1].isspace():
        end -= 1
    if end <= 0:
        return None
    turbo = None
    if text[end - 1] == ">":
        depth, j = 1, end - 2
        while j >= 0 and depth:
            if text[j] == ">":
                depth += 1
            elif text[j] == "<":
                depth -= 1
            j -= 1
        if depth:
            return None
        turbo = text[j + 2:end - 1].strip()
        end = j + 1
        while end > 0 and text[end - 1] == ":":
            end -= 1
    if end > 0 and text[end - 1] == ")":
        # A constructor arriving through a CALL RESULT
        # (seam round 33, protest P3): the callee is a
        # call whose declared return is function-shaped
        # at an iterator result — the returning item is
        # the carrier, judged at its declared return
        # exactly as a const item's declared type is.
        _depth33, _q33 = 1, end - 2
        while _q33 >= 0 and _depth33:
            if text[_q33] == ")":
                _depth33 += 1
            elif text[_q33] == "(":
                _depth33 -= 1
            _q33 -= 1
        if _depth33 == 0:
            _co33 = _q33 + 1
            _ce33 = _co33
            while _ce33 > 0 and text[_ce33 - 1].isspace():
                _ce33 -= 1
            if _ce33 > 0 and (text[_ce33 - 1].isalnum() or text[_ce33 - 1] == "_"):
                _cj33 = _ce33
                while _cj33 > 0 and (text[_cj33 - 1].isalnum() or text[_cj33 - 1] == "_"):
                    _cj33 -= 1
                _rt33 = _callee_return_text(text, _co33, rmap)
                _sh33 = _fn_shaped_iter33(_rt33)
                if _sh33 == "REFUSE33":
                    _iter_base_refusal31(text[_cj33:_ce33], text[_cj33:_ce33], _iter_chain_base31(text, open_idx))
                    return None
                if _sh33 is not None:
                    return _sh33
            # The FIELD carrier at the projection (seam
            # round 34, protest P3): a constructor held in
            # a struct field, called through the field of a
            # holder — `(HOLDER.field)(x)`, the only
            # compilable spelling — is consulted BEFORE
            # this branch may return None: the field's
            # declared function type judges the call, the
            # holder's own carrier (const item, static
            # item, call result, let binding) supplying the
            # holder's type, nested fields included.
            _pc34 = globals().get("_projection_ctor34")
            if _pc34 is not None:
                _fld34 = _pc34(text[_co33 + 1:end - 1], text, rmap, texts)
                if _fld34 == "REFUSE33":
                    _iter_base_refusal31(text[_co33 + 1:end - 1].strip(), text[_co33 + 1:end - 1].strip(), _iter_chain_base31(text, open_idx))
                    return None
                if _fld34 is not None:
                    return _fld34
        return None
    if end <= 0 or not (text[end - 1].isalnum() or text[end - 1] == "_"):
        return None
    j = end
    while j > 0 and (text[j - 1].isalnum() or text[j - 1] == "_"):
        j -= 1
    seg = text[j:end]
    # The constructor is typed by DENOTATION (seam round
    # 31, protest P1): the call denotes the `std::iter`
    # free constructor its spelled path resolves to, or
    # the one the consumer's own binding denotes — a
    # renamed import denotes the constructor it renames,
    # exactly as a renamed receiver or carrier does — and
    # the resolved constructor is typed by its signature's
    # form: at its argument's type (`once`, `repeat`,
    # `repeat_n`, `successors`), at its closure's return
    # (`once_with`, `repeat_with`), at its closure's
    # returned `Option` payload (`from_fn`), at the pair
    # of its two iterator arguments' elements (the free
    # `zip`), or at its turbofish (`empty`). The names
    # stand as an index of the signature forms, never as
    # the criterion: a call denoting no `std::iter`
    # constructor is None here and stands judged by the
    # ordinary arms, and a call denoting one whose element
    # the signature forms do not determine, or whose
    # element's type nothing in the call determines, fails
    # closed BY NAME where it stands as a chain's base —
    # never by silence.
    segs = _expand_module_segs(None, _path_segs_before(text, j))
    eff = None
    if segs and segs[-1] == "iter" and (len(segs) == 1 or segs[-2] in ("std", "core", "alloc")):
        eff = seg
    if eff is None and segs and _std_ctx_rel() is not None:
        _ch31 = _chase_std_path(_std_ctx_rel(), segs + [seg])
        if _ch31 is not None and _ch31.rsplit("::", 2)[-2:-1] == ["iter"]:
            eff = _ch31.rsplit("::", 1)[-1]
    if eff is None and _std_ctx_rel() is not None:
        for _local31, _scope31, _bsegs31, _pub31 in FILE_BINDINGS_RAW.get(_std_ctx_rel(), []):
            if _local31 != seg or not _bsegs31:
                continue
            _joined31 = "::".join(_bsegs31) if _bsegs31[0] in ("std", "core", "alloc") else _chase_std_path(_std_ctx_rel(), list(_bsegs31))
            if _joined31 is not None and _joined31.rsplit("::", 2)[-2:-1] == ["iter"]:
                eff = _joined31.rsplit("::", 1)[-1]
                break
    if eff is None and _std_ctx_rel() is not None:
        # The constructor bound to a name first (seam
        # round 32, protest P3): the binding in force —
        # the last binding of the name standing before
        # the call — spells the constructor's own path,
        # and the call is judged at the binding, as the
        # rider's sentence states. A binding spelling a
        # constructor's name through a carrier the
        # census cannot resolve fails closed by name at
        # the chain base, never by silence.
        _bind32 = None
        _binds33 = list(re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(seg) + r"\b\s*(?::[^=;]+)?=\s*((?:\w+\s*::\s*)*\w+)\s*;", text[:j]))
        for _lm32 in _binds33:
            if _binding_in_force33(text, _lm32.start(), j) is True:
                _bind32 = _lm32.group(1)
        if _bind32 is None and _binds33 and any(_binding_in_force33(text, _lm33.start(), j) is None for _lm33 in _binds33):
            _iter_base_refusal31(seg, seg, _iter_chain_base31(text, open_idx))
        if _bind32 is not None:
            _bsegs32 = [s.strip() for s in _bind32.split("::") if s.strip()]
            if _bsegs32:
                _joined32 = "::".join(_bsegs32) if _bsegs32[0] in ("std", "core", "alloc") else _chase_std_path(_std_ctx_rel(), list(_bsegs32))
                if _joined32 is not None and _joined32.rsplit("::", 2)[-2:-1] == ["iter"]:
                    eff = _joined32.rsplit("::", 1)[-1]
                elif _bsegs32[-1] in ("once", "once_with", "repeat", "repeat_n", "repeat_with", "from_fn", "successors", "empty", "zip"):
                    _iter_base_refusal31(seg, _bsegs32[-1], _iter_chain_base31(text, open_idx))
    if eff is None:
        # The constructor arriving through a carrier the
        # spelled and let-bound arms do not read (seam
        # round 33, protest P3): a const or static item,
        # a parameter, an annotated binding, a field —
        # each either resolves the constructor by
        # denotation or refuses by name at the base.
        _car33 = _ctor_carrier33(text, j, end, seg, segs, rmap, texts, open_idx)
        if _car33 is not None:
            return None if _car33 == "REFUSED33" else _car33
    if eff is None and segs and seg in ("once", "once_with", "repeat", "repeat_n", "repeat_with", "from_fn", "successors", "empty", "zip"):
        # The constructor spelled through a re-export of
        # the std::iter MODULE (seam round 32, protest
        # P3): the module segments' own chase denotes
        # the module, and the constructor stands at the
        # path's last segment exactly as the direct
        # spelling's does.
        _chm32 = _chase_std_path(_std_ctx_rel(), list(segs)) if _std_ctx_rel() is not None else None
        if _chm32 is not None and _chm32.rsplit("::", 1)[-1] == "iter" and _chm32.rsplit("::", 2)[-2:-1] in (["std"], ["core"], ["alloc"]):
            eff = seg
    if eff is None and _std_ctx_rel() is not None and seg in ("once", "once_with", "repeat", "repeat_n", "repeat_with", "from_fn", "successors", "empty", "zip"):
        # The constructor spelled bare through a glob
        # import (seam round 32, protest P3): a glob
        # binding of the file whose target module is
        # std::iter — directly, or through a re-export
        # of the module — supplies the constructor
        # exactly as a named binding of it does.
        for _local32, _scope32, _gsegs32, _pub32 in FILE_BINDINGS_RAW.get(_std_ctx_rel(), []):
            if _local32 != "*" or not _gsegs32:
                continue
            _mod32 = "::".join(_gsegs32) if _gsegs32[0] in ("std", "core", "alloc") else _chase_std_path(_std_ctx_rel(), list(_gsegs32))
            if _mod32 is not None and _mod32.rsplit("::", 1)[-1] == "iter" and _mod32.rsplit("::", 2)[-2:-1] in (["std"], ["core"], ["alloc"]):
                eff = seg
                break
    if eff is None:
        return None
    _base31 = _iter_chain_base31(text, open_idx)
    if eff == "empty":
        if turbo:
            return "__Iter<" + turbo + ">"
        _iter_base_refusal31(seg, eff, _base31)
        return None
    if eff == "zip":
        _args31 = _call_args(text, open_idx)
        _elems31 = []
        for _a31 in (_args31 or [])[:2]:
            _at31 = _expr_type_text_at(_a31, len(_a31), rmap, _texts_of(rmap, texts))
            if _at31 is None:
                _at31 = _arg_shape_text(_a31, rmap, texts)
            _e31 = (_iter_elem_of(_at31) or _generic_arg(_at31, 0)) if _at31 is not None else None
            _elems31.append(_e31)
        if len(_elems31) == 2 and all(_elems31):
            return "__Iter<(" + _elems31[0] + ", " + _elems31[1] + ")>"
        _iter_base_refusal31(seg, eff, _base31)
        return None
    arg = _first_arg_text(text, open_idx)
    if arg is None:
        _iter_base_refusal31(seg, eff, _base31)
        return None
    if eff in ("once", "repeat", "repeat_n", "successors"):
        at = _expr_type_text_at(arg, len(arg), rmap, _texts_of(rmap, texts))
        if at is None:
            at = _arg_shape_text(arg, rmap, texts)
        if at is None:
            at = _literal_type31(arg)
        if at is not None:
            return "__Iter<" + at.strip() + ">"
        _iter_base_refusal31(seg, eff, _base31)
        return None
    if eff in ("once_with", "repeat_with", "from_fn"):
        rt = _closure_return_text(arg, None, rmap)
        if rt is not None:
            if eff in ("once_with", "repeat_with"):
                return "__Iter<" + rt.strip() + ">"
            parts = _result_option_parts(rt)
            if parts and parts[0] == "Option" and parts[1]:
                return "__Iter<" + parts[1][0] + ">"
        _iter_base_refusal31(seg, eff, _base31)
        return None
    _iter_base_refusal31(seg, eff, _base31)
    return None


def _fn_value_return_text(ttext):
    """The return type text a function-shaped type text
    declares (seam round 30, protest P5): `fn(A) -> R`,
    `Fn(A) -> R`, `impl FnOnce(A) -> R` — the text after
    the parameter list's arrow, or `()` where no arrow
    stands."""
    if ttext is None:
        return None
    t = ttext.strip()
    m = re.search(r"\b(?:FnMut|FnOnce|Fn|fn)\s*\(", t)
    if not m:
        return None
    open_idx = t.find("(", m.start())
    end = _delim_match(t, open_idx, "(", ")")
    if end < 0:
        return None
    rest = t[end:].strip()
    if rest.startswith("->"):
        return rest[2:].strip() or None
    return "()"


def _resolved_free_return32(text, j, seg):
    """The declared return text of the free function the
    path spelled before the call denotes (seam round 32,
    protest P4): the path resolved through _resolve_item
    to the definition standing at the spelled module —
    the module's own definition, where a glob also
    supplies the name — and its return read from the
    per-definition record, never from the name-keyed
    merge of every definition of the name. None where
    the name has at most one production definition (the
    merge is that definition's own there), or where the
    path denotes no determinable free definition at the
    spelled module."""
    rel = _std_ctx_rel()
    if rel is None:
        return None
    segs = _expand_module_segs(None, _path_segs_before(text, j))
    # The call arm keyed as the glob stop is keyed
    # (seam round 33, protest P2): a definition standing
    # in the CALLER'S OWN file at the spelled local path
    # — a fn-body local module's function included — is
    # the call's binding, read from the per-definition
    # record; a same-named local definition in another
    # file is never the call's binding.
    _clean33 = [s for s in segs if s not in ("crate", "self", "super")]
    if _clean33:
        _own33 = [(r33, q33) for (r33, q33, _c33, _s33) in FN_LOCS.get(seg, []) if r33 == rel and q33.split("::")[-len(_clean33) - 1:-1] == _clean33]
        if len(_own33) == 1:
            return RETURN_FREE_QUAL.get(_own33[0])
    if len(FN_LOCS.get(seg, [])) <= 1:
        return None
    desc = _resolve_item(rel, segs + [seg])
    if desc is None or desc[0] != "free":
        return None
    mp = _resolve_modpath(rel, segs)
    for cand in _candidate_files(mp, rel):
        for (r, qual, _c, _s) in FN_LOCS.get(seg, []):
            if r == cand and "::".join(qual.split("::")[:-1]) == mp and _loc_module_scope32(_s):
                return RETURN_FREE_QUAL.get((cand, qual))
    return None


def _callee_expr32(text, open_idx):
    """The callee expression ending at the argument
    list opening at open_idx (seam round 32, protest
    P2): the backward walk over the expression's own
    shape — a name, a path, a field access, a call
    result, a grouping — stopping where the expression
    stops, so a value-position judgement reads the
    callee, not the whole text standing before it."""
    i = open_idx
    while i > 0 and text[i - 1].isspace():
        i -= 1
    while i > 0:
        c = text[i - 1]
        if c == ")":
            # find the matching open by scanning back
            depth, q = 1, i - 2
            while q >= 0 and depth:
                if text[q] == ")":
                    depth += 1
                elif text[q] == "(":
                    depth -= 1
                q -= 1
            if depth:
                break
            i = q + 1
            continue
        if c.isalnum() or c == "_":
            while i > 0 and (text[i - 1].isalnum() or text[i - 1] == "_"):
                i -= 1
            if i >= 2 and text[i - 2:i] == "::":
                i -= 2
                continue
            if i >= 1 and text[i - 1] == ".":
                i -= 1
                continue
            break
        if c == ">":
            depth, q = 1, i - 2
            while q >= 0 and depth:
                if text[q] == ">":
                    depth += 1
                elif text[q] == "<":
                    depth -= 1
                q -= 1
            if depth:
                break
            i = q + 1
            if i >= 2 and text[i - 2:i] == "::":
                i -= 2
            continue
        break
    return text[i:open_idx].strip()


def _from_path_self32(a):
    """The denoted Self text a `from` path spelling
    selects (seam round 32, protest P2): the type inside
    a qualified `<Self>::from`, the head with its
    arguments in a `Head::<args>::from`, the head itself
    in a `Head::from`. None where the spelling is no
    `from` path."""
    a = a.strip()
    m = re.fullmatch(r"<(.+)>\s*::\s*from", a, re.S)
    if m:
        inner = m.group(1)
        asm = re.match(r"^(.+?)\s+as\s+(?:\w+\s*::\s*)*\w+$", inner, re.S)
        return (asm.group(1) if asm else inner).strip()
    m = re.fullmatch(r"((?:\w+\s*::\s*)*\w+)\s*::<(.+)>\s*::\s*from", a, re.S)
    if m:
        head = [s.strip() for s in m.group(1).split("::") if s.strip()][-1]
        return head + "<" + m.group(2) + ">"
    m = re.fullmatch(r"(?:\w+\s*::\s*)*(\w+)\s*::\s*from", a, re.S)
    if m:
        return m.group(1)
    return None


def _struct_literal_fields32(body):
    """The (field, initialiser) pairs of a struct
    literal's brace body (seam round 32, protest P2):
    top-level comma-separated `field: expr` entries;
    shorthand entries carry no initialiser and are
    skipped."""
    out = []
    for part in _split_top(body):
        fm = re.match(r"^(\w+)\s*:\s*(.+)$", part.strip(), re.S)
        if fm:
            out.append((fm.group(1), fm.group(2).strip()))
    return out


def _from_value_denotation32(expr, text, rmap):
    """The (denoted Self, declared return) a fn VALUE
    expression denotes where it carries a `from` path
    (seam round 32, protest P2): the path itself; a call
    to a free function whose return expression is a
    `from` path value (the FREE_FN_FROM record); a field
    access whose field a construction initialises from
    a `from` path (the FIELD_FROM record), or whose
    receiver is a local bound to a construction
    initialising the field from such a value or from a
    call to such a function; and a bare local bound to
    any of those. None where the value denotes no
    determinable `from` path."""
    expr = expr.strip()
    while expr.startswith("(") and expr.endswith(")") and _delim_match(expr, 0, "(", ")") == len(expr):
        expr = expr[1:-1].strip()
    _self32 = _from_path_self32(expr)
    if _self32 is not None:
        return (_self32, None)
    fm = re.match(r"^(.+?)\s*\.\s*(\w+)\s*$", expr, re.S)
    if fm is not None:
        recv, field = fm.group(1).strip(), fm.group(2)
        _rt32 = _expr_type_text_at(recv, len(recv), rmap, _texts_of(rmap, None))
        if _rt32 is not None:
            _ident32 = _det_id(_rt32)
            if _ident32 is not None and (_ident32, field) in FIELD_FROM:
                return FIELD_FROM[(_ident32, field)]
        if re.fullmatch(r"\w+", recv):
            _bm32 = None
            for _lm32 in re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(recv) + r"\b\s*(?::[^=;]+)?=\s*(\w+)\s*\{", text):
                _bm32 = _lm32
            if _bm32 is not None:
                _bend32 = _brace_match(text, _bm32.end() - 1)
                if _bend32 > 0:
                    for _f32, _init32 in _struct_literal_fields32(text[_bm32.end():_bend32 - 1]):
                        if _f32 == field:
                            return _from_value_denotation32(_init32, text, rmap)
        return None
    cm = re.match(r"^((?:\w+\s*::\s*)*\w+)\s*(?:::\s*<.*>)?\s*\(", expr, re.S)
    if cm is not None and expr.endswith(")"):
        _segs32 = [s.strip() for s in cm.group(1).split("::") if s.strip()]
        if _segs32 and _segs32[-1] != "from":
            _desc32 = _resolve_item(_std_ctx_rel(), _segs32) if _std_ctx_rel() is not None else None
            if _desc32 is not None and _desc32[0] == "free" and (_desc32[2], _desc32[1]) in FREE_FN_FROM:
                return FREE_FN_FROM[(_desc32[2], _desc32[1])]
            _cands32 = [v for (r32, n32), v in FREE_FN_FROM.items() if n32 == _segs32[-1]]
            if len(_cands32) == 1:
                return _cands32[0]
        return None
    if re.fullmatch(r"\w+", expr):
        _bm32 = None
        for _lm32 in re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(expr) + r"\b\s*(?::[^=;]+)?=\s*(.+?)\s*;", text, re.S):
            _bm32 = _lm32
        if _bm32 is not None:
            return _from_value_denotation32(_bm32.group(1), text, rmap)
    return None


def _from_call_through32(text, open_idx, rmap):
    """The type text a call THROUGH a fn value constructs
    where the value denotes a `from` path at the return
    or field position (seam round 32, protest P2): the
    callee is a call's result, a field's value, or a
    local bound to one of those — the positions the
    wrapper census's return-yield and field-carriage
    derivations already read for wrapper paths — and
    the call constructs what the same path standing as
    a call head constructs from its argument, at the
    declared return where the argument's standing
    determines nothing. A callee spelled as a plain
    path or name is no value position and is None here."""
    callee = _callee_expr32(text, open_idx)
    if not callee:
        return None
    if re.fullmatch(r"(?:\w+\s*::\s*)+\w+", callee):
        return None
    _den32 = _from_value_denotation32(callee, text, rmap)
    if _den32 is None:
        return None
    _self32, _decl32 = _den32
    arg = _first_arg_text(text, open_idx)
    if arg is not None and _self32 is not None:
        at = _expr_type_text_at(arg, len(arg), rmap, _texts_of(rmap, None))
        if at is None:
            at = _arg_shape_text(arg, rmap, _texts_of(rmap, None))
        if at is not None:
            _c32 = _from_value_construct31(_self32, at)
            if _c32 is not None:
                return _c32
    return _decl32


def _from_value_call_text(text, open_idx, rmap):
    """The type text a call through a fn-typed binding
    initialised by a `from` path VALUE constructs (seam
    round 30, protest P5): `<Option<Built>>::from` standing
    as a value — bound to a local whose declared type is a
    function type, and called through the binding — denotes
    the `From` implementation the path selects, exactly as
    the same path standing as a call head does; the
    binding's declared argument and return texts are the
    agreement the constructor arm checks at a head — where
    they agree the identity is constructed, where they
    stand as payload and container the container is — and
    in every case the call stands at the declared return.
    A binding initialised by anything else, or typed by no
    function type, is None here and stands judged by the
    ordinary arms."""
    end = open_idx
    while end > 0 and text[end - 1].isspace():
        end -= 1
    if end <= 0 or not (text[end - 1].isalnum() or text[end - 1] == "_"):
        return None
    j = end
    while j > 0 and (text[j - 1].isalnum() or text[j - 1] == "_"):
        j -= 1
    seg = text[j:end]
    # A const or static binding of the name (seam round
    # 31, protest P7): a binding declared at a function
    # type in an item of its own, initialised by the same
    # path value — the const/static initialiser position
    # stands in the same family as the let position, and
    # the call through the binding constructs by the
    # binding's declared return text, across files as
    # within one, spelled bare or by path alike.
    if seg in FN_VALUE_FROM and _free_return_text(seg) is None:
        return FN_VALUE_FROM[seg]
    if j >= 2 and text[j - 2:j] == "::":
        return None
    if j >= 1 and text[j - 1] == ".":
        return None
    if _free_return_text(seg) is not None:
        return None
    ret = _fn_value_return_text(_texts_of(rmap, None).get(seg))
    if ret is not None and re.search(r"\blet\s+(?:mut\s+)?" + re.escape(seg) + r"\b[^;]*?=\s*(?:<.*>::\s*from|(?:\w+\s*::\s*)*\w+\s*::\s*from)\s*;", text[:j], re.S):
        return ret
    return None




MACRO_BRACE34 = {}  # macro name -> "pass" | "block" | "unknown": the brace behaviour of its expansion (seam round 34, protest P1)
MACRO_DEFS35 = {}  # file -> [(definition offset, name, brace kind, scope chain)] in standing order, over the cfg-decided census text (seam round 35, protest P3; the scope chain seam round 36, protest P3)
MACRO_BODIES36 = {}  # (defining file, macro name) -> [(definition offset, scope chain, definition body text, exported)] in standing order, over the cfg-decided census text — keyed as MACRO_DEFS35 is keyed, never by bare name at the first body (seam round 36, protest P6; seam round 37, protest P5)


def _macro_name_at36(code, pos):
    """The name of the `macro_rules!` definition whose body
    contains `pos` in `code`, or None (seam round 36,
    protest P7)."""
    for m in re.finditer(r"\bmacro_rules!\s*(\w+)", code):
        j = m.end()
        while j < len(code) and code[j] not in "{[(":
            j += 1
        if j >= len(code):
            continue
        end = _delim_match(code, j, code[j], {"{": "}", "[": "]", "(": ")"}[code[j]])
        if m.start() <= pos < end:
            return m.group(1)
    return None


def _scope_chain36(code, pos):
    """The scope chain enclosing `pos` in `code` (seam round
    36, protest P3; the block term seam round 37, protest
    P3): the keys of the scopes — inline modules and fn
    bodies, as _scope_spans records them, and every bare
    block — that enclose the position, outermost first. A definition's
    chain against an invocation's chain is the scope term
    name resolution keys a macro definition by: a
    definition stands for an invocation exactly where
    every scope enclosing the definition also encloses the
    invocation."""
    _sp36 = globals().get("_scope_spans")
    if _sp36 is None:
        return ()
    enc = [s for s in _sp36(code) if s["start"] < pos < s["end"]]
    # The block term (seam round 37, protest P3): a bare
    # block is a scope for a macro definition exactly as
    # it is for a binding — the text's brace pairs stand
    # in the chain beside the fn and module scopes (a
    # pair whose opening brace is a recorded scope's own
    # brace is that scope, not a second term), so a
    # definition inside a bare block carries the block
    # in its chain and stands only for invocations the
    # block also encloses.
    _starts37 = {s["start"] for s in enc}
    _stack37 = []
    _pairs37 = []
    for _i37, _ch37 in enumerate(code):
        if _ch37 == "{":
            _stack37.append(_i37)
        elif _ch37 == "}" and _stack37:
            _pairs37.append((_stack37.pop(), _i37 + 1))
    for _a37, _b37 in _pairs37:
        if _a37 < pos < _b37 and _a37 not in _starts37:
            enc.append({"kind": "block", "key": ("block", _a37), "start": _a37, "end": _b37})
    enc.sort(key=lambda s: s["start"])
    return tuple(s["key"] for s in enc)


def _macro_defs_at35(code):
    """Every `macro_rules!` definition in `code` as
    (offset, name, brace kind, scope chain), in standing
    order (seam round 35, protest P3; the scope chain seam
    round 36, protest P3): _macro_defs' reading, keeping
    the position and the scope name resolution keys on."""
    out = []
    _sc36 = globals().get("_scope_chain36")
    for m in re.finditer(r"\bmacro_rules!\s*(\w+)", code):
        j = m.end()
        while j < len(code) and code[j] not in "{[(":
            j += 1
        if j >= len(code):
            continue
        close = {"{": "}", "[": "]", "(": ")"}[code[j]]
        end = _delim_match(code, j, code[j], close)
        out.append((m.start(), m.group(1), _macro_brace_kind34(code[j:end]), _sc36(code, m.start()) if _sc36 is not None else ()))
    return out


def _macro_kind35(name, text, inv_pos):
    """The brace kind of the definition of `name` IN FORCE
    at the invocation standing at `inv_pos` in `text`
    (seam round 35, protest P3), keyed as name resolution
    keys it: the invoking file's own definitions first, in
    standing order — the last one standing before the
    invocation, its position read in the file's census
    text exactly as _cfg_truths_raw35 reads a cfg's span —
    and `sys`'s definitions, whose macros stand exported
    crate-wide, where the invoking file defines none. A
    definition under a cfg false on the one target stands
    in no file's list (the census text it was read from
    already removed it), so it is absent here as it is in
    every build. "unknown" where the standing cannot be
    assigned to one definition, which the reading arm
    refuses by name; None where no definition of the name
    stands anywhere the invocation can reach. Seam round
    36 (protest P3): name resolution keys a definition by
    SCOPE as well — a definition stands for the invocation
    only where every scope enclosing the definition (a fn
    body, an inline module) also encloses the invocation,
    so a fn-body-local or inline-module definition decides
    only inside its own scope, exactly as the scope
    discipline the binding arms keep already reads it."""
    rel = _std_ctx_rel()
    defs = [d for d in (globals().get("MACRO_DEFS35") or {}).get(rel, []) if d[1] == name] if rel else []
    _own36 = bool(defs)
    if not defs and rel != SYS_DECL_REL:
        defs = [d for d in (globals().get("MACRO_DEFS35") or {}).get(SYS_DECL_REL, []) if d[1] == name]
    if not defs:
        # No definition stands in the invoking file or
        # in `sys`: the name can reach the invocation
        # only as an exported macro's (seam round 37,
        # protest P5's sweep) — its brace kind is the
        # exported definition's, where exactly one
        # exported body stands; more than one distinct
        # exported body is "unknown", which the reading
        # arm refuses by name. The bare-name first-seen
        # table (MACRO_BRACE34) is read only where no
        # production definition of the name stands in
        # any recorded table.
        _mb37 = globals().get("MACRO_BODIES36") or {}
        _exp37 = {_e37[2] for _k37, _ents37 in _mb37.items() if _k37[1] == name for _e37 in _ents37 if _e37[3]}
        if len(_exp37) == 1:
            return _macro_brace_kind34(_exp37.pop())
        if len(_exp37) > 1:
            return "unknown"
        return (globals().get("MACRO_BRACE34") or {}).get(name)
    if _own36:
        _sc36 = globals().get("_scope_chain36")
        code = (globals().get("CODE_BY_REL35") or {}).get(rel) if rel else None
        if _sc36 is not None and code is not None:
            first = code.find(text)
            if first >= 0 and code.find(text, first + 1) < 0:
                _inv36 = first + inv_pos
                _chain36 = set(_sc36(code, _inv36))
                _vis36 = [d for d in defs if d[0] < _inv36 and len(d) > 3 and set(d[3]) <= _chain36]
                if _vis36:
                    return _vis36[-1][2]
                return "unknown"
    if len(defs) == 1:
        return defs[0][2]
    code = (globals().get("CODE_BY_REL35") or {}).get(rel) if rel else None
    if code is not None:
        first = code.find(text)
        if first >= 0 and code.find(text, first + 1) < 0:
            standing = [d for d in defs if d[0] < first + inv_pos]
            if standing:
                return standing[-1][2]
            return "unknown"
    return "unknown"


def _macro_brace_kind34(mbody):
    """The brace behaviour a `macro_rules!` definition's
    expansion denotes (seam round 34, protest P1): "pass"
    where the transcription splices its tokens into the
    enclosing scope and contributes no brace of its own,
    "block" where the transcription wraps its tokens in a
    block, and "unknown" where the definition's text
    decides neither — the standing the reading arms refuse
    BY NAME, naming the macro and the file."""
    kinds = []
    idx = mbody.find("=>")
    if idx < 0:
        return "unknown"
    t = mbody[idx + 2:].strip()
    if t.endswith("}"):
        t = t[:-1].strip()
    if t.endswith(";"):
        t = t[:-1].strip()
    if not (t.startswith("{") and _delim_match(t, 0, "{", "}") == len(t)):
        return "unknown"
    inner = t[1:-1].strip()
    if inner.startswith("{") and _delim_match(inner, 0, "{", "}") == len(inner):
        kinds.append("block")
    elif re.fullmatch(r"\$\(.*?\)\s*[*+?]", inner, re.S) or re.fullmatch(r"\$\w+", inner):
        kinds.append("pass")
    else:
        kinds.append("unknown")
    return kinds[0] if kinds and all(k == kinds[0] for k in kinds) else "unknown"


def _cfg_eval34(content):
    """The truth of one cfg expression under the crate's one
    denotation target (seam round 34, protest P2): the
    compile-time refusal at the crate root makes
    `target_os = "windows"` the only target any denotation
    in this tree can have, so a cfg whose truth the target
    facts decide is True or False here; a cfg they do not
    decide is None — undecidable, which the reading arms
    refuse BY NAME, naming the cfg and the file."""
    # A cfg value arriving by macro substitution (seam
    # round 36, protest P7): the content spells a
    # metavariable (`$v`), whose substituted value stands
    # at the invocation, not at this span — undecidable
    # here, and never decided from the parameter's own
    # spelling, in either direction.
    if "$" in content:
        return None
    toks = re.findall(r'"[^"]*"|\w+|[(),=]', content)
    pos = [0]

    def peek():
        return toks[pos[0]] if pos[0] < len(toks) else None

    def parse():
        t = peek()
        if t is None:
            return None
        if t in ("all", "any") and pos[0] + 1 < len(toks) and toks[pos[0] + 1] == "(":
            op = t
            pos[0] += 2
            vals = []
            if peek() == ")":
                pos[0] += 1
                return (op == "all")
            while True:
                vals.append(parse())
                if peek() == ",":
                    pos[0] += 1
                    continue
                if peek() == ")":
                    pos[0] += 1
                break
            if op == "all":
                if any(v is False for v in vals):
                    return False
                if any(v is None for v in vals):
                    return None
                return True
            if any(v is True for v in vals):
                return True
            if any(v is None for v in vals):
                return None
            return False
        if t == "not" and pos[0] + 1 < len(toks) and toks[pos[0] + 1] == "(":
            pos[0] += 2
            v = parse()
            if peek() == ")":
                pos[0] += 1
            return None if v is None else (not v)
        if re.fullmatch(r"\w+", t):
            pos[0] += 1
            if peek() == "=":
                pos[0] += 1
                val = peek()
                if val is not None and val not in (")", ","):
                    pos[0] += 1
                else:
                    val = None
                # A cfg value is a string literal by the
                # grammar of cfg, and the census lexer
                # blanks literal contents, so an equality
                # whose value arrives blanked in this text
                # was never read in this text: it is
                # undecidable here and its reader refuses
                # by name (seam round 35, protest P1).
                # The spelled values are recovered from
                # the raw text at the cfg's own span —
                # when the census text is built
                # (_cfg_dead_spans35) and at the binding
                # arm (_cfg_truth34's raw reading) — and
                # an equality standing in raw text is
                # compared as spelled, against the crate's
                # one denotation target.
                if val is None or not val.strip('"').strip():
                    return None
                val = val.strip('"').strip()
                if t == "target_os":
                    return val == "windows"
                if t == "target_family":
                    return val == "windows"
                return None
            if t == "test":
                # The census text is production text by
                # construction, so `test` is false in it —
                # the production definition cfg_test_spans
                # already enacts (seam round 35, protest P2).
                return False
            if t == "windows":
                return True
            if t == "unix":
                return False
            return None
        pos[0] += 1
        return None

    if not toks:
        return None
    return parse()


def _cfg_truth34(text, bind_pos):
    """The cfg existence of the binding standing at
    `bind_pos` in `text` (seam round 34, protest P2): the
    `#[cfg(...)]` attributes standing immediately before
    the binding, evaluated against the crate's one
    denotation target, as (truth, cfg text) — truth True
    where no cfg stands or every standing cfg holds, False
    where one is false on the target (the binding is
    ABSENT: it neither shadows nor is shadowed), and None
    where a standing cfg's truth the target facts do not
    decide, with the cfg's text for the refusal by name."""
    s = text[:bind_pos]
    truths = []
    while True:
        t = s.rstrip()
        if not t.endswith("]"):
            break
        k = t.rfind("#[")
        if k < 0 or not t[k:].startswith("#[cfg("):
            break
        attr = t[k:]
        open_idx = attr.find("(")
        end = _delim_match(attr, open_idx, "(", ")")
        if end < 0 or attr[end:].strip() != "]":
            break
        truths.append((_cfg_eval34(attr[open_idx + 1:end - 1]), attr[2:end], (k + open_idx + 1, k + end - 1)))
        s = t[:k]
    if not truths:
        return (True, None)
    if any(v is None for v, _c, _sp in truths):
        # The raw reading (seam round 35, protest P1): a
        # cfg value blanked in this text is recovered from
        # the raw text at the cfg's own span and the
        # equality is decided by the spelled string; a
        # value that cannot be recovered stands
        # undecidable, and the caller refuses by name.
        _raw35 = globals().get("_cfg_truths_raw35")
        _rec35 = _raw35(text, [sp for _v, _c, sp in truths]) if _raw35 is not None else None
        if _rec35 is not None:
            truths = [(rv, c, sp) for rv, (_v, c, sp) in zip(_rec35, truths)]
    for v, c, _sp in truths:
        if v is False:
            return (False, c)
    for v, c, _sp in truths:
        if v is None:
            return (None, c)
    return (True, None)


def _cfg_truths_raw35(text, spans):
    """The truths of the cfg contents standing at `spans`
    in `text`, read from the RAW text (seam round 35,
    protest P1): the raw text of the file being resolved,
    at the same offsets — the raw and census texts stand
    offset-aligned in the registries, and `text` must
    stand in the census text at exactly one offset for
    the reading to be assigned to it. None where the
    reading cannot be assigned, which its caller refuses
    by name."""
    rel = _std_ctx_rel()
    if rel is None:
        return None
    raw = (globals().get("RAW_BY_REL35") or {}).get(rel)
    code = (globals().get("CODE_BY_REL35") or {}).get(rel)
    if raw is None or code is None or len(raw) != len(code):
        return None
    first = code.find(text)
    if first < 0 or code.find(text, first + 1) >= 0:
        return None
    return [_cfg_eval34(raw[first + a:first + b]) for (a, b) in spans]


def _split_dots34(s):
    """`s` split at its top-level `.` separators (seam round
    34, protest P3): a projection chain's holder and fields,
    the dots inside a call's arguments or a path's turbofish
    standing below the top level."""
    out, depth, cur = [], 0, ""
    for ch in s:
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        if ch == "." and depth == 0:
            out.append(cur)
            cur = ""
            continue
        cur += ch
    out.append(cur)
    return [p.strip() for p in out]


def _closure_base_type35(base, text, rmap, texts):
    """The declared type text of a projection base that is
    a CALL through a closure or fn value (seam round 35,
    protest P5): the callee is a locally bound name whose
    value is a closure — its own literal, or an item's
    returned closure under an `impl Fn(...) -> T` return —
    or an annotated fn-typed binding, and the base's type
    is the callee's return read at the DEFINITION SITE in
    the item text the base stands in, the road
    _closure_call_return34 already walks for the callee
    twins, never from the severed fragment `name()` where
    no binding stands. An annotated fn-typed binding at
    the site is read at its declared return first: the
    annotation is the site's own spelling of the value's
    type. None where the base denotes no such value."""
    b = base.strip()
    m = re.fullmatch(r"(\w+)\s*\((.*)\)", b, re.S)
    if not m:
        return None
    seg = m.group(1)
    _ann35 = None
    for lm in re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(seg) + r"\b\s*:\s*([^=;]+?)\s*=", text):
        _ann35 = lm.group(1).strip()
    if _ann35 is not None:
        rt = _fn_value_return_text(_ann35)
        if rt is not None:
            return rt
    _cc34 = globals().get("_closure_call_return34")
    if _cc34 is None:
        return None
    for cm in re.finditer(r"\b" + re.escape(seg) + r"\s*\(", text):
        rt = _cc34(text, cm.end() - 1, rmap)
        if rt is not None:
            return rt
    # A closure whose body is a const or static item's
    # path (seam round 35, protest P5's const-bodied
    # faces): the body stands at the item's declared type,
    # read at the definition site — the binding in force
    # at a spelling of the call, its closure literal's
    # body's return expressions, and a path body read in
    # the const tables exactly as _base_type_text34 reads
    # a const base at its declared type.
    _bif35 = globals().get("_binding_in_force33")
    _cb35f = globals().get("_closure_body")
    _ci35 = globals().get("CONST_ITEMS33") or {}
    if _bif35 is None or _cb35f is None:
        return None
    for cm in re.finditer(r"\b" + re.escape(seg) + r"\s*\(", text):
        _best35 = None
        for _lm35 in re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(seg) + r"\b\s*(?::\s*[^=;]+?)?\s*=\s*", text[:cm.start()]):
            if _bif35(text, _lm35.start(), cm.start()) is True:
                _best35 = _lm35
        if _best35 is None:
            continue
        _i35, _d35, _k35 = _best35.end(), 0, _best35.end()
        while _k35 < len(text):
            _c35 = text[_k35]
            if _c35 in "([{":
                _d35 += 1
            elif _c35 in ")]}":
                if _d35 == 0:
                    break
                _d35 -= 1
            elif _c35 == ";" and _d35 == 0:
                break
            _k35 += 1
        _init35 = text[_i35:_k35].strip()
        if _init35.startswith("move") and _init35[4:5].isspace():
            _init35 = _init35[4:].strip()
        _body35 = _cb35f(_init35)
        if _body35 is None:
            continue
        _exprs35 = _return_exprs(_body35) if _body35.strip().startswith("{") else [_body35]
        for _e35 in _exprs35:
            _pm35 = re.fullmatch(r"((?:\w+\s*::\s*)*)(\w+)", _e35.strip())
            if not _pm35 or not _ci35.get(_pm35.group(2)):
                continue
            _cands35 = _ci35[_pm35.group(2)]
            _rel35 = _std_ctx_rel()
            _pref35 = [c for c in _cands35 if c[0] == _rel35]
            _pick35 = _pref35[0] if len(_pref35) == 1 else (_cands35[0] if len(_cands35) == 1 else None)
            if _pick35 is not None:
                return _pick35[1]
    # A closure standing in a macro expansion (seam round
    # 36, protest P6): the binding's initialiser is an
    # invocation, and the closure's definition site stands
    # in the macro's template — the expansion the
    # invocation denotes is read at the invocation site
    # (the definition site this computation keys on), for
    # an #[macro_export] macro as for a consumer-local
    # one, and the expanded text is typed as a spelled
    # closure is typed.
    _mb36 = globals().get("MACRO_BODIES36") or {}
    _ea36 = globals().get("_macro_expr_arms")
    _ex36 = globals().get("_macro_expand_invocation")
    if _mb36 and _ea36 is not None and _ex36 is not None:
        # The binding in force (seam round 37, protest
        # P4): the road reads the binding of the name
        # that stands at a call of it — the last binding
        # before the call that encloses it, as
        # _binding_in_force33 decides — never the first
        # binding in the text whose expansion types.
        for _cm37 in re.finditer(r"\b" + re.escape(seg) + r"\s*\(", text):
            _lm36 = None
            for _lm37 in re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(seg) + r"\b\s*(?::\s*[^=;]+?)?\s*=\s*", text[:_cm37.start()]):
                if _bif35(text, _lm37.start(), _cm37.start()) is True:
                    _lm36 = _lm37
            if _lm36 is None:
                continue
            _i36, _d36, _k36 = _lm36.end(), 0, _lm36.end()
            while _k36 < len(text):
                _c36 = text[_k36]
                if _c36 in "([{":
                    _d36 += 1
                elif _c36 in ")]}":
                    if _d36 == 0:
                        break
                    _d36 -= 1
                elif _c36 == ";" and _d36 == 0:
                    break
                _k36 += 1
            _init36 = text[_i36:_k36].strip()
            _im36 = re.match(r"^(?:\w+\s*::\s*)*(\w+)\s*!\s*([\(\{\[])", _init36)
            if not _im36:
                continue
            _open36 = _im36.end() - 1
            _close36 = {"(": ")", "{": "}", "[": "]"}[_init36[_open36]]
            _end36 = _delim_match(_init36, _open36, _init36[_open36], _close36)
            if _end36 < 0:
                continue
            _args36 = _init36[_open36 + 1:_end36 - 1]
            # The definition in force (seam round 37,
            # protest P5): the body read is the
            # definition of the name standing in the
            # invoking file at the invocation — the last
            # definition before it whose scope chain the
            # invocation's chain carries, over the
            # cfg-decided text — never the first body
            # recorded for the name.
            _name37 = _im36.group(1)
            _rel36 = _std_ctx_rel()
            _own36 = _mb36.get((_rel36, _name37), [])
            _pick36 = None
            if _own36:
                _code37 = (globals().get("CODE_BY_REL35") or {}).get(_rel36) if _rel36 else None
                _sc37 = globals().get("_scope_chain36")
                _inv37 = None
                if _code37 is not None and _sc37 is not None:
                    _f37 = _code37.find(text)
                    if _f37 >= 0 and _code37.find(text, _f37 + 1) < 0:
                        _inv37 = _f37 + _i36
                if _inv37 is not None:
                    _chain37 = set(_sc37(_code37, _inv37))
                    _vis37 = [c for c in _own36 if c[0] < _inv37 and set(c[1]) <= _chain37]
                    if _vis37:
                        _pick36 = _vis37[-1][2]
                elif len(_own36) == 1:
                    _pick36 = _own36[0][2]
                else:
                    _msg37 = ("macro definition in force undecidable: the invocation of the macro `" + _name37 + "` in " + str(_rel36 or "the file being resolved")
                              + " stands in a text the census cannot assign to one offset of its file, and the file records more than one definition of the name; "
                              + "the computation refuses by name rather than read the first body recorded (seam round 37, protest P5)")
                    if _msg37 not in CHASE_FAILURES:
                        CHASE_FAILURES.append(_msg37)
                    continue
            if _pick36 is None:
                _expb36 = [c[2] for _k37, _ents37 in _mb36.items() if _k37[1] == _name37 for c in _ents37 if c[3]]
                if len(set(_expb36)) == 1:
                    _pick36 = _expb36[0]
            if _pick36 is None:
                continue
            _expn36 = _ex36(_args36, _ea36(_pick36))
            if _expn36 is None or (_im36.group(1) + "!") in _expn36:
                continue
            _fake36 = "let " + seg + " = " + _expn36 + "; " + base
            _rt36 = _closure_base_type35(base, _fake36, rmap, texts)
            if _rt36 is not None:
                return _rt36
    return None


def _base_type_text34(base, text, rmap, texts, depth34=0):
    """The declared type TEXT of a projection chain's base
    expression (seam round 34, protest P3): a call result at
    its callee's declared return, a const or static item at
    its declared type, a let-bound name at its binding's
    value — each level resolved by denotation, as the
    carrier family the grammar gives is resolved."""
    texts = _texts_of(rmap, texts)
    base = base.strip()
    while base.startswith("(") and _delim_match(base, 0, "(", ")") == len(base):
        base = base[1:-1].strip()
    if not base:
        return None
    _cb35 = globals().get("_closure_base_type35")
    if _cb35 is not None:
        # A closure-typed base is typed at its definition
        # site BEFORE the fragment reading (seam round 35,
        # protest P5): the fragment `name()` carries no
        # binding, and the name-keyed reading inside it
        # merges definitions the site does not stand in.
        _ct35 = _cb35(base, text, rmap, texts)
        if _ct35 is not None:
            return _ct35
    tt = _expr_type_text_at(base, len(base), rmap, texts)
    if tt is not None:
        return tt
    if depth34 > 3:
        return None
    last = [s.strip() for s in base.split("::") if s.strip()][-1] if "::" in base else base
    if re.fullmatch(r"\w+", last) and globals().get("CONST_ITEMS33", {}).get(last):
        cands = CONST_ITEMS33[last]
        rel = _std_ctx_rel()
        pref = [c for c in cands if c[0] == rel]
        pick = pref[0] if len(pref) == 1 else (cands[0] if len(cands) == 1 else None)
        if pick is not None:
            return pick[1]
    if re.fullmatch(r"\w+", base):
        got = _texts_of(rmap, texts).get(base)
        if got is not None:
            return got
        for lm in re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(base) + r"\b\s*(?::[^=;]+)?=\s*(.+?)\s*;", text, re.S):
            init = lm.group(1).strip()
            if "." in init:
                ft = _projection_field_type34(init, rmap, texts, depth34 + 1)
                if ft is not None:
                    return ft
            bt = _base_type_text34(init, text, rmap, texts, depth34 + 1)
            if bt is not None:
                return bt
    return None


def _projection_field_type34(expr, rmap, texts, depth34=0, srctext=None):
    """The declared type text of the LAST field of the
    projection chain `expr` (seam round 34, protest P3):
    the holder's type resolved by denotation at each level
    — nested fields included — and each field read at its
    declared type in its defining struct. None where any
    level determines nothing."""
    texts = _texts_of(rmap, texts)
    parts = _split_dots34(expr.strip())
    if len(parts) < 2:
        return None
    # `text` for the base's own bindings: the projection
    # stands in the item text the caller resolves over;
    # the base routes that need it search the expression
    # itself and the receiver map's texts.
    tt = _base_type_text34(parts[0], srctext if srctext is not None else expr, rmap, texts, depth34)
    if tt is None:
        return None
    for f in parts[1:]:
        _cm36 = re.fullmatch(r"(\w+)\s*\(.*\)", f, re.S)
        if _cm36:
            # A method step in the chain (seam round 36,
            # protest P5): the segment is a call, and the
            # chain stands at the method's declared return —
            # a trait method's default body at the trait's
            # declared return, as _meth_return_text reads
            # it — before the next field is read.
            _mr36 = globals().get("_meth_return_text")
            _nt36 = _mr36(tt, _cm36.group(1)) if _mr36 is not None else None
            if _nt36 is None:
                return None
            tt = _nt36
            continue
        if not re.fullmatch(r"\w+", f):
            return None
        _ft35 = _substituted_field_text(tt, f)
        if _ft35 is None:
            # The Deref step (seam round 35, protest P4): a
            # field access reaches its field through
            # auto-deref — where the head declares no field
            # of the name, the head stands at its Deref
            # target and the field is read there, the step
            # repeated down the chain with the receiver
            # arms' own classes and cycle guard: a
            # reference's target, the std Deref heads'
            # first generic argument (Box, Rc, Arc, Cow and
            # the recorded guard heads), and an in-tree
            # type's recorded Deref target, as
            # _deref_target_text reads them for receivers.
            _dt35 = globals().get("_deref_target_text")
            _seen35 = set()
            _cur35 = tt
            while _ft35 is None and _dt35 is not None and _cur35 is not None and _cur35 not in _seen35:
                _seen35.add(_cur35)
                _cur35 = _dt35(_cur35)
                if _cur35 is None:
                    break
                _ft35 = _substituted_field_text(_cur35, f)
            if _ft35 is None:
                return None
        tt = _ft35
    return tt


def _projection_ctor34(inner, srctext, rmap, texts):
    """The iterator type text a parenthesised projection
    heading a call constructs (seam round 34, protest P3):
    `(HOLDER.field)(x)` — a constructor held in a struct
    field, called through the field of its holder — read
    at the field's declared function type, exactly as a
    const item's declared type is read. The sentinel
    "REFUSED33" where the field's type names a constructor
    result but no element; None where the projection is no
    field-held constructor."""
    inner = inner.strip()
    if len(_split_dots34(inner)) < 2:
        return None
    ft = _projection_field_type34(inner, rmap, texts, 0, srctext)
    if ft is None:
        return None
    return _fn_shaped_iter33(ft)


def _closure_call_return34(text, open_idx, rmap):
    """The return type text a call through a locally bound
    CLOSURE stands at (seam round 34, protest P4): a local
    closure is an item of its defining scope for this
    computation — its annotated return where it stands
    annotated, its body's determined return where the body
    spells it, exactly as a fn's are judged — and a binding
    whose value is a call whose callee declares an
    `impl Fn(...) -> T` (or any function-shaped) return
    stands at T, the closure class the return position
    names. Keyed by DEFINITION SITE: the binding in force
    at the call, in the call's own item text. None where
    the call denotes no such closure."""
    end = open_idx
    while end > 0 and text[end - 1].isspace():
        end -= 1
    if end <= 0 or not (text[end - 1].isalnum() or text[end - 1] == "_"):
        return None
    j = end
    while j > 0 and (text[j - 1].isalnum() or text[j - 1] == "_"):
        j -= 1
    if j >= 2 and text[j - 2:j] == "::":
        return None
    if j >= 1 and text[j - 1] == ".":
        return None
    seg = text[j:end]
    best = None
    for m in re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(seg) + r"\b\s*(?::\s*[^=;]+?)?\s*=\s*", text[:j]):
        if _binding_in_force33(text, m.start(), j) is True:
            best = m
    if best is None:
        return None
    i, depth, k = best.end(), 0, best.end()
    while k < len(text):
        c = text[k]
        if c in "([{":
            depth += 1
        elif c in ")]}":
            if depth == 0:
                break
            depth -= 1
        elif c == ";" and depth == 0:
            break
        k += 1
    init = text[i:k].strip()
    if init.startswith("move") and init[4:5].isspace():
        init = init[4:].strip()
    if init.startswith("|"):
        am = re.match(r"\|[^|]*\|\s*->\s*([^\{]+?)\s*(?:\{|$)", init, re.S)
        if am:
            return am.group(1).strip()
        return _closure_return_text(init, None, rmap)
    tt = _expr_type_text_at(init, len(init), rmap, _texts_of(rmap, None))
    if tt is not None:
        rt = _fn_value_return_text(tt)
        if rt is not None:
            return rt
    return None


def _binding_in_force33(text, bind_pos, site_pos):
    """Whether the binding standing at `bind_pos` in `text`
    is in force at `site_pos` (seam round 33, protest P1):
    the binding in force is the one standing before the
    site AND enclosing it — a binding whose enclosing
    brace block has closed before the site binds only
    within that block (a loop body, a bare block, any
    nested scope), and a binding standing outside a
    nested function body does not bind a site inside
    that body. True where the binding encloses the site,
    False where it determinably does not, and None where
    the enclosure cannot be determined from the text —
    a brace opened in the text and never closed there
    contains the binding — which the reading arms refuse
    BY NAME, as every fail-closed in this census does."""
    _cfn34 = globals().get("_cfg_truth34")
    if _cfn34 is not None:
        # Existence before scope (seam round 34, protest
        # P2): a binding under a cfg that is false on the
        # crate's one denotation target is ABSENT — it
        # neither shadows nor is shadowed — and a cfg whose
        # truth the target facts do not decide refuses BY
        # NAME, naming the cfg and the file.
        _truth34, _cfg34 = _cfn34(text, bind_pos)
        if _truth34 is False:
            return False
        if _truth34 is None:
            _msg34 = ("binding existence undecidable: the binding in " + str(_std_ctx_rel() or "the file being resolved")
                      + " stands under `#[cfg(" + str(_cfg34) + ")]`, whose truth the crate's one denotation target (target_os = \"windows\") does not decide; "
                      + "the computation refuses by name rather than count the binding as standing (seam round 34, protest P2)")
            if _msg34 not in CHASE_FAILURES:
                CHASE_FAILURES.append(_msg34)
            return None
    pairs = []
    stack = []
    for i, ch in enumerate(text):
        if ch == "{":
            stack.append(i)
        elif ch == "}":
            if stack:
                pairs.append((stack.pop(), i))
    _mtab34 = globals().get("MACRO_BRACE34") or {}
    _mk35 = globals().get("_macro_kind35")
    if _mtab34 or globals().get("MACRO_DEFS35"):
        # Braces as expansions denote (seam round 34,
        # protest P1): the enclosure is read over the text
        # AS THE COMPILER'S FIRST PASSES LEAVE IT — a macro
        # invocation whose expansion splices its tokens into
        # the enclosing scope contributes no brace of its
        # own, a macro whose expansion is a block
        # contributes that block's brace, and a macro whose
        # brace behaviour its definition does not decide
        # refuses BY NAME, naming the macro and the file.
        for _mm34 in re.finditer(r"\b(\w+)!\s*([\(\{\[])", text):
            _kind34 = _mk35(_mm34.group(1), text, _mm34.start()) if _mk35 is not None else _mtab34.get(_mm34.group(1))
            if _kind34 is None:
                continue
            _open34 = _mm34.start(2)
            _close34 = {"(": ")", "{": "}", "[": "]"}[_mm34.group(2)]
            _end34 = _delim_match(text, _open34, _mm34.group(2), _close34)
            if _end34 < 0:
                continue
            if _kind34 == "unknown":
                if _open34 < bind_pos < _end34:
                    _msg34 = ("binding enclosure undecidable: the binding in " + str(_std_ctx_rel() or "the file being resolved")
                              + " stands inside an invocation of the macro `" + _mm34.group(1) + "`, whose expansion's brace behaviour its definition does not decide; "
                              + "the computation refuses by name rather than read the enclosure from the unexpanded text (seam round 34, protest P1)")
                    if _msg34 not in CHASE_FAILURES:
                        CHASE_FAILURES.append(_msg34)
                    return None
                continue
            if _kind34 == "pass" and _mm34.group(2) == "{":
                pairs = [p for p in pairs if p != (_open34, _end34 - 1)]
            elif _kind34 == "block" and _mm34.group(2) != "{":
                pairs.append((_open34, _end34 - 1))
    if any(a < bind_pos for a in stack):
        return None
    for m in re.finditer(r"\bfn\s+\w+", text):
        brace = text.find("{", m.end())
        semi = text.find(";", m.end())
        if brace < 0 or (0 <= semi < brace):
            continue
        end = _brace_match(text, brace)
        if brace < site_pos < end and not (brace < bind_pos < end):
            return False
    enc = None
    for a, b in pairs:
        if a < bind_pos < b and (enc is None or b - a < enc[1] - enc[0]):
            enc = (a, b)
    if enc is None:
        return True
    return enc[0] < site_pos < enc[1]


def _fn_shaped_iter33(ttext):
    """The iterator type text a function-shaped type
    text's declared return names, where that return is a
    `std::iter` constructor's result type standing at
    its element (seam round 33, protest P3): `Once<T>`,
    `Empty<T>`, `Repeat<T>`, `RepeatN<T>` and `Cycle<T>`
    at their element argument. The sentinel "REFUSE33"
    where the return names such a type but no element
    argument stands — a denotation the carrier names
    but does not determine, which its reading arm
    refuses by name. None where the type is not
    function-shaped at such a return."""
    if ttext is None:
        return None
    rt = _fn_value_return_text(ttext)
    if rt is None:
        return None
    rt = rt.strip()
    bare = rt.split("<")[0].split("::")[-1].strip()
    if not bare:
        return None
    if bare not in ("Once", "Empty", "Repeat", "RepeatN", "Cycle"):
        return None
    elem = _generic_arg(rt, 0)
    if elem is None:
        return "REFUSE33"
    return "__Iter<" + elem + ">"


def _ctor_carrier33(text, j, end, seg, segs, rmap, texts, open_idx):
    """A constructor arriving through a carrier the
    spelled and let-bound arms do not read (seam round
    33, protest P3), resolved by denotation or refused
    by name: (a) a CONST or STATIC item — the carrier
    family the grammar of items that can hold a value
    gives beside let bindings: const items, static
    items, and their associated forms, in the consumer's
    own file, in the file the spelled path's module
    denotes, or standing unique in the crate — judged
    at the item's declared function type where it names
    the element, and at its initialiser's path where
    the path denotes the constructor, refusing by name
    where the denotation names a constructor but
    determines no element; (b) a callee expression
    standing at a declared function type — a parameter,
    an annotated binding, a struct field's value — read
    at that declared type exactly as a const item's is.
    Returns the iterator type text, the sentinel
    "REFUSED33" where a refusal was recorded by name,
    or None where no carrier of this family stands."""
    rel = _std_ctx_rel()
    if CONST_ITEMS33.get(seg):
        files33 = []
        if rel is not None:
            files33.append(rel)
        if segs and rel is not None:
            for f33 in _candidate_files(_resolve_modpath(rel, segs), rel):
                if f33 not in files33:
                    files33.append(f33)
        cands33 = [c for c in CONST_ITEMS33.get(seg, []) if c[0] in files33]
        if not cands33 and len(CONST_ITEMS33.get(seg, [])) == 1:
            cands33 = list(CONST_ITEMS33[seg])
        if len(cands33) > 1:
            _iter_base_refusal31(seg, seg, _iter_chain_base31(text, open_idx))
            return "REFUSED33"
        if len(cands33) == 1:
            _cf33, _ct33, _ci33 = cands33[0]
            _sh33 = _fn_shaped_iter33(_ct33)
            if _sh33 is None:
                _exp33 = _expand_alias_text(_ct33)
                if _exp33 is not None and _exp33 != _ct33:
                    _sh33 = _fn_shaped_iter33(_exp33)
            if _sh33 is not None and _sh33 != "REFUSE33":
                return _sh33
            _im33 = re.fullmatch(r"((?:\w+\s*::\s*)*\w+)", _ci33)
            if _im33:
                _isegs33 = [s.strip() for s in _im33.group(1).split("::") if s.strip()]
                if _isegs33:
                    _joined33 = "::".join(_isegs33) if _isegs33[0] in ("std", "core", "alloc") else (_chase_std_path(_cf33, list(_isegs33)) if _cf33 is not None else None)
                    if _joined33 is not None and _joined33.rsplit("::", 2)[-2:-1] == ["iter"]:
                        _iter_base_refusal31(seg, _joined33.rsplit("::", 1)[-1], _iter_chain_base31(text, open_idx))
                        return "REFUSED33"
                    if _isegs33[-1] in ("once", "once_with", "repeat", "repeat_n", "repeat_with", "from_fn", "successors", "empty", "zip"):
                        _iter_base_refusal31(seg, _isegs33[-1], _iter_chain_base31(text, open_idx))
                        return "REFUSED33"
            if _sh33 == "REFUSE33":
                _iter_base_refusal31(seg, seg, _iter_chain_base31(text, open_idx))
                return "REFUSED33"
            return None
    if globals().get("_expr_type_at") is None:
        return None
    _tt33 = _expr_type_text_at(text, end, rmap, _texts_of(rmap, texts))
    if _tt33 is not None:
        _sh33 = _fn_shaped_iter33(_tt33)
        if _sh33 == "REFUSE33":
            _iter_base_refusal31(seg, seg, _iter_chain_base31(text, open_idx))
            return "REFUSED33"
        if _sh33 is not None:
            return _sh33
    # A let-bound FIELD VALUE (seam round 34, protest P3):
    # `let ctor = HOLDER.field;` binds the field's value —
    # the binding in force whose initialiser is a
    # projection is read at the field's declared function
    # type, as the destructured binding of the same field
    # already is, each level resolved by denotation.
    _pf34 = globals().get("_projection_field_type34")
    if _pf34 is not None:
        for _lm34 in re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(seg) + r"\b\s*(?::[^=;]+)?=\s*(.+?)\s*;", text[:j], re.S):
            if _binding_in_force33(text, _lm34.start(), j) is not True:
                continue
            _ft34 = _pf34(_lm34.group(1).strip(), rmap, texts, 0, text)
            if _ft34 is None:
                continue
            _sh34 = _fn_shaped_iter33(_ft34)
            if _sh34 == "REFUSE33":
                _iter_base_refusal31(seg, seg, _iter_chain_base31(text, open_idx))
                return "REFUSED33"
            if _sh34 is not None:
                return _sh34
    return None


def _fn_body_only33(seg):
    """Whether every production definition of the free
    name `seg` stands inside a function body (seam round
    33, protest P2): such a name has no module-level
    definition for a name-keyed merge to read, so a call
    arm that cannot key the call to its own file's and
    scope's definition abstains rather than merge the
    fn-body definitions of every file by name."""
    entries = FN_LOCS.get(seg, [])
    return bool(entries) and all(FN_IN_FN33.get((r, q), False) for (r, q, _c, _s) in entries)


def _own_fn_body_return33(seg, text, j):
    """The declared return text of the fn-body definition
    of `seg` standing in the caller's own file and in
    the call's own item text (seam round 33, protest
    P2): a bare call inside the body that defines the
    name denotes that body's definition, keyed by
    (file, scope) exactly as the glob stop keys it —
    never a same-named definition in another file, or
    in another scope of the same file whose text does
    not stand in this item."""
    rel = _std_ctx_rel()
    if rel is None:
        return None
    own = [(r, q) for (r, q, _c, _s) in FN_LOCS.get(seg, []) if r == rel and FN_IN_FN33.get((r, q), False)]
    if len(own) != 1:
        return None
    if not re.search(r"\bfn\s+" + re.escape(seg) + r"\s*\(", text[:j]):
        return None
    return RETURN_FREE_QUAL.get(own[0])


def _trait_default_ctor_yield33(body, sig, rel):
    """Whether a trait method's default body yields a
    wrapper through a bound `std::iter` constructor
    (seam round 33, protest P3): the default body is an
    item the census reads for its yields, and a
    constructor bound inside it is judged at the
    binding in force in that body, exactly as a
    constructor bound in any other item's body is — a
    chain in the body standing at an iterator over a
    wrapper type is the default's yield of that
    wrapper."""
    _set_std_bind_ctx(rel)
    _rtf33 = globals().get("_receiver_types_full")
    rmap = _rtf33(None, sig, body, rel=rel) if _rtf33 is not None else {}
    for m in re.finditer(r"\w+\s*\(", body):
        _ct33 = _std_iter_ctor_text(body, m.end() - 1, rmap)
        if _ct33 is not None and _ct33.startswith("__Iter<"):
            _elem33 = _generic_arg(_ct33, 0)
            if _elem33 is not None and (_elem33.strip() in WRAPPER_TYPES or _det_id(_elem33, rel=rel) in WRAPPER_TYPES or _disp(_det_id(_elem33, rel=rel) or "") in WRAPPER_TYPES):
                return True
    return False


def _bound_fn_value_return31(text, open_idx, rmap):
    """The return type text a call through a fn-value
    BINDING stands at, as (return text, target name) (seam
    round 31, protest P2's joint): a name the item binds —
    a plain let's initialiser, or a destructured let's
    element at the name's pattern position — to a path
    denoting a free function denotes that function at the
    call, exactly as the refusal's keying reads the same
    binding: the call is judged by the bound value's
    declared return, never by the name-keyed tables' merge
    of every definition of the name. A binding to anything
    else — a closure, a `from` path value (read by
    _from_value_call_text), a value no path denotes — is
    None here and stands judged by the ordinary arms."""
    end = open_idx
    while end > 0 and text[end - 1].isspace():
        end -= 1
    if end <= 0 or not (text[end - 1].isalnum() or text[end - 1] == "_"):
        return None
    j = end
    while j > 0 and (text[j - 1].isalnum() or text[j - 1] == "_"):
        j -= 1
    if j >= 2 and text[j - 2:j] == "::":
        return None
    if j >= 1 and text[j - 1] == ".":
        return None
    seg = text[j:end]
    pre = text[:j]
    path = None
    # The binding IN FORCE at the call (seam round 32,
    # protest P1): the LAST binding of the name standing
    # before the site, as the census's reaching discipline
    # judges every other name — a shadowed binding is
    # judged by the binding that shadows it, in both
    # directions, never by the first spelling.
    _ms32 = list(re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(seg) + r"\b\s*(?::[^=;]+)?=\s*((?:\w+\s*::\s*)*\w+)\s*(?:as\s+[^;]+)?;", pre))
    # The binding in force under SCOPE (seam round 33,
    # protest P1): among the bindings standing before
    # the site, only those whose scope encloses the site
    # bind there — a shadow inside a loop body, a bare
    # block, or any nested scope binds only within that
    # scope, and the binding in force after the scope is
    # the enclosing scope's. An enclosure that cannot be
    # determined fails closed BY NAME.
    _mf33 = [m33 for m33 in _ms32 if _binding_in_force33(text, m33.start(), j) is True]
    if _ms32 and not _mf33 and any(_binding_in_force33(text, m33.start(), j) is None for m33 in _ms32):
        _msg33 = ("binding in force undecidable: the enclosure of the binding of `" + seg + "` in "
                  + str(_std_ctx_rel() or "the file being resolved")
                  + " cannot be determined from the item's scopes; the computation refuses by name rather than judge the call by a binding whose scope is undecided (seam round 33, protest P1)")
        if _msg33 not in CHASE_FAILURES:
            CHASE_FAILURES.append(_msg33)
    m = _mf33[-1] if _mf33 else None
    if m:
        path = m.group(1)
    else:
        # A destructured let: the name's position in the
        # pattern selects the initialiser's element at the
        # same position.
        for lm in re.finditer(r"\blet\s+(\([^)]*\))\s*(?::[^=;]+)?=\s*(\([^;]*\))\s*;", pre, re.S):
            if _binding_in_force33(text, lm.start(), j) is not True:
                continue
            pats = [p.strip() for p in _split_top(lm.group(1)[1:-1])]
            idx = None
            for i2, p2 in enumerate(pats):
                if re.fullmatch(r"(?:mut\s+)?" + re.escape(seg), p2):
                    idx = i2
                    break
            if idx is None:
                continue
            elems = _split_top(lm.group(2)[1:-1])
            if idx >= len(elems):
                continue
            el = re.sub(r"\s+as\s+[^,]+$", "", elems[idx].strip()).strip()
            pm = re.fullmatch(r"((?:\w+\s*::\s*)*\w+)", el)
            if pm:
                path = pm.group(1)
                break
    if path is None:
        # A binding whose initialiser is a projection
        # (seam round 32, protest P1): `let take =
        # holder().field;` binds the FIELD'S VALUE — the
        # field's declared type, read at the receiver's
        # type, is the bound value, and where that type
        # is function-shaped its declared return judges
        # the call, never the name-keyed tables' merge
        # of the name's definitions. A tuple element at
        # its position reads the same way, at the
        # element's declared text.
        _pm32 = None
        for _lm32 in re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(seg) + r"\b\s*(?::[^=;]+)?=\s*(.+?)\s*;", pre, re.S):
            if _binding_in_force33(text, _lm32.start(), j) is True:
                _pm32 = _lm32
        if _pm32 is not None:
            _fm32 = re.match(r"^(.+?)\s*\.\s*(\w+)\s*$", _pm32.group(1).strip(), re.S)
            if _fm32 is not None:
                _rt32 = _expr_type_text_at(_fm32.group(1), len(_fm32.group(1)), rmap, _texts_of(rmap, None))
                if _rt32 is not None:
                    _ft32 = _substituted_field_text(_rt32, _fm32.group(2))
                    if _ft32 is not None:
                        _fr32 = _fn_value_return_text(_ft32)
                        if _fr32 is not None:
                            return (_fr32, _fm32.group(2))
        return None
    segs = [s.strip() for s in path.split("::") if s.strip()]
    if not segs or segs[-1] == "from":
        return None
    desc = _resolve_item(_std_ctx_rel(), segs) if _std_ctx_rel() is not None else None
    tname = None
    if desc is not None and desc[0] == "free":
        tname = desc[1]
    elif len(segs) == 1 and _free_return_text(segs[0]) is not None:
        tname = segs[0]
    if tname is None:
        return None
    rt = _free_return_text(tname)
    if rt is None:
        return None
    return (rt, tname)


def _ctor_call_text31(text, open_idx, rmap):
    """The container text a container constructor heading
    a chain constructs (seam round 31, protest P7): the
    receiver position is a value position of the same
    grammar as the argument position — `Some(x)` / `Ok(x)`
    / `Err(x)` heading a chain is the container over its
    argument, as _ctor_container_text reads the same
    construction standing as an argument. Any other call
    head is None here."""
    m = re.search(r"((?:\w+\s*::\s*)*(?:Ok|Err|Some)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?)\s*$", text[:open_idx])
    if not m:
        return None
    close = _delim_match(text, open_idx, "(", ")")
    if close < 0:
        return None
    return _ctor_container_text(text[m.start(1):close], rmap)


def _callee_return_text(text, open_idx, rmap):
    """The declared return type TEXT of the call whose
    argument list opens at open_idx, or None — _callee_return's
    resolution, keeping the text patterns bind against."""
    _tm33 = re.search(r"<[^<>]*\bas\s+(?:\w+\s*::\s*)*(\w+)\s*>\s*::\s*(\w+)\s*$", text[:open_idx])
    if _tm33 is not None and (_tm33.group(1), _tm33.group(2)) in TRAIT_METH_RETURN33:
        # A call through a qualified trait path (seam
        # round 33, protest P3): the trait method's
        # DEFAULT BODY is the item the call denotes
        # where no override stands, and an override
        # declares the same return the trait declares,
        # so the call stands at the trait's declared
        # return exactly as a method call stands at its
        # method's.
        return TRAIT_METH_RETURN33[(_tm33.group(1), _tm33.group(2))]
    _sc26 = _std_ctor_call_text(text, open_idx, rmap)
    if _sc26 is not None:
        return _sc26
    _ic30 = _std_iter_ctor_text(text, open_idx, rmap)
    if _ic30 is not None:
        return _ic30
    _cc31 = _ctor_call_text31(text, open_idx, rmap)
    if _cc31 is not None:
        return _cc31
    _fc32 = _from_call_through32(text, open_idx, rmap)
    if _fc32 is not None:
        return _fc32
    end = open_idx
    while end > 0 and text[end - 1].isspace():
        end -= 1
    if end <= 0:
        return None
    ch = text[end - 1]
    if ch == ">":
        depth, j = 1, end - 2
        while j >= 0 and depth:
            if text[j] == ">":
                depth += 1
            elif text[j] == "<":
                depth -= 1
            j -= 1
        if depth:
            return None
        end = j + 1
        while end > 0 and text[end - 1] == ":":
            end -= 1
        ch = text[end - 1] if end > 0 else ""
    if not (ch.isalnum() or ch == "_"):
        return None
    j = end
    while j > 0 and (text[j - 1].isalnum() or text[j - 1] == "_"):
        j -= 1
    seg = text[j:end]
    if j >= 2 and text[j - 1] == "." and (text[j - 2].isalnum() or text[j - 2] in "_)]"):
        base = _expr_type_at(text, j - 1, rmap)
        if base is None:
            # A receiver whose identity no table names — a
            # generic std container's instantiation the
            # standing case, `Vec<...>` — still stands in
            # the text (seam round 27, protests P3/P5): an
            # iterator step on it is read at its text, the
            # breadth the arms below read a named receiver
            # at, so a chain crossing `into_iter` on such a
            # container reaches its adapters and terminals.
            _recv27 = _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None))
            if _recv27 is None or seg not in ("iter", "iter_mut", "into_iter", "next", "last", "nth", "max", "min", "map", "filter_map", "flat_map", "map_while", "enumerate", "zip", "scan", "flatten", "peekable", "inspect", "fuse", "cycle", "by_ref", "take_while", "skip_while", "chain", "cloned", "copied", "filter", "rev", "skip", "take", "step_by", "find", "reduce", "max_by", "min_by", "max_by_key", "min_by_key", "unzip", "and_then", "find_map"):
                return None
            _rt27 = _meth_return_text(_recv27, seg)
            if seg in ("map", "filter_map", "flat_map", "map_while", "enumerate", "zip", "scan", "flatten", "peekable", "inspect", "fuse", "cycle", "by_ref", "take_while", "skip_while", "chain", "cloned", "copied", "filter", "rev", "skip", "take", "step_by"):
                _ad27 = _iter_adapter_return_text(text, open_idx, rmap, seg, _recv27)
                if _ad27 is not None:
                    _rt27 = _ad27
            if seg == "find_map":
                _fm29 = _find_map_call_text(text, open_idx, rmap, _recv27)
                if _fm29 is not None:
                    _rt27 = _fm29
            if _rt27 is None and seg == "unzip":
                _rt27 = _unzip_call_text(text, open_idx, rmap, _recv27)
            if _rt27 is None and seg in ("map", "and_then", "filter", "inspect"):
                _rt27 = _container_step_result_text(text, open_idx, rmap, seg, _recv27)
            return _recv27 if _rt27 == "Self" else _rt27
        rt = _meth_return_text(base, seg)
        if rt is not None and rt != "Self":
            rt = _call_generic_substitution(rt, text, open_idx, rmap, GENERIC_PARAMS_METH.get((base, seg)), PARAMS_METH.get((base, seg)))
        if seg in ("and", "zip"):
            # The argument-carrying steps (seam round 23,
            # protest P1): the result's payload is the
            # ARGUMENT's, read from the argument expression's
            # own declared type at the call, at both elements
            # for `zip` — the receiver's text alone cannot
            # name it, and recording the receiver's payload
            # in its place judged the wrong holder's fields.
            arg = _first_arg_text(text, open_idx)
            at = None
            if arg is not None:
                at = _expr_type_text_at(arg, len(arg), rmap, _texts_of(rmap, None))
                if at is None:
                    at = _expr_type_at(arg, len(arg), rmap)
                if at is None:
                    at = _ctor_container_text(arg, rmap)
            recv_text = _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None)) or base
            ov = _and_arg_text(recv_text, at) if seg == "and" else _zip_arg_text(recv_text, at)
            if ov is not None:
                rt = ov
        if seg in ("map", "filter_map", "flat_map", "map_while", "enumerate", "zip", "scan", "flatten", "peekable", "inspect", "fuse", "cycle", "by_ref", "take_while", "skip_while", "chain", "cloned", "copied", "filter", "rev", "skip", "take", "step_by"):
            _ad26 = _iter_adapter_return_text(text, open_idx, rmap, seg, _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None)) or base)
            if _ad26 is not None:
                rt = _ad26
        if seg == "find_map":
            _fm29 = _find_map_call_text(text, open_idx, rmap, _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None)) or base)
            if _fm29 is not None:
                rt = _fm29
        if rt is None and seg == "unzip":
            rt = _unzip_call_text(text, open_idx, rmap, _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None)) or base)
        if rt is None and seg in ("map", "and_then", "filter", "inspect"):
            rt = _container_step_result_text(text, open_idx, rmap, seg, _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None)) or base)
        return base if rt == "Self" else rt
    if j >= 2 and text[j - 2:j] == "::":
        segs = _expand_module_segs(None, _path_segs_before(text, j))
        if segs and segs[-1][:1].isupper():
            ident = _ident_of(segs[-1], segs[:-1])
            if ident is not None:
                rt = _meth_return_text(ident, seg)
                if rt is not None and rt != "Self":
                    rt = _call_generic_substitution(rt, text, open_idx, rmap, GENERIC_PARAMS_METH.get((ident, seg)), PARAMS_METH.get((ident, seg)))
                return ident if rt == "Self" else rt
        _rfr32 = _resolved_free_return32(text, j, seg)
        if _rfr32 is None and _fn_body_only33(seg):
            return _from_value_call_text(text, open_idx, rmap)
        _fr31 = _call_generic_substitution(_rfr32 if _rfr32 is not None else _free_return_text(seg), text, open_idx, rmap, GENERIC_PARAMS_FREE.get(seg), PARAMS_FREE.get(seg))
        if _fr31 is not None:
            return _fr31
        return _from_value_call_text(text, open_idx, rmap)
    _fv30 = _from_value_call_text(text, open_idx, rmap)
    if _fv30 is not None:
        return _fv30
    _bv31 = _bound_fn_value_return31(text, open_idx, rmap)
    if _bv31 is not None:
        return _call_generic_substitution(_bv31[0], text, open_idx, rmap, GENERIC_PARAMS_FREE.get(_bv31[1]), PARAMS_FREE.get(_bv31[1]))
    _cl34 = globals().get("_closure_call_return34")
    if _cl34 is not None:
        # A call through a closure (seam round 34, protest
        # P4): the closure's return, keyed by its
        # definition site, exactly as an item's is.
        _cr34 = _cl34(text, open_idx, rmap)
        if _cr34 is not None:
            return _cr34
    _ownb33 = _own_fn_body_return33(seg, text, j)
    if _ownb33 is not None:
        return _call_generic_substitution(_ownb33, text, open_idx, rmap, GENERIC_PARAMS_FREE.get(seg), PARAMS_FREE.get(seg))
    if _fn_body_only33(seg):
        return None
    return _call_generic_substitution(_free_return_text(seg), text, open_idx, rmap, GENERIC_PARAMS_FREE.get(seg), PARAMS_FREE.get(seg))

def _expr_type_text_at(text, end, rmap, texts):
    """The declared type TEXT of the expression ending at
    `end`: a variable's recorded text, a field access's field
    type text, a call's declared return text."""
    while end > 0 and text[end - 1].isspace():
        end -= 1
    if end <= 0:
        return None
    ch = text[end - 1]
    if ch == ")":
        depth, j = 1, end - 2
        while j >= 0 and depth:
            if text[j] == ")":
                depth += 1
            elif text[j] == "(":
                depth -= 1
            j -= 1
        if depth:
            return None
        _deref28 = _explicit_deref_text(text, j + 1, end, rmap, texts)
        if _deref28 is not None:
            return _deref28
        if j < 0 or not (text[j].isalnum() or text[j] == "_" or text[j] in ")]>!"):
            # A grouping parenthesis (seam round 30,
            # protest P1): the bracket the walk matched
            # opens no call — a reference to a literal
            # standing as a chain's base in parentheses is
            # the ordinary spelling — and the expression
            # stands at its content's type, as a call's
            # argument shape already reads the same
            # content.
            _inner30 = text[j + 2:end - 1]
            _gt30 = _arg_shape_text(_inner30, rmap, texts)
            if _gt30 is None:
                _gt30 = _expr_type_text_at(_inner30, len(_inner30), rmap, texts)
            if _gt30 is not None:
                return _gt30
        return _callee_return_text(text, j + 1, rmap)
    if ch == "?":
        # The payload step at the text level (seam round 16,
        # protest P1; seam round 25, protest P3: read through
        # the receiver's Deref chain as the method steps are).
        tt = _expr_type_text_at(text, end - 1, rmap, texts)
        return _payload_text_through_deref(tt) if tt is not None else None
    if ch == "]":
        # The index step at the text level (seam round 16,
        # protest P3): the element text of the indexed
        # expression's declared type text.
        depth, j = 1, end - 2
        while j >= 0 and depth:
            if text[j] == "]":
                depth += 1
            elif text[j] == "[":
                depth -= 1
            j -= 1
        if depth:
            return None
        _vm28 = re.search(r"((?:\w+\s*::\s*)*vec\s*!)\s*$", text[:j + 1])
        if _vm28:
            # A `vec!` literal (seam round 28, protest P1):
            # the bracket is the literal's own, not an index
            # into a receiver — the expression is the vector
            # the macro constructs, and its shape is its
            # type, as the inference walk already reads a
            # literal argument's shape.
            return _arg_shape_text(text[_vm28.start():end], rmap, texts)
        if j < 0 or not (text[j].isalnum() or text[j] in "_)]}\"'"):
            # An array literal (seam round 29, protest P1):
            # the bracket is the literal's own where no
            # receiver stands before it — the expression is
            # the array the literal constructs, and its shape
            # is its type, as the `vec!` spelling above is
            # read at its shape.
            return _arg_shape_text(text[j + 1:end], rmap, texts)
        tt = _expr_type_text_at(text, j + 1, rmap, texts)
        return _iter_element_text(tt) if tt is not None else None
    if ch.isalnum() or ch == "_":
        j = end
        while j > 0 and (text[j - 1].isalnum() or text[j - 1] == "_"):
            j -= 1
        seg = text[j:end]
        if j >= 2 and text[j - 1] == "." and (text[j - 2].isalnum() or text[j - 2] in "_)]"):
            tt2 = _expr_type_text_at(text, j - 1, rmap, texts)
            if tt2 is not None:
                st2 = _substituted_field_text(tt2, seg)
                if st2 is not None:
                    return st2
            base = _expr_type_at(text, j - 1, rmap)
            if base is None:
                return None
            entry = STRUCT_FIELDS.get(base)
            if entry is None:
                return None
            named, positional = entry
            if seg.isdigit():
                idx = int(seg)
                return positional[idx] if idx < len(positional) else None
            return named.get(seg)
        if j >= 2 and text[j - 2:j] == "::":
            return None
        return texts.get(seg)
    return None

def _bind_pattern(pat, typetext, out, texts):
    """Bind every variable of pattern `pat`, destructuring a
    value whose declared type text is `typetext`, with the
    type its position declares (seam round 6, protest P2):
    a struct field's declared type, a tuple position's type,
    an enum variant payload's type; a generic-wrapped
    declared type (Option/Result/Box/...) unwraps to its
    payload where the pattern names the payload. Returns
    True when any binding was added."""
    pat = pat.strip()
    pat = re.sub(r"^(?:ref\s+|mut\s+)+", "", pat).strip()
    if not pat or pat == "_" or pat.startswith(".."):
        return False
    grew = False

    def bind(name, tt):
        nonlocal grew
        if name in out:
            if tt is not None:
                texts.setdefault(name, tt)
            return
        ident = _det_id(tt, rel=rel) if tt is not None else None
        if ident is not None and ident != "Self":
            out[name] = ident
            grew = True
        if tt is not None:
            texts.setdefault(name, tt)

    # An or-pattern (seam round 26, protest P5): each
    # alternative of a top-level `|` binds at its own
    # positions' declared types, as the alternative standing
    # alone as the arm's pattern does — a variable bound in
    # every alternative takes the type the alternatives agree
    # on (Rust's own binding rules refuse a variable whose
    # alternatives disagree, so the first binding stands).
    _alts26, _depth26, _cur26, _i26 = [], 0, "", 0
    while _i26 < len(pat):
        _c26 = pat[_i26]
        if _c26 in "(<[{":
            _depth26 += 1
        elif _c26 in ")>]}":
            _depth26 -= 1
        if _c26 == "|" and _depth26 == 0 and pat[_i26 - 1:_i26] != "|" and pat[_i26 + 1:_i26 + 2] != "|":
            _alts26.append(_cur26)
            _cur26 = ""
            _i26 += 1
            continue
        _cur26 += _c26
        _i26 += 1
    if _alts26:
        _alts26.append(_cur26)
        for _alt26 in _alts26:
            grew = _bind_pattern(_alt26.strip(), typetext, out, texts) or grew
        return grew
    if pat.startswith("&"):
        # A pattern standing under a reference (seam round
        # 25, protest P4): `&(a, b)` binds through the
        # reference exactly as `(a, b)` binds through the
        # value — the pattern is read at the reference's
        # target type, the reference stripped from the type
        # text where it stands there, as every reference
        # receiver is read elsewhere.
        rest = re.sub(r"^mut\s+", "", pat[1:].strip()).strip()
        tt2 = typetext
        if tt2 is not None and tt2.strip().startswith("&"):
            tt2 = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", tt2.strip()).strip()
        return _bind_pattern(rest, tt2, out, texts) or grew
    am = re.match(r"^(\w+)\s*@\s*(.+)$", pat, re.S)
    if am:
        bind(am.group(1), typetext)
        return _bind_pattern(am.group(2), typetext, out, texts) or grew
    if re.fullmatch(r"\w+", pat):
        bind(pat, typetext)
        return grew
    sm = re.match(r"^((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\{(.*)\}\s*$", pat, re.S)
    if sm:
        segs = [s.strip() for s in sm.group(1).split("::")]
        ident = _ident_of(segs[-1], segs[:-1])
        if ident is None:
            ident = _det_id(typetext, rel=rel)
        entry = STRUCT_FIELDS.get(ident) if ident else None
        if len(segs) >= 2 and (entry is None or not any(re.match(r"^(?:r#)?(\w+)\s*(?::\s*(.+))?$", _es37.strip(), re.S) and re.match(r"^(?:r#)?(\w+)\s*(?::\s*(.+))?$", _es37.strip(), re.S).group(1) in entry[0] for _es37 in _split_top(sm.group(2)) if _es37.strip() and _es37.strip() != "..")):
            # A struct-shaped ENUM VARIANT's pattern
            # (seam round 37, protest P1's carrier): the
            # head's last segment is the variant, whose
            # fields are the ENUM's declared fields — the
            # reading the tuple-variant branch below
            # already makes at its own fallback. The
            # variant ident standing in the enum's place
            # yields no entry carrying the pattern's
            # fields, so the head is read at the enum.
            _ident37 = _ident_of(segs[-2], segs[:-2])
            _entry37 = STRUCT_FIELDS.get(_ident37) if _ident37 else None
            if _entry37 is not None:
                ident, entry = _ident37, _entry37
        named = entry[0] if entry else {}
        for entry_seg in _split_top(sm.group(2)):
            entry_seg = entry_seg.strip()
            if not entry_seg or entry_seg == "..":
                continue
            fm = re.match(r"^(?:r#)?(\w+)\s*(?::\s*(.+))?$", entry_seg, re.S)
            if not fm:
                continue
            ftext = named.get(fm.group(1))
            st = _substituted_field_text(typetext, fm.group(1))
            if st is not None:
                ftext = st
            if fm.group(2):
                grew = _bind_pattern(fm.group(2), ftext, out, texts) or grew
            else:
                bind(fm.group(1), ftext)
        return grew
    if pat.startswith("(") and pat.endswith(")"):
        _subs26 = _split_top(pat[1:-1])
        _tt26 = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", typetext.strip()).strip() if typetext is not None else ""
        _orc27, _od27 = False, 0
        for _oc27 in pat[1:-1]:
            if _oc27 in "(<[{":
                _od27 += 1
            elif _oc27 in ")>]}":
                _od27 -= 1
            elif _oc27 == "|" and _od27 == 0:
                _orc27 = True
        if len(_subs26) == 1 and not pat[1:-1].rstrip().endswith(",") and (not _tt26.startswith("(") or _orc27):
            # A parenthesised pattern (seam round 26,
            # protest P5's sweep): `(PAT)` is the pattern
            # PAT itself, not a one-tuple — the parentheses
            # group, as they group an expression — so it
            # binds at the value's own type, the form a
            # top-level or-pattern in a `let` must take.
            # Seam round 27 (protest P10): the grouping
            # stands also at a tuple type text where the
            # grouped pattern is an or-pattern — its
            # alternatives bind at the whole value, as an
            # unparenthesised or-pattern does, and the
            # tuple reading below has no reading for a
            # top-level `|` standing as an element.
            return _bind_pattern(_subs26[0], typetext, out, texts) or grew
        tparts = []
        if typetext is not None:
            tt = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", typetext.strip()).strip()
            if tt.startswith("(") and tt.endswith(")"):
                tparts = [p.strip() for p in _split_top(tt[1:-1])]
        for idx, sub in enumerate(_split_top(pat[1:-1])):
            grew = _bind_pattern(sub, tparts[idx] if idx < len(tparts) else None, out, texts) or grew
        return grew
    vm = re.match(r"^((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\((.*)\)\s*$", pat, re.S)
    if vm:
        segs = [s.strip() for s in vm.group(1).split("::")]
        variant = segs[-1]
        subs = _split_top(vm.group(2))
        payloads = [None] * len(subs)
        # A tuple-struct pattern (seam round 25, protest
        # P4): the pattern's head IS the type, and its
        # positions are the type's positional fields,
        # read through the destructured value's own
        # instantiation as a struct pattern's fields are.
        head_ident = _ident_of(segs[-1], segs[:-1])
        head_entry = STRUCT_FIELDS.get(head_ident) if head_ident is not None else None
        if head_entry is not None and len(head_entry[1]) == len(subs):
            payloads = list(head_entry[1])
            if typetext is not None and _det_id(typetext, rel=rel) == head_ident:
                for idx in range(len(subs)):
                    st = _substituted_field_text(typetext, str(idx))
                    if st is not None:
                        payloads[idx] = st
        elif variant == "Some" or variant == "Ok":
            payloads[0] = _generic_arg(typetext, 0) if subs else None
        elif variant == "Err":
            payloads[0] = _generic_arg(typetext, 1) if subs else None
        elif len(subs) == 1:
            payloads[0] = _generic_arg(typetext, 0)
        if all(p is None for p in payloads) and len(segs) >= 2:
            tident = _ident_of(segs[-2], segs[:-2])
            entry = STRUCT_FIELDS.get(tident) if tident else None
            if entry and len(entry[1]) == len(subs):
                payloads = list(entry[1])
        for sub, tt in zip(subs, payloads):
            grew = _bind_pattern(sub, tt, out, texts) or grew
        return grew
    return grew

def _scope_spans(code):
    """Every scope of `code` in Rust's own model (seam round
    6, protest P5): the inline modules and the item bodies —
    a function body is a scope, and a definition inside one
    is that body's item. Each span carries its kind, its
    opening brace (its identity), its end and, for a module,
    its name."""
    spans = []
    for name, a, b in _inline_mods(code):
        spans.append({"kind": "mod", "key": ("mod", a), "start": a, "end": b, "name": name})
    for m in re.finditer(r"\bfn\s+(\w+)", code):
        brace = code.find("{", m.end())
        semi = code.find(";", m.end())
        if brace < 0 or (0 <= semi < brace):
            continue
        spans.append({"kind": "fn", "key": ("fn", brace), "start": brace, "end": _brace_match(code, brace), "name": m.group(1)})
    return spans

def _scopes_at(spans, pos):
    out = [s for s in spans if s["start"] < pos < s["end"]]
    out.sort(key=lambda s: s["end"] - s["start"])
    return out

def _scope_key_of(spans, pos):
    at = _scopes_at(spans, pos)
    return at[0]["key"] if at else None

def _mod_chain_of(spans, key):
    for s in spans:
        if s["key"] == key and s["kind"] == "mod":
            chain = [(o["start"], o["name"]) for o in spans if o["kind"] == "mod" and o["start"] < s["start"] and s["start"] < o["end"]]
            chain.append((s["start"], s["name"]))
            chain.sort()
            return [n for _a, n in chain]
    return []

def _use_bindings(code, spans):
    """The `use` bindings of `code`, read for the scope
    computation even though they stay blanked for the call
    census (seam round 6, protest P5): (imported name or "*"
    for a glob, the scope the statement stands in, the
    statement's path segments)."""
    out = []
    for m in re.finditer(r"\buse\s+([^;]+);", code):
        body = m.group(1).strip()
        scope = _scope_key_of(spans, m.start())
        gm = re.match(r"^(.*?)\s*\{\s*(.*?)\s*\}\s*$", body, re.S)
        if gm:
            prefix = [s.strip() for s in gm.group(1).split("::") if s.strip()]
            for item in gm.group(2).split(","):
                item = item.strip()
                if not item:
                    continue
                if item == "self":
                    if prefix:
                        out.append((prefix[-1], scope, prefix))
                    continue
                am = re.match(r"^(\w+)\s+as\s+(\w+)$", item)
                if am:
                    out.append((am.group(2), scope, prefix + [am.group(1)]))
                elif item == "*":
                    out.append(("*", scope, prefix))
                else:
                    out.append((item, scope, prefix + [item]))
            continue
        body = re.sub(r"\s+", "", body)
        if body.endswith("::*"):
            segs = [s for s in body[:-3].split("::") if s]
            out.append(("*", scope, segs))
            continue
        am = re.match(r"^(.*)::(\w+)as(\w+)$", body)
        if am:
            segs = [s for s in am.group(1).split("::") if s]
            out.append((am.group(3), scope, segs + [am.group(2)]))
            continue
        segs = [s for s in body.split("::") if s]
        if segs:
            out.append((segs[-1], scope, segs))
    return out


def _expand_use(text):
    """The leaf bindings of one use statement's body text, as
    (local name, path segments, is_glob): brace groups expanded
    recursively, an `as` clause giving the local name, `self`
    naming the prefix's last segment."""
    text = text.strip()
    if "{" in text:
        i = text.index("{")
        prefix = text[:i].rstrip()
        if prefix.endswith("::"):
            prefix = prefix[:-2]
        end = _delim_match(text, i, "{", "}")
        psegs = [s.strip() for s in prefix.split("::") if s.strip()] if prefix else []
        out = []
        for part in _split_top(text[i + 1:end - 1]):
            for local, segs, glob in _expand_use(part):
                if local == "self":
                    out.append((psegs[-1] if psegs else "self", psegs, glob))
                else:
                    out.append((local, psegs + segs, glob))
        return out
    m = re.match(r"^(.*?)\s+as\s+(\w+)$", text, re.S)
    if m:
        path, local = m.group(1), m.group(2)
    else:
        path, local = text, None
    segs = [s.strip() for s in path.split("::") if s.strip()]
    if segs and segs[-1] == "*":
        return [("*", segs[:-1], True)]
    if local is None:
        local = segs[-1] if segs else ""
    return [(local, segs, False)]

def _rename_bindings(code, spans):
    """Every `use` binding of `code` as (local name, scope key,
    path segments, is a pub re-export) — the use-statement
    reading the scope model already makes, carrying the `as`
    clauses: the local name is the alias where one stands, the
    segments the full original path (seam round 7, protest P1)."""
    out = []
    for m in re.finditer(r"\b(pub(?:\([^)]*\))?\s+)?use\s+([^;]+);", code):
        is_pub = m.group(1) is not None
        scope = _scope_key_of(spans, m.start())
        for local, segs, glob in _expand_use(m.group(2)):
            out.append((local, scope, segs, is_pub))
    return out

def _resolve_modpath(from_rel, modsegs):
    """The module path a spelled module prefix denotes in file
    `from_rel`: `crate` anchors at the root, `self` at the
    file's own module, `super` climbs, and a plain prefix is
    anchored at the crate root (the 2018 path rule)."""
    own = FILE_MODULES.get(from_rel, "")
    base = own.split("::") if own else []
    if not modsegs:
        return own
    if modsegs[0] == "crate":
        return "::".join(modsegs[1:])
    if modsegs[0] == "self":
        return "::".join(base + modsegs[1:])
    if modsegs[0] == "super":
        rest = list(modsegs)
        b = list(base)
        while rest and rest[0] == "super":
            b = b[:-1]
            rest = rest[1:]
        return "::".join(b + rest)
    return "::".join(modsegs)

def _root_file_of(rel):
    """The crate root file of the crate `rel` belongs to
    (seam round 9, protest P2): `src/lib.rs` for the library
    crate, `src/main.rs` for the binary crate rooted there,
    and each `src/bin/<name>.rs` for its own crate, whose
    file-module children stand under `src/bin/<name>/`.
    Resolution is root-confined: a candidate from another
    crate's root never satisfies a path spelled in this one,
    and the re-export chase runs in the root that owns the
    path."""
    if rel == "src/main.rs" or rel.startswith("src/main/"):
        return "src/main.rs"
    if rel.startswith("src/bin/"):
        parts = rel.split("/")
        if len(parts) == 3:
            return rel
        return "src/bin/" + parts[2] + ".rs"
    return "src/lib.rs"

def _candidate_files(modpath, from_rel=None):
    """Every production file standing at module path
    `modpath`, in a deterministic order (seam round 7,
    protest P1, third spelling): the module map's recorded
    file first — the order resolution has always tried
    first, so a path that already resolved keeps resolving
    to the same file — then every file whose own module
    path it is, then every file defining an item of the
    module (an inline module's home file). More than one
    file can stand at one path: src/lib.rs and src/main.rs
    both stand at the empty path, each the root of its own
    crate, so an item spelled through the crate root — a
    root definition, or a root `pub use` re-export — may
    stand in either of them, and trusting the one recorded
    file alone makes every item of the other root
    invisible to resolution. Seam round 9 (protest P2):
    when the spelling file is known, the candidates are
    confined to its own crate — a same-named item in
    another crate's root is not a candidate for the path
    at any position in any order, and a bare definition
    hit in a confined candidate never pre-empts the
    owning root's re-export chase."""
    out = []

    def add(rel):
        if rel is not None and rel not in out:
            out.append(rel)

    add(MODULE_FILE.get(modpath))
    for rel in sorted(FILE_MODULES):
        if FILE_MODULES[rel] == modpath:
            add(rel)
    for rel in sorted(FILE_DECLARED_PATHS):
        if FILE_DECLARED_PATHS[rel] == modpath:
            add(rel)
    add(INLINE_MOD_HOME.get(modpath))
    for locs in TYPE_LOCS.values():
        for rel, qual, _c, _k, _s in locs:
            if "::".join(qual.split("::")[:-1]) == modpath:
                add(rel)
    if from_rel is not None:
        root = _root_file_of(from_rel)
        out = [rel for rel in out if _root_file_of(rel) == root]
    return out



def _record_chase_failure(segs, kind):
    """Record a chase-bound refusal (seam round 8, protest P3):
    the spelled path `segs` exhausted the recorded bound of
    `kind` ("depth": CHASE_DEPTH_BOUND re-export hops;
    "variant": CHASE_VARIANT_BOUND module-path variants)
    where the exhaustion decides the resolution, so the
    resolution's None would be a bound artifact, not a
    finding of no wrapper. The message names the spelled path
    and the bound; the generator prints every recorded message
    and exits non-zero without writing the graph, and D43's
    checker appends every recorded message to its failures
    — the computation refuses by name, never silently."""
    spelled = "::".join(segs)
    if kind == "depth":
        msg = ("re-export chase bound exceeded: resolving `" + spelled + "` followed more than "
               + str(CHASE_DEPTH_BOUND) + " re-export hops (the recorded chase depth bound, seam round 8, protest P3); "
               + "the computation refuses by name rather than read an over-deep chain as no wrapper")
    else:
        msg = ("re-export chase bound exceeded: resolving `" + spelled + "` exhausted the "
               + str(CHASE_VARIANT_BOUND) + " module-path variant bound without resolving (the recorded chase variant bound, seam round 8, protest P3); "
               + "the computation refuses by name rather than read a truncated chase as no wrapper")
    if msg not in CHASE_FAILURES:
        CHASE_FAILURES.append(msg)

def _module_export_names(modpath, seen=frozenset(), from_rel=None):
    """The names module `modpath` exports (seam round 8,
    protest P1), as (names, ambiguous): the items the module
    defines at that path, the local names of its `use`
    public `use` bindings — its re-exports, renamed alike, so `pub use X
    as Y` in the module exports Y — and, transitively, the
    exports of the modules it glob re-exports. A name standing
    at the module with more than one production definition
    (two type identities at the path, or free definitions in
    two files standing at the path) is ambiguous there — the
    recorded limit's bare-name rule — and stands in the
    second return value, never in the first: a glob supply of
    it resolves nothing, never a first-wins identity.
    Candidates are confined to the crate of `from_rel`
    when one is given (seam round 9, protest P2)."""
    cache_key = (modpath, _root_file_of(from_rel) if from_rel is not None else None)
    if not seen and cache_key in _EXPORT_NAMES_CACHE:
        return _EXPORT_NAMES_CACHE[cache_key]
    if modpath in seen:
        return [], set()
    seen = seen | {modpath}
    names = []

    def add(name):
        if name not in names:
            names.append(name)

    ambiguous = set()
    cands = _candidate_files(modpath, from_rel)
    for cand in cands:
        for local, scope, bsegs, is_pub in FILE_BINDINGS_RAW.get(cand, []):
            if not _binding_stands_at(cand, scope, modpath):
                continue
            if local == "*":
                if is_pub:
                    sub, sub_amb = _module_export_names(_resolve_modpath(cand, bsegs), seen, cand)
                    for n in sub:
                        add(n)
                    ambiguous |= sub_amb
                continue
            if is_pub:
                add(local)
    for cand in cands:
        for (r, name) in sorted(FREE_FN_DEFS):
            if r == cand:
                add(name)
        for name, home in sorted(WRAPPER_VALUES.items()):
            if home == cand:
                add(name)
    free_files = {}
    for (r, name) in FREE_FN_DEFS:
        if r in cands:
            free_files.setdefault(name, set()).add(r)
    for name, rs in free_files.items():
        if len(rs) > 1:
            ambiguous.add(name)
    for name, locs in sorted(TYPE_LOCS.items()):
        quals = {qual for (r, qual, _c, _k, _s) in locs if "::".join(qual.split("::")[:-1]) == modpath}
        if not quals:
            continue
        if len(quals) > 1:
            ambiguous.add(name)
        else:
            add(name)
    out = ([n for n in names if n not in ambiguous], ambiguous)
    if len(seen) == 1:
        _EXPORT_NAMES_CACHE[cache_key] = out
    return out

def _chase_item_denotes(item):
    """Whether the spelled final segment `item` denotes a
    production binding for the chase-bound record (seam
    round 9, protest P1): it is a definition name (a type
    location or a free function definition), a wrapper
    value, or the local name of any `use` binding in any
    production file — renamed re-exports included. The
    round-8 record condition tested the segment only
    against the original-name tables (type definitions,
    wrapper values, free function definitions), so a
    renamed alias — the spelled segment standing in none
    of those tables by construction — suppressed the
    refusal even when the exhaustion decided the top-level
    resolution itself."""
    if item in TYPE_LOCS or item in WRAPPER_VALUES:
        return True
    if any(n == item for _r, n in FREE_FN_DEFS):
        return True
    return any(local == item for bindings in FILE_BINDINGS_RAW.values() for local, _s, _segs, _p in bindings)

def _resolve_item(from_rel, segs, seen=()):
    """The descriptor of the item the path `segs`, spelled in
    file `from_rel`, denotes (seam round 7, protest P1):
    resolved through the renamed and plain re-exports of
    intermediate modules to the item's definition, or None when
    the path denotes no determinable production item. A
    re-export is chased transitively, in every position: the
    final segment may be a renamed or plain `pub use` in a
    file standing at the spelled module path, or a name a
    `pub use ...::*` glob re-export carries from its target
    module; a module segment of the spelled prefix may itself
    be a `pub use` re-export of another module; and where
    several files stand at one module path (see
    _candidate_files) each is tried in turn, so a re-export
    standing in any of them is followed to its definition.
    A re-export's own path is read as a use path in its
    file: anchored as spelled, and also relative to its
    file's own module (the `self` anchor), the two anchors
    a use statement's first segment can carry. The chase is
    bounded (seam round 8, protest P3): at most
    CHASE_DEPTH_BOUND re-export hops (the `seen` set) and
    CHASE_VARIANT_BOUND module-path variants. Following a
    chain past the depth bound records a named refusal (see
    _record_chase_failure) instead of returning a silent
    None; exhausting the variant bound records one when it
    decides the resolution — the top-level resolution
    returns no descriptor, the spelled item denotes a
    production item, and some frame of its chase exhausted
    the variant enumeration (a speculative frame's exhaustion
    alone decides nothing: a chase explores wrong modules
    whose variants explode while the item resolves through
    its own module, as engine's items resolve through
    src/engine.rs while the trace glob's retry enumerates).
    Seam round 9 (protest P1): the spelled item denotes,
    for this record, when its final segment is any
    production binding local — a definition name, a
    wrapper value, or a `use` binding's local name in any
    production file, renamed re-exports included (see
    _chase_item_denotes) — never only when it keys an
    original-name table, so a renamed alias cannot
    suppress the refusal; and the record is still made
    only at a top level that returns no descriptor, so
    exhaustion inside a chase another frame completes
    records nothing.
    (Variant exhaustion alone decides nothing where a
    collected variant resolves the path: the enumeration
    generates self-similar variants past the cap on live
    paths — `pub use trace::trace` in src/engine.rs makes
    every `engine::trace` resolution enumerate
    `trace::trace::trace...` variants to the cap — and the
    resolution through the collected variants stands.)"""
    if not segs:
        return None
    if len(seen) > CHASE_DEPTH_BOUND:
        _record_chase_failure(segs, "depth")
        return None
    if not seen:
        _VARIANT_HITS.clear()
    item = segs[-1]
    modpath = _resolve_modpath(from_rel, segs[:-1])
    if not seen and len(segs) == 1 and from_rel is not None:
        for local, scope, bsegs, _is_pub in FILE_BINDINGS_RAW.get(from_rel, []):
            if local == item and local != "*" and scope is None:
                _saved_hits = len(_VARIANT_HITS)
                desc = _resolve_item(from_rel, list(bsegs), seen + ((from_rel, "own-binding", item),))
                if desc is not None:
                    return desc
                del _VARIANT_HITS[_saved_hits:]

    def chase(target_rel, spelled, key):
        desc = _resolve_item(target_rel, spelled, seen + (key,))
        if desc is not None:
            return desc
        if spelled and spelled[0] not in ("crate", "self", "super"):
            return _resolve_item(target_rel, ["self"] + spelled, seen + (key,))
        return None

    def chase_at(target_rel, spelled, key, standing):
        # A link standing in a submodule (seam round 30,
        # protest P4): a re-export's own `super` / `self`
        # anchor climbs from the module the binding STANDS
        # at — the submodule's own path, which the module
        # map records — not from the home file's root
        # module, so a chain whose middle link is a
        # re-export inside a submodule is followed exactly
        # as a chain whose links stand at the root is.
        desc = chase(target_rel, spelled, key)
        if desc is not None:
            return desc
        if spelled and spelled[0] in ("super", "self") and standing:
            base = [s for s in standing.split("::") if s]
            rest = list(spelled)
            if rest[0] == "self":
                abs_segs = base + rest[1:]
            else:
                while rest and rest[0] == "super":
                    base = base[:-1]
                    rest = rest[1:]
                abs_segs = base + rest
            if abs_segs:
                return _resolve_item(target_rel, ["crate"] + abs_segs, seen + (key,))
        return None

    modpaths = [modpath]
    idx = 0
    while idx < len(modpaths) and len(modpaths) <= CHASE_VARIANT_BOUND:
        mpsegs = [s for s in modpaths[idx].split("::") if s]
        idx += 1
        for pos, segname in enumerate(mpsegs):
            parent = "::".join(mpsegs[:pos])
            for cand in _candidate_files(parent, from_rel):
                for local, scope, bsegs, is_pub in FILE_BINDINGS_RAW.get(cand, []):
                    if not is_pub or local != segname or not _binding_stands_at(cand, scope, parent):
                        continue
                    anchors = [bsegs]
                    if bsegs and bsegs[0] not in ("crate", "self", "super"):
                        anchors.append(["self"] + bsegs)
                    for anchor in anchors:
                        target_mp = _resolve_modpath(cand, anchor)
                        if not target_mp or target_mp == "::".join(mpsegs[:pos + 1]):
                            continue
                        variant = target_mp if not mpsegs[pos + 1:] else target_mp + "::" + "::".join(mpsegs[pos + 1:])
                        if variant not in modpaths:
                            modpaths.append(variant)
    # Function scopes are homes (seam round 12, protest
    # P1): an inline module declared inside a function body
    # stands at a module path anchored in its home file, not
    # at the crate root the spelled prefix anchors to, so the
    # spelled first segment also tries every inline module of
    # the spelling file whose last segment it names — the
    # local path from inside the body resolves through it
    # exactly as a module-path call does.
    if from_rel is not None and len(segs) >= 2:
        for _mp_path, _mp_home in sorted(INLINE_MOD_HOME.items()):
            if _mp_home != from_rel or _mp_path.split("::")[-1] != segs[0]:
                continue
            _variant = _mp_path if len(segs) == 2 else _mp_path + "::" + "::".join(segs[1:-1])
            if _variant not in modpaths:
                modpaths.append(_variant)
    for mp in modpaths:
        for target_rel in _candidate_files(mp, from_rel):
            # The cycle key carries the module path (seam
            # round 30, protest P4): the same item in the
            # same file standing at a DEEPER module — a
            # glob's target module re-entering the item the
            # glob itself supplied — is a further link of
            # the chain, not a return to a visited link;
            # only the same item at the same module in the
            # same file closes a cycle.
            key = (target_rel, mp, item)
            if key in seen:
                continue
            bindings = FILE_BINDINGS_RAW.get(target_rel, [])
            for local, scope, bsegs, is_pub in bindings:
                if local == item and is_pub and _binding_stands_at(target_rel, scope, mp):
                    desc = chase_at(target_rel, bsegs, key, mp)
                    if desc is not None:
                        return desc
            # A definition standing in the module itself
            # (seam round 31, protest P5): the module's own
            # item shadows its glob imports of the name, as
            # the language has it — the chase stops at the
            # definition standing in the module the path
            # names, before any glob standing there is
            # followed, so a plain twin defined in the
            # glob's own module is judged as itself and
            # never expelled as its glob-imported reaching
            # namesake.
            for (r, qual, _c, _k, _s) in TYPE_LOCS.get(item, []):
                if r == target_rel and "::".join(qual.split("::")[:-1]) == mp and _loc_module_scope32(_s):
                    return ("type", item if len(TYPE_LOCS[item]) == 1 else qual, target_rel)
            # A free function standing in the module
            # itself stops the chase at the same place
            # (seam round 32, protest P4): the module's
            # own definitions of every kind the stop
            # reads — types and free functions — shadow
            # its glob imports of the name.
            for (r, qual, _c, _s) in FN_LOCS.get(item, []):
                if r == target_rel and "::".join(qual.split("::")[:-1]) == mp and _loc_module_scope32(_s):
                    return ("free", item, target_rel)
            for local, scope, bsegs, is_pub in bindings:
                if local == "*" and is_pub and _binding_stands_at(target_rel, scope, mp):
                    desc = chase_at(target_rel, bsegs + [item], key, mp)
                    if desc is not None:
                        return desc
            locs = TYPE_LOCS.get(item, [])
            for (r, qual, _c, _k, _s) in locs:
                if r == target_rel and "::".join(qual.split("::")[:-1]) == mp and _loc_module_scope32(_s):
                    return ("type", item if len(locs) == 1 else qual, target_rel)
            if (target_rel, item) in FREE_FN_DEFS:
                return ("free", item, target_rel)
            if item in WRAPPER_VALUES and WRAPPER_VALUES[item] == target_rel:
                return ("value", item, target_rel)
            if item in SYS_DERIVED_VALUES and SYS_DERIVED_VALUES[item] == target_rel:
                return ("value", item, target_rel)
            for _sdt in SYS_DERIVED_TYPES:
                if _disp(_sdt) == item and SYS_DERIVED_TYPE_HOME.get(_sdt) == target_rel:
                    return ("type", _sdt, target_rel)
            if any(_centry[0] == target_rel for _centry in CONST_ITEMS33.get(item, [])):
                return ("const", item, target_rel)
    if len(modpaths) > CHASE_VARIANT_BOUND:
        _VARIANT_HITS.append("::".join(segs))
    if not seen and _VARIANT_HITS and _chase_item_denotes(item):
        _record_chase_failure(segs, "variant")
    return None

def _build_rename_maps(codes, production_rels):
    """Each production file's rename map (seam round 7, protest
    P1; glob entries seam round 8, protest P1): its use
    bindings resolved to the items they denote, so every arm
    can resolve a spelled local name through its scope's map
    before lookup. Bindings denoting no production item (std
    paths, sys paths, module imports) are not recorded. A
    glob binding (`use PATH::*;`) yields an entry for every
    name the target module exports — its own definitions
    and its re-export renames alike (`pub use X as Y` in the
    target binds Y to X's identity in the importing scope)
    — each resolved through _resolve_item exactly as the
    path-spelled chase resolves it. An explicit binding of a
    name shadows the glob supply of that name in its scope,
    as the language has it; a name two glob sources in one
    scope export with different identities is ambiguous in
    that scope — the recorded limit's bare-name rule — and
    yields no entry, never a first-wins one."""
    FILE_RENAMES.clear()
    _EXPORT_NAMES_CACHE.clear()
    for rel in production_rels:
        entries = []
        globbed = {}
        for local, scope, segs, _is_pub in FILE_BINDINGS_RAW.get(rel, []):
            if local == "*":
                names, _amb = _module_export_names(_resolve_modpath(rel, segs), from_rel=rel)
                for name in names:
                    desc = _resolve_item(rel, segs + [name])
                    if desc is not None:
                        globbed.setdefault((scope, name), set()).add(desc)
                continue
            desc = _resolve_item(rel, segs)
            if desc is not None:
                entries.append((local, scope, desc))
        named = {(scope, local) for local, scope, _d in entries}
        for (scope, name), descs in globbed.items():
            if (scope, name) in named or len(descs) != 1:
                continue
            entries.append((name, scope, next(iter(descs))))
        FILE_RENAMES[rel] = entries

def _denoted_platform_path(from_rel, segs, seen=()):
    """The platform path the spelled path `segs` denotes,
    followed through production re-exports (seam round 9,
    protests P5/P7): an absolute `std::os::<platform>` path
    or a `std::arch` / `core::arch` path denotes itself;
    any other spelled path is chased through the `pub use`
    bindings of the files standing at its module path —
    root-confined, as _resolve_item is — until it reaches
    such an absolute path or denotes no platform item. A
    name whose definition is a std-platform item (a trait
    included — the chase trades in bindings, not only in
    the type tables) is therefore censused at every use
    site, by the absolute path it denotes. Seam round 10
    (protest P3): the spelled module path itself is expanded
    through re-exported module segments before the item
    chase — a segment that is a `pub use` re-export of
    another module contributes the module-path variants the
    wrapper chase's variant generation computes, within the
    recorded variant bound — because the textual anchor
    alone stands no candidate at an alias's path."""
    segs = [s.strip() for s in segs if s and s.strip()]
    if len(segs) >= 3 and segs[0] == "std" and segs[1] == "os":
        return "::".join(segs)
    if len(segs) >= 3 and segs[0] in ("std", "core") and segs[1] == "arch":
        return "::".join(segs)
    if from_rel is None or len(segs) < 2 or len(seen) > CHASE_DEPTH_BOUND:
        return None
    item = segs[-1]
    modpath = _resolve_modpath(from_rel, segs[:-1])
    modpaths = [modpath]
    idx = 0
    while idx < len(modpaths) and len(modpaths) <= CHASE_VARIANT_BOUND:
        mpsegs = [s for s in modpaths[idx].split("::") if s]
        idx += 1
        for pos, segname in enumerate(mpsegs):
            parent = "::".join(mpsegs[:pos])
            for cand in _candidate_files(parent, from_rel):
                for local, scope, bsegs, is_pub in FILE_BINDINGS_RAW.get(cand, []):
                    if not is_pub or local != segname or not _binding_stands_at(cand, scope, parent):
                        continue
                    anchors = [bsegs]
                    if bsegs and bsegs[0] not in ("crate", "self", "super"):
                        anchors.append(["self"] + bsegs)
                    for anchor in anchors:
                        target_mp = _resolve_modpath(cand, anchor)
                        if not target_mp or target_mp == "::".join(mpsegs[:pos + 1]):
                            continue
                        variant = target_mp if not mpsegs[pos + 1:] else target_mp + "::" + "::".join(mpsegs[pos + 1:])
                        if variant not in modpaths:
                            modpaths.append(variant)
    for mp in modpaths:
        for cand in _candidate_files(mp, from_rel):
            key = (cand, item)
            if key in seen:
                continue
            for local, scope, bsegs, is_pub in FILE_BINDINGS_RAW.get(cand, []):
                if not is_pub or not _binding_stands_at(cand, scope, mp):
                    continue
                if local == item:
                    denoted = _denoted_platform_path(cand, bsegs, seen + (key,))
                    if denoted is not None:
                        return denoted
                elif local == "*":
                    denoted = _denoted_platform_path(cand, bsegs + [item], seen + (key,))
                    if denoted is not None:
                        return denoted
    return None


def _root_relative_occurrences(code, spans, roots):
    """The occurrences spelled from resolution roots: a path
    whose first segment is a root's local name, in a scope
    the root's binding applies in, counts as the absolute
    path the root's prefix plus the spelled remainder
    denotes."""
    occs = []
    for local, scope, prefix in roots:
        for m in re.finditer(r"\b" + re.escape(local) + r"::(\w+(?:::\w+)*)", code):
            if m.start() >= 2 and code[m.start() - 2:m.start()] == "::":
                continue
            if m.start() >= 1 and code[m.start() - 1] == ".":
                continue
            keys = [s["key"] for s in _scopes_at(spans, m.start())]
            if scope is not None and scope not in keys:
                continue
            occs.append(prefix + "::" + m.group(1))
    return occs

def _chased_occurrences(code, rel, is_channel):
    """The platform occurrences a file reaches through the
    crate's own re-export machinery (seam round 9, protest
    P5): a spelled multi-segment path whose segments the
    re-export chase resolves to a platform item counts in
    the spelling file as the absolute path it denotes, and
    so does a bare local name the file's own bindings bind
    — through a re-export — to such an item, where the name
    is used outside a use statement. Direct std bindings
    are not chased here: their absolute spelling is already
    censused by the channel's absolute arm. Seam round 10
    (protest P4): the bare-name arm follows glob bindings —
    a name a glob binding in the file supplies, expanded
    through the target module's exports exactly as the
    wrapper census's glob expansion supplies it, counts
    where the name is used bare, an explicit binding of the
    same name in the file shadowing the glob supply."""
    if rel is None:
        return []
    occs = []
    for m in re.finditer(r"((?:\w+\s*::\s*)+\w+)", code):
        segs = [s.strip() for s in m.group(1).split("::")]
        if segs[0] in ("std", "core"):
            continue
        denoted = _denoted_platform_path(rel, segs)
        if denoted is not None and is_channel(denoted):
            occs.append(denoted)
    spans = _scope_spans(code)
    scan = blank_use_statements(code)
    bindings = _rename_bindings(code, spans)
    effective = []
    explicit = {local for local, _s, _segs, _p in bindings if local != "*"}
    for local, scope, segs, _pub in bindings:
        if local != "*":
            effective.append((local, scope, segs))
    for local, scope, segs, _pub in bindings:
        if local != "*":
            continue
        names, _amb = _module_export_names(_resolve_modpath(rel, segs), from_rel=rel)
        for name in names:
            if name not in explicit:
                effective.append((name, scope, segs + [name]))
    for local, scope, segs in effective:
        if not segs or segs[0] in ("std", "core"):
            continue
        denoted = _denoted_platform_path(rel, segs)
        if denoted is None or not is_channel(denoted):
            continue
        for m in re.finditer(r"\b" + re.escape(local) + r"\b", scan):
            keys = [s["key"] for s in _scopes_at(spans, m.start())]
            if scope is not None and scope not in keys:
                continue
            occs.append(denoted)
            break
    return occs


def _std_platform_occurrences(code, rel=None):
    """The std-platform occurrences of one file's production
    code text (seam round 7, protest P6; by resolution, seam
    round 8, protest P2): every `std::os::<platform>` path the
    file reaches, spelled absolutely (`std::os::...`, the
    STD_PLATFORM_RE matches) or relatively — a path whose
    first segment is a name the file's own `use` bindings bind
    to `std::os` or to a deeper `std::os::<platform>` prefix
    (`use std::os;` binds `os`, `use std::os::windows;` binds
    `windows`), spelled with the remaining segments from that
    root, counts as the absolute path it denotes, exactly as
    the absolute spelling counts. A binding applies in its
    own scope, as the rename maps apply. Seam round 9: glob
    roots join the census (protest P4) — a `use std::os::*;`
    binding makes the platform module names the target
    exports (`windows`, `unix`, ...) roots in that scope, and
    a `use std::*;` binding likewise makes `os` a root, a
    name an explicit binding of the file binds being left to
    that binding — and the census follows re-exports to the
    definition (protest P5): a path the crate's re-export
    machinery resolves to a std-platform item counts in the
    spelling file as the absolute path it denotes. The
    census's unit is the path denoted, not the spelling.
    Seam round 10: the bare-name arm of the chased census
    follows glob bindings (protest P4), a one-segment root
    bound to the `std` or `core` crate itself joins the
    censused roots (protest P5), and the platform chase
    expands re-exported module segments (protest P3)."""
    occs = [m.group(0) for m in STD_PLATFORM_RE.finditer(code)]
    spans = _scope_spans(code)
    bindings = _rename_bindings(code, spans)
    bound_locals = {local for local, _s, _segs, _p in bindings if local != "*"}
    roots = []
    for local, scope, segs, _pub in bindings:
        if local != "*" and len(segs) >= 2 and segs[0] == "std" and segs[1] == "os":
            roots.append((local, scope, "::".join(segs)))
        elif local != "*" and len(segs) == 1 and segs[0] in ("std", "core"):
            roots.append((local, scope, segs[0]))
        elif local == "*":
            prefix = "::".join(segs)
            for name in STD_OS_GLOB_NAMES.get(prefix, []):
                if name not in bound_locals:
                    roots.append((name, scope, prefix + "::" + name))
    occs.extend(o for o in _root_relative_occurrences(code, spans, roots) if o.startswith("std::os::"))
    occs.extend(_chased_occurrences(code, rel, lambda p: p.startswith("std::os::")))
    return occs

def _arch_occurrences(code, rel=None):
    """The arch-channel occurrences of one file's production
    code text (seam round 9, protest P7): every `std::arch`
    / `core::arch` path the file reaches, spelled absolutely
    (the ARCH_RE matches), through a root the file's own
    bindings bind to `std::arch` / `core::arch` or a deeper
    prefix, through a glob root (the arch submodule names
    the target exports are roots in that scope), or through
    a crate re-export of the arch item itself — the same
    resolution census as the std-platform channel, beside
    it. Inside the pure set the channel stands only as the
    pinned occurrences in ARCH_PINNED — the empty set: the
    tree carries no live arch occurrence in any production
    file, so any occurrence in a pinned file fails by name.
    Seam round 10: the channel shares the std-platform
    census's round-10 arms — glob bare names, the
    one-segment crate root, and module-segment expansion
    (protests P3/P4/P5)."""
    occs = [m.group(0) for m in ARCH_RE.finditer(code)]
    spans = _scope_spans(code)
    bindings = _rename_bindings(code, spans)
    bound_locals = {local for local, _s, _segs, _p in bindings if local != "*"}
    roots = []
    for local, scope, segs, _pub in bindings:
        if local != "*" and len(segs) >= 2 and segs[0] in ("std", "core") and segs[1] == "arch":
            roots.append((local, scope, "::".join(segs)))
        elif local != "*" and len(segs) == 1 and segs[0] in ("std", "core"):
            roots.append((local, scope, segs[0]))
        elif local == "*":
            prefix = "::".join(segs)
            for name in ARCH_GLOB_NAMES.get(prefix, []):
                if name not in bound_locals:
                    roots.append((name, scope, prefix + "::" + name))
    occs.extend(o for o in _root_relative_occurrences(code, spans, roots) if "::arch::" in o)
    occs.extend(_chased_occurrences(code, rel, lambda p: "::arch::" in p))
    return occs

def _extern_decl_names(code):
    """The names a file declares in its own `extern` blocks —
    every item kind the block can carry: `fn`, `static` and
    `type` (seam round 10, protest P7: the round-9 extraction
    read only `fn` names, so a foreign static — storage in a
    system library, an FFI reach of the same kind — was
    invisible) — plus any declaration-form `extern fn` item,
    an `extern fn` whose signature ends at a semicolon, a
    foreign declaration with no body (seam round 9, protest
    P3). The census runs on code text, whose literal contents
    are blanked, so the block pattern accepts any ABI string.
    A defined `extern fn` item (a callback with a body) is a
    definition, not a declaration, and an `extern fn` pointer
    type names no function after `fn`; neither is returned."""
    names = []
    for m in re.finditer(r"\bextern\s+(?:\"[^\"]*\"\s*)?\{", code):
        brace = code.find("{", m.start())
        end = _brace_match(code, brace)
        block = code[brace:end]
        for fm in re.finditer(r"\bfn\s+(\w+)\s*\(", block):
            names.append(fm.group(1))
        for fm in re.finditer(r"\bstatic\s+(?:mut\s+)?(\w+)\s*:", block):
            names.append(fm.group(1))
        for fm in re.finditer(r"\btype\s+(\w+)\s*;", block):
            names.append(fm.group(1))
    for m in re.finditer(r"\bextern\s+(?:\"[^\"]*\"\s*)?fn\s+(\w+)\s*\(", code):
        j = m.end()
        while j < len(code) and code[j] not in "{;":
            j += 1
        if j < len(code) and code[j] == ";":
            names.append(m.group(1))
    return sorted(set(names))

def trait_spans(code):
    """Every `trait` definition in `code` as (brace, end, name)
    (seam round 10, protest P2): a trait definition is not an
    `impl` block, so the derivation's impl-span attribution
    never sees its default methods."""
    out = []
    for m in re.finditer(r"\btrait\s+(\w+)", code):
        brace = code.find("{", m.end())
        semi = code.find(";", m.end())
        if brace < 0 or (0 <= semi < brace):
            continue
        out.append((brace, _brace_match(code, brace), m.group(1)))
    return out

def impl_trait_pairs(code):
    """Every `impl` block's (trait name or None, defining type
    name) (seam round 10, protest P2): the trait-implementation
    relation, read from the same headers impl_spans reads —
    `impl Trait for Type` contributes (Trait, Type), an
    inherent `impl Type` contributes (None, Type)."""
    out = []
    for m in re.finditer(r"\bimpl\b", code):
        brace = code.find("{", m.end())
        semi = code.find(";", m.end())
        if brace < 0 or (0 <= semi < brace):
            continue
        header = code[m.end():brace]
        tr = None
        if " for " in header:
            tpart = header.split(" for ")[0]
            tpart = re.sub(r"<[^>]*>", "", tpart).strip()
            twords = re.findall(r"(\w+)", tpart)
            tr = twords[-1] if twords else None
            header = header.split(" for ")[-1]
        header = re.sub(r"<[^>]*>", "", header).strip()
        words = re.findall(r"(\w+)", header)
        if words:
            out.append((tr, words[-1]))
    return out

def _macro_defs(code):
    """Every `macro_rules!` definition in `code` as (name, body
    text) (seam round 10, protest P10): the definition's
    delimiter block, brace-, bracket- or paren-delimited as
    written, read on blanked text."""
    out = []
    for m in re.finditer(r"\bmacro_rules!\s*(\w+)", code):
        j = m.end()
        while j < len(code) and code[j] not in "{[(":
            j += 1
        if j >= len(code):
            continue
        close = {"{": "}", "[": "]", "(": ")"}[code[j]]
        end = _delim_match(code, j, code[j], close)
        out.append((m.group(1), code[j:end]))
    return out

def _blanket_traits(code):
    """The traits a blanket impl in `code` supplies (seam round
    11, protest P2): an `impl<...> Trait for T` whose
    implementing type is one of the impl's own generic
    parameters denotes the trait on EVERY type, so the
    derivation keys it by the trait itself, never by the
    spelled parameter name — the recorded generic-receiver
    limit is not this case, the receiver's type being a
    concrete declared struct."""
    out = set()
    for m in re.finditer(r"\bimpl\s*<([^>]*)>", code):
        brace = code.find("{", m.end())
        semi = code.find(";", m.end())
        if brace < 0 or (0 <= semi < brace):
            continue
        header = code[m.end():brace]
        if " for " not in header:
            continue
        params = {p.strip().split(":")[0].split("=")[0].strip() for p in m.group(1).split(",")}
        tpart, impart = header.split(" for ", 1)
        twords = re.findall(r"(\w+)", re.sub(r"<[^>]*>", "", tpart))
        iwords = re.findall(r"(\w+)", re.sub(r"<[^>]*>", "", impart))
        if twords and len(iwords) == 1 and iwords[0] in params:
            out.add(twords[-1])
    return out

def _closure_body(expr):
    """The body text of the closure literal `expr` is, or None
    when `expr` is not a closure literal (seam round 11,
    protest P5): the text after the parameter list's closing
    bar, a brace block's contents being the body as written."""
    m = re.match(r"^(?:move\s+)?\|[^|]*\|\s*(.*)$", expr.strip(), re.S)
    return m.group(1) if m else None

def _return_yields(body, rel):
    """Whether an item's return expressions yield a wrapper
    (seam round 11, protests P3/P5): a return expression that
    yields the wrapper as its own value, as the free-function
    derivation has always judged it, or a returned closure
    whose body reaches a wrapper — the wrapper's behaviour in
    an unnamed item, attached to the item that defines it."""
    for e in _return_exprs(body):
        if _expr_yields_wrapper(e, rel):
            return True
        cb = _closure_body(e)
        if cb is not None and (body_reaches_sys(cb, cb) or (WRAPPER_WORD_RE is not None and WRAPPER_WORD_RE.search(cb) is not None) or any(n in WRAPPER_VALUES for n in re.findall(r"\b\w+\b", cb)) or any(re.search(r"\b" + re.escape(_disp(t)) + r"::" + re.escape(n) + r"\b", cb) for (t, n) in WRAPPERS_METH)):
            return True
    return False

def _yielded_wrapper(expr, rel):
    """The wrapper a bare path expression denotes, as
    (display, home), or None (seam round 11, protest P4): a
    free wrapper, a wrapper value, or a wrapper method's path,
    named bare or resolved through the re-export chase — the
    wrapper-value derivation's judgement of a path, returning
    the wrapper itself for the field-carriage record."""
    expr = _strip_turbofish(expr.strip())
    m = re.fullmatch(r"((?:\w+\s*::\s*)*)(\w+)", expr)
    if not m:
        return None
    segs = [s.strip() for s in m.group(1).split("::") if s.strip()]
    last = m.group(2)
    if segs:
        tident = _ident_of(segs[-1], segs[:-1])
        if tident is not None and (tident, last) in WRAPPERS_METH:
            return (_disp(tident) + "::" + last, WRAPPERS_METH[(tident, last)])
        desc = _resolve_item(rel, segs + [last])
        if desc is not None and desc[0] == "free" and desc[1] in WRAPPERS_FREE:
            return (desc[1], WRAPPERS_FREE[desc[1]])
        if desc is not None and desc[0] == "value" and desc[1] in WRAPPER_VALUES:
            return (desc[1] + " (wrapper value)", desc[2])
        return None
    if last in WRAPPERS_FREE:
        return (last, WRAPPERS_FREE[last])
    if last in WRAPPER_VALUES:
        return (last + " (wrapper value)", WRAPPER_VALUES[last])
    return None

def _expand_alias_ident(ident):
    """The defining type identity an alias identity denotes
    (seam round 13, protest P1): aliases expanded transitively,
    as the wrapper-type closure already expands them — an
    associated call spelled on an alias is a call on the type
    the alias denotes."""
    seen = set()
    while ident in ALIAS_IDENTS and ident not in seen:
        seen.add(ident)
        nxt = _det_id(ALIAS_TEXT.get(ident, ""), expand=False, rel=_alias_home(ident))
        if nxt is None or nxt == ident:
            break
        ident = nxt
    return ident

def _impl_trait_spans(code):
    """Every `impl` block as (trait name or None, defining type
    bare name, brace, end) (seam round 13, protest P8): the
    impl_trait_pairs relation with its spans, so the items an
    impl defines can be read from the impl itself."""
    out = []
    for m in re.finditer(r"\bimpl\b", code):
        brace = code.find("{", m.end())
        semi = code.find(";", m.end())
        if brace < 0 or (0 <= semi < brace):
            continue
        header = code[m.end():brace]
        tr = None
        if " for " in header:
            tpart = header.split(" for ")[0]
            tpart = re.sub(r"<[^>]*>", "", tpart).strip()
            twords = re.findall(r"(\w+)", tpart)
            tr = twords[-1] if twords else None
            header = header.split(" for ")[-1]
        header = re.sub(r"<[^>]*>", "", header).strip()
        words = re.findall(r"(\w+)", header)
        if words:
            out.append((tr, words[-1], brace, _brace_match(code, brace)))
    return out

def _blanket_impl_bounds(code):
    """The bound traits of every blanket impl in `code`, as
    {trait name: {bound trait bare names}} (seam round 13,
    protest P8's reason-level note): an `impl<P: Bound> Trait
    for P` supplies Trait only to types that satisfy Bound, so
    the blanket attribution reads the bound's satisfaction —
    from the receiver type's own impl list, or from a generic
    parameter's signature bounds (see _blanket_satisfied)."""
    out = {}
    for m in re.finditer(r"\bimpl\s*<([^>]*)>", code):
        brace = code.find("{", m.end())
        semi = code.find(";", m.end())
        if brace < 0 or (0 <= semi < brace):
            continue
        header = code[m.end():brace]
        if " for " not in header:
            continue
        params = {}
        for p in m.group(1).split(","):
            p = p.strip()
            if not p or p.startswith("'"):
                continue
            if ":" in p:
                pname, bounds = p.split(":", 1)
                bset = set()
                for b in bounds.split("+"):
                    bw = re.findall(r"(\w+)", re.sub(r"<[^>]*>", "", b))
                    if bw:
                        bset.add(bw[-1])
                params[pname.strip()] = bset
            else:
                params[p.strip()] = set()
        tpart, impart = header.split(" for ", 1)
        twords = re.findall(r"(\w+)", re.sub(r"<[^>]*>", "", tpart))
        iwords = re.findall(r"(\w+)", re.sub(r"<[^>]*>", "", impart))
        if twords and len(iwords) == 1 and iwords[0] in params:
            out.setdefault(twords[-1], set()).update(params[iwords[0]])
    return out

def _blanket_impl_pairs(code):
    """The (trait, parameter) pairs of every blanket impl in
    `code` (seam round 14, protest P11): an
    `impl<P: Bound> Trait for P` supplies Trait to every
    type satisfying Bound — it is not an impl OF the
    parameter, and recording it under the parameter's
    spelled name would key the trait relation on a spelling,
    so the derivation records blanket pairs apart and never
    enters them in TRAIT_IMPLS."""
    out = set()
    for m in re.finditer(r"\bimpl\s*<([^>]*)>", code):
        brace = code.find("{", m.end())
        semi = code.find(";", m.end())
        if brace < 0 or (0 <= semi < brace):
            continue
        header = code[m.end():brace]
        if " for " not in header:
            continue
        params = {p.strip().split(":")[0].split("=")[0].strip() for p in m.group(1).split(",")}
        tpart, impart = header.split(" for ", 1)
        twords = re.findall(r"(\w+)", re.sub(r"<[^>]*>", "", tpart))
        iwords = re.findall(r"(\w+)", re.sub(r"<[^>]*>", "", impart))
        if twords and len(iwords) == 1 and iwords[0] in params:
            out.add((twords[-1], iwords[0]))
    return out

def _build_trait_overrides(codes, production_rels):
    """The trait-override and blanket-bound tables (seam round
    13, protest P8): TRAIT_OVERRIDES records, for every
    production `impl Trait for Type` that DEFINES a method,
    the (type, trait, method) it defines — where a receiver
    type's own impl defines the method, the item judged is
    the override, and the trait default is attributed only to
    types whose impl leaves it in place. BLANKET_BOUNDS
    records the bound each blanket impl requires."""
    TRAIT_OVERRIDES.clear()
    BLANKET_BOUNDS.clear()
    SUPERTRAITS.clear()
    for rel in production_rels:
        code = codes[rel]
        spans = _impl_trait_spans(code)
        if spans:
            items = typed_items(code)
            for tr, ty, brace, end in spans:
                if tr is None:
                    continue
                for name, tname, _sig, _body, off in items:
                    if brace < off < end and tname == ty:
                        TRAIT_OVERRIDES.setdefault((ty, tr, name), rel)
        for tr, bounds in _blanket_impl_bounds(code).items():
            BLANKET_BOUNDS.setdefault(tr, set()).update(bounds)
        for m in re.finditer(r"\btrait\s+(\w+)\s*(?:<[^;{]*>)?\s*:\s*([^{;]+)\{", code):
            sups = set()
            for b in re.split(r"\bwhere\b", m.group(2))[0].split("+"):
                bw = re.findall(r"(\w+)", re.sub(r"<[^>]*>", "", b))
                if bw and bw[-1][0].isupper():
                    sups.add(bw[-1])
            if sups:
                SUPERTRAITS.setdefault(m.group(1), set()).update(sups)

def _generic_param_bounds(sig, name):
    """A signature's generic parameters' bound trait names, as
    {param: {bound trait bare names}} (seam round 13, protest
    P8): read from the generics list after the item's name and
    from its `where` clause — the bounds a generic receiver's
    type is guaranteed by its own item's signature."""
    out = {}
    texts = []
    m = re.match(r"\s*fn\s+" + re.escape(name) + r"\s*<", sig)
    if m:
        start = m.end() - 1
        end = _delim_match(sig, start, "<", ">")
        texts.append(sig[start + 1:end - 1])
    wm = re.search(r"\bwhere\b(.*)$", sig, re.S)
    if wm:
        texts.append(wm.group(1))
    for text in texts:
        for part in _split_top_commas(text):
            pm = re.match(r"(\w+)\s*:\s*(.+)$", part.strip(), re.S)
            if not pm:
                continue
            bset = out.setdefault(pm.group(1), set())
            for b in pm.group(2).split("+"):
                bw = re.findall(r"(\w+)", re.sub(r"<[^>]*>", "", b))
                if bw and not bw[-1][0].islower():
                    bset.add(bw[-1])
    return out

def _effective_traits(traits):
    """The traits a trait set effectively supplies (seam
    round 14, protest P11): the set closed under supertrait
    chains — a trait's declared supertraits stand wherever
    the trait stands — and under blanket supply — a blanket
    impl's trait stands wherever its recorded bound is
    satisfied — the language's own reading of what a type
    implementing `traits` satisfies, computed to a fixed
    point."""
    out = set(traits)
    changed = True
    while changed:
        changed = False
        for t in list(out):
            for s in SUPERTRAITS.get(t, ()):
                if s not in out:
                    out.add(s)
                    changed = True
        for bt, bounds in BLANKET_BOUNDS.items():
            if bt not in out and bounds and bounds <= out:
                out.add(bt)
                changed = True
    return out

def _blanket_satisfied(trait, rt, sig, name):
    """Whether receiver type `rt` satisfies blanket trait
    `trait`'s recorded bound (seam round 13, protest P8;
    seam round 14, protest P11): the bound stands among the
    traits the receiver type effectively supplies — its own
    impls closed under supertrait chains and blanket supply
    — or among the signature bounds of the generic parameter
    the receiver's type is, closed the same way. Satisfaction
    is keyed on the parameter's identity — its own bounds —
    never its spelled name: a blanket impl records no impl
    under its parameter's name (see _blanket_impl_pairs), so
    no name can collide with one. A bound with no recorded
    requirement is vacuously satisfied. A bound satisfied
    only through another parameter's bound is not read —
    the recorded limit, at its true boundary."""
    bounds = BLANKET_BOUNDS.get(trait)
    if not bounds:
        return True
    bare = _disp(rt)
    if bounds <= _effective_traits(TRAIT_IMPLS.get(bare, set())):
        return True
    gb = _generic_param_bounds(sig, name)
    return bare in gb and bounds <= _effective_traits(gb[bare])

def _called_through(text, close):
    """Whether the call whose argument list ends at `close`
    (one past its closing paren) is itself called — its result
    called through (seam round 13, protest P7): grouping
    parentheses around the call are read through, as Rust
    permits them, before the call-through paren is required."""
    j = close
    while True:
        while j < len(text) and text[j].isspace():
            j += 1
        if j < len(text) and text[j] == ")":
            j += 1
            continue
        break
    return j < len(text) and text[j] == "("

def _is_call_through_at(text, end):
    """Whether the value whose text ends at `end` in `text`
    is called — directly, through a value-preserving
    projection chain of method calls and indexes on the value
    itself (`unwrap()` and kin, seam round 13, protest P11),
    or through grouping parentheses around it."""
    j = end
    while j < len(text) and text[j].isspace():
        j += 1
    while j < len(text):
        if text[j] == ".":
            km = re.match(r"\.\s*\w+\s*\(", text[j:])
            if not km:
                break
            j = _delim_match(text, j + km.end() - 1, "(", ")")
        elif text[j] == "[":
            j = _delim_match(text, j, "[", "]")
        else:
            break
        while j < len(text) and text[j].isspace():
            j += 1
    if j < len(text) and text[j] == "(":
        return True
    if j < len(text) and text[j] == ")":
        return _called_through(text, j + 1)
    return False

def _call_result_hit(call, rel):
    """The wrapper a call's RESULT carries, as (display,
    home), or None (seam round 13, protest P4): the callee is
    wrapper-yielding — a free function, a method, or a trait
    default spelled `<Type as Trait>::name`, the trait path
    parsed as a callee — and the yielded wrapper is the
    callee's own return yield where its body spells it, else
    the yielding item itself. A trait-path call on a type
    whose own impl overrides the method is judged by the
    OVERRIDE (seam round 13, protest P8), never the default.
    Seam round 14 (protest P1): the trait-path arm resolves
    the callee type through production type aliases to its
    defining type, as the value closures already do, so the
    override lookup and the yield lookup alike are judged by
    the defining type's own impl in both directions. Seam
    round 14 (protest P4): a receiver-spelled method callee
    is a callee here as everywhere else in the computation —
    a wrapper-yielding method called on a value whose type
    its const or static declaration spells (VALUE_TYPES) is
    judged by that method's own yield."""
    call = call.strip()
    while call.startswith("(") and _delim_match(call, 0, "(", ")") == len(call):
        call = call[1:-1].strip()
    tm = re.match(r"^<\s*((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s+as\s+((?:\w+\s*::\s*)*\w+)\s*>\s*::\s*(\w+)\s*\(", call)
    if tm:
        tsegs = [s.strip() for s in tm.group(1).split("::")]
        trait = [s.strip() for s in tm.group(2).split("::")][-1]
        method = tm.group(3)
        tident = _ident_of(tsegs[-1], tsegs[:-1])
        if tident is not None:
            tident = _expand_alias_ident(tident)
        key = _disp(tident) if tident is not None else tsegs[-1]
        if (key, trait, method) in TRAIT_OVERRIDES:
            if tident is not None and (tident, method) in WRAPPER_YIELD_METH:
                return (_disp(tident) + "::" + method + " (wrapper-yielding method)", WRAPPER_YIELD_METH[(tident, method)])
            return None
        if (trait, method) in TRAIT_YIELD:
            return (trait + "::" + method + " (wrapper-yielding trait method)", TRAIT_YIELD[(trait, method)])
        return None
    for (h, n) in _call_targets(call, rel):
        if n in WRAPPER_YIELD_FREE:
            body = FN_BODIES.get((h, n))
            if body is not None:
                for e in _return_exprs(body):
                    hit = _yielded_wrapper(e, h)
                    if hit is not None:
                        return hit
            return (n + " (wrapper-yielding function)", WRAPPER_YIELD_FREE[n])
    for (t, n) in _call_targets_meth(call, rel):
        if (t, n) in WRAPPER_YIELD_METH:
            ent = METH_BODIES.get((t, n))
            if ent is not None:
                for e in _return_exprs(ent[1]):
                    hit = _yielded_wrapper(e, ent[0])
                    if hit is not None:
                        return hit
            return (_disp(t) + "::" + n + " (wrapper-yielding method)", WRAPPER_YIELD_METH[(t, n)])
    for rm in re.finditer(r"((?:\w+(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*::\s*)*\w+)\s*\.\s*(\w+)\s*\(", call):
        rsegs = [s.strip() for s in rm.group(1).split("::") if s.strip() and not s.strip().startswith("<")]
        if not rsegs:
            continue
        tident = VALUE_TYPES.get(rsegs[-1])
        if tident is None:
            continue
        n = rm.group(2)
        if (tident, n) in WRAPPER_YIELD_METH:
            ent = METH_BODIES.get((tident, n))
            if ent is not None:
                for e in _return_exprs(ent[1]):
                    hit = _yielded_wrapper(e, ent[0])
                    if hit is not None:
                        return hit
            return (_disp(tident) + "::" + n + " (wrapper-yielding method)", WRAPPER_YIELD_METH[(tident, n)])
    return None

def _return_positions_of(body, var):
    """How the local `var` stands in `body`'s return
    expressions, as (mentioned, tuple index paths) (seam
    round 16, protest P5): mentioned where a return
    expression carries the variable in a value position
    the result's own call-through can follow (bare, or
    under a variant or constructor the caller unwraps, as
    the round-14 step already read it), and the index
    PATH of the variable in a tuple-packaged return — the
    position of the tuple element that is the variable
    itself, at whatever packaging depth it stands. Seam
    round 18 (protest P5): the packaging is read to the
    depth the caller's destructure reaches — an element
    that is itself a tuple is walked as the caller's
    pattern walks it, the pattern the guide, as the
    nested-subpattern step already reads it."""
    mentioned = any(re.search(r"\b" + re.escape(var) + r"\b", e) for e in _return_exprs(body))
    paths = []

    def walk(e2, prefix):
        e2 = e2.strip()
        if e2.startswith("(") and _delim_match(e2, 0, "(", ")") == len(e2):
            parts = _split_top(e2[1:-1])
            if len(parts) > 1:
                for idx, p in enumerate(parts):
                    p2 = p.strip()
                    if p2 == var:
                        if prefix + (idx,) not in paths:
                            paths.append(prefix + (idx,))
                    elif p2.startswith("(") or re.match(r"^(?:\w+\s*::\s*)*\w+(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\(", p2):
                        walk(p2, prefix + (idx,))
                return
            if parts:
                walk(parts[0], prefix)
                return
        # A container constructor around the packaging
        # (seam round 20, protest P5): `Ok(x)` / `Some(x)`
        # holds its single argument where the caller's
        # destructure — after the caller's own payload
        # step — reaches it, at the same path; a
        # multi-argument constructor's positions stand as
        # a tuple's do.
        cm = re.match(r"^(?:\w+\s*::\s*)*\w+(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\((.*)\)$", e2, re.S)
        if cm and _delim_match(e2, e2.index("("), "(", ")") == len(e2):
            args = _split_top(cm.group(1))
            if len(args) == 1:
                walk(args[0], prefix)
            elif len(args) > 1:
                for idx, p in enumerate(args):
                    p2 = p.strip()
                    if p2 == var:
                        if prefix + (idx,) not in paths:
                            paths.append(prefix + (idx,))
                    else:
                        walk(p2, prefix + (idx,))

    for e in _return_exprs(body):
        walk(e.strip(), ())
    return mentioned, paths

def _return_projection_positions(body, rmap, rel):
    """The (hit, tuple index path) pairs of the field
    projections standing in `body`'s return expressions
    in packaging positions (seam round 20, protest P5):
    a tuple element that IS a field projection is judged
    by the projection arms — _bound_local_hit's candidate
    logic — as a bound local is judged, at every
    packaging depth the caller's destructure reaches:
    nested tuples, and a projection packaged inside a
    container constructor (`Ok(...)`, `Some(...)`), whose
    single argument stands at the same path the
    destructure reaches after its payload step. The
    round-18 step read only a projection that had first
    paused at a named local; the value's flow is the
    claim's unit, not the binding's name."""
    out = []

    def leaf(e2, prefix):
        e2 = e2.strip()
        if re.search(r"\.\w+$", e2):
            off = body.find(e2)
            if off >= 0:
                hit = _bound_local_hit(body, off, e2, rmap, rel)
                if hit is not None and (hit, prefix) not in out:
                    out.append((hit, prefix))
                    return
        if prefix:
            # A wrapper standing DIRECTLY as a packaging
            # element (seam round 24, protest P5): the
            # element is itself a wrapper path, or a
            # wrapper-yielding call, judged at the
            # field-initialiser judgement's breadth, and it
            # stands at the element's own path, as a wrapper
            # arriving by field projection stands at its
            # path — no projection step intervenes to be the
            # unit of the judgement.
            hit = _field_init_wrapper(e2, rel)
            if hit is not None and (hit, prefix) not in out:
                out.append((hit, prefix))

    def walk(e2, prefix):
        e2 = e2.strip()
        if e2.startswith("[") and _delim_match(e2, 0, "[", "]") == len(e2):
            # An array literal's elements (seam round 22,
            # protest P4): each element stands at its index
            # path, the path the caller's own index reaches.
            parts = _split_top(e2[1:-1])
            if len(parts) == 1 and ";" in parts[0]:
                parts = [parts[0].split(";", 1)[0]]
            for idx, p in enumerate(parts):
                if p.strip():
                    walk(p, prefix + (("i", idx),))
            return
        vm22 = re.match(r"^vec\s*!\s*\[(.*)\]$", e2, re.S)
        if vm22 and _delim_match(e2, e2.index("["), "[", "]") == len(e2):
            # A `vec!` literal's elements, at their index
            # paths as an array's are (seam round 22,
            # protest P4): the macro's brackets are the
            # array's shape to the walk.
            parts = _split_top(vm22.group(1))
            if len(parts) == 1 and ";" in parts[0]:
                parts = [parts[0].split(";", 1)[0]]
            for idx, p in enumerate(parts):
                if p.strip():
                    walk(p, prefix + (("i", idx),))
            return
        sm22 = re.match(r"^((?:\w+\s*::\s*)*\w+|Self)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\{", e2)
        if sm22 and _brace_match(e2, e2.index("{")) == len(e2):
            # A struct literal's fields (seam round 22,
            # protest P4): each field stands at its field
            # path, and the literal's field initialiser is
            # judged by the projection arms, as a
            # construction's is in the carriage derivation.
            lits = _struct_literals(e2)
            if lits:
                for fname, fexpr in lits[0][1]:
                    walk(fexpr, prefix + (("f", fname),))
                return
        if e2.startswith("(") and _delim_match(e2, 0, "(", ")") == len(e2):
            parts = _split_top(e2[1:-1])
            if len(parts) > 1:
                for idx, p in enumerate(parts):
                    walk(p, prefix + (idx,))
                return
            if parts:
                walk(parts[0], prefix)
                return
        cm = re.match(r"^(?:\w+\s*::\s*)*\w+(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\((.*)\)$", e2, re.S)
        if cm and _delim_match(e2, e2.index("("), "(", ")") == len(e2):
            args = _split_top(cm.group(1))
            if len(args) == 1:
                walk(args[0], prefix)
            elif len(args) > 1:
                for idx, p in enumerate(args):
                    walk(p, prefix + (idx,))
            elif prefix:
                # A wrapper-yielding call standing directly
                # as a packaging element (seam round 24,
                # protest P5), at the element's path.
                hit = _field_init_wrapper(e2, rel)
                if hit is not None and (hit, prefix) not in out:
                    out.append((hit, prefix))
            return
        leaf(e2, prefix)

    for e in _return_exprs(body):
        walk(e, ())
    return out


def _result_called_through(scan, callee, positions, starts=None):
    """Whether a call to `callee` in `scan` has its result
    called through, in the senses _return_positions_of
    records (seam round 16, protest P5): directly — the
    call's result itself called, a projection chain on it
    included — or by tuple destructure: a `let (.....) =
    callee(...)` pattern binding whose element at a
    packaged index is a plain variable that is itself
    called in the file."""
    mentioned, idxs = positions[0], positions[1]
    direct = positions[2] if len(positions) > 2 else []
    if mentioned:
        for cm in re.finditer(r"\b" + re.escape(callee) + r"\s*\(", scan):
            if scan[max(0, cm.start() - 3):cm.start()] == "fn ":
                continue
            if starts is not None and cm.start() not in starts:
                continue
            if _is_call_through_at(scan, _delim_match(scan, cm.end() - 1, "(", ")")):
                return True
    for path in direct:
        # A packaging the caller reaches through on the
        # call result itself (seam round 22, protest P4):
        # an index step (`pick()[0]`) or a field step
        # (`pick().field`), the steps followed textually
        # from the call's own closing paren, the result
        # then called through as a mentioned result is.
        if not path:
            continue
        for cm in re.finditer(r"\b" + re.escape(callee) + r"\s*\(", scan):
            if scan[max(0, cm.start() - 3):cm.start()] == "fn ":
                continue
            if starts is not None and cm.start() not in starts:
                continue
            j = _delim_match(scan, cm.end() - 1, "(", ")")
            ok = True
            for step in path:
                while j < len(scan) and scan[j].isspace():
                    j += 1
                if isinstance(step, tuple) and step[0] == "i":
                    if j >= len(scan) or scan[j] != "[":
                        ok = False
                        break
                    j = _delim_match(scan, j, "[", "]")
                elif isinstance(step, tuple) and step[0] == "f":
                    fm = re.match(r"\.\s*" + re.escape(step[1]) + r"\b", scan[j:])
                    if not fm:
                        ok = False
                        break
                    j += fm.end()
                elif isinstance(step, int) and not isinstance(step, bool):
                    # A tuple step (seam round 23, protest
                    # P4): the walk records a tuple element
                    # as a bare integer, and the caller
                    # reaches it as `.<idx>` on the call
                    # result — the step the pattern arm
                    # already reads — so a path mixing the
                    # index steps with the tuple steps
                    # (an array of tuples reached through
                    # `[0].0`, and its sibling mixtures)
                    # is followed whole, not refused.
                    fm = re.match(r"\.\s*" + str(step) + r"\b", scan[j:])
                    if not fm:
                        ok = False
                        break
                    j += fm.end()
                else:
                    ok = False
                    break
            if ok and _is_call_through_at(scan, j):
                return True
    for path in idxs:
        for lm in re.finditer(r"\blet\s+", scan):
            j = lm.end()
            while j < len(scan) and scan[j].isspace():
                j += 1
            if j >= len(scan):
                continue
            if scan[j] == "(":
                pend = _delim_match(scan, j, "(", ")")
            elif scan[j] == "[":
                pend = _delim_match(scan, j, "[", "]")
            else:
                bpos = scan.find("{", j)
                if bpos < 0:
                    continue
                pend = _brace_match(scan, bpos)
            am = re.match(r"\s*(?::[^=;]+)?=\s*(?:(?:\w+\s*::\s*)*|<(?:[^<>]|<[^<>]*>)*>\s*::\s*)" + re.escape(callee) + r"\s*\(", scan[pend:], re.S)
            if not am:
                continue
            cur = scan[j:pend]
            v = None
            ok = True
            for depth_i, step in enumerate(path):
                if depth_i > 0:
                    vm0 = re.fullmatch(r"(?:ref\s+|mut\s+)?(\w+)", cur.strip())
                    if vm0:
                        # A plain variable the pattern binds at
                        # this position, with packaging steps
                        # still to follow (seam round 24,
                        # protest P3): the remaining steps are
                        # projections standing ON the bound
                        # local in the body — the
                        # pattern-then-field form — and are
                        # followed textually from each occurrence
                        # of the variable after the binding, as
                        # the direct arm follows them from the
                        # call itself, so a recorded path is
                        # followed in composition, not only in
                        # isolation.
                        vname = vm0.group(1)
                        rest0 = scan[pend:]
                        for m3 in re.finditer(r"\b" + re.escape(vname) + r"\b", rest0):
                            j2 = pend + m3.end()
                            ok2 = True
                            for step2 in path[depth_i:]:
                                while j2 < len(scan) and scan[j2].isspace():
                                    j2 += 1
                                if isinstance(step2, tuple) and step2[0] == "i":
                                    if j2 >= len(scan) or scan[j2] != "[":
                                        ok2 = False
                                        break
                                    j2 = _delim_match(scan, j2, "[", "]")
                                elif isinstance(step2, tuple) and step2[0] == "f":
                                    fm9 = re.match(r"\.\s*" + re.escape(step2[1]) + r"\b", scan[j2:])
                                    if not fm9:
                                        ok2 = False
                                        break
                                    j2 += fm9.end()
                                elif isinstance(step2, int) and not isinstance(step2, bool):
                                    fm9 = re.match(r"\.\s*" + str(step2) + r"\b", scan[j2:])
                                    if not fm9:
                                        ok2 = False
                                        break
                                    j2 += fm9.end()
                                else:
                                    ok2 = False
                                    break
                            if ok2 and _is_call_through_at(scan, j2):
                                return True
                        ok = False
                        break
                last_step = depth_i == len(path) - 1
                if isinstance(step, tuple) and step[0] == "i":
                    # An array pattern's element (seam round
                    # 22, protest P4), at its index path as a
                    # tuple pattern's element stands at its
                    # index.
                    if not (cur.startswith("[") and _delim_match(cur, 0, "[", "]") == len(cur)):
                        ok = False
                        break
                    elems = _split_top(cur[1:-1])
                    if step[1] >= len(elems):
                        ok = False
                        break
                    el = elems[step[1]].strip()
                elif isinstance(step, tuple) and step[0] == "f":
                    # A struct pattern's field (seam round
                    # 22, protest P4), at its field path: the
                    # field's entry in the pattern, shorthand
                    # or `field: subpattern`.
                    pm = re.match(r"^(?:\w+\s*::\s*)*\w+(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\{(.*)\}$", cur, re.S)
                    if not pm:
                        ok = False
                        break
                    el = None
                    for part in _split_top(pm.group(1)):
                        fm2 = re.match(r"^" + re.escape(step[1]) + r"\s*(?::\s*(.+))?$", part.strip(), re.S)
                        if fm2:
                            el = fm2.group(1).strip() if fm2.group(1) else step[1]
                            break
                    if el is None:
                        ok = False
                        break
                else:
                    idx = step
                    if not (cur.startswith("(") and _delim_match(cur, 0, "(", ")") == len(cur)):
                        ok = False
                        break
                    elems = _split_top(cur[1:-1])
                    if idx >= len(elems):
                        ok = False
                        break
                    el = elems[idx].strip()
                if last_step:
                    vm = re.fullmatch(r"(?:ref\s+|mut\s+)?(\w+)", el)
                    if not vm:
                        ok = False
                        break
                    v = vm.group(1)
                else:
                    cur = el
            if not ok or v is None:
                continue
            rest = scan[pend:]
            if any(_is_call_through_at(scan, pend + m2.end()) for m2 in re.finditer(r"\b" + re.escape(v) + r"\b", rest)):
                return True
    return False

def _let_closures(body):
    """The closures `body` binds to locals, as (name, body
    text with braces) (seam round 16, protest P5): a
    `let name = || ... { ... }` or `let name = || expr;`
    binding, the closure's return expressions readable by
    _return_exprs over the returned text. A closure with a
    declared return type (`|| -> T { ... }`) is read past
    its type text to its block, a function pointer's `->`
    inside the type read as two neutral characters."""
    out = []
    for lm in re.finditer(r"\blet\s+(?:mut\s+)?(\w+)\s*(?::[^=;]+)?=\s*\(?\s*(?:move\s+)?\|[^|]*\|", body):
        j = lm.end()
        rest = body[j:]
        stripped = rest.lstrip()
        off = len(rest) - len(stripped)
        if stripped.startswith("->"):
            k = j + off + 2
            depth = 0
            brace = -1
            while k < len(body):
                if body[k:k + 2] == "->":
                    k += 2
                    continue
                c = body[k]
                if c in "<([":
                    depth += 1
                elif c in ">)]":
                    depth -= 1
                elif c == "{" and depth == 0:
                    brace = k
                    break
                elif c == ";" and depth == 0:
                    break
                k += 1
            if brace < 0:
                continue
            out.append((lm.group(1), body[brace:_brace_match(body, brace)]))
        elif stripped.startswith("{"):
            brace = j + off
            out.append((lm.group(1), body[brace:_brace_match(body, brace)]))
        else:
            end = _statement_end(body, j)
            if end is None:
                continue
            out.append((lm.group(1), "{" + body[j:end] + "}"))
    return out

def _pattern_var_names(pat):
    """The plain variables an array pattern binds, one level
    (seam round 16, protest P3): each top-level element that
    is a plain binding (a `ref` / `mut` prefix aside, or a
    `name @` binding's name)."""
    pat = pat.strip()
    if not (pat.startswith("[") and pat.endswith("]")):
        return []
    out = []
    for seg in _split_top(pat[1:-1]):
        seg = seg.strip()
        if seg == "..":
            continue
        m = re.fullmatch(r"(?:ref\s+|mut\s+)?(\w+)(?:\s*@\s*.+)?", seg, re.S)
        if m:
            out.append(m.group(1))
    return out

def _payload_expr_hit(expr, rel):
    """The wrapper a return expression carries as the
    payload of the container it constructs, as (display,
    home), or None (seam round 20, protest P1): a wrapper
    path standing as the whole expression, as an element
    of a tuple the expression constructs, or as the
    argument of a container constructor — `Some`, `Ok`,
    `Err`, the positions whose value the container holds
    as its payload. A wrapper named inside an ordinary
    call's arguments is yielded INTO that call, not held
    as a payload, and does not count — the constructor
    heads are the variant-shaped ones, named by an
    uppercase segment that no production function
    definition spells."""
    expr = expr.strip()
    while expr.startswith("(") and _delim_match(expr, 0, "(", ")") == len(expr):
        inner = expr[1:-1]
        parts = _split_top(inner) if inner.strip() else []
        if len(parts) > 1:
            for p in parts:
                hit = _payload_expr_hit(p, rel)
                if hit is not None:
                    return hit
            return None
        if parts:
            expr = parts[0].strip()
            continue
        return None
    cm = re.match(r"^((?:\w+\s*::\s*)*)(\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\((.*)\)$", expr, re.S)
    if cm and _delim_match(expr, expr.index("("), "(", ")") == len(expr):
        last = cm.group(2)
        if last[:1].isupper() and last not in WRAPPERS_FREE:
            for p in _split_top(cm.group(3)):
                hit = _payload_expr_hit(p, rel)
                if hit is not None:
                    return hit
            return None
        return None
    return _yielded_wrapper(expr, rel)


def _call_payload_hit(call, rel):
    """The wrapper a call's result carries as payload, as
    (display, home), or None (seam round 20, protest P1):
    the callee — a free function or a method — whose
    return expressions carry a wrapper as the payload of
    the container they construct (see _payload_expr_hit),
    judged from the callee's own body, as the yield arms
    judge a callee's return yield."""
    call = call.strip()
    while call.startswith("(") and _delim_match(call, 0, "(", ")") == len(call):
        call = call[1:-1].strip()
    for (h, n) in _call_targets(call, rel):
        body = FN_BODIES.get((h, n))
        if body is not None:
            for e in _return_exprs(body):
                hit = _payload_expr_hit(e, h)
                if hit is not None:
                    return hit
    for (t, n) in _call_targets_meth(call, rel):
        ent = METH_BODIES.get((t, n))
        if ent is not None:
            for e in _return_exprs(ent[1]):
                hit = _payload_expr_hit(e, ent[0])
                if hit is not None:
                    return hit
    return None


def _bound_local_hit(body, init_start, init_text, rmap, rel):
    """The wrapper a local binding's initialiser denotes, as
    (display, home), or None (seam round 13, protest P5): a
    carried field's projection (the receiver's type read at
    the projection in the binding's own body), a
    wrapper-yielding call's result, or a wrapper path or
    wrapper value standing as the initialiser itself. Seam
    round 14 (protest P7): the projection is read through the
    grouping parentheses Rust permits around it, as the
    call-through arms already read through them. Seam round
    14 (protest P5): the projection is read through the
    container projections applied to the bound value before
    the binding — an `unwrap()` or a `?` on the field's own
    value denotes the field's value, so the candidate field
    is the text the projections project FROM. Seam round
    14's strip reads an `unwrap()` or a `?`; seam round 16
    (protest P3) reads a trailing index suffix (`[0]`,
    `[i]`) in the same strip — a bound local through an
    index denotes the field's element, and the candidate
    field is the text the index indexes into. Seam round
    18 (protest P4): the strip reads a trailing
    `expect(...)` as it reads `unwrap()` — the same
    container projection, which the direct-projection arm
    and the use-side payload step both already read, so
    the bound-local form of it denotes the field's value
    exactly as its direct form does."""
    init = init_text.strip()
    stripped_step = False
    base = init_start + (len(init_text) - len(init_text.lstrip()))
    while init.startswith("(") and _delim_match(init, 0, "(", ")") == len(init):
        inner = init[1:-1]
        base += 1 + (len(inner) - len(inner.lstrip()))
        init = inner.strip()
    proj = init
    while True:
        s = proj.rstrip()
        if s.endswith("?"):
            proj = s[:-1]
            stripped_step = True
            continue
        m2 = re.search(r"\.unwrap\s*\(\s*\)$", s)
        if m2:
            proj = s[:m2.start()]
            stripped_step = True
            continue
        if s.endswith(")"):
            depth, k = 1, len(s) - 2
            while k >= 0 and depth:
                if s[k] == ")":
                    depth += 1
                elif s[k] == "(":
                    depth -= 1
                k -= 1
            if depth == 0:
                head = s[:k + 1].rstrip()
                # The balanced-paren head check, generalised
                # past `.expect` (seam round 20, protests P1
                # and P4) and read at the payload ring's full
                # breadth (seam round 22, protests P1 and
                # P2): the strip reads every step of the
                # payload enumeration that can stand in
                # bound-local position — the round-20 list
                # and the ring round 22 reads beside it
                # (`ok_or`, `ok_or_else`, `or`, `or_else`,
                # `and`, `zip`, `map_err`, `flatten`, `take`,
                # `replace`, `get_or_insert` and `clone` on a
                # container) — each the enumeration's own
                # step, read here as the direct arms read it,
                # so the candidate is the text the steps
                # project FROM. The head check stands in the
                # sibling enumeration's fixed class: a
                # turbofish segment standing on the step's
                # head (`unwrap_or_else::<fn() -> ...>`) is
                # stripped before the name is read, as the
                # sibling arms strip it — the segment stands
                # after the candidate's own dot, so the
                # retained prefix's offsets do not move.
                shead = _strip_turbofish(head) if head.endswith(">") else head
                hm = re.search(r"\.(\w+)$", shead)
                if hm and hm.group(1) in ("expect", "unwrap_or", "unwrap_or_else", "unwrap_or_default", "ok", "ok_or", "ok_or_else", "as_ref", "as_mut", "copied", "cloned", "as_deref", "as_deref_mut", "transpose", "or", "or_else", "xor", "and", "zip", "err", "unwrap_err", "expect_err", "map_err", "flatten", "take", "replace", "get_or_insert", "get_or_insert_with", "get_or_insert_default", "insert", "clone", "as_slice", "as_mut_slice"):
                    proj = shead[:hm.start()]
                    stripped_step = True
                    continue
        if s.endswith("]"):
            depth, k = 1, len(s) - 2
            while k >= 0 and depth:
                if s[k] == "]":
                    depth += 1
                elif s[k] == "[":
                    depth -= 1
                k -= 1
            if depth == 0:
                proj = s[:k + 1]
                continue
        proj = s
        break
    if proj:
        idx = proj.rfind(".")
        if idx > 0:
            field = proj[idx + 1:].strip()
            if re.fullmatch(r"\w+", field or ""):
                rt = _expr_type_at(body, base + idx, rmap)
                if rt is not None:
                    for t in _deref_chain(rt):
                        if (t, field) in FIELD_WRAPPERS:
                            return FIELD_WRAPPERS[(t, field)]
    if stripped_step:
        # A payload step stood on the initialiser (seam
        # round 20, protest P1): the binding denotes the
        # receiver's payload, so the receiver expression is
        # judged for the wrapper its result carries AS
        # PAYLOAD — a callee whose return expressions place
        # a wrapper under a container constructor (`Some`,
        # `Ok`, `Err`) or in a tuple element carries it to
        # every step that opens the container.
        hit = _call_payload_hit(proj, rel)
        if hit is not None:
            return hit
    hit = _call_result_hit(init, rel)
    if hit is not None:
        return hit
    return _yielded_wrapper(init, rel)

def _macro_expr_arms(mbody):
    """A macro definition body's arms whose template is a
    single expression, as (pattern text, template text) (seam
    round 13, protest P9): an item template — one whose text
    opens with an item keyword — is not an expression arm and
    stands in the item arm's census, not this one; a template
    carrying a top-level statement separator is a block, not
    the single expression this arm reads."""
    body = mbody.strip()
    if body and body[0] in "{[(" and _delim_match(body, 0, body[0], {"{": "}", "[": "]", "(": ")"}[body[0]]) == len(body):
        body = body[1:-1]
    arms = []
    i = 0
    while True:
        j = body.find("=>", i)
        if j < 0:
            break
        pat = body[i:j].strip()
        k = j + 2
        while k < len(body) and body[k].isspace():
            k += 1
        if k >= len(body):
            break
        if body[k] in "{[(":
            end = _delim_match(body, k, body[k], {"{": "}", "[": "]", "(": ")"}[body[k]])
            template = body[k + 1:end - 1]
            i = end
        else:
            end = body.find(";", k)
            if end < 0:
                end = len(body)
            template = body[k:end]
            i = end
        template = template.strip()
        if template.endswith(";"):
            template = template[:-1].strip()
        if not template:
            continue
        _depth = 0
        _top_semi = False
        for _ch in template:
            if _ch in "([{":
                _depth += 1
            elif _ch in ")]}":
                _depth -= 1
            elif _ch == ";" and _depth == 0:
                _top_semi = True
                break
        if _top_semi:
            continue
        if re.match(r"^(pub\b|use\b|fn\b|struct\b|enum\b|union\b|trait\b|impl\b|mod\b|const\b|static\b|type\b|extern\b|#)", template):
            continue
        arms.append((pat, template))
        while i < len(body) and body[i] in "; \t\r\n":
            i += 1
    return arms

def _macro_expand_invocation(args_text, arms):
    """The expansion of an invocation with argument text
    `args_text` under `arms`, or None (seam round 13, protest
    P9): an arm matches when its pattern is the argument text
    itself (a literal or empty pattern), or a comma list of
    simple `$name` / `$name:kind` parameters, whose texts the
    invocation's top-level arguments supply in order;
    repetition patterns and token-tree patterns beyond that
    form are not read — the recorded limit."""
    for pat, template in arms:
        p = pat.strip()
        if p and p[0] in "{[(" and _delim_match(p, 0, p[0], {"{": "}", "[": "]", "(": ")"}[p[0]]) == len(p):
            p = p[1:-1].strip()
        if "$" not in p:
            if re.sub(r"\s+", "", p) == re.sub(r"\s+", "", args_text):
                return template
            continue
        params = []
        ok = True
        for part in _split_top_commas(p) if p else []:
            pm = re.fullmatch(r"\$(\w+)\s*(?::\s*\w+)?", part.strip())
            if not pm:
                ok = False
                break
            params.append(pm.group(1))
        if not ok or "$(" in template:
            continue
        args = [a.strip() for a in _split_top(args_text)] if args_text.strip() else []
        if len(args) != len(params):
            continue
        out = template
        for pname, aval in zip(params, args):
            out = re.sub(r"\$" + re.escape(pname) + r"\b", lambda _m, v=aval: v, out)
        if "$" in out:
            continue
        return out
    return None

def _expand_macro_exprs(codes, production_rels, sys_code):
    """Macro expansions read in expression position (seam
    round 13, protest P9): a production invocation of any
    production or `sys` macro whose matching arm's template
    is a single expression is replaced, in the derivation's
    own code texts, by that expression — parenthesised — so
    every derivation that judges an initialiser (const,
    static, field, return and binding positions alike) judges
    the expanded expression exactly as it judges the spelled
    one. The item arm's scoping (macros defined in `sys`, and
    `#[macro_export]` macros) does not bound this arm: it
    reads production macros generally."""
    defs = {}
    for mname, mbody in _macro_defs(sys_code):
        arms = _macro_expr_arms(mbody)
        if arms:
            defs.setdefault(mname, []).extend(arms)
    for rel in production_rels:
        for mname, mbody in _macro_defs(codes[rel]):
            arms = _macro_expr_arms(mbody)
            if arms:
                defs.setdefault(mname, []).extend(arms)
    if not defs:
        return
    for rel in production_rels:
        code = codes[rel]
        for _pass in range(3):
            changed = False
            for mname, arms in defs.items():
                pat = re.compile(r"((?:\w+\s*::\s*)*)" + re.escape(mname) + r"\s*!\s*")
                out = []
                last = 0
                for m in pat.finditer(code):
                    if code[max(0, m.start() - 12):m.start()].endswith("macro_rules"):
                        continue
                    j = m.end()
                    if j >= len(code) or code[j] not in "([{":
                        continue
                    end = _delim_match(code, j, code[j], {"(": ")", "[": "]", "{": "}"}[code[j]])
                    expansion = _macro_expand_invocation(code[j + 1:end - 1], arms)
                    if expansion is None:
                        continue
                    out.append(code[last:m.start()])
                    out.append("(" + expansion + ")")
                    last = end
                    changed = True
                if out:
                    out.append(code[last:])
                    code = "".join(out)
            codes[rel] = code
            if not changed:
                break

def _call_targets_meth(init, rel):
    """The production associated functions / methods an
    initialiser text calls, as (type identity, name) (seam
    round 12, protest P2): every call spelled `Type::name(...)`
    whose type the spelled path denotes and whose method the
    method tables carry — the associated spelling of the call
    the free derivation has always followed, the callee's body
    read from METH_BODIES. Seam round 13 (protest P1): the
    spelled type identity is resolved through production type
    aliases to its defining type first, so a call spelled on
    an alias is the call on the type the alias denotes."""
    out = []
    init = _strip_turbofish(init)
    for pm in re.finditer(r"((?:\w+\s*::\s*)*)(\w+)\s*(?:\(|::<)", init):
        segs = [s.strip() for s in pm.group(1).split("::") if s.strip()]
        last = pm.group(2)
        if segs:
            tident = _ident_of(segs[-1], segs[:-1])
            if tident is not None:
                tident = _expand_alias_ident(tident)
            if tident is not None and (tident, last) in METH_BODIES:
                out.append((tident, last))
    return out

def _meth_return_sys(tident, name, seen=frozenset()):
    """Whether the value a production associated function /
    method returns is derived from `sys` (seam round 12,
    protest P2): _fn_return_sys's judgement over the method
    tables — for a `const fn` there is no other channel: the
    value is evaluated at compile time from the callee's body
    alone."""
    if (tident, name) in seen:
        return False
    ent = METH_BODIES.get((tident, name))
    if ent is None:
        return False
    home, body = ent
    seen = seen | {(tident, name)}
    lets = {}
    for lm in re.finditer(r"\blet\s+(?:mut\s+)?(\w+)\s*(?::[^=;]+)?=\s*([^;]+);", body):
        lets[lm.group(1)] = lm.group(2)
    for e in _return_exprs(body):
        expr = e
        for _ in range(4):
            if not any(w in lets for w in re.findall(r"\b\w+\b", expr)):
                break
            expr = re.sub(r"\b(\w+)\b", lambda mm: lets.get(mm.group(1), mm.group(1)), expr)
        if _names_sys_item(expr):
            return True
        if any(n in SYS_DERIVED_VALUES for n in re.findall(r"\b\w+\b", expr)):
            return True
        for (h2, n2) in _call_targets(expr, home):
            if _fn_return_sys(h2, n2, seen):
                return True
        for (t2, n2) in _call_targets_meth(expr, home):
            if _meth_return_sys(t2, n2, seen):
                return True
    return False

def _closure_reached_wrapper(cb, rel):
    """The wrapper a closure body reaches, as (display, home),
    or None (seam round 12, protest P8): the free wrapper,
    wrapper value or wrapper method the body names — the
    wrapper's behaviour in an unnamed item, returned for the
    field-carriage record."""
    if WRAPPER_WORD_RE is not None:
        m = WRAPPER_WORD_RE.search(cb)
        if m:
            return (m.group(1), WRAPPERS_FREE[m.group(1)])
    for (t, n) in sorted(WRAPPERS_METH):
        if re.search(r"\b" + re.escape(_disp(t)) + r"::" + re.escape(n) + r"\b", cb):
            return (_disp(t) + "::" + n, WRAPPERS_METH[(t, n)])
    for n in sorted(WRAPPER_VALUES):
        if re.search(r"\b" + re.escape(n) + r"\b", cb):
            return (n + " (wrapper value)", WRAPPER_VALUES[n])
    return None

def _proj_ttext(expr, rel):
    """The declared type TEXT a projection expression
    denotes (seam round 18, protest P2): _proj_tident's
    resolution keeping the text, so a field read through
    the projection substitutes an instantiation's
    arguments for its defining type's parameters."""
    expr = expr.strip()
    while expr.startswith("(") and _delim_match(expr, 0, "(", ")") == len(expr):
        expr = expr[1:-1].strip()
    pm = re.fullmatch(r"(.+)\.(\w+)", expr, re.S)
    if pm:
        tt = _proj_ttext(pm.group(1), rel)
        if tt is not None:
            st = _substituted_field_text(tt, pm.group(2))
            if st is not None:
                return st
        base = _proj_tident(pm.group(1), rel)
        if base is not None:
            return _field_decl_text(base, pm.group(2))
        return None
    ftgts = _call_targets(expr, rel)
    if ftgts:
        return RETURN_FREE.get(ftgts[0][1])
    mtgts = _call_targets_meth(expr, rel)
    if mtgts:
        rt = _meth_return_text(mtgts[0][0], mtgts[0][1])
        return mtgts[0][0] if rt == "Self" else rt
    return None

def _proj_tident(expr, rel):
    """The type identity a projection expression denotes
    (seam round 16, protest P4): a call's declared return
    type, or a field projection's field type in its
    receiver's defining struct, composed stepwise — the
    head of a multi-step projection resolves through each
    field it projects, as the receiver machinery resolves
    a receiver chain."""
    expr = expr.strip()
    while expr.startswith("(") and _delim_match(expr, 0, "(", ")") == len(expr):
        expr = expr[1:-1].strip()
    pm = re.fullmatch(r"(.+)\.(\w+)", expr, re.S)
    if pm:
        tt = _proj_ttext(pm.group(1), rel)
        if tt is not None:
            sub = _field_type_through(tt, pm.group(2))
            if sub is not None:
                return sub
        base = _proj_tident(pm.group(1), rel)
        return _field_type(base, pm.group(2)) if base is not None else None
    ftgts = _call_targets(expr, rel)
    if ftgts:
        rt = RETURN_FREE.get(ftgts[0][1])
        return _det_id(rt, rel=rel) if rt is not None else None
    mtgts = _call_targets_meth(expr, rel)
    if mtgts:
        return _method_return(mtgts[0][0], mtgts[0][1])
    return None

def _invoked_closure_body(expr):
    """The body text of the closure literal `expr`
    immediately invokes, or None (seam round 16, protest
    P5): the closure parenthesised, the invocation's
    argument list and any value-preserving suffix chain
    (`.unwrap()`, `?`) standing after it, as in
    `(|| -> Result<...> { ... })().unwrap()` — the field
    judgement reads the invoked closure's body as it reads
    a plain closure initialiser's. A declared return type
    is read past, its `->`s read as neutral characters."""
    s = expr.strip()
    clos = None
    if s.startswith("("):
        end = _delim_match(s, 0, "(", ")")
        inner = s[1:end - 1].strip()
        rest = s[end:].strip()
        if (inner.startswith("|") or inner.startswith("move")) and rest.startswith("("):
            clos = inner
    if clos is None:
        return None
    m = re.match(r"^(?:move\s+)?\|[^|]*\|\s*(.*)$", clos, re.S)
    if not m:
        return None
    rem = m.group(1).strip()
    if rem.startswith("->"):
        depth = 0
        k = 2
        brace = -1
        while k < len(rem):
            if rem[k:k + 2] == "->":
                k += 2
                continue
            c = rem[k]
            if c in "<([":
                depth += 1
            elif c in ">)]":
                depth -= 1
            elif c == "{" and depth == 0:
                brace = k
                break
            k += 1
        if brace < 0:
            return None
        rem = rem[brace:]
    if rem.startswith("{"):
        end = _brace_match(rem, 0)
        return rem[1:end - 1]
    return rem

def _field_init_wrapper(expr, rel):
    """The wrapper a struct field's initialiser carries, as
    (display, home), or None (seam round 11, protest P4, as
    _yielded_wrapper; extended seam round 12, protest P8;
    seam round 13, protests P3/P4): a bare path denoting a
    wrapper; a closure whose body reaches a wrapper; or a
    call — a constructor call, `Box::new(...)` the ordinary
    form, or a method chain of calls — one of whose calls'
    arguments, anywhere in the chain, carries the wrapper in
    any of those forms, or whose RESULT is a wrapper a
    wrapper-yielding callee yields (free, method, or
    trait-default spelled `<Type as Trait>::name`), the field
    carrying what the argument or the result denotes, exactly
    as the initialiser-call arms follow a call to the value
    it yields in const position."""
    hit = _yielded_wrapper(expr, rel)
    if hit is not None:
        return hit
    expr = expr.strip()
    if expr.endswith("]"):
        # A wrapper value under an index suffix (seam round
        # 18, protest P6): a field initialised from an
        # element of a wrapper value — `VALUE[0]`, an
        # array-typed const's element the ordinary form —
        # carries the value's wrapper, the index step the
        # bound-local strip already reads (seam round 16,
        # protest P3); the candidate is the text the index
        # indexes into, judged as an initialiser itself.
        depth, k = 1, len(expr) - 2
        while k >= 0 and depth:
            if expr[k] == "]":
                depth += 1
            elif expr[k] == "[":
                depth -= 1
            k -= 1
        if depth == 0:
            hit = _field_init_wrapper(expr[:k + 1].strip(), rel)
            if hit is not None:
                return hit
    cb = _closure_body(expr)
    if cb is not None:
        return _closure_reached_wrapper(cb, rel)
    icb = _invoked_closure_body(expr)
    if icb is not None:
        # An immediately-invoked closure initialiser (seam
        # round 16, protest P5): the field is initialised by
        # the closure's returned value, so its body is
        # judged as a plain closure initialiser's body is,
        # and its return expressions as initialisers.
        hit = _closure_reached_wrapper(icb, rel)
        if hit is not None:
            return hit
        for e in _return_exprs("{" + icb + "}"):
            hit = _field_init_wrapper(e, rel)
            if hit is not None:
                return hit
        return None
    while expr.startswith("(") and _delim_match(expr, 0, "(", ")") == len(expr):
        expr = expr[1:-1].strip()
        hit = _yielded_wrapper(expr, rel)
        if hit is not None:
            return hit
        cb = _closure_body(expr)
        if cb is not None:
            return _closure_reached_wrapper(cb, rel)
    if expr.startswith("[") and _delim_match(expr, 0, "[", "]") == len(expr):
        parts = _split_top(expr[1:-1])
        if len(parts) == 1 and ";" in parts[0]:
            parts = [parts[0].split(";", 1)[0]]
        for part in parts:
            hit = _field_init_wrapper(part.strip(), rel)
            if hit is not None:
                return hit
    pm = re.fullmatch(r"(.+)\.(\w+)", expr, re.S)
    if pm:
        head, fld = pm.group(1).strip(), pm.group(2)
        # The head's type composed stepwise through the
        # projections it stands through (seam round 16,
        # protest P4), as a call head's return type was
        # composed before it.
        tident = _proj_tident(head, rel)
        if tident is not None and (tident, fld) in FIELD_WRAPPERS:
            return FIELD_WRAPPERS[(tident, fld)]
    i = 0
    seg_start = 0
    while i < len(expr):
        if expr[i] != "(":
            i += 1
            continue
        prev = expr[:i].rstrip()
        if not prev or not (prev[-1].isalnum() or prev[-1] in "_>)"):
            i += 1
            continue
        end = _delim_match(expr, i, "(", ")")
        segment = expr[seg_start:end]
        hit = _call_result_hit(segment, rel)
        if hit is not None:
            return hit
        inner = expr[i + 1:end - 1]
        for arg in _split_top(inner) if inner.strip() else []:
            hit = _field_init_wrapper(arg, rel)
            if hit is not None:
                return hit
        j = end
        while j < len(expr) and expr[j].isspace():
            j += 1
        if j < len(expr) and expr[j] == "?":
            j += 1
            while j < len(expr) and expr[j].isspace():
                j += 1
        if j < len(expr) and expr[j] == ".":
            seg_start = j + 1
            i = j + 1
            continue
        break
    return None

def _tuple_constructions(text):
    """Every tuple construction in `text` as (type text,
    [argument expressions]) (seam round 12, protest P3): a
    tuple struct's or tuple variant's construction is a call
    whose callee's last segment is a type name — capitalised,
    as function names never are — its arguments split at the
    top level. Seam round 18 (protest P1): a construction
    spelled with a turbofish head (`Type::<args>(...)`)
    is keyed by the head it stands on, as a struct
    literal's is."""
    out = []
    for m in re.finditer(r"((?:\w+\s*::\s*)*\w+|Self)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\(", text):
        ttext = re.sub(r"\s+", "", m.group(1))
        last = ttext.split("::")[-1]
        if ttext != "Self" and not last[:1].isupper():
            continue
        open_idx = m.end() - 1
        end = _delim_match(text, open_idx, "(", ")")
        inner = text[open_idx + 1:end - 1]
        args = [a.strip() for a in _split_top(inner)] if inner.strip() else []
        if args:
            out.append((ttext, args))
    return out

def _nested_pattern_vars(pat, tident, fkey):
    """The variables a pattern's NESTED subpatterns bind
    from the position (tident, fkey) (seam round 16,
    protest P4): a subpattern standing as a field's or a
    position's binding destructures the value that field
    or position holds, so a variable it binds from
    (tident, fkey) is carried from that position exactly
    as a one-level binding is — the recursion walks every
    nested struct or tuple subpattern, its own spelled
    type deciding which position it reads, and a struct
    subpattern standing inside a construction the keyed
    arms do not read is read on its own type."""
    out = []
    pat = pat.strip()
    pat = re.sub(r"^(?:ref\s+|mut\s+)+", "", pat)
    pat = re.sub(r"^&\s*(?:mut\s+)?", "", pat).strip()
    matched = False
    sm = re.match(r"^((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\{(.*)\}\s*(?::.*)?$", pat, re.S)
    if sm and not fkey.isdigit():
        matched = True
        segs = [s.strip() for s in sm.group(1).split("::")]
        ident = _ident_of(segs[-1], segs[:-1])
        if ident is None and len(segs) > 1:
            ident = _ident_of(segs[-2], segs[:-2])
        for seg in _split_top(sm.group(2)):
            seg = seg.strip()
            if not seg or seg == "..":
                continue
            fm = re.match(r"^(?:r#)?(\w+)\s*(?::\s*(.+))?$", seg, re.S)
            if not fm:
                continue
            field, bound = fm.group(1), fm.group(2)
            if bound is None:
                if ident == tident and field == fkey:
                    out.append(field)
                continue
            bound = bound.strip()
            vm = re.fullmatch(r"(?:ref\s+|mut\s+)?(\w+)", bound)
            if vm:
                if ident == tident and field == fkey:
                    out.append(vm.group(1))
                continue
            if "{" in bound or "(" in bound:
                out.extend(_nested_pattern_vars(bound, tident, fkey))
        return out
    tm = re.match(r"^((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\((.*)\)\s*(?::.*)?$", pat, re.S)
    if tm and fkey.isdigit():
        matched = True
        segs = [s.strip() for s in tm.group(1).split("::")]
        ident = _ident_of(segs[-1], segs[:-1])
        if ident is None and len(segs) > 1:
            ident = _ident_of(segs[-2], segs[:-2])
        subs = _split_top(tm.group(2))
        idx = int(fkey)
        if ident == tident and idx < len(subs):
            vm = re.fullmatch(r"(?:ref\s+|mut\s+)?(\w+)", subs[idx].strip())
            if vm:
                out.append(vm.group(1))
        for sub in subs:
            sub = sub.strip()
            if "{" in sub or "(" in sub:
                out.extend(_nested_pattern_vars(sub, tident, fkey))
        return out
    if not matched:
        for m in re.finditer(r"((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\{", pat):
            end = _brace_match(pat, m.end() - 1)
            # Only a strictly smaller substring recurses; a
            # pattern the keyed arms do not read in whole
            # (a struct pattern under a positional key) is
            # not its own subpattern.
            if end > m.start() and not (m.start() == 0 and end >= len(pat)):
                out.extend(_nested_pattern_vars(pat[m.start():end], tident, fkey))
    return out

def _pattern_carried_vars(body, tident, fkey, sig=None):
    """The variables `body`'s patterns bind from the position
    (tident, fkey) (seam round 12, protests P3/P4): a `let` /
    `if let` pattern or a `match` arm pattern destructuring a
    value of the type — a struct or variant pattern's named
    field `fkey` (the variable it binds, renamed or shorthand),
    or a tuple pattern's position `fkey` when `fkey` is a digit
    index. A call of such a variable is a call through the
    position's projection. Seam round 13 (protest P6):
    destructuring FUNCTION PARAMETERS — an item's parameter
    list, and closure parameter lists in the body — are
    pattern sites besides `let` and `match`: a parameter
    pattern destructures a value of its annotated type and
    binds each variable with its position's declared type,
    as a `let` pattern does."""
    pats = []
    for lm in re.finditer(r"\blet\s+(.+?)\s*=(?!=)", body, re.S):
        pats.append(lm.group(1))
    for fm in re.finditer(r"\bfor\s+(.+?)\s+in\s", body, re.S):
        pats.append(fm.group(1))
    for lm in re.finditer(r"\bmatch\s+", body):
        depth, brace = 0, -1
        j = lm.end()
        while j < len(body):
            c = body[j]
            if c in "(<[":
                depth += 1
            elif c in ")>]":
                depth -= 1
            elif c == "{" and depth == 0:
                brace = j
                break
            j += 1
        if brace < 0:
            continue
        bend = _brace_match(body, brace)
        block = body[brace + 1:bend - 1]
        i = 0
        while True:
            j = block.find("=>", i)
            if j < 0:
                break
            seg = block[i:j]
            depth, start = 0, 0
            for k, ch in enumerate(seg):
                if ch in "(<[{":
                    depth += 1
                elif ch in ")>]}":
                    depth -= 1
                elif ch == "," and depth == 0:
                    start = k + 1
            _pat26 = seg[start:]
            _gd26, _gcut26 = 0, -1
            for _gk26, _gc26 in enumerate(_pat26):
                if _gc26 in "(<[{":
                    _gd26 += 1
                elif _gc26 in ")>]}":
                    _gd26 -= 1
                elif _gd26 == 0 and _pat26.startswith(" if ", _gk26):
                    _gcut26 = _gk26
                    break
            if _gcut26 >= 0:
                _pat26 = _pat26[:_gcut26]
            pats.append(_pat26)
            i = j + 2
    if sig:
        pi = sig.find("(")
        if pi >= 0:
            pend = _delim_match(sig, pi, "(", ")")
            for part in _split_top(sig[pi + 1:pend - 1]):
                depth, sep = 0, -1
                for k, ch in enumerate(part):
                    if ch in "(<[{":
                        depth += 1
                    elif ch in ")>]}":
                        depth -= 1
                    elif ch == ":" and depth == 0 and part[k - 1] != ":" and part[k + 1:k + 2] != ":":
                        sep = k
                        break
                if sep >= 0:
                    pat = part[:sep].strip()
                    if "{" in pat or "(" in pat:
                        pats.append(pat)
    for cm in re.finditer(r"\|([^|]*)\|", body):
        seg = cm.group(1)
        if "{" not in seg and "(" not in seg:
            continue
        for part in _split_top(seg):
            pat = part.strip()
            depth, sep = 0, -1
            for k, ch in enumerate(part):
                if ch in "(<[{":
                    depth += 1
                elif ch in ")>]}":
                    depth -= 1
                elif ch == ":" and depth == 0 and part[k - 1] != ":" and part[k + 1:k + 2] != ":":
                    sep = k
                    break
            if sep >= 0:
                pat = part[:sep].strip()
            if "{" in pat or "(" in pat:
                pats.append(pat)
    out = []
    for pat in pats:
        pat = pat.strip()
        pat = re.sub(r"^&\s*(?:mut\s+)?", "", pat).strip()
        sm = re.match(r"^((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\{(.*)\}\s*(?::.*)?$", pat, re.S)
        if sm and not fkey.isdigit():
            segs = [s.strip() for s in sm.group(1).split("::")]
            ident = _ident_of(segs[-1], segs[:-1])
            if ident is None and len(segs) > 1:
                ident = _ident_of(segs[-2], segs[:-2])
            if ident != tident:
                out.extend(_nested_pattern_vars(pat, tident, fkey))
                continue
            for seg in _split_top(sm.group(2)):
                fm = re.match(r"^(?:r#)?(\w+)\s*(?::\s*(?:ref\s+|mut\s+)?(\w+)\s*)?$", seg.strip(), re.S)
                if fm and fm.group(1) == fkey:
                    out.append(fm.group(2) or fm.group(1))
                else:
                    fm2 = re.match(r"^(?:r#)?(\w+)\s*:\s*(.+)$", seg.strip(), re.S)
                    if fm2 and ("{" in fm2.group(2) or "(" in fm2.group(2)):
                        out.extend(_nested_pattern_vars(fm2.group(2), tident, fkey))
            continue
        tm = re.match(r"^((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\((.*)\)\s*(?::.*)?$", pat, re.S)
        if tm and fkey.isdigit():
            segs = [s.strip() for s in tm.group(1).split("::")]
            ident = _ident_of(segs[-1], segs[:-1])
            if ident is None and len(segs) > 1:
                ident = _ident_of(segs[-2], segs[:-2])
            if ident != tident:
                out.extend(_nested_pattern_vars(pat, tident, fkey))
                continue
            subs = _split_top(tm.group(2))
            idx = int(fkey)
            if idx < len(subs):
                vm = re.fullmatch(r"(?:ref\s+|mut\s+)?(\w+)", subs[idx].strip())
                if vm:
                    out.append(vm.group(1))
        out.extend(_nested_pattern_vars(pat, tident, fkey))
    return out

def _inject_macro_expansions(codes, production_rels, sys_code):
    """Macro expansions read as items of the invocation site
    (seam round 12, protest P6): a production invocation of a
    macro whose expansion contains item definitions makes
    those items derivation inputs of the invoking file, in its
    module scope — the expansion's `use` bindings join the
    invoking file's binding table at the invocation's scope,
    and its free function definitions join the function tables
    at the invoking file. The census of macros read this way
    is the charged minimum: macros defined in `sys`, and
    `#[macro_export]` macros wherever they are defined."""
    defs = {}
    for mname, mbody in _macro_defs(sys_code):
        defs.setdefault(mname, mbody)
    for rel in production_rels:
        code = codes[rel]
        for m in re.finditer(r"\bmacro_rules!\s*(\w+)", code):
            if "#[macro_export]" in code[max(0, m.start() - 200):m.start()]:
                for n2, b2 in _macro_defs(code):
                    if n2 == m.group(1):
                        defs.setdefault(n2, b2)
    if not defs:
        return
    for rel in production_rels:
        code = codes[rel]
        spans = _scope_spans(code)
        for mname, mbody in defs.items():
            for im in re.finditer(r"(?:\w+\s*::\s*)*" + re.escape(mname) + r"\s*!", code):
                if code[max(0, im.start() - 12):im.start()].endswith("macro_rules"):
                    continue
                scope = _scope_key_of(spans, im.start())
                for um in re.finditer(r"\b(pub(?:\([^)]*\))?\s+)?use\s+([^;]+);", mbody):
                    is_pub = um.group(1) is not None
                    for local, segs, glob in _expand_use(um.group(2)):
                        entry = (local, scope, segs, is_pub)
                        if entry not in FILE_BINDINGS_RAW.get(rel, []):
                            FILE_BINDINGS_RAW.setdefault(rel, []).append(entry)
                for name, tname, sig, body, _off in typed_items(mbody):
                    if tname is None:
                        FREE_FN_DEFS.add((rel, name))
                        FN_BODIES.setdefault((rel, name), body)

def _pattern_bound_field(pat, varname):
    """The field or position a destructuring pattern binds
    `varname` from, or None (seam round 14, protest P2): a
    struct pattern's named field — the binding spelled
    `field` or `field: varname` — or a tuple pattern's
    position index, as a string. Seam round 16 (protest
    P4): the search recurses into nested subpatterns — a
    variable bound inside a nested struct or tuple
    subpattern binds from the projection path through
    every level that contains it, returned as the dotted
    path (the field or position at each level, outermost
    first) the shorthand initialiser denotes."""
    pat = pat.strip()
    pat = re.sub(r"^(?:ref\s+|mut\s+)+", "", pat)
    bi = pat.find("{")
    if bi >= 0:
        end = _brace_match(pat, bi)
        for seg in _split_top(pat[bi + 1:end - 1]):
            seg = seg.strip()
            if not seg or seg == "..":
                continue
            fm = re.match(r"^(?:r#)?(\w+)\s*(?::\s*(.+))?$", seg, re.S)
            if not fm:
                continue
            field, bound = fm.group(1), fm.group(2)
            if bound is None:
                if field == varname:
                    return field
            else:
                bound = bound.strip()
                bm = re.fullmatch(r"(?:ref\s+|mut\s+)?(\w+)", bound)
                if bm and bm.group(1) == varname:
                    return field
                if "{" in bound or "(" in bound:
                    sub = _pattern_bound_field(bound, varname)
                    if sub is not None:
                        return field + "." + sub
        return None
    pi = pat.find("(")
    if pi >= 0:
        end = _delim_match(pat, pi, "(", ")")
        for idx, seg in enumerate(_split_top(pat[pi + 1:end - 1])):
            seg = seg.strip()
            bm = re.fullmatch(r"(?:ref\s+|mut\s+)?(\w+)", seg)
            if bm and bm.group(1) == varname:
                return str(idx)
            if "{" in seg or "(" in seg:
                sub = _pattern_bound_field(seg, varname)
                if sub is not None:
                    return str(idx) + "." + sub
    return None

def _struct_literals(text):
    """Every struct literal in `text` as (type text, [(field
    name, initialiser expression)]) (seam round 11, protest
    P4): a `Type { field: expr, ... }` construction, its
    fields split at the top level; the `..rest` tail carries
    no initialiser and is not returned. Seam round 13
    (protest P2): a shorthand field IS returned, with the
    initialiser it denotes — the last `let` binding of the
    same name standing before the literal in the same text,
    judged by its own initialiser; with no such binding the
    shorthand name itself stands as the initialiser text, so
    a wrapper path of that name still judges. Seam round
    18 (protest P1): a literal spelled with a turbofish
    head (`Type::<args> { ... }`) is the same construction
    — the turbofish segment is read, and the carriage key
    is the head it stands on, as the tuple-construction
    arm reads its head."""
    out = []
    for m in re.finditer(r"((?:\w+\s*::\s*)*\w+|Self)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\{", text):
        brace = m.end() - 1
        end = _brace_match(text, brace)
        fields = []
        for part in _split_top(text[brace + 1:end - 1]):
            fm = re.match(r"^\s*(\w+)\s*:\s*(.+)$", part, re.S)
            if fm:
                fields.append((fm.group(1), fm.group(2).strip()))
                continue
            sm = re.match(r"^\s*(?:ref\s+|mut\s+)?(\w+)\s*$", part, re.S)
            if sm:
                fname = sm.group(1)
                init = fname
                best = -1
                for lm in re.finditer(r"\blet\s+(?:mut\s+)?" + re.escape(fname) + r"\b\s*(?::[^=;]+)?=\s*([^;]+);", text[:brace]):
                    if lm.start() >= best:
                        best = lm.start()
                        init = lm.group(1).strip()
                for lm in re.finditer(r"\blet\s+(.+?)\s*=\s*([^;]+);", text[:brace], re.S):
                    fld = _pattern_bound_field(lm.group(1), fname)
                    if fld is not None and lm.start() >= best:
                        best = lm.start()
                        init = "(" + lm.group(2).strip() + ")." + fld
                fields.append((fname, init))
        if fields:
            out.append((re.sub(r"\s+", "", m.group(1)), fields))
    return out

def _call_targets(init, rel):
    """The production free functions an initialiser text calls,
    as (defining file, name) (seam round 11, protest P6): every
    call-shaped path, resolved through the re-export chase when
    spelled as a path, or to its single production definition
    when spelled bare — the defining file's own definition
    first, as a same-file call is spelled."""
    out = []
    init = _strip_turbofish(init)
    for pm in re.finditer(r"((?:\w+\s*::\s*)*)(\w+)\s*(?:\(|::<)", init):
        segs = [s.strip() for s in pm.group(1).split("::") if s.strip()]
        last = pm.group(2)
        if segs:
            desc = _resolve_item(rel, segs + [last])
            if desc is not None and desc[0] == "free":
                out.append((desc[2], desc[1]))
        elif (rel, last) in FREE_FN_DEFS:
            out.append((rel, last))
        else:
            homes = [r for (r, n) in FREE_FN_DEFS if n == last]
            if len(homes) == 1:
                out.append((homes[0], last))
    return out

def _fn_return_sys(home, name, seen=frozenset()):
    """Whether the value a production free function returns is
    derived from `sys` (seam round 11, protest P6): its return
    expressions — with `let` bindings expanded through their
    initialisers — name a sys item or a sys-derived value, or
    call a function whose returned value is itself so derived.
    For a `const fn` there is no other channel: the value is
    evaluated at compile time from the callee's body alone."""
    if (home, name) in seen:
        return False
    body = FN_BODIES.get((home, name))
    if body is None:
        return False
    seen = seen | {(home, name)}
    lets = {}
    for lm in re.finditer(r"\blet\s+(?:mut\s+)?(\w+)\s*(?::[^=;]+)?=\s*([^;]+);", body):
        lets[lm.group(1)] = lm.group(2)
    for e in _return_exprs(body):
        expr = e
        for _ in range(4):
            if not any(w in lets for w in re.findall(r"\b\w+\b", expr)):
                break
            expr = re.sub(r"\b(\w+)\b", lambda mm: lets.get(mm.group(1), mm.group(1)), expr)
        if _names_sys_item(expr):
            return True
        if any(n in SYS_DERIVED_VALUES for n in re.findall(r"\b\w+\b", expr)):
            return True
        for (h2, n2) in _call_targets(expr, home):
            if _fn_return_sys(h2, n2, seen):
                return True
        for (t2, n2) in _call_targets_meth(expr, home):
            if _meth_return_sys(t2, n2, seen):
                return True
    return False

def _call_derives_sys(init, rel):
    """Whether an initialiser's value derives from `sys`
    through a call in initialiser position (seam round 11,
    protest P6): a call yields the callee's return value, and
    that value's derivation is the callee's own."""
    if any(_fn_return_sys(h, n) for (h, n) in _call_targets(init, rel)):
        return True
    return any(_meth_return_sys(t, n) for (t, n) in _call_targets_meth(init, rel))

def _call_yields_wrapper(init, rel):
    """Whether an initialiser's value is a wrapper through a
    call in initialiser position (seam round 11, protest P6):
    the callee is itself wrapper-yielding, or its return
    expressions yield a wrapper."""
    for (h, n) in _call_targets(init, rel):
        if n in WRAPPER_YIELD_FREE:
            return True
        body = FN_BODIES.get((h, n))
        if body is not None and any(_expr_yields_wrapper(e, h) for e in _return_exprs(body)):
            return True
    for (t, n) in _call_targets_meth(init, rel):
        if (t, n) in WRAPPER_YIELD_METH:
            return True
        ent = METH_BODIES.get((t, n))
        if ent is not None and any(_expr_yields_wrapper(e, ent[0]) for e in _return_exprs(ent[1])):
            return True
    return False

def _binding_stands_at(rel, scope, modpath):
    """Whether the `use` binding declared in file `rel` in
    scope `scope` stands at module path `modpath` (seam round
    11, protests P1/P10): a binding declared inside an inline
    module stands at that module's path alone — the module
    map is built from declarations, so the home file's other
    bindings do not leak into the inline module and the
    inline module's do not leak out into the file's own
    module. Any other binding stands where it always stood:
    at its file's own module path, or at the declared path
    its `mod` declaration places its file at."""
    mp = SCOPE_MODPATH.get((rel, scope))
    if mp is not None:
        return mp == modpath
    return modpath == FILE_MODULES.get(rel) or modpath == FILE_DECLARED_PATHS.get(rel)

def _fill_sys_kinds(sys_code):
    """The kind of every name `sys` declares, from its own
    declarations (seam round 11, protest P8): types (structs,
    enums, unions, aliases, extern types), values (consts,
    statics, extern statics) and functions (owned functions
    and extern functions) — the kinds a re-export binding
    inherits from its target."""
    SYS_KINDS.clear()
    for m in re.finditer(r"\bpub\s+(?:struct|enum|union|type)\s+(\w+)", sys_code):
        SYS_KINDS[m.group(1)] = "type"
    for m in re.finditer(r"\bpub\s+(?:const|static)\s+(?:mut\s+)?(\w+)", sys_code):
        SYS_KINDS.setdefault(m.group(1), "value")
    for m in re.finditer(r"\bpub\s+(?:const\s+)?fn\s+(\w+)", sys_code):
        SYS_KINDS.setdefault(m.group(1), "fn")
    for block in extern_block_bodies(sys_code):
        for fm in re.finditer(r"\bfn\s+(\w+)\s*\(", block):
            SYS_KINDS.setdefault(fm.group(1), "fn")
        for fm in re.finditer(r"\bstatic\s+(?:mut\s+)?(\w+)\s*:", block):
            SYS_KINDS.setdefault(fm.group(1), "value")
        for fm in re.finditer(r"\btype\s+(\w+)\s*;", block):
            SYS_KINDS.setdefault(fm.group(1), "type")

def _binding_sys_kind(rel, segs):
    """The sys kind a `use` binding's target carries, or None
    (seam round 11, protest P8): the target resolves into
    `sys` itself, its kind read from sys's declarations, or
    it resolves to a name already derived from `sys`, whose
    kind it inherits."""
    if not segs:
        return None
    if _resolve_modpath(rel, segs[:-1]) == "sys":
        return SYS_KINDS.get(segs[-1])
    desc = _resolve_item(rel, segs)
    if desc is None:
        return None
    if desc[0] == "type" and desc[1] in SYS_DERIVED_TYPES:
        return "type"
    if desc[0] == "value" and desc[1] in SYS_DERIVED_VALUES:
        return "value"
    if desc[0] == "free" and desc[1] in SYS_DERIVED_FNS:
        return "fn"
    return None

def _names_sys_item(text):
    """Whether `text` names a `sys`-declared item (seam round
    10, protest P1): it spells a `sys::` path, or it names
    whole-word an extended-mint name that no production
    definition carries — `sys`'s own items have no production
    home, so a mint name standing in no production table can
    only be `sys`'s. The recorded exclusions are not sys
    items for this derivation either."""
    if re.search(r"\bsys\s*::", text):
        return True
    free_names = {n for _r, n in FREE_FN_DEFS}
    for m in re.finditer(r"\b\w+\b", text):
        n = m.group(0)
        if n in SYS_MINT_NAMES and n not in EXCLUSIONS and n not in TYPE_LOCS and n not in free_names and n not in WRAPPER_VALUES:
            return True
    return False

def _return_exprs(body):
    """The return expressions of an item body (seam round 10,
    protest P8): every `return <expr>;` expression and the
    body's tail expression — the final top-level segment when
    the body does not end it with a semicolon — a brace-block
    tail recursed into once per level."""
    inner = body[1:-1] if body.startswith("{") and body.endswith("}") else body
    exprs = [m.group(1).strip() for m in re.finditer(r"\breturn\s+([^;]+);", inner)]
    parts, depth, cur = [], 0, ""
    for ch in inner:
        if ch in "(<[{":
            depth += 1
        elif ch in ")>]}":
            depth -= 1
        if ch == ";" and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    tail = cur.strip()
    if tail.startswith("{") and tail.endswith("}"):
        exprs.extend(_return_exprs(tail))
    elif tail and not tail.startswith(("let ", "fn ", "impl ", "mod ", "use ", "struct ", "enum ", "trait ")):
        exprs.append(tail)
    return exprs

def _expr_yields_wrapper(expr, rel):
    """Whether return expression `expr`, in file `rel`, yields
    a wrapper AS ITS OWN VALUE (seam round 10, protest P8):
    the wrapper path stands as the expression itself, as an
    element of the tuple/array the expression constructs, or
    under a reference or a cast — the positions whose value
    the return carries out. A wrapper named inside the
    expression's own calls — passed as a function argument,
    consumed by a callee — is yielded INTO that call, not out
    of the function, and does not count. The path itself is
    judged as the wrapper-value derivation judges it (seam
    round 9, protest P6): a free wrapper, a wrapper value,
    another wrapper-yielding function, or a wrapper method's
    path, named bare or resolved through the re-export
    chase, and never in call shape."""
    expr = expr.strip()
    while expr.startswith("&"):
        expr = re.sub(r"^&\s*(?:mut\s+)?", "", expr).strip()
    cm = re.match(r"^(.*\S)\s+as\s+(?:\w+\s*::\s*)*\w+(?:\s*<[^;]*>)?$", expr, re.S)
    if cm:
        expr = cm.group(1).strip()
    if (expr.startswith("(") and expr.endswith(")")) or (expr.startswith("[") and expr.endswith("]")):
        inner = expr[1:-1]
        parts = _split_top(inner) if inner.strip() else []
        if len(parts) > 1 or expr.startswith("["):
            return any(_expr_yields_wrapper(p, rel) for p in parts)
        if parts:
            return _expr_yields_wrapper(parts[0], rel)
        return False
    # A turbofish segment standing on the path's head is
    # stripped before the fullmatch, as the sibling
    # _yielded_wrapper strips it (seam round 20, protest
    # P6): the spelled path `Type::<args>::name` denotes
    # the same wrapper method as the plain spelling.
    expr = _strip_turbofish(expr)
    m = re.fullmatch(r"((?:\w+\s*::\s*)*)(\w+)", expr)
    if not m:
        return False
    segs = [s.strip() for s in m.group(1).split("::") if s.strip()]
    last = m.group(2)
    if segs:
        tident = _ident_of(segs[-1], segs[:-1])
        if tident is not None and (tident, last) in WRAPPERS_METH:
            return True
        if tident is not None and (tident, last) in WRAPPER_YIELD_METH:
            return True
        desc = _resolve_item(rel, segs + [last])
        if desc is not None and desc[0] == "free" and (desc[1] in WRAPPERS_FREE or desc[1] in WRAPPER_YIELD_FREE):
            return True
        if desc is not None and desc[0] == "value" and desc[1] in WRAPPER_VALUES:
            return True
        return False
    return last in WRAPPERS_FREE or last in WRAPPER_VALUES or last in WRAPPER_YIELD_FREE


def _deref_chain(t):
    """`t` and the types its Deref steps reach, in resolution
    order (seam round 7, protest P4): the in-tree Deref and
    DerefMut targets computed in DEREF_TARGETS. A std
    smart-pointer head's target is its generic argument, which
    the identity tables do not carry, so at the identity level
    the chain stops there — the text-level step in
    _det_id_deref is where those heads resolve."""
    out = [t]
    cur = t
    while cur in DEREF_TARGETS:
        nxt = DEREF_TARGETS[cur]
        if nxt is None or nxt in out:
            break
        out.append(nxt)
        cur = nxt
    return out

def _det_id_deref(ttext, rel=None):
    """_det_id, plus the std Deref heads (seam round 7, protest
    P4): a type text `Head<...>` whose head is a recorded std
    Deref head denotes, for receiver resolution, its first
    generic argument's identity — `Box<Owners>` derefs to
    Owners, as the language resolves the receiver call."""
    ident = _det_id(ttext, expand=True, rel=rel)
    if ident is not None:
        return ident
    if ttext is None:
        return None
    t = re.sub(r"\s+", " ", ttext.strip())
    t = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", t).strip()
    m = re.match(r"^(?:\w+\s*::\s*)*(\w+)\s*<", t)
    if m and m.group(1) in STD_DEREF_HEADS:
        arg = _generic_arg(t, 0)
        if arg is not None:
            # The reading composes (seam round 28, protest
            # P5): a carrier over a carrier denotes the
            # payload at two derefs — the recursion walks
            # the chain the construction nests, as the
            # text arms already walk an annotated binding's
            # chain, instead of stopping one carrier deep
            # at a text no identity names.
            return _det_id_deref(arg, rel=rel)
    return None

def _iter_text(ttext, name):
    """The iterator type text `iter` / `iter_mut` / `into_iter`
    returns on a Result/Option type text (seam round 25,
    protest P2): the container's payload under the synthetic
    iterator head `__Iter` — by reference for `iter`, by
    mutable reference for `iter_mut`, by value for
    `into_iter`; a Result's iterator holds its success
    payload only, as those steps declare. The head is a
    synthetic the crate cannot spell, so no crate type
    collides with it, and the arms that read an iterator
    read it by that head."""
    parts = _result_option_parts(ttext)
    if not parts or not parts[1]:
        # A generic container's iterator (seam round 27,
        # protests P3/P5): the element stands at the head's
        # first argument, the element the `for` arm reads a
        # generic head at — `Vec<Option<T>>`'s `into_iter`
        # holds `Option<T>` as `Option<T>`'s `into_iter`
        # holds `T`.
        _elem27 = _iter_element_text(ttext)
        if _elem27 is None:
            return None
        payload = _elem27
        # A reference standing as the receiver (seam
        # round 30, protest P1): a reference to a container
        # is a chain's base at its target — `&[T]`'s and
        # `&Vec<T>`'s iterators, by `iter` and by
        # `into_iter` alike, yield the reference the
        # receiver spells over the element, never the
        # element by value.
        _ref30 = re.match(r"^\s*&\s*(?:'\w+\s+)?(mut\s+)?", ttext)
        if _ref30:
            if name == "iter_mut":
                return "__Iter<&mut " + _elem27 + ">"
            return "__Iter<" + ("&mut " if _ref30.group(1) else "&") + _elem27 + ">"
    else:
        payload = parts[1][0]
    if name == "iter":
        elem = "&" + payload
    elif name == "iter_mut":
        elem = "&mut " + payload
    else:
        elem = payload
    return "__Iter<" + elem + ">"


def _iter_elem_of(ttext):
    """The element type text of a synthetic iterator text, or
    None (seam round 25, protest P2)."""
    if ttext is None:
        return None
    t = re.sub(r"\s+", " ", ttext.strip())
    t = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", t).strip()
    if t.startswith("__Iter<") and t.endswith(">"):
        return _generic_arg(t, 0)
    return None


def _iter_step_text(ttext, name):
    """The type text an iterator step returns on a synthetic
    iterator text (seam round 25, protest P2): `next` hands
    the element out under `Option`, the payload step the
    iterator exists to perform; `copied` / `cloned` return
    the iterator over the element values, one reference
    stripped, as they do on a container; the remaining
    element-preserving adapters of the consumer arm's strip
    return the iterator itself."""
    elem = _iter_elem_of(ttext)
    if elem is None:
        return None
    if name == "next":
        return "Option<" + elem + ">"
    if name in ("last", "nth", "max", "min"):
        # The element-returning terminals (seam round 27,
        # protest P5's census): each hands the element out
        # under `Option` as `next` does, at the position its
        # own signature states.
        return "Option<" + elem + ">"
    if name in ("find", "reduce", "max_by", "min_by", "max_by_key", "min_by_key"):
        # The dual members (seam round 28, protest P1):
        # each stands in the consumer census for the
        # closure it hands the element to, and each ALSO
        # returns the element under `Option` — an
        # element-returning terminal at the same position,
        # read at the element as `next` is, so a chain
        # standing on the step's result is typed.
        return "Option<" + elem + ">"
    if name == "find_map":
        # `find_map` (seam round 29, protest P1): the step
        # returns the `Option` its closure returns — at
        # this level, where the closure stands out of view,
        # the `Option` over the element itself, as `find`
        # stands; the call-level arm
        # (_find_map_call_text) refines it from the closure
        # standing at the call.
        return "Option<" + elem + ">"
    if name in ("copied", "cloned"):
        unref = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", elem.strip()).strip()
        return "__Iter<" + unref + ">"
    # The transforming adapters (seam round 26, protest P2):
    # `enumerate` yields the pair of the index and the element
    # itself, at the pair's second position; `zip` yields the
    # pair of this element and the argument iterator's, which
    # this level cannot name and which stands as `()` here,
    # the call-level arm naming it where the argument stands;
    # `map` / `filter_map` / `flat_map` / `map_while` yield
    # what their closures determine, which this level cannot
    # see, so the iterator stands as its own record here and
    # the call-level arm (_iter_adapter_return_text) refines
    # it from the closure standing at the call; the
    # element-preserving `take_while` / `skip_while` / `chain`
    # return the iterator itself, as the strip's adapters do.
    if name == "enumerate":
        return "__Iter<(usize, " + elem + ")>"
    if name == "zip":
        return "__Iter<(" + elem + ", ())>"
    if name in ("map", "filter_map", "flat_map", "map_while", "take_while", "skip_while", "chain", "scan", "flatten"):
        return ttext
    if name in ITER_ADAPTERS:
        return ttext
    return None


def _payload_text_through_deref(ttext):
    """The payload type text of a Result/Option text, read
    through the receiver's recorded Deref chain where the
    receiver's own text is no container (seam round 25,
    protest P3): the chain the return-type arms already
    walk, walked for the payload step — a receiver whose
    Deref target is a container has its payload read at the
    target's breadth."""
    payload = _payload_text(ttext)
    if payload is not None:
        return payload
    ident = _det_id(ttext)
    if ident is None:
        return None
    for tt in _deref_chain(ident):
        payload = _payload_text(tt)
        if payload is not None:
            return payload
    return None


def _trait_default_return36(t, name):
    """The declared return text of a trait method's DEFAULT
    body as it types a receiver call on `t` (seam round 36,
    protest P5): where the receiver type's own impl of a
    trait leaves the method in place — no override recorded
    for (type, trait, method) — the call stands at the
    trait's declared return, the round-33 declared-return
    road (TRAIT_METH_RETURN33) read at the projection as at
    the chain arms; where an override stands, the
    override's own declared return answers in RETURN_METH
    first, in both directions. None where no implemented
    trait declares such a default."""
    _tm33 = globals().get("TRAIT_METH_RETURN33") or {}
    _ti36 = globals().get("TRAIT_IMPLS") or {}
    _ov36 = globals().get("TRAIT_OVERRIDES") or {}
    if not isinstance(t, str):
        return None
    _bare36 = _disp(t)
    # The traits standing for the receiver (seam round
    # 37, protests P6/P7): its direct impls, and the
    # traits a blanket impl supplies to it — a blanket
    # impl whose bound the receiver satisfies, keyed by
    # the impl's trait exactly as the chain arms key it
    # (the bound closed under the receiver's own traits
    # by _effective_traits; a bound with no recorded
    # requirement vacuously satisfied, as
    # _blanket_satisfied reads it).
    _trs37 = set(_ti36.get(_bare36, ()))
    _bb37 = globals().get("BLANKET_BOUNDS") or {}
    if _bb37:
        _eff37 = globals().get("_effective_traits")
        _et37 = _eff37(set(_trs37)) if _eff37 is not None else set(_trs37)
        for _bt37, _bounds37 in _bb37.items():
            if not _bounds37 or _bounds37 <= _et37:
                _trs37.add(_bt37)
    _cands37 = [_tr36 for _tr36 in sorted(_trs37) if (_tr36, name) in _tm33 and (_bare36, _tr36, name) not in _ov36]
    if not _cands37:
        return None
    if len(_cands37) == 1:
        return _tm33[(_cands37[0], name)]
    # More than one trait supplies the default: the
    # trait IN SCOPE AT THE CALL decides (seam round
    # 37, protest P6) — the calling file's own imports
    # and trait definitions — and sorted order never
    # decides; where the supplying trait cannot be
    # assigned to one, the computation refuses by name.
    _rel37 = _std_ctx_rel()
    _inscope37 = set()
    _glob37 = False
    for _local37, _scope37, _segs37, _pub37 in (globals().get("FILE_BINDINGS_RAW") or {}).get(_rel37, []):
        if _segs37 and _segs37[-1] == "*":
            _glob37 = True
        elif _segs37:
            _inscope37.add(_segs37[-1])
    _code37 = (globals().get("CODE_BY_REL35") or {}).get(_rel37) if _rel37 else None
    if _code37:
        _inscope37.update(m.group(1) for m in re.finditer(r"\btrait\s+(\w+)", _code37))
    _sel37 = [_tr36 for _tr36 in _cands37 if _tr36 in _inscope37] if not _glob37 else []
    if len(_sel37) == 1:
        return _tm33[(_sel37[0], name)]
    _msg37 = ("trait default undecidable: the call to `" + str(name) + "` on `" + str(_bare36) + "` in " + str(_rel37 or "the file being resolved")
              + " is supplied a default by more than one trait standing for the receiver (" + ", ".join("`" + _tr36 + "`" for _tr36 in _cands37)
              + "), and the trait in scope at the call cannot be assigned to one of them; the computation refuses by name rather than let sorted order decide (seam round 37, protest P6)")
    _cf37 = globals().get("CHASE_FAILURES")
    if _cf37 is not None and _msg37 not in _cf37:
        _cf37.append(_msg37)
    return None


def _meth_return_text(t, name):
    """The declared return type text of method `name` on `t`,
    resolved through `t`'s Deref chain when `t` itself does not
    declare it (seam round 7, protest P4). Seam round 16
    (protest P1): on a determinable Result/Option receiver
    text, `unwrap` / `expect` return the payload text,
    `as_ref` / `as_mut` the reference-wrapped head and
    `ok` the payload under the sibling container, as the
    language declares them — no crate table records a std
    method (seam round 18, protest P8)."""
    if name in ("unwrap", "expect", "unwrap_or", "unwrap_or_else", "unwrap_or_default", "unwrap_unchecked"):
        payload = _payload_text(t)
        if payload is not None:
            return payload
    if name in ("unwrap_err", "expect_err", "unwrap_err_unchecked"):
        parts = _result_option_parts(t)
        if parts and parts[0] == "Result" and len(parts[1]) >= 2:
            return parts[1][1]
    if name in ("as_ref", "as_mut"):
        aref = _as_ref_text(t) if name == "as_ref" else _as_mut_text(t)
        if aref is not None:
            return aref
    if name == "ok":
        okt = _ok_text(t)
        if okt is not None:
            return okt
    if name in ("copied", "cloned"):
        ct = _copied_text(t)
        if ct is not None:
            return ct
    if name in ("as_deref", "as_deref_mut"):
        dt = _as_deref_text(t, name == "as_deref_mut")
        if dt is not None:
            return dt
    if name == "transpose":
        tt = _transpose_text(t)
        if tt is not None:
            return tt
    if name in ("as_slice", "as_mut_slice"):
        st = _as_slice_text(t, name == "as_mut_slice")
        if st is not None:
            return st
    if name == "unzip":
        ut = _unzip_text(t)
        if ut is not None:
            return ut
    # The payload ring's next carriers (seam round 22,
    # protest P1): the sibling-container steps, the
    # payload-preserving and payload-extracting steps, and
    # `clone` on a container receiver. Every arm is guarded
    # by the container head itself — on a payload receiver
    # these names are the payload's own steps (the standard
    # library's `Clone` on the payload is the standing
    # instance) and no arm reads them.
    if name in ("ok_or", "ok_or_else"):
        ot = _ok_or_text(t)
        if ot is not None:
            return ot
    if name in ("or", "or_else", "xor", "take", "replace", "clone"):
        if _result_option_parts(t) is not None:
            return _self_text(t)
    if name == "and":
        if _result_option_parts(t) is not None:
            return _and_text(t)
    if name == "err":
        et = _err_text(t)
        if et is not None:
            return et
    if name == "map_err":
        mt = _map_err_text(t)
        if mt is not None:
            return mt
    if name == "flatten":
        ft = _flatten_text(t)
        if ft is not None:
            return ft
    if name == "zip":
        zt = _zip_text(t)
        if zt is not None:
            return zt
    if name in ("get_or_insert", "get_or_insert_with", "get_or_insert_default", "insert"):
        gt = _get_or_insert_text(t)
        if gt is not None:
            return gt
    if name in ("iter", "iter_mut", "into_iter"):
        it = _iter_text(t, name)
        if it is not None:
            return it
    ist = _iter_step_text(t, name)
    if ist is not None:
        return ist
    # The Deref chain walked for payload steps (seam round
    # 25, protest P3), in the language's own resolution
    # order: each chain element in turn — a container text
    # the chain reaches has the step read at its breadth, a
    # crate type the chain passes has its declared method
    # read, exactly as _method_return's fallthrough reads
    # crate methods through the same chain.
    for tt in _deref_chain(t):
        if tt != t and _result_option_parts(tt) is not None:
            rt = _meth_return_text(tt, name)
            if rt is not None:
                return rt
            continue
        rt = RETURN_METH.get((tt, name))
        if rt is not None:
            return rt
        _tdf36 = globals().get("_trait_default_return36")
        if _tdf36 is not None:
            _td36 = _tdf36(tt, name)
            if _td36 is not None:
                return _td36
    return None

def _free_return_text(name):
    """RETURN_FREE's text for a free call, through the rename
    map first (seam round 7, protest P1)."""
    desc = RENAME_CTX.get(name)
    if desc is not None and desc[0] == "free":
        name = desc[1]
    return RETURN_FREE.get(name)

def _iter_element_text(tt):
    """The element type text of an iterable type text (seam
    round 7, protest P4): a slice or array's element, or a
    generic head's first argument — the element a `for`
    pattern or an iterator closure's parameter binds."""
    if tt is None:
        return None
    t = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", tt.strip()).strip()
    if t.startswith("["):
        return t[1:t.rfind("]")].split(";")[0].strip()
    return _generic_arg(t, 0)

def _fn_param_types(ttext):
    """The parameter type texts of a function-shaped parameter
    type — `Fn(A, B)`, `FnMut(A)`, `impl Fn(A) -> R`, a bare
    fn pointer `fn(A, B) -> R` — or None (seam round 7,
    protest P4: the declared signature a closure parameter is
    bound from)."""
    if ttext is None:
        return None
    t = ttext.strip()
    m = re.search(r"\b(?:FnMut|FnOnce|Fn|fn)\s*\(", t)
    if not m:
        return None
    open_idx = t.find("(", m.start())
    end = _delim_match(t, open_idx, "(", ")")
    inner = t[open_idx + 1:end - 1]
    return [p.strip() for p in _split_top(inner)] if inner.strip() else []

# The iterator-consumer arm's membership, censused against
# the Iterator trait's stable surface (seam round 27, protest
# P6): each member's value is the closure parameter positions
# its own signature binds the element to — the first for the
# one-parameter consumers, the second for `fold` / `try_fold`
# / `scan` (whose first is the accumulator / state), both for
# `reduce` / `max_by` / `min_by` / `is_sorted_by` (whose two
# parameters are both elements).
ITER_CONSUMER_ELEM_PARAMS = {"any": (0,), "all": (0,), "for_each": (0,), "try_for_each": (0,), "find": (0,), "find_map": (0,), "position": (0,), "rposition": (0,), "fold": (1,), "try_fold": (1,), "reduce": (0, 1), "max_by": (0, 1), "min_by": (0, 1), "max_by_key": (0,), "min_by_key": (0,), "is_sorted_by": (0, 1), "is_sorted_by_key": (0,), "partition": (0,), "inspect": (0,), "map": (0,), "filter": (0,), "filter_map": (0,), "flat_map": (0,), "map_while": (0,), "take_while": (0,), "skip_while": (0,), "scan": (1,)}
ITER_CONSUMERS = set(ITER_CONSUMER_ELEM_PARAMS)
ITER_ADAPTERS = {"iter", "iter_mut", "into_iter", "rev", "skip", "take", "step_by", "filter", "cloned", "copied", "peekable", "inspect", "fuse", "cycle", "by_ref", "take_while", "skip_while", "chain"}

def _iter_base_end(text, end):
    """The end offset of the base expression of an iterator
    receiver chain ending at `end` (seam round 7, protest P4):
    trailing calls of the element-preserving adapters are
    stripped, so the chain's element is its base expression's
    element."""
    cur = end
    while True:
        j = cur
        while j > 0 and text[j - 1].isspace():
            j -= 1
        if j <= 0 or text[j - 1] != ")":
            return cur
        depth, q = 1, j - 2
        while q >= 0 and depth:
            if text[q] == ")":
                depth += 1
            elif text[q] == "(":
                depth -= 1
            q -= 1
        if depth:
            return cur
        open_idx = q + 1
        k = open_idx
        while k > 0 and (text[k - 1].isalnum() or text[k - 1] == "_"):
            k -= 1
        if text[k:open_idx] in ITER_ADAPTERS and k >= 1 and text[k - 1] == ".":
            cur = k - 1
            continue
        return cur

def struct_attributes(code):
    """Every struct declaration's attribute texts, by name: the
    `#[...]` blocks standing immediately before the declaration
    (before its visibility), read on blanked text (seam round
    7, protest P5: the census records attributes beside
    fields)."""
    out = {}
    for m in re.finditer(r"\bstruct\s+(\w+)", code):
        attrs = []
        j = m.start()
        while True:
            k = j
            while k > 0 and code[k - 1].isspace():
                k -= 1
            vm = re.search(r"pub(?:\s*\([^)]*\))?$", code[:k])
            if vm and (vm.start() == 0 or not (code[vm.start() - 1].isalnum() or code[vm.start() - 1] == "_")):
                j = vm.start()
                continue
            if k > 0 and code[k - 1] == "]":
                depth, q = 1, k - 2
                while q >= 0 and depth:
                    if code[q] == "]":
                        depth += 1
                    elif code[q] == "[":
                        depth -= 1
                    q -= 1
                if depth == 0 and q >= 0 and code[q] == "#":
                    attrs.insert(0, re.sub(r"\s+", " ", code[q + 2:k - 1]).strip())
                    j = q
                    continue
            break
        out[m.group(1)] = attrs
    return out

def _defined_names(code):
    return {m.group(1) for m in re.finditer(r"(?<!['*])\b(?:fn|struct|enum|union|type|const|static|trait)\s+(\w+)", code)}

def _sys_import_names(code, rel=None):
    """The sys names file `rel`'s production code uses
    unqualified (seam round 7, protest P7): the per-file census
    the sys import lists are tied to — every extended-mint
    name the production code text (use statements blanked)
    names whole-word outside a path or field/method position
    and outside the file's own definitions of that name, the
    `slot` call shape and a bare `Bool` judged by occurrence as
    in the pure criterion, and any sys name the file names
    through a renamed local binding (`use crate::sys::X as Y`
    — Y's occurrences are X's)."""
    scan = blank_use_statements(code)
    defs = _defined_names(code)
    out = set()
    for n in SYS_MINT_NAMES:
        if n in EXCLUSIONS or n in defs:
            continue
        for m in re.finditer(r"\b" + re.escape(n) + r"\b", scan):
            if scan[max(0, m.start() - 2):m.start()] == "::" or scan[m.start() - 1:m.start()] == ".":
                continue
            out.add(n)
            break
    if "slot" not in defs and SLOT_CALL_RE.search(scan):
        out.add("slot")
    if rel != BOOL_HOME_REL and "Bool" not in defs:
        for m in BOOL_WORD_RE.finditer(scan):
            if scan[max(0, m.start() - 2):m.start()] != "::":
                out.add("Bool")
                break
    for local, _scope, segs, _pub in _rename_bindings(code, _scope_spans(code)):
        if len(segs) >= 3 and _resolve_modpath(rel, segs[:-1]) == "sys" and local != segs[-1]:
            if re.search(r"\b" + re.escape(local) + r"\b", scan):
                out.add(segs[-1])
    return out

def _sys_imported_names(code, rel=None):
    """The sys names a file imports from `crate::sys` in its
    own text (seam round 7, protest P7), and whether any sys
    glob import stands: the tie's other side."""
    out = set()
    glob = False
    for local, _scope, segs, _pub in _rename_bindings(code, _scope_spans(code)):
        if len(segs) >= 2 and segs[0] == "crate" and segs[1] == "sys":
            if local == "*":
                glob = True
            elif len(segs) >= 3:
                out.add(segs[-1])
        elif segs and segs[0] == "sys" and len(segs) >= 2:
            if local == "*":
                glob = True
            else:
                out.add(segs[-1])
    return out, glob

# ------------------------------------------------------- seam round 5: the
# fixed point over declared types (protest P1), the module-scope
# exclusions (protest P4) and the generic-instantiation arm
# (protest P5). All three read the declared-type tables above.

def _field_decl_text(tident, field):
    """The declared type TEXT of `tident`'s field `field`
    (a positional index for a tuple field), or None."""
    entry = STRUCT_FIELDS.get(tident)
    if entry is None:
        return None
    named, positional = entry
    if field.isdigit():
        idx = int(field)
        return positional[idx] if idx < len(positional) else None
    return named.get(field)

def _substituted_field_text(ttext, field):
    """The declared type text of `field`, read through the
    instantiation `ttext` (seam round 18, protest P2):
    the instantiation's arguments are substituted for its
    defining type's parameters in the field's declared
    type, position for position — the field of
    `Outer<Wrap<2>>` declared `T` reads as `Wrap<2>`, as
    the language projects it. With no instantiation, an
    inference placeholder among the arguments, or fewer
    arguments than parameters, the declared text stands
    as written."""
    if ttext is None:
        return None
    t = re.sub(r"\s+", " ", ttext.strip())
    t = re.sub(r"^&\s*(?:'\w+\s+)?(?:mut\s+)?", "", t).strip()
    if field.isdigit() and t.startswith("(") and t.endswith(")"):
        # A tuple type text's positional element (seam round
        # 27, protest P3): a local standing at a tuple text —
        # an adapter chain's pair, a closure's parameter — has
        # its `.<idx>` projection read at the position's own
        # text, as the identity level already reads it.
        _tp27 = _split_top(t[1:-1])
        _ti27 = int(field)
        if _ti27 < len(_tp27):
            return _tp27[_ti27].strip()
    ident = _det_id(t)
    if ident is None:
        return None
    ft = _field_decl_text(ident, field)
    if ft is None:
        return None
    params = STRUCT_PARAMS.get(ident) or []
    if not params or "<" not in t or not t.endswith(">"):
        return ft
    args = [p.strip() for p in _split_top(t[t.find("<") + 1:-1])]
    if len(args) < len(params) or any(a == "_" for a in args[:len(params)]):
        return ft
    # Simultaneous substitution (seam round 20, protest
    # P2): one pass over the declared text, each parameter
    # token replaced by its argument exactly once — an
    # inserted argument is a denotation in the
    # instantiating scope and is never rescanned, so a
    # later parameter's substitution cannot capture it,
    # as the language's own substitution cannot.
    mapping = dict(zip(params, args))
    pat = re.compile("|".join(
        re.escape(p) + r"\b" if p.startswith("'") else r"\b" + re.escape(p) + r"\b"
        for p in mapping))
    return pat.sub(lambda m: mapping[m.group(0)], ft)

def _field_type_through(ttext, field):
    """The declared type of `field` read through the
    instantiation `ttext`, as an identity, or None (seam
    round 18, protest P2)."""
    ft = _substituted_field_text(ttext, field)
    if ft is None:
        return None
    ident = _det_id(ttext) if ttext is not None else None
    return _det_id(ft, rel=TYPE_DEFS.get(_disp(ident)) if ident is not None else None)

def _field_type(tname, field):
    """The declared type of `tname`'s field `field` (a positional
    index for a tuple field), as a type identity with aliases
    expanded (seam round 6, protest P1), or None."""
    entry = STRUCT_FIELDS.get(tname)
    if entry is None:
        return None
    named, positional = entry
    if field.isdigit():
        idx = int(field)
        return _det_id(positional[idx], rel=TYPE_DEFS.get(_disp(tname))) if idx < len(positional) else None
    ft = named.get(field)
    return _det_id(ft, rel=TYPE_DEFS.get(_disp(tname))) if ft is not None else None

def _method_return(tname, mname):
    # The payload step (seam round 16, protest P1; seam
    # round 18, protest P8): on a determinable
    # Result/Option receiver, `unwrap` and `expect` return
    # the payload type, `as_ref` and `as_mut` return the
    # reference-wrapped Result/Option and `ok` the payload
    # under the sibling container, as the language
    # declares them — no crate table records a std method.
    if mname in ("unwrap", "expect", "unwrap_or", "unwrap_or_else", "unwrap_or_default", "unwrap_unchecked"):
        payload = _payload_text(tname)
        if payload is not None:
            return _det_id(payload)
    if mname in ("unwrap_err", "expect_err", "unwrap_err_unchecked"):
        parts = _result_option_parts(tname)
        if parts and parts[0] == "Result" and len(parts[1]) >= 2:
            return _det_id(parts[1][1])
    if mname in ("as_ref", "as_mut"):
        aref = _as_ref_text(tname) if mname == "as_ref" else _as_mut_text(tname)
        if aref is not None:
            return _det_id(aref)
    if mname == "ok":
        okt = _ok_text(tname)
        if okt is not None:
            return _det_id(okt)
    if mname in ("copied", "cloned"):
        ct = _copied_text(tname)
        if ct is not None:
            return _det_id(ct)
    if mname in ("as_deref", "as_deref_mut"):
        dt = _as_deref_text(tname, mname == "as_deref_mut")
        if dt is not None:
            return _det_id(dt)
    if mname == "transpose":
        tt = _transpose_text(tname)
        if tt is not None:
            return _det_id(tt)
    if mname in ("as_slice", "as_mut_slice"):
        st = _as_slice_text(tname, mname == "as_mut_slice")
        if st is not None:
            return _det_id(st)
    if mname == "unzip":
        ut = _unzip_text(tname)
        if ut is not None:
            return _det_id(ut)
    # The payload ring at the identity level (seam round
    # 22, protest P1), as in _meth_return_text: guarded by
    # the container head, so a payload receiver's own
    # `clone` — the standing instance — is not read.
    if mname in ("ok_or", "ok_or_else"):
        ot = _ok_or_text(tname)
        if ot is not None:
            return _det_id(ot)
    if mname in ("or", "or_else", "xor", "take", "replace", "clone"):
        if _result_option_parts(tname) is not None:
            return _det_id(_self_text(tname))
    if mname == "and":
        if _result_option_parts(tname) is not None:
            return _det_id(_and_text(tname))
    if mname == "err":
        et = _err_text(tname)
        if et is not None:
            return _det_id(et)
    if mname == "map_err":
        mt = _map_err_text(tname)
        if mt is not None:
            return _det_id(mt)
    if mname == "flatten":
        ft = _flatten_text(tname)
        if ft is not None:
            return _det_id(ft)
    if mname == "zip":
        zt = _zip_text(tname)
        if zt is not None:
            return _det_id(zt)
    if mname in ("get_or_insert", "get_or_insert_with", "get_or_insert_default", "insert"):
        gt = _get_or_insert_text(tname)
        if gt is not None:
            return _det_id(gt)
    if mname in ("iter", "iter_mut", "into_iter"):
        it = _iter_text(tname, mname)
        if it is not None:
            return it
    ist = _iter_step_text(tname, mname)
    if ist is not None:
        return _det_id(ist) if mname in ("next", "last", "nth", "max", "min", "find", "find_map", "reduce", "max_by", "min_by", "max_by_key", "min_by_key") else ist
    _return_home = TYPE_DEFS.get(_disp(tname))
    rt = None
    for _t in _deref_chain(tname):
        if _t != tname and _result_option_parts(_t) is not None:
            sub = _method_return(_t, mname)
            if sub is not None:
                return sub
            continue
        rt = RETURN_METH.get((_t, mname))
        if rt is not None:
            tname = _t
            break
    if rt is None:
        return None
    if rt == "Self":
        return tname
    return _det_id(rt, rel=_return_home)

def _free_return(name):
    _return_home = None
    desc = RENAME_CTX.get(name)
    if desc is not None and desc[0] == "free":
        name = desc[1]
    rt = RETURN_FREE.get(name)
    if rt is None or rt == "Self":
        return None
    return _det_id(rt, rel=_return_home)

def _callee_return(text, open_idx, rmap):
    """The declared return type of the call whose argument list
    opens at open_idx in `text`, or None: a method call resolves
    through its receiver's type, an associated call through its
    type — by the identity the spelled path denotes (seam
    round 6, protest P10) — a free call through its name; each
    to the callee's declared return type in the crate, with
    aliases expanded."""
    _tm33 = re.search(r"<[^<>]*\bas\s+(?:\w+\s*::\s*)*(\w+)\s*>\s*::\s*(\w+)\s*$", text[:open_idx])
    if _tm33 is not None and (_tm33.group(1), _tm33.group(2)) in TRAIT_METH_RETURN33:
        _tret33 = TRAIT_METH_RETURN33[(_tm33.group(1), _tm33.group(2))]
        return _det_id(_tret33) or _tret33
    _sc26 = _std_ctor_call_text(text, open_idx, rmap)
    if _sc26 is not None:
        # The identity a constructor call's result binds at
        # (seam round 27, protest P8): a `Deref` carrier's
        # result stands at its target's identity, as an
        # annotated binding of the same construction binds
        # through `_det_id_deref` — `Box::new(x)` binds what
        # `x`'s container is, not the carrier.
        return _det_id_deref(_sc26) or _sc26
    _ic30 = _std_iter_ctor_text(text, open_idx, rmap)
    if _ic30 is not None:
        return _ic30
    _cc31 = _ctor_call_text31(text, open_idx, rmap)
    if _cc31 is not None:
        return _cc31
    _fc32 = _from_call_through32(text, open_idx, rmap)
    if _fc32 is not None:
        return _fc32
    end = open_idx
    while end > 0 and text[end - 1].isspace():
        end -= 1
    if end <= 0:
        return None
    ch = text[end - 1]
    if ch == ">":
        # A turbofish call `name::<args>(...)`: the callee name
        # stands before the `<`.
        depth, j = 1, end - 2
        while j >= 0 and depth:
            if text[j] == ">":
                depth += 1
            elif text[j] == "<":
                depth -= 1
            j -= 1
        if depth:
            return None
        end = j + 1
        while end > 0 and text[end - 1] == ":":
            end -= 1
        ch = text[end - 1] if end > 0 else ""
    if not (ch.isalnum() or ch == "_"):
        return None
    j = end
    while j > 0 and (text[j - 1].isalnum() or text[j - 1] == "_"):
        j -= 1
    seg = text[j:end]
    if j >= 2 and text[j - 1] == "." and (text[j - 2].isalnum() or text[j - 2] in "_)]"):
        base = _expr_type_at(text, j - 1, rmap)
        if base is None:
            # The identity-level twin of _callee_return_
            # text's unnamed-receiver step (seam round 27,
            # protests P3/P5): an iterator step on a
            # receiver that stands only as a text is read
            # at that text.
            _recv27 = _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None))
            if _recv27 is None or seg not in ("iter", "iter_mut", "into_iter", "next", "last", "nth", "max", "min", "map", "filter_map", "flat_map", "map_while", "enumerate", "zip", "scan", "flatten", "peekable", "inspect", "fuse", "cycle", "by_ref", "take_while", "skip_while", "chain", "cloned", "copied", "filter", "rev", "skip", "take", "step_by", "find", "reduce", "max_by", "min_by", "max_by_key", "min_by_key", "unzip", "and_then", "find_map"):
                return None
            _rt27 = _meth_return_text(_recv27, seg)
            if seg in ("map", "filter_map", "flat_map", "map_while", "enumerate", "zip", "scan", "flatten", "peekable", "inspect", "fuse", "cycle", "by_ref", "take_while", "skip_while", "chain", "cloned", "copied", "filter", "rev", "skip", "take", "step_by"):
                _ad27 = _iter_adapter_return_text(text, open_idx, rmap, seg, _recv27)
                if _ad27 is not None:
                    _rt27 = _ad27
            elif seg in ("next", "last", "nth", "max", "min", "find", "reduce", "max_by", "min_by", "max_by_key", "min_by_key") and _rt27 is not None:
                _rt27 = _det_id(_rt27) or _rt27
            if seg == "find_map":
                _fm29 = _find_map_call_text(text, open_idx, rmap, _recv27)
                if _fm29 is not None:
                    _rt27 = _fm29
            if _rt27 is None and seg == "unzip":
                _rt27 = _unzip_call_text(text, open_idx, rmap, _recv27)
            if _rt27 is None and seg in ("map", "and_then", "filter", "inspect"):
                _rt27 = _container_step_result_text(text, open_idx, rmap, seg, _recv27)
            return _recv27 if _rt27 == "Self" else _rt27
        rt = _method_return(base, seg)
        if seg in ("map", "filter_map", "flat_map", "map_while", "enumerate", "zip", "scan", "flatten", "peekable", "inspect", "fuse", "cycle", "by_ref", "take_while", "skip_while", "chain", "cloned", "copied", "filter", "rev", "skip", "take", "step_by"):
            _ad26 = _iter_adapter_return_text(text, open_idx, rmap, seg, _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None)) or base)
            if _ad26 is not None:
                rt = _ad26
        if seg in ("and", "zip"):
            arg = _first_arg_text(text, open_idx)
            at = None
            if arg is not None:
                at = _expr_type_text_at(arg, len(arg), rmap, _texts_of(rmap, None))
                if at is not None and _result_option_parts(at) is None:
                    at = None
            if at is None and arg is not None:
                at = _expr_type_at(arg, len(arg), rmap)
            if at is None and arg is not None:
                at = _ctor_container_text(arg, rmap)
            ov = _and_arg_text(base, at) if seg == "and" else _zip_arg_text(base, at)
            if ov is not None:
                rt = _det_id(ov)
        if seg == "find_map":
            _fm29 = _find_map_call_text(text, open_idx, rmap, _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None)) or base)
            if _fm29 is not None:
                rt = _det_id(_fm29) or _fm29
        if rt is None and seg == "unzip":
            _ov28 = _unzip_call_text(text, open_idx, rmap, _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None)) or base)
            if _ov28 is not None:
                rt = _det_id(_ov28) or _ov28
        if rt is None and seg in ("map", "and_then", "filter", "inspect"):
            _ov28 = _container_step_result_text(text, open_idx, rmap, seg, _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None)) or base)
            if _ov28 is not None:
                rt = _det_id(_ov28) or _ov28
        return rt
    if j >= 2 and text[j - 2:j] == "::":
        segs = _expand_module_segs(None, _path_segs_before(text, j))
        if segs and segs[-1][:1].isupper():
            ident = _ident_of(segs[-1], segs[:-1])
            if ident is not None:
                return _method_return(ident, seg)
        _rfr32 = _resolved_free_return32(text, j, seg)
        if _rfr32 is not None:
            _sub32 = _call_generic_substitution(_rfr32, text, open_idx, rmap, GENERIC_PARAMS_FREE.get(seg), PARAMS_FREE.get(seg))
            return _det_id(_sub32 if _sub32 is not None else _rfr32) or _sub32 or _rfr32
        if _fn_body_only33(seg):
            _fv31 = _from_value_call_text(text, open_idx, rmap)
            return (_det_id(_fv31) or _fv31) if _fv31 is not None else None
        _fr31 = _free_return_at(seg, text, open_idx, rmap)
        if _fr31 is not None:
            return _fr31
        _fv31 = _from_value_call_text(text, open_idx, rmap)
        return (_det_id(_fv31) or _fv31) if _fv31 is not None else None
    _fv30 = _from_value_call_text(text, open_idx, rmap)
    if _fv30 is not None:
        return _det_id(_fv30) or _fv30
    _bv31 = _bound_fn_value_return31(text, open_idx, rmap)
    if _bv31 is not None:
        _sub31 = _call_generic_substitution(_bv31[0], text, open_idx, rmap, GENERIC_PARAMS_FREE.get(_bv31[1]), PARAMS_FREE.get(_bv31[1]))
        return _det_id(_sub31 if _sub31 is not None else _bv31[0]) or _sub31 or _bv31[0]
    _cl34 = globals().get("_closure_call_return34")
    if _cl34 is not None:
        _cr34 = _cl34(text, open_idx, rmap)
        if _cr34 is not None:
            return _det_id(_cr34) or _cr34
    _ownb33 = _own_fn_body_return33(seg, text, j)
    if _ownb33 is not None:
        _sub33 = _call_generic_substitution(_ownb33, text, open_idx, rmap, GENERIC_PARAMS_FREE.get(seg), PARAMS_FREE.get(seg))
        return _det_id(_sub33 if _sub33 is not None else _ownb33) or _sub33 or _ownb33
    if _fn_body_only33(seg):
        return None
    return _free_return_at(seg, text, open_idx, rmap)

def _expr_type_at(text, end, rmap):
    """The declared type of the expression ending at offset
    `end` in `text`, resolved over declared types to an
    identity: a variable from the receiver map; a field access
    through the field's declared type in its defining struct;
    a call through the callee's declared return type; a
    spelled path (`Type::Variant`, `Type::CONSTANT`) through
    the identity the path denotes; a struct literal
    (`Type { ... }`, `Type::Variant { ... }`) through its
    type (seam round 6, protests P6/P10). Anything else — a
    receiver whose type arrives through a generic parameter
    or a trait object, an index, a deref, a block, any
    expression with no declared type in the crate — is None:
    the computation's recorded limit."""
    while end > 0 and text[end - 1].isspace():
        end -= 1
    if end <= 0:
        return None
    ch = text[end - 1]
    if ch == ")":
        depth, j = 1, end - 2
        while j >= 0 and depth:
            if text[j] == ")":
                depth += 1
            elif text[j] == "(":
                depth -= 1
            j -= 1
        if depth:
            return None
        _deref28 = _explicit_deref_text(text, j + 1, end, rmap, _texts_of(rmap, None))
        if _deref28 is not None:
            return _det_id_deref(_deref28) or _det_id(_deref28) or _deref28
        if j < 0 or not (text[j].isalnum() or text[j] == "_" or text[j] in ")]>!"):
            # A grouping parenthesis (seam round 30,
            # protest P1), as at the text level beside it.
            _inner30 = text[j + 2:end - 1]
            _gt30 = _expr_type_text_at(_inner30, len(_inner30), rmap, _texts_of(rmap, None))
            if _gt30 is not None:
                return _det_id_deref(_gt30) or _det_id(_gt30) or _gt30
            _gi30 = _expr_type_at(_inner30, len(_inner30), rmap)
            if _gi30 is not None:
                return _gi30
        return _callee_return(text, j + 1, rmap)
    if ch == "}":
        depth, j = 1, end - 2
        while j >= 0 and depth:
            if text[j] == "}":
                depth += 1
            elif text[j] == "{":
                depth -= 1
            j -= 1
        if depth:
            return None
        pm = re.search(r"((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*$", text[:j + 1])
        if not pm:
            return None
        segs = [s.strip() for s in pm.group(1).split("::")]
        ident = _ident_of(segs[-1], segs[:-1])
        if ident is not None and ident in STRUCT_FIELDS:
            return ident
        if len(segs) >= 2:
            ident = _ident_of(segs[-2], segs[:-2])
            if ident is not None and ident in STRUCT_FIELDS:
                return ident
        return None
    if ch == "?":
        # The payload step (seam round 16, protest P1): the
        # type of `expr?` is the payload of expr's declared
        # Result/Option type, read at the text level (a
        # call's return text, a field's declared text), with
        # the identity level as its fallback (a determinable
        # Result/Option identity IS its text, see _det_id).
        tt = _expr_type_text_at(text, end - 1, rmap, _texts_of(rmap, None))
        payload = _payload_text_through_deref(tt) if tt is not None else None
        if payload is None:
            base = _expr_type_at(text, end - 1, rmap)
            payload = _payload_text_through_deref(base) if base is not None else None
        return _det_id(payload) if payload is not None else None
    if ch == "]":
        # The index step (seam round 16, protest P3): the
        # type of `expr[i]` is the element type of expr's
        # declared type, read at the text level as the
        # iterator arms read elements.
        depth, j = 1, end - 2
        while j >= 0 and depth:
            if text[j] == "]":
                depth += 1
            elif text[j] == "[":
                depth -= 1
            j -= 1
        if depth:
            return None
        tt = _expr_type_text_at(text, j + 1, rmap, _texts_of(rmap, None))
        elem = _iter_element_text(tt) if tt is not None else None
        return _det_id(elem) if elem is not None else None
    if ch.isalnum() or ch == "_":
        j = end
        while j > 0 and (text[j - 1].isalnum() or text[j - 1] == "_"):
            j -= 1
        seg = text[j:end]
        if j >= 2 and text[j - 1] == "." and (text[j - 2].isalnum() or text[j - 2] in "_)]"):
            # A field read through a generic instantiation
            # (seam round 18, protest P2): the field's
            # declared type is read through the receiver's
            # type TEXT, the instantiation's arguments
            # substituted for the defining type's
            # parameters, before the identity-level reading
            # stands as the fallback.
            tt = _expr_type_text_at(text, j - 1, rmap, _texts_of(rmap, None))
            if tt is not None and seg.isdigit() and tt.strip().startswith("(") and tt.strip().endswith(")"):
                # A tuple type text's positional element
                # (seam round 22, protest P1): the pair
                # `zip` returns stands as a tuple text at
                # this level, and its `.0` is its first
                # element's type, as a tuple struct's
                # positional field is its declared type.
                tparts = _split_top(tt.strip()[1:-1])
                tidx = int(seg)
                if tidx < len(tparts):
                    return _det_id(tparts[tidx])
            if tt is not None:
                sub = _field_type_through(tt, seg)
                if sub is not None:
                    return sub
            base = _expr_type_at(text, j - 1, rmap)
            return _field_type(base, seg) if base is not None else None
        if j >= 2 and text[j - 2:j] == "::":
            segs = _expand_module_segs(None, _path_segs_before(text, j))
            ident = _ident_of(seg, segs)
            if ident is not None and ident in TYPE_LOCS:
                return ident
            if segs:
                ident = _ident_of(segs[-1], segs[:-1])
                if ident is not None and ident in TYPE_LOCS:
                    return ident
            return None
        return rmap.get(seg)
    return None

def _receiver_types_full(tname, sig, body, rel=None):
    """The receiver variable -> type map of one item, to a FIXED
    POINT over declared types (seam round 5, protest P1): the
    landed forms (_receiver_types: parameters, the `Self`
    receiver, annotated bindings), then unannotated `let`
    bindings whose initialiser's declared type the machinery
    resolves — a call through its callee's declared return
    type, a field access through the field's declared type —
    iterated until no binding is added, so multi-hop chains of
    bindings resolve too. Pattern bindings stand in the same
    fixed point (seam round 6, protest P2): a `let`/parameter/
    `if let`/`match`-arm pattern destructuring a value of a
    determinable declared type binds each pattern variable
    with the type its position declares."""
    out = _receiver_types(tname, sig, body, rel=rel)
    texts = {}
    TEXTS_BY_RMAP[id(out)] = (out, texts)
    for pname, ptype in _param_list(sig):
        if pname is not None:
            texts.setdefault(pname, ptype)
    for lm in re.finditer(r"\blet\s+(?:mut\s+)?(\w+)\s*:\s*([^=;]+)", body):
        texts.setdefault(lm.group(1), lm.group(2).strip())
    # Pattern parameters: `fn f(Struct { field }: Struct)`.
    for part in _split_top(sig[sig.find("(") + 1:_delim_match(sig, sig.find("("), "(", ")") - 1]) if "(" in sig else []:
        part = part.strip()
        if not part or re.match(r"^(?:&\s*(?:mut\s+)?|mut\s+)?self\b", part):
            continue
        if re.match(r"^(?:mut\s+)?\w+\s*:", part):
            continue
        depth, colon = 0, -1
        for idx, c in enumerate(part):
            if c in "(<[{":
                depth += 1
            elif c in ")>]}":
                depth -= 1
            elif c == ":" and depth == 0 and part[idx - 1] != ":" and part[idx + 1:idx + 2] != ":":
                colon = idx
                break
        if colon > 0:
            _bind_pattern(part[:colon], part[colon + 1:].strip(), out, texts)
    for _pass in range(32):
        grew = False
        for lm in re.finditer(r"\blet\s+(?:mut\s+)?(\w+)\s*=\s*", body):
            name = lm.group(1)
            # A plain binding's declared type TEXT stands in
            # the texts map beside its identity (seam round
            # 25, protests P2 and P4): a tuple or container
            # text no identity denotes — a `(Built, u32)`
            # binding — is still the type its pattern, `match`
            # and `for` scrutinees destructure, and those
            # arms read texts, not identities.
            if name not in texts:
                end0 = _statement_end(body, lm.end())
                if end0 is not None:
                    tt0 = _expr_type_text_at(body, end0, out, texts)
                    if tt0 is None:
                        tt0 = _arg_shape_text(body[lm.end():end0], out)
                    if tt0 is not None:
                        texts[name] = tt0
            if name in out:
                continue
            end = _statement_end(body, lm.end())
            if end is None:
                continue
            stmt = body[lm.end():end].rstrip()
            if stmt.endswith("?"):
                # A binding initialised by `expr?` (seam round
                # 10, protest P6): the ordinary error-propagation
                # spelling unwraps exactly as the pattern arm's
                # Some(p) / Ok(p) does — the binding takes the
                # payload type of the initialiser's declared
                # Result/Option type, its first generic argument.
                qpos = lm.end() + len(stmt) - 1
                tt = _expr_type_text_at(body, qpos, out, texts)
                payload = _generic_arg(tt, 0) if tt is not None else None
                t = _det_id(payload) if payload is not None else None
                if t is not None:
                    out[name] = t
                    grew = True
                continue
            t = _expr_type_at(body, end, out)
            if t is None:
                # A binding initialised by a bare type name — a
                # unit struct's value construction (seam round
                # 10, protest P2's receiver form): the name
                # denotes the type it constructs. Seam round
                # 20 (protest P3): the construction may carry
                # a turbofish segment — `Type::<args>` is the
                # only spelling that compiles unannotated for
                # a generic unit struct — and the segment is
                # stripped before the fullmatch, as the
                # sibling arms strip it; the construction
                # arms judge a construction as a naming event
                # and do not type the binding it initialises,
                # so this arm, not they, is where the
                # binding's type is read.
                bare = _strip_turbofish(stmt.strip())
                vm = re.fullmatch(r"((?:\w+\s*::\s*)*)(\w+)", bare)
                if vm:
                    vsegs = [s.strip() for s in vm.group(1).split("::") if s.strip()]
                    if _ident_of(vm.group(2), vsegs) is not None:
                        t = _det_id(bare)
            if t is not None:
                out[name] = t
                grew = True
        # Pattern `let` bindings: `let PAT = INIT;` and
        # `let PAT: TYPE = INIT;`.
        for lm in re.finditer(r"\blet\s+", body):
            start = lm.end()
            depth, eq, j = 0, -1, start
            while j < len(body):
                c = body[j]
                if c in "(<[{":
                    depth += 1
                elif c in ")>]}":
                    depth -= 1
                elif c == "=" and depth == 0 and body[j + 1:j + 2] != "=" and body[j - 1] != "=":
                    eq = j
                    break
                elif c == ";" and depth == 0:
                    break
                j += 1
            if eq < 0:
                continue
            pat = body[start:eq].strip()
            if re.fullmatch(r"(?:mut\s+)?\w+", pat):
                continue
            depth, colon = 0, -1
            for idx, c in enumerate(pat):
                if c in "(<[{":
                    depth += 1
                elif c in ")>]}":
                    depth -= 1
                elif c == ":" and depth == 0 and pat[idx - 1] != ":" and pat[idx + 1:idx + 2] != ":":
                    colon = idx
                    break
            ann = None
            if colon > 0:
                ann = pat[colon + 1:].strip()
                pat = pat[:colon].strip()
            end = _statement_end(body, eq + 1)
            if end is None:
                continue
            # A let-else (seam round 27, protest P10): the
            # statement's end stands past the else block, and
            # the pattern binds from the initialiser standing
            # before it — the extraction reads the initialiser
            # to the top-level `else` that opens the diverging
            # block, as it reads a plain let's initialiser to
            # its `;`, so the binding enters the map at its
            # position's declared type for the body that
            # follows the statement, in the simple and the
            # or-pattern forms alike.
            _else27 = -1
            _d27, _j27 = 0, eq + 1
            while _j27 < len(body):
                _c27 = body[_j27]
                if _c27 in "(<[{":
                    _d27 += 1
                elif _c27 in ")>]}":
                    _d27 -= 1
                elif _c27 == ";" and _d27 == 0:
                    break
                elif _d27 == 0 and body.startswith("else", _j27) and not (body[_j27 - 1].isalnum() or body[_j27 - 1] == "_") and not (body[_j27 + 4:_j27 + 5].isalnum() or body[_j27 + 4:_j27 + 5] == "_"):
                    _k27 = _j27 + 4
                    while _k27 < len(body) and body[_k27].isspace():
                        _k27 += 1
                    if _k27 < len(body) and body[_k27] == "{":
                        _else27 = _j27
                        break
                _j27 += 1
            _iend27 = _else27 if _else27 >= 0 else end
            tt = ann if ann is not None else _expr_type_text_at(body, _iend27, out, texts)
            if tt is None:
                # A literal initialiser's own shape (seam
                # round 25, protest P4): a tuple of a
                # reference to a call — `(&(h, _), _)` bound
                # from `(&pick(), 0)` — is typed by its
                # elements' types where no declared text
                # names the whole.
                tt = _arg_shape_text(body[eq + 1:_iend27], out)
            if _bind_pattern(pat, tt, out, texts):
                grew = True
        # `if let` / `while let` patterns: `if let PAT = EXPR {`.
        for lm in re.finditer(r"\b(?:if|while)\s+let\s+", body):
            start = lm.end()
            depth, eq, j = 0, -1, start
            while j < len(body):
                c = body[j]
                if c in "(<[{":
                    depth += 1
                elif c in ")>]}":
                    depth -= 1
                elif c == "=" and depth == 0 and body[j + 1:j + 2] != "=" and body[j - 1] != "=":
                    eq = j
                    break
                elif c == "{" and depth == 0:
                    break
                j += 1
            if eq < 0:
                continue
            pat = body[start:eq].strip()
            if re.fullmatch(r"(?:mut\s+)?\w+", pat):
                continue
            depth, brace = 0, -1
            j = eq + 1
            while j < len(body):
                c = body[j]
                if c in "(<[":
                    depth += 1
                elif c in ")>]":
                    depth -= 1
                elif c == "{" and depth == 0:
                    brace = j
                    break
                j += 1
            if brace < 0:
                continue
            tt = _expr_type_text_at(body, brace, out, texts)
            if tt is None:
                tt = _expr_type_at(body, brace, out)
            if _bind_pattern(pat, tt, out, texts):
                grew = True
        # `match` arms: `match EXPR { PAT => ... }` — arm
        # patterns at the block's own depth.
        for lm in re.finditer(r"\bmatch\s+", body):
            start = lm.end()
            depth, brace = 0, -1
            j = start
            while j < len(body):
                c = body[j]
                if c in "(<[":
                    depth += 1
                elif c in ")>]":
                    depth -= 1
                elif c == "{" and depth == 0:
                    brace = j
                    break
                j += 1
            if brace < 0:
                continue
            tt = _expr_type_text_at(body, brace, out, texts)
            if tt is None:
                tt = _expr_type_at(body, brace, out)
            if tt is None:
                # A literal scrutinee's own shape (seam
                # round 26, protest P5's sweep), as the
                # pattern-`let` arm reads a literal
                # initialiser: a tuple of typed elements
                # stands as its tuple type where no declared
                # text names the whole.
                tt = _arg_shape_text(body[start:brace], out)
            if tt is None:
                continue
            bend = _brace_match(body, brace)
            block = body[brace + 1:bend - 1]
            # Arm patterns extracted at bracket depth (seam
            # round 25, protest P4), as the pattern-carried
            # arm extracts them: a tuple or struct pattern's
            # own commas stand inside its brackets and are
            # not arm separators.
            i = 0
            while True:
                j = block.find("=>", i)
                if j < 0:
                    break
                seg = block[i:j]
                depth, start = 0, 0
                for k, ch in enumerate(seg):
                    if ch in "(<[{":
                        depth += 1
                    elif ch in ")>]}":
                        depth -= 1
                    elif ch == "," and depth == 0:
                        start = k + 1
                pat = seg[start:].strip()
                # A match-arm guard (seam round 26, protest
                # P6): the pattern ends where its guard begins
                # — a top-level ` if ` — and the bindings the
                # pattern makes stand for the guard's reads as
                # they stand for the body's: the receiver map
                # is the item's, and the guard stands in the
                # item's text the map is read over, so a binding
                # read in the guard is judged at the body's
                # breadth once the pattern itself is read.
                _gd26, _gcut26 = 0, -1
                for _gk26, _gc26 in enumerate(pat):
                    if _gc26 in "(<[{":
                        _gd26 += 1
                    elif _gc26 in ")>]}":
                        _gd26 -= 1
                    elif _gd26 == 0 and pat.startswith(" if ", _gk26):
                        _gcut26 = _gk26
                        break
                if _gcut26 >= 0:
                    pat = pat[:_gcut26].strip()
                i = j + 2
                if not pat or re.fullmatch(r"(?:mut\s+)?\w+", pat) or pat == "_":
                    continue
                if _bind_pattern(pat, tt, out, texts):
                    grew = True
        # `for` loop variables (seam round 7, protest P4): a
        # pattern bound by the iterable expression, with the
        # element type the iterable's declared type gives it.
        for lm in re.finditer(r"\bfor\s+", body):
            start = lm.end()
            depth, inp, j = 0, -1, start
            while j < len(body):
                c = body[j]
                if c in "(<[{":
                    depth += 1
                elif c in ")>]}":
                    depth -= 1
                elif depth == 0 and body.startswith("in", j) and not (body[j - 1].isalnum() or body[j - 1] == "_") and not (body[j + 2:j + 3].isalnum() or body[j + 2:j + 3] == "_"):
                    inp = j
                    break
                elif c == "{" and depth == 0:
                    break
                j += 1
            if inp < 0:
                continue
            depth, brace, j = 0, -1, inp + 2
            while j < len(body):
                c = body[j]
                if c in "(<[":
                    depth += 1
                elif c in ")>]":
                    depth -= 1
                elif c == "{" and depth == 0:
                    brace = j
                    break
                j += 1
            if brace < 0:
                continue
            pat = body[start:inp].strip()
            tt = _expr_type_text_at(body, brace, out, texts)
            if tt is None:
                tt = _expr_type_at(body, brace, out)
            elem = _iter_element_text(tt) if _iter_elem_of(tt) is None else _iter_elem_of(tt)
            if elem is not None and _bind_pattern(pat, elem, out, texts):
                grew = True
        # Closure parameters (seam round 7, protest P4): bound
        # by their annotation, by the declared signature of the
        # crate function or method the closure is passed to (a
        # Fn-shaped parameter's own parameter types), or —
        # for an iterator consumer — by the element type of
        # the iterable the receiver chain starts from, as
        # declared.
        for cm in re.finditer(r"\|([^|]*)\|", body):
            params = [p.strip() for p in _split_top(cm.group(1))]
            todo = []
            for idx, part in enumerate(params):
                if not part:
                    continue
                depth, colon = 0, -1
                for ci, c in enumerate(part):
                    if c in "(<[{":
                        depth += 1
                    elif c in ")>]}":
                        depth -= 1
                    elif c == ":" and depth == 0 and part[ci - 1] != ":" and part[ci + 1:ci + 2] != ":":
                        colon = ci
                        break
                if colon > 0:
                    if _bind_pattern(part[:colon].strip(), part[colon + 1:].strip(), out, texts):
                        grew = True
                else:
                    todo.append((idx, part))
            if not todo:
                continue
            depth, open_idx = 0, -1
            j = cm.start() - 1
            while j >= 0:
                c = body[j]
                if c == ")":
                    depth += 1
                elif c == "(":
                    if depth == 0:
                        open_idx = j
                        break
                    depth -= 1
                j -= 1
            if open_idx < 0:
                continue
            prefix = body[open_idx + 1:cm.start()]
            arg_idx = len(_split_top(prefix)) if prefix.strip() else 0
            k = open_idx
            while k > 0 and body[k - 1].isspace():
                k -= 1
            seg_end = k
            while k > 0 and (body[k - 1].isalnum() or body[k - 1] == "_"):
                k -= 1
            callee = body[k:seg_end]
            if not callee:
                continue
            if k >= 1 and body[k - 1] == ".":
                recv_end = k - 1
                rident = _expr_type_at(body, recv_end, out)
                ptypes = PARAMS_METH.get((rident, callee)) if rident is not None else None
                bound = False
                if ptypes is not None and arg_idx < len(ptypes):
                    fnargs = _fn_param_types(ptypes[arg_idx])
                    if fnargs is not None:
                        for idx, pat in todo:
                            if idx < len(fnargs) and _bind_pattern(pat, fnargs[idx], out, texts):
                                grew = True
                                bound = True
                if not bound and callee in ITER_CONSUMERS:
                    base_end = _iter_base_end(body, recv_end)
                    tt = _expr_type_text_at(body, base_end, out, texts)
                    elem = _iter_element_text(tt)
                    if elem is not None:
                        for idx, pat in todo:
                            if idx in ITER_CONSUMER_ELEM_PARAMS.get(callee, (0,)) and _bind_pattern(pat, elem, out, texts):
                                grew = True
                if not bound and callee in ("and_then", "is_some_and", "is_ok_and", "is_none_or", "map_or", "map_or_else", "map_or_default", "take_if", "is_err_and", "inspect_err", "map_err", "or_else", "unwrap_or_else"):
                    # The payload-closure steps (seam round 20,
                    # protest P1; seam round 22, protest P1):
                    # `and_then` hands the container's payload
                    # to its closure exactly as `map` does —
                    # the closure's parameter is the payload
                    # itself; `is_some_and` and `is_ok_and`
                    # hand a reference to it (bound with the
                    # payload type, as the iterator consumers'
                    # element binding already reads a
                    # reference-handed payload); `map_or` and
                    # `map_or_else` hand it as the second
                    # closure's parameter — so the parameter
                    # binds with the payload type of the
                    # receiver's declared container type, as
                    # the iterator consumers' element binds.
                    # The ERROR payload's closure steps (seam
                    # round 23, protest P2): a `Result` holds
                    # two payloads, and `is_err_and`,
                    # `inspect_err` and `map_err`'s own closure
                    # hand the second one to their closures as
                    # `is_ok_and` hands the first; `or_else`
                    # and `unwrap_or_else` on a `Result` hand
                    # it likewise, and `map_or_else`'s FIRST
                    # closure on a `Result` is handed it (its
                    # second is handed the success payload, as
                    # above) — each such parameter binds with
                    # the container's second payload type.
                    tt = _expr_type_text_at(body, recv_end, out, texts)
                    if tt is None and rident is not None:
                        # A receiver bound to an unannotated
                        # local (seam round 24, protest P2):
                        # its identity is its container text,
                        # as the identity-level arms read it,
                        # and the closure's parameter binds
                        # from it where the text level has no
                        # annotation to read.
                        tt = rident
                    parts = _result_option_parts(tt) if tt is not None else None
                    payload = parts[1][0] if parts and parts[1] else None
                    errload = parts[1][1] if parts and parts[0] == "Result" and len(parts[1]) >= 2 else None
                    bind_text = payload
                    if callee in ("is_err_and", "inspect_err", "map_err"):
                        bind_text = errload
                    elif callee in ("or_else", "unwrap_or_else"):
                        bind_text = errload if parts and parts[0] == "Result" else None
                    elif callee == "map_or_else" and arg_idx == 0 and parts and parts[0] == "Result":
                        bind_text = errload
                    if bind_text is not None:
                        for idx, pat in todo:
                            if idx == 0 and _bind_pattern(pat, bind_text, out, texts):
                                grew = True
            else:
                desc = RENAME_CTX.get(callee)
                ptypes = PARAMS_FREE.get(desc[1]) if desc is not None and desc[0] == "free" else PARAMS_FREE.get(callee)
                if ptypes is not None and arg_idx < len(ptypes):
                    fnargs = _fn_param_types(ptypes[arg_idx])
                    if fnargs is not None:
                        for idx, pat in todo:
                            if idx < len(fnargs) and _bind_pattern(pat, fnargs[idx], out, texts):
                                grew = True
        if not grew:
            break
    return out

def _ambiguous_receiver_abstention(body, sig, recv_end, rel):
    """Whether a receiver call's receiver is a bare local
    whose declared type is a bare name with more than one
    production definition that the file's own imports do not
    resolve (seam round 27, protest P9): the recorded limit's
    own case — such a name is NOT counted — so a judgement
    that cannot key the receiver to one definition abstains
    rather than deliver the other definition's judgement.
    The receiver's declared type is read from the item's
    parameter list or the local's annotation, in the file
    standing at `rel`, whose reachable modules decide the
    name where they can (see _resolve_bare)."""
    recv = body[:recv_end]
    m = re.search(r"(\w+)\s*$", recv)
    if not m:
        return False
    if m.start() > 0 and recv[m.start() - 1] == ".":
        return False
    name = m.group(1)
    decl = None
    for pname, ptype in _param_list(sig):
        if pname == name:
            decl = ptype
            break
    if decl is None:
        lm = re.search(r"\blet\s+(?:mut\s+)?" + re.escape(name) + r"\s*:\s*([^=;]+)", body)
        if lm:
            decl = lm.group(1).strip()
    if decl is None:
        return False
    dm = re.fullmatch(r"(\w+)", decl.strip())
    if not dm:
        return False
    if len(TYPE_LOCS.get(dm.group(1), [])) <= 1:
        return False
    return _resolve_bare(dm.group(1), rel) is None


def _inline_mod_spans(code):
    """The (start, end) brace spans of the inline modules in
    `code`: the file's module scopes below its top level."""
    spans = []
    for m in re.finditer(r"\bmod\s+(\w+)\s*\{", code):
        brace = m.end() - 1
        spans.append((brace, _brace_match(code, brace)))
    return spans

def _scope_key(spans, pos):
    """The identity of the innermost inline-module scope
    containing pos (its opening brace), or None for the file's
    top level."""
    best = None
    for a, b in spans:
        if a < pos < b and (best is None or b - a < best[1] - best[0]):
            best = (a, b)
    return best[0] if best is not None else None

def _scope_chain(spans, pos):
    """The scope chain of a use at pos: the file's top level
    (None) and every ancestor inline module of the use."""
    chain = {None}
    for a, b in spans:
        if a < pos < b:
            chain.add(a)
    return chain

def _defs_in_scopes(code, spans):
    """The file's self-definitions, each attributed to its
    scope in Rust's own model (seam round 5, protest P4;
    completed seam round 6, protest P5): (free function defs,
    method defs, type defs) as (key, scope) lists, over the
    scopes of _scope_spans — inline modules AND item bodies.
    A definition inside a function body is that body's item
    and exempts only uses inside it (see wrapper_uses)."""
    fn_defs, meth_defs, type_defs = [], [], []
    for name, tname, start in _def_positions(code):
        if tname is None:
            fn_defs.append((name, _scope_key_of(spans, start)))
        else:
            tident = tname
            meth_defs.append(((tident, name), _scope_key_of(spans, start)))
    for m in re.finditer(r"\b(?:struct|enum|union)\s+(\w+)", code):
        type_defs.append((m.group(1), _scope_key_of(spans, m.start())))
    for m in re.finditer(r"\btype\s+(\w+)\s*(?:<[^;{]*>)?\s*=", code):
        type_defs.append((m.group(1), _scope_key_of(spans, m.start())))
    return fn_defs, meth_defs, type_defs

def _def_positions(code):
    """Every function and method definition in `code` as
    (name, defining type or None, offset of the `fn` keyword) —
    typed_items' scan, carrying positions for the scope
    computation."""
    spans = impl_spans(code)
    out = []
    for m in re.finditer(r"\bfn\s+(\w+)", code):
        brace = code.find("{", m.end())
        semi = code.find(";", m.end())
        if brace < 0 or (0 <= semi < brace):
            continue
        tname = None
        for a, b, t in spans:
            if a < m.start() < b:
                tname = t
                break
        out.append((m.group(1), tname, m.start()))
    return out

def _generic_params(sig, name):
    """The generic type parameter names an item declares, from
    the `<...>` after its name in its signature text (lifetimes
    and const parameters are not type parameters)."""
    m = re.match(r"\s*fn\s+" + re.escape(name) + r"\s*<", sig)
    if not m:
        return []
    start = m.end() - 1
    depth, j = 1, start + 1
    while j < len(sig) and depth:
        if sig[j] == "<":
            depth += 1
        elif sig[j] == ">" and sig[j - 1] != "-":
            depth -= 1
        j += 1
    inner = sig[start + 1:j - 1]
    out = []
    for part in _split_top_commas(inner):
        part = part.strip()
        if not part or part.startswith("'") or part.startswith("const "):
            continue
        pm = re.match(r"(\w+)", part)
        if pm:
            out.append(pm.group(1))
    return out

def _param_list(sig):
    """An item's parameters as (name or None, type text): the
    first parenthesised group of the signature, split on
    top-level commas; a `self` parameter carries name None."""
    i = sig.find("(")
    if i < 0:
        return []
    end = _delim_match(sig, i, "(", ")")
    out = []
    for part in _split_top(sig[i + 1:end - 1]):
        part = part.strip()
        if not part:
            continue
        if re.match(r"^(?:&\s*(?:mut\s+)?|mut\s+)?self\b", part):
            out.append((None, "Self"))
            continue
        pm = re.match(r"^(?:mut\s+)?(\w+)\s*:\s*(.+)$", part, re.S)
        if pm:
            out.append((pm.group(1), pm.group(2).strip()))
        else:
            out.append((None, part))
    return out

def _call_args(body, open_idx):
    """The argument texts of the call whose argument list opens
    at open_idx in `body`, split on top-level commas."""
    end = _delim_match(body, open_idx, "(", ")")
    return _split_top(body[open_idx + 1:end - 1])

def _param_owned_to_exit(body, pname):
    """A by-value generic parameter is owned to a scope exit
    (seam round 6, protest P6(a)) — held in a binding, stored,
    returned, moved into another call, spelled in `drop(...)`
    or a method call, or simply never consumed — in every
    case but one: a parameter whose every occurrence is a
    borrow (`&pname`, `&mut pname`) is consumed by reference
    alone and is not counted as dropped by this item."""
    occ = list(re.finditer(r"\b" + re.escape(pname) + r"\b", body))
    if not occ:
        return True
    for m in occ:
        before = body[:m.start()].rstrip()
        if before.endswith("&"):
            continue
        return True
    return False

def compute_generic_uses(codes, production_rels):
    """The generic-instantiation uses (seam round 5, protest P5,
    arm (a); completed seam round 6, protest P6): an item with
    a by-value generic parameter the item owns to a scope exit
    counts as a wrapper use IN THE ITEM'S FILE when any
    production instantiation of the item supplies a wrapper
    type for that parameter. Instantiation supply is computed
    to a FIXED POINT through generic-to-generic hops: when a
    call site supplies a caller-generic parameter to a
    registered generic item, every wrapper type supplied to
    the CALLER for that parameter is supplied to the callee.
    The method arm indexes arguments excluding the self
    parameter and resolves temporary and associated-path
    receivers of the defining type. Results fill
    GENERIC_USES, keyed by the item's file."""
    all_items = {}  # (rel, name, tname) -> {pname: arg index}
    dropping = {}  # (rel, name, tname) -> [pname]
    for rel in production_rels:
        for name, tname, sig, body, _off in typed_items(codes[rel]):
            gens = _generic_params(sig, name)
            if not gens:
                continue
            params = _param_list(sig)
            entry = {}
            for idx, (pname, ptype) in enumerate(params):
                if pname is None or _det_type(ptype) not in gens:
                    continue
                if ptype.strip().startswith("&"):
                    continue
                arg_idx = idx
                if tname is not None and params and params[0][0] is None:
                    arg_idx = idx - 1
                entry[pname] = arg_idx
                if _param_owned_to_exit(body, pname):
                    dropping.setdefault((rel, name, tname), []).append(pname)
            if entry:
                all_items[(rel, name, tname)] = entry
    if not all_items:
        return
    supply = {key: {p: set() for p in entry} for key, entry in all_items.items()}
    edges = []  # ((callee key, callee param), (caller key, caller param))
    for rel in production_rels:
        code = codes[rel]
        _set_std_bind_ctx(rel)
        items = typed_items(code)
        for name, tname, sig, body, _off in items:
            RENAME_CTX.clear()
            for local, _scope, desc in FILE_RENAMES.get(rel, []):
                RENAME_CTX[local] = desc
            caller_key = (rel, name, tname)
            caller_gens = {}
            if caller_key in all_items:
                for pname in all_items[caller_key]:
                    caller_gens[pname] = pname
            rmap = _receiver_types_full(tname, sig, body, rel=rel)
            for (grel, gname, gtname), entry in sorted(all_items.items()):
                calls = []  # (args list) for this callee in this item
                if gtname is None:
                    spellings = [gname] + [local for local, _s, desc in FILE_RENAMES.get(rel, []) if desc[0] == "free" and desc[1] == gname]
                    for cm in re.finditer(r"\b(" + "|".join(re.escape(s) for s in spellings) + r")\s*(?:::|::\s*<|\()", body):
                        if cm.start() > 0 and body[cm.start() - 1] == ".":
                            continue
                        head = body[max(0, cm.start() - 4):cm.start()]
                        if head.endswith("fn "):
                            continue
                        paren = body.find("(", cm.start())
                        if paren < 0:
                            continue
                        calls.append(_call_args(body, paren))
                else:
                    for cm in re.finditer(r"\." + re.escape(gname) + r"\s*\(", body):
                        rt = _expr_type_at(body, cm.start(), rmap)
                        if rt != gtname:
                            continue
                        calls.append(_call_args(body, body.find("(", cm.start())))
                    # The spelled-callee arm reads a turbofish
                    # segment standing on the type or on the
                    # method alike (seam round 20, protest P6):
                    # `Type::<args>::name(` and
                    # `Type::name::<args>(` are the spellings a
                    # generic supply is written in, and the
                    # plain arm's search missed both.
                    for cm in re.finditer(r"\b" + re.escape(_disp(gtname)) + r"(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*::\s*" + re.escape(gname) + r"(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*\(", body):
                        calls.append(_call_args(body, cm.end() - 1))
                for args in calls:
                    for pname, arg_idx in entry.items():
                        if arg_idx < 0 or arg_idx >= len(args):
                            continue
                        arg = args[arg_idx].strip()
                        vm = re.fullmatch(r"(?:mut\s+)?(\w+)", arg)
                        if vm and vm.group(1) in caller_gens:
                            edges.append(((grel, gname, gtname), pname, caller_key, vm.group(1)))
                            continue
                        at = _expr_type_at(args[arg_idx], len(args[arg_idx]), rmap)
                        if at in WRAPPER_TYPES:
                            supply[(grel, gname, gtname)][pname].add(at)
    changed = True
    while changed:
        changed = False
        for (ckey, cpname, caller_key, caller_pname) in edges:
            src = supply.get(caller_key, {}).get(caller_pname, set())
            dst = supply[ckey][cpname]
            if not src <= dst:
                dst |= src
                changed = True
    for (grel, gname, gtname), pnames in sorted(dropping.items()):
        for pname in pnames:
            for at in sorted(supply[(grel, gname, gtname)][pname]):
                entry = (f"{gname} (generic parameter instantiated with {_disp(at)})",
                         WRAPPER_TYPE_HOME.get(at, "?"))
                GENERIC_USES.setdefault(grel, [])
                if entry not in GENERIC_USES[grel]:
                    GENERIC_USES[grel].append(entry)

def _impl_generic_params(code, brace):
    """The generic parameter names of the impl block whose
    body opens at `brace` (seam round 24, protest P4): the
    names the impl's own generics list declares, lifetimes
    and const parameters aside."""
    for m in re.finditer(r"\bimpl\b", code):
        b = code.find("{", m.end())
        semi = code.find(";", m.end())
        if b < 0 or (0 <= semi < b) or b != brace:
            continue
        header = code[m.end():b].lstrip()
        if not header.startswith("<"):
            return set()
        end = _angle_match(header, 0)
        out = set()
        for part in _split_top_commas(header[1:end - 1]):
            part = part.strip()
            if not part or part.startswith("'") or part.startswith("const "):
                continue
            pm = re.match(r"(\w+)", part)
            if pm:
                out.add(pm.group(1))
        return out
    return set()


def _impl_kind_for(rel, code, brace, tr, trait_paths):
    """The impl kind of a trait impl (seam round 24,
    protest P4): the trait's own identity — its full module
    path and name, the item the spelled path denotes — not
    its bare name, so two traits of one name in two inline
    modules of one file are two kinds, as `<Type as
    a::Tr>` and `<Type as b::Tr>` are two items. The
    spelled path in the impl header is matched against the
    production trait definitions by its suffix; where the
    spelling determines no one definition, the definition
    in the impl's own file stands, then the crate's only
    definition, and failing all of those the bare name
    stands as it stood before this round."""
    if tr is None:
        return None
    cand = trait_paths.get(tr, set())
    header = None
    for m in re.finditer(r"\bimpl\b", code):
        b = code.find("{", m.end())
        semi = code.find(";", m.end())
        if b < 0 or (0 <= semi < b) or b != brace:
            continue
        header = code[m.end():b]
        break
    segs = []
    if header is not None and " for " in header:
        tpart = header.split(" for ")[0]
        tpart = re.sub(r"<[^>]*>", "", tpart)
        segs = [s.strip().split()[-1] for s in tpart.split("::") if s.strip() and s.strip().split()]
    if segs:
        stripped = segs[1:] if segs[0] == "crate" else segs
        matches = {fp for fp, _fr in cand if fp.split("::")[-len(stripped):] == stripped}
        if len(matches) == 1:
            return matches.pop()
        if len(matches) > 1:
            return "::".join(stripped)
    if len(cand) == 1:
        return next(iter(cand))[0]
    same = {fp for fp, fr in cand if fr == rel}
    if len(same) == 1:
        return same.pop()
    return tr


def compute_return_projections(codes, production_rels):
    """The return-packaging projections of every production
    item (seam round 20, protest P5): for each item whose
    return expressions place a field projection in a
    packaging position, the (hit, tuple index path) pairs
    _return_projection_positions judges in the item's own
    file, recorded by the item's IDENTITY — its defining
    file, its defining type for a method, and its name —
    in RETURN_PROJECTIONS: the caller-side record the
    returned-bound-value step consults, since the step's
    judgement is made in the CALLER's file, whose text the
    item's own file never sees (the round-18 step,
    same-file by construction, could not judge a helper
    defined in one file and destructured in another).
    Keyed by bare name the table merged every production
    definition of a name into one entry, and the
    caller-side arm expelled a caller of a plain same-named
    helper on another file's helper's entry — a false
    expulsion (seam round 22, protest P5). Computed once
    the field tables stand, beside compute_generic_uses."""
    FN_VALUE_FROM.clear()
    FREE_FN_FROM.clear()
    FIELD_FROM.clear()
    RETURN_PROJECTIONS.clear()
    PROJECTION_IDENTITIES.clear()
    BLANKET_PROJECTION_IDENTITIES.clear()
    trait_paths = {}
    for trel in production_rels:
        tcode = codes[trel]
        for _ta, _tb, _tn in trait_spans(tcode):
            full = "::".join(p for p in [FILE_MODULES.get(trel, ""), *_mod_chain_at(tcode, _ta), _tn] if p)
            trait_paths.setdefault(_tn, set()).add((full, trel))
    fnames = {f for (_t, f) in FIELD_WRAPPERS}
    if not fnames and not WRAPPERS_FREE and not WRAPPERS_METH and not WRAPPER_VALUES:
        # The walk also records a wrapper standing directly
        # as a packaging element (seam round 24, protest
        # P5), which stands in no field table: an empty
        # field-carriage table no longer ends the walk
        # before it starts.
        return
    fre = re.compile(r"\.(?:" + ("|".join(sorted((re.escape(f) for f in fnames), key=len, reverse=True)) if fnames else r"(?!)") + r")\b")
    # The walk's direct-element judgement (seam round 24,
    # protest P5): an item whose return packaging carries a
    # wrapper standing directly as an element mentions the
    # wrapper's name, not a carried field's, so the field
    # gate alone would never admit it to the walk.
    wnames = set(WRAPPERS_FREE) | {n for (_t, n) in WRAPPERS_METH} | set(WRAPPER_VALUES)
    wre = re.compile(r"(?:::|\b)(?:" + "|".join(sorted((re.escape(n) for n in wnames), key=len, reverse=True)) + r")\b") if wnames else None
    for rel in production_rels:
        code = codes[rel]
        # A const or static initialised by a `from` path
        # value (seam round 31, protest P7): the item is a
        # binding declared at a function type, exactly as a
        # let binding is, and a call through its name
        # constructs by its declared argument and return
        # texts, in its own file and across files alike —
        # recorded here, beside the return-projection walk
        # that already visits every production file.
        for _cm31 in re.finditer(r"\b(?:const|static)\s+(\w+)\s*:\s*([^=;]+?)\s*=\s*(?:<.*>::\s*from|(?:\w+\s*::\s*)*\w+\s*::\s*from)\s*;", code, re.S):
            _rt31 = _fn_value_return_text(_cm31.group(2))
            if _rt31 is not None:
                FN_VALUE_FROM[_cm31.group(1)] = _rt31
        # A free function returning a `from` path value,
        # and a struct field a construction initialises
        # from one (seam round 32, protest P2): the
        # return and field positions, recorded beside
        # the const/static record — the function by its
        # (file, name), the field by its (type, field) —
        # each with the denoted Self and the declared
        # return a call through the position stands at.
        for _iname32, _itname32, _isig32, _ibody32, _ioff32 in typed_items(code):
            if _itname32 is not None:
                continue
            _fself32 = None
            for _e32 in _return_exprs(_ibody32):
                _fself32 = _from_path_self32(_e32)
                if _fself32 is not None:
                    break
            if _fself32 is not None:
                _frt32 = _fn_value_return_text(_return_type(_isig32) or "")
                if _frt32 is not None:
                    FREE_FN_FROM[(rel, _iname32)] = (_fself32, _frt32)
        for _sm32 in re.finditer(r"\b(\w+)\s*\{", code):
            _bend32 = _brace_match(code, _sm32.end() - 1)
            if _bend32 < 0:
                continue
            _sident32 = _type_ident_at(rel, code, _sm32.group(1), _sm32.start())
            if _sident32 is None:
                continue
            for _field32, _init32 in _struct_literal_fields32(code[_sm32.end():_bend32 - 1]):
                _fself32 = _from_path_self32(_init32)
                if _fself32 is None:
                    continue
                _fdecl32 = _field_decl_text(_sident32, _field32)
                if _fdecl32 is None:
                    continue
                _frt32 = _fn_value_return_text(_fdecl32)
                if _frt32 is not None:
                    FIELD_FROM[(_sident32, _field32)] = (_fself32, _frt32)
        RENAME_CTX.clear()
        for local, _scope, desc in FILE_RENAMES.get(rel, []):
            RENAME_CTX[local] = desc
        _set_std_bind_ctx(rel)
        _tspans = trait_spans(code)
        _ispans = _impl_trait_spans(code)
        for name, tname, sig, body, _off in typed_items(code):
            # The identity completed (seam round 23,
            # protest P5): the item's module path within
            # its defining file joins the key, and for a
            # method its impl kind — inherent (None) or the
            # trait it implements — so two free functions
            # in different inline modules of one file, and
            # an inherent and a trait method of one type,
            # no longer merge under one key.
            chain = _mod_chain_at(code, _off)
            implkind = None
            blanket_param = None
            trait_bare = None
            if tname is not None:
                for _tr, _ty, _ba, _bb in _ispans:
                    if _ba < _off < _bb:
                        trait_bare = _tr
                        implkind = _impl_kind_for(rel, code, _ba, _tr, trait_paths)
                        if _tr is not None and _ty == tname and tname in _impl_generic_params(code, _ba):
                            blanket_param = tname
                        break
            else:
                for _ta, _tb, _tn in _tspans:
                    if _ta < _off < _tb:
                        implkind = "::".join(p for p in [FILE_MODULES.get(rel, ""), *_mod_chain_at(code, _ta), _tn] if p)
                        break
            # A blanket impl's identity (seam round 24,
            # protest P4): the impl is keyed under its
            # generic parameter, an identity no concrete
            # caller can spell — the projections are
            # recorded instead under each concrete type the
            # blanket's bound is satisfied by, as the
            # trait-yield arm's blanket attribution already
            # computes satisfaction; where no concrete type
            # satisfies the bound, no identity is recorded
            # and the definition stands in
            # BLANKET_PROJECTION_IDENTITIES, whose callers
            # the caller arm refuses by name.
            if blanket_param is not None:
                bounds = _blanket_impl_bounds(code).get(trait_bare, set())
                concrete = sorted(ty for ty, trs in TRAIT_IMPLS.items() if bounds and bounds <= trs)
                if concrete:
                    key_tnames = concrete
                    for ct in concrete:
                        PROJECTION_IDENTITIES.setdefault(name, set()).add((rel, chain, ct, implkind))
                else:
                    key_tnames = []
                    BLANKET_PROJECTION_IDENTITIES.setdefault(name, set()).add((rel, chain, blanket_param, implkind))
            else:
                key_tnames = [tname]
                PROJECTION_IDENTITIES.setdefault(name, set()).add((rel, chain, tname, implkind))
            if not any(fre.search(e) or (wre is not None and wre.search(e)) for e in _return_exprs(body)):
                continue
            rmap = _receiver_types_full(tname, sig, body, rel=rel)
            for hit, path in _return_projection_positions(body, rmap, rel):
                entry = (hit, path)
                for kt in key_tnames:
                    lst = RETURN_PROJECTIONS.setdefault((rel, chain, kt, implkind, name), [])
                    if entry not in lst:
                        lst.append(entry)


def _pattern_binds31(pat, name):
    """Whether pattern `pat` binds `name` (seam round 31,
    protest P2): a plain binding, a `name @ sub` binding, a
    tuple / array / parenthesised pattern binding it in an
    element, a tuple-struct pattern binding it in a
    position, a struct pattern binding it as a field or in
    a field's subpattern, or an or-pattern binding it in an
    alternative — the binding forms the language's pattern
    grammar gives, read at the pattern's own structure."""
    pat = pat.strip()
    pat = re.sub(r"^(?:ref\s+|mut\s+)+", "", pat).strip()
    if not pat or pat == "_" or pat.startswith(".."):
        return False
    _d = 0
    _parts = []
    _cur = ""
    _orp = False
    for _c in pat:
        if _c in "(<[{":
            _d += 1
        elif _c in ")>]}":
            _d -= 1
        if _c == "|" and _d == 0:
            _parts.append(_cur)
            _cur = ""
            _orp = True
        else:
            _cur += _c
    if _orp:
        _parts.append(_cur)
        return any(_pattern_binds31(_p, name) for _p in _parts)
    _am = re.match(r"^(\w+)\s*@\s*(.+)$", pat, re.S)
    if _am:
        return _am.group(1) == name or _pattern_binds31(_am.group(2), name)
    if re.fullmatch(r"\w+", pat):
        return pat == name
    if pat.startswith("(") and pat.endswith(")"):
        return any(_pattern_binds31(_p, name) for _p in _split_top(pat[1:-1]))
    if pat.startswith("[") and pat.endswith("]"):
        return any(_pattern_binds31(_p, name) for _p in _split_top(pat[1:-1]))
    _sm = re.match(r"^(?:\w+\s*::\s*)*\w+(?:\s*::<[^>]*>)?\s*\{(.*)\}\s*$", pat, re.S)
    if _sm:
        for _f in _split_top(_sm.group(1)):
            _f = _f.strip()
            if not _f or _f == "..":
                continue
            _fm = re.match(r"^(?:r#)?(\w+)\s*(?::\s*(.+))?$", _f, re.S)
            if not _fm:
                continue
            if _fm.group(2):
                if _pattern_binds31(_fm.group(2), name):
                    return True
            elif _fm.group(1) == name:
                return True
        return False
    _tm = re.match(r"^(?:\w+\s*::\s*)*\w+(?:\s*::<[^>]*>)?\s*\((.*)\)\s*$", pat, re.S)
    if _tm:
        return any(_pattern_binds31(_p, name) for _p in _split_top(_tm.group(1)))
    return False


def _param_list_binds31(params, name):
    """Whether a parameter list binds `name` (seam round
    31, protest P2): a parameter whose pattern — the text
    before its top-level annotation colon — binds the
    name, as a plain parameter does. Read for signature
    parameters and closure parameters alike: the keying
    reads the binding, not the item kind."""
    for _p in _split_top(params):
        _p = _p.strip()
        if not _p:
            continue
        _d = 0
        _colon = -1
        for _i, _c in enumerate(_p):
            if _c in "(<[{":
                _d += 1
            elif _c in ")>]}":
                _d -= 1
            elif _c == ":" and _d == 0 and _p[_i - 1] != ":" and _p[_i + 1:_i + 2] != ":":
                _colon = _i
                break
        _pat = _p[:_colon].strip() if _colon > 0 else _p
        if _pattern_binds31(_pat, name):
            return True
    return False


def _closure_body_span31(body, start):
    """The (start, end) span of a closure's body in
    `body`, where `start` is the offset just past the
    parameter list's closing bar (seam round 31, protest
    P2): past an optional return-type annotation, a block
    body stands at its braces; an expression body stands
    to the first comma, semicolon or closing delimiter at
    its own depth."""
    i = start
    while i < len(body) and body[i].isspace():
        i += 1
    if body[i:i + 2] == "->":
        i += 2
        _d = 0
        while i < len(body):
            _c = body[i]
            if _c == "{" and _d == 0:
                break
            if _c in "(<[":
                _d += 1
            elif _c in ")>]":
                _d -= 1
            elif _c == ";" and _d == 0:
                return None
            i += 1
    while i < len(body) and body[i].isspace():
        i += 1
    if i < len(body) and body[i] == "{":
        return (i, _brace_match(body, i))
    _d = 0
    j = i
    while j < len(body):
        _c = body[j]
        if _c in "([{":
            _d += 1
        elif _c in ")]}":
            if _d == 0:
                break
            _d -= 1
        elif _c in ",;" and _d == 0:
            break
        j += 1
    return (i, j)


def wrapper_uses(code, rel=None):
    """The wrappers a file's production code uses, as
    (display name, defining file) pairs, under the criterion's
    use forms: a free wrapper is used where its name is called
    (`name(`, `name::<`) or named as a value — not at its own
    definition, not in a `use` statement, not after a `.` (a
    method call), and not where this file itself defines a
    function or method of that name or `let`-binds it (there the
    name is the file's own); a method wrapper is used where it
    is called by its defining type's associated path
    (`Type::name`), or by a receiver call `.name(` whose
    receiver's type is determinable over declared types to a
    fixed point (see _receiver_types_full and _expr_type_at),
    unless this file defines that very method; a wrapper type
    (a type carrying any derived wrapper method, the set closed
    under by-value field containment and production type
    aliases) is used where the file names it in production
    code — type position, associated path with any method
    name, or value construction — by the identity the spelled
    name denotes (seam round 6, protest P10): a spelled path
    denotes its own definition, and a bare name with more than
    one production definition denotes nothing determinable and
    is not counted; and a by-value generic parameter the file
    owns to a scope exit is used where a production
    instantiation of its item supplies a wrapper type (see
    compute_generic_uses). The self-defined exclusions — the
    defined names, methods and types — are computed over
    Rust's own scopes (seam round 5, protest P4; completed
    seam round 6, protest P5): function bodies and other item
    bodies are scopes, so a definition inside one exempts only
    uses inside it; a definition in an ancestor module exempts
    a use inside a nested module only when the nested module's
    own text imports it (`use super::*`, `use super::Name`, an
    ancestor glob); and a `use` binding in the use's own scope
    bringing a same-named item from a descendant or sibling
    scope of this file IS a self-definition."""
    _set_std_bind_ctx(rel)
    scan = blank_use_statements(code)
    items = typed_items(code)
    spans = _scope_spans(code)
    fn_defs, meth_defs, type_defs = _defs_in_scopes(code, spans)
    imports = _use_bindings(code, spans)
    renames = FILE_RENAMES.get(rel, []) if rel is not None else []

    def rename_at(pos):
        # The rename map in force at pos: the bindings of the
        # use's own scope chain (seam round 7, protest P1).
        keys = [s["key"] for s in _scopes_at(spans, pos)]
        out = {}
        for local, scope, desc in renames:
            if scope is None or scope in keys:
                out[local] = desc
        return out

    val_defs = [(m.group(1), _scope_key_of(spans, m.start())) for m in re.finditer(r"(?<!['*])\b(?:const|static)\s+(\w+)\s*[:=]", code)]

    def mod_imports(mod_span, name):
        # The nested module's own text imports `name` from an
        # ancestor: `use super::*`, `use super::Name`, or an
        # ancestor glob — the statement standing in the module
        # itself (or in a function body inside it is not the
        # module's own text, so only the module scope counts).
        for iname, iscope, segs in imports:
            if iscope != mod_span["key"]:
                continue
            if not segs or segs[0] != "super":
                continue
            if iname == name:
                return True
            if iname == "*" and all(s == "super" for s in segs):
                return True
        return False

    def import_denotes_local(name, segs):
        # A use binding whose source denotes a definition of
        # `name` inside THIS file in a descendant or sibling
        # scope: the source's parent segments name the module
        # chain of such a definition.
        if not segs or segs[0] == "crate":
            return False
        parent = [s for s in segs[:-1] if s != "super"]
        if segs and segs[0] == "super":
            parent = [s for s in segs[:-1] if s != "super"]
        for defs in (fn_defs, meth_defs, type_defs):
            for key, dscope in defs:
                dname = key[1] if isinstance(key, tuple) else key
                if dname != name or dscope is None:
                    continue
                chain = _mod_chain_of(spans, dscope)
                if parent and chain[-len(parent):] == parent:
                    return True
                if not parent and chain:
                    return True
        return False

    def exempt(defs, key, pos, name=None):
        if name is None:
            name = key[1] if isinstance(key, tuple) else key
        use_scopes = _scopes_at(spans, pos)
        use_keys = [s["key"] for s in use_scopes]
        for k, dscope in defs:
            if k != key:
                continue
            if dscope is None:
                mods = [s for s in use_scopes if s["kind"] == "mod"]
                if all(mod_imports(m, name) for m in mods):
                    return True
            elif dscope in use_keys:
                dspan = next(s for s in spans if s["key"] == dscope)
                if dspan["kind"] == "fn":
                    return True
                inner = [s for s in use_scopes if s["kind"] == "mod" and s["start"] > dspan["start"]]
                if all(mod_imports(m, name) for m in inner):
                    return True
        for iname, iscope, segs in imports:
            if iname != name:
                continue
            if iscope is not None and iscope not in use_keys:
                continue
            if import_denotes_local(name, segs):
                return True
        return False

    def bare_candidates(bare, pos):
        # The identities a bare naming of `bare` at pos can
        # denote (seam round 6, protests P5/P10 composed): a
        # definition in another file is always a candidate; a
        # definition in THIS file is a candidate only where
        # Rust could name it at pos — standing in the use's own
        # scope chain, or in an ancestor module the intervening
        # modules import it from. A dummy inside a sibling
        # function body, or an ancestor definition no nested
        # module imports, creates no ambiguity at this use.
        locs = TYPE_LOCS.get(bare, [])
        total = len(locs)
        out = set()
        use_scopes = _scopes_at(spans, pos)
        use_keys = [s["key"] for s in use_scopes]
        for (lrel, qual, _chain, _kind, skey) in locs:
            ident = bare if total == 1 else qual
            if rel is None:
                out.add(ident)
                continue
            if lrel != rel:
                home_mod = "::".join(qual.split("::")[:-1])
                if home_mod in _reachable_modules(rel):
                    out.add(ident)
                continue
            if skey is None:
                mods = [s for s in use_scopes if s["kind"] == "mod"]
                if all(mod_imports(mm, bare) for mm in mods):
                    out.add(ident)
            elif skey in use_keys:
                out.add(ident)
        return out

    let_bound = set(re.findall(r"\blet\s+(?:mut\s+)?(\w+)", code))

    uses = []
    if WRAPPER_WORD_RE is not None:
        for m in WRAPPER_WORD_RE.finditer(scan):
            name = m.group(1)
            if exempt(fn_defs, name, m.start()):
                continue
            if m.start() > 0 and scan[m.start() - 1] == ".":
                continue
            call_shaped = scan[m.end():m.end() + 1] == "(" or scan[m.end():m.end() + 3].startswith("::<")
            if call_shaped or name not in let_bound:
                uses.append((name, WRAPPERS_FREE[name]))
    for local, _scope, desc in renames:
        if desc[0] != "free" or desc[1] not in WRAPPERS_FREE:
            continue
        for m in re.finditer(r"\b" + re.escape(local) + r"\b", scan):
            if rename_at(m.start()).get(local) != desc:
                continue
            if exempt(fn_defs, local, m.start()):
                continue
            if m.start() > 0 and scan[m.start() - 1] == ".":
                continue
            call_shaped = scan[m.end():m.end() + 1] == "(" or scan[m.end():m.end() + 3].startswith("::<")
            if call_shaped or local not in let_bound:
                # A binding whose local name is the item's own
                # name is not a rename — a plain import of a
                # re-exported item, which _resolve_item now
                # chases, produces one — and counts under the
                # canonical entry, never as a second entry
                # renamed from itself.
                if local == desc[1]:
                    entry = (local, WRAPPERS_FREE[desc[1]])
                else:
                    entry = (local + " (renamed from " + desc[1] + ")", WRAPPERS_FREE[desc[1]])
                if entry not in uses:
                    uses.append(entry)
                break
    for vname, vhome in sorted(WRAPPER_VALUES.items()):
        for m in re.finditer(r"\b" + re.escape(vname) + r"\b", scan):
            if m.start() > 0 and scan[m.start() - 1] == ".":
                continue
            if exempt(val_defs, vname, m.start()):
                continue
            entry = (vname + " (wrapper value)", vhome)
            if entry not in uses:
                uses.append(entry)
            break
    for local, _scope, desc in renames:
        if desc[0] != "value":
            continue
        for m in re.finditer(r"\b" + re.escape(local) + r"\b", scan):
            if rename_at(m.start()).get(local) != desc:
                continue
            if exempt(val_defs, local, m.start()):
                continue
            if local == desc[1]:
                entry = (local + " (wrapper value)", desc[2])
            else:
                entry = (local + " (renamed from " + desc[1] + ") (wrapper value)", desc[2])
            if entry not in uses:
                uses.append(entry)
            break
    if rel is not None:
        # Path spellings through a renamed re-export (seam round
        # 7, protest P1, third spelling): the spelled path's last
        # segment is the alias; resolving the path names the
        # wrapper it denotes. Canonical spellings (last segment
        # already the wrapper's own name) are the arms above.
        for m in re.finditer(r"((?:\w+(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*::\s*)+)(\w+)", scan):
            if m.start() > 0 and scan[m.start() - 1] == ".":
                continue
            segs = [s.strip() for s in m.group(1).split("::") if s.strip() and not s.strip().startswith("<")] + [m.group(2)]
            desc = _resolve_item(rel, segs)
            if desc is not None and desc[0] in ("free", "value") and segs[-1] != desc[1]:
                if desc[0] == "free" and desc[1] in WRAPPERS_FREE:
                    entry = ("::".join(segs) + " (renamed from " + desc[1] + ")", WRAPPERS_FREE[desc[1]])
                    if entry not in uses:
                        uses.append(entry)
                elif desc[0] == "value":
                    entry = ("::".join(segs) + " (renamed from " + desc[1] + ") (wrapper value)", desc[2])
                    if entry not in uses:
                        uses.append(entry)
                continue
            if len(segs) >= 2:
                tdesc = _resolve_item(rel, segs[:-1])
                if tdesc is not None and tdesc[0] == "type" and segs[-2] != _disp(tdesc[1]) and (tdesc[1], segs[-1]) in WRAPPERS_METH:
                    entry = ("::".join(segs) + " (renamed from " + _disp(tdesc[1]) + "::" + segs[-1] + ")", WRAPPERS_METH[(tdesc[1], segs[-1])])
                    if entry not in uses:
                        uses.append(entry)
    for (tname, name), home in sorted(WRAPPERS_METH.items()):
        bare = _disp(tname)
        for m in re.finditer(r"\b" + re.escape(bare) + r"(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*::\s*" + re.escape(name) + r"\b", scan):
            # The identity the spelled path denotes: collect
            # the segments spelled before the type name.
            k = m.start()
            segs = []
            while k >= 2 and scan[k - 2:k] == "::":
                s = k - 2
                while s > 0 and (scan[s - 1].isalnum() or scan[s - 1] == "_"):
                    s -= 1
                segs.insert(0, scan[s:k - 2])
                k = s
            denoted = _ident_of(bare, segs)
            if denoted is not None and denoted != tname:
                continue
            if denoted is None and len(TYPE_LOCS.get(bare, [])) > 1:
                qsegs = tname.split("::")
                if not (len(qsegs) >= len(segs) + 1 and qsegs[-len(segs) - 1:-1] == segs):
                    continue
            if exempt(meth_defs, (tname, name), m.start(), name):
                continue
            entry = (bare + "::" + name, home)
            if entry not in uses:
                uses.append(entry)
            break
        for local, _scope, desc in renames:
            if desc[0] != "type" or desc[1] != tname:
                continue
            for m in re.finditer(r"\b" + re.escape(local) + r"(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*::\s*" + re.escape(name) + r"\b", scan):
                if rename_at(m.start()).get(local) != desc:
                    continue
                if exempt(meth_defs, (tname, name), m.start(), name):
                    continue
                if local == bare:
                    entry = (local + "::" + name, home)
                else:
                    entry = (local + "::" + name + " (renamed from " + bare + "::" + name + ")", home)
                if entry not in uses:
                    uses.append(entry)
                break
    for name, tname, sig, body, bstart in items:
        RENAME_CTX.clear()
        RENAME_CTX.update(rename_at(bstart + 1))
        rmap = _receiver_types_full(tname, sig, body, rel=rel)
        for cm in re.finditer(r"\.(\w+)\s*\(", body):
            for t in _deref_chain(_expr_type_at(body, cm.start(), rmap)):
                key = (t, cm.group(1))
                if key in WRAPPERS_METH and not exempt(meth_defs, key, bstart + cm.start(), cm.group(1)):
                    entry = (_disp(t) + "::" + cm.group(1), WRAPPERS_METH[key])
                    if entry not in uses:
                        uses.append(entry)
                    break
            _rtf = _expr_type_at(body, cm.start(), rmap)
            if _rtf is not None and not any((t, cm.group(1)) in PARAMS_METH for t in _deref_chain(_rtf)):
                for t in _deref_chain(_rtf):
                    if (t, cm.group(1)) in FIELD_WRAPPERS and (t, cm.group(1)) not in WRAPPERS_METH and not exempt(meth_defs, (t, cm.group(1)), bstart + cm.start(), cm.group(1)):
                        entry = FIELD_WRAPPERS[(t, cm.group(1))]
                        if entry not in uses:
                            uses.append(entry)
                        break
            _rt0 = _expr_type_at(body, cm.start(), rmap)
            if _rt0 is not None:
                _close0 = _delim_match(body, cm.end() - 1, "(", ")")
                _called0 = _called_through(body, _close0)
                if _called0:
                    for t in _deref_chain(_rt0):
                        if (t, cm.group(1)) in WRAPPER_YIELD_METH and not exempt(meth_defs, (t, cm.group(1)), bstart + cm.start(), cm.group(1)):
                            entry = (_disp(t) + "::" + cm.group(1) + " (wrapper-yielding method)", WRAPPER_YIELD_METH[(t, cm.group(1))])
                            if entry not in uses:
                                uses.append(entry)
                            break
                        if (t, cm.group(1)) in FIELD_WRAPPERS and not exempt(meth_defs, (t, cm.group(1)), bstart + cm.start(), cm.group(1)):
                            entry = FIELD_WRAPPERS[(t, cm.group(1))]
                            if entry not in uses:
                                uses.append(entry)
                            break
            _rt = _expr_type_at(body, cm.start(), rmap)
            if _rt is not None:
                _traits_rt = set(TRAIT_IMPLS.get(_disp(_rt), set()))
                for _bt in sorted(BLANKET_TRAITS):
                    if _blanket_satisfied(_bt, _rt, sig, name):
                        _traits_rt.add(_bt)
                for _tr in sorted(_traits_rt):
                    if (_disp(_rt), _tr, cm.group(1)) in TRAIT_OVERRIDES:
                        continue
                    if (_tr, cm.group(1)) in TRAIT_WRAPPERS and not exempt(meth_defs, (_rt, cm.group(1)), bstart + cm.start(), cm.group(1)) and not exempt(meth_defs, (_disp(_rt), cm.group(1)), bstart + cm.start(), cm.group(1)):
                        entry = (_tr + "::" + cm.group(1) + " (trait default method)", TRAIT_WRAPPERS[(_tr, cm.group(1))])
                        if entry not in uses:
                            uses.append(entry)
                    if (_tr, cm.group(1)) in TRAIT_YIELD and _called0 and not exempt(meth_defs, (_rt, cm.group(1)), bstart + cm.start(), cm.group(1)) and not exempt(meth_defs, (_disp(_rt), cm.group(1)), bstart + cm.start(), cm.group(1)):
                        entry = (_tr + "::" + cm.group(1) + " (wrapper-yielding trait method)", TRAIT_YIELD[(_tr, cm.group(1))])
                        if entry not in uses:
                            uses.append(entry)
    for name, tname, sig, body, bstart in items:
        RENAME_CTX.clear()
        RENAME_CTX.update(rename_at(bstart + 1))
        rmap = _receiver_types_full(tname, sig, body, rel=rel)
        for cm in re.finditer(r"\.(\w+)\s*\)\s*\(", body):
            _rt0 = _expr_type_at(body, cm.start(), rmap)
            if _rt0 is None:
                continue
            for t in _deref_chain(_rt0):
                if (t, cm.group(1)) in FIELD_WRAPPERS and not exempt(meth_defs, (t, cm.group(1)), bstart + cm.start(), cm.group(1)):
                    entry = FIELD_WRAPPERS[(t, cm.group(1))]
                    if entry not in uses:
                        uses.append(entry)
                    break
    # Pattern-bound projections of carried fields (seam
    # round 12, protests P3/P4): a variable a pattern binds
    # from a carried field or position, called in the body,
    # is a call through that position's projection.
    for name, tname, sig, body, bstart in items:
        for (tident, fkey), hit in sorted(FIELD_WRAPPERS.items()):
            for var in _pattern_carried_vars(body, tident, fkey, sig):
                if any(_is_call_through_at(body, vm.end()) for vm in re.finditer(r"\b" + re.escape(var) + r"\b", body)):
                    if hit not in uses:
                        uses.append(hit)
                    break
    # Bound locals and container projections (seam round 13,
    # protests P5 and P11): a wrapper-denoting value bound to
    # a local and then called is a use of the wrapper the
    # binding denotes — a carried field's projection, a
    # wrapper-yielding call's return, a wrapper path or value —
    # the binding read through the file's own binding tables;
    # and a call through a carried field's value-preserving
    # projection chain (an `unwrap()` / `expect()` / index
    # chain on the field's own value) is a use of the carried
    # wrapper, as a direct projection is.
    for name, tname, sig, body, bstart in items:
        RENAME_CTX.clear()
        RENAME_CTX.update(rename_at(bstart + 1))
        rmap = _receiver_types_full(tname, sig, body, rel=rel)
        for lm in re.finditer(r"\blet\s+(?:mut\s+)?(\w+)\s*(?::[^=;]+)?=\s*([^;]+);", body):
            var = lm.group(1)
            hit = _bound_local_hit(body, lm.start(2), lm.group(2), rmap, rel)
            if hit is None:
                continue
            rest = body[lm.end():]
            if any(_is_call_through_at(body, lm.end() + vm.end()) for vm in re.finditer(r"\b" + re.escape(var) + r"\b", rest)):
                if hit not in uses:
                    uses.append(hit)
                continue
            # The bound value returned by its item and the
            # item's result called through in this file (seam
            # round 14, protest P5): the call through the
            # helper's return is a call of the bound value.
            # Seam round 16 (protest P5): the returned bound
            # value may stand packaged — a tuple element of
            # the return, destructured by the caller's tuple
            # pattern and called there — and it may be
            # returned by a closure the item binds, the
            # closure's call standing in the item's place.
            if _result_called_through(scan, name, _return_positions_of(body, var)):
                if hit not in uses:
                    uses.append(hit)
                continue
            for cname, cbody in _let_closures(body):
                if _result_called_through(scan, cname, _return_positions_of(cbody, var)):
                    if hit not in uses:
                        uses.append(hit)
                    break
        # Array-pattern bindings of a carried field's value
        # (seam round 16, protest P3): a `let [f, ..] =
        # <projection>` binding binds the carried field's
        # elements, and a call of a bound element is a call
        # of the carried value, judged by the same
        # _bound_local_hit the simple binding is judged by.
        for lm in re.finditer(r"\blet\s+(\[[^\]]*\])\s*(?::[^=;]+)?=\s*([^;]+);", body):
            hit = _bound_local_hit(body, lm.start(2), lm.group(2), rmap, rel)
            if hit is None:
                continue
            rest = body[lm.end():]
            if any(any(_is_call_through_at(body, lm.end() + vm.end()) for vm in re.finditer(r"\b" + re.escape(v) + r"\b", rest)) for v in _pattern_var_names(lm.group(1))):
                if hit not in uses:
                    uses.append(hit)
        for (tident, fkey), hit in sorted(FIELD_WRAPPERS.items()):
            for fm in re.finditer(r"\." + re.escape(fkey) + r"\b", body):
                rt = _expr_type_at(body, fm.start(), rmap)
                if rt is None or tident not in _deref_chain(rt):
                    continue
                if _is_call_through_at(body, fm.end()):
                    if hit not in uses:
                        uses.append(hit)
                    break
    # Returned projections, caller side (seam round 20,
    # protest P5): a call in THIS file to an item whose
    # return packaging carries a field projection at a
    # path the caller's destructure reaches and calls
    # through is a use of the carried wrapper — the
    # returned-bound-value step's judgement, made where
    # the destructure stands, from the table
    # compute_return_projections recorded in the callee's
    # own file.
    if rel is not None:
        by_name = {}
        for key, entries in RETURN_PROJECTIONS.items():
            by_name.setdefault(key[4], []).append((key, entries))
        # A blanket impl with no resolved identity (seam
        # round 24, protest P4) records no projections, so
        # its name stands in no keyed entry — the loop must
        # still visit it, or its callers are judged as
        # nothing and the refusal below never stands.
        for bname in BLANKET_PROJECTION_IDENTITIES:
            by_name.setdefault(bname, [])
        for cname, keyed in sorted(by_name.items()):
            if not re.search(r"\b" + re.escape(cname) + r"\s*\(", scan) and not any(iname != cname and isegs and isegs[-1] == cname and re.search(r"\b" + re.escape(iname) + r"\s*\(", scan) for iname, _iscope, isegs in imports):
                continue
            identities = PROJECTION_IDENTITIES.get(cname, set())
            # A blanket impl the computation could not
            # resolve to a concrete identity (seam round 24,
            # protest P4): a call spelling the blanket's
            # trait on a concrete type the blanket supplies
            # to no nameable identity is refused by name in
            # the CHASE_FAILURES idiom — the refusal names
            # the blanket and the caller — rather than
            # judged as nothing, the silence the shadow
            # resolution abolished for calls standing
            # unrepaired in this table.
            blanket_ids = BLANKET_PROJECTION_IDENTITIES.get(cname, set())
            if blanket_ids:
                for cm in re.finditer(r"\b" + re.escape(cname) + r"\s*\(", scan):
                    if re.search(r"\bfn\s*$", scan[:cm.start()]):
                        continue
                    asm2 = re.search(r"<((?:\w+\s*::\s*)*\w+)\s+as\s+((?:\w+\s*::\s*)*\w+)\s*>\s*::\s*$", scan[:cm.start()])
                    if asm2:
                        typebare = asm2.group(1).split("::")[-1].strip()
                        trsegs = [s.strip() for s in asm2.group(2).split("::")]
                        mp2 = _resolve_modpath(rel, trsegs[:-1]) if len(trsegs) > 1 else FILE_MODULES.get(rel, "")
                        trfull = "::".join(p for p in [mp2, trsegs[-1]] if p)
                        for bid in sorted(blanket_ids):
                            if bid[3] == trfull or (bid[3] or "").split("::")[-1] == trsegs[-1]:
                                if not any(i[2] == typebare and i[3] == bid[3] for i in identities):
                                    msg = ("return-projection blanket impl unresolved: the blanket impl of `" + str(bid[3]) + "` in " + bid[0]
                                           + " is keyed under its generic parameter `" + str(bid[2]) + "` and supplies `" + cname
                                           + "` to no concrete type the computation can name, and the call in " + rel + " on `" + typebare
                                           + "` resolves to no one of them; the computation refuses by name rather than judge nothing (seam round 24, protest P4)")
                                    if msg not in CHASE_FAILURES:
                                        CHASE_FAILURES.append(msg)
                    else:
                        segs9 = _path_segs_before(scan, cm.start())
                        if segs9 and segs9[-1][:1].isupper():
                            for bid in sorted(blanket_ids):
                                if not any(i[2] == segs9[-1] for i in identities):
                                    msg = ("return-projection blanket impl unresolved: the blanket impl of `" + str(bid[3]) + "` in " + bid[0]
                                           + " is keyed under its generic parameter `" + str(bid[2]) + "` and supplies `" + cname
                                           + "` to no concrete type the computation can name, and the call in " + rel + " on `" + segs9[-1]
                                           + "` resolves to no one of them; the computation refuses by name rather than judge nothing (seam round 24, protest P4)")
                                    if msg not in CHASE_FAILURES:
                                        CHASE_FAILURES.append(msg)
            free_ids = {i for i in identities if i[2] is None and i[3] is None}
            free_homes = {i[0] for i in free_ids}
            free_homes |= {r for (r, n) in FREE_FN_DEFS if n == cname}
            # A bare call spelled through a RENAMED import
            # of the name (seam round 31, protest P4): the
            # call's local name is the import's alias, and
            # the call is judged at the definition the
            # import denotes — resolved through the import's
            # target exactly as the plain-name call below is
            # resolved through its binding — so the reaching
            # face expels and the plain face retains BY
            # DECISION, not by the call's invisibility to
            # the name-keyed scan.
            def _resolve_import31(isegs):
                mp = _resolve_modpath(rel, list(isegs[:-1]))
                cand = {i for i in free_ids if "::".join(p for p in [FILE_MODULES.get(i[0], ""), *i[1]] if p) == mp}
                if cand:
                    return cand
                desc = _resolve_item(rel, list(isegs))
                if desc is not None and desc[0] == "free":
                    cand = {i for i in free_ids if i[0] == desc[2]}
                    if len(cand) > 1:
                        fmod = FILE_MODULES.get(desc[2], "")
                        fsegs = fmod.split("::") if fmod else []
                        chain = tuple(mp.split("::")[len(fsegs):]) if mp and mp.split("::")[:len(fsegs)] == fsegs else ()
                        exact = {i for i in cand if i[1] == chain}
                        return exact if exact else cand
                    return cand
                return set()
            _ren31 = []
            for iname, iscope, isegs in imports:
                if iname == cname or not isegs or isegs[-1] != cname:
                    continue
                for rm31 in re.finditer(r"\b" + re.escape(iname) + r"\s*\(", scan):
                    if re.search(r"\bfn\s*$", scan[:rm31.start()]):
                        continue
                    if rm31.start() >= 1 and scan[rm31.start() - 1] == ".":
                        continue
                    if iscope is not None and iscope not in [s["key"] for s in _scopes_at(spans, rm31.start())]:
                        continue
                    _ren31.append((iname, rm31.start(), _resolve_import31(isegs)))
            if len(identities) > 1 or len(free_homes) > 1:
                # A name with more than one production
                # definition (seam round 22, protest P5;
                # completed seam round 23, protests P5 and
                # P6): the arm judges the call it RESOLVES to
                # an identity — the item's defining file, its
                # module path within that file, its defining
                # type and, for a method, its impl kind
                # (inherent, or the trait it implements).
                # A spelled path resolves through the
                # re-export chase to its defining file and
                # module; a `<Type as Trait>::name` spelling
                # resolves to the trait impl; a `Type::name`
                # spelling to the inherent impl; a receiver
                # call to the type's methods (the inherent
                # impl's where one stands, as the language
                # prefers it); and a bare call resolves
                # through any scoped `use` binding of the
                # name standing at the call site (seam round
                # 23, protest P6) before the caller's own
                # file's definition is assumed — a bare call
                # it cannot resolve fails in the
                # recorded-limit idiom (a named refusal in
                # CHASE_FAILURES) rather than merging the
                # definitions into one judgement, and never
                # silently as the caller's own.
                resolved = set()
                ambiguous = False
                for cm in re.finditer(r"\b" + re.escape(cname) + r"\s*\(", scan):
                    if re.search(r"\bfn\s*$", scan[:cm.start()]):
                        continue
                    if cm.start() >= 1 and scan[cm.start() - 1] == ".":
                        # A receiver call keyed by the
                        # RECEIVER'S OWN type (seam round 26,
                        # protest P4): where the receiver's
                        # type is determinable, the identities
                        # it resolves to are its own type's —
                        # through its Deref chain, in the
                        # language's order — and a same-named
                        # method on an unrelated type supplies
                        # nothing; where it is not determinable,
                        # the inherent identities stand as
                        # before.
                        _rid26 = None
                        for _in26, _it26, _is26, _ib26, _io26 in items:
                            if _io26 < cm.start() < _io26 + len(_ib26):
                                _rid26 = _expr_type_at(_ib26, cm.start() - _io26 - 1, _receiver_types_full(_it26, _is26, _ib26, rel=rel))
                                break
                        if _rid26 is not None:
                            # The bare-name match in the set
                            # below stands only where the name
                            # has one production definition
                            # (seam round 27, protest P9): a
                            # receiver resolved through the
                            # file's own bindings to one of two
                            # same-named types is judged by
                            # THAT type's identities — matching
                            # the other twin by its bare name
                            # re-merges what the binding
                            # decided, the false expulsion the
                            # protest charges.
                            _exact26 = {i for i in identities if i[2] is not None and any(i[2] == _ct26 or (len(TYPE_LOCS.get(_disp(i[2]), [])) <= 1 and _disp(i[2]) == _disp(_ct26)) for _ct26 in _deref_chain(_rid26))}
                            if _exact26:
                                _inh26 = {i for i in _exact26 if i[3] is None}
                                resolved |= (_inh26 if _inh26 else _exact26)
                            continue
                        if _ambiguous_receiver_abstention(_ib26, _is26, cm.start() - _io26 - 1, rel):
                            # The receiver's bare type name
                            # stands unresolved in this file
                            # (seam round 27, protest P9): the
                            # recorded limit abstains — the
                            # name is not counted — rather than
                            # merge every same-named definition
                            # into this call's judgement.
                            continue
                        mids = {i for i in identities if i[2] is not None}
                        inh = {i for i in mids if i[3] is None}
                        resolved |= (inh if inh else mids)
                        continue
                    asm = re.search(r"<((?:\w+\s*::\s*)*\w+)\s+as\s+((?:\w+\s*::\s*)*\w+)\s*>\s*::\s*$", scan[:cm.start()])
                    if asm:
                        # The spelled trait path resolved whole
                        # (seam round 24, protest P4): the
                        # identity it denotes is the trait at
                        # its own module path, on the spelled
                        # type — `<Type as a::Tr>` and
                        # `<Type as b::Tr>` are two items.
                        typebare = asm.group(1).split("::")[-1].strip()
                        trsegs = [s.strip() for s in asm.group(2).split("::")]
                        trname = trsegs[-1]
                        mp = _resolve_modpath(rel, trsegs[:-1]) if len(trsegs) > 1 else FILE_MODULES.get(rel, "")
                        trfull = "::".join(p for p in [mp, trname] if p)
                        exact = {i for i in identities if i[3] == trfull and i[2] == typebare}
                        if exact:
                            resolved |= exact
                        else:
                            bytr = {i for i in identities if i[3] == trfull}
                            if bytr:
                                resolved |= bytr
                            else:
                                byname = {i for i in identities if i[3] is not None and (i[3] == trname or i[3].split("::")[-1] == trname)}
                                if len(byname) == 1:
                                    resolved |= byname
                                elif len(byname) > 1:
                                    ambiguous = True
                        continue
                    segs = _path_segs_before(scan, cm.start())
                    if segs:
                        if segs[-1][:1].isupper():
                            resolved |= {i for i in identities if i[2] == segs[-1] and i[3] is None}
                        else:
                            mp = _resolve_modpath(rel, segs)
                            cand = {i for i in free_ids if "::".join(p for p in [FILE_MODULES.get(i[0], ""), *i[1]] if p) == mp}
                            if cand:
                                resolved |= cand
                            else:
                                desc = _resolve_item(rel, segs + [cname])
                                if desc is not None and desc[0] == "free":
                                    cand = {i for i in free_ids if i[0] == desc[2]}
                                    if len(cand) > 1:
                                        fmod = FILE_MODULES.get(desc[2], "")
                                        fsegs = fmod.split("::") if fmod else []
                                        chain = tuple(mp.split("::")[len(fsegs):]) if mp and mp.split("::")[:len(fsegs)] == fsegs else ()
                                        exact = {i for i in cand if i[1] == chain}
                                        resolved |= (exact if exact else cand)
                                    else:
                                        resolved |= cand
                        continue
                    # A bare name the caller's own item binds
                    # (seam round 30, protest P2): a parameter
                    # or a local binding of the name standing
                    # in the item the call stands in is the
                    # call's meaning — the call stands through
                    # the binding, at no production definition
                    # at all — and a bare name with no FREE
                    # production definition anywhere denotes
                    # no free item the projections record,
                    # whatever methods of the name unrelated
                    # types declare. Either way the site is
                    # decided by its own file's text and
                    # supplies no refusal: the refusal stands
                    # only where a bare call cannot be resolved
                    # to the definition it denotes among the
                    # free definitions that genuinely contest
                    # it.
                    _bound30 = False
                    for _in30, _it30, _is30, _ib30, _io30 in items:
                        if _io30 < cm.start() < _io30 + len(_ib30):
                            if re.search(r"(?:^|,|\()\s*(?:mut\s+)?" + re.escape(cname) + r"\s*:", _is30) or re.search(r"\blet\s+(?:mut\s+)?" + re.escape(cname) + r"\b", _ib30[:cm.start() - _io30 - 1]):
                                _bound30 = True
                            else:
                                # Every binding form binds
                                # (seam round 31, protest
                                # P2): the keying reads the
                                # BINDING, not the item kind
                                # — a signature parameter
                                # binding the name by pattern,
                                # a destructured let binding
                                # it by pattern before the
                                # site, and a closure
                                # parameter binding it in a
                                # closure whose body encloses
                                # the site, bind as a plain
                                # let and a plain signature
                                # parameter bind. A binding
                                # standing after the site, or
                                # in a sibling item, supplies
                                # no exemption.
                                _site31 = cm.start() - _io30
                                _sig31 = _is30[_is30.find("(") + 1:_delim_match(_is30, _is30.find("("), "(", ")") - 1] if "(" in _is30 else ""
                                if _param_list_binds31(_sig31, cname):
                                    _bound30 = True
                                if not _bound30:
                                    for _lm31 in re.finditer(r"\blet\s+(?:mut\s+)?([^=;:]+?)\s*(?::[^=;]+)?=", _ib30[:_site31]):
                                        if _pattern_binds31(_lm31.group(1), cname):
                                            _bound30 = True
                                            break
                                if not _bound30:
                                    for _cp31 in re.finditer(r"\|([^|]*)\|", _ib30):
                                        if _cp31.end() > _site31:
                                            break
                                        if not _param_list_binds31(_cp31.group(1), cname):
                                            continue
                                        _span31 = _closure_body_span31(_ib30, _cp31.end())
                                        if _span31 is not None and _span31[0] <= _site31 < _span31[1]:
                                            _bound30 = True
                                            break
                            break
                    if _bound30:
                        continue
                    if not free_ids and not any(_n30 == cname for (_r30, _n30) in FREE_FN_DEFS):
                        continue
                    use_keys = [s["key"] for s in _scopes_at(spans, cm.start())]
                    bound_segs = None
                    for iname, iscope, isegs in imports:
                        if iname == cname and (iscope is None or iscope in use_keys):
                            bound_segs = isegs
                            break
                    if bound_segs is not None:
                        mp = _resolve_modpath(rel, list(bound_segs[:-1]))
                        cand = {i for i in free_ids if "::".join(p for p in [FILE_MODULES.get(i[0], ""), *i[1]] if p) == mp}
                        if cand:
                            resolved |= cand
                        else:
                            desc = _resolve_item(rel, list(bound_segs))
                            if desc is not None and desc[0] == "free":
                                cand = {i for i in free_ids if i[0] == desc[2]}
                                if len(cand) > 1:
                                    fmod = FILE_MODULES.get(desc[2], "")
                                    fsegs = fmod.split("::") if fmod else []
                                    chain = tuple(mp.split("::")[len(fsegs):]) if mp and mp.split("::")[:len(fsegs)] == fsegs else ()
                                    exact = {i for i in cand if i[1] == chain}
                                    resolved |= (exact if exact else cand)
                                else:
                                    resolved |= cand
                            else:
                                ambiguous = True
                        continue
                    own = {i for i in free_ids if i[0] == rel}
                    if own:
                        chain_at = _mod_chain_at(code, cm.start())
                        exact = {i for i in own if i[1] == chain_at}
                        if exact:
                            resolved |= exact
                        elif len(own) == 1:
                            resolved |= own
                        else:
                            ambiguous = True
                    else:
                        ambiguous = True
                for _ln31, _pos31, _ids31 in _ren31:
                    if _ids31:
                        resolved |= _ids31
                    else:
                        ambiguous = True
                if ambiguous:
                    # The refusal names every contesting
                    # definition at the computation's own
                    # identity (seam round 31, protest P3):
                    # file AND module path, with the defining
                    # type where the definition is a method —
                    # two definitions in two modules of one
                    # file name as two, never collapse to one.
                    _defs30 = sorted({i[0] + " (" + "::".join([*i[1], ((_disp(i[2]) + "::") if i[2] is not None else "") + cname]) + ")" for i in identities} | {h for h in free_homes if h not in {i[0] for i in identities}})
                    msg = ("return-projection name with more than one production definition: `"
                           + cname + "` is defined in " + ", ".join(_defs30)
                           + " and a bare call to it in " + rel + " resolves to no one of them; "
                           + "the computation refuses by name rather than merge the definitions' return projections into one judgement (seam round 22, protest P5)")
                    if msg not in CHASE_FAILURES:
                        CHASE_FAILURES.append(msg)
                    continue
                keyed = [(k, e) for k, e in keyed if (k[0], k[1], k[2], k[3]) in resolved]
            # The receiver-decided sites (seam round 29,
            # protest P1): a receiver call whose receiver's
            # type is determinable is judged by THAT type's
            # identities, at every identity count — the
            # round-26 receiver resolution above runs only
            # where a name has more than one definition, so
            # at one definition the arm merged the one
            # declared method's projections into every
            # receiver call of the name, and a file's
            # judgement turned on whether an unrelated file
            # declared the method at all. A determinable
            # receiver resolving to no one of the name's
            # identities decides its call against every
            # key; an undeterminable receiver, and every
            # non-receiver call, stands as before.
            _site29 = None
            if identities:
                _site29 = {}
                for cm in re.finditer(r"\b" + re.escape(cname) + r"\s*\(", scan):
                    if re.search(r"\bfn\s*$", scan[:cm.start()]):
                        continue
                    if cm.start() >= 1 and scan[cm.start() - 1] == ".":
                        _rid29 = None
                        for _in29, _it29, _is29, _ib29, _io29 in items:
                            if _io29 < cm.start() < _io29 + len(_ib29):
                                _rid29 = _expr_type_at(_ib29, cm.start() - _io29 - 1, _receiver_types_full(_it29, _is29, _ib29, rel=rel))
                                break
                        if _rid29 is not None:
                            _site29[cm.start()] = {i for i in identities if i[2] is not None and any(i[2] == _ct29 or (len(TYPE_LOCS.get(_disp(i[2]), [])) <= 1 and _disp(i[2]) == _disp(_ct29)) for _ct29 in _deref_chain(_rid29))}
                            continue
                    _site29[cm.start()] = None
            for key, entries in keyed:
                _allow29 = None
                _renpos31 = [(ln, lp) for (ln, lp, ids) in _ren31 if (key[0], key[1], key[2], key[3]) in ids]
                if _site29 is not None:
                    _allow29 = {s for s, ex in _site29.items() if ex is None or (key[0], key[1], key[2], key[3]) in ex}
                    if not _allow29 and not _renpos31:
                        continue
                for hit, path in entries:
                    _pos31 = (path == (), [path] if path else [], [path] if path and any(isinstance(s, tuple) for s in path) else [])
                    if _result_called_through(scan, cname, _pos31, _allow29) or any(_result_called_through(scan, ln, _pos31, {lp}) for ln, lp in _renpos31):
                        if hit not in uses:
                            uses.append(hit)
    for tname in sorted(WRAPPER_TYPES):
        bare = _disp(tname)
        for m in re.finditer(r"\b" + re.escape(bare) + r"\b", scan):
            k = m.start()
            segs = []
            while k >= 2 and scan[k - 2:k] == "::":
                s = k - 2
                while s > 0 and (scan[s - 1].isalnum() or scan[s - 1] == "_"):
                    s -= 1
                segs.insert(0, scan[s:k - 2])
                k = s
            if segs:
                denoted = _ident_of(bare, segs)
                if denoted is not None:
                    if denoted != tname:
                        continue
                else:
                    desc = _resolve_item(rel, segs + [bare]) if rel is not None else None
                    if desc is not None and desc[0] == "type":
                        if desc[1] != tname:
                            continue
                    elif segs[-1][:1].isupper():
                        # A same-named enum variant path, as below.
                        continue
                    elif len(TYPE_LOCS.get(bare, [])) > 1:
                        continue
            else:
                if len(TYPE_LOCS.get(bare, [])) > 1:
                    cands = bare_candidates(bare, m.start())
                    if tname not in cands:
                        continue
                    if sum(1 for c in cands if c in WRAPPER_TYPES) > 1:
                        continue
                if m.start() >= 2 and scan[m.start() - 2:m.start()] == "::":
                    seg = re.search(r"(\w+)::$", scan[:m.start()])
                    if seg and seg.group(1)[0].isupper():
                        # A same-named enum variant path:
                        # `Method::Console` names the variant of
                        # the file's own enum, not the wrapper
                        # type.
                        continue
            if exempt(type_defs, bare, m.start(), bare):
                continue
            entry = (bare + " (wrapper type)", WRAPPER_TYPE_HOME.get(tname, "?"))
            if entry not in uses:
                uses.append(entry)
            break
    for local, _scope, desc in renames:
        if desc[0] != "type" or desc[1] not in WRAPPER_TYPES:
            continue
        for m in re.finditer(r"\b" + re.escape(local) + r"\b", scan):
            if rename_at(m.start()).get(local) != desc:
                continue
            if m.start() >= 2 and scan[m.start() - 2:m.start()] == "::":
                seg = re.search(r"(\w+)::$", scan[:m.start()])
                if seg and seg.group(1)[0].isupper():
                    continue
            if exempt(type_defs, local, m.start(), local):
                continue
            if local == _disp(desc[1]):
                entry = (local + " (wrapper type)", WRAPPER_TYPE_HOME.get(desc[1], "?"))
            else:
                entry = (local + " (renamed from " + _disp(desc[1]) + ") (wrapper type)", WRAPPER_TYPE_HOME.get(desc[1], "?"))
            if entry not in uses:
                uses.append(entry)
            break
    for (trname, mname), home in sorted(TRAIT_WRAPPERS.items()):
        for m in re.finditer(r"\bas\s+(?:\w+\s*::\s*)*" + re.escape(trname) + r"\s*>\s*::\s*" + re.escape(mname) + r"\b", scan):
            _pre = scan[max(0, m.start() - 160):m.start()]
            _tm = re.search(r"((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*$", _pre)
            _tb = _tm.group(1).split("::")[-1].strip() if _tm else None
            if _tb is not None and (_tb, trname, mname) in TRAIT_OVERRIDES:
                _ti = _ident_of(_tb, [s.strip() for s in _tm.group(1).split("::")[:-1] if s.strip()])
                if _ti is not None:
                    _ti = _expand_alias_ident(_ti)
                if _ti is not None and (_ti, mname) in WRAPPERS_METH:
                    entry = (_disp(_ti) + "::" + mname, WRAPPERS_METH[(_ti, mname)])
                    if entry not in uses:
                        uses.append(entry)
                break
            entry = (trname + "::" + mname + " (trait default method)", home)
            if entry not in uses:
                uses.append(entry)
            break
    for (trname, mname), home in sorted(TRAIT_YIELD.items()):
        for m in re.finditer(r"\bas\s+(?:\w+\s*::\s*)*" + re.escape(trname) + r"\s*>\s*::\s*" + re.escape(mname) + r"\s*\(", scan):
            close = _delim_match(scan, m.end() - 1, "(", ")")
            if not _called_through(scan, close):
                continue
            _pre = scan[max(0, m.start() - 160):m.start()]
            _tm = re.search(r"((?:\w+\s*::\s*)*\w+)(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*$", _pre)
            _tb = _tm.group(1).split("::")[-1].strip() if _tm else None
            if _tb is not None and (_tb, trname, mname) in TRAIT_OVERRIDES:
                _ti = _ident_of(_tb, [s.strip() for s in _tm.group(1).split("::")[:-1] if s.strip()])
                if _ti is not None:
                    _ti = _expand_alias_ident(_ti)
                if _ti is not None and (_ti, mname) in WRAPPER_YIELD_METH:
                    entry = (_disp(_ti) + "::" + mname + " (wrapper-yielding method)", WRAPPER_YIELD_METH[(_ti, mname)])
                    if entry not in uses:
                        uses.append(entry)
                break
            entry = (trname + "::" + mname + " (wrapper-yielding trait method)", home)
            if entry not in uses:
                uses.append(entry)
            break
    for tname in sorted(SYS_DERIVED_TYPES):
        bare = _disp(tname)
        for m in re.finditer(r"\b" + re.escape(bare) + r"\b", scan):
            if m.start() > 0 and scan[m.start() - 1] == ".":
                continue
            if exempt(type_defs, bare, m.start(), bare):
                continue
            entry = (bare + " (sys-derived type)", SYS_DERIVED_TYPE_HOME.get(tname, "?"))
            if entry not in uses:
                uses.append(entry)
            break
    for vname, vhome in sorted(SYS_DERIVED_VALUES.items()):
        for m in re.finditer(r"\b" + re.escape(vname) + r"\b", scan):
            if m.start() > 0 and scan[m.start() - 1] == ".":
                continue
            if exempt(val_defs, vname, m.start()):
                continue
            entry = (vname + " (sys-derived value)", vhome)
            if entry not in uses:
                uses.append(entry)
            break
    if rel is not None:
        for m in re.finditer(r"((?:\w+(?:\s*::<(?:[^<>]|<[^<>]*>)*>)?\s*::\s*)*)(\w+)\s*\(", scan):
            if m.start() > 0 and scan[m.start() - 1] == ".":
                continue
            segs = [s.strip() for s in m.group(1).split("::") if s.strip() and not s.strip().startswith("<")]
            last = m.group(2)
            orig = None
            if segs:
                desc = _resolve_item(rel, segs + [last])
                if desc is not None and desc[0] == "free":
                    orig = desc[1]
            else:
                desc = rename_at(m.start()).get(last)
                if desc is not None and desc[0] == "free":
                    orig = desc[1]
                elif last in WRAPPER_YIELD_FREE:
                    orig = last
            if orig is None or orig not in WRAPPER_YIELD_FREE:
                continue
            close = _delim_match(scan, m.end() - 1, "(", ")")
            if not _called_through(scan, close):
                continue
            if exempt(fn_defs, last, m.start()):
                continue
            entry = (last + " (wrapper-yielding function)", WRAPPER_YIELD_FREE[orig])
            if entry not in uses:
                uses.append(entry)
    if rel is not None:
        for (tname, mname), mhome in sorted(WRAPPER_YIELD_METH.items()):
            for m in re.finditer(r"\b" + re.escape(_disp(tname)) + r"::" + re.escape(mname) + r"\s*\(", scan):
                close = _delim_match(scan, m.end() - 1, "(", ")")
                if not _called_through(scan, close):
                    continue
                if exempt(meth_defs, (tname, mname), m.start(), mname):
                    continue
                entry = (_disp(tname) + "::" + mname + " (wrapper-yielding method)", mhome)
                if entry not in uses:
                    uses.append(entry)
                break
    for fname, fhome in sorted(SYS_DERIVED_FNS.items()):
        for m in re.finditer(r"\b" + re.escape(fname) + r"\b", scan):
            if m.start() > 0 and scan[m.start() - 1] == ".":
                continue
            if exempt(fn_defs, fname, m.start()):
                continue
            entry = (fname + " (sys-derived function)", fhome)
            if entry not in uses:
                uses.append(entry)
            break
    for mname, mhome in sorted(MACRO_REACHING.items()):
        if mhome == rel:
            continue
        for m in re.finditer(r"(?:\w+\s*::\s*)*" + re.escape(mname) + r"\s*!", scan):
            entry = (mname + "! (macro whose expansion reaches sys, defined in " + mhome + " — the macro channel is unmodelled and refused for the pure set)", mhome)
            if entry not in uses:
                uses.append(entry)
            break
    if rel is not None:
        for entry in GENERIC_USES.get(rel, []):
            if entry not in uses:
                uses.append(entry)
    return uses

# The files whose only `mod` declaration in their parent chain is
# #[cfg(test)]-gated (seam round 4, protest P3), filled in once the
# raw texts are loaded, before the census loop runs: the
# production definition sees the parents' declarations, so a
# module its parent declares only for tests is test code, not
# production, however production-shaped its own text is.
TEST_GATED_FILES = set()
TEST_GATED_PARENTS = {}  # gated file -> the parents that declare it

def _brace_match(code, open_idx):
    """The offset one past the `}` matching the `{` at open_idx,
    counted on blanked text (braces in comments and literals are
    already blanked and cannot move the count)."""
    depth, j = 1, open_idx + 1
    while j < len(code) and depth:
        if code[j] == "{":
            depth += 1
        elif code[j] == "}":
            depth -= 1
        j += 1
    return j

def _path_attr_value(raw, blanked, decl_start):
    """The `#[path = "..."]` value on the attribute run
    immediately preceding the declaration at decl_start in
    `blanked`, or None (seam round 5, protest P6). The
    attribute's presence and its offsets are read on the
    blanked text — offset-preserving, and safe for bracket
    matching because a `]` inside the string is blanked there —
    while the string's contents are read from the raw text of
    the same attribute group, the blanker having erased them
    in the blanked form. An optional visibility qualifier
    (`pub`, `pub(crate)`, ...) between the attribute run and
    the `mod` keyword is stepped over first: the run precedes
    the whole declaration, qualifier included. The value is
    decoded as Rust reads a string literal (seam round 6,
    protest P7): a raw string at every hash count including
    zero, and a plain string's escapes decoded (`\\`, `\"`,
    and the hex and unicode escape forms), so the resolved target is
    the file rustc resolves."""
    i = decl_start
    j = i
    while j > 0 and blanked[j - 1].isspace():
        j -= 1
    if j > 0 and blanked[j - 1] == ")":
        depth, k = 1, j - 2
        while k >= 0 and depth:
            if blanked[k] == ")":
                depth += 1
            elif blanked[k] == "(":
                depth -= 1
            k -= 1
        if depth == 0 and k + 1 >= 3 and blanked[k - 2:k + 1] == "pub" and (k - 2 == 0 or not (blanked[k - 3].isalnum() or blanked[k - 3] == "_")):
            i = k - 2
    elif j >= 3 and blanked[j - 3:j] == "pub" and (j - 3 == 0 or not (blanked[j - 4].isalnum() or blanked[j - 4] == "_")):
        i = j - 3
    groups = []
    while True:
        j = i
        while j > 0 and blanked[j - 1].isspace():
            j -= 1
        if j >= 2 and blanked[j - 1] == "]":
            depth, k = 1, j - 2
            while k >= 0 and depth:
                if blanked[k] == "]":
                    depth += 1
                elif blanked[k] == "[":
                    depth -= 1
                k -= 1
            if depth:
                break
            start = k + 1
            if start >= 1 and blanked[start - 1] == "#":
                groups.append((start - 1, j))
                i = start - 1
                continue
        break
    for a, b in reversed(groups):
        if not re.search(r"\bpath\s*=", blanked[a:b]):
            continue
        if re.match(r"#\[\s*cfg_attr\s*\(", blanked[a:b]):
            # A cfg_attr's payload stands only where its
            # condition holds (seam round 37, protest
            # P8): the condition — the attribute's first
            # argument, read from the raw text at the
            # same span, as a cfg's spelled values are —
            # is evaluated under the one denotation
            # target BEFORE the payload is read; a
            # condition that does not hold, or that the
            # target does not decide (which _cfg_audit35
            # refuses by name), reads no payload here.
            _seg37 = raw[a:b]
            _open37 = _seg37.find("(")
            _d37 = 0
            _cut37 = len(_seg37)
            for _i37 in range(_open37 + 1, len(_seg37)):
                _ch37 = _seg37[_i37]
                if _ch37 in "([{":
                    _d37 += 1
                elif _ch37 in ")]}":
                    if _d37 == 0:
                        _cut37 = _i37
                        break
                    _d37 -= 1
                elif _ch37 == "," and _d37 == 0:
                    _cut37 = _i37
                    break
            _ev37 = globals().get("_cfg_eval34")
            if _ev37 is None or _ev37(_seg37[_open37 + 1:_cut37]) is not True:
                continue
        seg = raw[a:b]
        m = re.search(r"\bpath\s*=\s*", seg)
        if not m:
            continue
        rest = seg[m.end():]
        hm = re.match(r"r(#*)\"", rest)
        if hm:
            close = '"' + hm.group(1)
            k = rest.find(close, hm.end())
            if k >= 0:
                return rest[hm.end():k]
            continue
        if rest.startswith('"'):
            out, k = [], 1
            simple = {"n": "\n", "r": "\r", "t": "\t", "0": "\0", "\\": "\\", '"': '"', "'": "'"}
            while k < len(rest):
                ch = rest[k]
                if ch == '"':
                    break
                if ch == "\\" and k + 1 < len(rest):
                    e = rest[k + 1]
                    if e == "x" and k + 3 < len(rest) and re.fullmatch(r"[0-9a-fA-F]{2}", rest[k + 2:k + 4]):
                        out.append(chr(int(rest[k + 2:k + 4], 16)))
                        k += 4
                    elif e == "u" and k + 2 < len(rest) and rest[k + 2] == "{":
                        close = rest.find("}", k + 3)
                        if close > 0:
                            try:
                                out.append(chr(int(rest[k + 3:close].replace("_", ""), 16)))
                            except ValueError:
                                pass
                            k = close + 1
                        else:
                            k += 2
                    elif e == "\n":
                        k += 2
                        while k < len(rest) and rest[k] in " \t\r\n":
                            k += 1
                    elif e in simple:
                        out.append(simple[e])
                        k += 2
                    else:
                        out.append(e)
                        k += 2
                else:
                    out.append(ch)
                    k += 1
            return "".join(out)
    return None

def _module_decls(code):
    """Every `mod` declaration in `code` (blanked text) as
    (name, kind, start, body_span): kind is "file" for
    `mod name;` and "inline" for `mod name { ... }`, whose
    body_span is the brace block's (start, end)."""
    out = []
    for m in re.finditer(r"\bmod\s+(\w+)\s*(;|\{)", code):
        if m.group(2) == ";":
            out.append((m.group(1), "file", m.start(), None))
        else:
            brace = m.end() - 1
            out.append((m.group(1), "inline", m.start(), (brace, _brace_match(code, brace))))
    return out

def _child_base(rel):
    # The directory a file's own `mod` declarations resolve in:
    # `src/lib.rs` and `src/main.rs` declare the modules of `src/`
    # itself; a `src/bin/*.rs` crate root declares its file
    # modules beside the root, exactly as `src/main.rs` does
    # (seam round 5, W4); a `mod.rs` declares the modules of its
    # own folder; any other file `foo.rs` declares the modules
    # of `foo/`.
    if rel in ("src/lib.rs", "src/main.rs"):
        return "src"
    parts = rel.split("/")
    if len(parts) == 3 and parts[0] == "src" and parts[1] == "bin":
        return "src/bin"
    if parts[-1] == "mod.rs":
        return "/".join(parts[:-1])
    return "/".join(parts[:-1]) + "/" + parts[-1][:-3]

def _path_loaded_files(texts):
    """The files a `#[path]` declaration loads, as a set of
    target rels (seam round 14, protest P9): a `#[path]`
    value on a declaration at a file's top level resolves
    relative to the directory containing the declaring
    file, as the compiler resolves it — not relative to
    the declaring file's module directory; a value on a
    declaration inside an inline module resolves under
    that module's directory, as the module map already
    reads it. The set is what makes a loaded file's own
    children resolvable at the compiler's placement:
    they stand beside the loaded file itself, not in the
    directory its stem names."""
    loaded = set()
    for rel, text in texts.items():
        code = blank_comments_and_literals(text)
        mods = _module_decls(code)
        inlines = [(n, s, sp) for n, k, s, sp in mods if k == "inline"]
        fdir = posixpath.dirname(rel)
        base = _child_base(rel)
        for name, kind, start, _sp in mods:
            if kind != "file":
                continue
            pv = _path_attr_value(text, code, start)
            if pv is None:
                continue
            chain = [iv for iv in inlines if iv[2][0] < start < iv[2][1]]
            if not chain:
                loaded.add(posixpath.normpath(fdir + "/" + pv))
                continue
            chain.sort(key=lambda iv: iv[2][1] - iv[2][0], reverse=True)
            ctx = base
            for i2, (n, s, _s2) in enumerate(chain):
                ipv = _path_attr_value(text, code, s)
                if ipv is not None and i2 == 0:
                    ctx = fdir + "/" + ipv
                else:
                    ctx = ctx + "/" + (ipv if ipv is not None else n)
            loaded.add(posixpath.normpath(ctx + "/" + pv))
    return loaded

def _compiler_child_base(rel, path_loaded):
    """The directory a file's own `mod` declarations
    resolve in, as the compiler resolves them (seam round
    14, protest P9): _child_base's directory, except for
    a file loaded by a `#[path]` declaration, whose
    children the compiler resolves beside the file
    itself."""
    if rel in path_loaded:
        return posixpath.dirname(rel)
    return _child_base(rel)

def _mod_decl_targets(rel, name, pv, ctx, top_level):
    """The candidate target files of a file-module
    declaration (seam round 14, protest P9): with a
    `#[path]` value, the single file the compiler
    resolves — at a file's top level, the value relative
    to the directory containing the declaring file;
    inside an inline module, relative to that module's
    directory (`ctx`). Without one, the module's own
    name under `ctx`, as a file or a `mod.rs`. A target
    the compiler's resolution leaves outside the tree
    is a missing target, refused by name — never a model
    at a placement the compiler rejects."""
    if pv is not None:
        if top_level:
            return [posixpath.normpath(posixpath.dirname(rel) + "/" + pv)]
        return [posixpath.normpath(ctx + "/" + pv)]
    return [f"{ctx}/{name}.rs", f"{ctx}/{name}/mod.rs"]

def _compute_test_gated(raws_by_rel):
    decls = {}  # child rel -> [(parent rel, gated)]
    dead_decls = {}  # child rel -> [(parent rel, gated, cfg-false gated)] (seam round 36, protest P2)
    loaded = _path_loaded_files(raws_by_rel)
    for rel, text in raws_by_rel.items():
        # The declarations are read on the comment/literal-blanked
        # text WITHOUT the #[cfg(test)] spans removed: the gate on
        # the declaration is the very fact being computed, and a
        # declaration is gated exactly when it falls inside its
        # own file's cfg(test) span. Each declaration is resolved
        # to its ACTUAL target file (seam round 5, protest P6):
        # a `#[path = "..."]` on the declaration points it at an
        # arbitrary file, and file-module children declared
        # inside an inline module resolve under that inline
        # module's directory — or under its own #[path] when it
        # carries one (seam round 5, W4's base rules).
        code = blank_comments_and_literals(text)
        spans = cfg_test_spans(code)
        _dead36 = globals().get("_cfg_dead_spans35")
        if _dead36 is not None:
            # The chain reaches the module's FILE (seam
            # round 36, protest P2): a declaration standing
            # in text a false cfg removes — at the
            # declaration itself or at any enclosing link —
            # reaches no file, exactly as a #[cfg(test)]
            # declaration reaches none.
            spans = spans + _dead36(code, text)
        base = _compiler_child_base(rel, loaded)
        mods = _module_decls(code)
        inlines = [(name, start, span) for name, kind, start, span in mods if kind == "inline"]

        def context_dir(pos):
            chain = [iv for iv in inlines if iv[2][0] < pos < iv[2][1]]
            chain.sort(key=lambda iv: iv[2][1] - iv[2][0], reverse=True)
            ctx = base
            fdir = posixpath.dirname(rel)
            for i2, (name, start, _span) in enumerate(chain):
                pv = _path_attr_value(text, code, start)
                if pv is not None and i2 == 0:
                    # #[path] on an inline module (seam round
                    # 12, protest P7): relative to the declaring
                    # FILE's directory, as Rust resolves it.
                    ctx = fdir + "/" + pv
                else:
                    ctx = ctx + "/" + (pv if pv is not None else name)
            return ctx

        _spans_d36 = _dead36(code, text) if _dead36 is not None else []
        for name, kind, start, _span in mods:
            if kind != "file":
                continue
            gated = any(a <= start < b for a, b in spans)
            dgated = any(a <= start < b for a, b in _spans_d36)
            pv = _path_attr_value(text, code, start)
            ctx = context_dir(start)
            targets = _mod_decl_targets(rel, name, pv, ctx, not any(sp[0] < start < sp[1] for _n2, _s2, sp in inlines))
            for cand in targets:
                if cand in raws_by_rel:
                    decls.setdefault(cand, []).append((rel, gated))
                    dead_decls.setdefault(cand, []).append((rel, gated, dgated))

    def gated(rel, seen=frozenset()):
        if rel in seen or rel not in decls:
            return False
        return all(g or gated(parent, seen | {rel}) for parent, g in decls[rel])

    def dead(rel, seen=frozenset()):
        if rel in seen or rel not in dead_decls:
            return False
        if not gated(rel):
            return False
        return any(dg or dead(parent, seen | {rel}) for parent, _g, dg in dead_decls[rel])

    found = {rel for rel in raws_by_rel if gated(rel)}
    parents = {rel: sorted({p for p, _g in decls[rel]}) for rel in found}
    return found, parents, {rel for rel in found if dead(rel)}

def _missing_module_targets(raws_by_rel):
    """Production module declarations whose resolved target
    file is absent from the tree (seam round 11, protest P9),
    as {declaring file: [module names]}: the production
    definition resolves a declaration to its ACTUAL target
    file, exactly as _compute_test_gated resolves it, so a
    declaration no file in the tree satisfies — a module a
    build script generates into `src/`, say — denotes a file
    that exists by the definition and stands in no file list
    this computation walks. In the `include!` idiom the
    declaration is refused by name until the file stands in
    the tree: an unverifiable declaration is an unmodelled
    channel, and unmodelled channels fail closed."""
    out = {}
    loaded = _path_loaded_files(raws_by_rel)
    for rel, text in raws_by_rel.items():
        code = blank_comments_and_literals(text)
        spans = cfg_test_spans(code)
        _dead36 = globals().get("_cfg_dead_spans35")
        if _dead36 is not None:
            spans = spans + _dead36(code, text)
        base = _compiler_child_base(rel, loaded)
        mods = _module_decls(code)
        inlines = [(name, start, span) for name, kind, start, span in mods if kind == "inline"]

        def context_dir_missing(pos, _inlines=inlines, _base=base, _raw=text, _code=code, _fdir=posixpath.dirname(rel)):
            chain = [iv for iv in _inlines if iv[2][0] < pos < iv[2][1]]
            chain.sort(key=lambda iv: iv[2][1] - iv[2][0], reverse=True)
            ctx = _base
            for i2, (name, start, _span) in enumerate(chain):
                pv = _path_attr_value(_raw, _code, start)
                if pv is not None and i2 == 0:
                    # #[path] on an inline module (seam round
                    # 12, protest P7): relative to the declaring
                    # FILE's directory, as Rust resolves it.
                    ctx = _fdir + "/" + pv
                else:
                    ctx = ctx + "/" + (pv if pv is not None else name)
            return ctx

        for name, kind, start, _span in mods:
            if kind != "file":
                continue
            if any(a <= start < b for a, b in spans):
                continue
            pv = _path_attr_value(text, code, start)
            ctx = context_dir_missing(start)
            targets = _mod_decl_targets(rel, name, pv, ctx, not any(sp[0] < start < sp[1] for _n2, _s2, sp in inlines))
            if not any(cand in raws_by_rel for cand in targets):
                out.setdefault(rel, []).append(name)
    return out

def is_production(rel):
    # A production file: under src/, excluding any tests.rs file, the
    # testkit helper (a separate program) and the sys subtree itself
    # (the declarations' home, not a caller of them) — and excluding
    # any file whose only `mod` declaration in its parent chain is
    # #[cfg(test)]-gated (test code, recorded as such below).
    if rel == TESTKIT_REL or rel == SYS_DECL_REL or rel.startswith(SYS_PREFIX_REL):
        return False
    if rel in TEST_GATED_FILES:
        return False
    return pathlib.PurePosixPath(rel).name != "tests.rs"

files = sorted(SRC.rglob("*.rs"))
rows = []
edges_mod = []
edges_ref = {}
census = {}
raws = {}
# The crate's real top-level modules, from lib.rs's own declarations
# (`mod name;` and the inline `mod name {` forms). A textual
# `crate::<name>` reference is a module edge only when <name> is one
# of these: the same syntax also names root items that are not modules
# at all (the `GuardError` type, the `Role` enum, the `MAX_SECONDS`
# constant, the `main_*` entry functions), and printing those in a
# section headed "crate modules named" teaches a module map the tree
# does not have.
lib_text = (LIB_FILE).read_text()
MODULES = set(re.findall(r"(?m)^\s*(?:pub(?:\([^)]*\))?\s+)?mod\s+(\w+)\s*(?:;|\{)", lib_text))
for f in files:
    rel = f.relative_to(TREE).as_posix()
    raws[rel] = f.read_text()
TEST_GATED_FILES, TEST_GATED_PARENTS, DEAD_GATED_FILES = _compute_test_gated(raws)
MISSING_MOD_TARGETS.update(_missing_module_targets(raws))
for f in files:
    rel = f.relative_to(TREE).as_posix()
    text = raws[rel]
    lines = text.count("\n")
    # Only the module's own `//!` line may stand as the file's summary.
    # Falling back to the first `///` item doc mislabels submodule files:
    # it presented an interior item's doc (a wait helper's, a constant's
    # fraction digits) as the file's purpose. A file with no `//!` line
    # records an em dash, which says exactly that and nothing more.
    doc = "—"
    for line in text.splitlines():
        if line.startswith("//!"):
            doc = line[3:].strip()
            break
    rows.append((rel, lines, doc))
    if is_production(rel):
        ptext = production_text(text)
        census[rel] = sum(len(p.findall(ptext)) for p in SYS_PATTERNS)
    _code36 = blank_comments_and_literals(text)
    _dead36m = globals().get("_cfg_dead_spans35")
    _spans36 = _dead36m(_code36, text) if _dead36m is not None else []
    for m in re.finditer(r"(?m)^\s*(?:pub(?:\([^)]*\))?\s+)?mod\s+(\w+);", text):
        if any(a <= m.start() < b for a, b in _spans36):
            continue
        edges_mod.append((rel, m.group(1)))
    refs = sorted(set(re.findall(r"crate::(\w+)", text)))
    top = rel.split("/")[1].replace(".rs", "") if rel.startswith("src/") else ""
    refs = [r for r in refs if r != top and r in MODULES]
    if rel == "src/lib.rs":
        # The crate root names its own modules bare, without the
        # `crate::` prefix every other file needs, so the rule above
        # under-reports exactly this file. For the root alone, a
        # declared module named as a path head (`<module>::`) on a
        # line that is not a `mod` declaration is also an edge. Only
        # declared module names count, exactly as above: root types,
        # constants and functions named the same way are not edges.
        bare = set()
        for line in text.splitlines():
            if re.match(r"\s*(?:pub(?:\([^)]*\))?\s+)?mod\s+\w+\s*(?:;|\{)", line):
                continue
            bare.update(re.findall(r"(?<!\w)(\w+)::", line))
        refs = sorted(set(refs) | {r for r in bare if r != top and r in MODULES})
    if is_production(rel) and census.get(rel, 0) > 0 and "sys" not in refs:
        # A production file whose census is non-zero imports the
        # declarations' names from `crate::sys` in its own header
        # (seam round 7, protest P7: the glob supply is removed),
        # so its coupling stands in its own text. The census count
        # is in the Files table.
        refs = sorted(set(refs) | {"sys"})
    if refs and rel not in DEAD_GATED_FILES:
        edges_ref[rel] = refs

# The sys fan-in, stated whole: the direct callers, the files with no
# direct call that still reference sys (with the computed reason for
# each), and the pinned pure set the computation leaves standing.
direct = {rel: n for rel, n in census.items() if n > 0}

derive_wrappers(raws, sorted(census))
sys_import_census = {rel: _sys_import_names(code_text(raws[rel]), rel) for rel in sorted(census)}
# Manifest tie (S3.6, pins.import_files): the set of production files
# carrying a crate::sys import list must equal the manifest's set, by
# key and path, or the generator fails by name.
_import_files_computed = {rel for rel, _names in sys_import_census.items() if _names}
if _import_files_computed != IMPORT_FILES:
    _layout_fail(f"key pins.import_files: the computed sys-import file set disagrees with the manifest (only in census: {sorted(_import_files_computed - IMPORT_FILES)}; only in manifest: {sorted(IMPORT_FILES - _import_files_computed)})")
std_platform_census = {}
for rel in sorted(census):
    occs_ = _std_platform_occurrences(code_text(raws[rel]), rel)
    if occs_:
        std_platform_census[rel] = occs_
arch_census = {}
for rel in sorted(census):
    occs_a = _arch_occurrences(code_text(raws[rel]), rel)
    if occs_a:
        arch_census[rel] = occs_a
sys_repr_attrs = struct_attributes(code_text((DECL_FILE).read_text()))
sys_repr_carrying = sorted(n for n, attrs in sys_repr_attrs.items() if "repr(C)" in attrs)

def reference_facts(rel):
    """Why a production file is not pure, computed from its code
    text: the sys paths it names, the extended-mint names it names
    whole-word, the never-exempt exclusion shapes, and the
    sys-reaching wrappers it uses in one hop. A file with a
    non-zero census is a direct caller and needs no further fact."""
    code = code_text(raws[rel])
    facts = []
    for mname in MISSING_MOD_TARGETS.get(rel, []):
        facts.append("declares the module `" + mname + "`, whose resolved target file stands in no file list this computation walks — a production module declaration whose target file is absent from the tree is refused by name, in the `include!` idiom: the declared file exists by the production definition, so its own reaches are invisible to every census until the file stands in the tree")
    if INCLUDE_RE.search(code):
        facts.append("invokes `include!` in production code — production `include!` is refused by name: included text stands in no file list this computation walks, so no census can see it")
    ext_names = _extern_decl_names(code)
    if ext_names and rel not in EXTERN_DECL_HOMES and not rel.startswith(SYS_PREFIX_REL):
        facts.append("declares the extern item(s) " + ", ".join("`" + n + "`" for n in ext_names) + " in its own production extern declaration — extern declarations outside `" + SYS_DECL_REL + "` (and the recorded testkit mirror in `" + TESTKIT_REL + "`) are censused in their own right, every item kind: a file declaring any extern item — fn, static or type — reaches the platform through its own declaration, whatever item it declares")
    arch_occs = _arch_occurrences(code, rel)
    if arch_occs and sorted(arch_occs) != sorted(ARCH_PINNED.get(rel, [])):
        facts.append("reaches the platform through the arch channel (" + ", ".join("`" + p + "`" for p in sorted(set(arch_occs))) + ") — a `std::arch` / `core::arch` path in production code, censused per file; inside the pure set the channel stands only as the pinned occurrences recorded beside the exclusions (the empty set)")
    std_occs = _std_platform_occurrences(code, rel)
    if std_occs and sorted(std_occs) != sorted(STD_PLATFORM_PINNED.get(rel, [])):
        facts.append("reaches the platform through the std-platform channel (" + ", ".join("`" + p + "`" for p in sorted(set(std_occs))) + ") — a `std::os::<platform>` path in production code, censused per file; inside the pure set the channel stands only as the pinned occurrence recorded beside the exclusions")
    if "sys::" in code or "crate::sys" in code:
        facts.append("names a `sys::` path or a `crate::sys` import")
    named = [n for n, p in MINT_PATTERNS if p.search(code)]
    if named:
        facts.append("names the sys-declared name(s) " + ", ".join("`" + n + "`" for n in named))
    if SLOT_CALL_RE.search(code):
        facts.append("calls `slot` in a call shape (`slot::<`, `slot(`) — sys's v-table accessor, which the recorded `slot` exclusion never exempts")
    if rel != BOOL_HOME_REL:
        for m in BOOL_WORD_RE.finditer(code):
            if code[max(0, m.start() - 2):m.start()] != "::":
                facts.append("names `Bool` bare outside its enum home in `" + BOOL_HOME_REL + "` — sys's alias for `i32`, which the recorded `Bool` exclusion never exempts")
                break
    for display, home in wrapper_uses(code, rel):
        facts.append(f"uses the wrapper `{display}`, which itself reaches `sys` where it is defined (in `{home}`)")
    return facts

not_pure = {}
pure = []
for rel in sorted(census):
    if census[rel] > 0:
        continue
    facts = reference_facts(rel)
    if facts:
        not_pure[rel] = facts
    else:
        pure.append(rel)
# Manifest tie (S3.6, pins.pure_set): the computed pinned pure set
# must equal the manifest's list, or the generator fails by name.
if sorted(pure) != sorted(PURE_SET):
    _layout_fail(f"key pins.pure_set: the computed pure set disagrees with the manifest (only computed: {sorted(set(pure) - set(PURE_SET))}; only in manifest: {sorted(set(PURE_SET) - set(pure))})")

out = []
out.append("# process-tree-guard — module dependency graph")
out.append("<!-- SPDX-License-Identifier: Apache-2.0 -->")
out.append("<!-- Copyright 2026 Peter Shiller -->")
out.append("")
out.append("Generated by `tools/gen_dependency_graph.py` from the tree at")
out.append("`~/workspace/pgl-gauntlet/tree/`. Do not hand-edit: regenerate after")
out.append("any file move. `tools/design-gate.sh` (D4) fails while the line")
out.append("counts below are stale. Edges are mechanical: a `mod` declaration")
out.append("(parent -> child) or a textual `crate::<module>` reference in the")
out.append("file, where the name after `crate::` is one of the crate's declared")
out.append("modules (references to root types, constants and functions are not")
out.append("module edges and are not listed). Submodule files also glob-import their parent (`use super::*;`),")
out.append("which is how they reach the parent's re-exports; that channel is")
out.append("structural, not an edge per file. `sys` does not travel it:")
out.append("every production file imports the sys names")
out.append("it uses from `crate::sys` explicitly, in its own text, and the")
out.append("Files table's census counts that coupling per file.")
out.append("The crate root (`" + LIB_REL + "`) can name its own modules bare, so for")
out.append("that file alone a declared module named as a path head (`<module>::`)")
out.append("also counts as an edge.")
out.append("")
out.append("The Files table also carries, per production file, its direct-sys-call")
out.append("census: the count of call sites of the functions declared in the")
out.append("production `extern` blocks of `" + SYS_DECL_REL + "`, matched by name over the")
out.append("file's production text — the file with its `#[cfg(test)]` items and")
out.append("modules removed, the production definition the design gate's")
out.append("production-line counter applies, so test code is not counted as")
out.append("production coupling. A production file is a file under `src/`")
out.append("excluding any `tests.rs` file, `" + TESTKIT_REL + "` (a separate")
out.append("program, counted in its own right by design gate D44) and the `sys`")
out.append("subtree itself — and excluding any file whose every `mod`")
out.append("declaration in its parent chain is `#[cfg(test)]`-gated: the")
out.append("production definition sees the parents' declarations, resolved to")
out.append("their actual target files (a `#[path = \"...\"]` attribute on a")
out.append("declaration, or on an enclosing inline module, is honoured, and")
out.append("file-module children of an inline module resolve under that")
out.append("module's directory, as a `src/bin/*.rs` root's children resolve")
out.append("beside the root), so a file with any ungated declaration, by")
out.append("whatever path, is production, and such a file as has none is test")
out.append("code, recorded as such below, not production;")
out.append("non-production rows show — in that column. A")
out.append("production file whose census is non-zero shows its `sys` edge in the")
out.append("cross-module table even when its own text names no `crate::sys`,")
out.append("because its own header imports the names from `crate::sys`.")
out.append("")
out.append("## Files")
out.append("")
out.append("| File | Lines | Direct sys calls | First doc line |")
out.append("|---|---|---|---|")
for rel, n, doc in rows:
    calls = str(census[rel]) if rel in census else "—"
    out.append(f"| `{rel}` | {n} | {calls} | {doc} |")
out.append("")
out.append(f"Total: {sum(n for _, n, _ in rows)} lines in {len(rows)} files.")
out.append("")
_tree_total = sum(n for _, n, _ in rows)
try:
    _tools_root = WS / _layout_path("tools.root")
    _inst_lines = {p.name: len(p.read_text().splitlines()) for p in sorted(_tools_root.iterdir()) if p.is_file()}
    _tools_total = sum(_inst_lines.values())
    _pct = round(100 * _tools_total / _tree_total) if _tree_total else 0
    _inst_list = ", ".join(f"`tools/{name}` ({n} lines)" for name, n in _inst_lines.items())
    out.append(f"The working instruments that took this census — {_inst_list} —")
    out.append(f"total {_tools_total} lines against the tree's {_tree_total} lines: about")
    out.append(f"{_pct} per cent (reported, not gated). These instruments produced the")
    out.append("shipped results in this tree; they do not ship in process-tree-guard,")
    out.append("and they are preserved on the `ptg-gauntlet-instruments` branch in HerrNest.")
    out.append("")
except OSError:
    pass
if TEST_GATED_FILES:
    out.append("Recorded as test code, not production, under the parent-declaration")
    out.append("half of the production definition (each file's only `mod`")
    out.append("declaration in its parent chain is `#[cfg(test)]`-gated):")
    out.append("")
    for rel in sorted(TEST_GATED_FILES):
        parents = ", ".join("`" + p + "`" for p in TEST_GATED_PARENTS.get(rel, []))
        if rel in DEAD_GATED_FILES:
            out.append(f"- `{rel}` — declared only under a cfg false on the crate's one denotation target in {parents}")
        else:
            out.append(f"- `{rel}` — declared only under `#[cfg(test)]` in {parents}")
    out.append("")
out.append("## Module declarations (parent -> child)")
out.append("")
for rel, child in edges_mod:
    out.append(f"- `{rel}` declares `{child}`")
out.append("")
out.append("## Cross-module references (file -> crate modules named)")
out.append("")
for rel in sorted(edges_ref):
    out.append(f"- `{rel}` -> {', '.join('`' + r + '`' for r in edges_ref[rel])}")
out.append("")
out.append("## The sys fan-in")
out.append("")
out.append(f"{sum(direct.values())} direct sys call sites in {len(direct)} production files:")
out.append("")
for rel in sorted(direct):
    out.append(f"- `{rel}` -> {direct[rel]} direct sys call sites")
out.append("")
out.append("Production files with no direct sys call that still reference `sys`,")
out.append("each with the reason the computation gives for it:")
out.append("")
GLOSSES = {
    "src/main.rs": "recorded as an entry shim: the file exists only to call the process-owning boundary (`cli_exit` in `src/diagnostics.rs`)",
    "src/bin/process-tree-guard-deadline.rs": "recorded as an entry shim: the file exists only to call the process-owning boundary (`cli_exit` in `src/diagnostics.rs`)",
    "src/bin/process-tree-guard-gate.rs": "recorded as an entry shim: the file exists only to call the process-owning boundary (`cli_exit` in `src/diagnostics.rs`)",
    "src/bin/process-tree-guard-contain.rs": "recorded as an entry shim: the file exists only to call the process-owning boundary (`cli_exit` in `src/diagnostics.rs`)",
    "src/extend/state.rs": "recorded mechanism-adjacent, not pure: the extendable run's state machine, keyed on the `Handle` type `sys` declares",
    "src/extend/state/rate.rs": "recorded mechanism-adjacent beside `src/extend/state.rs`, not pure: the state machine's other half, whose liveness oracle opens live process handles through `Process::open` and waits on them through its `alive` method",
}
for rel in sorted(not_pure):
    line = f"- `{rel}` — " + "; ".join(not_pure[rel])
    if rel in GLOSSES:
        line += " — " + GLOSSES[rel]
    out.append(line)
out.append("")
out.append(f"The remaining {len(pure)} production files contain no sys reference")
out.append("of any kind — no `sys::` path, no `crate::sys` import, no whole-word")
out.append(f"naming of any of the {len(EXTENDED_MINT)} names `sys` declares outside")
out.append(f"the {len(EXCLUSIONS)} recorded exclusions (judged by occurrence: a")
out.append("`slot` call shape and a bare `Bool` outside `" + BOOL_HOME_REL + "` are")
out.append("never exempt), and no one-hop use of a wrapper that itself reaches")
out.append("`sys` (every production function and method in the crate whose own")
out.append("body names a `sys::` path, calls a declared extern name unqualified,")
out.append("or names an extended-mint item, or whose item text carries a `slot`")
out.append("call shape or a bare `Bool`) — where a free wrapper is used by call")
out.append("or by name as a value, a method wrapper is used by its defining")
out.append("type's associated path or by a receiver call whose receiver's type")
out.append("is determinable from declared types, resolved to a fixed point (a")
out.append("parameter typed `Type`/`&Type`/`&mut Type`, a `Self` receiver inside")
out.append("`impl Type`, or a binding annotated with the type — a pattern")
out.append("binding destructuring a determinable declared type binds each")
out.append("variable with its position's declared type; a field receiver")
out.append("through the field's declared type in its defining struct; a chained")
out.append("receiver through the inner callee's declared return type; an")
out.append("unannotated binding initialised by such a call or field access —")
out.append("multi-hop fields and chains fall out of the iteration), a wrapper")
out.append("type — a type carrying any derived wrapper method, constructors and")
out.append("`Drop` included, the set closed under by-value field containment")
out.append("(a type owning a wrapper type by value in a field, transitively,")
out.append("is itself one; reference and pointer fields do not contain) and")
out.append("under production type aliases (an alias in whose target a wrapper")
out.append("type occurs by value anywhere is one, its home the alias's file) — is used by being")
out.append("named whole-word in type position, in an associated path with any")
out.append("method name, or in a value construction (a type the file itself")
out.append("defines — where Rust's own scoping makes the definition the")
out.append("name's meaning: the use's own scope, an ancestor module the")
out.append("intervening modules import it from, or the file's own `use` of")
out.append("an item from a descendant or sibling scope, the self-defined")
out.append("exclusions being computed under that scoping for types and")
out.append("names alike — and a same-named enum variant path, are not the")
out.append("type), and a by-value generic parameter a file owns to a scope")
out.append("exit is used where any production instantiation of its item —")
out.append("supply computed to a fixed point through generic-to-generic")
out.append("hops — supplies a wrapper type,")
out.append("computed at the call sites with the same machinery.")
out.append("Use statements yield per-scope rename maps, and every arm")
out.append("resolves a spelled local name through its scope's map before")
out.append("lookup; const and static items whose initialiser is a wrapper")
out.append("path are wrapper values, and naming one is a wrapper use;")
out.append("receiver resolution takes a Deref step and binds `for` loop")
out.append("variables and closure parameters from the declared types that")
out.append("bind them; and name supply is textual and local to each")
out.append("file — `sys` names reach a file only through its own")
out.append("`crate::sys` import list, tied below to this census. The")
out.append("recorded limit of the computation: a receiver call whose")
out.append("receiver's type arrives through a generic parameter, a trait")
out.append("object, or an expression with no declared type in the crate")
out.append("is not counted as a wrapper use, and neither is a bare name")
out.append("with more than one production definition.")
out.append("Glob bindings yield rename entries — a scope that")
out.append("glob-imports a module gains entries for the names that module")
out.append("exports, its re-export renames included, a name two glob")
out.append("sources export with different identities yielding none; the")
out.append("std-platform channel below is censused by resolution, not by")
out.append("spelling; and the re-export chase is bounded — 8 re-export")
out.append("hops, 16 module-path variants — and fails closed by name past")
out.append("the bound, the bound and the deepest live chain (2 hops)")
out.append("recorded in " + LIB_REL + " and in D43. The chase's variant record")
out.append("condition may not be suppressed by renaming — exhaustion in")
out.append("a chase whose top-level resolution fails records a named")
out.append("refusal when the spelled final segment is any production")
out.append("binding local (a definition name, a wrapper value, or a use")
out.append("binding's local name, renamed re-exports included), while")
out.append("exhaustion inside a chase another frame completes records")
out.append("nothing; resolution is root-confined — a candidate from")
out.append("another crate's root never satisfies a path, and the chase")
out.append("runs in the root that owns the path; extern declarations")
out.append("outside " + SYS_DECL_REL + " and the recorded testkit mirror are censused")
out.append("in their own right, a pure file declaring any extern fn")
out.append("being named as a platform reach; glob roots join the")
out.append("std-platform resolution census, and that census follows")
out.append("re-exports to the definition, a name whose definition is a")
out.append("std-platform item being censused at every use site; wrapper")
out.append("values are derived from every expression position that")
out.append("yields the wrapper, array and table elements included; and")
out.append("arch paths (std::arch, core::arch, and their re-export")
out.append("spellings) join the censused platform channels for pure")
out.append("files, recorded below.")
out.append("Sys items are derivation sources — a production alias or")
out.append("const/static whose target or initialiser resolves into sys")
out.append("joins the census universe as a sys-derived name, and naming")
out.append("one is named; trait default methods are method wrappers of")
out.append("their trait, reached through the receivers of types that")
out.append("implement it; the platform chase expands re-exported module")
out.append("segments within the recorded bounds; the channel censuses'")
out.append("bare-name arm follows glob bindings; a one-segment root")
out.append("bound to the std or core crate itself joins the censused")
out.append("roots; the receiver fixed point unwraps ?-bindings; the")
out.append("own-extern census extracts every extern item, fns and")
out.append("statics alike; functions whose return expression yields a")
out.append("wrapper are wrapper-yielding, like consts; the chase's")
out.append("module map honours #[path] — a file's declared module path")
out.append("is a candidate home for its items; and the macro channel")
out.append("stands in the include! idiom — a macro defined outside sys")
out.append("whose expansion reaches a wrapper or sys item, invoked from")
out.append("a pinned file, is named as an unmodelled channel, refused")
out.append("for the pure set.")
out.append("The yield derivation runs over methods as the criterion's")
out.append("text names them — a method whose return expression yields a")
out.append("wrapper is wrapper-yielding, and a call through its return")
out.append("is a wrapper use; a trait default method supplied by a")
out.append("blanket impl is keyed by the impl's trait, not by the")
out.append("spelled generic parameter's name, so a receiver call on any")
out.append("determinable receiver type reaches it; a wrapper carried in")
out.append("a struct field at construction is yielded for that field,")
out.append("and a call through the field's projection is a use; a")
out.append("returned closure whose body reaches a wrapper is a yield")
out.append("attached to its defining item; both value closures follow")
out.append("calls in initialiser position — a holder whose initialiser")
out.append("calls a sys-reaching const fn derives from the callee's")
out.append("returned value, in the plain-const and associated-const")
out.append("forms alike; the module map is built from declarations — an")
out.append("inline module is a candidate home at its path in both")
out.append("chases, and a file's binding reads are scoped to the module")
out.append("that declares the binding; the macro census reads sys's own")
out.append("macro definitions; re-export bindings that rename a sys")
out.append("item are derivation sources in the mint, the sys-derived")
out.append("closure and the chase; and a production module declaration")
out.append("whose resolved target file is absent from the tree is")
out.append("refused by name in the include! idiom.")
out.append("Function scopes are homes — an inline module declared")
out.append("inside a function body is a candidate home scoped to that")
out.append("body, and a call through its local path resolves as a")
out.append("module-path call; both value closures follow initialiser")
out.append("calls through associated functions and methods as through")
out.append("free functions, the callee's body read from the method")
out.append("tables; carriage runs over tuple constructions as over")
out.append("literals, a positional argument carrying its wrapper at its")
out.append("index, and a variant literal is keyed by the enum it")
out.append("denotes; the yield derivation runs over trait default")
out.append("methods, keyed by (trait, method); macro expansions are")
out.append("read as items of the invocation site — the expansion's use")
out.append("bindings and function definitions stand in the invoking")
out.append("file's tables, for macros defined in sys and")
out.append("#[macro_export] macros; #[path] on an inline module")
out.append("resolves relative to the declaring file's directory in the")
out.append("production definition, the declared-path map and the")
out.append("missing-target census alike; and the field initialiser's")
out.append("judgement extends through constructor calls, a field")
out.append("initialised by a call carrying what its wrapper or")
out.append("wrapper-reaching closure argument denotes.")
out.append("Both value closures resolve an initialiser call's callee")
out.append("type through production type aliases to its defining type;")
out.append("the carriage derivation reads field-init shorthand as the")
out.append("explicit initialiser its same-named let binding denotes;")
out.append("field carriage follows a value through a method chain,")
out.append("every call in the chain judged as a constructor call is")
out.append("judged; the field initialiser's judgement reads a call's")
out.append("RESULT as it reads its arguments — a field initialised by a")
out.append("wrapper-yielding call, free or trait-path spelled, carries")
out.append("the yielded wrapper; the use arms count a wrapper-denoting")
out.append("value bound to a local and then called, by its bound field")
out.append("projection or its bound yield return; the pattern-carried")
out.append("arm reads destructuring function parameters and closure")
out.append("parameters as it reads let and match patterns; the")
out.append("qualified-path yield arm and its sibling yield arms read")
out.append("through the grouping parentheses Rust permits around a")
out.append("call; trait-yield and trait-wrapper attribution reads the")
out.append("receiver type's own impl — where the impl defines the")
out.append("method, the item judged is the override and its own yield")
out.append("or wrapper derivation, and the default is attributed only")
out.append("to types whose impl leaves it in place, in both directions;")
out.append("blanket-impl attribution reads the blanket's bound against")
out.append("the receiver type's own impls and a generic parameter's")
out.append("signature bounds, under the satisfaction rule stated below;")
out.append("a macro's expansion is a derivation input in expression")
out.append("position as in item position — an invocation whose matching")
out.append("arm's template is a single expression, in a const")
out.append("initialiser or any derivation position, derives as the")
out.append("expression it expands to, for production macros generally,")
out.append("simple dollar-parameter substitution included (repetition")
out.append("and token-tree patterns beyond that form are not read, the")
out.append("recorded limit); a file module loaded by #[path] records")
out.append("its subtree under its DECLARED path, in the declared-path")
out.append("map and the type qualifications alike, so re-exports inside")
out.append("its children are chaseable by the paths consumers spell;")
out.append("and the use arms count projections of container-carried")
out.append("fields — a call through a carried field's")
out.append("value-preserving projection chain, the unwrap() chain and")
out.append("the pattern-bound chain alike.")
out.append("The trait-path result arm resolves the callee type through")
out.append("production type aliases to its defining type, so an")
out.append("override is judged by the defining type's own impl in both")
out.append("directions; the carriage derivation reads field-init")
out.append("shorthand fed by a destructuring let binding as the")
out.append("projection of the destructured value it denotes; field")
out.append("carriage follows a value through a method chain across a")
out.append("`?` in the chain; the field result judgement reads")
out.append("receiver-spelled method callees, a wrapper-yielding method")
out.append("called on a value whose type its const or static")
out.append("declaration spells; the bound-local arm counts container")
out.append("projections of bound values — an `unwrap()` or a `?`")
out.append("applied before the binding — and a bound value returned by")
out.append("its item whose result is called through in the file; the")
out.append("pattern-carried arm reads `for` patterns as it reads let")
out.append("and match patterns; the bound-local arm reads through")
out.append("grouping parentheses around the projection; the macro")
out.append("expression arm applies its template rule at the depth it")
out.append("states — a statement separator at nested depth does not")
out.append("reject a block-expression template; the module map follows")
out.append("the compiler's resolution for `#[path]` — a `#[path]` value")
out.append("on a declaration resolves relative to the directory")
out.append("containing the declaring file, and the children of a file")
out.append("loaded by `#[path]` resolve beside the file itself, so a")
out.append("subtree stands chaseable at the placement rustc accepts, a")
out.append("placement rustc rejects is never the model, and a")
out.append("declaration whose compiler-resolved target stands in no")
out.append("file list is refused by name; the item slicer tracks")
out.append("bracket depth as it tracks parenthesis depth, and reads a")
out.append("const-generic brace in a signature as an argument, not a")
out.append("body, so bracketed and braced signature shapes do not blind")
out.append("it; blanket satisfaction is keyed on the parameter's")
out.append("identity, not its spelled name — a blanket impl records no")
out.append("impl under its parameter's name, and a bound is satisfied")
out.append("where it stands among the receiver type's own impls, among")
out.append("a generic parameter's signature bounds, or is supplied to")
out.append("either through a supertrait chain or another blanket impl,")
out.append("the recorded limit standing at this boundary: a bound")
out.append("satisfied only through another parameter's bound is not")
out.append("read; and field carriage reads array-literal initialisers")
out.append("as it reads scalar ones.")
out.append("The use-side receiver typing reads the payload step — an")
out.append("`unwrap()`, `expect()` or `as_ref()` on a determinable")
out.append("`Result`/`Option` receiver, and the direct `?` chain,")
out.append("resolve to the payload type, as the `?`-binding fixed point")
out.append("and the bound-local strip read it; a generic-instantiated")
out.append("receiver identity is normalised to its defining type in the")
out.append("field arms and every sibling arm keyed on bare type")
out.append("identity; the bound-local arm reads a trailing index suffix")
out.append("as it reads `unwrap()` / `?`, with the variable-index,")
out.append("array-pattern-binding and field-of-index forms; the")
out.append("shorthand judgement reads nested subpatterns, the")
out.append("variable's projection path composed stepwise; the")
out.append("returned-bound-value step reads tuple-packaged and closure")
out.append("returns, and the field judgement reads an invoked-closure")
out.append("initialiser; and the nested-`;` block-expression macro")
out.append("template derives in fact, the const value closures reading")
out.append("it as the other derivation positions do.")
out.append("Carriage reads a turbofish head — a struct literal or tuple")
out.append("construction spelled `Type::<args>` is keyed by the head it")
out.append("stands on; a field's declared type is read through the")
out.append("instantiation that supplies it, the instantiation's")
out.append("arguments substituted for its defining type's parameters,")
out.append("position for position; the associated-path arms read a")
out.append("turbofish segment standing in a spelled path, as every")
out.append("sibling arm that segments a spelled path on `::` does; the")
out.append("bound-local strip reads a trailing `expect(...)` as it")
out.append("reads `unwrap()`; the returned-bound-value step reads tuple")
out.append("packaging to the depth the caller's destructure reaches,")
out.append("the pattern the guide; the const/static capture reads the")
out.append("item head at its full breadth — `static mut` included, and")
out.append("a declared type read to its depth-zero `=`, as the")
out.append("initialiser is read to its depth-zero `;`, and a field")
out.append("initialised from an element of such a value carries the")
out.append("value's wrapper, the index step the bound-local strip")
out.append("reads; a signature's return type ends at a depth-zero")
out.append("`where` clause; and the payload step reads `unwrap`,")
out.append("`expect`, `as_ref`, `as_mut`, `ok` and `?` on the ground")
out.append("stated with the full enumeration below: each such step is")
out.append("declared on the container and exposes the payload the")
out.append("container holds — the payload itself, a reference to it,")
out.append("or, for `ok`, the same payload under the sibling container")
out.append("— while `Clone` is declared on the payload, not on any")
out.append("container, and its return is a second value of the")
out.append("receiver's own type, made by copying, not the held payload")
out.append("exposed; a step through a method the crate does not declare")
out.append("that is not in the payload enumeration is not read, the")
out.append("standard library's `Clone` the standing instance.")
out.append("A field's declared type is read through the instantiation")
out.append("that supplies it with the substitution made simultaneous —")
out.append("one pass over the declared text, each parameter token")
out.append("replaced by its argument exactly once, an inserted argument")
out.append("never rescanned, so no later parameter can capture it; the")
out.append("arms that segment a spelled path on `::` read a turbofish")
out.append("segment standing on the construction they bind — the")
out.append("receiver fixed point's bare-name binding arm reads such a")
out.append("segment on the construction it binds, the construction arms")
out.append("judging a construction as a naming event and never typing")
out.append("the binding it initialises, `_expr_yields_wrapper` strips")
out.append("the segment as `_yielded_wrapper` does, and the")
out.append("generic-supply spelled-callee arm reads a segment standing")
out.append("on the type or on the method; the bound-local strip reads")
out.append("the enumeration's own steps — `ok()`, `as_ref()` and")
out.append("`as_mut()` beside `expect(...)` and the rest of the")
out.append("enumeration that can stand in bound-local position, the")
out.append("balanced-paren head check generalised past `.expect`; the")
out.append("returned-bound-value step judges a tuple element that is")
out.append("itself a field projection by the projection arms, at every")
out.append("packaging depth the caller's destructure reaches — nested")
out.append("tuples, and a projection packaged inside a container")
out.append("constructor such as `Ok(...)`, whose single argument stands")
out.append("at the path the destructure reaches after its payload step")
out.append("— the judgement recorded from the callee's own file and")
out.append("made in the caller's, so the helper's home file no longer")
out.append("bounds it; and the payload step's enumeration also reads")
out.append("`copied`, `cloned`, `as_deref`, `as_deref_mut`,")
out.append("`transpose`, `unwrap_or`, `unwrap_or_else` and")
out.append("`unwrap_or_default`. The rationale is what the step does to")
out.append("the value it stands on, judged by the receiver it stands")
out.append("on: every read step is declared on the container itself —")
out.append("on `Result` or `Option` — and its result carries the")
out.append("payload the container holds: the payload itself (`unwrap`,")
out.append("`expect`, `?`, and the `unwrap_or` family, whose result is")
out.append("the payload on the branch where the container holds one), a")
out.append("reference to it (`as_ref`, `as_mut`), a reference to what")
out.append("the payload itself dereferences to (`as_deref`,")
out.append("`as_deref_mut`), the payload made by copying it out of the")
out.append("reference the container holds (`copied`, `cloned`), or the")
out.append("same payload under the sibling container (`ok`;")
out.append("`transpose`, the containers swapped). The closure steps")
out.append("`map` and `and_then` are read in the closure arm on the")
out.append("same ground: each hands the held payload to its closure as")
out.append("the closure's parameter. `Clone` is not read, and the")
out.append("separation is the receiver: `Clone` is declared on the")
out.append("payload itself — on whatever value type implements it,")
out.append("container or not — and stands on no container; its return")
out.append("is a second value of the receiver's own type, and no")
out.append("container is opened by it. `copied` and `cloned` make their")
out.append("copies by the same copying, but they are declared on the")
out.append("container and open it, and that is the clause that governs:")
out.append("a step read here stands on a `Result` or `Option` receiver")
out.append("and carries its held payload out; a step whose receiver is")
out.append("the payload itself does not. A step through a method the")
out.append("crate does not declare that is not in the enumeration is")
out.append("not read, and the standard library's `Clone` is the")
out.append("standing instance.")
out.append("The payload step's enumeration also reads its next ring —")
out.append("the sibling-container steps `ok_or`, `ok_or_else`, `or`,")
out.append("`or_else`, `and` and `zip`, the payload-preserving and")
out.append("payload-extracting steps `map_err`, `flatten`, `take`,")
out.append("`replace` and `get_or_insert`, the closure steps")
out.append("`is_some_and`, `is_ok_and`, `map_or` and `map_or_else`, and")
out.append("`clone` on a container receiver — each guarded by the")
out.append("container head itself, so `Clone` on a payload receiver")
out.append("stands unread as before, the separation now the receiver")
out.append("the computation itself types; the iterator-consumer arm's")
out.append("membership stands named where the closure steps are named —")
out.append("`any`, `all`, `for_each`, `find`, `find_map`, `position`,")
out.append("`fold`, `inspect`, `map`, `filter`, `filter_map`,")
out.append("`flat_map` and `map_while`; the bound-local strip reads the")
out.append("same ring in bound-local position and a turbofish segment")
out.append("standing on a step's head, its head check placed in the")
out.append("sibling enumeration's fixed class; the carriage derivation")
out.append("records every wrapper-carrying field of a construction —")
out.append("the declaration split reads a function pointer's arrow as")
out.append("two neutral characters, so no field stands dropped by its")
out.append("position after such a field; the return-projection walk")
out.append("reads array and `vec!` element packagings at their index")
out.append("paths and struct-literal field packagings at their field")
out.append("paths; and the return-projection table is keyed by the")
out.append("item's identity — defining file and name — the caller-side")
out.append("arm judging the call it resolves, a bare name with more than")
out.append("one production definition refusing by name in the")
out.append("recorded-limit idiom rather than merging.")
out.append("`and` is read at the argument's container and `zip`'s pair")
out.append("at both elements, the whole result payload standing as `()`")
out.append("for `and` and the second element as `()` for `zip` only")
out.append("where an argument's container text is not determinable at a")
out.append("call; `xor` and `insert` are read, `err` and")
out.append("`unwrap_err`/`expect_err` at the error payload, and the")
out.append("error payload's closure steps — `is_err_and`,")
out.append("`inspect_err`, `map_err`'s own closure, and the error")
out.append("closures of `or_else`, `unwrap_or_else` and `map_or_else`")
out.append("— beside the success side's, with `is_none_or` beside")
out.append("`is_some_and` and `get_or_insert_with` named as")
out.append("`get_or_insert`'s twin; the declaration split reads a")
out.append("comparison or shift `>` inside const-generic braces or a")
out.append("parenthesised group as no angle close; the direct caller")
out.append("arm follows the tuple step `.<idx>`, so mixed packaging")
out.append("paths judge as their pattern equivalents do; the")
out.append("return-projection key carries the item's module path within")
out.append("its defining file and, for a method, its impl kind; and a")
out.append("bare call shadowed by a scoped `use` import is resolved to")
out.append("the import's target or refused by name.")
out.append("The `and`/`zip` record is computed, not read — the callee's")
out.append("type parameters are replaced by the call's actual arguments")
out.append("(the turbofish where it stands, otherwise inferred from the")
out.append("argument expressions' own types), and the constructor arm")
out.append("reads turbofish spellings; the payload ring stands closed")
out.append("against a mechanical census of `Option`'s and `Result`'s")
out.append("stable combinator surface at this toolchain, `take_if`,")
out.append("`get_or_insert_default` and `as_slice` read at their")
out.append("payloads' breadths and the census's exclusions named beside")
out.append("it; the pattern arm composes through the packaging steps")
out.append("that remain on a pattern-bound local; the impl kind carries")
out.append("the trait's module path, and a blanket impl is resolved to")
out.append("its bound's concrete types or refused by name; and a")
out.append("wrapper standing directly as a returned tuple or array")
out.append("element is recorded at its element path, the walk running")
out.append("on that ground even where no field carries.")
out.append("Judged on")
out.append("production code with comments and literal")
out.append("contents blanked, so a name mentioned in prose is not a")
out.append("reference. The pinned pure set is exactly those files:")
out.append("")
for rel in pure:
    out.append(f"- `{rel}`")
out.append("")
out.append("D45's judged set is recorded here as its second home: the")
out.append("(struct, field) pairs of `" + SYS_DECL_REL + "` the shape")
out.append("rule judges pointer-carrying on their own homes' evidence. D45's")
out.append("check compares its own pin against this list on every run, so a")
out.append("pair retires only by coordinated visible edits in both records —")
out.append("the pin in D45's section and this list, regenerated from the")
out.append("generator's record:")
out.append("")
for s_, f_ in JUDGED_RECORD:
    out.append(f"- `{s_}.{f_}`")
out.append("")
out.append("The pinned pure set is recorded in `tools/design-gate.sh` (D43),")
out.append("which recomputes this set's facts and fails while its recorded set")
out.append("differs from the set computed here: a pinned file gaining a sys")
out.append("reference fails the gate and must win its argument explicitly, and")
out.append("the two records cannot drift silently. The tie is stated honestly:")
out.append("it ties two RECORDS (this computation and D43's recomputation), not")
out.append("two independent computations — gate and generator share the one")
out.append("comment/literal lexer, so a lexer bug would corrupt both at once")
out.append("and the tie could not catch it. The lexer's correctness rests on")
out.append("the pinned test corpus inside D43 (raw strings with embedded")
out.append("quotes, raw byte strings, raw C strings, plain C strings, byte")
out.append("strings, char literals against lifetimes, nested block comments,")
out.append("and negative fixtures), not on the tie. The macro channel stands")
out.append("in the refusal idiom: a macro defined outside sys whose expansion")
out.append("reaches a wrapper or sys item, invoked from a pinned file, is")
out.append("named as an unmodelled channel and refused for the pure set —")
out.append("the tree contains no `macro_rules!` anywhere today, so the")
out.append("channel has no live instance. The census also reads sys's own")
out.append("macro definitions, so a macro defined in " + SYS_DECL_REL + " itself")
out.append("stands in the table beside the production ones.")
out.append("The built-in inclusion channel beside it is not a note but a")
out.append("refusal: production `include!` is")
out.append("refused by name in this census and in D43 — included text stands")
out.append("in no file list this computation walks, so no census can see it;")
out.append("`include_str!` and `include_bytes!` splice data, not code, and")
out.append("stand outside the refusal. The tree carries no production")
out.append("`include!` today.")
out.append("")
out.append("The std-platform channel is censused")
out.append("per file beside the sys channels: production `std::os::<platform>`")
out.append("paths \u2014 spelled absolutely, or through a root the file's own")
out.append("imports bind to `std::os` or a deeper `std::os::<platform>` prefix")
out.append("(a glob root included), or through a")
out.append("crate re-export of the platform item itself, the census")
out.append("being by resolution \u2014 stand")
out.append("in exactly these production files:")
out.append("")
for rel in sorted(std_platform_census):
    for occ in std_platform_census[rel]:
        out.append(f"- `{rel}` — `{occ}`")
out.append("")
out.append("Inside the pure set the channel stands only as one pinned")
out.append("occurrence, in the exclusions idiom: `" + STD_PLATFORM_FILE_REL + "`'s")
out.append("`std::os::windows::ffi::OsStrExt` use, for the file's UTF-16")
out.append("encoding logic — the file already recorded Windows-shaped for")
out.append("its environment block's sort order; its membership does not move.")
out.append("Any other std-platform occurrence in a pinned file fails by name")
out.append("in D43.")
out.append("")
out.append("The arch channel is censused per file")
out.append("beside it: production `std::arch::\u2026` and `core::arch::\u2026` paths \u2014")
out.append("spelled absolutely, through a root bound to `std::arch` or")
out.append("`core::arch`, through a glob root, or through a crate re-export")
out.append("\u2014 stand in exactly these production files:")
out.append("")
for rel in sorted(arch_census):
    for occ in arch_census[rel]:
        out.append(f"- `{rel}` \u2014 `{occ}`")
out.append("")
out.append("Inside the pure set the channel stands only as its pinned")
out.append("occurrences (the empty set): the tree carries no production arch")
out.append("path today, and any arch occurrence in a pinned file fails by")
out.append("name in D43.")
out.append("")
out.append("Extern declarations are censused in")
out.append("their own right beside the channels above: a production file")
out.append("outside `" + SYS_DECL_REL + "` and the recorded testkit mirror that")
out.append("declares an extern item — fn, static or type — in its own")
out.append("extern block reaches the")
out.append("platform through its own declaration and is named where it")
out.append("stands \u2014 no such declaration stands in a member of the pinned")
out.append("pure set today.")
out.append("")
out.append("Name supply is textual and local to")
out.append("each file: the `crate::sys::*` glob roots are removed, and every")
out.append("production file imports the sys names it uses from `crate::sys`")
out.append("explicitly, in that file — the rename maps are")
out.append("read from the same headers. D43 ties each file's import list to")
out.append("the set of sys names this census records for it:")
out.append("")
out.append(f"- {sum(1 for v in sys_import_census.values() if v)} production files carry a `crate::sys` import list, {sum(len(v) for v in sys_import_census.values())} names in all, each list the census set of its file.")
out.append("")
out.append("D45's repr record: the structural")
out.append("census of `" + SYS_DECL_REL + "` records each censused struct's attributes")
out.append("beside its fields; the structs standing with `#[repr(C)]` are:")
out.append("")
for n_ in sys_repr_carrying:
    out.append(f"- `{n_}`")
out.append("")
out.append("The remaining censused structs stand recorded in D45 as the")
out.append("non-repr exceptions (the `*Api` tables, `Com`, `HString`); a")
out.append("repr-carrying struct losing `#[repr(C)]` fails by name in D45.")
out.append("")
if CHASE_FAILURES:
    for msg in CHASE_FAILURES:
        print(msg, file=sys.stderr)
    sys.exit(1)
OUT.write_text("\n".join(out))
print(f"wrote {_layout_path('graph.output')}: {len(rows)} files, {sum(n for _, n, _ in rows)} lines")
