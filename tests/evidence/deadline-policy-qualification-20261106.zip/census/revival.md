# Current seam census baseline

Product commit: accadc289e2501f444ba51976246d8c2417de4e1. The baseline ZIP was created with Git archive and core.autocrlf=false. All 84 extracted src/ files were compared against the commit's Git blobs. The original graph was copied to tree/docs/dependency-graph.md to satisfy a historical layout existence check.

Instrument commit: d7d64f6516df9f6df98fdfe9b531e2799ec5ae85. The generator is unchanged, Git blob 50b44f53a0346d51b92b6ad0e3d750af05940725. Each attempt preserves its own input layout and separate stdout, stderr and exit status. The invocation uses the installed Python 3.12 with -I -B -X utf8 and a 120-second whole-tree bound.

1. Original layout refused. The computed sys-import set adds src/auth/password_budget.rs. Commit 435671d added that file. Its explicit crate::sys::windows import names the registry APIs and Handle.
2. Added only that path under pins.import_files. The generator next refused because src/engine/environment.rs remained in pins.pure_set. Commit 6bfe73c moved encoding into src/sys/windows/encoding.rs, and the environment builder now calls crate::sys::windows::encode_wide. The generator treats this path as platform reach.
3. Removed only src/engine/environment.rs from pins.pure_set. Kept the historical pins.std_platform_file key because the original generator schema requires a present path and the historical exception no longer matches an occurrence in this file. Setting it to the backend encoder would describe a different exception and would not make the generated prose accurate.

The historical generator unconditionally prints prose saying that the environment builder's OsStrExt occurrence remains inside the pure set. That sentence no longer follows from the current source and the recomputed list. Any emitted graph is a raw generator receipt. Publication requires a separate correction of this historical reporting behavior.

Attempt 003 exited 0 and emitted the raw graph for 67 files and 26,295 lines. The raw graph SHA-256 is 932c2e5465f2f5a57831c90d09df06fcafb533e7dd85408eb6ccd277cc0f5fb4. Its exact layout SHA-256 is 765dbb3af79f02d2aa18899995c573ad25dce7da6b322463ac44ba26d6eabdfb. The raw graph names the environment builder's sys path and excludes the file from the recomputed pure set. Its historical exception paragraph is retained verbatim as part of the receipt. No full design gate, candidate source, or canonical change was attempted.
