# Deadline validation prototype qualification

The prototype extracts the existing deadline bound and parsing policy
from the Windows CLI paths for later reuse by a portable backend.
Source baseline is accadc289e2501f444ba51976246d8c2417de4e1.
The exact candidate is preserved as a patch.

The two pure tests passed on Linux ARM64 and physical macOS ARM64
through Tailscale, with independent cleanup. Three focused tests passed
on Windows x64 MSVC. The matched release executables each measured
822,784 bytes. The mapped code section changed digest and grew by
384 bytes. Speed qualification remains open.

The original and updated layout attempts exercised the exact historic
generator from d7d64f6516df9f6df98fdfe9b531e2799ec5ae85. Two current
baseline pins required source-backed changes. Both the updated baseline
and candidate produced raw graphs. The candidate added one pure module
with no direct Windows references. The historic generator retains an
obsolete environment.rs narrative in its output. Treat the graphs as
raw evidence pending a fresh publication pass and full design gate.

The prototype remains outside production. The evidence covers deadline
validation and code structure. Platform activation and runtime
containment have separate acceptance requirements.
