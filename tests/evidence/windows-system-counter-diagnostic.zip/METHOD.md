# Partial Windows system-counter diagnostic 001

This archive preserves every file from diagnostic 001, including the C and Python source, C executable and object, build command and raw compiler output, tool provenance, both complete saved partial JSONL traces, raw exits, original analysis and original METHOD. A separate packaging check recomputes the trace metrics and verifies all archived bytes. It runs no diagnostic or benchmark.

The fixed design requested 1024 pairs in an unaffined phase followed by 1024 pairs with only the calling thread affinity changed. Each reader had an absolute 15-second internal deadline inside a separate 30-second whole-tree guard. Compilation used a 60-second guard. Both readers returned internal terminal code 124 during the first phase. Neither completed the requested controls, and the affinity phase remains untested. The false affinity_restored flags accompany traces with no affinity phase.

The C partial trace contains 925 observed pairs and 84 component regressions. In 82, idle and kernel decreased equally with unchanged user time. In two, idle decreased more than kernel, increasing derived busy time. Its largest observed component decrease is 4843750 FILETIME ticks, or 0.484375 seconds.

The Python partial trace contains 940 observed pairs and 45 component regressions. All 45 decreased idle and kernel equally with unchanged user time. Its largest observed component decrease is 2500000 ticks, or 0.25 seconds.

Derived busy, computed as kernel plus user minus idle, never decreased within these recorded pairs. The native calls succeeded and the unassigned Job accounting stayed empty in these saved observations. The packaging check also verifies each decoded FILETIME against its raw high and low words, contiguous pair indices, trace hashes, terminal counts and the original analysis.

These are counts and maxima within two partial traces on this host. They establish neither a global regression rate nor a universal tolerance or accounting-error bound. The underlying cause is unproved. The effects of affinity, complete phase controls, other hosts and other Windows versions remain unmeasured. No benchmark slot was executed. The failed attempt 011 remains rejected, and this diagnostic supports no retrospective scoring or latency conclusion.

The saved build selected MSVC 14.51.36231, compiler version 19.51.36260.0, through the default vcvars64.bat path. Compilation passed /W4 /WX. The original provenance file records that compiler and the Python 3.12.10 interpreter, together with source and binary hashes.

Original files retain their repository-relative paths. The top-level INDEX.json lists byte lengths and SHA-256 hashes for every other member. independently-recomputed.json contains the packaging check's metrics. The original diagnostic directory was read before and after packaging and verified unchanged. ZIP timestamps do not record experiment timing.
