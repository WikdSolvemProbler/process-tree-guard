"""Preserve and independently recount existing partial counter traces only."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import zipfile

repo = Path(r"C:\Users\Peter\process-tree-guard")
source = repo / "target/codex-security/issue7-system-counter-diagnostic-001"
pack = repo / "target/codex-security/issue7-system-counter-diagnostic-package-001"
destination = repo / "tests/evidence/windows-system-counter-diagnostic.zip"
if destination.exists():
    raise RuntimeError("refusing to replace diagnostic evidence")

def sha(data):
    return hashlib.sha256(data).hexdigest()

original = {
    path.relative_to(source).as_posix(): path.read_bytes()
    for path in sorted(source.rglob("*")) if path.is_file()
}
old_analysis = json.loads(original["analysis-001.json"])
expected = {
    "c-001": {"pairs": 925, "regressions": 84, "equal": 82, "unequal": 2, "drop": 4843750},
    "python-001": {"pairs": 940, "regressions": 45, "equal": 45, "unequal": 0, "drop": 2500000},
}
summaries = []
for reader, pin in expected.items():
    raw = original[reader + ".jsonl"]
    rows = [json.loads(line) for line in raw.splitlines()]
    contexts = [row for row in rows if row["kind"] == "context"]
    terminals = [row for row in rows if row["kind"] == "terminal"]
    pairs = [row for row in rows if row["kind"] == "pair"]
    errors = [row for row in rows if row["kind"] == "error"]
    expected_errors = ([{"kind": "error", "error": "TimeoutError: absolute reader deadline"}]
                       if reader == "python-001" else [])
    if (len(contexts) != 1 or len(terminals) != 1 or errors != expected_errors
            or len(rows) != len(pairs) + len(errors) + 2):
        raise RuntimeError("trace shape differs in " + reader)
    context, terminal = contexts[0], terminals[0]
    if context["pairs_per_phase"] != 1024 or context["deadline_seconds"] != 15:
        raise RuntimeError("fixed diagnostic protocol differs")
    if terminal["code"] != 124 or original[reader + ".exit.txt"].decode().strip() != "124":
        raise RuntimeError("internal deadline refusal was not preserved")
    if any(row["phase"] != "unaffined" for row in pairs):
        raise RuntimeError("unexpected affinity observations")
    if [row["index"] for row in pairs] != list(range(len(pairs))):
        raise RuntimeError("pair indices are incomplete or reordered")
    regressions = []
    busy_regressions = 0
    native_failures = 0
    nonempty_jobs = 0
    lows = {key: 0 for key in ("idle", "kernel", "user", "busy")}
    for row in pairs:
        delta = {}
        for endpoint in ("before", "after"):
            value = row[endpoint]
            if value["status"] != 1:
                native_failures += 1
            for component in ("idle", "kernel", "user"):
                counter = value[component]
                if counter["ticks"] != (counter["high"] << 32) | counter["low"]:
                    raise RuntimeError("FILETIME decoding differs")
        for component in ("idle", "kernel", "user"):
            delta[component] = row["after"][component]["ticks"] - row["before"][component]["ticks"]
        delta["busy"] = delta["kernel"] + delta["user"] - delta["idle"]
        for component in lows:
            lows[component] = min(lows[component], delta[component])
        if any(delta[key] < 0 for key in ("idle", "kernel", "user")):
            regressions.append(delta)
        busy_regressions += delta["busy"] < 0
        job = row["job"]
        native_failures += job["status"] != 1
        nonempty_jobs += any(job[key] != 0 for key in (
            "kernel", "user", "total_processes", "active_processes"))
    equal = sum(
        row["idle"] == row["kernel"] < 0 and row["user"] == 0
        for row in regressions
    )
    unequal = [
        row for row in regressions
        if not (row["idle"] == row["kernel"] < 0 and row["user"] == 0)
    ]
    if not all(row["idle"] < row["kernel"] <= 0 and row["user"] == 0
               and row["busy"] > 0 for row in unequal):
        raise RuntimeError("unexpected unequal regression shape")
    actual = {
        "pairs": len(pairs), "regressions": len(regressions), "equal": equal,
        "unequal": len(unequal), "drop": -min(lows.values()),
    }
    if actual != pin:
        raise RuntimeError("metrics disagree with requested preserved scope: " + repr(actual))
    if (terminal["pairs"] != len(pairs)
            or terminal["regressions"] != [len(regressions), 0]
            or terminal["affinity_restored"] is not False
            or native_failures or nonempty_jobs or busy_regressions):
        raise RuntimeError("terminal, API, Job or derived busy evidence differs")
    previous = next(row for row in old_analysis["summaries"] if row["reader"] == reader)
    if (previous["sha256"] != sha(raw) or previous["pairs"] != len(pairs)
            or previous["regressions"] != len(regressions)
            or previous["busy_regressions"] != busy_regressions
            or previous["lowest_deltas"] != lows):
        raise RuntimeError("saved analysis differs from raw recount")
    summaries.append({
        "reader": reader, "scope": "recorded partial unaffined trace only",
        "requested_pairs_per_phase": 1024, "observed_pairs": len(pairs),
        "observed_component_regressions": len(regressions),
        "equal_idle_kernel_decreases_user_unchanged": equal,
        "idle_decreased_more_than_kernel": len(unequal),
        "observed_busy_regressions": busy_regressions,
        "largest_observed_component_drop_ticks": actual["drop"],
        "largest_observed_component_drop_seconds": actual["drop"] / 10_000_000,
        "native_failures": native_failures, "nonempty_jobs": nonempty_jobs,
        "terminal_code": terminal["code"], "affinity_phase_observed": False,
        "recorded_errors": errors,
        "source_trace_sha256": sha(raw),
    })
for entry in json.loads(original["provenance.json"]):
    path = Path(entry["path"])
    if path.parent == source and sha(original[path.name]) != entry["sha256"]:
        raise RuntimeError("source/binary provenance differs: " + path.name)
if original["build.exit.txt"].decode().strip() != "0":
    raise RuntimeError("build did not qualify")
recomputed = {
    "scope": "partial observed records only; no global rate or universal tolerance",
    "complete_controls": False, "cause_established": False, "benchmark_slots": 0,
    "summaries": summaries,
}
recomputed_bytes = (json.dumps(recomputed, indent=2) + "\n").encode()
(pack / "independently-recomputed.json").write_bytes(recomputed_bytes)
members = {
    (source.relative_to(repo) / name).as_posix(): data for name, data in original.items()
}
members["METHOD.md"] = (pack / "METHOD.md").read_bytes()
members["independently-recomputed.json"] = recomputed_bytes
members["package_diagnostic.py"] = Path(__file__).read_bytes()
members["package_diagnostic_attempt_001.py"] = (pack / "package_diagnostic_attempt_001.py").read_bytes()
index = {
    "schema": 1, "scope": recomputed["scope"],
    "complete_controls": False, "affinity_phase_observed": False,
    "cause_established": False, "benchmark_slots": 0,
    "members": [
        {"path": name, "bytes": len(data), "sha256": sha(data)}
        for name, data in sorted(members.items())
    ],
}
members["INDEX.json"] = (json.dumps(index, indent=2) + "\n").encode()
with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(destination) as archive:
    if archive.testzip() is not None or len(archive.namelist()) != len(members):
        raise RuntimeError("archive CRC or member count differs")
    for name, data in members.items():
        if archive.read(name) != data:
            raise RuntimeError("archive bytes differ: " + name)
after = {
    path.relative_to(source).as_posix(): path.read_bytes()
    for path in sorted(source.rglob("*")) if path.is_file()
}
if original != after:
    raise RuntimeError("original diagnostic changed during packaging")
receipt = {
    "archive": str(destination), "sha256": sha(destination.read_bytes()),
    "bytes": destination.stat().st_size, "members": len(members),
    "verified": True, "original_diagnostic_unchanged": True,
    "metrics": summaries,
}
(pack / "archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
