set -eu
umask 077
tag=ptg-portable-linux-ee885c6-002
tree=$(/usr/bin/mktemp -d "/tmp/$tag.XXXXXXXX")
case "$tree" in "/tmp/$tag."*) ;; *) exit 125;; esac
[ -d "$tree" ] && [ ! -L "$tree" ]
cleanup() {
    result=$?
    trap - EXIT
    case "$tree" in "/tmp/$tag."*) ;; *) exit 125;; esac
    if [ ! -L "$tree" ] && /bin/rm -rf -- "$tree" && [ ! -e "$tree" ]; then
        printf 'test_scratch_removed=%s\n' "$tree"
    else
        printf 'test_scratch_present=%s\n' "$tree"
        result=125
    fi
    exit "$result"
}
trap cleanup EXIT
printf 'test_scratch=%s\n' "$tree"
/usr/bin/cat /proc/self/cgroup
/usr/bin/systemctl --user show ptg-portable-linux-ee885c6-002.scope -p RuntimeMaxUSec -p KillMode -p KillSignal
/bin/cat > "$tree/payload.tar.gz"
[ "$(/usr/bin/sha256sum "$tree/payload.tar.gz" | /usr/bin/cut -d ' ' -f 1)" = '2cec11a2d3122a0887b43410febc8aa6778cff8dc4d58b17f6fd91b04569a5a1' ]
/usr/bin/tar -xzf "$tree/payload.tar.gz" -C "$tree"
[ "$(/usr/bin/sha256sum "$tree/tests/tests/test_campaign_logic.py" | /usr/bin/cut -d ' ' -f 1)" = 'bcf6359af3af7c6f76da96d5174854a202a3342742dfd88e911429682a83b117' ]
/usr/bin/uname -srm
/usr/bin/python3 --version
cd "$tree"
/usr/bin/env -u PTG_SUITE_BUILD -u PYTHONPATH -u PYTHONHOME PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -u -B - <<'PTG_RUN'
import base64
import io
import json
from pathlib import Path
import sys
import tarfile
import time
sys.path.insert(0, "tests")
import run_tests

class Immediate(run_tests.CertificateResult):
    def startTest(self, test):
        super().startTest(test)
        print(f"START {test.id()} ns={time.monotonic_ns()}", flush=True)

    def addSuccess(self, test):
        super().addSuccess(test)
        print(f"PASS {test.id()}", flush=True)

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        print(f"SKIP {test.id()} reason={reason}", flush=True)

    def addFailure(self, test, err):
        super().addFailure(test, err)
        print(f"FAIL {test.id()}\n{self._exc_info_to_string(err, test)}", flush=True)

    def addError(self, test, err):
        super().addError(test, err)
        print(f"ERROR {test.id()}\n{self._exc_info_to_string(err, test)}", flush=True)

    def addExpectedFailure(self, test, err):
        super().addExpectedFailure(test, err)
        print(f"SKIP {test.id()} reason=expected_failure", flush=True)

    def addUnexpectedSuccess(self, test):
        super().addUnexpectedSuccess(test)
        print(f"FAIL {test.id()} reason=unexpected_success", flush=True)

run_tests.CertificateResult = Immediate
result = run_tests.main(["--tree-sha", "ee885c6a3d5dfdab2bcfe7230bcdcdb41f43c2ed"])
folder = Path("tests/certificates")
index = json.loads((folder / "index.json").read_text(encoding="utf-8"))
print("CERTIFICATE_INDEX " + json.dumps(index, sort_keys=True), flush=True)
buf = io.BytesIO()
with tarfile.open(fileobj=buf, mode="w:gz") as archive:
    for path in sorted(folder.glob("*.json")):
        archive.add(path, arcname=path.name, recursive=False)
print("CERTIFICATE_ARCHIVE_B64 " + base64.b64encode(buf.getvalue()).decode("ascii"), flush=True)
sys.exit(result)

PTG_RUN
