# Correctness rerun

Both full suites evaluated source at ee885c6a3d5dfdab2bcfe7230bcdcdb41f43c2ed.
The Windows x64 release binaries were verified before and after the run and
the compiled source was checked against this tree. The first Windows archive
was refused at preflight due to CRLF conversion. Its receipt is included.
The Windows rerun used git -c core.autocrlf=false archive.

The Linux ARM64 guest ran the portable suite under a finite user cgroup scope.
The first archive transfer was reset before tests began and cleanup was
independently checked. The successful retry omitted the 15 listed publication
archives, none referenced by the tests. It used the standard test runner with
immediate progress reporting. A private overlay address in the failed transfer
log is redacted. Its unredacted receipt remains local.

Explicit live pricing gates are outside the default correctness suite. The
separate owner-pricing archive contains the targeted native macOS run and the
failed earlier macOS live stability gate. Backend availability and performance
certification are outside the scope of this package.
