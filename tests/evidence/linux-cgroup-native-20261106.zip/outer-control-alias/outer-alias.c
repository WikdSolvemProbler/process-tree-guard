#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/magic.h>
#include <linux/sched.h>
#include <limits.h>
#include <poll.h>
#include <sched.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/statfs.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <unistd.h>

#define MOUNT "/sys/fs/cgroup"
#define SCOPE_PREFIX "/user.slice/user-501.slice/user@501.service/app.slice/"
#define MAX_PATH PATH_MAX

static void need(int ok, const char *operation)
{
    if (!ok) {
        int error = errno;
        fprintf(stderr, "invalid operation=%s errno=%d (%s)\n",
                operation, error, strerror(error));
        exit(90);
    }
}

static void join(char output[MAX_PATH], const char *base, const char *name)
{
    int count = snprintf(output, MAX_PATH, "%s/%s", base, name);
    need(count >= 0 && count < MAX_PATH, "join path");
}

static void procfile(char output[MAX_PATH], pid_t pid, const char *name)
{
    int count = snprintf(output, MAX_PATH, "/proc/%ld/%s", (long)pid, name);
    need(count >= 0 && count < MAX_PATH, "proc path");
}

static void read_text(const char *path, char *buffer, size_t size)
{
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    need(fd >= 0, path);
    ssize_t n = read(fd, buffer, size - 1);
    need(n >= 0 && (size_t)n < size - 1, "read text");
    buffer[n] = '\0';
    close(fd);
}

static void read_ns(const char *path, char output[128])
{
    ssize_t n = readlink(path, output, 127);
    need(n > 0 && n < 127, "read namespace link");
    output[n] = '\0';
}

static int put(const char *label, const char *path, const char *value)
{
    int fd = open(path, O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) {
        int error = errno;
        printf("%s stage=open errno=%d path=%s\n", label, error, path);
        return error;
    }
    size_t size = strlen(value);
    ssize_t n = write(fd, value, size);
    int error = n < 0 ? errno : 0;
    close(fd);
    need(n < 0 || (size_t)n == size, "control short write");
    printf("%s stage=write errno=%d path=%s\n", label, error, path);
    return error;
}

static int cg_put(const char *label, const char *cg, const char *name, const char *value)
{
    char path[MAX_PATH];
    join(path, cg, name);
    return put(label, path, value);
}

static void member(const char *label, pid_t pid, const char *suffix)
{
    char path[MAX_PATH], actual[MAX_PATH], expected[MAX_PATH];
    procfile(path, pid, "cgroup");
    read_text(path, actual, sizeof(actual));
    int n = snprintf(expected, sizeof(expected), "0::%s\n", suffix);
    need(n > 0 && (size_t)n < sizeof(expected), "membership expectation");
    printf("%s pid=%ld membership=%s", label, (long)pid, actual);
    need(strcmp(actual, expected) == 0, "membership mismatch");
}

static void enter(const char *cg)
{
    need(cg_put("place-own-worker", cg, "cgroup.procs", "0") == 0, "place own worker");
    member("placed-worker", getpid(), cg + strlen(MOUNT));
}

static void no_processes(const char *cg)
{
    char path[MAX_PATH], events[128];
    join(path, cg, "cgroup.events");
    read_text(path, events, sizeof(events));
    printf("drain path=%s %s", cg, events);
    need(strstr(events, "populated 0\n") != NULL, "nonempty dedicated cgroup");
}

static int reap(int fd, pid_t pid, const char *label)
{
    siginfo_t result = {0};
    need(waitid(P_PIDFD, (id_t)fd, &result, WEXITED) == 0, "waitid pidfd");
    need(result.si_pid == pid, "wrong pidfd result");
    printf("%s held_pid=%ld si_code=%d si_status=%d\n",
           label, (long)pid, result.si_code, result.si_status);
    close(fd);
    return result.si_code == CLD_EXITED ? result.si_status : 128 + result.si_status;
}

static void still_held(int pidfd)
{
    struct pollfd pfd = {.fd = pidfd, .events = POLLIN};
    need(poll(&pfd, 1, 0) == 0, "expected held live process");
}

static void map_child(pid_t pid)
{
    char path[MAX_PATH], value[80];
    snprintf(value, sizeof(value), "%u %u 1\n", geteuid(), geteuid());
    procfile(path, pid, "uid_map");
    need(put("parent-map", path, value) == 0, "uid_map");
    procfile(path, pid, "setgroups");
    need(put("parent-map", path, "deny\n") == 0, "setgroups");
    snprintf(value, sizeof(value), "%u %u 1\n", getegid(), getegid());
    procfile(path, pid, "gid_map");
    need(put("parent-map", path, value) == 0, "gid_map");
}


enum variant { EXPOSED, NAMESPACED, MASKED };

static int own_mount_setup(const char *outside_mount)
{
    char mount_ns[128];
    read_ns("/proc/self/ns/mnt", mount_ns);
    printf("mount-namespace outside=%s inside=%s\n", outside_mount, mount_ns);
    need(strcmp(outside_mount, mount_ns) != 0, "mount namespace unchanged");
    int result = mount(NULL, "/", NULL, MS_REC | MS_PRIVATE, NULL);
    int error = result < 0 ? errno : 0;
    printf("mount stage=private-propagation result=%d errno=%d\n", result, error);
    if (result < 0)
        return 77;
    struct statfs filesystem;
    need(statfs(MOUNT, &filesystem) == 0 && filesystem.f_type == CGROUP2_SUPER_MAGIC,
         "verify cgroup mount before masking");
    result = mount("tmpfs", MOUNT, "tmpfs", MS_RDONLY | MS_NOSUID | MS_NODEV | MS_NOEXEC,
                   "size=4096,mode=0555");
    error = result < 0 ? errno : 0;
    printf("mount stage=readonly-mask result=%d errno=%d\n", result, error);
    if (result < 0)
        return 77;
    struct statvfs attrs;
    need(statfs(MOUNT, &filesystem) == 0 && filesystem.f_type == TMPFS_MAGIC &&
         statvfs(MOUNT, &attrs) == 0 && (attrs.f_flag & ST_RDONLY),
         "verify readonly tmpfs mask");
    return 0;
}

static void link_receipt(const char *victim, const char *alias)
{
    char canonical[MAX_PATH], alternate[MAX_PATH];
    join(canonical, victim, "cgroup.kill");
    join(alternate, alias, "cgroup.kill");
    struct stat left, right;
    need(stat(canonical, &left) == 0 && stat(alternate, &right) == 0 &&
         left.st_dev == right.st_dev && left.st_ino == right.st_ino,
         "textual alias does not match dedicated victim");
    printf("alias-authenticated canonical=%s alias=%s inode=%lu\n",
           canonical, alternate, (unsigned long)left.st_ino);
}

static int variant(const char *label, enum variant mode, const char *root, const char *scratch)
{
    char branch[MAX_PATH], worker[MAX_PATH], victim[MAX_PATH], alias[MAX_PATH];
    join(branch, root, label);
    join(worker, branch, "worker");
    join(victim, branch, "victim");
    join(alias, scratch, label);
    need(mkdir(branch, 0700) == 0 && mkdir(worker, 0700) == 0 && mkdir(victim, 0700) == 0,
         "create dedicated branch");
    need(symlink(victim, alias) == 0, "create scratch-only symlink alias");
    link_receipt(victim, alias);

    int victim_ready[2];
    need(pipe2(victim_ready, O_CLOEXEC) == 0, "victim pipe");
    pid_t victim_pid = fork();
    need(victim_pid >= 0, "fork victim");
    if (victim_pid == 0) {
        close(victim_ready[0]);
        enter(victim);
        need(write(victim_ready[1], "R", 1) == 1, "victim ready");
        close(victim_ready[1]);
        for (;;) pause();
    }
    close(victim_ready[1]);
    int victim_fd = (int)syscall(SYS_pidfd_open, victim_pid, 0);
    char byte;
    need(victim_fd >= 0 && read(victim_ready[0], &byte, 1) == 1 && byte == 'R',
         "held victim ready");
    close(victim_ready[0]);
    still_held(victim_fd);
    member("victim-held", victim_pid, victim + strlen(MOUNT));

    int ready[2], release[2];
    need(pipe2(ready, O_CLOEXEC) == 0 && pipe2(release, O_CLOEXEC) == 0, "worker pipes");
    char outside_mount[128];
    read_ns("/proc/self/ns/mnt", outside_mount);
    pid_t worker_pid = fork();
    need(worker_pid >= 0, "fork worker");
    if (worker_pid == 0) {
        close(victim_fd);
        close(ready[0]);
        close(release[1]);
        enter(worker);
        if (mode != EXPOSED) {
            int flags = CLONE_NEWUSER | CLONE_NEWCGROUP;
            if (mode == MASKED) flags |= CLONE_NEWNS;
            int result = unshare(flags);
            int error = result < 0 ? errno : 0;
            printf("namespace case=%s flags=0x%x result=%d errno=%d\n", label, flags, result, error);
            if (result < 0) _exit(77);
        }
        need(write(ready[1], "R", 1) == 1, "worker ready");
        close(ready[1]);
        need(read(release[0], &byte, 1) == 1 && byte == 'G', "worker gate");
        close(release[0]);
        need(geteuid() == 501 && getegid() == 1000, "numeric credential identity");
        if (mode != EXPOSED) {
            char profile[128];
            read_text("/proc/self/attr/current", profile, sizeof(profile));
            printf("worker-profile case=%s %s", label, profile);
            member("worker-private-cgroup-root", getpid(), "/");
        }
        if (mode == MASKED) {
            int rc = own_mount_setup(outside_mount);
            if (rc) _exit(rc);
            int direct = cg_put("masked-canonical", victim, "cgroup.kill", "1");
            int indirect = cg_put("masked-textual-alias", alias, "cgroup.kill", "1");
            _exit(direct == ENOENT && indirect == ENOENT ? 0 : 2);
        }
        int error = cg_put(label, mode == EXPOSED ? victim : alias, "cgroup.kill", "1");
        _exit(error == 0 ? 0 : 3);
    }
    close(ready[1]);
    close(release[0]);
    int worker_fd = (int)syscall(SYS_pidfd_open, worker_pid, 0);
    need(worker_fd >= 0, "pidfd_open worker");
    if (read(ready[0], &byte, 1) == 1 && byte == 'R') {
        still_held(worker_fd);
        member("worker-held-before-gate", worker_pid, worker + strlen(MOUNT));
        if (mode != EXPOSED)
            map_child(worker_pid);
        need(write(release[1], "G", 1) == 1, "release worker");
    }
    close(ready[0]);
    close(release[1]);
    int worker_rc = reap(worker_fd, worker_pid, label);
    struct pollfd pfd = {.fd = victim_fd, .events = POLLIN};
    int expected_kill = mode != MASKED && worker_rc == 0;
    int ready_count = poll(&pfd, 1, expected_kill ? 1000 : 0);
    need(ready_count >= 0, "poll victim");
    printf("effect case=%s worker_rc=%d victim_exited_before_cleanup=%d expected_kill=%d\n",
           label, worker_rc, ready_count > 0, expected_kill);
    if (!ready_count)
        need(cg_put("supervisor-cleanup", victim, "cgroup.kill", "1") == 0, "kill held victim");
    int victim_rc = reap(victim_fd, victim_pid, "victim-reap");
    no_processes(worker);
    no_processes(victim);
    need(victim_rc == 128 + SIGKILL && ((ready_count > 0) == expected_kill),
         "unexpected victim status or effect");
    return worker_rc;
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    need(argc == 3 && geteuid() == 501 && getegid() == 1000, "expected account");
    const char *unit_prefix = "ptg-linux-outer-alias-";
    need(strncmp(argv[1], unit_prefix, strlen(unit_prefix)) == 0 &&
         strspn(argv[1], "abcdefghijklmnopqrstuvwxyz0123456789.-") == strlen(argv[1]),
         "verify scope ID");
    char suffix[MAX_PATH], root[MAX_PATH];
    int n = snprintf(suffix, sizeof(suffix), "%s%s", SCOPE_PREFIX, argv[1]);
    need(n > 0 && (size_t)n < sizeof(suffix), "scope suffix");
    n = snprintf(root, sizeof(root), "%s%s", MOUNT, suffix);
    need(n > 0 && (size_t)n < sizeof(root), "scope path");
    member("verify-owned-outer-scope", getpid(), suffix);
    struct stat info;
    struct statfs filesystem;
    need(lstat(root, &info) == 0 && S_ISDIR(info.st_mode) && info.st_uid == 501 &&
         statfs(root, &filesystem) == 0 && filesystem.f_type == CGROUP2_SUPER_MAGIC,
         "scope filesystem and ownership");
    char exact_scratch[MAX_PATH];
    size_t unit_len = strlen(argv[1]);
    need(unit_len > 6 && strcmp(argv[1] + unit_len - 6, ".scope") == 0, "scope unit suffix");
    n = snprintf(exact_scratch, sizeof(exact_scratch), "/tmp/%.*s", (int)(unit_len - 6), argv[1]);
    need(n > 0 && (size_t)n < sizeof(exact_scratch), "scratch path");
    need(strcmp(argv[2], exact_scratch) == 0 &&
         lstat(argv[2], &info) == 0 && S_ISDIR(info.st_mode) && info.st_uid == 501 &&
         (info.st_mode & 0777) == 0700, "private scratch identity");
    int exposed = variant("exposed", EXPOSED, root, argv[2]);
    need(exposed == 0, "exposed positive control failed");
    int namespaced = variant("namespaced", NAMESPACED, root, argv[2]);
    int masked = variant("masked", MASKED, root, argv[2]);
    printf("summary exposed=%d namespaced=%d masked=%d\n", exposed, namespaced, masked);
    return masked == 77 ? 77 : (masked || (namespaced != 0 && namespaced != 3));
}
