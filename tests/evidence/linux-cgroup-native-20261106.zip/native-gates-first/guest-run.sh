set -eu
umask 077
unit=ptg-linux-native-gates-20261106-3cb1a8f1.scope
scope=/user.slice/user-501.slice/user@501.service/app.slice/ptg-linux-native-gates-20261106-3cb1a8f1.scope
root=/sys/fs/cgroup$scope
scratch=/tmp/ptg-linux-native-gates-20261106-3cb1a8f1
[ "$(/usr/bin/id -u)" = 501 ]
[ "$(/usr/bin/id -g)" = 1000 ]
[ "$(/usr/bin/cat /proc/$$/cgroup)" = "0::$scope" ]
[ "$(/usr/bin/stat -c %u "$root")" = 501 ]
[ "$(/usr/bin/stat -f -c %T "$root")" = cgroup2fs ]
printf 'scope=%s\n' "$scope"
if [ -e '/sys/fs/cgroup/user.slice/user-501.slice/user@501.service/app.slice/ptg-linux-nsvariant-20261106-6bf1d3d1.scope' ]; then printf 'previous_scope_present=yes\n'; else printf 'previous_scope_present=no\n'; fi
/usr/bin/systemctl --user show "$unit" --property=Delegate,ControlGroup,RuntimeMaxUSec,KillMode,KillSignal,ActiveState
/usr/bin/uname -srvmo
/usr/bin/mkdir -m 700 -- "$scratch"
cleanup() {
    result=$?
    trap - EXIT
    for leaf in type-protected-root/leaf type-live-root/leaf type-empty-root/leaf setns-leaf clone-root/sibling clone-root/source type-protected-root type-live-root type-empty-root clone-root; do
        target="$root/$leaf"
        if [ -d "$target" ]; then
            if /usr/bin/rmdir -- "$target"; then
                printf 'removed cgroup=%s\n' "$target"
            else
                result=91
            fi
        fi
    done
    if /usr/bin/rm -f -- "$scratch/probe" "$scratch/native-gates.c" && /usr/bin/rmdir -- "$scratch" && [ ! -e "$scratch" ]; then
        printf 'scratch_removed=%s\n' "$scratch"
    else
        result=92
    fi
    /usr/bin/cat "$root/cgroup.stat"
    exit "$result"
}
trap cleanup EXIT
/usr/bin/cat > "$scratch/native-gates.c" <<'PTG_NATIVE_GATES_SOURCE'
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/magic.h>
#include <linux/sched.h>
#include <limits.h>
#include <poll.h>
#include <sched.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <unistd.h>

#define MOUNT "/sys/fs/cgroup"
#define SCOPE_PREFIX "/user.slice/user-501.slice/user@501.service/app.slice/"
#define MAX_PATH PATH_MAX

static void need(int ok, const char *operation)
{
    if (!ok) {
        int error = errno;
        fprintf(stderr, "invalid operation=%s errno=%d (%s)\n",
                operation, error, strerror(error));
        exit(90);
    }
}

static void join(char output[MAX_PATH], const char *base, const char *name)
{
    int count = snprintf(output, MAX_PATH, "%s/%s", base, name);
    need(count >= 0 && count < MAX_PATH, "join path");
}

static void procfile(char output[MAX_PATH], pid_t pid, const char *name)
{
    int count = snprintf(output, MAX_PATH, "/proc/%ld/%s", (long)pid, name);
    need(count >= 0 && count < MAX_PATH, "proc path");
}

static void read_text(const char *path, char *buffer, size_t size)
{
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    need(fd >= 0, path);
    ssize_t n = read(fd, buffer, size - 1);
    need(n >= 0 && (size_t)n < size - 1, "read text");
    buffer[n] = '\0';
    close(fd);
}

static void read_ns(const char *path, char output[128])
{
    ssize_t n = readlink(path, output, 127);
    need(n > 0 && n < 127, "read namespace link");
    output[n] = '\0';
}

static int put(const char *label, const char *path, const char *value)
{
    int fd = open(path, O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) {
        int error = errno;
        printf("%s stage=open errno=%d path=%s\n", label, error, path);
        return error;
    }
    size_t size = strlen(value);
    ssize_t n = write(fd, value, size);
    int error = n < 0 ? errno : 0;
    close(fd);
    need(n < 0 || (size_t)n == size, "control short write");
    printf("%s stage=write errno=%d path=%s\n", label, error, path);
    return error;
}

static int cg_put(const char *label, const char *cg, const char *name, const char *value)
{
    char path[MAX_PATH];
    join(path, cg, name);
    return put(label, path, value);
}

static void member(const char *label, pid_t pid, const char *suffix)
{
    char path[MAX_PATH], actual[MAX_PATH], expected[MAX_PATH];
    procfile(path, pid, "cgroup");
    read_text(path, actual, sizeof(actual));
    int n = snprintf(expected, sizeof(expected), "0::%s\n", suffix);
    need(n > 0 && (size_t)n < sizeof(expected), "membership expectation");
    printf("%s pid=%ld membership=%s", label, (long)pid, actual);
    need(strcmp(actual, expected) == 0, "membership mismatch");
}

static void enter(const char *cg)
{
    need(cg_put("place-own-worker", cg, "cgroup.procs", "0") == 0, "place own worker");
    member("placed-worker", getpid(), cg + strlen(MOUNT));
}

static void no_processes(const char *cg)
{
    char path[MAX_PATH], events[128];
    join(path, cg, "cgroup.events");
    read_text(path, events, sizeof(events));
    printf("drain path=%s %s", cg, events);
    need(strstr(events, "populated 0\n") != NULL, "nonempty dedicated cgroup");
}

static int reap(int fd, pid_t pid, const char *label)
{
    siginfo_t result = {0};
    need(waitid(P_PIDFD, (id_t)fd, &result, WEXITED) == 0, "waitid pidfd");
    need(result.si_pid == pid, "wrong pidfd result");
    printf("%s held_pid=%ld si_code=%d si_status=%d\n",
           label, (long)pid, result.si_code, result.si_status);
    close(fd);
    return result.si_code == CLD_EXITED ? result.si_status : 128 + result.si_status;
}

static void still_held(int pidfd)
{
    struct pollfd pfd = {.fd = pidfd, .events = POLLIN};
    need(poll(&pfd, 1, 0) == 0, "expected held live process");
}

static void map_child(pid_t pid)
{
    char path[MAX_PATH], value[80];
    snprintf(value, sizeof(value), "%u %u 1\n", geteuid(), geteuid());
    procfile(path, pid, "uid_map");
    need(put("parent-map", path, value) == 0, "uid_map");
    procfile(path, pid, "setgroups");
    need(put("parent-map", path, "deny\n") == 0, "setgroups");
    snprintf(value, sizeof(value), "%u %u 1\n", getegid(), getegid());
    procfile(path, pid, "gid_map");
    need(put("parent-map", path, value) == 0, "gid_map");
}

static int try_clone(const char *sibling, int protected_case)
{
    struct stat status;
    int cgroup_fd = open(sibling, O_PATH | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    int error = cgroup_fd < 0 ? errno : 0;
    printf("clone3-target protected=%d stage=open errno=%d path=%s\n",
           protected_case, error, sibling);
    if (cgroup_fd < 0)
        return 1;
    need(fstat(cgroup_fd, &status) == 0 && status.st_uid == 501, "sibling fd identity");
    int ready[2], release[2];
    need(pipe2(ready, O_CLOEXEC) == 0 && pipe2(release, O_CLOEXEC) == 0, "clone pipes");
    int pidfd = -1;
    struct clone_args args = {
        .flags = CLONE_INTO_CGROUP | CLONE_PIDFD,
        .pidfd = (uintptr_t)&pidfd,
        .cgroup = (uint64_t)cgroup_fd,
        .exit_signal = SIGCHLD,
    };
    long child = syscall(SYS_clone3, &args, sizeof(args));
    error = child < 0 ? errno : 0;
    close(cgroup_fd);
    if (child == 0) {
        close(ready[0]);
        close(release[1]);
        char actual[MAX_PATH], byte;
        read_text("/proc/self/cgroup", actual, sizeof(actual));
        printf("clone3-child-before-ready pid=%ld membership=%s", (long)getpid(), actual);
        need(write(ready[1], "R", 1) == 1, "child ready");
        close(ready[1]);
        ssize_t result = read(release[0], &byte, 1);
        close(release[0]);
        _exit(result == 1 && byte == 'G' ? 0 : 2);
    }
    printf("clone3 protected=%d stage=syscall errno=%d result=%ld pidfd=%d\n",
           protected_case, error, child, pidfd);
    close(ready[1]);
    close(release[0]);
    if (child < 0) {
        close(ready[0]);
        close(release[1]);
        return !(protected_case && error == ENOENT && pidfd == -1);
    }
    need(pidfd >= 0, "clone did not return pidfd");
    char byte;
    need(read(ready[0], &byte, 1) == 1 && byte == 'R', "clone child did not arm");
    still_held(pidfd);
    if (!protected_case)
        member("clone-held-child", (pid_t)child, sibling + strlen(MOUNT));
    need(write(release[1], "G", 1) == 1, "release clone child");
    close(ready[0]);
    close(release[1]);
    int rc = reap(pidfd, (pid_t)child, "clone3-held-result");
    return protected_case || rc != 0;
}

static int try_setns(pid_t outer_pid, int inherited_outer_fd, const char *outer_id)
{
    char path[MAX_PATH], before[128], after[128];
    read_ns("/proc/self/ns/cgroup", before);
    procfile(path, outer_pid, "ns/cgroup");
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    int error = fd < 0 ? errno : 0;
    printf("setns stage=open errno=%d path=%s expected_namespace=%s\n", error, path, outer_id);
    if (fd < 0) {
        fd = inherited_outer_fd;
        inherited_outer_fd = -1;
        printf("setns using dedicated inherited descriptor for same outer namespace\n");
    }
    need(fd >= 0, "setns no descriptor");
    struct stat info;
    need(fstat(fd, &info) == 0, "setns descriptor identity");
    char actual_id[128];
    snprintf(actual_id, sizeof(actual_id), "cgroup:[%lu]", (unsigned long)info.st_ino);
    need(strcmp(actual_id, outer_id) == 0, "wrong outer namespace descriptor");
    int result = setns(fd, CLONE_NEWCGROUP);
    error = result < 0 ? errno : 0;
    printf("setns stage=syscall errno=%d result=%d descriptor_namespace=%s\n",
           error, result, actual_id);
    close(fd);
    if (inherited_outer_fd >= 0)
        close(inherited_outer_fd);
    read_ns("/proc/self/ns/cgroup", after);
    printf("setns namespace_before=%s namespace_after=%s\n", before, after);
    return !(result < 0 && error == EPERM && strcmp(before, after) == 0);
}

enum operation { CLONE_BASE, CLONE_PROTECTED, SETNS_PROTECTED, TYPE_BASE, TYPE_PROTECTED };

static int worker(const char *name, enum operation op, const char *leaf, const char *sibling)
{
    char outer_id[128];
    read_ns("/proc/self/ns/cgroup", outer_id);
    int outer_fd = -1;
    if (op == SETNS_PROTECTED) {
        outer_fd = open("/proc/self/ns/cgroup", O_RDONLY | O_CLOEXEC);
        need(outer_fd >= 0, "open scoped supervisor namespace");
    }
    int ready[2], release[2];
    need(pipe2(ready, O_CLOEXEC) == 0 && pipe2(release, O_CLOEXEC) == 0, "worker pipes");
    pid_t outer_pid = getpid();
    int is_protected = op == CLONE_PROTECTED || op == SETNS_PROTECTED || op == TYPE_PROTECTED;
    pid_t pid = fork();
    need(pid >= 0, "fork worker");
    if (pid == 0) {
        close(ready[0]);
        close(release[1]);
        enter(leaf);
        if (is_protected) {
            int result = unshare(CLONE_NEWUSER | CLONE_NEWCGROUP);
            int error = result < 0 ? errno : 0;
            printf("namespace-admission case=%s errno=%d result=%d\n", name, error, result);
            need(result == 0, "combined namespace admission");
        }
        need(write(ready[1], "R", 1) == 1, "worker ready");
        close(ready[1]);
        char byte;
        need(read(release[0], &byte, 1) == 1 && byte == 'G', "worker release");
        close(release[0]);
        if (is_protected) {
            char inner_id[128], profile[128];
            read_ns("/proc/self/ns/cgroup", inner_id);
            read_text("/proc/self/attr/current", profile, sizeof(profile));
            printf("namespace case=%s outer=%s inner=%s uid=%u gid=%u profile=%s",
                   name, outer_id, inner_id, geteuid(), getegid(), profile);
            need(geteuid() == 501 && getegid() == 1000 && strcmp(outer_id, inner_id) != 0,
                 "namespace identity and credentials");
            member("namespace-local", getpid(), "/");
        }
        int result;
        if (op == CLONE_BASE || op == CLONE_PROTECTED) {
            result = try_clone(sibling, is_protected);
        } else if (op == SETNS_PROTECTED) {
            result = try_setns(outer_pid, outer_fd, outer_id);
        } else {
            int expected = op == TYPE_PROTECTED ? EPERM : EOPNOTSUPP;
            result = cg_put(name, leaf, "cgroup.type", "threaded") != expected;
        }
        _exit(result);
    }
    close(ready[1]);
    close(release[0]);
    if (outer_fd >= 0)
        close(outer_fd);
    int pidfd = (int)syscall(SYS_pidfd_open, pid, 0);
    need(pidfd >= 0, "pidfd_open worker");
    char byte;
    if (read(ready[0], &byte, 1) == 1 && byte == 'R') {
        still_held(pidfd);
        member("worker-held-in-exact-leaf", pid, leaf + strlen(MOUNT));
        if (is_protected)
            map_child(pid);
        need(write(release[1], "G", 1) == 1, "release worker");
    }
    close(ready[0]);
    close(release[1]);
    int rc = reap(pidfd, pid, name);
    no_processes(leaf);
    return rc;
}

static void mkdir_exact(char output[MAX_PATH], const char *root, const char *name)
{
    join(output, root, name);
    need(mkdir(output, 0700) == 0, output);
}

static void type_is(const char *leaf, const char *expected)
{
    char path[MAX_PATH], type[64];
    join(path, leaf, "cgroup.type");
    read_text(path, type, sizeof(type));
    printf("type path=%s value=%s", leaf, type);
    need(strcmp(type, expected) == 0, "wrong cgroup type");
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    need(argc == 2 && geteuid() == 501 && getegid() == 1000, "scope account");
    need(strncmp(argv[1], "ptg-linux-native-gates-", 23) == 0 &&
         strspn(argv[1], "abcdefghijklmnopqrstuvwxyz0123456789.-") == strlen(argv[1]),
         "scope identifier");
    char scope_path[MAX_PATH], scope_suffix[MAX_PATH];
    int n = snprintf(scope_suffix, sizeof(scope_suffix), "%s%s", SCOPE_PREFIX, argv[1]);
    need(n > 0 && (size_t)n < sizeof(scope_suffix), "scope suffix");
    n = snprintf(scope_path, sizeof(scope_path), "%s%s", MOUNT, scope_suffix);
    need(n > 0 && (size_t)n < sizeof(scope_path), "scope path");
    member("verify-owned-outer-scope", getpid(), scope_suffix);
    struct stat info;
    struct statfs filesystem;
    need(lstat(scope_path, &info) == 0 && S_ISDIR(info.st_mode) && info.st_uid == geteuid(),
         "verify scope ownership and path");
    need(statfs(scope_path, &filesystem) == 0 && filesystem.f_type == CGROUP2_SUPER_MAGIC,
         "verify cgroup2 filesystem");
    char clone_root[MAX_PATH], source[MAX_PATH], sibling[MAX_PATH], setns_leaf[MAX_PATH];
    char empty_root[MAX_PATH], live_root[MAX_PATH], protected_root[MAX_PATH];
    char empty[MAX_PATH], live[MAX_PATH], protected_leaf[MAX_PATH];
    mkdir_exact(clone_root, scope_path, "clone-root");
    mkdir_exact(source, clone_root, "source");
    mkdir_exact(sibling, clone_root, "sibling");
    mkdir_exact(setns_leaf, scope_path, "setns-leaf");
    mkdir_exact(empty_root, scope_path, "type-empty-root");
    mkdir_exact(live_root, scope_path, "type-live-root");
    mkdir_exact(protected_root, scope_path, "type-protected-root");
    mkdir_exact(empty, empty_root, "leaf");
    mkdir_exact(live, live_root, "leaf");
    mkdir_exact(protected_leaf, protected_root, "leaf");

    int positive = worker("clone3-positive", CLONE_BASE, source, sibling);
    int negative = worker("clone3-protected", CLONE_PROTECTED, source, sibling);
    no_processes(sibling);
    int setns_result = worker("setns-protected", SETNS_PROTECTED, setns_leaf, NULL);
    int type_positive = cg_put("type-empty-positive", empty, "cgroup.type", "threaded");
    type_is(empty, type_positive ? "domain\n" : "threaded\n");
    int kill_threaded = cg_put("kill-empty-threaded-control", empty, "cgroup.kill", "1");
    int type_live = worker("type-live-baseline", TYPE_BASE, live, NULL);
    type_is(live, "domain\n");
    int type_protected = worker("type-live-protected", TYPE_PROTECTED, protected_leaf, NULL);
    type_is(protected_leaf, "domain\n");
    int kill_protected = cg_put("kill-protected-domain-after-exit", protected_leaf, "cgroup.kill", "1");
    no_processes(empty);
    no_processes(protected_leaf);
    printf("summary clone_positive=%d clone_protected=%d setns_protected=%d "
           "type_empty_errno=%d kill_threaded_errno=%d type_live=%d type_protected=%d "
           "kill_protected_errno=%d\n",
           positive, negative, setns_result, type_positive, kill_threaded, type_live,
           type_protected, kill_protected);
    return !!(positive || negative || setns_result || type_positive ||
              kill_threaded != EOPNOTSUPP || type_live || type_protected || kill_protected);
}
PTG_NATIVE_GATES_SOURCE
/usr/bin/sha256sum "$scratch/native-gates.c"
/usr/bin/gcc --version | /usr/bin/sed -n '1p'
TMPDIR="$scratch" /usr/bin/gcc -std=gnu11 -Wall -Wextra -Werror -O2 "$scratch/native-gates.c" -o "$scratch/probe"
/usr/bin/sha256sum "$scratch/probe"
"$scratch/probe" "$unit"
