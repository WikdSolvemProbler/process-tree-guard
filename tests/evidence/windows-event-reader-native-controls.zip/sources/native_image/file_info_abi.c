#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stddef.h>
#include <stdio.h>

_Static_assert(sizeof(FILE_BASIC_INFO) == 40, "FILE_BASIC_INFO size");
_Static_assert(sizeof(FILE_STANDARD_INFO) == 24, "FILE_STANDARD_INFO size");
_Static_assert(sizeof(FILE_ID_INFO) == 24, "FILE_ID_INFO size");
_Static_assert(offsetof(FILE_BASIC_INFO, FileAttributes) == 32, "basic offset");
_Static_assert(offsetof(FILE_STANDARD_INFO, DeletePending) == 20, "delete offset");
_Static_assert(offsetof(FILE_STANDARD_INFO, Directory) == 21, "directory offset");
_Static_assert(offsetof(FILE_ID_INFO, FileId) == 8, "ID offset");
_Static_assert(FileBasicInfo == 0 && FileStandardInfo == 1 && FileIdInfo == 18, "class values");

int main(void) {
    printf("{\"basic_size\":%zu,\"standard_size\":%zu,\"id_size\":%zu,"
           "\"id_bytes\":%zu,\"share_mask\":%lu,\"payload_runs\":0}\n",
           sizeof(FILE_BASIC_INFO), sizeof(FILE_STANDARD_INFO), sizeof(FILE_ID_INFO),
           sizeof(FILE_ID_128), (unsigned long)(FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE));
    return 0;
}
