The prospective image reader preserves independent per-process file inspection. It performs one named-entry metadata open, one content open with held metadata before and after the full hash, and one independent named-entry metadata open afterward. All four native signatures must agree. Every process image path, creation time, Job check, final identity query and liveness read remain in the collector. There is no row grouping, digest cache, or path cache.

The native signature contains volume serial and all 128 file-ID bits, size, allocation, link count, creation time, write time, change time, attributes and file type/deletion state. Basic, standard and ID information classes are 0, 1 and 18. Python layouts assert 40, 24 and 24 bytes, with the same offsets asserted independently against the installed Windows SDK in file_info_abi.c. Any unsupported query or native failure refuses the inspected row. No legacy file-ID fallback exists.

The reader uses OPEN_EXISTING, read-only desired access, null security attributes for non-inheritance, and FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE. All three opens use that explicit sharing policy. It supplies no exclusion against another process changing or deleting the image. Any observed identity, named binding or metadata change refuses the row. This policy avoids relying on incidental CRT sharing behavior. It characterizes the file observed at the retained process's reported path, not originally loaded executable bytes or undetectable concurrent changes.

LastAccessTime is omitted from stable comparison because this observer reads the file. CreationTime, LastWriteTime and ChangeTime are retained separately without treating Python's ctime as a native ChangeTime alias. The prior 009 control established that different Python metadata paths can return different ctime values on this host. This implementation uses the same native interfaces for all compared signatures.

ReadFile reads at most the initial file size, followed by a single one-byte EOF check. Truncation, excess data and any error refuse. All owned handles close on every path. There are no deny-write handles, process interventions, retries, source edits to 013, or changed measurement thresholds. Speed remains unproved until bounded controls on the exact reviewed source.

Microsoft documents the native identity combination in [FILE_ID_INFO](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_id_info), information classes and query results in [GetFileInformationByHandleEx](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-getfileinformationbyhandleex), and opening and sharing in [CreateFileW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew). Structure members are defined in [FILE_BASIC_INFO](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_basic_info) and [FILE_STANDARD_INFO](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_standard_info). Python's documented metadata qualifications are in [Python 3.12 stat_result](https://docs.python.org/3.12/library/os.html#os.stat_result).

Any future full protocol must bind native_image.py alongside its importing inventory_gate.py, preserve its raw per-row file evidence, and distinguish inventory elapsed-budget refusal from disallowed-image refusal. Current work is a component candidate and controls only.


Prospective fixed two-read strengthening: every successful inspected row hashes the
same held file twice, with checked SetFilePointerEx(FILE_BEGIN, signed 64-bit zero)
and verified returned position zero between the reads. Each pass is independently
bounded to the initial size plus one EOF probe. Both complete digests and QPC
brackets, the rewind result, and all original metadata observations are retained;
any mismatch refuses. Failed operations retain partial diagnostic evidence.

This is observed two-read consistency. It does not establish atomic immutability,
original loaded bytes, or detection of every possible concurrent mutation.
SetFilePointerEx API: https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-setfilepointerex
