using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
[assembly: DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
public static class EventSetup005 {
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern bool CreateDirectoryW(string path, IntPtr security);
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern IntPtr CreateFileW(string path,uint access,uint share,IntPtr security,uint creation,uint flags,IntPtr template);
 [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileInformationByHandleEx(IntPtr h,int kind,[Out]byte[] data,uint bytes);
 [DllImport("kernel32.dll", SetLastError=true)] static extern uint GetFileType(IntPtr h);
 [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetHandleInformation(IntPtr h,out uint flags);
 [DllImport("kernel32.dll", SetLastError=true)] static extern bool CloseHandle(IntPtr h);
 // Actual SDK/qualified native_image.py layouts: BASIC40/attrs32,
 // STANDARD24/delete20/directory21, FILE_ID_INFO24/volume0/id8.
 [StructLayout(LayoutKind.Sequential)] struct Basic {public long creation,access,write,change;public uint attributes;}
 [StructLayout(LayoutKind.Sequential)] struct Standard {public long allocation,end;public uint links;public byte delete,directory;}
 [StructLayout(LayoutKind.Sequential)] struct Identity {public ulong volume;[MarshalAs(UnmanagedType.ByValArray,SizeConst=16)] public byte[] id;}
 public static readonly Dictionary<long,string> Owners=new Dictionary<long,string>();
 public static readonly List<Dictionary<string,object>> Calls=new List<Dictionary<string,object>>();
 static EventSetup005(){if(IntPtr.Size!=8||Marshal.SizeOf(typeof(Basic))!=40||Marshal.OffsetOf(typeof(Basic),"attributes").ToInt32()!=32||Marshal.SizeOf(typeof(Standard))!=24||Marshal.OffsetOf(typeof(Standard),"delete").ToInt32()!=20||Marshal.OffsetOf(typeof(Standard),"directory").ToInt32()!=21||Marshal.SizeOf(typeof(Identity))!=24||Marshal.OffsetOf(typeof(Identity),"id").ToInt32()!=8)throw new Exception("Windows64 native file ABI differs");}
 static void Record(string api,long h,bool ok,int error,string path=null){Calls.Add(new Dictionary<string,object>{{"api",api},{"handle",h.ToString()},{"ok",ok},{"error",error},{"path",path}});}
 public static void NewDirectory(string path){bool ok=CreateDirectoryW(path,IntPtr.Zero);int e=Marshal.GetLastWin32Error();Record("CreateDirectoryW",0,ok,ok?0:e,path);if(!ok)throw new Win32Exception(e,"Exclusive fresh directory refused: "+path);}
 public static IntPtr OpenDirectory(string path){IntPtr h=CreateFileW(path,129,3,IntPtr.Zero,3,0x02200000,IntPtr.Zero);int e=Marshal.GetLastWin32Error();bool ok=h!=IntPtr.Zero&&h!=new IntPtr(-1);Record("CreateFileW-access129-share3-openreparse",h.ToInt64(),ok,ok?0:e,path);if(!ok)throw new Win32Exception(e);Owners.Add(h.ToInt64(),path);uint flags;ok=GetHandleInformation(h,out flags);e=Marshal.GetLastWin32Error();Record("GetHandleInformation",h.ToInt64(),ok,ok?0:e,path);if(!ok||(flags&1)!=0){CloseOwned(h);throw new Exception("Fresh directory handle inheritance unconfirmed");}return h;}
 public static bool CloseOwned(IntPtr h){if(!Owners.ContainsKey(h.ToInt64()))throw new Exception("Unknown native owner close refused");bool ok=CloseHandle(h);int e=Marshal.GetLastWin32Error();Record("CloseHandle",h.ToInt64(),ok,ok?0:e,Owners[h.ToInt64()]);if(ok)Owners.Remove(h.ToInt64());return ok;}
 static byte[] Info(IntPtr h,int kind,int count){byte[] b=new byte[count];bool ok=GetFileInformationByHandleEx(h,kind,b,(uint)count);int e=Marshal.GetLastWin32Error();Record("GetFileInformationByHandleEx-"+kind,h.ToInt64(),ok,ok?0:e);if(!ok)throw new Win32Exception(e);return b;}
 public static Dictionary<string,object> Snapshot(IntPtr h,bool allowReparse){uint type=GetFileType(h);int e=Marshal.GetLastWin32Error();Record("GetFileType",h.ToInt64(),type==1,type==1?0:e);if(type!=1)throw new Exception("Own directory is not disk object");byte[] b=Info(h,0,40),s=Info(h,1,24),i=Info(h,18,24);uint attrs=BitConverter.ToUInt32(b,32);if(s[21]==0||s[20]!=0||(attrs&16)==0||(!allowReparse&&(attrs&1024)!=0))throw new Exception("Own directory type/reparse/delete state refused");byte[] tag=null;if(allowReparse){tag=Info(h,9,8);if((attrs&1024)==0||BitConverter.ToUInt32(tag,0)!=attrs||BitConverter.ToUInt32(tag,4)!=0xa0000003u)throw new Exception("Prepared leaf is not exact mount-point junction tag");}byte[] id=new byte[16];Array.Copy(i,8,id,0,16);bool any=false;foreach(byte x in id)any|=x!=0;if(!any)throw new Exception("Missing full file identity");return new Dictionary<string,object>{{"volume",BitConverter.ToUInt64(i,0).ToString()},{"file_id_128",BitConverter.ToString(id).Replace("-","").ToLowerInvariant()},{"creation_ticks",BitConverter.ToInt64(b,0).ToString()},{"attributes",attrs},{"directory",true},{"delete_pending",false},{"reparse_tag",tag==null?(object)null:BitConverter.ToUInt32(tag,4)},{"raw_attribute_tag_b64",tag==null?null:Convert.ToBase64String(tag)},{"raw_basic_b64",Convert.ToBase64String(b)},{"raw_standard_b64",Convert.ToBase64String(s)},{"raw_id_b64",Convert.ToBase64String(i)}};}
 public static Dictionary<string,object> Named(string path,bool allowReparse){IntPtr h=OpenDirectory(path);Exception primary=null;try{return Snapshot(h,allowReparse);}catch(Exception e){primary=e;throw;}finally{bool ok=CloseOwned(h);if(!ok&&primary==null)throw new Exception("Own directory close failed; retained");}}
}
