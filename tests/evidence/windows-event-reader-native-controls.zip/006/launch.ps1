param([Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ApprovedPlanSha)
$ErrorActionPreference='Stop'
$clock=[Diagnostics.Stopwatch]::StartNew()
$root=$PSScriptRoot
$failure=$null;$cleanup=[Collections.Generic.List[object]]::new();$held=[Collections.Generic.List[IntPtr]]::new()
$ownedProcesses=[Collections.Generic.List[object]]::new();$streamOwners=[Collections.Generic.List[object]]::new();$childFacts=[Collections.Generic.List[object]]::new();$helperAttempts=0;$setup=$null;$nativeExit=$null;$nativeReceiptSha=$null
function Bytes-Sha([byte[]]$b){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($b)).ToLowerInvariant()}
function Check-Time {if($clock.Elapsed.TotalSeconds -ge 40){throw '40s coupled launcher ledger expired; outer45Job remains authoritative'}}
function Verify-Pins {
 if((Bytes-Sha ([IO.File]::ReadAllBytes("$root/plan.json"))) -cne $ApprovedPlanSha){throw 'plan changed'}
 foreach($pair in $plan.file_sha256.GetEnumerator()) {if((Bytes-Sha ([IO.File]::ReadAllBytes($pair.Key))) -cne $pair.Value){throw "pinned file differs: $($pair.Key)"}}
 Check-Time
}
function Write-Json-New([string]$path,$value){$b=[Text.UTF8Encoding]::new($false).GetBytes(($value|ConvertTo-Json -Depth 30));$f=[IO.File]::Open($path,'CreateNew','Write','Read');try{$f.Write($b,0,$b.Length);$f.Flush()}finally{$f.Dispose()};return ,$b}
function Run-Owned([string]$program,[string[]]$arguments,[string]$prefix,[int]$limitMs){
 Check-Time
 $fact=@{argv=@($program)+$arguments;prefix=$prefix;attempted=$true;started=$false;terminal=$false;streams=[Collections.Generic.List[object]]::new()};$childFacts.Add($fact)
 $si=[Diagnostics.ProcessStartInfo]::new();$si.FileName=[IO.Path]::GetFullPath($program);$si.UseShellExecute=$false;$si.CreateNoWindow=$true
 $si.RedirectStandardInput=$true;$si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true
 foreach($arg in $arguments){$si.ArgumentList.Add($arg)}
 $acquired=[Collections.Generic.List[object]]::new();$p=$null;$done=$false;$copyActive=$false
 function Own-Stream($stream,[string]$kind){$f=@{kind=$kind;closed=$false};$fact.streams.Add($f);$owner=@{stream=$stream;fact=$f;prefix=$prefix};$acquired.Add($owner);$streamOwners.Add($owner);return $stream}
 function Close-Stream($owner){try{$owner.stream.Dispose();$owner.fact.closed=$true}catch{$owner.fact.close_error=$_.Exception.ToString();$cleanup.Add(@{prefix=$prefix;stream=$owner.fact.kind;error=$owner.fact.close_error})}}
 try {
  $out=Own-Stream ([IO.File]::Open("$prefix.stdout.bin",'CreateNew','Write','Read')) 'stdout-file'
  $err=Own-Stream ([IO.File]::Open("$prefix.stderr.bin",'CreateNew','Write','Read')) 'stderr-file'
  $p=[Diagnostics.Process]::Start($si);$po=@{process=$p;fact=$fact};$ownedProcesses.Add($po)
  $fact.started=$true;$fact.pid=$p.Id;$fact.creation_filetime=$p.StartTime.ToUniversalTime().ToFileTimeUtc().ToString()
  $stdin=Own-Stream $p.StandardInput 'stdin-writer';Close-Stream $acquired[$acquired.Count-1]
  if(-not $acquired[$acquired.Count-1].fact.closed){throw 'stdin close unconfirmed'}
  $stdout=Own-Stream $p.StandardOutput 'stdout-reader';$stderr=Own-Stream $p.StandardError 'stderr-reader'
  $copyOut=$stdout.BaseStream.CopyToAsync($out);$copyActive=$true;$copyErr=$stderr.BaseStream.CopyToAsync($err)
  $wait=[Math]::Max(1,[Math]::Min($limitMs,[Math]::Floor((40-$clock.Elapsed.TotalSeconds)*1000)))
  if(-not $p.WaitForExit([int]$wait)){throw "owned child did not settle within coupled wait: $($p.Id)"}
  $fact.terminal=$true;$fact.exit=$p.ExitCode
  $left=[Math]::Max(1,[Math]::Floor((40-$clock.Elapsed.TotalSeconds)*1000));if(-not $copyOut.Wait([int]$left)){throw 'stdout copy incomplete'}
  $left=[Math]::Max(1,[Math]::Floor((40-$clock.Elapsed.TotalSeconds)*1000));if(-not $copyErr.Wait([int]$left)){throw 'stderr copy incomplete'}
  [void]$copyOut.GetAwaiter().GetResult();[void]$copyErr.GetAwaiter().GetResult();$fact.copies_complete=$true;$done=$true
 } catch {$fact.error=$_.Exception.ToString();throw}
 finally {
  if($done -or -not $copyActive){foreach($owner in $acquired){if(-not $owner.fact.closed -and -not $owner.fact.ContainsKey('close_error')){Close-Stream $owner}}}
  else {$cleanup.Add(@{scope='copy/stream/process custody retained to enclosing process teardown';prefix=$prefix;pid=$(if($p){$p.Id}else{$null})})}
 }
 if(@($fact.streams|Where-Object{$_.closed -ne $true}).Count -ne 0){throw 'child stream disposal unconfirmed'}
 Check-Time
 return @{pid=$fact.pid;creation_filetime=$fact.creation_filetime;exit=$fact.exit;argv=$fact.argv;terminal=$true;streams=$fact.streams;copies_complete=$true}
}

try {
 $raw=[IO.File]::ReadAllBytes("$root/plan.json");if((Bytes-Sha $raw) -cne $ApprovedPlanSha){throw 'unapproved plan'}
 $plan=[Text.Encoding]::UTF8.GetString($raw)|ConvertFrom-Json -AsHashtable
 if($plan.reviewed -ne $true -or $plan.outer_seconds -ne 45 -or $plan.inner_seconds -ne 35){throw 'unapproved scope'}
 Verify-Pins
 $bridge=[IO.File]::ReadAllBytes("$root/native_setup.cs")
 if((Bytes-Sha $bridge) -cne $plan.file_sha256[$plan.native_setup_source]){throw 'native bridge captured bytes differ'}
 # Add-Type compiles this reviewed C# bridge in this fresh PowerShell process;
 # no standalone compiler command is launched. It is inside the outer Job/ledger.
 Add-Type -TypeDefinition ([Text.Encoding]::UTF8.GetString($bridge)) -Language CSharp
 Check-Time
 $capture=[IO.Path]::GetFullPath($plan.capture)
 if($capture -cne [IO.Path]::GetFullPath("$root/attempt-001")){throw 'foreign capture'}
 foreach($p in @($root,(Split-Path -Parent $root))){$item=Get-Item -LiteralPath $p -Force;if(($item.Attributes -band 1024)-ne0 -or -not $item.PSIsContainer){throw 'source parent reparse/type refused'}}
 $setupDir=Join-Path $capture 'setup';$fixtures=Join-Path $capture 'fixtures';$junction=Join-Path $fixtures 'junction';$namespace=Join-Path $junction 'processkit-events';$target=Join-Path $junction 'junction-target';$leaf=Join-Path $namespace 'slot-junction'
 foreach($p in @($capture,$setupDir,$fixtures,$junction,$namespace,$target)){[EventSetup005]::NewDirectory($p)}
 foreach($p in @($capture,$fixtures)){$h=[EventSetup005]::OpenDirectory($p);$held.Add($h);[EventSetup005]::Snapshot($h,$false)|Out-Null}
 $cmd=[IO.Path]::GetFullPath($plan.cmd);$guard=[IO.Path]::GetFullPath($plan.guard)
 $helperAttempts++
 $helper=Run-Owned $guard @('--timeout','5','--',$cmd,'/d','/c','mklink','/J',$leaf,$target) (Join-Path $setupDir 'helper') 7000
 if($helper -isnot [Collections.IDictionary]){throw 'Run-Owned helper result is not one dictionary'}
 if($helper.exit -ne 0){throw 'junction setup helper failed; no fallback/retry'}
 if(@([IO.Directory]::EnumerateFileSystemEntries($target)).Count -ne 0){throw 'setup target not empty'}
 if(@([IO.Directory]::EnumerateFileSystemEntries($namespace)).Count -ne 1){throw 'unexpected setup leaf entries'}
 $roles=@{capture=$capture;setup=$setupDir;fixtures=$fixtures;junction=$junction;namespace=$namespace;target=$target;leaf=$leaf}
 $ids=@{};foreach($name in $roles.Keys){$ids[$name]=[EventSetup005]::Named($roles[$name],($name -eq 'leaf'))}
 if(($ids.leaf.attributes -band 1024)-eq0){throw 'setup leaf is not reparse'}
 $token=[Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32)).ToLowerInvariant()
 $setup=@{schema=1;plan_sha256=$ApprovedPlanSha;token=$token;launcher_pid=$PID;capture=$capture;paths=$roles;identities=$ids;helper=$helper
  helper_stdout_sha256=(Bytes-Sha ([IO.File]::ReadAllBytes((Join-Path $setupDir 'helper.stdout.bin'))));helper_stderr_sha256=(Bytes-Sha ([IO.File]::ReadAllBytes((Join-Path $setupDir 'helper.stderr.bin'))))
  expected_initial_capture=@('fixtures','setup');expected_setup_entries=@('helper.stdout.bin','helper.stderr.bin','manifest.json','python.stdout.bin','python.stderr.bin');native_setup_calls=[EventSetup005]::Calls
  binding='exact-byte SHA passed directly by reviewed launcher; no cryptographic signature claim';held_parent_roles=@('capture','fixtures');setup_elapsed_seconds=$clock.Elapsed.TotalSeconds}
 $manifestPath=Join-Path $setupDir 'manifest.json';$manifestBytes=Write-Json-New $manifestPath $setup;$manifestSha=Bytes-Sha $manifestBytes
 Verify-Pins
 $remaining=[Math]::Min(35.0,40.0-$clock.Elapsed.TotalSeconds-1.0);if($remaining -le 0){throw 'no coupled Python budget remains'}
 $budgetNs=[long][Math]::Floor($remaining*1000000000.0)
 $native=Run-Owned $plan.python @('-I','-B',"$root/control.py",'--approved-plan-sha',$ApprovedPlanSha,'--setup-manifest-sha',$manifestSha,'--setup-token',$token,'--remaining-budget-ns',$budgetNs.ToString()) (Join-Path $setupDir 'python') ([int][Math]::Max(1,[Math]::Floor((40-$clock.Elapsed.TotalSeconds)*1000)))
 if($native -isnot [Collections.IDictionary]){throw 'Run-Owned reader result is not one dictionary'}
 $nativeExit=$native.exit;if($nativeExit -ne 0){throw "reader control failed: $nativeExit"}
 $rb=[IO.File]::ReadAllBytes((Join-Path $capture 'receipt.json'));$nativeReceiptSha=Bytes-Sha $rb;$r=[Text.Encoding]::UTF8.GetString($rb)|ConvertFrom-Json -AsHashtable
 if($r.qualified -ne $true -or $r.code -ne 0 -or $r.cases.Count -ne 13 -or @($r.cases|Where-Object{$_.qualified -ne $true}).Count -ne0 -or $r.handles_after_binding_init -ne $r.handles_final -or $r.counted_python_process_launches -ne 0){throw 'reader result did not meet original strict contract'}
 Verify-Pins;Check-Time
} catch {$failure=$_.Exception.ToString()}
finally {
 foreach($h in $held){try{if(-not [EventSetup005]::CloseOwned($h)){$cleanup.Add(@{native_handle=$h.ToInt64().ToString();error='CloseHandle returned false'})}}catch{$cleanup.Add(@{native_handle=$h.ToInt64().ToString();error=$_.Exception.ToString()})}}
 foreach($po in $ownedProcesses){try{if($po.process.HasExited){$po.fact.terminal=$true;$po.fact.exit=$po.process.ExitCode;$po.process.Dispose();$po.fact.process_disposed=$true}else{$cleanup.Add(@{pid=$po.process.Id;error='owned child remains live; outer Job retains authority'})}}catch{$po.fact.process_dispose_error=$_.Exception.ToString();$cleanup.Add(@{error=$_.Exception.ToString()})}}
}
$remainingNative=@();$calls=@();try{if('EventSetup005' -as [type]){$remainingNative=@([EventSetup005]::Owners.GetEnumerator()|ForEach-Object{@{handle=$_.Key.ToString();path=$_.Value}});$calls=[EventSetup005]::Calls}}catch{$cleanup.Add(@{scope='native inventory unreadable';error=$_.Exception.ToString()});$remainingNative=@(@{state='unreadable; no clean ownership claim'})}
if($clock.Elapsed.TotalSeconds -ge40 -and $null -eq $failure){$failure='coupled launcher ledger exceeded40s'}
$qualified=($null -eq $failure -and $cleanup.Count -eq0 -and $remainingNative.Count -eq0 -and $nativeExit -eq0)
$receipt=@{schema='owned-event-controls005-launcher-v1';qualified=$qualified;failure=$failure;cleanup=$cleanup;remaining_native_owners=$remainingNative;native_setup_calls=$calls
 remaining_stream_owners=@($streamOwners|Where-Object{$_.fact.closed -ne $true}|ForEach-Object{@{prefix=$_.prefix;kind=$_.fact.kind;close_error=$_.fact.close_error}});native_exit=$nativeExit;native_receipt_sha256=$nativeReceiptSha;elapsed_seconds=$clock.Elapsed.TotalSeconds;ledger_seconds=40;outer_job_seconds=45;python_max_seconds=35
 explicit_setup_helper_attempts=$helperAttempts;child_lifecycle=$childFacts;counted_python_process_launches=0;component_scope_only=$true;full_session_or_setup_custody_qualified=$false;old_failures_waived=$false}
Write-Json-New "$root/launcher-receipt-001.json" $receipt|Out-Null
if(-not $qualified){exit 1};exit 0
