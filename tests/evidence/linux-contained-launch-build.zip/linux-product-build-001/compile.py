import base64,gzip,hashlib,json,pathlib,subprocess,sys,time
HERE=pathlib.Path(__file__).resolve().parent
command=(HERE/"ssh-command.txt").read_text(encoding="utf-8")
argv=["C:/Windows/System32/OpenSSH/ssh.exe","-T","-o","BatchMode=yes","-o","StrictHostKeyChecking=yes","-o","ConnectTimeout=8","peters-mac-mini",command]
units=len(subprocess.list2cmdline(argv).encode("utf-16-le"))//2
if units>30000: raise RuntimeError("Windows argv length bound exceeded")
started=time.monotonic_ns()
try:
    result=subprocess.run(argv,input=(HERE/"source-payload.json").read_bytes(),capture_output=True,timeout=145)
except subprocess.TimeoutExpired as e:
    (HERE/"ssh.stdout").write_bytes(e.stdout or b"");(HERE/"ssh.stderr").write_bytes(e.stderr or b"")
    (HERE/"local-timeout.json").write_text(json.dumps({"timeout":145,"no_retry":True})+"\n")
    raise
(HERE/"ssh.stdout").write_bytes(result.stdout);(HERE/"ssh.stderr").write_bytes(result.stderr)
(HERE/"ssh-result.json").write_text(json.dumps({"exit":result.returncode,"elapsed_ns":time.monotonic_ns()-started,"windows_argv_utf16_units":units})+"\n")
lines=[x[len(b"PRESERVED="):] for x in result.stdout.splitlines() if x.startswith(b"PRESERVED=")]
if len(lines)!=1:
    print(json.dumps({"ssh_exit":result.returncode,"preserved_packages":len(lines),"raw_output_saved":True}))
    raise SystemExit(1)
package=gzip.decompress(base64.b64decode(lines[0],validate=True))
if len(package)>128*1024*1024: raise RuntimeError("decoded package bound exceeded")
decoded=json.loads(package);out=HERE/"preserved";out.mkdir()
for row in decoded["files"]:
    parts=pathlib.PurePosixPath(row["path"]).parts
    if not parts or any(x in (".","..","/") or ":" in x or "\\" in x for x in parts): raise RuntimeError("noncanonical artifact path")
    data=base64.b64decode(row["data_b64"],validate=True)
    if len(data)!=row["bytes"] or hashlib.sha256(data).hexdigest()!=row["sha256"]: raise RuntimeError("artifact identity differs")
    target=out.joinpath(*parts);target.parent.mkdir(parents=True,exist_ok=True)
    with target.open("xb") as stream: stream.write(data)
(HERE/"preservation.json").write_text(json.dumps({"files":len(decoded["files"]),"package_sha256":hashlib.sha256(package).hexdigest(),"receipt":decoded["receipt"]},indent=2)+"\n")
print(json.dumps({"ssh_exit":result.returncode,"artifact_files":len(decoded["files"]),"all_pass":decoded["receipt"]["all_pass"],"steps":[{"index":x["index"],"exit":x["exit"]} for x in decoded["receipt"]["records"]]}))
sys.exit(0 if result.returncode==0 and decoded["receipt"]["all_pass"] else 1)
