import hashlib,json,os,pathlib,stat,sys
p=json.loads(sys.stdin.buffer.read(1024*1024))
if os.getuid()!=501 or os.geteuid()!=501: raise RuntimeError("ordinary UID501 required")
checked=[]
for item in p["roots"]:
    root=item["root"];path=pathlib.PurePosixPath(root["path"])
    if path.parent!=pathlib.PurePosixPath("/tmp") or not path.name.startswith("ptg-linux-product-"): raise RuntimeError("outside owned scratch namespace")
    cg=pathlib.Path(item["cgroup_path"])
    if cg.exists() and "populated 0" not in (cg/"cgroup.events").read_text().splitlines(): raise RuntimeError("original scope still populated")
    fd=os.open(str(path),os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    s=os.fstat(fd)
    if (s.st_dev,s.st_ino,s.st_uid)!=(root["dev"],root["ino"],501): raise RuntimeError("scratch identity differs")
    seen={};dirs={}
    for rel,subdirs,files,dfd in os.fwalk(".",dir_fd=fd,follow_symlinks=False):
        prefix="" if rel=="." else rel.removeprefix("./")+"/"
        for name in subdirs:
            ds=os.stat(name,dir_fd=dfd,follow_symlinks=False)
            if not stat.S_ISDIR(ds.st_mode) or ds.st_uid!=501: raise RuntimeError("unexpected directory")
            dirs[prefix+name]=(ds.st_dev,ds.st_ino)
        for name in files:
            key=prefix+name
            if key not in item["files"]: raise RuntimeError("unexpected scratch member")
            ff=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dfd)
            try:
                fs=os.fstat(ff);h=hashlib.sha256()
                if not stat.S_ISREG(fs.st_mode) or fs.st_uid!=501 or fs.st_size!=item["files"][key]["bytes"]: raise RuntimeError("artifact metadata differs")
                while True:
                    b=os.read(ff,1024*1024)
                    if not b: break
                    h.update(b)
                if h.hexdigest()!=item["files"][key]["sha256"]: raise RuntimeError("artifact bytes differ")
                seen[key]=(fs.st_dev,fs.st_ino)
            finally:os.close(ff)
    if set(seen)!=set(item["files"]): raise RuntimeError("scratch census differs")
    checked.append((item,fd,seen,dirs))
removed=[]
for item,fd,seen,dirs in checked:
    for rel,subdirs,files,dfd in os.fwalk(".",topdown=False,dir_fd=fd,follow_symlinks=False):
        prefix="" if rel=="." else rel.removeprefix("./")+"/"
        for name in files:
            s=os.stat(name,dir_fd=dfd,follow_symlinks=False)
            if (s.st_dev,s.st_ino)!=seen[prefix+name]: raise RuntimeError("artifact replaced before unlink")
            os.unlink(name,dir_fd=dfd)
        for name in subdirs:
            s=os.stat(name,dir_fd=dfd,follow_symlinks=False)
            if (s.st_dev,s.st_ino)!=dirs[prefix+name]: raise RuntimeError("directory replaced before removal")
            os.rmdir(name,dir_fd=dfd)
    root=item["root"];parent=os.open("/tmp",os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    name=pathlib.PurePosixPath(root["path"]).name
    try:
        s=os.stat(name,dir_fd=parent,follow_symlinks=False)
        if (s.st_dev,s.st_ino)!=(root["dev"],root["ino"]):raise RuntimeError("root name no longer identifies owned directory")
        os.rmdir(name,dir_fd=parent)
    finally:os.close(parent);os.close(fd)
    row={"root":root,"files_verified":len(seen),"absent_after":not os.path.lexists(root["path"]),"scope_absent_after":not os.path.exists(item["cgroup_path"])}
    removed.append(row);print("CLEANED="+json.dumps(row),flush=True)
print("RESULT="+json.dumps({"removed":removed,"all_owned_scratch_absent":all(x["absent_after"] for x in removed),"scope":"Only exact identity-and-byte-verified build/unit scratch; no runtime reset or other worker cleanup; trusted nonadversarial same-UID build workspace."}),flush=True)
