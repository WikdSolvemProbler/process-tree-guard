import json,pathlib,subprocess,sys
H=pathlib.Path(__file__).resolve().parent
args=["C:/Windows/System32/OpenSSH/ssh.exe","-T","-o","BatchMode=yes","-o","StrictHostKeyChecking=yes","-o","ConnectTimeout=8","peters-mac-mini",(H/"ssh-command.txt").read_text()]
if len(subprocess.list2cmdline(args).encode("utf-16-le"))//2>30000:raise RuntimeError("argv too long")
r=subprocess.run(args,input=(H/"payload.json").read_bytes(),capture_output=True,timeout=145)
(H/"ssh.stdout").write_bytes(r.stdout);(H/"ssh.stderr").write_bytes(r.stderr)
(H/"ssh-exit.txt").write_text(str(r.returncode)+"\n")
rows=[json.loads(x[7:]) for x in r.stdout.splitlines() if x.startswith(b"RESULT=")]
if r.returncode or len(rows)!=1:print(r.stdout.decode(errors="replace"));print(r.stderr.decode(errors="replace"));raise SystemExit(1)
(H/"receipt.json").write_text(json.dumps(rows[0],indent=2)+"\n")
print(json.dumps({"exit":r.returncode,"removed":len(rows[0]["removed"]),"all_owned_scratch_absent":rows[0]["all_owned_scratch_absent"],"all_original_scopes_absent":all(x["scope_absent_after"] for x in rows[0]["removed"])}))
