use super::*;

const TOKEN: &[u8] = b"PTGA1";
const SOL_SOCKET: i32 = 1;
const SCM_RIGHTS: i32 = 1;
const SCM_CREDENTIALS: i32 = 2;

#[repr(C)]
struct IoVec { base: *mut u8, len: usize }
#[repr(C)]
struct Message {
    name: *mut c_void, name_len: u32, vec: *mut IoVec, vec_len: usize,
    control: *mut Control, control_len: usize, flags: i32,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct Cred { pid: i32, uid: u32, gid: u32 }
#[repr(C)]
#[derive(Default)]
struct Control { len: usize, level: i32, kind: i32, cred: Cred }

unsafe extern "C" {
    fn socketpair(domain: i32, kind: i32, protocol: i32, pair: *mut i32) -> i32;
    fn setsockopt(fd: i32, level: i32, opt: i32, value: *const i32, len: u32) -> i32;
    fn recvmsg(fd: i32, message: *mut Message, flags: i32) -> isize;
    fn sendmsg(fd: i32, message: *const Message, flags: i32) -> isize;
}

fn pair() -> Result<(OwnedFd, OwnedFd)> {
    let mut pair = [-1; 2];
    os_ok(i64::from(unsafe { socketpair(1, 5 | CLOEXEC, 0, pair.as_mut_ptr()) }))?;
    let [receiver, sender] = pair.map(|fd| unsafe { OwnedFd::from_raw_fd(fd) });
    os_ok(i64::from(unsafe { setsockopt(receiver.as_raw_fd(), SOL_SOCKET, 16, &1, 4) }))?;
    Ok((receiver, sender))
}

fn message(vec: &mut IoVec, control: &mut Control) -> Message {
    Message { name: ptr::null_mut(), name_len: 0, vec, vec_len: 1,
              control, control_len: size_of::<Control>(), flags: 0 }
}

fn send_control(fd: RawFd, kind: i32, cred: Cred, len: usize) -> Result<()> {
    let mut token = TOKEN.to_vec();
    let mut vec = IoVec { base: token.as_mut_ptr(), len: token.len() };
    let mut control = Control { len, level: SOL_SOCKET, kind, cred };
    let mut msg = message(&mut vec, &mut control);
    msg.control_len = len;
    let count = os_ok(unsafe { sendmsg(fd, &msg, 0) } as i64)?;
    check(count as usize == TOKEN.len(), "short seqpacket send")
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct Identity { pub uid: u32, pub gid: u32, pub groups: Vec<u32> }
impl Identity {
    pub(super) fn fixture() -> Self { Self { uid: 501, gid: 1000, groups: vec![999, 1000] } }
}

fn read_identity(owner: &Held, cred: Cred) -> Result<Identity> {
    owner.live()?;
    check(cred.pid == owner.pid, "unexpected kernel sender PID")?;
    let status = fs::read_to_string(format!("/proc/{}/status", owner.pid))?;
    let field = |name| status.lines().find_map(|line| line.strip_prefix(name))
        .map(str::trim).ok_or_else(|| io::Error::other("missing credential field"));
    let ids = |name| -> Result<Vec<u32>> {
        field(name)?.split_whitespace().map(|s| s.parse().map_err(io::Error::other)).collect()
    };
    check(cred.uid != 0 && cred.gid != 0 && ids("Uid:")? == [cred.uid; 4]
          && ids("Gid:")? == [cred.gid; 4], "sender IDs do not match held owner")?;
    for name in ["CapEff:", "CapPrm:", "CapInh:", "CapAmb:"] {
        check(field(name)? == "0000000000000000", "sender retained capabilities")?;
    }
    check(field("NoNewPrivs:")? == "1", "sender could reacquire privileges")?;
    let groups = ids("Groups:")?;
    check(!groups.contains(&0), "sender has root group")?;
    owner.live()?;
    Ok(Identity { uid: cred.uid, gid: cred.gid, groups })
}

fn validate_root(root: &Path) -> Result<()> {
    check(root.parent() == Some(Path::new("/sys/fs/cgroup/system.slice")),
          "cgroup root outside approved system slice")?;
    check(root.canonicalize()? == root, "cgroup authority alias")?;
    for path in root.ancestors().take(3) {
        let meta = fs::symlink_metadata(path)?;
        check(meta.is_dir() && meta.uid() == 0 && meta.gid() == 0 && meta.mode() & 0o022 == 0,
              "cgroup authority directory is writable by caller")?;
    }
    for name in ["cgroup.procs", "cgroup.kill", "cgroup.events"] {
        let meta = fs::symlink_metadata(root.join(name))?;
        check(meta.is_file() && meta.uid() == 0 && meta.gid() == 0 && meta.mode() & 0o022 == 0,
              "cgroup controller is writable by caller")?;
    }
    membership(std::process::id() as i32, root)
}

fn receive(socket: &OwnedFd, owner: &Held, root: &Path) -> Result<Identity> {
    owner.live()?;
    let [socket_events, owner_events] = poll_flags([socket.as_raw_fd(), owner.fd()], 1000)?;
    check(owner_events == 0, "owner died before admission")?;
    check(socket_events & POLLIN != 0, "admission packet unavailable")?;
    let mut token = [0; 64];
    let mut vec = IoVec { base: token.as_mut_ptr(), len: token.len() };
    // SO_PASSCRED puts credentials first. With space for that one record, the kernel
    // discards and closes any excess rights and sets MSG_CTRUNC.
    let mut control = Control::default();
    let mut msg = message(&mut vec, &mut control);
    let count = os_ok(unsafe { recvmsg(socket.as_raw_fd(), &mut msg, 0x40000000) } as i64)? as usize;
    check(msg.flags == 0 || msg.flags == 0x40000000, "truncated admission packet or ancillary data")?;
    check(count == TOKEN.len() && &token[..count] == TOKEN, "malformed admission packet")?;
    check(msg.control_len == size_of::<Control>() && control.len == 28
          && control.level == SOL_SOCKET && control.kind == SCM_CREDENTIALS, "unexpected ancillary record")?;
    let identity = read_identity(owner, control.cred)?;
    validate_root(root)?;
    owner.live()?;
    Ok(identity)
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub(super) enum Attempt { Valid, Malformed, ForgedUid, ForgedGid, WrongPeer, InjectedPidfd, WrongRoot, OwnerDead }
impl Attempt {
    fn label(self) -> &'static str {
        match self {
            Self::Valid => "valid", Self::Malformed => "malformed", Self::ForgedUid => "forged-uid",
            Self::ForgedGid => "forged-gid", Self::WrongPeer => "wrong-peer",
            Self::InjectedPidfd => "injected-pidfd", Self::WrongRoot => "wrong-root",
            Self::OwnerDead => "owner-dead",
        }
    }
}

pub(super) fn attempt(root: &Path, kind: Attempt, unrelated: &Held) -> Result<Option<(Held, Identity)>> {
    let (receiver, sender) = pair()?;
    let (ready, sent) = exact_pipe()?;
    let pid = fork_exact()?;
    if pid == 0 {
        drop((receiver, ready));
        end((|| {
            drop_identity(&Identity::fixture())?;
            let fd = sender.as_raw_fd();
            let pid = std::process::id() as i32;
            match kind {
                Attempt::Malformed => output(fd, b"PTGA1uid=0 gid=0 groups=0 root=/tmp")?,
                Attempt::ForgedUid | Attempt::ForgedGid => {
                    let cred = Cred { pid, uid: if kind == Attempt::ForgedUid { 0 } else { 501 },
                                      gid: if kind == Attempt::ForgedGid { 0 } else { 1000 } };
                    check(send_control(fd, SCM_CREDENTIALS, cred, 28).err()
                              .and_then(|e| e.raw_os_error()) == Some(1), "kernel accepted forged credential")?;
                    // A rejected send cannot fall through to a command.
                    drop(sender);
                }
                Attempt::WrongPeer => {
                    let peer = fork_exact()?;
                    if peer == 0 { end(output(fd, TOKEN).map(|()| 0)); }
                    check(Held::new(peer)?.reap("unexpected-peer-reaped")? == 0, "wrong-peer sender failed")?;
                }
                Attempt::InjectedPidfd => {
                    send_control(fd, SCM_RIGHTS, Cred { pid: unrelated.fd(), uid: 0, gid: 0 }, 20)?;
                }
                _ => output(fd, TOKEN)?,
            }
            output(sent.as_raw_fd(), b"S")?;
            parked()
        })());
    }
    drop((sender, sent));
    // No concurrent waiter or SIGCHLD auto-reap: forked child PID remains reserved
    // even if the child exits before pidfd_open. The request never supplies this FD.
    let owner = Held::new(pid)?;
    check(poll_flags([ready.as_raw_fd()], 1000)?[0] & POLLIN != 0, "sender readiness")?;
    let mut token = [0];
    check(input(ready.as_raw_fd(), &mut token)? == 1 && token == [b'S'], "sender handshake")?;
    if kind == Attempt::OwnerDead {
        owner.kill()?;
        check(readable(poll_flags([owner.fd()], 1000)?[0]), "owner death fixture not ready")?;
    }
    let result = receive(&receiver, &owner, if kind == Attempt::WrongRoot { Path::new("/tmp") } else { root });
    if kind == Attempt::Valid {
        let identity = result?;
        check(identity == Identity::fixture(), "captured identity differs from fixture")?;
        println!("admission=valid pid={pid} uid={} gid={} groups={:?}", identity.uid, identity.gid, identity.groups);
        return Ok(Some((owner, identity)));
    }
    let expected = match kind {
        Attempt::Malformed => "malformed admission packet",
        Attempt::ForgedUid | Attempt::ForgedGid => "malformed admission packet",
        Attempt::WrongPeer => "unexpected kernel sender PID",
        Attempt::InjectedPidfd => "truncated admission packet or ancillary data",
        Attempt::WrongRoot => "cgroup root outside approved system slice",
        Attempt::OwnerDead => "held PID already exited",
        Attempt::Valid => unreachable!(),
    };
    check(result.expect_err("negative admission accepted").to_string() == expected, "unexpected refusal reason")?;
    if kind != Attempt::OwnerDead { owner.kill()?; }
    check(owner.reap("admission-reaped-caller")? == 137, "caller cleanup")?;

    unrelated.live()?;
    println!("admission={} status=125 reason={expected} sibling=alive", kind.label());
    Ok(None)
}

