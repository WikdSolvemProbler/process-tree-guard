set -eu
umask 077
unit=ptg-linux-external-20261106-a2fd0e18.scope
scope=/system.slice/ptg-linux-external-20261106-a2fd0e18.scope
root=/sys/fs/cgroup$scope
scratch=/tmp/ptg-linux-external-20261106-a2fd0e18
expected_hash=$1
case "$expected_hash" in *[!0-9a-f]*) exit 90;; esac
[ "${#expected_hash}" -eq 64 ]
[ "$(/usr/bin/id -u)" = 0 ]
[ "$(/usr/bin/id -g)" = 0 ]
[ "$(/usr/bin/cat /proc/$$/cgroup)" = "0::$scope" ]
[ "$(/usr/bin/realpath -e -- "$root")" = "$root" ]
[ "$(/usr/bin/stat -c '%u:%g' -- "$root")" = 0:0 ]
[ "$(/usr/bin/stat -f -c %T -- "$root")" = cgroup2fs ]
/usr/bin/grep -Fxq 'nr_descendants 0' "$root/cgroup.stat"
properties=$(/usr/bin/systemctl --system show "$unit" --property=Delegate,ControlGroup,RuntimeMaxUSec,KillMode,KillSignal,SendSIGKILL,ActiveState)
printf '%s\n' "$properties"
for exact in Delegate=no "ControlGroup=$scope" RuntimeMaxUSec=30s KillMode=control-group KillSignal=9 SendSIGKILL=yes ActiveState=active; do
    printf '%s\n' "$properties" | /usr/bin/grep -Fxq -- "$exact"
done
/usr/bin/uname -srvmo
/usr/bin/mkdir -m 700 -- "$scratch"
cleanup() {
    result=$?
    trap - EXIT
    for leaf in normal pre post sibling; do
        target="$root/$leaf"
        if [ -d "$target" ]; then
            if /usr/bin/grep -Fxq 'populated 1' "$target/cgroup.events"; then
                printf '1' > "$target/cgroup.kill" || result=91
                attempt=0
                while /usr/bin/grep -Fxq 'populated 1' "$target/cgroup.events" && [ "$attempt" -lt 20 ]; do
                    /usr/bin/sleep 0.025
                    attempt=$((attempt+1))
                done
            fi
            if /usr/bin/rmdir -- "$target"; then printf 'removed cgroup=%s\n' "$target"; else result=91; fi
        fi
    done
    if /usr/bin/rm -f -- "$scratch/proof" "$scratch/admission.sock" "$scratch.normal.marker" "$scratch.pre.marker" "$scratch.post.marker" && /usr/bin/rmdir -- "$scratch" && [ ! -e "$scratch" ]; then
        printf 'root_scratch_removed=%s\n' "$scratch"
    else
        result=92
    fi
    /usr/bin/cat "$root/cgroup.stat"
    exit "$result"
}
trap cleanup EXIT
/usr/bin/cat > "$scratch/proof"
root_hash=$(/usr/bin/sha256sum "$scratch/proof")
printf 'root_copy_sha256 %s\n' "$root_hash"
[ "${root_hash%% *}" = "$expected_hash" ]
/usr/bin/chmod 0755 -- "$scratch" "$scratch/proof"
"$scratch/proof" "$unit"
