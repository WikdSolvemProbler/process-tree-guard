//! Native Linux test seam for the root-owned process-tree proof.
#![cfg(all(target_os = "linux", any(target_arch = "aarch64", target_arch = "x86_64")))]

use std::ffi::{CString, c_char, c_int, c_long, c_uint, c_void};
use std::fs::{self, File, OpenOptions};
use std::io::{self, Write};
use std::mem::size_of;
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd, RawFd};
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{MetadataExt, OpenOptionsExt};
use std::path::{Path, PathBuf};
use std::ptr;
use std::sync::atomic::{AtomicI32, Ordering};
use std::time::{Duration, Instant};

mod admission;
use admission::Identity;

const SIGKILL: i32 = 9;
const SIGPIPE: i32 = 13;
const SIGCHLD: u64 = 17;
const CLOEXEC: i32 = 0o2_000_000;
const NOFOLLOW: i32 = 0o400_000;
const PATH_FD: i32 = 0o10_000_000;
const DIRECTORY: i32 = 0o200_000;
const F_DUPFD_CLOEXEC: i32 = 1030;
const EINTR: i32 = 4;
const ECHILD: i32 = 10;
const EPIPE: i32 = 32;
const ENOENT: i32 = 2;
const POLLIN: i16 = 1;
const POLLHUP: i16 = 16;
const CLOCK_BOOTTIME: i32 = 7;
const SYS_PIDFD_SEND_SIGNAL: c_long = 424;
const SYS_PIDFD_OPEN: c_long = 434;
const SYS_CLONE3: c_long = 435;
const SYS_CLOSE_RANGE: c_long = 436;

#[repr(C)]
struct PollFd { fd: c_int, events: i16, revents: i16 }
#[repr(C)]
#[derive(Clone, Copy, Default)]
struct Timespec { seconds: i64, nanos: i64 }
#[repr(C)]
struct ItimerSpec { interval: Timespec, value: Timespec }
#[repr(C)]
#[derive(Default)]
struct CloneArgs {
    flags: u64, pidfd: u64, child_tid: u64, parent_tid: u64, exit_signal: u64,
    stack: u64, stack_size: u64, tls: u64, set_tid: u64, set_tid_size: u64, cgroup: u64,
}

unsafe extern "C" {
    fn syscall(number: c_long, ...) -> c_long;
    fn fork() -> c_int;
    fn pipe2(pipe: *mut c_int, flags: c_int) -> c_int;
    fn poll(fds: *mut PollFd, count: usize, timeout: c_int) -> c_int;
    fn read(fd: c_int, data: *mut c_void, len: usize) -> isize;
    fn write(fd: c_int, data: *const c_void, len: usize) -> isize;
    fn close(fd: c_int) -> c_int;
    fn dup3(old: c_int, new: c_int, flags: c_int) -> c_int;
    fn fcntl(fd: c_int, command: c_int, ...) -> c_int;
    fn waitpid(pid: c_int, status: *mut c_int, flags: c_int) -> c_int;
    fn clock_gettime(clock: c_int, value: *mut Timespec) -> c_int;
    fn timerfd_create(clock: c_int, flags: c_int) -> c_int;
    fn timerfd_settime(fd: c_int, flags: c_int, value: *const ItimerSpec, old: *mut ItimerSpec) -> c_int;
    fn signal(signal: c_int, handler: usize) -> usize;
    fn prctl(option: c_int, arg2: c_long, arg3: c_long, arg4: c_long, arg5: c_long) -> c_int;
    fn setgroups(count: usize, groups: *const c_uint) -> c_int;
    fn setresgid(real: c_uint, effective: c_uint, saved: c_uint) -> c_int;
    fn setresuid(real: c_uint, effective: c_uint, saved: c_uint) -> c_int;
    fn geteuid() -> c_uint;
    fn getegid() -> c_uint;
    fn pause() -> c_int;
    fn execve(path: *const c_char, argv: *const *const c_char, env: *const *const c_char) -> c_int;
    fn mmap(addr: *mut c_void, len: usize, prot: c_int, flags: c_int, fd: c_int, offset: i64) -> *mut c_void;
    fn mprotect(addr: *mut c_void, len: usize, prot: c_int) -> c_int;
    fn munmap(addr: *mut c_void, len: usize) -> c_int;
    fn _exit(status: c_int) -> !;
}

type Result<T> = io::Result<T>;
const PENDING: i32 = 0;
const PLACED: i32 = 1;
const RELEASED: i32 = 2;
const CANCELLED: i32 = 3;
const FINISHED: i32 = 4;

fn check(condition: bool, message: &str) -> Result<()> {
    if condition { Ok(()) } else { Err(io::Error::other(message)) }
}
fn os_ok(value: i64) -> Result<i64> {
    if value >= 0 { Ok(value) } else { Err(io::Error::last_os_error()) }
}
fn exact_pipe() -> Result<(OwnedFd, OwnedFd)> {
    let mut ends = [-1; 2];
    os_ok(i64::from(unsafe { pipe2(ends.as_mut_ptr(), CLOEXEC) }))?;
    Ok(unsafe { (OwnedFd::from_raw_fd(ends[0]), OwnedFd::from_raw_fd(ends[1])) })
}
fn input(fd: RawFd, data: &mut [u8]) -> Result<usize> {
    loop {
        let n = unsafe { read(fd, data.as_mut_ptr().cast(), data.len()) };
        if n >= 0 { return Ok(n as usize); }
        let error = io::Error::last_os_error();
        if error.raw_os_error() != Some(EINTR) { return Err(error); }
    }
}
fn output(fd: RawFd, data: &[u8]) -> Result<()> {
    loop {
        let n = unsafe { write(fd, data.as_ptr().cast(), data.len()) };
        if n >= 0 { return check(n as usize == data.len(), "short atomic pipe write"); }
        let error = io::Error::last_os_error();
        if error.raw_os_error() != Some(EINTR) { return Err(error); }
    }
}
fn poll_flags<const N: usize>(fds: [RawFd; N], timeout: i32) -> Result<[i16; N]> {
    let mut p = fds.map(|fd| PollFd { fd, events: POLLIN, revents: 0 });
    loop {
        if unsafe { poll(p.as_mut_ptr(), N, timeout) } >= 0 { return Ok(p.map(|entry| entry.revents)); }
        let error = io::Error::last_os_error();
        if error.raw_os_error() != Some(EINTR) { return Err(error); }
    }
}
fn readable(flags: i16) -> bool { flags & (POLLIN | POLLHUP) != 0 }
fn parked() -> ! { loop { unsafe { pause(); } } }
fn end(result: Result<i32>) -> ! {
    match result {
        Ok(status) => unsafe { _exit(status) },
        Err(error) => { eprintln!("proof-process-error {error}"); unsafe { _exit(90) } }
    }
}
fn fork_exact() -> Result<i32> { Ok(os_ok(i64::from(unsafe { fork() }))? as i32) }

struct Held { pid: i32, fd: OwnedFd }
impl Held {
    fn new(pid: i32) -> Result<Self> {
        check(pid > 0, "invalid held pid")?;
        let fd = os_ok(unsafe { syscall(SYS_PIDFD_OPEN, c_long::from(pid), 0 as c_long) })? as RawFd;
        Ok(Self { pid, fd: unsafe { OwnedFd::from_raw_fd(fd) } })
    }
    fn fd(&self) -> RawFd { self.fd.as_raw_fd() }
    fn live(&self) -> Result<()> { check(poll_flags([self.fd()], 0)? == [0], "held PID already exited") }
    fn kill(&self) -> Result<()> {
        os_ok(unsafe { syscall(SYS_PIDFD_SEND_SIGNAL, c_long::from(self.fd()), c_long::from(SIGKILL),
                                ptr::null::<c_void>(), 0 as c_long) })?;
        Ok(())
    }
    fn reap(self, label: &str) -> Result<i32> {
        check(readable(poll_flags([self.fd()], 1500)?[0]), "held PID did not terminate")?;
        let mut status = 0;
        check(unsafe { waitpid(self.pid, &mut status, 0) } == self.pid, "held direct child wait failed")?;
        let result = status_code(status);
        println!("{label} pid={} status={result}", self.pid);
        Ok(result)
    }
}
fn status_code(status: i32) -> i32 {
    let signal = status & 0x7f;
    if signal == 0 { (status >> 8) & 0xff } else { 128 + signal }
}

fn clock() -> Result<Timespec> {
    let mut value = Timespec::default();
    os_ok(i64::from(unsafe { clock_gettime(CLOCK_BOOTTIME, &mut value) }))?;
    Ok(value)
}
fn deadline_timer(seconds: i64) -> Result<OwnedFd> {
    let fd = os_ok(i64::from(unsafe { timerfd_create(CLOCK_BOOTTIME, CLOEXEC) }))? as RawFd;
    let fd = unsafe { OwnedFd::from_raw_fd(fd) };
    let mut value = clock()?;
    value.seconds += seconds;
    let deadline = ItimerSpec { interval: Timespec::default(), value };
    os_ok(i64::from(unsafe { timerfd_settime(fd.as_raw_fd(), 1, &deadline, ptr::null_mut()) }))?;
    Ok(fd)
}

fn membership(pid: i32, expected: &Path) -> Result<()> {
    let contents = fs::read_to_string(format!("/proc/{pid}/cgroup"))?;
    let suffix = expected.strip_prefix("/sys/fs/cgroup").map_err(io::Error::other)?;
    check(contents.trim_end() == format!("0::/{}", suffix.display()), "cgroup membership mismatch")?;
    println!("membership pid={pid} path={}", expected.display());
    Ok(())
}
fn control(leaf: &Path, name: &str) -> Result<File> {
    OpenOptions::new().write(true).custom_flags(NOFOLLOW).open(leaf.join(name))
}
fn require_empty(leaf: &Path) -> Result<()> {
    let until = Instant::now() + Duration::from_secs(1);
    loop {
        let state = fs::read_to_string(leaf.join("cgroup.events"))?;
        if state.lines().any(|line| line == "populated 0") {
            println!("drained path={} populated=0", leaf.display());
            return Ok(());
        }
        check(Instant::now() < until, "cgroup drain deadline")?;
        std::thread::sleep(Duration::from_millis(10));
    }
}
fn kill_tree(leaf: &Path, mut kill: File) -> Result<()> {
    kill.write_all(b"1")?;
    require_empty(leaf)
}
fn set_subreaper() -> Result<()> {
    os_ok(i64::from(unsafe { prctl(36, 1, 0, 0, 0) }))?;
    Ok(())
}
fn drop_identity(identity: &Identity) -> Result<()> {
    os_ok(i64::from(unsafe { prctl(47, 4, 0, 0, 0) }))?;
    os_ok(i64::from(unsafe { setgroups(identity.groups.len(), identity.groups.as_ptr()) }))?;
    os_ok(i64::from(unsafe { setresgid(identity.gid, identity.gid, identity.gid) }))?;
    os_ok(i64::from(unsafe { setresuid(identity.uid, identity.uid, identity.uid) }))?;
    os_ok(i64::from(unsafe { prctl(38, 1, 0, 0, 0) }))?;
    Ok(())
}

struct Gate(*mut AtomicI32);
impl Gate {
    fn new() -> Result<Self> {
        let memory = unsafe { mmap(ptr::null_mut(), size_of::<AtomicI32>(), 3, 0x21, -1, 0) };
        check(memory as isize != -1, "shared gate mmap failed")?;
        let gate = Self(memory.cast());
        unsafe { gate.0.write(AtomicI32::new(PENDING)); }
        Ok(gate)
    }
    fn state(&self) -> &AtomicI32 { unsafe { &*self.0 } }
    fn read_only(&self) -> Result<()> {
        os_ok(i64::from(unsafe { mprotect(self.0.cast(), size_of::<AtomicI32>(), 1) }))?;
        Ok(())
    }
}
impl Drop for Gate {
    fn drop(&mut self) { unsafe { munmap(self.0.cast(), size_of::<AtomicI32>()); } }
}

const ARMED: i32 = 1;
const HELD: i32 = 2;
const EXEC: i32 = 3;
const DONE: i32 = 4;
const RECOVERY: i32 = 5;
const BEFORE_CHILD_FD_CLOSE: i32 = 6;
const NORMAL: i32 = 1;
const EXEC_ERROR: i32 = 2;
const OWNER_LOST: i32 = 3;
const DEADLINE: i32 = 4;
const SUPERVISOR_LOST: i32 = 5;
const WATCHDOG_LOST: i32 = 6;

#[repr(C)]
#[derive(Clone, Copy, Default)]
struct Note { stage: i32, watcher: i32, child: i32, cause: i32, detail: i32, status: i32 }
fn send_note(fd: RawFd, note: &Note) -> Result<()> {
    let data = unsafe { std::slice::from_raw_parts(ptr::from_ref(note).cast(), size_of::<Note>()) };
    output(fd, data)
}
fn receive_note(fd: RawFd) -> Result<Option<Note>> {
    let mut note = Note::default();
    let data = unsafe { std::slice::from_raw_parts_mut(ptr::from_mut(&mut note).cast(), size_of::<Note>()) };
    let n = input(fd, data)?;
    if n == 0 { return Ok(None); }
    check(n == size_of::<Note>(), "short watchdog receipt")?;
    Ok(Some(note))
}
fn require_note(fd: RawFd) -> Result<Note> {
    receive_note(fd)?.ok_or_else(|| io::Error::other("missing watchdog receipt"))
}

struct Command { program: CString, argv: Vec<CString>, hold_before_fd_close: bool, identity: Identity }
impl Command {
    fn new(path: &Path, args: &[&str]) -> Result<Self> {
        let program = CString::new(path.as_os_str().as_bytes())?;
        let mut argv = vec![program.clone()];
        for arg in args { argv.push(CString::new(*arg)?); }
        Ok(Self { program, argv, hold_before_fd_close: false, identity: Identity::fixture() })
    }
}

fn launch_held(
    leaf: &Path, gate: &Gate, command: &Command, permit: RawFd, ready: RawFd, errors: RawFd,
) -> Result<Held> {
    let target = OpenOptions::new().read(true).custom_flags(PATH_FD | DIRECTORY | NOFOLLOW).open(leaf)?;
    let mut pidfd = -1i32;
    let args = CloneArgs {
        flags: 0x2_0000_0000 | 0x1000,
        pidfd: ptr::from_mut(&mut pidfd) as u64,
        exit_signal: SIGCHLD,
        cgroup: target.as_raw_fd() as u64,
        ..CloneArgs::default()
    };
    let child = os_ok(unsafe { syscall(SYS_CLONE3, ptr::from_ref(&args), size_of::<CloneArgs>()) })? as i32;
    if child == 0 {
        // The test-only fault holds the trusted trampoline with its inherited fds open.
        if command.hold_before_fd_close { parked(); }
        end(child_before_exec(leaf, gate, command, [permit, ready, errors]));
    }
    check(pidfd >= 0, "clone3 did not install pidfd")?;
    println!("atomic-clone3 pid={child} pidfd={pidfd}");
    Ok(Held { pid: child, fd: unsafe { OwnedFd::from_raw_fd(pidfd) } })
}
fn child_before_exec(leaf: &Path, gate: &Gate, command: &Command, fds: [RawFd; 3]) -> Result<i32> {
    membership(std::process::id() as i32, leaf)?;
    let mut staged = [-1; 3];
    for (i, fd) in fds.into_iter().enumerate() {
        staged[i] = os_ok(i64::from(unsafe { fcntl(fd, F_DUPFD_CLOEXEC, 10i32) }))? as RawFd;
    }
    for (i, fd) in staged.into_iter().enumerate() {
        os_ok(i64::from(unsafe { dup3(fd, 3 + i as RawFd, CLOEXEC) }))?;
    }
    os_ok(unsafe { syscall(SYS_CLOSE_RANGE, 6 as c_long, u32::MAX as c_long, 0 as c_long) })?;
    gate.read_only()?;
    drop_identity(&command.identity)?;
    let mut argv: Vec<_> = command.argv.iter().map(|arg| arg.as_ptr()).collect();
    argv.push(ptr::null());
    let env = [c"PATH=/usr/bin:/bin".as_ptr(), c"LC_ALL=C".as_ptr(), ptr::null()];
    output(4, b"R")?;
    unsafe { close(4); }
    let mut permit = [0];
    let n = input(3, &mut permit)?;
    unsafe { close(3); }
    if n != 1 || permit != [b'G'] || gate.state().load(Ordering::Acquire) != RELEASED {
        return Ok(125);
    }
    unsafe { execve(command.program.as_ptr(), argv.as_ptr(), env.as_ptr()); }
    let errno = io::Error::last_os_error().raw_os_error().ok_or_else(|| io::Error::other("missing exec errno"))?;
    output(5, &errno.to_ne_bytes())?;
    Ok(127)
}

struct Watches { supervisor: RawFd, owner: RawFd, timer: RawFd }
impl Watches {
    fn event(&self, input: RawFd, timeout: i32) -> Result<(i32, bool)> {
        let ready = poll_flags([self.supervisor, self.owner, self.timer, input], timeout)?;
        let cause = if readable(ready[0]) { SUPERVISOR_LOST }
                    else if readable(ready[1]) { OWNER_LOST }
                    else if readable(ready[2]) { DEADLINE }
                    else { 0 };
        if cause == 0 && !readable(ready[3]) {
            check(ready == [0; 4], "unexpected poll event")?;
        }
        Ok((cause, readable(ready[3])))
    }
}

struct WatchInputs { supervisor: RawFd, owner: RawFd, request: OwnedFd, permit: OwnedFd,
                     result: RawFd, evidence: RawFd }
fn watchdog(leaf: &Path, gate: &Gate, command: &Command, channels: WatchInputs) -> Result<i32> {
    let kill = control(leaf, "cgroup.kill")?;
    let timer = deadline_timer(6)?;
    let watches = Watches { supervisor: channels.supervisor, owner: channels.owner, timer: timer.as_raw_fd() };
    let mut note = Note { stage: ARMED, watcher: std::process::id() as i32, ..Note::default() };
    send_note(channels.evidence, &note)?;
    let (mut cause, requested) = watches.event(channels.request.as_raw_fd(), -1)?;
    let mut child = None;
    if cause == 0 && requested {
        let mut token = [0];
        check(input(channels.request.as_raw_fd(), &mut token)? == 1 && token == [b'L'], "invalid launch request")?;
        cause = watches.event(-1, 0)?.0;
        if cause == 0 {
            let (ready_in, ready_out) = exact_pipe()?;
            let (error_in, error_out) = exact_pipe()?;
            let held = launch_held(leaf, gate, command, channels.permit.as_raw_fd(),
                                   ready_out.as_raw_fd(), error_out.as_raw_fd())?;
            drop((ready_out, error_out));
            note.child = held.pid;
            if command.hold_before_fd_close {
                note.stage = BEFORE_CHILD_FD_CLOSE;
                send_note(channels.evidence, &note)?;
            }
            let (cancel, ready) = watches.event(ready_in.as_raw_fd(), -1)?;
            cause = cancel;
            if cause == 0 && ready {
                let mut token = [0];
                check(input(ready_in.as_raw_fd(), &mut token)? == 1 && token == [b'R'], "payload did not arm")?;
                gate.state().compare_exchange(PENDING, PLACED, Ordering::AcqRel, Ordering::Acquire)
                    .map_err(|_| io::Error::other("publish held payload after cancellation"))?;
                note.stage = HELD;
                send_note(channels.evidence, &note)?;
                let (cancel, report) = watches.event(error_in.as_raw_fd(), -1)?;
                cause = cancel;
                if cause == 0 && report {
                    let mut error = [0; 4];
                    match input(error_in.as_raw_fd(), &mut error)? {
                        0 if gate.state().load(Ordering::Acquire) == RELEASED => {
                            note.stage = EXEC;
                            send_note(channels.evidence, &note)?;
                            let (cancel, exited) = watches.event(held.fd(), -1)?;
                            cause = if cancel == 0 && exited { NORMAL } else { cancel };
                        }
                        0 => { cause = watches.event(-1, -1)?.0; }
                        4 => {
                            note.detail = i32::from_ne_bytes(error);
                            check(note.detail > 0, "invalid exec errno")?;
                            cause = EXEC_ERROR;
                        }
                        _ => return Err(io::Error::other("partial exec errno frame")),
                    }
                }
            }
            child = Some(held);
        }
    }
    drop((channels.request, channels.permit));
    check(cause != 0, "watchdog has no terminal cause")?;
    let mut observed = None;
    if cause == NORMAL || cause == EXEC_ERROR {
        gate.state().store(FINISHED, Ordering::Release);
        if let Some(process) = child.take() {
            observed = Some(process.reap("watchdog-reaped-payload")?);
        }
    } else {
        gate.state().store(CANCELLED, Ordering::Release);
    }
    kill_tree(leaf, kill)?;
    if let Some(process) = child {
        observed = Some(process.reap("watchdog-reaped-cancelled-payload")?);
    }
    if cause == EXEC_ERROR {
        check(observed == Some(127), "exec failure marker lost its trusted child status")?;
    }
    note.stage = DONE;
    note.cause = cause;
    note.status = match cause { NORMAL => observed.ok_or_else(|| io::Error::other("missing payload exit"))?,
                               DEADLINE => 124, _ => 125 };
    send_note(channels.evidence, &note)?;
    if let Err(error) = send_note(channels.result, &note) {
        if error.raw_os_error() != Some(EPIPE) { return Err(error); }
    }
    Ok(0)
}

fn reap_adopted() -> Result<i32> {
    let until = Instant::now() + Duration::from_secs(1);
    let mut count = 0;
    loop {
        let mut status = 0;
        let pid = unsafe { waitpid(-1, &mut status, 1) };
        if pid > 0 {
            count += 1;
            println!("supervisor-reaped-adopted pid={pid} status={}", status_code(status));
        } else if pid < 0 {
            check(io::Error::last_os_error().raw_os_error() == Some(ECHILD), "reap adopted children")?;
            return Ok(count);
        } else {
            check(Instant::now() < until, "adopted child wait deadline")?;
            std::thread::sleep(Duration::from_millis(10));
        }
    }
}
fn supervisor(leaf: &Path, gate: &Gate, command: &Command, owner: Held,
              instructions: OwnedFd, evidence: OwnedFd) -> Result<i32> {
    set_subreaper()?;
    let backup = control(leaf, "cgroup.kill")?;
    let myself = Held::new(std::process::id() as i32)?;
    let (launch_in, launch_out) = exact_pipe()?;
    let (permit_in, permit_out) = exact_pipe()?;
    let (result_in, result_out) = exact_pipe()?;
    let pid = fork_exact()?;
    if pid == 0 {
        drop((backup, instructions, launch_out, permit_out, result_in));
        let channels = WatchInputs {
            supervisor: myself.fd(), owner: owner.fd(), request: launch_in, permit: permit_in,
            result: result_out.as_raw_fd(), evidence: evidence.as_raw_fd(),
        };
        end(watchdog(leaf, gate, command, channels));
    }
    drop((myself, owner, launch_in, permit_in, result_out));
    let watchdog = Held::new(pid)?;
    let mut launch = Some(launch_out);
    let mut permit = Some(permit_out);
    let mut instructions = Some(instructions);
    loop {
        let fds = [result_in.as_raw_fd(), watchdog.fd(), instructions.as_ref().map_or(-1, AsRawFd::as_raw_fd)];
        let events = poll_flags(fds, -1)?;
        // A just-cloned trampoline can still hold a copy of the result writer.
        // A signaled watchdog pidfd must never turn into a blocking result read.
        if events[0] & POLLIN != 0 {
            let note = require_note(result_in.as_raw_fd())?;
            check(note.stage == DONE && note.watcher == pid, "invalid final watchdog receipt")?;
            check(watchdog.reap("supervisor-reaped-watchdog")? == 0, "watchdog failed after completion")?;
            return Ok(note.status);
        }
        if readable(events[0]) || readable(events[1]) {
            println!("supervisor-fallback-events result={} watchdog={}", events[0], events[1]);
            // Close the sole exec authority before confirming the sole clone authority died.
            gate.state().store(CANCELLED, Ordering::Release);
            drop((launch.take(), permit.take()));
            let watcher_status = watchdog.reap("supervisor-observed-watchdog-death")?;
            kill_tree(leaf, backup)?;
            let adopted = reap_adopted()?;
            let recovered = Note { stage: RECOVERY, watcher: pid, cause: WATCHDOG_LOST,
                                   detail: adopted, status: 125, child: watcher_status };
            send_note(evidence.as_raw_fd(), &recovered)?;
            return Ok(125);
        }
        if readable(events[2]) {
            let mut token = [0];
            let instruction = instructions.as_ref().expect("poll tracks the instruction fd");
            match input(instruction.as_raw_fd(), &mut token)? {
                0 => { instructions = None; }
                1 if token == [b'L'] => {
                    let fd = launch.take().ok_or_else(|| io::Error::other("duplicate launch"))?;
                    if let Err(error) = output(fd.as_raw_fd(), b"L") {
                        if error.raw_os_error() != Some(EPIPE) { return Err(error); }
                    }
                }
                1 if token == [b'G'] => {
                    let fd = permit.take().ok_or_else(|| io::Error::other("duplicate release"))?;
                    if gate.state().compare_exchange(PLACED, RELEASED, Ordering::AcqRel, Ordering::Acquire).is_ok() {
                        if let Err(error) = output(fd.as_raw_fd(), b"G") {
                            if error.raw_os_error() != Some(EPIPE) { return Err(error); }
                        }
                    }
                }
                _ => return Err(io::Error::other("invalid supervisor instruction")),
            }
        }
    }
}

fn held_sibling(leaf: &Path) -> Result<Held> {
    let (ready, tell) = exact_pipe()?;
    let pid = fork_exact()?;
    if pid == 0 {
        drop(ready);
        end((|| {
            control(leaf, "cgroup.procs")?.write_all(b"0")?;
            membership(std::process::id() as i32, leaf)?;
            output(tell.as_raw_fd(), b"R")?;
            drop(tell);
            parked()
        })());
    }
    drop(tell);
    let held = Held::new(pid)?;
    let mut byte = [0];
    check(input(ready.as_raw_fd(), &mut byte)? == 1 && byte == [b'R'], "sibling readiness")?;
    held.live()?;
    Ok(held)
}
fn verify_fixture_credentials() -> Result<()> {
    for fd in 3..=5 {
        check(unsafe { fcntl(fd, 1) } < 0 && io::Error::last_os_error().raw_os_error() == Some(9),
              "inherited startup control descriptor")?;
    }
    let proc_status = fs::read_to_string("/proc/self/status")?;
    for (name, expected) in [
        ("Uid:", "501 501 501 501"), ("Gid:", "1000 1000 1000 1000"),
        ("Groups:", "999 1000"), ("CapEff:", "0000000000000000"),
        ("CapPrm:", "0000000000000000"), ("CapInh:", "0000000000000000"),
        ("CapAmb:", "0000000000000000"), ("NoNewPrivs:", "1"),
    ] {
        let actual = proc_status.lines().find_map(|line| line.strip_prefix(name))
            .ok_or_else(|| io::Error::other("missing process credential field"))?;
        check(actual.split_whitespace().collect::<Vec<_>>().join(" ") == expected, "credential mismatch")?;
        println!("fixture {name} {expected}");
    }
    Ok(())
}

fn run() -> Result<i32> {
    let args: Vec<_> = std::env::args_os().collect();
    if args.len() == 3 && args[1] == "--external-client" {
        return admission::client(Path::new(&args[2]));
    }
    if args.len() == 4 && args[1] == "--fixture" {
        verify_fixture_credentials()?;

        check(args[2] == "127" || args[2] == "hold-marker", "invalid fixture mode")?;
        check(args.len() == 4, "exec marker required")?;
        OpenOptions::new().write(true).create_new(true).mode(0o600).open(&args[3])?.write_all(b"exec 127\n")?;
        if args[2] == "hold-marker" { parked(); }
        return Ok(127);
    }
    check(args.len() == 2 && unsafe { geteuid() == 0 && getegid() == 0 }, "require exact root system scope")?;
    let unit = args[1].to_str().ok_or_else(|| io::Error::other("invalid scope encoding"))?;
    let stem = unit.strip_suffix(".scope").ok_or_else(|| io::Error::other("invalid scope unit"))?;
    let id = stem.strip_prefix("ptg-linux-external-").ok_or_else(|| io::Error::other("wrong scope prefix"))?;
    check(id.len() == 17 && id.bytes().all(|c| c.is_ascii_hexdigit() || c == b'-'), "scope ID shape")?;
    let root = PathBuf::from("/sys/fs/cgroup/system.slice").join(unit);
    check(root.canonicalize()? == root, "unexpected cgroup alias")?;
    let metadata = fs::symlink_metadata(&root)?;
    check(metadata.is_dir() && metadata.uid() == 0 && metadata.gid() == 0 && metadata.mode() & 0o022 == 0,
          "scope ownership")?;
    membership(std::process::id() as i32, &root)?;
    check(fs::read_to_string(root.join("cgroup.stat"))?.lines().any(|line| line == "nr_descendants 0"),
          "scope already has child cgroups")?;
    let binary = std::env::current_exe()?;
    check(binary == PathBuf::from("/tmp").join(stem).join("proof"), "unexpected proof binary")?;
    let executable = fs::symlink_metadata(&binary)?;
    check(executable.is_file() && executable.uid() == 0 && executable.mode() & 0o022 == 0, "unsafe proof binary")?;
    set_subreaper()?;
    unsafe { signal(SIGPIPE, 1); }
    let sibling_leaf = root.join("sibling");
    fs::create_dir(&sibling_leaf)?;
    let sibling = held_sibling(&sibling_leaf)?;
    let scratch = PathBuf::from("/tmp").join(stem);
    let socket = scratch.join("admission.sock");
    admission::serve(&root, &binary, &socket, &scratch, &sibling)?;
    fs::remove_file(socket)?;
    kill_tree(&sibling_leaf, control(&sibling_leaf, "cgroup.kill")?)?;
    check(sibling.reap("controller-reaped-independent-sibling")? == 137, "sibling cleanup")?;
    println!("external-root-owned-proof=passed");
    Ok(0)
}
fn main() -> std::process::ExitCode {
    match run() {
        Ok(status) => std::process::ExitCode::from(status as u8),
        Err(error) => { eprintln!("rust-proof-error {error}"); std::process::ExitCode::from(90) }
    }
}
