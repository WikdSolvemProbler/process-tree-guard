# Linux external one-shot activation fixture

A normal guest user launched the client independently of the trusted root
fixture. The latter was activated in a separate bounded root scope. It bound
one private Unix seqpacket rendezvous and used the accepted socket credentials
and per-message kernel credentials together with an actual transferred pidfd.

Seven requests were refused before a payload cgroup or exec marker appeared.
The valid client ran the fixed contained fixture and received exit 127. Caller
loss before release prevented exec. Caller loss after exec triggered cgroup
drain. The sibling survived every case.

The archive records ARM64 Linux 6.8, Rust 1.99.0, exact source and executable
hashes, scope deadlines, outputs and independent cleanup. It qualifies this
external-caller fixture. A product activation policy, general command
authorization, and Linux 5.14 execution are separate work.
