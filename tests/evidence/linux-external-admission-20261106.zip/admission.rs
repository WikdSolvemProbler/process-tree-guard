use super::*;

const SOL_SOCKET: i32 = 1;
const TOKEN: &[u8] = b"PTGEX1";
const CONTROL_SPACE: usize = 64;
const DENIALS: [&str; 7] = ["wrong", "dead", "file", "extra", "transferred", "forged", "malformed"];

#[repr(C)]
struct IoVec { base: *mut u8, len: usize }
#[repr(C)]
struct Message {
    name: *mut c_void, name_len: u32, vec: *mut IoVec, vec_len: usize,
    control: *mut u8, control_len: usize, flags: i32,
}
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct Cred { pid: i32, uid: u32, gid: u32 }
#[repr(C)]
struct Addr { family: u16, path: [u8; 108] }

unsafe extern "C" {
    fn socket(domain: i32, kind: i32, protocol: i32) -> i32;
    fn bind(fd: i32, addr: *const Addr, len: u32) -> i32;
    fn connect(fd: i32, addr: *const Addr, len: u32) -> i32;
    fn listen(fd: i32, backlog: i32) -> i32;
    fn accept4(fd: i32, addr: *mut c_void, len: *mut u32, flags: i32) -> i32;
    fn getsockopt(fd: i32, level: i32, opt: i32, value: *mut Cred, len: *mut u32) -> i32;
    fn setsockopt(fd: i32, level: i32, opt: i32, value: *const i32, len: u32) -> i32;
    fn recvmsg(fd: i32, message: *mut Message, flags: i32) -> isize;
    fn sendmsg(fd: i32, message: *const Message, flags: i32) -> isize;
}

fn new_socket() -> Result<OwnedFd> {
    let fd = os_ok(i64::from(unsafe { socket(1, 5 | CLOEXEC, 0) }))? as RawFd;
    Ok(unsafe { OwnedFd::from_raw_fd(fd) })
}
fn address(path: &Path) -> Result<(Addr, u32)> {
    let bytes = path.as_os_str().as_bytes();
    let mut addr = Addr { family: 1, path: [0; 108] };
    check(bytes.len() < addr.path.len() && !bytes.contains(&0), "rendezvous address")?;
    addr.path[..bytes.len()].copy_from_slice(bytes);
    Ok((addr, (3 + bytes.len()) as u32))
}
fn call(value: i32) -> Result<()> { os_ok(i64::from(value)).map(|_| ()) }
fn create_listener(path: &Path) -> Result<OwnedFd> {
    let fd = new_socket()?;
    let (addr, len) = address(path)?;
    // Set on the listening socket before bind/accept, so a fast sender cannot race SO_PASSCRED.
    call(unsafe { setsockopt(fd.as_raw_fd(), SOL_SOCKET, 16, &1, 4) })?;
    call(unsafe { bind(fd.as_raw_fd(), &addr, len) })?;
    fs::set_permissions(path, std::os::unix::fs::PermissionsExt::from_mode(0o660))?;
    std::os::unix::fs::chown(path, Some(0), Some(1000))?;
    call(unsafe { listen(fd.as_raw_fd(), 1) })?;
    Ok(fd)
}
fn connected(path: &Path) -> Result<OwnedFd> {
    let fd = new_socket()?;
    let (addr, len) = address(path)?;
    call(unsafe { connect(fd.as_raw_fd(), &addr, len) })?;
    Ok(fd)
}
fn wait_data(fd: RawFd) -> Result<()> {
    check(poll_flags([fd], 2200)?[0] & POLLIN != 0, "socket data deadline")
}
fn accept(listener: RawFd) -> Result<OwnedFd> {
    wait_data(listener)?;
    let fd = os_ok(i64::from(unsafe { accept4(listener, ptr::null_mut(), ptr::null_mut(), CLOEXEC) }))? as RawFd;
    Ok(unsafe { OwnedFd::from_raw_fd(fd) })
}
fn make_message(vec: &mut IoVec, control: &mut [u64; 8], len: usize) -> Message {
    Message { name: ptr::null_mut(), name_len: 0, vec, vec_len: 1,
              control: control.as_mut_ptr().cast(), control_len: len, flags: 0 }
}
fn append(control: &mut [u64; 8], offset: usize, kind: i32, payload: &[u8]) -> usize {
    let raw = unsafe { std::slice::from_raw_parts_mut(control.as_mut_ptr().cast::<u8>(), CONTROL_SPACE) };
    let len = 16 + payload.len();
    raw[offset..offset + 8].copy_from_slice(&len.to_ne_bytes());
    raw[offset + 8..offset + 12].copy_from_slice(&SOL_SOCKET.to_ne_bytes());
    raw[offset + 12..offset + 16].copy_from_slice(&kind.to_ne_bytes());
    raw[offset + 16..offset + len].copy_from_slice(payload);
    offset + len.next_multiple_of(8)
}
fn send_request(fd: RawFd, mode: &str, rights: &[RawFd]) -> Result<()> {
    let mut payload = if mode == "malformed" { b"PTGEX1uid=0".to_vec() } else { TOKEN.to_vec() };
    let mut vec = IoVec { base: payload.as_mut_ptr(), len: payload.len() };
    let mut control = [0u64; 8];
    let data: Vec<_> = rights.iter().flat_map(|fd| fd.to_ne_bytes()).collect();
    let mut end_at = append(&mut control, 0, 1, &data);
    if mode == "forged" {
        let fake = [std::process::id(), 0, 0].into_iter().flat_map(u32::to_ne_bytes).collect::<Vec<_>>();
        end_at = append(&mut control, end_at, 2, &fake);
    }
    let msg = make_message(&mut vec, &mut control, end_at);
    let result = unsafe { sendmsg(fd, &msg, 0) };
    if mode == "forged" {
        return check(result == -1 && io::Error::last_os_error().raw_os_error() == Some(1), "kernel allowed forged identity");
    }
    check(os_ok(result as i64)? as usize == payload.len(), "short request send")
}
fn recv_request(fd: RawFd) -> Result<(Cred, OwnedFd)> {
    let mut peer = Cred::default();
    let mut peer_len = 12;
    call(unsafe { getsockopt(fd, SOL_SOCKET, 17, &mut peer, &mut peer_len) })?;
    check(peer_len == 12, "peer credentials shape")?;
    wait_data(fd)?;
    let mut payload = [0u8; 64];
    let mut vec = IoVec { base: payload.as_mut_ptr(), len: payload.len() };
    let mut control = [0u64; 8];
    let mut msg = make_message(&mut vec, &mut control, CONTROL_SPACE);
    let count = os_ok(unsafe { recvmsg(fd, &mut msg, 0x40000000) } as i64)? as usize;
    let raw = unsafe { std::slice::from_raw_parts(control.as_ptr().cast::<u8>(), msg.control_len) };
    let mut cursor = 0;
    let mut creds = Vec::new();
    let mut rights = Vec::new();
    let mut other = false;
    let integer = |bytes: &[u8]| i32::from_ne_bytes(bytes.try_into().expect("four-byte ancillary integer"));
    while cursor + 16 <= raw.len() {
        let len = usize::from_ne_bytes(raw[cursor..cursor + 8].try_into().expect("native ancillary length"));
        check(len >= 16 && cursor + len <= raw.len(), "ancillary length")?;
        let level = integer(&raw[cursor + 8..cursor + 12]);
        let kind = integer(&raw[cursor + 12..cursor + 16]);
        let data = &raw[cursor + 16..cursor + len];
        match (level, kind) {
            (SOL_SOCKET, 1) => {
                for item in data.chunks_exact(4) {
                    rights.push(unsafe { OwnedFd::from_raw_fd(integer(item)) });
                }
                other |= data.len() % 4 != 0;
            }
            (SOL_SOCKET, 2) if data.len() == 12 => creds.push(Cred {
                pid: integer(&data[..4]), uid: integer(&data[4..8]) as u32, gid: integer(&data[8..]) as u32,
            }),
            _ => other = true,
        }
        cursor += len.next_multiple_of(8);
    }
    check(msg.flags & !0x40000000 == 0 && !other, "unexpected ancillary data or truncation")?;
    check(count == TOKEN.len() && &payload[..count] == TOKEN, "malformed request")?;
    check(creds.as_slice() == [peer], "connection and packet sender mismatch")?;
    check(rights.len() == 1, "expected exactly one transferred descriptor")?;
    Ok((peer, rights.pop().expect("one descriptor")))
}

fn match_pidfd(cred: Cred, fd: OwnedFd) -> Result<Held> {
    let number = fd.as_raw_fd();
    check(fs::read_link(format!("/proc/self/fd/{number}"))? == Path::new("anon_inode:[pidfd]"),
          "not a pidfd")?;
    let info = fs::read_to_string(format!("/proc/self/fdinfo/{number}"))?;
    let pid = info.lines().find_map(|line| line.strip_prefix("Pid:")).and_then(|value| value.trim().parse::<i32>().ok());
    check(cred.pid > 0 && pid == Some(cred.pid), "pidfd does not name packet sender")?;
    let owner = Held { pid: cred.pid, fd };
    owner.live()?;
    Ok(owner)
}


#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct Identity { pub uid: u32, pub gid: u32, pub groups: Vec<u32> }
impl Identity {
    pub(super) fn fixture() -> Self { Self { uid: 501, gid: 1000, groups: vec![999, 1000] } }
}

fn read_identity(owner: &Held, cred: Cred) -> Result<Identity> {
    owner.live()?;
    check(cred.pid == owner.pid, "unexpected kernel sender PID")?;
    let status = fs::read_to_string(format!("/proc/{}/status", owner.pid))?;
    let field = |name| status.lines().find_map(|line| line.strip_prefix(name))
        .map(str::trim).ok_or_else(|| io::Error::other("missing credential field"));
    let ids = |name| -> Result<Vec<u32>> {
        field(name)?.split_whitespace().map(|s| s.parse().map_err(io::Error::other)).collect()
    };
    check(cred.uid != 0 && cred.gid != 0 && ids("Uid:")? == [cred.uid; 4]
          && ids("Gid:")? == [cred.gid; 4], "sender IDs do not match held owner")?;
    for name in ["CapEff:", "CapPrm:", "CapInh:", "CapAmb:"] {
        check(field(name)? == "0000000000000000", "sender retained capabilities")?;
    }
    check(field("NoNewPrivs:")? == "1", "sender could reacquire privileges")?;
    let groups = ids("Groups:")?;
    check(!groups.contains(&0), "sender has root group")?;
    owner.live()?;
    Ok(Identity { uid: cred.uid, gid: cred.gid, groups })
}

fn validate_root(root: &Path) -> Result<()> {
    check(root.parent() == Some(Path::new("/sys/fs/cgroup/system.slice")),
          "cgroup root outside approved system slice")?;
    check(root.canonicalize()? == root, "cgroup authority alias")?;
    for path in root.ancestors().take(3) {
        let meta = fs::symlink_metadata(path)?;
        check(meta.is_dir() && meta.uid() == 0 && meta.gid() == 0 && meta.mode() & 0o022 == 0,
              "cgroup authority directory is writable by caller")?;
    }
    for name in ["cgroup.procs", "cgroup.kill", "cgroup.events"] {
        let meta = fs::symlink_metadata(root.join(name))?;
        check(meta.is_file() && meta.uid() == 0 && meta.gid() == 0 && meta.mode() & 0o022 == 0,
              "cgroup controller is writable by caller")?;
    }
    membership(std::process::id() as i32, root)
}


fn marker_absent(marker: &Path) -> Result<()> {
    check(fs::symlink_metadata(marker).err().and_then(|e| e.raw_os_error()) == Some(ENOENT),
          "exec marker exists before release")
}

fn supervised(root: &Path, binary: &Path, mode: &str, peer: &OwnedFd, owner: Held,
              identity: Identity, sibling: &Held, scratch: &Path) -> Result<()> {
    let leaf = root.join(mode);
    let marker = scratch.with_extension(format!("{mode}.marker"));
    marker_absent(&marker)?;
    let gate = Gate::new()?;
    let args = ["--fixture", if mode == "normal" { "127" } else { "hold-marker" },
                marker.to_str().ok_or_else(|| io::Error::other("marker encoding"))?];
    let mut command = Command::new(binary, &args)?;
    command.identity = identity;
    fs::create_dir(&leaf)?;
    let (instructions, send) = exact_pipe()?;
    let (notes, evidence) = exact_pipe()?;
    let supervisor_pid = fork_exact()?;
    if supervisor_pid == 0 {
        drop((send, notes));
        end(supervisor(&leaf, &gate, &command, owner, instructions, evidence));
    }
    drop((instructions, evidence));
    let supervisor = Held::new(supervisor_pid)?;
    let notes = notes.as_raw_fd();
    check(require_note(notes)?.stage == ARMED, "external supervisor not armed")?;
    owner.live()?;
    output(send.as_raw_fd(), b"L")?;
    let placed = require_note(notes)?;
    check(placed.stage == HELD, "external payload not held")?;
    let child = Held::new(placed.child)?;
    membership(child.pid, &leaf)?;
    if mode == "pre" {
        output(peer.as_raw_fd(), b"D")?;
    } else {
        owner.live()?;
        output(send.as_raw_fd(), b"G")?;
        check(require_note(notes)?.stage == EXEC, "external exec receipt")?;
        if mode == "post" {
            let until = Instant::now() + Duration::from_secs(1);
            while !marker.exists() {
                check(Instant::now() < until, "exec marker deadline")?;
                std::thread::sleep(Duration::from_millis(5));
            }
            output(peer.as_raw_fd(), b"D")?;
        }
    }
    let final_note = require_note(notes)?;
    let (cause, status) = if mode == "normal" { (NORMAL, 127) } else { (OWNER_LOST, 125) };
    check(final_note.stage == DONE && final_note.cause == cause && final_note.status == status,
          "external lifecycle disposition")?;
    check(supervisor.reap("controller-reaped-external-supervisor")? == status, "external supervisor status")?;
    check(readable(poll_flags([child.fd()], 0)?[0]), "external payload survived")?;
    require_empty(&leaf)?;
    fs::remove_dir(&leaf)?;
    if mode == "pre" {
        marker_absent(&marker)?;
    } else {
        check(fs::read(&marker)? == b"exec 127\n" && fs::metadata(&marker)?.uid() == 501,
              "exec marker content or identity")?;
        fs::remove_file(&marker)?;
    }
    if mode == "normal" {
        owner.live()?;
        output(peer.as_raw_fd(), &[127])?;
    } else {
        check(readable(poll_flags([owner.fd()], 0)?[0]), "external caller remained alive")?;
    }
    sibling.live()?;
    println!("external={mode} status={status} cause={cause} marker={} cgroup=drained sibling=alive",
             if mode == "pre" { "absent" } else { "verified" });
    Ok(())
}

pub(super) fn serve(root: &Path, binary: &Path, socket: &Path, scratch: &Path, sibling: &Held) -> Result<()> {
    validate_root(root)?;
    let listener = create_listener(socket)?;
    println!("external-rendezvous-ready");
    for mode in DENIALS.into_iter().chain(["normal", "pre", "post"]) {
        let peer = accept(listener.as_raw_fd())?;
        let admission = recv_request(peer.as_raw_fd()).and_then(|(cred, fd)| {
            let owner = match_pidfd(cred, fd)?;
            let identity = read_identity(&owner, cred)?;
            check(identity == Identity::fixture(), "identity outside root allowlist")?;
            Ok((owner, identity))
        });
        if DENIALS.contains(&mode) {
            let reason = match mode {
                "wrong" | "dead" => "pidfd does not name packet sender",
                "file" => "not a pidfd",
                "extra" => "expected exactly one transferred descriptor",
                "transferred" => "connection and packet sender mismatch",
                "forged" | "malformed" => "malformed request",
                _ => unreachable!(),
            };
            let error = match admission { Ok(_) => return Err(io::Error::other("negative admitted")), Err(e) => e };
            if error.to_string() != reason { return Err(io::Error::other(format!("{mode} wrong refusal: {error}"))); }
            marker_absent(&scratch.with_extension(format!("{mode}.marker")))?;
            check(!root.join(mode).exists(), "negative allocated payload cgroup")?;
            sibling.live()?;
            output(peer.as_raw_fd(), &[125])?;
            println!("external={mode} status=125 reason={reason} marker=absent payload_cgroup=absent sibling=alive");
        } else {
            let (owner, identity) = admission?;
            println!("external-authenticated pid={} uid={} gid={} groups={:?}", owner.pid, identity.uid, identity.gid, identity.groups);
            supervised(root, binary, mode, &peer, owner, identity, sibling, scratch)?;
        }
    }
    Ok(())
}

fn client_case(path: &Path, mode: &str) -> Result<i32> {
    let until = Instant::now() + Duration::from_secs(4);
    let socket = loop {
        match connected(path) {
            Ok(fd) => break fd,
            Err(e) if matches!(e.raw_os_error(), Some(2 | 111)) && Instant::now() < until =>
                std::thread::sleep(Duration::from_millis(10)),
            Err(e) => return Err(e),
        }
    };
    let fd = socket.as_raw_fd();
    if mode == "transferred" {
        let pid = fork_exact()?;
        if pid != 0 { return Held::new(pid)?.reap("client-reaped-socket-recipient"); }
    }
    let me = Held::new(std::process::id() as i32)?;
    let mut wrong = None;
    let file = File::open("/dev/null")?;
    let rights = match mode {
        "wrong" | "dead" => {
            let pid = fork_exact()?;
            if pid == 0 { parked(); }
            let held = Held::new(pid)?;
            if mode == "dead" {
                held.kill()?;
                let mut status = 0;
                check(unsafe { waitpid(pid, &mut status, 0) } == pid && status_code(status) == 137, "dead pidfd fixture")?;
            }
            let foreign = held.fd();
            wrong = Some(held);
            vec![foreign]
        }
        "file" => vec![file.as_raw_fd()],
        "extra" => vec![me.fd(), file.as_raw_fd()],
        _ => vec![me.fd()],
    };
    send_request(fd, mode, &rights)?;
    if mode == "forged" {
        unsafe extern "C" { fn shutdown(fd: i32, how: i32) -> i32; }
        call(unsafe { shutdown(fd, 1) })?;
        println!("external-client kernel rejected forged credentials with EPERM");
    }
    wait_data(fd)?;
    let mut response = [0u8; 1];
    check(input(fd, &mut response)? == 1, "missing external response")?;
    if mode == "wrong" {
        let wrong = wrong.take().expect("foreign pidfd");
        wrong.kill()?;
        check(wrong.reap("client-reaped-unrelated-process")? == 137, "foreign process cleanup")?;
    }
    if mode == "pre" || mode == "post" {
        check(response == [b'D'], "owner loss synchronization")?;
        println!("external-client mode={mode} voluntarily exiting pid={}", std::process::id());
        return Ok(0);
    }
    check(response == [if mode == "normal" { 127 } else { 125 }], "unexpected external response")?;
    Ok(0)
}
pub(super) fn client(path: &Path) -> Result<i32> {
    check(unsafe { geteuid() == 501 && getegid() == 1000 }, "unexpected external client IDs")?;
    call(unsafe { prctl(38, 1, 0, 0, 0) })?;
    for mode in DENIALS.into_iter().chain(["normal", "pre", "post"]) {
        let pid = fork_exact()?;
        if pid == 0 { end(client_case(path, mode)); }
        check(Held::new(pid)?.reap("client-reaped-external-sender")? == 0, "external client case failed")?;
    }
    Ok(0)
}
