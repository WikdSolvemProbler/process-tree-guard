# Rejected exploratory Windows laptop capture 012

This archive preserves the complete saved capture and frozen source of attempt 012, its input manifests and harness source, preregistered index, native qualification and source-freeze records, and independent forensic and cleanup records. All original capture files, including provisional run metadata, remain byte-for-byte unchanged. No benchmark slot was repeated and no score was recomputed.

The exact source manifest is b73713eb726622e167d14b2381c3756a118e37ed7fc0d01fe28b169c1426fd12. The terminal record rejects the attempt with "Rejected: live telemetry capture refused", telemetry_pass=false and package_complete=false. The final during window has the single error power_state. Its native AC-line value changed from 1 in the preceding sample to 0 in the final sample. The final available-memory sample is 6699577344 bytes, and its native_errors list is empty.

The final two residual CPU estimates are preserved unchanged as 18.30203924056933 and 19.60665191580948 percent. These values and their raw numerator and capacity fields remain potential gate data. This package performs no new trend-gate evaluation, retrospective acceptance or rescore. The recorded abort reason remains power_state.

## Persisted progress and raw outcomes

The saved metadata and observation file agree on 76 of 1940 planned slots. The complete saved prefix contains all 36 controls and 40 warmups. It contains zero measured slots. Every persisted slot matches its position in the saved seeded order.

There are 1864 planned slots without persisted observations. The next planned slot, numbered 77, is a Nuewframe kill warmup in NO_WINDOW context with rep 7. The last inventory contains its timeout PID 19564 and fixture children 54016 and 29392 under campaign worker PID 51620. That slot has no observation and is retained as interrupted. Later slots have no persisted completion evidence.

The original run.json remains provisional=true and campaign_status=incomplete, with pricing_probe_observations=0 and null standing-loss and freeze-gate counts. No finalized report, pricing result or claim ledger exists in the capture. This rejected partial attempt establishes no latency, parity, ranking, campaign completion or strict quiet-host conclusion.

There are 72 ok outcomes and four descendant-survived outcomes. All four non-ok records are Nuewframe warmups. No guard record has a non-ok outcome within the persisted prefix. Full per-slot evidence remains in the original observations.jsonl and the separately derived non-ok-slots.json.

| One-based slot | Path | Context | Rep |
| --- | --- | --- | --- |
| 41 | scale | DETACHED | 2 |
| 59 | kill | NO_WINDOW | 1 |
| 65 | kill | DETACHED | 8 |
| 70 | scale | NO_WINDOW | 2 |

The original per-slot Job receipts and the abort receipt are retained. The latter records active_before=5, terminated=true and active_after=0.

## Independent cleanup

A separate finite Windows Job invocation performed read-only native checks against all 113 exact identities recorded as pinned_enclosing_guard or campaign_member. It used OpenProcess with query/synchronize rights, GetProcessTimes when available and a zero-time native wait. All 113 returned ERROR_INVALID_PARAMETER (87) from OpenProcess, indicating the numeric PID was absent at inspection.

The exact guard is PID 37420 with creation FILETIME 134384962546759747. The campaign worker is PID 51620 with creation FILETIME 134384963152059800. The binding records observer PID 37024 without a creation FILETIME, so the observer is excluded from the exact-identity conclusion. All identity values were parsed as Python integers. No process was signalled, terminated or matched by a general name in this inspection.

The outer-session exit 1 is recorded as parent-reported context, with session ID 71118. The recorded Job zero and independent exact-identity results provide the stated cleanup evidence. The forensic check verified source and capture hashes, then re-read every original file to confirm that inspection had changed none. Packaging repeats this immutability check.

## Frozen inputs and scope

The binding retains exact launch arguments, source hashes, executable fingerprints, configuration, seed, environment hashes, finite deadlines and sampled image policy. The full capture used the frozen observed-accounting protocol with a 6900-second outer deadline and a 6600-second during deadline. The independent forensic process used a separate 45-second whole-tree deadline.

The frozen protocol archive is windows-laptop-exploratory-protocol-012.zip with SHA-256 45520e84d07098dc814a449772b2583c76051c95b271aaa2ff2627412940e582. Its original INDEX.json and PREREGISTRATION.json are included. Executables remain in that existing protocol archive and are referenced by content hash. This smaller preservation package includes all pinned non-executable campaign inputs, source.tar, checker and input manifest.

The top-level INDEX.json lists paths, byte lengths and SHA-256 hashes for every other member. Original files retain repository-relative paths. Derived forensic files live separately under target/codex-security/issue7-attempt-012-forensics-001. Strict protocol 007 and issue #7 remain open.
