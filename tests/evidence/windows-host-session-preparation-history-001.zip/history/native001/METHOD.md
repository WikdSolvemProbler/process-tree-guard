# Owned event acquisition and retention controls — prepared only

This package is unexecuted. No AST parser, process, native call, test, competitor, workload, observer, thread, session or setting change was launched while authoring it. Exact source and plan require root and two independent reviews before one attempt. Host source005 in implementation-002 is read-only; its actual PURE24 receipt is a prerequisite, not native qualification.

The fixed attempt uses the qualified copied8fa guard for45s around Python3.12 -I -B and control.py. The checked inner endpoint is35s from the early Python entry clock through source/tool checks, native setup/calls, exact owned recovery and final fixture/log hashes. Interpreter startup and receipt serialization are still inside45s outer custody. It is a checked component deadline, not hard real-time proof of arbitrary blocked Win32 calls. Each of13 cases is attempted once in fixed order; any unexpected refusal, missing capability, late endpoint, API error, handle imbalance or remaining owner fails the attempt and stops later cases. There is no retry, privilege fallback or automatic follow-on session.

All functions are loaded from exact captured hash-bound buffers: actual Host005 common.py, worker.py, session.py, owned_events.py and native_image8adc. The new control calls actual NativeEvents.collect/opened/info, worker.retain_event_bundle, session.verify_retained_outputs and the actual pure classifiers. No worker.main/session.main/Observer/input_bindings/frozen runner or competitor is invoked. The constructed slot/Job/presentation fields used solely as inputs to disposition are labeled pure_classifier_only; they are not native Job custody or process-launch evidence. This package qualifies only the declared event/retention component if every actual result passes.

The capture directory is fixed fresh attempt-001; it is created exclusively. Each case owns separate ordinary directories/files under fixtures. Normal fixture and retained bytes remain present, including malformed and overflowing originals. The no-follow inventory skips/quarantines surviving reparse entries. No recursive deletion or move is performed. The only removed object is the one exact mklink-created junction leaf, after its native metadata/refusal and pre-removal receipt are flushed; its own target and all normal files are preserved. An unexpected identity/target leaves the leaf untouched.

## Fixed13 controls

1. stable_one: one valid owned two-event file; actual bounded ReadFile including EOF, full128-bit file ID/volume/basic/standard evidence, equal before/after metadata and every production handle closed; actual retained bundle/verifier produces the declared good content verdict.
2. missing_empty: actual empty owned event namespace; complete zero-file bundle is reliably missing/adverse, rather than failed acquisition.
3. ambiguous_two: two actual owned slot directories each with one valid log; both artifacts retained and verified before deriving ambiguous/adverse.
4. malformed_json: actual malformed bytes retained and classified adverse only after complete verified acquisition.
5. duplicate_json: actual duplicate JSON key in otherwise valid events; complete bytes retained, strict parser refuses contract.
6. overlong_json: otherwise valid run_started/runner_exit events, with a padding value making one line exceed64KiB while total stays under1MiB; complete bytes retained and line-bound contract fails.
7. overflow: actual1MiB+1 file; production bounded acquisition refuses size/overflow, original remains. It is not scored as product adversity.
8. wrong_type: events.jsonl is an actual directory; production acquisition refuses without a ReadFile. An open/type refusal is preserved, not substituted by synthetic metadata.
9. extra_entry: actual unexpected owned entry beside events.jsonl; production namespace contract refuses. Entry order may allow reading the legitimate log first; the whole acquisition still refuses and no complete verdict is invented.
10. mutation_after_read: the wrapper first calls the REAL ReadFile and retains result/count, then appends one actual byte to that exact own file. A native same-held-handle metadata readback is recorded before production resumes. Production refuses the changed initial-size/read relation. This is a controlled same-process interleaving, not a claim about every external writer.
11. held_directory_rename: while actual NativeEvents.opened holds one own directory without DELETE sharing, a real Path.rename attempt must fail with sharing violation32. No rollback/move is attempted if it unexpectedly succeeds; the failed fixture remains preserved.
12. protected_close: only the exact own events file handle returned by actual CreateFileW gets SetHandleInformation PROTECT_FROM_CLOSE=2 and readback. Actual production CloseHandle must fail with error6, preserve cleanup_error and the same quarantine handle. After recording all production evidence, the control clears only that exact owned flag and closes the same held handle. No fabricated close return is injected. Recovery errors retain explicit owners and fail qualification.
13. junction: one nested helper uses current guard --timeout5 -- native-backslash C:\Windows\System32\cmd.exe /d /c mklink /J OWNEDlink OWNEDtarget. Both paths are fixed inside the fresh fixture root and the leaf must be absent. Caller waits7s, retains actual helper stdout/stderr and exit; no unsupported-capability fallback or retry. Actual reader must observe reparse metadata and refuse without ReadFile. Only after flushed metadata/refusal receipt and identity/target recheck may os.rmdir remove that junction leaf. If helper is unexpectedly live after bounded exact-handle cancellation/wait, its Popen owner is retained and the45s outer guard remains final custody.

## Native evidence and boundaries

A fresh traced API delegates every production Win32 operation to the actual bound function; results and GetLastError are captured immediately before logging and restored for production error handling. ReadFile request/counts are recorded. Set/GetHandleInformation, GetProcessHandleCount and loaded kernel32 path/bytes are separately bound and retained. The reader keeps its actual production full128-bit IDs and Python integer fields; JSON serialization is lossless. Explicit instrumentation covers the adapter/control Win32 calls, not every internal interpreter/filesystem/loader syscall.

All bindings are initialized before the handle baseline. Every case preserves pre-recovery errors, metadata, production quarantine and exact CreateFileW owners before bounded same-handle recovery. Case and final handle counts must return to baseline while the same journal handle remains open. Counts complement exact ownership, never replace it. The final count follows no-follow inventory traversal and pin checks; journal closure/hash precede the checked observation. Failed/partial raw evidence must remain as-is.

The helper process count is one directly observed Popen guard attempt, plus one nested cmd required by the exact guarded argv and successful result. It is not independently enumerated process-tree evidence; no process discovery is performed. No other test process is launched. The helper has its own5s guard, its caller and all cases remain inside45s outer Job.

Sources: Microsoft SetHandleInformation documents flag2 preventing CloseHandle; mklink documents /J directory junctions; CreateFileW documents DELETE sharing and OPEN_REPARSE_POINT; GetProcessHandleCount documents own-process handle count. These API facts do not substitute for the unexecuted native controls.

- https://learn.microsoft.com/en-us/windows/win32/api/handleapi/nf-handleapi-sethandleinformation
- https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/mklink
- https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew
- https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getprocesshandlecount

No50s whole-arm custodian, parent/worker death, dispatcher,66-arm session, benchmark slots, primary admission, speed/win/tie/equivalence, full academic battery or production guard code is qualified or changed by this package.
