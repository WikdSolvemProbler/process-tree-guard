@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Auxiliary/Build/vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
where cl
cl /Bv
cl /nologo /std:c11 /W4 /WX file_info_abi.c /Fe:file_info_abi.exe /Fo:file_info_abi.obj
exit /b %errorlevel%
