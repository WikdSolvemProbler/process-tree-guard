"""Fixed read-only image controls plus replacement of one owned temporary file."""
import ctypes
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
FIXED = HERE.with_name("issue7-quiet-launch-013")
EXPECTED = "6b1efb97b74cc24fe29d8a764d37ddd35ab251ba9685bf90d990759e92b1ab4b"
MANIFEST = "313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae"


def loaded(name, path, expected):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise RuntimeError(f"source differs before execution: {name}")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def main():
    manifest_raw = (FIXED / "manifest.json").read_bytes()
    if hashlib.sha256(manifest_raw).hexdigest() != MANIFEST:
        raise ValueError("013 manifest differs")
    manifest = json.loads(manifest_raw)
    for name, digest in manifest["file_sha256"].items():
        if hashlib.sha256((FIXED / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"013 source differs: {name}")
    loaded("image_policy", FIXED / "image_policy.py", manifest["file_sha256"]["image_policy.py"])
    image = loaded("native_image", HERE / "native_image.py", EXPECTED)
    old = loaded("old_inventory_control", FIXED / "inventory_gate.py",
                 manifest["file_sha256"]["inventory_gate.py"])
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    count_handles = kernel.GetProcessHandleCount
    count_handles.argtypes = [w.HANDLE, ctypes.POINTER(w.DWORD)]
    count_handles.restype = w.BOOL
    current_process = kernel.GetCurrentProcess
    current_process.argtypes = []
    current_process.restype = w.HANDLE

    def handles():
        value = w.DWORD()
        if not count_handles(current_process(), ctypes.byref(value)):
            raise ctypes.WinError(ctypes.get_last_error())
        return value.value

    deadline = time.perf_counter_ns() + 20_000_000_000
    code = 0
    fixture = HERE / "native-fixture-001"
    if not fixture.resolve().is_relative_to(HERE.resolve()):
        raise ValueError("fixture escaped diagnostic directory")
    with (HERE / "native-control-001.jsonl").open("x", encoding="utf-8") as output:
        def emit(kind, **values):
            print(json.dumps({"kind": kind, **values}), file=output, flush=True)
        baseline = handles()
        emit("context", helper_sha256=EXPECTED, manifest_sha256=MANIFEST,
             scope="fixed per-row component controls, no workload process", benchmark_slots=0)
        try:
            images = {"python": manifest["tools"]["python"],
                      "guard": manifest["fingerprints"]["guard"],
                      "sysprims": manifest["fingerprints"]["sysprims"],
                      "outer_guard": manifest["tools"]["outer_guard"]}
            for name, expected in images.items():
                if time.perf_counter_ns() >= deadline:
                    raise TimeoutError("20-second native component deadline")
                path = Path(expected["path"])
                begin = time.perf_counter_ns()
                digest, evidence = image.inspect_image(path)
                end = time.perf_counter_ns()
                old_digest = old.image_digest(path)
                if digest != expected["sha256"] or old_digest != digest:
                    raise ValueError(f"pinned/native/013 digest disagreement: {name}")
                emit("image", name=name, native_elapsed_ns=end - begin,
                     evidence=evidence, old_digest=old_digest, pinned_digest=expected["sha256"])
            fixture.mkdir()
            target, replacement = fixture / "target", fixture / "replacement"
            original = image.held_digest
            for mutation in ("in_place", "replacement", "growth", "truncation"):
                if time.perf_counter_ns() >= deadline:
                    raise TimeoutError("20-second native component deadline")
                target.write_bytes(b"same")
                replacement.write_bytes(b"next")

                def mutate_at_read(handle, size):
                    if mutation == "truncation":
                        target.write_bytes(b"")
                    elif mutation == "growth":
                        with target.open("ab") as appended:
                            appended.write(b"+")
                    digest = original(handle, size)
                    if mutation == "replacement":
                        os.replace(replacement, target)
                    elif mutation == "in_place":
                        target.write_bytes(b"edit")
                    return digest
                image.held_digest = mutate_at_read
                refused = None
                try:
                    image.inspect_image(target)
                except ValueError as error:
                    refused = str(error)
                finally:
                    image.held_digest = original
                if refused is None:
                    raise ValueError(f"native mutation was not refused: {mutation}")
                emit("owned_mutation", mutation=mutation, refused=True, reason=refused,
                     partial_file_evidence_available=False,
                     scope="only this control's temporary files were changed")
                if handles() != baseline:
                    raise ValueError("native image controls changed process handle count")
        except BaseException as error:
            code = 1
            emit("error", error=f"{type(error).__name__}: {error}")
        finally:
            if fixture.exists():
                for name in ("target", "replacement"):
                    path = fixture / name
                    if path.exists():
                        path.unlink()
                fixture.rmdir()
            if time.perf_counter_ns() >= deadline:
                code = 1
                emit("error", error="20-second deadline exceeded before terminal")
            if hashlib.sha256((HERE / "native_image.py").read_bytes()).hexdigest() != EXPECTED:
                code = 1
                emit("error", error="helper source changed")
            emit("terminal", code=code, handle_count=handles(), baseline=baseline,
                 fixture_absent=not fixture.exists(), benchmark_slots=0)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
