import ctypes
import hashlib
from pathlib import Path
import unittest
from unittest.mock import patch

EXPECTED = "6b1efb97b74cc24fe29d8a764d37ddd35ab251ba9685bf90d990759e92b1ab4b"
if hashlib.sha256(Path(__file__).with_name("native_image.py").read_bytes()).hexdigest() != EXPECTED:
    raise RuntimeError("native image source differs before importing controls")
import native_image as image


def signature():
    return {"volume": 9, "file_id_128": "11" * 16, "size": 4,
            "allocation": 4096, "links": 1, "creation_ticks": 100,
            "write_ticks": 200, "change_ticks": 300, "attributes": 32,
            "directory": False, "delete_pending": False}


class ImageTests(unittest.TestCase):
    def inspect(self, signatures):
        with (
            patch.object(image, "create_file", side_effect=[101, 102, 103]) as opened,
            patch.object(image, "close_handle", return_value=1) as closed,
            patch.object(image, "metadata", side_effect=signatures),
            patch.object(image, "held_digest", return_value="a" * 64) as digest,
        ):
            result = image.inspect_image(Path("C:/fixture/python.exe"))
        return result, opened, closed, digest

    def test_per_row_named_and_held_checks_and_nonblocking_shares(self):
        result, opened, closed, digest = self.inspect([signature() for _ in range(4)])
        self.assertEqual(result[0], "a" * 64)
        self.assertEqual([call.args[1] for call in opened.call_args_list],
                         [image.FILE_READ_ATTRIBUTES,
                          image.GENERIC_READ | image.FILE_READ_ATTRIBUTES,
                          image.FILE_READ_ATTRIBUTES])
        for call in opened.call_args_list:
            self.assertEqual(call.args[2:5], (7, None, image.OPEN_EXISTING))
        self.assertEqual(sorted(call.args[0] for call in closed.call_args_list), [101, 102, 103])
        digest.assert_called_once_with(102, 4)
        self.assertEqual(result[1]["held_before"], result[1]["named_after"])

    def test_full_high_128_bits_and_each_metadata_drift_refuse(self):
        for field, changed in (
            ("file_id_128", "11" * 8 + "22" * 8), ("volume", 10),
            ("size", 5), ("creation_ticks", 101), ("write_ticks", 201),
            ("change_ticks", 301), ("attributes", 0), ("links", 2),
        ):
            with self.subTest(field=field):
                states = [signature() for _ in range(4)]
                states[2][field] = changed
                with (
                    patch.object(image, "create_file", side_effect=[101, 102, 103]),
                    patch.object(image, "close_handle", return_value=1) as close,
                    patch.object(image, "metadata", side_effect=states),
                    patch.object(image, "held_digest", return_value="a" * 64),
                ):
                    with self.assertRaisesRegex(ValueError, "changed"):
                        image.inspect_image(Path("C:/fixture/python.exe"))
                self.assertEqual(close.call_count, 3)

    def test_native_query_error_closes_owned_handle(self):
        with (
            patch.object(image, "create_file", return_value=101),
            patch.object(image, "close_handle", return_value=1) as close,
            patch.object(image, "file_info", return_value=0),
        ):
            with self.assertRaises(OSError):
                image.inspect_image(Path("C:/fixture/python.exe"))
        close.assert_called_once_with(101)

    def test_late_metadata_read_and_open_failures_close_all_owned_handles(self):
        for failing_index, expected in ((1, [101, 102]), (2, [101, 102]), (3, [101, 102, 103])):
            with self.subTest(failing_index=failing_index):
                states = [signature() for _ in range(4)]
                states[failing_index] = OSError("injected query failure")
                with (
                    patch.object(image, "create_file", side_effect=[101, 102, 103]),
                    patch.object(image, "close_handle", return_value=1) as close,
                    patch.object(image, "metadata", side_effect=states),
                    patch.object(image, "held_digest", return_value="a" * 64),
                ):
                    with self.assertRaises(OSError):
                        image.inspect_image(Path("C:/fixture/python.exe"))
                self.assertEqual(sorted(call.args[0] for call in close.call_args_list), expected)
        with (
            patch.object(image, "create_file", side_effect=[101, 102]),
            patch.object(image, "close_handle", return_value=1) as close,
            patch.object(image, "metadata", side_effect=[signature(), signature()]),
            patch.object(image, "held_digest", side_effect=OSError("read failed")),
        ):
            with self.assertRaises(OSError):
                image.inspect_image(Path("C:/fixture/python.exe"))
        self.assertEqual(sorted(call.args[0] for call in close.call_args_list), [101, 102])
        with (
            patch.object(image, "create_file", side_effect=[101, 102, image.INVALID_HANDLE_VALUE]),
            patch.object(image, "close_handle", return_value=1) as close,
            patch.object(image, "metadata", side_effect=[signature()] * 3),
            patch.object(image, "held_digest", return_value="a" * 64),
        ):
            with self.assertRaises(OSError):
                image.inspect_image(Path("C:/fixture/python.exe"))
        self.assertEqual(sorted(call.args[0] for call in close.call_args_list), [101, 102])

    def test_bounded_content_read_and_excess_refusal(self):
        requested = []

        def read(handle, buffer, amount, count, overlapped):
            requested.append(amount)
            if len(requested) == 1:
                ctypes.memmove(buffer, b"data", 4)
                count._obj.value = 4
            else:
                count._obj.value = 1
            return 1
        with patch.object(image, "read_file", read):
            with self.assertRaisesRegex(ValueError, "exceeds"):
                image.held_digest(102, 4)
        self.assertEqual(requested, [4, 1])

    def test_short_content_refuses(self):
        def read(handle, buffer, amount, count, overlapped):
            count._obj.value = 0
            return 1
        with patch.object(image, "read_file", read):
            with self.assertRaisesRegex(ValueError, "ended"):
                image.held_digest(102, 4)


if __name__ == "__main__":
    unittest.main()
