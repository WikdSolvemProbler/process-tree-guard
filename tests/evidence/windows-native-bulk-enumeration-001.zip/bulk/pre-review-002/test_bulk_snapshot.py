"""Pure parser/ABI controls; no Windows API/DLL load or process launch."""
import ctypes
import struct
import unittest
import bulk_snapshot as b

def rows_and_evidence():
    rows = (b.Row * b.MAX_ROWS)()
    e = b.Evidence()
    e.version, e.bytes, e.count, e.capacity, e.name_units = 1, 120, 2, b.MAX_ROWS, 260
    e.upper_ticks, e.frequency = 134385106765169651, 10_000_000
    for index, key in enumerate(("begin_qpc", "snapshot_upper_begin_qpc", "snapshot_upper_end_qpc",
        "enumerate_begin_qpc", "enumerate_end_qpc", "close_begin_qpc", "close_end_qpc", "end_qpc")):
        setattr(e, key, 1000 + index)
    for index, text in enumerate(("Python.EXE", "A\U0001f600\ud800.EXE")):
        raw = text.encode("utf-16le", "surrogatepass")
        rows[index].pid, rows[index].parent_pid, rows[index].name_units = 20+index, 10, len(raw)//2
        for j in range(len(raw)//2):
            rows[index].name[j] = int.from_bytes(raw[j*2:j*2+2], "little")
    return rows, e

def pe():
    raw = bytearray(0x600)
    raw[:2] = b"MZ"
    struct.pack_into("<I", raw, 60, 0x80)
    raw[0x80:0x84] = b"PE\0\0"
    struct.pack_into("<HH", raw, 0x84, 0x8664, 1)
    struct.pack_into("<H", raw, 0x94, 240)
    optional = 0x98
    struct.pack_into("<H", raw, optional, 0x20b)
    struct.pack_into("<I", raw, optional+108, 16)
    struct.pack_into("<II", raw, optional+120, 0x1000, 40)
    section = optional+240
    struct.pack_into("<IIII", raw, section+8, 0x300, 0x1000, 0x300, 0x200)
    struct.pack_into("<IIIII", raw, 0x200, 0, 0, 0, 0x1080, 0)
    raw[0x280:0x28d] = b"kernel32.dll\0"
    return raw

class DecodeTests(unittest.TestCase):
    def test_complete_lossless_names_and_all_rows(self):
        rows,e=rows_and_evidence()
        output,raw=b.decode(rows,e,0)
        self.assertEqual(output,[{"pid":20,"parent_pid":10,"name":"python.exe"},
                                 {"pid":21,"parent_pid":10,"name":"a\U0001f600\ud800.exe"}])
        self.assertEqual(raw["upper_ticks"],134385106765169651)

    def test_errors_cannot_admit_even_with_rows(self):
        for field in ("status","primary_error","close_error","clock_error"):
            with self.subTest(field=field):
                rows,e=rows_and_evidence()
                setattr(e,field,1)
                with self.assertRaises(ValueError): b.decode(rows,e,int(e.status))

    def test_return_status_mismatch(self):
        rows,e=rows_and_evidence()
        with self.assertRaises(ValueError):b.decode(rows,e,2)

    def test_counts_and_abi_fail_closed(self):
        for field,value in (("count",0),("count",4097),("capacity",4095),
                            ("version",2),("bytes",119),("name_units",259),
                            ("reserved",1),("upper_ticks",0),("frequency",0)):
            with self.subTest(field=field,value=value):
                rows,e=rows_and_evidence()
                setattr(e,field,value)
                with self.assertRaises(ValueError):b.decode(rows,e,0)

    def test_duplicate_and_name_bounds(self):
        for change in ("duplicate","zero_length","oversize","embedded_nul","nonzero_tail"):
            with self.subTest(change=change):
                rows,e=rows_and_evidence()
                if change=="duplicate":rows[1].pid=rows[0].pid
                elif change=="zero_length":rows[0].name_units=0
                elif change=="oversize":rows[0].name_units=260
                elif change=="embedded_nul":rows[0].name[1]=0
                else:rows[0].name[259]=1
                with self.assertRaises(ValueError):b.decode(rows,e,0)

    def test_reversed_and_zero_qpc(self):
        for value in (0,998):
            rows,e=rows_and_evidence()
            e.end_qpc=value
            with self.assertRaises(ValueError):b.decode(rows,e,0)

class PeTests(unittest.TestCase):
    def test_exact_kernel_import(self):
        self.assertEqual(b.pe_imports(bytes(pe())),["kernel32.dll"])

    def test_invalid_layout_and_delay_refused(self):
        for change in ("short","machine","delay","unmapped","no_terminator","directory_name","section_cross"):
            with self.subTest(change=change):
                raw=pe()
                if change=="short":raw=raw[:100]
                elif change=="machine":struct.pack_into("<H",raw,0x84,0x14c)
                elif change=="delay":struct.pack_into("<II",raw,0x98+112+13*8,0x1000,40)
                elif change=="unmapped":struct.pack_into("<I",raw,0x98+120,0x5000)
                elif change=="no_terminator":struct.pack_into("<IIIII",raw,0x214,1,0,0,0x1080,0)
                elif change=="directory_name":raw[0x280:0x28d]=b"../evil.dll\0\0"
                else:
                    struct.pack_into("<I",raw,0x200+12,0x12fc)
                    raw[0x4fc:0x509]=b"kernel32.dll\0"
                with self.assertRaises((ValueError,UnicodeError)):b.pe_imports(bytes(raw))

class OwnershipTests(unittest.TestCase):
    def mock_owner(self):
        owner=b.NativeBulk.__new__(b.NativeBulk)
        owner.closed=False
        owner.module=123
        owner.evidence={}
        owner.check_code_pins=lambda:None
        return owner

    def test_close_still_unloads_after_pin_failure(self):
        owner=self.mock_owner()
        def mismatch():raise ValueError("changed pin")
        calls=[]
        owner.check_code_pins=mismatch
        owner.unload=lambda h:calls.append(h) or True
        with self.assertRaises(b.BulkSnapshotError):owner.close()
        self.assertEqual(calls,[123])
        self.assertTrue(owner.closed)
        self.assertIsNone(owner.module)
        with self.assertRaises(b.BulkSnapshotError):owner.close()
        self.assertEqual(calls,[123])

    def test_snapshot_closed_owner_refuses_before_native(self):
        owner=self.mock_owner()
        owner.closed=True
        owner.call=lambda *args:self.fail("native call after closed")
        with self.assertRaises(b.BulkSnapshotError):owner.snapshot()

if __name__=="__main__":
    unittest.main(verbosity=2)
