"""One read-only native bulk snapshot control; requires a future reviewed DLL seal."""
import ctypes
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types
HERE=Path(__file__).resolve().parent
GROUP=HERE.with_name("issue7-grouped-image-census-001")
NATIVE_SHA="8bef895fbfefe86f39fd8bf414d46ca4037dda6e71fb4a09e839910c33b4a166"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main(seal_sha):
    seal_path=HERE/"native-seal.json"
    if digest(seal_path)!=seal_sha:
        raise ValueError("unreviewed native seal")
    seal=json.loads(seal_path.read_bytes())
    if (seal["schema"]!="bulk-snapshot-native-seal-v1" or seal["reviewed"] is not True
            or seal["inner_seconds"]!=15 or seal["outer_seconds"]!=30):
        raise ValueError("unapproved native control constants")
    def bindings():
        for name,pin in seal["source_sha256"].items():
            if digest(HERE/name)!=pin:raise ValueError("source differs: "+name)
        for path,pin in seal["tool_sha256"].items():
            if digest(Path(path))!=pin:raise ValueError("tool differs: "+path)
        if digest(GROUP/"native_processes.py")!=NATIVE_SHA:
            raise ValueError("original native process module differs")
        if not Path(sys.executable).samefile(seal["python_path"]):
            raise ValueError("interpreter differs")
    bindings()
    def load(name,path,pin):
        raw=path.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=pin:raise ValueError("module changed before exec")
        module=types.ModuleType(name);module.__file__=str(path);sys.modules[name]=module
        exec(compile(raw,str(path),"exec"),module.__dict__)
        return module
    bulk=load("bulk_snapshot",HERE/"bulk_snapshot.py",seal["source_sha256"]["bulk_snapshot.py"])
    native=load("native_processes",GROUP/"native_processes.py",NATIVE_SHA)
    kernel=ctypes.WinDLL("kernel32",use_last_error=True)
    count=kernel.GetProcessHandleCount
    count.argtypes=[w.HANDLE,ctypes.POINTER(w.DWORD)];count.restype=w.BOOL
    current=kernel.GetCurrentProcess;current.argtypes=[];current.restype=w.HANDLE
    def handles():
        result=w.DWORD()
        if not count(current(),ctypes.byref(result)):raise ctypes.WinError(ctypes.get_last_error())
        return result.value
    deadline=time.perf_counter_ns()+15_000_000_000
    def check():
        if time.perf_counter_ns()>=deadline:raise TimeoutError("15-second component deadline")
    code=0;result=None;setup=None;cleanup_errors=[]
    with (HERE/"native-001.jsonl").open("x",encoding="utf-8") as output:
        def emit(kind,**values):
            print(json.dumps({"kind":kind,**values},allow_nan=False),file=output,flush=True)
        baseline=handles()
        emit("context",seal_sha256=seal_sha,benchmark_slots=0,inner_seconds=15,outer_seconds=30,
             scope="One native full Toolhelp component observation; no census classification/phase/performance claim",
             setup="Original enclosing_guard uses one separate Toolhelp snapshot before the measured native observation; no comparison/equivalence claimed",
             cutoff="snapshot call includes fresh allocation/native enumeration/raw UTF16 marshaling/all row validation; JSON emission separately timed, no50ms qualification")
        try:
            with native.enclosing_guard(seal["outer_guard_path"]) as guard:
                guard_before=native.identity(guard[1])
                with native.open_exact(os.getpid()) as self_handle:
                    observer_image,observer_created=native.identity(self_handle)
                    before_setup=time.perf_counter_ns()
                    module=bulk.NativeBulk(HERE/"ptg_bulk_snapshot_001.dll",seal["dll_sha256"],seal["dependency_sha256"])
                    try:
                        setup=module.evidence
                        emit("module_setup",elapsed_ns=time.perf_counter_ns()-before_setup,evidence=setup)
                        check()
                        rows,upper,evidence=module.snapshot()
                        by_pid={row["pid"]:row for row in rows}
                        if len(by_pid)!=len(rows):raise ValueError("duplicate native rows")
                        if os.getpid() not in by_pid or guard[0] not in by_pid:
                            raise ValueError("missing held observer/guard")
                        if (observer_created>upper or guard[2]>upper
                            or by_pid[os.getpid()]["name"]!=observer_image.name.casefold()
                            or by_pid[guard[0]]["name"]!="process-tree-guard.exe"):
                            raise ValueError("held identity differs from native snapshot")
                        observer_after=native.identity(self_handle)
                        guard_after=native.identity(guard[1])
                        if (observer_after!=(observer_image,observer_created)
                            or guard_after!=guard_before
                            or not native.is_alive(self_handle) or not native.is_alive(guard[1])):
                            raise ValueError("held identity lost")
                        result={"rows":rows,"upper_ticks":upper,"evidence":evidence,
                                "observer_pid":os.getpid(),"observer_created_ticks":observer_created,
                                "observer_image":str(observer_image),"guard_image":str(guard_before[0]),
                                "guard_pid":guard[0],"guard_created_ticks":guard[2],
                                "held_observer_alive":True,"held_guard_alive":True}
                        emit_begin=time.perf_counter_ns()
                        emit("snapshot",**result)
                        emit("output_timing",begin_ns=emit_begin,end_ns=time.perf_counter_ns())
                        check()
                    finally:
                        module.close()
                        emit("module_cleanup",evidence=module.evidence)
        except BaseException as error:
            code=1
            emit("error",type=type(error).__name__,error=str(error),evidence=getattr(error,"evidence",None))
        finally:
            final_handles=None;observed=None
            try:
                bindings()
                final_handles=handles()
                observed=time.perf_counter_ns()
                if observed>=deadline:raise TimeoutError("deadline after final native handle query")
            except BaseException as error:
                cleanup_errors.append(str(error));code=1
            if final_handles!=baseline or result is None:code=1
            emit("terminal",code=code,qualified=code==0,baseline_handles=baseline,final_handles=final_handles,
                 observed_ns=observed,deadline_ns=deadline,cleanup_errors=cleanup_errors,
                 native_observation_count=1 if result is not None else 0,
                 census_qualified=False,phase_qualified=False,campaign_qualified=False,benchmark_slots=0)
    return code

if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument("--approved-native-seal-sha",required=True)
    raise SystemExit(main(p.parse_args().approved_native_seal_sha))
