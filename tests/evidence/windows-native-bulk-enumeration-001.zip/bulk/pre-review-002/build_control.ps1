param([Parameter(Mandatory)][string]$ApprovedPlanSha)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSCommandPath
Set-Location -LiteralPath $root
function Digest([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
if((Digest "$root/plan.json") -cne $ApprovedPlanSha){throw 'unapproved exact plan'}
$plan=Get-Content -LiteralPath "$root/plan.json" -Raw|ConvertFrom-Json -AsHashtable
function Verify-Bindings {
 foreach($item in $plan.source_sha256.GetEnumerator()){
  if((Digest "$root/$($item.Key)") -cne $item.Value){throw "source differs: $($item.Key)"}
 }
 $installed=Get-Content -LiteralPath "$root/installed-inputs.json" -Raw|ConvertFrom-Json -AsHashtable
 foreach($item in $installed.GetEnumerator()){
  if((Digest $item.Key) -cne $item.Value){throw "installed input differs: $($item.Key)"}
 }
 return $installed
}
$installed=Verify-Bindings
foreach($name in @('build-001.stdout.log','build-001.stderr.log','build-receipt-001.json')){
 if(Test-Path -LiteralPath "$root/$name"){throw "existing outcome refused: $name"}
}
$old=@(Get-ChildItem -LiteralPath $root -File|Where-Object{$_.Extension -in '.obj','.dll','.exe','.lib','.exp','.pdb','.ilk'})
if($old.Count){throw 'preexisting compiler output refused'}
$begin=[DateTime]::UtcNow.ToString('o')
$buildExit=$null
$failure=$null
$verification=@()
try {
 & 'C:/Windows/System32/cmd.exe' /d /c "$root/build_native.cmd" 1>"$root/build-001.stdout.log" 2>"$root/build-001.stderr.log"
 $buildExit=$LASTEXITCODE
 if($buildExit -ne 0){throw "compiler/dumpbin failed: $buildExit"}
 $trace=(Get-Content -LiteralPath "$root/build-001.stdout.log" -Raw)+(Get-Content -LiteralPath "$root/build-001.stderr.log" -Raw)
 $parserBytes=[IO.File]::ReadAllBytes("$root/header_trace.ps1")
 if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($parserBytes)).ToLowerInvariant() -cne 'bcdb9f324e5d81530d987c6e359a583ab74773d2f2c6a06d4f49c6f0e869743a'){throw 'header parser differs'}
 . ([scriptblock]::Create([Text.Encoding]::UTF8.GetString($parserBytes)))
 $headers=@{}
 foreach($item in $installed.GetEnumerator()){if($item.Key -match '\.h$'){$headers[$item.Key]=$item.Value}}
 $verification=@(Get-PinnedHeaderTrace -Trace $trace -HeaderPins $headers)
 if($verification.Count -ne $headers.Count){throw 'required SDK/compiler headers not verified'}
 Verify-Bindings|Out-Null
} catch {$failure=$_.Exception.Message}
$artifacts=[ordered]@{}
foreach($file in Get-ChildItem -LiteralPath $root -File){
 if($file.Name -ne 'build-receipt-001.json'){$artifacts[$file.Name]=Digest $file.FullName}
}
$receipt=[ordered]@{schema='bulk-snapshot-build-v1';began_utc=$begin;ended_utc=[DateTime]::UtcNow.ToString('o')
 compile_exit=$buildExit;failure=$failure;qualified=($buildExit -eq 0 -and $null -eq $failure)
 artifact_sha256=$artifacts;header_verification=$verification;installed_input_sha256=$installed
 outer_seconds=60;native_snapshot_calls=0;test_executions=0
 scope='Compile and SDK/import evidence only; DLL/exe not executed. DLL dependency seal and independent review required before any native load.'}
$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($receipt|ConvertTo-Json -Depth 15))
$file=[IO.File]::Open("$root/build-receipt-001.json",[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$file.Write($bytes,0,$bytes.Length)}finally{$file.Dispose()}
if(-not $receipt.qualified){exit 1}
exit 0
