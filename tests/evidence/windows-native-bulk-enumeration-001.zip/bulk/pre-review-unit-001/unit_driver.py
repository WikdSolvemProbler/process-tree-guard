"""One bounded pure-Python/scripted-C unit qualification. Never loads private DLL."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import types
import unittest

HERE=Path(__file__).resolve().parent
GUARD=Path("C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe")
PYTHON=Path("C:/Users/Peter/AppData/Local/Programs/Python/Python312/python.exe")
def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(value,message):
    if not value:raise ValueError(message)
def checked(path,expected):
    raw=path.read_bytes()
    require(sha(raw)==expected,"bound bytes differ: "+str(path))
    return raw
def main(approved):
    began=time.perf_counter_ns()
    deadline=began+35_000_000_000
    code=0
    facts={"python":None,"scripted_c":None}
    errors=[]
    plan=None
    def check_time():
        if time.perf_counter_ns()>=deadline:raise TimeoutError("35-second unit qualification deadline")
    def bindings():
        checked(HERE/"unit-plan.json",approved)
        for name,pin in plan["source_sha256"].items():checked(HERE/name,pin)
        for name,pin in plan["build_artifact_sha256"].items():checked(HERE/name,pin)
        checked(HERE/"build-receipt-001.json",plan["build_receipt_sha256"])
        for path,pin in plan["tool_sha256"].items():checked(Path(path),pin)
        require(Path(sys.executable).samefile(PYTHON),"interpreter differs")
    with (HERE/"unit-001.jsonl").open("x",encoding="utf-8") as output:
        def emit(kind,**values):
            print(json.dumps({"kind":kind,**values},allow_nan=False),file=output,flush=True)
        emit("context",unit_plan_sha256=approved,outer_seconds=45,inner_seconds=35,
             scripted_c_child_job_seconds=15,private_dll_loads=0,native_snapshot_calls=0,
             scope="11purePython tests plus16scriptedCAPI cases; no native Toolhelp or private DLL execution")
        try:
            raw=checked(HERE/"unit-plan.json",approved)
            plan=json.loads(raw)
            require(plan["schema"]=="bulk-snapshot-unit-plan-v1" and plan["inner_seconds"]==35
                    and plan["outer_seconds"]==45 and plan["scripted_c_child_seconds"]==15,
                    "unreviewed unit constants")
            bindings()
            def load(name,filename):
                captured=checked(HERE/filename,plan["source_sha256"][filename])
                module=types.ModuleType(name);module.__file__=str(HERE/filename)
                sys.modules[name]=module
                exec(compile(captured,str(HERE/filename),"exec"),module.__dict__)
                return module
            load("bulk_snapshot","bulk_snapshot.py")
            tests=load("controlled_bulk_tests","test_bulk_snapshot.py")
            with (HERE/"python-unit-001.log").open("x",encoding="utf-8") as log:
                result=unittest.TextTestRunner(stream=log,verbosity=2).run(
                    unittest.defaultTestLoader.loadTestsFromModule(tests))
            python_ok=(result.wasSuccessful() and result.testsRun==11 and not result.skipped)
            facts["python"]={"qualified":python_ok,"tests":result.testsRun,
                             "failures":len(result.failures),"errors":len(result.errors),
                             "skipped":len(result.skipped)}
            if not python_ok:code=1
            emit("python",**facts["python"])
            check_time()
            with ((HERE/"scripted-c-001.stdout.log").open("xb") as out,
                  (HERE/"scripted-c-001.stderr.log").open("xb") as err):
                executed=subprocess.run([str(GUARD),"--timeout","15","--",
                    str(HERE/"test_bulk_snapshot.exe")],stdin=subprocess.DEVNULL,
                    stdout=out,stderr=err,timeout=20,check=False)
            captured=(HERE/"scripted-c-001.stdout.log").read_text(encoding="utf-8")
            lines=captured.splitlines()
            expected=["complete_raw_rows","snapshot_error","first_error","next_error","close_error",
                "final_qpc_failure_sticky","qpc_regression","duplicate_pid","unterminated_name",
                "empty_name","zero_upper","initial_qpc_failure","frequency_failure",
                "overflow_not_truncation","zero_capacity","oversize_capacity"]
            got=[line.split()[1] for line in lines if line.startswith("PASS ")]
            c_ok=(executed.returncode==0 and got==expected and len(lines)==17
                  and lines[-1]=="terminal failures=0 native_api_calls=0"
                  and (HERE/"scripted-c-001.stderr.log").read_bytes()==b"")
            facts["scripted_c"]={"qualified":c_ok,"exit":executed.returncode,"cases":got,
                "literal_native_api_calls_field_scope":"Only the replaced target API shims; no claim OS/process startup executes no native code"}
            if not c_ok:code=1
            emit("scripted_c",**facts["scripted_c"])
            check_time()
        except BaseException as error:
            code=1
            errors.append({"type":type(error).__name__,"message":str(error)})
            emit("error",**errors[-1])
        finally:
            if plan is not None:
                try:bindings()
                except BaseException as error:
                    code=1;errors.append({"type":type(error).__name__,"message":str(error)})
            observed=time.perf_counter_ns()
            if observed>=deadline:code=1;errors.append({"type":"TimeoutError","message":"terminal unit deadline"})
            if not all(value is not None and value["qualified"] for value in facts.values()):code=1
            artifacts={}
            for name in ("unit_driver.py","unit-plan.json","python-unit-001.log",
                         "scripted-c-001.stdout.log","scripted-c-001.stderr.log","unit-001.jsonl"):
                path=HERE/name
                if path.exists() and name!="unit-001.jsonl":artifacts[name]=sha(path.read_bytes())
            terminal={"kind":"terminal","code":code,"qualified":code==0,"facts":facts,"errors":errors,
                      "observed_ns":observed,"deadline_ns":deadline,"private_dll_loads":0,
                      "native_snapshot_calls":0,"census_qualified":False,"phase_qualified":False,
                      "campaign_qualified":False,"benchmark_slots":0}
            print(json.dumps(terminal,allow_nan=False),file=output,flush=True)
    artifacts["unit-001.jsonl"]=sha((HERE/"unit-001.jsonl").read_bytes())
    receipt={"schema":"bulk-snapshot-unit-receipt-v1","qualified":code==0,"code":code,"facts":facts,
             "errors":errors,"artifact_sha256":artifacts,"unit_plan_sha256":approved,
             "private_dll_loads":0,"native_snapshot_calls":0,"benchmark_slots":0}
    with (HERE/"unit-receipt-001.json").open("x",encoding="utf-8") as result:
        json.dump(receipt,result,indent=2,allow_nan=False);result.write("\n")
    return code

if __name__=="__main__":
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument("--approved-unit-plan-sha",required=True)
    raise SystemExit(main(parser.parse_args().approved_unit_plan_sha))
