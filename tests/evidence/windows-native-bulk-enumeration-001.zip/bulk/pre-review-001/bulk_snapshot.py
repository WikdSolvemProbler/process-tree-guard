"""Prospective bulk Toolhelp adapter. No native call or DLL load on import."""
import ctypes
from ctypes import wintypes as w
import hashlib
import ntpath
import os
from pathlib import Path
import struct
import time

MAX_ROWS = 4096
NAME_UNITS = 260
SYSTEM32_SEARCH = 0x800
class Row(ctypes.Structure):
    _fields_ = [("pid", ctypes.c_uint32), ("parent_pid", ctypes.c_uint32),
                ("name_units", ctypes.c_uint32), ("name", ctypes.c_uint16 * NAME_UNITS)]
class Evidence(ctypes.Structure):
    _fields_ = [(key, ctypes.c_uint32) for key in
                ("version", "bytes", "status", "primary_error", "close_error",
                 "clock_error", "count", "capacity", "name_units", "reserved")] + [
        ("upper_ticks", ctypes.c_uint64)] + [(key, ctypes.c_int64) for key in
        ("frequency", "begin_qpc", "snapshot_upper_begin_qpc", "snapshot_upper_end_qpc",
         "enumerate_begin_qpc", "enumerate_end_qpc", "close_begin_qpc", "close_end_qpc", "end_qpc")]

def require(value, message):
    if not value:
        raise ValueError(message)

def abi():
    require((ctypes.sizeof(Row), Row.name.offset, ctypes.sizeof(Evidence),
             Evidence.upper_ticks.offset, Evidence.frequency.offset) == (532, 12, 120, 40, 48),
            "unsupported native snapshot ABI")

def pe_imports(raw):
    """Bounded AMD64 PE32+ imports; no executable mapping, fallback or delay imports."""
    require(len(raw) >= 64 and raw[:2] == b"MZ", "not a bounded PE")
    def get(fmt, offset):
        size = struct.calcsize(fmt)
        require(type(offset) is int and 0 <= offset <= len(raw) - size, "PE field exceeds bytes")
        return struct.unpack_from(fmt, raw, offset)
    offset = get("<I", 60)[0]
    require(raw[offset:offset+4] == b"PE\0\0", "PE signature")
    machine, section_count = get("<HH", offset + 4)
    require(machine == 0x8664 and 1 <= section_count <= 96, "AMD64 bounded sections required")
    optional_size = get("<H", offset + 20)[0]
    optional = offset + 24
    require(optional_size >= 240 and get("<H", optional)[0] == 0x20b, "PE32+ optional header")
    require(get("<I", optional + 108)[0] >= 14, "missing PE data directories")
    sections_offset = optional + optional_size
    sections = []
    for index in range(section_count):
        base = sections_offset + index * 40
        virtual_size, address, raw_size, raw_offset = get("<IIII", base + 8)
        require(raw_offset <= len(raw) and raw_size <= len(raw) - raw_offset, "section raw bounds")
        sections.append((address, raw_size, raw_offset))
    def rva(address, size):
        require(0 < size <= len(raw), "RVA size")
        matches = [start + address - base for base, length, start in sections
                   if base <= address and address - base <= length - size]
        require(len(matches) == 1, "unmapped/ambiguous import RVA")
        return matches[0]
    delay_rva, delay_size = get("<II", optional + 112 + 13 * 8)
    require(delay_rva == delay_size == 0, "delay imports are not reviewed")
    import_rva, import_size = get("<II", optional + 112 + 8)
    require(20 <= import_size <= 20 * 129, "bounded import directory required")
    location = rva(import_rva, import_size)
    names = []
    terminated = False
    for index in range(min(import_size // 20, 129)):
        fields = get("<IIIII", location + index * 20)
        if not any(fields):
            terminated = True
            break
        require(len(names) < 128, "too many imports")
        name_start = rva(fields[3], 1)
        name_end = raw.find(b"\0", name_start, min(len(raw), name_start + 261))
        require(name_end > name_start, "unterminated import name")
        name = raw[name_start:name_end].decode("ascii", "strict").lower()
        require(ntpath.basename(name) == name and name.endswith(".dll")
                and "/" not in name and "\\" not in name and ":" not in name,
                "non-basename dependency")
        require(name not in names, "duplicate dependency")
        names.append(name)
    require(terminated and names, "unterminated/empty import directory")
    return sorted(names)

def decode(rows, evidence, returned):
    abi()
    raw = {name: getattr(evidence, name) for name, _ in Evidence._fields_}
    require(type(returned) is int and returned == raw["status"] == 0,
            "native snapshot refusal: " + repr(raw))
    require(raw["version"] == 1 and raw["bytes"] == 120 and raw["reserved"] == 0
            and raw["capacity"] == MAX_ROWS and raw["name_units"] == NAME_UNITS,
            "native evidence ABI/constants")
    require(raw["primary_error"] == raw["close_error"] == raw["clock_error"] == 0,
            "native errors cannot admit")
    require(1 <= raw["count"] <= MAX_ROWS and len(rows) == MAX_ROWS
            and raw["upper_ticks"] > 0 and raw["frequency"] > 0,
            "native count/upper/frequency")
    chain = [raw[key] for key in ("begin_qpc", "snapshot_upper_begin_qpc", "snapshot_upper_end_qpc",
             "enumerate_begin_qpc", "enumerate_end_qpc", "close_begin_qpc", "close_end_qpc", "end_qpc")]
    require(all(type(value) is int and value > 0 for value in chain)
            and chain == sorted(chain), "native QPC chain")
    output, seen = [], set()
    for index in range(raw["count"]):
        item = rows[index]
        require(1 <= item.name_units < NAME_UNITS, "name capacity")
        units = list(item.name)
        require(all(unit != 0 for unit in units[:item.name_units])
                and all(unit == 0 for unit in units[item.name_units:]), "UTF16 terminator/tail")
        # surrogatepass preserves the same Python WCHAR-string code units even
        # for an unusual unpaired surrogate; no replacement/drop normalization.
        name_raw = bytes().join(int(unit).to_bytes(2, "little") for unit in units[:item.name_units])
        name = name_raw.decode("utf-16le", "surrogatepass")
        require(name and item.pid not in seen, "empty name/duplicate PID")
        seen.add(item.pid)
        output.append({"pid": item.pid, "parent_pid": item.parent_pid, "name": name.casefold()})
    return output, raw

class BulkSnapshotError(ValueError):
    def __init__(self, message, evidence):
        super().__init__(message)
        self.evidence = evidence

def snapshot(dll_path, dll_sha256, dependency_sha256):
    """All binding, allocation, marshaling and validation are inside this call.

    dependency_sha256 is an exact basename->digest reviewed allowlist; missing or
    additional imports refuse. There is no cross-call cache or persistent DLL.
    """
    evidence = {"begin_ns": time.perf_counter_ns(), "scope": "same Toolhelp full snapshot; native bulk marshal only"}
    module = None
    try:
        abi()
        path = Path(dll_path).resolve(strict=True)
        require(path.is_absolute() and path.suffix.lower() == ".dll", "absolute DLL required")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == dll_sha256, "DLL pin differs")
        dependencies = pe_imports(raw)
        require(dependencies == sorted(dependency_sha256), "unreviewed dependency member set")
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        def bind(name, args, result):
            call = getattr(kernel, name)
            call.argtypes, call.restype = args, result
            return call
        system_directory = bind("GetSystemDirectoryW", [w.LPWSTR, w.UINT], w.UINT)
        load = bind("LoadLibraryExW", [w.LPCWSTR, w.HANDLE, w.DWORD], w.HMODULE)
        address = bind("GetProcAddress", [w.HMODULE, ctypes.c_char_p], ctypes.c_void_p)
        unload = bind("FreeLibrary", [w.HMODULE], w.BOOL)
        buffer = ctypes.create_unicode_buffer(32768)
        length = system_directory(buffer, len(buffer))
        require(0 < length < len(buffer), "System32 directory query failed")
        system = Path(buffer[:length])
        checked_dependencies = {}
        for name in dependencies:
            value = hashlib.sha256((system / name).read_bytes()).hexdigest()
            require(value == dependency_sha256[name], "System32 dependency pin differs")
            checked_dependencies[name] = value
        evidence["dependency_sha256"] = checked_dependencies
        module = load(str(path), None, SYSTEM32_SEARCH)
        if not module:
            raise ctypes.WinError(ctypes.get_last_error())
        pointer = address(module, b"ptg_bulk_snapshot")
        if not pointer:
            raise ctypes.WinError(ctypes.get_last_error())
        call = ctypes.CFUNCTYPE(ctypes.c_uint32, ctypes.POINTER(Row), ctypes.c_uint32,
                                ctypes.POINTER(Evidence))(pointer)
        # Fixed cap: no grow-and-retry, every allocation remains in caller cutoff.
        rows = (Row * MAX_ROWS)()
        native = Evidence()
        evidence["native_begin_ns"] = time.perf_counter_ns()
        returned = int(call(rows, MAX_ROWS, ctypes.byref(native)))
        evidence["native_end_ns"] = time.perf_counter_ns()
        evidence["native"] = {name: getattr(native, name) for name, _ in Evidence._fields_}
        output, details = decode(rows, native, returned)
        evidence["raw_utf16_rows"] = [{"pid": rows[i].pid, "parent_pid": rows[i].parent_pid,
            "name_units": rows[i].name_units, "name_utf16le_hex":
            bytes().join(int(unit).to_bytes(2,"little") for unit in rows[i].name[:rows[i].name_units]).hex()}
            for i in range(details["count"])]
        require(hashlib.sha256(path.read_bytes()).hexdigest() == dll_sha256, "DLL changed during snapshot")
        for name in dependencies:
            require(hashlib.sha256((system / name).read_bytes()).hexdigest() == dependency_sha256[name],
                    "System32 dependency changed during snapshot")
        evidence["dll_sha256"] = dll_sha256
    except Exception as error:
        evidence["error"] = {"type": type(error).__name__, "message": str(error),
                             "winerror": getattr(error, "winerror", None)}
        raise BulkSnapshotError(str(error), evidence) from error
    finally:
        if module is not None and module:
            evidence["unload_begin_ns"] = time.perf_counter_ns()
            if not unload(module):
                error = ctypes.get_last_error()
                evidence["unload_error"] = error
                evidence["end_ns"] = time.perf_counter_ns()
                raise BulkSnapshotError("FreeLibrary failed: " + str(error), evidence)
            evidence["unload_end_ns"] = time.perf_counter_ns()
        evidence["end_ns"] = time.perf_counter_ns()
    return output, details["upper_ticks"], evidence
