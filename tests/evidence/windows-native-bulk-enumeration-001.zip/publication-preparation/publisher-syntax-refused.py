import hashlib,json,zipfile,statistics
from pathlib import Path
root=Path(__file__).resolve().parents[2];base=root/'target/codex-security'
sha=lambda b:hashlib.sha256(b).hexdigest()
paths={'bulk':base/'issue7-native-bulk-snapshot-001','saved-decoder':base/'issue7-native-bulk-decoder-001'}
assert sha((paths['bulk']/'native-001.jsonl').read_bytes())=='25003cb193424bf3198286cc384f6de0f23de9a62384f22679d5bf4d4c7f117c'
assert sha((paths['saved-decoder']/'receipt-001.json').read_bytes())=='c53fa5673d2566fe82b5e9f477ff0d2e22109098e2696f6025471210d5b1ae42'
for folder,name in ((paths['bulk'],'unit-receipt-001.json'),(paths['saved-decoder'],'receipt-001.json')):
 receipt=json.loads((folder/name).read_bytes());assert receipt['qualified']is True
 for n,h in receipt['artifact_sha256'].items():assert sha((folder/n).read_bytes())==h
native=[json.loads(x)for x in (paths['bulk']/'native-001.jsonl').read_bytes().splitlines()]
observed=next(x for x in native if x['kind']=='snapshot_observed');terminal=native[-1]
assert terminal['kind']=='terminal' and terminal['qualified']is True
saved=[json.loads(x)for x in (paths['saved-decoder']/'comparison-001.jsonl').read_bytes().splitlines()]
measurements=[x for x in saved if x['kind']=='measured']
assert len(measurements)==8 and len({x['full_output_sha256']for x in measurements})==1
members={}
# Only frozen initial phase and saved-decoder outputs; later native plans use fresh directories.
for label,directory in paths.items():
 for p in sorted(directory.rglob('*')):
  if p.is_dir():continue
  assert p.is_file()and not p.is_symlink()and '__pycache__'not in p.parts
  assert p.stat().st_size<8000000
  members[label+'/'+p.relative_to(directory).as_posix()]=p.read_bytes()
review={'schema':1,'state':'NATIVE_COMPONENT_AND_SAVED_SHIM_PASSED_NO_CENSUS_OR_CAMPAIGN',
 'compile_plan_sha256':'616b1ba70ad25703efed29d698c9a2e350b5a4723be0ff2cc39b6ac1a70266ca',
 'unit_plan_sha256':'c513584f8548a07b214c759b346515198d7c2d4ccd55d13efb1822545da3a324',
 'native_seal_sha256':'c202dc9c485863449cc070bbe5116343d41276756bdecec7471ee525ce2ed6ff',
 'native_launch_sha256':'3d04af1fceb290fe8aed44839882299c557755d0e81e28b7b80b0df702a80fbc',
 'saved_proposal_sha256':'bef933ae755b7a2c382a069abff20e1ab91eadadd6934f5f9439181a2cb2ffd2',
 'saved_launch_sha256':'35960ff20fbc27043ecc73822a6dd52a91381c85c8cbdbf642a6a8a245c02c9c',
 'independent_sol_reviews':['profile_verified_critic','campaign_output'],
 'raw_native_audit':['root raw status/timing checks','profile_verified_method lossless integer audit a5355b2b'],
 'raw_saved_audits':['root offline audit','profile_verified_critic','campaign_output'],
 'review_scope':'Root records collaboration approvals; these records are not cryptographic reviewer signatures or independent performance replications',
 'attempts':{'compile':1,'unit':1,'native_capture':1,'saved_shim':1},
 'native_outer_seconds':30,'native_exit':0,'saved_outer_seconds':30,'saved_inner_seconds':15,'saved_exit':0,
 'native_rows':len(observed['rows']),'benchmark_slots':0,'qualified_census':False,'qualified_phase':False,'qualified_campaign':False,
 'old_wall_ns':[x['wall_ns']for x in measurements if x['variant']=='old'],
 'new_wall_ns':[x['wall_ns']for x in measurements if x['variant']=='new'],
 'population_limit':'Initial single native observation and subsequent saved-data fixed Python shim are separate experiments; neither compares guard implementations or qualifies the full collector',
 'production_change':'No production Rust guard, guarantee, default, threshold, or primary protocol changed',
 'preservation':'All initial source/compile/unit/native drafts retained. Initial native_control.py remains unexecuted; native_capture_control.py contains reviewed primary/cleanup error preservation. No retry of native or saved-data phase.'}
dependency=base/'issue7-grouped-image-census-001/native_processes.py'
assert sha(dependency.read_bytes())=='8bef895fbfefe86f39fd8bf414d46ca4037dda6e71fb4a09e839910c33b4a166'
members['dependencies/native_processes.py']=dependency.read_bytes()
members['REVIEW.json']=(json.dumps(review,indent=2)+'
').encode()
members['QUALIFICATION.md']=('''# Native enumeration component and saved-data decoder controls

The one warnings-denied MSVC build produced an AMD64 module with a single reviewed export and only KERNEL32.dll imports. Exact compiler/SDK headers, dependency paths and hashes, native ABI offsets, source and artifacts are bound. Eleven Python controls and sixteen C scripted branch controls passed in one separate unit invocation. These are controlled tests, not campaign slots.

One actual native capture returned all 524 rows without truncation or duplicate PID. Every raw UTF16 name, native status/clock chain and original observer/guard anchor was checked. Handles returned165 to165 and the code module unloaded; no error or quarantine remained. The entire Python snapshot took36.9241ms: allocation/precall0.3080ms, native FFI19.4772ms and post-native marshalling/validation17.1389ms. The native snapshot/upper bracket was16.8168ms and enumeration2.6005ms inside the FFI envelope. These elapsed intervals can include scheduling. No same-population, paired comparison against the prior collector was made. Full census, output-inclusive50ms admission and phase/campaign qualification remain false.

A separately reviewed decoder candidate replaces repeated ctypes code-unit iteration with one bounded contiguous used-row copy and compiled532-byte struct decoding. All row validation and raw UTF16 evidence generation stay inside the snapshot body. The C module, loader ownership, full-name/tail/duplicate/count/error/clock checks and original sources remain unchanged. Its single saved-data experiment reconstructed a524-row wire buffer from the qualified prefixes; zero tails are justified by the old accepted check, not claimed as original-memory bytes.

Eight complete old/new snapshot-body calls ran in fixed AB/BA/AB/BA order with the same Python memory shim. Every full output was identical, all sixteen adversarial acceptance/refusal/evidence pairs matched and eleven pure tests passed. Ordered old/new wall observations were14.8180/1.5684,10.3439/1.0326,12.9498/1.1307,10.5693/3.0047ms (pairs listed old/new independent of execution order). These are four descriptive paired saved-input observations, not population estimates, native speedups or guard comparisons. CPU deltas were quantized to0 or15.625ms; zero does not mean free CPU. Internal adapter timestamps were fixed and equal solely for complete output equality; only the outer bookends measured real wall/CPU time. No native DLL or Toolhelp call ran in that saved-data phase.

Two independent Sols approved the exact source/plan for every phase, and separate raw audits checked results. Root records their approvals in REVIEW.json; this is not an external replication or proof of universal correctness. All prelaunch corrections, source, binaries, raw streams, exact plans/seals, header traces and audits are retained. No production guard guarantee/default or numeric gate changed. The comprehensive benchmark has zero qualified measured comparisons; no win/tie/loss percentage follows.
''').encode()
index={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(members.items())}
members['INDEX.json']=(json.dumps(index,indent=2)+'
').encode()
out=root/'tests/evidence/windows-native-bulk-enumeration-001.zip'
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
with zipfile.ZipFile(out)as z:
 assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 for n,b in members.items():assert z.read(n)==b,n
print(json.dumps({'archive':str(out),'sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'members':len(members),'benchmark_slots':0},indent=2))
