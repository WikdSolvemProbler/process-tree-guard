# Windows build and image audit

The published mixed-workload directional comparison used rust-lld.exe for both consolidated main and repaired Wake. The later resolver diagnostic reused the exact same repaired Wake executable. Its baseline and candidate both used the local Microsoft link.exe version 14.51.36260.0. The candidate-minus-baseline resolver comparisons were matched by build recipe, while their comparisons with repaired Wake include the linker difference.

The audit reads the pinned AMD64 PE images without running them. The directional consolidated image contains 701,526 bytes of virtual text, 11 direct import descriptors and 175 imported symbols. The repaired Wake image contains 290,902 bytes of virtual text, 10 direct import descriptors and 127 imported symbols. The extra direct descriptor is bcryptprimitives.dll. These are file and build differences. They supply no attribution of startup latency to loading, code size, or an imported DLL.

Use pinned archive inputs windows-wake-directional-20261106.zip and windows-resolver-valid-launch-20261106.zip from the parent evidence directory. Run Python with -I -B and pass those two archive paths to audit-pe.py. The checked-in output preserves the four exact executable hashes and every parsed descriptor, section and data-directory record.
