from hashlib import sha256
import json
from pathlib import Path, PureWindowsPath
from struct import unpack_from
import sys
from zipfile import ZipFile

DIRECTIONAL = "56d7e8282ce249dc5bfc3ab984ea03e97d99b463bb85e96db1684a7992f47038"
RESOLVER = "e7bdc5ff85068e8ed03176628db5a4ad60014cbc9973577b1891f381404c1293"


def digest(raw):
    return sha256(raw).hexdigest()


def pe_layout(raw, expected):
    if digest(raw) != expected:
        raise ValueError("executable digest differs")
    u16 = lambda offset: unpack_from("<H", raw, offset)[0]
    u32 = lambda offset: unpack_from("<I", raw, offset)[0]
    u64 = lambda offset: unpack_from("<Q", raw, offset)[0]
    pe = u32(0x3C)
    coff = pe + 4
    optional = coff + 20
    if raw[:2] != b"MZ" or raw[pe:pe+4] != b"PE\0\0" or u16(coff) != 0x8664 or u16(optional) != 0x20B:
        raise ValueError("expected AMD64 PE32+")
    first_section = optional + u16(coff + 16)
    sections = []
    for index in range(u16(coff + 2)):
        offset = first_section + index * 40
        section_name = raw[offset:offset+8].partition(b"\0")[0].decode("ascii")
        virtual_size, virtual_address, raw_size, raw_offset = unpack_from("<4I", raw, offset + 8)
        sections.append({"name": section_name, "virtual_size": virtual_size, "virtual_address": virtual_address,
                         "raw_size": raw_size, "raw_offset": raw_offset})

    def absolute(rva):
        for section in sections:
            displacement = rva - section["virtual_address"]
            if 0 <= displacement < section["raw_size"]:
                return section["raw_offset"] + displacement
        raise ValueError(f"RVA is outside raw section bytes: {rva:#x}")

    def string_at(rva):
        start = absolute(rva)
        return raw[start:raw.index(b"\0", start)].decode("ascii")

    def directory(index):
        if index >= u32(optional + 108):
            return {"rva": 0, "size": 0}
        rva, size = unpack_from("<2I", raw, optional + 112 + index * 8)
        return {"rva": rva, "size": size}

    normal, delayed, tls = directory(1), directory(13), directory(9)
    imports = {}
    if normal["rva"]:
        table = absolute(normal["rva"])
        for entry in range(normal["size"] // 20):
            original, timestamp, forwarder, name, first = unpack_from("<5I", raw, table + 20 * entry)
            if not any((original, timestamp, forwarder, name, first)):
                break
            dll = string_at(name)
            if dll in imports:
                raise ValueError(f"duplicate import descriptor: {dll}")
            thunk = absolute(original or first)
            symbols = []
            while (value := u64(thunk)):
                if value >> 63:
                    symbols.append(f"#{value & 0xffff}")
                else:
                    symbols.append(string_at(value + 2))
                thunk += 8
            imports[dll] = symbols
        else:
            raise ValueError("import table has no terminating descriptor")
    return {
        "sha256": expected, "file_size": len(raw), "mapped_image_size": u32(optional + 56),
        "sections": sections, "imports": imports, "import_descriptors": len(imports),
        "import_symbols": sum(map(len, imports.values())), "delay_import_directory": delayed,
        "tls_directory": tls,
    }


def selected_linker(raw):
    argv = json.loads(raw)
    prefix = "target.x86_64-pc-windows-msvc.linker="
    paths = [value[len(prefix):].strip('"') for value in argv if value.startswith(prefix)]
    if len(paths) != 1:
        raise ValueError("expected one linker path")
    return PureWindowsPath(paths[0]).name


def main():
    direction, resolver = map(Path, sys.argv[1:])
    if digest(direction.read_bytes()) != DIRECTIONAL or digest(resolver.read_bytes()) != RESOLVER:
        raise ValueError("input archive digests differ")
    with ZipFile(direction) as old, ZipFile(resolver) as recent:
        provenance = json.loads(recent.read("assets/resolver_regression/qualification.json"))
        wake = old.read("binaries/wake/process-guard.exe")
        if wake != recent.read("assets/repaired_wake/wake.exe"):
            raise ValueError("resolver and directional Wake bytes differ")
        arms = {
            "directional_main": pe_layout(old.read("binaries/main/process-tree-guard.exe"),
                "f7f6e1fca2533e651ece4b44f6a484e6903612252d3aa466870314b920dc2e02"),
            "repaired_wake": pe_layout(wake,
                "50f73d903f03ab580d4dbe1335a055febcd2aef4a79d04c5a5a179d358324770"),
            "resolver_baseline": pe_layout(recent.read("assets/baseline/process-tree-guard.exe"),
                provenance["baseline_release_sha256"]),
            "resolver_candidate": pe_layout(recent.read("assets/candidate/process-tree-guard.exe"),
                provenance["candidate_release_sha256"]),
        }
        old_linkers = {arm: selected_linker(old.read(f"build/{arm}-argv.json")) for arm in ("main", "wake")}
    result = {
        "scope": "read-only PE layout and recorded build comparison; no launch or causal timing attribution",
        "archive_sha256": {"directional": DIRECTIONAL, "resolver": RESOLVER},
        "directional_linkers": old_linkers,
        "resolver_matched_pair_linker_version": provenance["linker_version"],
        "resolver_matched_pair_native_invocations_match": provenance["release_native_invocations_match"],
        "arms": arms,
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
