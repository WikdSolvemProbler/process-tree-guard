"""Fixed ordinary own-file controls, never a campaign or payload launcher."""
import ctypes
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
SOURCE = HERE.with_name("issue7-native-image-verification-001")
PINS = {"native_image.py": "8adc1aa23a2298c3adab9ca561b621e8dccca4e78e59407aea39b9b08a2b9440",
        "native_image_control.py": "e95d7c1cde00de756da5712ada770a3fde77767e407618bd84a3e0bad19879ea"}


CASES = ("growth", "truncation")
OUTPUT = "extent-001.jsonl"
SCOPE = "independent owned extent mutations between fixed read passes; no performance inference"
REQUIRE_REFUSAL = True

def loaded(name, filename):
    path = SOURCE / filename
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PINS[filename]:
        raise ValueError("source differs: " + filename)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def error_values(error):
    return {"type": type(error).__name__, "message": str(error),
            "winerror": getattr(error, "winerror", None),
            "errno": getattr(error, "errno", None),
            "evidence": getattr(error, "evidence", None)}


def main():
    image = loaded("native_image", "native_image.py")
    owner = loaded("owner_control", "native_image_control.py")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = w.HANDLE
    kernel.GetProcessHandleCount.argtypes = [w.HANDLE, ctypes.POINTER(w.DWORD)]
    kernel.GetProcessHandleCount.restype = w.BOOL

    def handles():
        value = w.DWORD()
        if not kernel.GetProcessHandleCount(kernel.GetCurrentProcess(), ctypes.byref(value)):
            raise ctypes.WinError(ctypes.get_last_error())
        return value.value

    deadline = time.perf_counter_ns() + 15_000_000_000
    code = 0
    with (HERE / OUTPUT).open("x", encoding="utf-8") as output:
        def emit(kind, **values):
            print(json.dumps({"kind": kind, **values}), file=output, flush=True)
        emit("context", source_sha256=PINS, cases=CASES, scope=SCOPE,
             inner_deadline_seconds=15, benchmark_slots=0)
        for case in CASES:
            if time.perf_counter_ns() >= deadline:
                code = 1
                emit("deadline", next_case=case)
                break
            baseline = handles()
            owned = owner.OwnedFixture(HERE / ("fixture-" + case))
            reads, metadata_calls = [], []
            operation = {}
            result = helper_error = outer_error = None
            qualification_errors = []
            identities_before = None
            file_metadata_before = file_metadata_after = None
            first_count = 0
            real_read, real_metadata = image.held_digest, image.metadata

            def mutate():
                operation["begin_ns"] = time.perf_counter_ns()
                try:
                    if case in ("closed_replace", "held_replace"):
                        owned.replace("replacement", "target")
                    elif case == "growth":
                        owned.append("target", b"+")
                    elif case == "truncation":
                        owned.write("target", b"")
                    operation["returned"] = True
                except (OSError, ValueError) as error:
                    operation["error"] = error_values(error)
                finally:
                    operation["end_ns"] = time.perf_counter_ns()

            def read(handle, size):
                nonlocal first_count
                first_count += 1
                record = {"pass": first_count, "begin_ns": time.perf_counter_ns(),
                          "handle": handle, "initial_size": size}
                reads.append(record)
                try:
                    digest = real_read(handle, size)
                    record["sha256"] = digest
                except (OSError, ValueError) as error:
                    record["error"] = error_values(error)
                    raise
                finally:
                    record["end_ns"] = time.perf_counter_ns()
                if first_count == 1 and case != "closed_replace":
                    mutate()
                return digest

            def metadata(handle):
                record = {"begin_ns": time.perf_counter_ns(), "handle": handle}
                metadata_calls.append(record)
                try:
                    value = real_metadata(handle)
                    record["value"] = value
                    return value
                except (OSError, ValueError) as error:
                    record["error"] = error_values(error)
                    raise
                finally:
                    record["end_ns"] = time.perf_counter_ns()

            try:
                owned.create()
                owned.write("target", b"same")
                owned.write("replacement", b"next")
                identities_before = dict(owned.files)
                file_metadata_before = {name: image.named_metadata(owned.check_file(name))
                                        for name in owned.files}
                if case == "closed_replace":
                    mutate()  # No file handle is held by this control here.
                image.held_digest, image.metadata = read, metadata
                try:
                    digest, evidence = image.inspect_image(owned.check_file("target"))
                    result = {"digest": digest, "evidence": evidence}
                except (OSError, ValueError) as error:
                    helper_error = error_values(error)
                finally:
                    image.held_digest, image.metadata = real_read, real_metadata
                file_metadata_after = {name: image.named_metadata(owned.check_file(name))
                                       for name in owned.files}
                final_path = owned.check_file("target")
                final_bytes = final_path.read_bytes()
                final_state = {"length": len(final_bytes),
                               "sha256": hashlib.sha256(final_bytes).hexdigest(),
                               "bytes_hex": final_bytes.hex(),
                               "native_metadata": image.named_metadata(final_path)}
                expected_bytes = b"same+" if case == "growth" else b""
                expected_error = ("image exceeds its initial size" if case == "growth"
                                  else "image ended before its initial size")
                if not operation.get("returned"):
                    qualification_errors.append("mutation did not return successfully")
                if final_bytes != expected_bytes or final_state["native_metadata"]["size"] != len(expected_bytes):
                    qualification_errors.append("final extent/bytes differ from intended mutation")
                if (len(reads) != 2 or reads[0].get("sha256") != hashlib.sha256(b"same").hexdigest()
                        or reads[1].get("error", {}).get("type") != "ValueError"
                        or reads[1].get("error", {}).get("message") != expected_error
                        or "sha256" in reads[1]):
                    qualification_errors.append("second-pass exact extent error not demonstrated")
                if (helper_error is None or helper_error["type"] != "ValueError"
                        or helper_error["message"] != expected_error):
                    qualification_errors.append("helper refusal was not exact extent error")
                if qualification_errors:
                    code = 1
            except BaseException as error:
                code = 1
                outer_error = error_values(error)
                final_state = None
            finally:
                image.held_digest, image.metadata = real_read, real_metadata
                identities_after = dict(owned.files)
                cleanup_errors = owned.cleanup()
                after_handles = handles()
                if cleanup_errors or after_handles != baseline:
                    code = 1
                emit("case", case=case, operation=operation, helper_result=result,
                     helper_error=helper_error, outer_error=outer_error,
                     read_calls=reads, metadata_calls=metadata_calls, final_state=final_state,
                     qualification_errors=qualification_errors,
                     file_metadata_before=file_metadata_before,
                     file_metadata_after=file_metadata_after,
                     owned_identities_before=identities_before,
                     owned_identities_after=identities_after,
                     handle_count=after_handles, baseline=baseline,
                     cleanup_errors=cleanup_errors, fixture_absent=not owned.path.exists(),
                     finished_ns=time.perf_counter_ns())
                if time.perf_counter_ns() >= deadline:
                    code = 1
                    emit("deadline", completed_case=case)
                    break
        for filename, digest in PINS.items():
            if hashlib.sha256((SOURCE / filename).read_bytes()).hexdigest() != digest:
                code = 1
                emit("source_changed", filename=filename)
        if time.perf_counter_ns() >= deadline:
            code = 1
            emit("deadline", stage="terminal")
        emit("terminal", code=code, benchmark_slots=0)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
