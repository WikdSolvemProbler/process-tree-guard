"""One ordinary before-content-open rebind control; no workload process."""
from contextlib import contextmanager
import ctypes
from ctypes import wintypes as w
import hashlib
import json
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
SOURCE = HERE.with_name("issue7-native-image-verification-001")
PINS = {"native_image.py": "8adc1aa23a2298c3adab9ca561b621e8dccca4e78e59407aea39b9b08a2b9440",
        "native_image_control.py": "e95d7c1cde00de756da5712ada770a3fde77767e407618bd84a3e0bad19879ea"}


def load(name, filename):
    path = SOURCE / filename
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PINS[filename]:
        raise ValueError("source differs: " + filename)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def error_values(error):
    return {"type": type(error).__name__, "message": str(error),
            "winerror": getattr(error, "winerror", None),
            "errno": getattr(error, "errno", None),
            "evidence": getattr(error, "evidence", None)}


def file_id(value):
    return value["volume"], value["file_id_128"]


def main():
    image = load("native_image", "native_image.py")
    owner = load("owner_control", "native_image_control.py")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = w.HANDLE
    kernel.GetProcessHandleCount.argtypes = [w.HANDLE, ctypes.POINTER(w.DWORD)]
    kernel.GetProcessHandleCount.restype = w.BOOL

    def handles():
        value = w.DWORD()
        if not kernel.GetProcessHandleCount(kernel.GetCurrentProcess(), ctypes.byref(value)):
            raise ctypes.WinError(ctypes.get_last_error())
        return value.value

    deadline = time.perf_counter_ns() + 15_000_000_000
    owned = owner.OwnedFixture(HERE / "fixture-before-content-open")
    code = 0
    opened_calls, metadata_calls, read_calls = [], [], []
    mutation = {}
    helper_error = outer_error = result = before = final = None
    qualification_errors = []
    named_close_ns = None
    content_access = image.GENERIC_READ | image.FILE_READ_ATTRIBUTES
    real_opened, real_metadata, real_read = image.opened, image.metadata, image.held_digest
    with (HERE / "path-binding-001.jsonl").open("x", encoding="utf-8") as output:
        def emit(kind, **values):
            print(json.dumps({"kind": kind, **values}), file=output, flush=True)
        baseline = handles()
        emit("context", source_sha256=PINS, scope="before-content-open native path binding only",
             inner_deadline_seconds=15, benchmark_slots=0)

        @contextmanager
        def opened(path, access):
            nonlocal named_close_ns
            call = {"access": access, "begin_ns": time.perf_counter_ns()}
            opened_calls.append(call)
            try:
                if access == content_access:
                    if mutation or named_close_ns is None:
                        raise ValueError("unexpected content hook ordering/count")
                    mutation["begin_ns"] = time.perf_counter_ns()
                    mutation["named_close_ns"] = named_close_ns
                    try:
                        owned.replace("replacement", "target")
                        mutation["returned"] = True
                    except (OSError, ValueError) as error:
                        mutation["error"] = error_values(error)
                        raise
                    finally:
                        mutation["end_ns"] = time.perf_counter_ns()
                call["native_open_begin_ns"] = time.perf_counter_ns()
                with real_opened(path, access) as handle:
                    call["native_open_return_ns"] = time.perf_counter_ns()
                    call["handle"] = handle
                    yield handle
            except BaseException as error:
                call["error"] = error_values(error)
                raise
            finally:
                call["finished_ns"] = time.perf_counter_ns()
                if access == image.FILE_READ_ATTRIBUTES and not call.get("error"):
                    named_close_ns = call["finished_ns"]

        def metadata(handle):
            call = {"handle": handle, "begin_ns": time.perf_counter_ns()}
            metadata_calls.append(call)
            try:
                value = real_metadata(handle)
                call["value"] = value
                return value
            except (OSError, ValueError) as error:
                call["error"] = error_values(error)
                raise
            finally:
                call["end_ns"] = time.perf_counter_ns()

        def read(handle, size):
            call = {"handle": handle, "initial_size": size, "begin_ns": time.perf_counter_ns()}
            read_calls.append(call)
            try:
                digest = real_read(handle, size)
                call["sha256"] = digest
                return digest
            finally:
                call["end_ns"] = time.perf_counter_ns()

        try:
            owned.create()
            owned.write("target", b"same")
            owned.write("replacement", b"next")
            before = {name: image.named_metadata(owned.check_file(name))
                      for name in owned.files}
            if file_id(before["target"]) == file_id(before["replacement"]):
                raise ValueError("fixture files not distinct")
            image.opened, image.metadata, image.held_digest = opened, metadata, read
            try:
                digest, evidence = image.inspect_image(owned.check_file("target"))
                result = {"digest": digest, "evidence": evidence}
            except (OSError, ValueError) as error:
                helper_error = error_values(error)
            finally:
                image.opened, image.metadata, image.held_digest = real_opened, real_metadata, real_read
            final_bytes = owned.check_file("target").read_bytes()
            final = {"bytes_hex": final_bytes.hex(), "length": len(final_bytes),
                     "sha256": hashlib.sha256(final_bytes).hexdigest(),
                     "metadata": image.named_metadata(owned.check_file("target"))}
            if not mutation.get("returned"):
                qualification_errors.append("replacement did not return successfully")
            if final_bytes != b"next" or file_id(final["metadata"]) != file_id(before["replacement"]):
                qualification_errors.append("replacement content/full identity not demonstrated")
            if (helper_error is None or helper_error["type"] != "ImageVerificationError"
                    or helper_error["message"] != "image named entry differs from opened native identity"):
                qualification_errors.append("exact named-versus-held refusal not demonstrated")
            else:
                evidence = helper_error["evidence"]
                if (file_id(evidence["named_before"]) != file_id(before["target"])
                        or file_id(evidence["held_before"]) != file_id(before["replacement"])):
                    qualification_errors.append("refusal evidence identities do not prove rebind")
            if read_calls:
                qualification_errors.append("hash/read executed despite before-open identity mismatch")
            if (len(opened_calls) != 2 or opened_calls[0]["access"] != image.FILE_READ_ATTRIBUTES
                    or opened_calls[1]["access"] != content_access
                    or not (opened_calls[0]["finished_ns"] <= mutation.get("begin_ns", -1)
                            <= mutation.get("end_ns", -1)
                            <= opened_calls[1].get("native_open_begin_ns", -1))):
                qualification_errors.append("mutation was not exactly between named close and content open")
            if qualification_errors:
                code = 1
        except BaseException as error:
            code = 1
            outer_error = error_values(error)
        finally:
            image.opened, image.metadata, image.held_digest = real_opened, real_metadata, real_read
            cleanup_errors = owned.cleanup()
            count = handles()
            if cleanup_errors or count != baseline:
                code = 1
            emit("case", before=before, mutation=mutation, opened_calls=opened_calls,
                 metadata_calls=metadata_calls, read_calls=read_calls, result=result,
                 helper_error=helper_error, outer_error=outer_error, final=final,
                 qualification_errors=qualification_errors, cleanup_errors=cleanup_errors,
                 handles=count, baseline=baseline, fixture_absent=not owned.path.exists())
            for filename, digest in PINS.items():
                if hashlib.sha256((SOURCE / filename).read_bytes()).hexdigest() != digest:
                    code = 1
                    emit("source_changed", filename=filename)
            if time.perf_counter_ns() >= deadline:
                code = 1
                emit("deadline", stage="terminal")
            emit("terminal", code=code, benchmark_slots=0)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
