# Authenticated PreparedRun to scripted child boundary

The bridge uses the ordinary-user authenticated SOCK_SEQPACKET and pidfd fixture from PreparedRun 002. Its transport, cross-peer module and release lease module are copied unchanged. The bridge consumes the real prepared identity, ExecPlan and retained lease. It checks that the original argv allocation reaches the scripted operation and observes the original pidfd and absolute timer at release. The placement token is fixture-only.

The native verifier expects five preparation lanes. Live enters the scripted operations in order. SetupFailure stops at the scripted UID step. OwnerLost waits for native readiness on the original pidfd before proving that no scripted operations run. NoPlacement also emits no operations. PolicyDenied proves the prior admission refusal. The allow lanes check descriptor counts after consuming the prepared state. The harness reaps each direct child and unlinks the rendezvous.

The scripted operations are observations only. The fixture never allocates a cgroup or runs the decoded command. The prior ordinary-user transport uses a direct child to set its own irreversible NoNewPrivs flag, as in the original fixture.

The local Windows metadata check uses the preserved PreparedRun 002 stand-ins for Unix-only Rust standard library types. Native Linux compile and execution remain unperformed for this revision. In a separately authorized finite ordinary-user Linux scope, preserve these repo-relative paths plus the existing generic request module and `src/deadline.rs`. Compile and run with an existing canonical owner-only 0700 scratch directory as the sole argument.

```sh
rustc --edition=2021 -D warnings -C linker=/usr/bin/gcc target/codex-security/issue2-linux-child-launch-bridge-001/transport.rs -o "$tree/child-launch-bridge"
"$tree/child-launch-bridge" "$tree"
```
