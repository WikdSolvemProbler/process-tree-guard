// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

use super::*;

const AT_REMOVEDIR: c_int = 0x200;
const POLLPRI: c_short = 0x2;
const POLLERR: c_short = 0x8;
const ENOENT: c_int = 2;

unsafe extern "C" {
    #[link_name = "write"]
    fn held_write(fd: c_int, bytes: *const c_void, size: usize) -> isize;
    #[link_name = "pread"]
    fn held_pread(fd: c_int, bytes: *mut c_void, size: usize, offset: i64) -> isize;
    #[link_name = "unlinkat"]
    fn held_unlinkat(parent: c_int, name: *const c_char, flags: c_int) -> c_int;
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in super::super) enum SettlementStage {
    ArmDeadline,
    Validate,
    Kill,
    Drain,
    Remove,
    Confirm,
}

#[derive(Debug)]
pub(in super::super) struct RemovedDomain {
    pub(in super::super) name: String,
    identity: Identity,
    pub(in super::super) started_ns: u64,
    pub(in super::super) empty_ns: u64,
    pub(in super::super) removed_ns: u64,
    pub(in super::super) poll_wakeups: usize,
}

#[must_use = "settlement failure retains the domain for quarantine or explicit recovery"]
pub(in super::super) struct SettlementQuarantine {
    pub(in super::super) controls: DomainControls,
    pub(in super::super) stage: SettlementStage,
    pub(in super::super) error: String,
    pub(in super::super) removal_succeeded: bool,
}

struct Deadline {
    timer: OwnedFd,
    until_ns: u64,
}

impl Deadline {
    fn arm(until_ns: u64) -> Probe<Self> {
        check(until_ns > 0, "settlement deadline cannot disarm the timer")?;
        check(
            boottime_ns()? < until_ns,
            "settlement deadline already expired",
        )?;
        let timer =
            fd_from_call(unsafe { timerfd_create(CLOCK_BOOTTIME, O_CLOEXEC | O_NONBLOCK) })?;
        native(close_on_exec(timer.as_raw_fd()))?;
        let value = ItimerSpec {
            interval: Timespec::default(),
            value: Timespec {
                seconds: (until_ns / NS_PER_SECOND) as i64,
                nanoseconds: (until_ns % NS_PER_SECOND) as i64,
            },
        };
        native(os_result(unsafe {
            timerfd_settime(
                timer.as_raw_fd(),
                TFD_TIMER_ABSTIME,
                &value,
                ptr::null_mut(),
            )
        } as isize))?;
        let value = Self { timer, until_ns };
        value.check()?;
        Ok(value)
    }

    fn check(&self) -> Probe<u64> {
        let now = boottime_ns()?;
        check(now < self.until_ns, "settlement absolute deadline expired")?;
        Ok(now)
    }
}

fn populated(events: &OwnedFd) -> Probe<bool> {
    // pread leaves the shared open-file offset intact for the watchdog.
    let mut bytes = [0u8; 4096];
    let count = native(os_result(unsafe {
        held_pread(
            events.as_raw_fd(),
            bytes.as_mut_ptr().cast(),
            bytes.len(),
            0,
        )
    }))?;
    check(
        count < bytes.len(),
        "cgroup.events exceeded the bounded read",
    )?;
    let contents = std::str::from_utf8(&bytes[..count])
        .map_err(|_| "cgroup.events contains non-UTF-8 text")?;
    let mut field = contents
        .lines()
        .filter_map(|line| line.strip_prefix("populated "));
    let value = field.next().ok_or("cgroup.events omits populated")?;
    check(field.next().is_none(), "cgroup.events duplicates populated")?;
    match value {
        "0" => Ok(false),
        "1" => Ok(true),
        _ => Err("cgroup.events has invalid populated value".into()),
    }
}

fn wait_empty(events: &OwnedFd, deadline: &Deadline) -> Probe<(u64, usize)> {
    let mut wakeups = 0;
    loop {
        deadline.check()?;
        if !populated(events)? {
            return Ok((deadline.check()?, wakeups));
        }
        let mut descriptors = [
            PollFd {
                fd: events.as_raw_fd(),
                events: POLLPRI | POLLERR,
                revents: 0,
            },
            PollFd {
                fd: deadline.timer.as_raw_fd(),
                events: POLLIN,
                revents: 0,
            },
        ];
        native(os_result(
            unsafe { poll(descriptors.as_mut_ptr(), descriptors.len(), -1) } as isize,
        ))?;
        deadline.check()?;
        check(
            descriptors[0].revents & !(POLLPRI | POLLERR) == 0 && descriptors[1].revents == 0,
            "unexpected settlement poll event",
        )?;
        wakeups += 1;
    }
}

fn require_name_absent(parent: &OwnedFd, name: &CStr) -> Probe<()> {
    let mut unused = Statx::default();
    let result = unsafe {
        fd_statx(
            parent.as_raw_fd(),
            name.as_ptr(),
            AT_SYMLINK_NOFOLLOW,
            STATX_BASIC_STATS | STATX_MNT_ID,
            &mut unused,
        )
    };
    check(
        result == -1 && io::Error::last_os_error().raw_os_error() == Some(ENOENT),
        "removed cgroup name is not verifiably absent",
    )
}

fn unlink_exact(
    parent: &OwnedFd,
    name: &CStr,
    directory: &OwnedFd,
    expected: Identity,
) -> Probe<()> {
    require_cgroup2(parent)?;
    require_cgroup2(directory)?;
    let parent_id = require_root_mode(&descriptor_stat(parent)?, S_IFDIR)?;
    let held = require_root_mode(&descriptor_stat(directory)?, S_IFDIR)?;
    check(
        held == expected && held.same_mount(parent_id),
        "removal identity or mount changed",
    )?;
    require_name_matches(parent.as_raw_fd(), name, directory)?;
    native(os_result(
        unsafe { held_unlinkat(parent.as_raw_fd(), name.as_ptr(), AT_REMOVEDIR) } as isize,
    ))?;
    Ok(())
}

impl DomainControls {
    pub(in super::super) fn settle(
        self,
        absolute_deadline_ns: u64,
    ) -> std::result::Result<RemovedDomain, SettlementQuarantine> {
        let mut stage = SettlementStage::ArmDeadline;
        let mut removal_succeeded = false;
        let result = (|| -> Probe<RemovedDomain> {
            let started_ns = boottime_ns()?;
            let deadline = Deadline::arm(absolute_deadline_ns)?;
            stage = SettlementStage::Validate;
            self.revalidate()?;
            require_cgroup2(&self.provenance.creation.parent.directory)?;
            check(
                Identity::from(&descriptor_stat(&self.watchdog_kill)?)
                    == Identity::from(&descriptor_stat(&self.supervisor_kill)?),
                "settlement kill descriptors name different inodes",
            )?;
            deadline.check()?;
            stage = SettlementStage::Kill;
            let written = native(os_result(unsafe {
                held_write(self.supervisor_kill.as_raw_fd(), b"1".as_ptr().cast(), 1)
            }))?;
            check(written == 1, "settlement cgroup.kill write was short")?;
            stage = SettlementStage::Drain;
            let (empty_ns, poll_wakeups) = wait_empty(&self.events, &deadline)?;
            stage = SettlementStage::Remove;
            self.revalidate()?;
            deadline.check()?;
            let creation = &self.provenance.creation;
            unlink_exact(
                &creation.parent.directory,
                &creation.name,
                &self.directory,
                self.provenance.identity,
            )?;
            removal_succeeded = true;
            stage = SettlementStage::Confirm;
            require_name_absent(&creation.parent.directory, &creation.name)?;
            let removed_ns = deadline.check()?;
            Ok(RemovedDomain {
                name: creation.name.to_string_lossy().into_owned(),
                identity: self.provenance.identity,
                started_ns,
                empty_ns,
                removed_ns,
                poll_wakeups,
            })
        })();
        result.map_err(|error| SettlementQuarantine {
            controls: self,
            stage,
            error,
            removal_succeeded,
        })
    }
}

#[cfg(test)]
#[path = "settlement_fixture.rs"]
mod fixture;
