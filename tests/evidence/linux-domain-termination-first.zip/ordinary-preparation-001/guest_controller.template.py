"""Ordinary compilation and four selected component controls; never root."""
import base64
import hashlib
import json
import os
from pathlib import Path
import selectors
import stat
import subprocess
import sys
import tempfile

EXPECTED = @EXPECTED_JSON@
PAYLOAD_SHA256 = "@PAYLOAD_SHA256@"
UNIT = "ptg-authority-linux-007.scope"
CONTROL_GROUP = "/user.slice/user-501.slice/user@501.service/app.slice/" + UNIT
COMPILER = "/home/petershiller1.guest/.rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu/bin/rustc"
FILTER = "cross_peer::release_lease::prepared_run::native_activation::cgroup_authority::settlement::controls::"

def demand(value, text):
    if not value:
        raise RuntimeError(text)

def write_all(fd, data):
    while data:
        n = os.write(fd, data)
        demand(n > 0, "short retained stream write")
        data = data[n:]

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for part in iter(lambda: f.read(65536), b""):
            h.update(part)
    return h.hexdigest()

tree = None
try:
    os.umask(0o077)
    demand(os.getuid() == 501 and os.geteuid() == 501, "ordinary UID501 required")
    demand(os.getgid() != 0 and os.getegid() != 0, "root group refused")
    demand(os.uname().machine == "aarch64", "ARM64 qualification only")
    scope = Path("/proc/self/cgroup").read_text().strip()
    demand(scope == "0::" + CONTROL_GROUP, "unexpected actual user scope")
    prop = subprocess.run(["/usr/bin/systemctl", "--user", "show", UNIT,
                           "-p", "RuntimeMaxUSec", "-p", "KillMode", "-p", "KillSignal",
                           "-p", "SendSIGKILL", "-p", "ControlGroup", "-p", "ActiveState"],
                          capture_output=True, text=True, timeout=3)
    print("SCOPE_PROPERTIES=" + json.dumps({"stdout": prop.stdout, "stderr": prop.stderr,
          "exit": prop.returncode, "actual_cgroup": scope}), flush=True)
    demand(prop.returncode == 0, "effective scope query refused")
    properties = dict(line.split("=", 1) for line in prop.stdout.splitlines())
    for key, value in {"RuntimeMaxUSec": "1min 10s", "KillMode": "control-group", "KillSignal": "9",
                       "SendSIGKILL": "yes", "ControlGroup": CONTROL_GROUP, "ActiveState": "active"}.items():
        demand(properties.get(key) == value, "effective finite scope property differs: " + key)
    packet = sys.stdin.buffer.read(1024 * 1024 + 1)
    demand(len(packet) <= 1024 * 1024 and hashlib.sha256(packet).hexdigest() == PAYLOAD_SHA256,
           "exact source payload differs")
    entries = json.loads(packet)["files"]
    demand(set(entries) == set(EXPECTED), "source member set differs")
    tree = Path(tempfile.mkdtemp(prefix="ptg-authority-linux-007.", dir="/tmp"))
    held = tree.stat()
    demand(held.st_uid == 501 and stat.S_IMODE(held.st_mode) == 0o700, "scratch custody differs")
    print("ORDINARY_SCRATCH=" + json.dumps({"path": str(tree), "device": held.st_dev,
          "inode": held.st_ino, "uid": held.st_uid, "mode": stat.S_IMODE(held.st_mode)}), flush=True)
    for name, pin in EXPECTED.items():
        data = base64.b64decode(entries[name], validate=True)
        demand(len(data) == pin["bytes"] and hashlib.sha256(data).hexdigest() == pin["sha256"],
               "source bytes differ: " + name)
        path = tree / name
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with path.open("xb") as f:
            f.write(data)
        demand(digest(path) == pin["sha256"], "staged source differs: " + name)
    os.environ["TMPDIR"] = str(tree)
    os.chdir(tree)

    def command(argv, tag):
        print("NATIVE_ARGV=" + json.dumps({"tag": tag, "argv": argv}), flush=True)
        out_path, err_path = tree / (tag + ".stdout.log"), tree / (tag + ".stderr.log")
        with out_path.open("xb") as out, err_path.open("xb") as err:
            child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, close_fds=True)
            print("NATIVE_CHILD=" + json.dumps({"tag": tag, "pid": child.pid}), flush=True)
            with selectors.DefaultSelector() as selector:
                selector.register(child.stdout, selectors.EVENT_READ, (out, 1))
                selector.register(child.stderr, selectors.EVENT_READ, (err, 2))
                while selector.get_map():
                    for key, events in selector.select(timeout=0.1):
                        data = os.read(key.fileobj.fileno(), 4096)
                        if not data:
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                            continue
                        retained, transport = key.data
                        retained.write(data)
                        retained.flush()
                        write_all(transport, data)
            code = child.wait()
        (tree / (tag + ".exit.txt")).write_text(str(code))
        print("NATIVE_EXIT=" + json.dumps({"tag": tag, "pid": child.pid, "exit": code,
              "stdout_sha256": digest(out_path), "stderr_sha256": digest(err_path)}), flush=True)
        demand(code == 0, "native step failed: " + tag)
        return out_path

    print("NATIVE_CONTEXT=" + json.dumps({"pid": os.getpid(), "uid": os.getuid(),
          "uname": list(os.uname()), "compiler": COMPILER, "compiler_sha256": digest(Path(COMPILER)),
          "gcc_sha256": digest(Path("/usr/bin/gcc")), "payload_executions": 0,
          "root_fixture_executions": 0, "cgroup_writes": 0}), flush=True)
    command([COMPILER, "--version", "--verbose"], "compiler-version")
    command([COMPILER, "--edition=2021", "-D", "warnings", "--test", "-C", "linker=/usr/bin/gcc",
             "target/codex-security/issue2-linux-cgroup-authority-007/transport.rs", "-o", "authority-tests"], "compile")
    print("NATIVE_BINARY=" + json.dumps({"path": str(tree / "authority-tests"),
          "sha256": digest(tree / "authority-tests")}), flush=True)
    listed = command([str(tree / "authority-tests"), FILTER, "--list"], "list-controls")
    actual_names = [line[:-6] for line in listed.read_text().splitlines() if line.endswith(": test")]
    expected_names = {FILTER + suffix for suffix in (
        "callback_error_follows_kill_and_keeps_its_outcome",
        "unsuccessful_kill_never_enters_cleanup_wait_setup",
        "successful_post_kill_result_preserves_outcome",
        "native_regular_file_kill_attempt_precedes_expired_timer_refusal",
    )}
    demand(len(actual_names) == 4 and set(actual_names) == expected_names,
           "selected test names/count differ; refuse execution")
    print("SELECTED_CONTROLS=" + json.dumps(actual_names), flush=True)
    output = command([str(tree / "authority-tests"), FILTER, "--nocapture", "--test-threads=1"], "controls")
    text = output.read_text()
    demand("test result: ok. 4 passed; 0 failed; 0 ignored;" in text,
           "selected four-control result differs")
    demand("ordinary_file_write=1 expired_timer_refused=true payloads=0 cgroup_writes=0" in text,
           "native ordinary-file/expired-deadline receipt missing")
    demand(not list(tree.glob("ptg-termination007-*")), "ordinary control artifact remains")
    for name, pin in EXPECTED.items():
        demand(digest(tree / name) == pin["sha256"], "source changed during qualification: " + name)
    inventory = {str(p.relative_to(tree)): {"bytes": p.stat().st_size, "sha256": digest(p),
                 "device": p.stat().st_dev, "inode": p.stat().st_ino}
                 for p in sorted(tree.rglob("*")) if p.is_file()}
    (tree / "ordinary-inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
    print("ORDINARY_COMPONENT_COMPLETE=" + json.dumps({"four_controls_passed": True,
          "scratch_retained": str(tree), "scratch_identity": [held.st_dev, held.st_ino],
          "file_inventory": inventory, "payload_executions": 0, "root_fixture_executions": 0,
          "cgroup_writes": 0, "scope": "termination driver plus ordinary held-file/expired-deadline control only"}), flush=True)
except BaseException as error:
    print("ORDINARY_COMPONENT_REFUSED=" + json.dumps({"error": type(error).__name__ + ": " + str(error),
          "scratch_retained": None if tree is None else str(tree),
          "policy": "preserve raw failure and owned artifacts before exact identity cleanup; no retry/root fallback"}), flush=True)
    raise
