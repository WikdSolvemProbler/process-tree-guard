# Prepared ordinary007 compile/control launch

PREPARED ONLY. No compiler, selected control or VM command has run for007.
The exact source candidate requires independent source approval and this exact
command/plan requires root review before execution. This preparation uses the
parent's reviewed proposed bounds: Linux ordinary user scope70s, guest waiting
client timeout75s/kill-after3s, Mac gtimeout80s/kill-after3s, Windows Job100s.
These replace the earlier illustrative bounds in the source-only METHOD.

The chain contains no sudo, administrator authentication, root process, root
fixture, account change, cgroup provision/placement/write, payload, or concurrency
probe. The guest controller refuses any real/effective UID except501, any root
primary group, unexpected ARM architecture, wrong actual cgroup, or wrong
effective RuntimeMax/KillMode/KillSignal/SendSIGKILL properties before staging.
Its systemd scope and both timeout wrappers use finite whole-group termination.
The waiting systemd-run client has its separate guest timeout bound as well.
SSH uses BatchMode, strict known-host checking, and an8s connect timeout.

Windows reads and hashes each plan/command/payload byte snapshot once and uses
those same verified command/payload buffers. The guest verifies the exact payload
digest, exact named source set, every source length/hash, and every staged source
again before compilation in a new private mode0700 UID501 directory. It compiles
the unchanged real Rust module graph with -D warnings and the actual Linux ARM64
compiler. Compiler version/hash, gcc hash, native binary hash, exact argv, child
PIDs, exits and raw streams are recorded. Stream chunks are flushed to transport
and local raw files as observed, rather than discarded until completion.

The only selected test filter is
cross_peer::release_lease::prepared_run::native_activation::cgroup_authority::settlement::controls::
with --nocapture --test-threads=1. First --list must resolve exactly the four
expected fully qualified names; a missing/extra name refuses execution. The
execution must report exactly4 passed,0 failed,0 ignored
and the ordinary native-file/past-deadline receipt. The inherited ignored root
fixture is compiled but not selected or run. No broader transport/lifecycle test
suite is selected. The native control uses TMPDIR under this exact owned scratch.

Success verifies source continuity and prints the retained scratch identity and
complete file inventory. Failure preserves its raw receipt and the exact scratch
path if known. This command performs no scratch cleanup. Archive and verify all
raw artifacts before a separately scoped identity-checked ordinary cleanup; never
guess a path, rerun failed tests, or use root as a fallback. Abrupt expiry can leave
ordinary artifacts while the independent scope bounds the process tree.

This is ordinary compiler/shared-driver/regular-file qualification only. It does
not requalify native DomainControls custody, populated cleanup, error injection
into actual cgroup syscalls, child reaping, watchdog integration or a full port.
The trusted local ordinary account and installed system/toolchain utilities are
part of the test trust boundary; this is not a hostile-administrator file-race
proof. No Mac administrator test or earlier rejected concurrency test is resumed.
