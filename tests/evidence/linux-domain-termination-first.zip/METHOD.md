# Termination-first settlement candidate007

SOURCE ONLY: neither a compiler nor these controls has run for007 at preparation.
No root, privileged, payload, concurrent, or production activation is performed.
Sources005 and006 and all of their receipts remain unchanged. This fresh source
graph copies006, including its corrected ARM64 open constants and explicit ABI
scope. Only settlement.rs, its error-output fields in settlement_fixture.rs, and
the new settlement_controls.rs differ from the inherited Rust graph.

The concrete repair makes the original held supervisor-kill write the first
native operation in DomainControls::settle. The trusted factory's original held
authority is used, never a client descriptor or newly resolved path. No initial
clock read, cleanup timer allocation/arming, fstat, or name/path revalidation is
a prerequisite for that cancellation attempt. Exactly one write is attempted;
its outcome is Written, Short(bytes), or Failed(errno). Failed/short writes return
retained quarantine without entering the cleanup callback. They are not a pass
or proof of termination. EINTR is preserved as a failure, not silently retried.

The shared terminate_then helper owns its custody value. Production passes the
actual DomainControls. On a returned error the helper returns that owned value,
kill outcome and error together; settle moves them into SettlementQuarantine,
retaining the stage and removal_succeeded flag. Successful RemovedDomain receipts
also include the kill outcome. The existing ignored fixture only adds outcome
fields to its failure output; it is not executed or otherwise redesigned here.
The clock field is now after_kill_ns: it is observed after the write returns,
not a pre-kill timestamp or a measured syscall duration.

After a successful write, the existing finite cleanup path remains: read time,
arm/check a separate absolute CLOCK_BOOTTIME deadline, revalidate authorities,
wait for populated0, revalidate/remove the exact leaf, and confirm absence before
that same deadline. Zero/past deadlines and clock/timer failures now return
quarantine after the kill request. They never enter wait_empty. That function
still requires a successfully constructed Deadline and checks it before poll.
No lease timer is rearmed, no execution deadline is extended, and no unarmed or
fallback unlimited wait is added. A later error, including one after successful
removal, retains its original kill outcome and custody; it is not cleanup success.

The component has important limits. The native write can itself block. Clock,
validation, and removal syscalls also need independent process-level coverage in
a complete implementation. The prototype is not an independent custodian and
does not replace the missing one-shot watchdog/full terminal orchestration.
An armed cleanup timer bounds the polling path, not every kernel syscall or
supervisor failure. A write receipt does not prove populated drainage or reaping.
Unexpected panic/process death is outside this returned-error custody contract.
There is no do-nothing Drop implementation presented as a cleanup guarantee.

Four new controls are prepared, not executed:

* One honest callback-order/error test for the shared driver. This is not kernel
  clock/timer/fstat/path fault injection and does not construct fake DomainControls.
* Short and errno outcome controls require that the cleanup callback is not entered.
* A successful callback preserves its recorded kill outcome.
* On Linux only, the real held-write helper writes1 to a fresh private ordinary
  regular file. The same driver then calls the real Deadline::arm(1), which must
  refuse an already-past deadline and return the held file in its error custody.
  The fixture verifies the byte and removes its own ordinary file/directory.
  It opens no cgroup, starts no child or payload, and performs no root operation.

The source ordering/shared helper and owned return types explain why other
returned clock/timer/fstat/name errors cannot precede the held write. They are
not claimed as distinct native fault-injection results. Real DomainControls
custody, populated wait behavior and root cleanup have not been requalified for007.
The prior006 native pass was empty-domain only with zero poll wakeups; it cannot
be carried forward as a007 populated or failure-path pass.

Proposed qualification after exact source and command review: a30s Windows
metadata-only test build against the copied metadata wrappers, followed separately
by an ordinary Linux ARM64 full-module test build and only the settlement::controls
filter with --nocapture --test-threads=1. Proposed independent bounds are Linux
user scope35s (SIGKILL/control-group), Mac gtimeout50s/kill-after3s and Windows
Job70s. Root will review the exact command and approve before any VM launch.
Only the selected four new controls are intended; do not run the ignored root
fixture or unrelated transport/lifecycle tests. Any compiler/control failure and
partial output must be preserved. No prior rejected concurrency test is resumed.

The next separate component remains typed arming-failure custody and a consuming
PendingSettlement owner with exact payload/watchdog reaping and independent
finite watchdog coverage. This patch does not enable a production Linux backend.
