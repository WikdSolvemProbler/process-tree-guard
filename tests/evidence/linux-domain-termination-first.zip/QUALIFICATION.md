# Termination-first Linux settlement: source and ordinary qualification

Candidate007 repairs the concrete prototype ordering defect that allowed a clock,
expired-deadline, timer-setup or path-validation error to precede its held kill
request. It writes through the original trusted supervisor-kill descriptor first.
Written, Short(bytes) or Failed(errno) is retained in successful or quarantined
outcomes. Failed/short writes do not enter wait setup. The shared helper owns the
actual DomainControls and returns that custody on every returned error. Removal
still requires the original bounded timer, authority/name validation, populated0,
exact original leaf unlink and absence confirmation. after_kill_ns is observed
after the write returns; it is not a pre-kill or syscall-duration measurement.

The independent source review and parent review approved source-candidate.json
SHA488f969acb88300ce7a76da6ab615013b31c932b044571d37d7f5daf4c1fe736
and the ordinary-only qualification scope. REVIEW.json records the reviewers,
resolved objections and remaining production gaps. No unresolved objection was
left for this narrow source/ordinary-control scope. These reviews do not substitute
for native evidence or approve full production activation.

Exactly one ordinary VM attempt ran under plan
014cbde3665dcccb6c67766e77ba81e4a920d4a0910c1bc86aee65f1b0ea9459.
The actual Linux ARM64 environment was kernel6.8.0-147-generic. The full real module
graph compiled with Rust1.99 and -D warnings. The driver verified effective user
scope RuntimeMax70s, KillMode control-group, KillSignal9 and SendSIGKILLyes before
staging. Independent guest-client75s, Mac80s and Windows Job100s deadlines bounded
the enclosing chain. Source lengths/hashes were checked before compilation and
again after testing. No root command or administrator authentication was attempted.

The native test harness first listed exactly these four selected controls:

* callback_error_follows_kill_and_keeps_its_outcome
* unsuccessful_kill_never_enters_cleanup_wait_setup
* successful_post_kill_result_preserves_outcome
* native_regular_file_kill_attempt_precedes_expired_timer_refusal

All four share the prefix
cross_peer::release_lease::prepared_run::native_activation::cgroup_authority::settlement::controls::
and were then run with --nocapture --test-threads=1. The result was4 passed,
0 failed,0 ignored,13 filtered out. The first three check shared-driver contracts.
The fourth used the actual held-write helper on a private ordinary regular file,
verified byte1, then required the actual Deadline::arm(1) call to refuse an expired
deadline while returning the owned file in its failure. That fixture removed its
ordinary file/directory. No cgroup was opened or written by these controls, no
payload or child fixture ran, and the inherited ignored root fixture was not run.

The native binary SHA-256 is
93b3b21d89ae570cad221d7410f00ffbdba8d149a2487a657de0b5db71a58644.
Its exact bytes, all26 remote artifacts, compiler version/hash, gcc hash, complete
raw streams, exits, --list receipt, source/payload/tool pins and commands are in
the archive. The unchanged006 baseline settlement files are included for review;
the full prior empty-domain source/native proof remains separately bound by
linux-domain-settlement.zip SHA
609e1812f40f0387680f2e8e7686ddb8f1262469e47581cf752dffb0d4a69b35.
The source-only METHOD and pending-review source snapshot describe preparation
chronology and are preserved unchanged; RESULTS.json states the later actual run.

Before deletion, an independently bounded ordinary check found the original unit
not loaded/inactive, its exact cgroup path absent, and all five recorded controller,
compiler, list and test PIDs absent. It opened only the original private UID501
scratch /tmp/ptg-authority-linux-007.se7ag3gv, dev64769 inode1052328, using retained
no-follow descriptors. It checked the exact inventory and completion hashes/inodes
and downloaded every file. These checks report PID absence; no unrecorded process
creation-time identity claim is made.

Every downloaded artifact was locally hash-verified. A complete pre-removal ZIP
was verified before cleanup: SHA
ae59a60f289628a592245f187a2e7bc9e374a00a07cfda1d2a09c0922456e9e3,
7,252,681bytes,65members. The subsequent ordinary removal repeated worker/scope
checks and compared held directory/file identities, sizes, hashes, modes and the
full preserved inventory. It unlinked only those exact26 files, removed their
verified now-empty directories and confirmed the original root scratch absent.
Every removal is recorded. No recursive guessed-path or root deletion was used.
The local pre-removal ZIP is not nested in this public ZIP; its complete evidence
members are directly included along with the subsequent cleanup receipts.

Limitations remain substantial. A native write or another kernel syscall can
block. The component is not an independent watchdog and does not enforce bounded
custody on process death or panic. There is no claim of actual clock/timer/fstat
fault injection: the helper/source ordering explains why those later returned
errors cannot skip the first write. Native DomainControls success/error handling,
populated polling, reaping, watchdog behavior and a full one-shot activation were
not exercised by007. The prior006 native proof used an empty domain with zero
poll wakeups. Typed arming-failure custody, consuming PendingSettlement and exact
payload/watchdog child settlement remain open. No production backend was enabled,
no performance claim is made, and no rejected concurrency experiment was resumed.

INDEX.json gives exact byte lengths and SHA-256 for every other public archive
member. Complete source/capture continuity, archive membership/CRC and exact bytes
are checked. No tracked documentation or Git history was changed by this task.
