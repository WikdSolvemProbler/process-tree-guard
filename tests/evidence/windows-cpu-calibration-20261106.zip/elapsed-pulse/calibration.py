"""Scratch instrument for the frozen Windows raw-cycle calibration."""
import ctypes
from ctypes import wintypes
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import random
import struct
import subprocess
import sys
import time


PROTOCOL_SHA256 = "f42b03f787681823c73e225bd78272e6bf3c92612b8154f135442297b28fec87"
CLOCK = time.perf_counter_ns
MS = 1_000_000
PACKET = struct.Struct("<BQ")
READY = 254
QUIT = 255
CONDITIONS = ("idle_a", "idle_b", "short", "long")
PULSES = (0, 0, 2, 8)
KERNEL = ctypes.WinDLL("kernel32", use_last_error=True)
HANDLE = wintypes.HANDLE
DWORD = wintypes.DWORD
BOOL = wintypes.BOOL
FILETIME = wintypes.FILETIME
U64 = ctypes.c_ulonglong


def bind(name, result, *arguments):
    function = getattr(KERNEL, name)
    function.restype = result
    function.argtypes = arguments
    return function


get_process_times = bind("GetProcessTimes", BOOL, HANDLE, *([ctypes.POINTER(FILETIME)] * 4))
get_cycles = bind("QueryProcessCycleTime", BOOL, HANDLE, ctypes.POINTER(U64))
get_process_id = bind("GetProcessId", DWORD, HANDLE)
get_current_process = bind("GetCurrentProcess", HANDLE)
is_process_in_job = bind("IsProcessInJob", BOOL, HANDLE, HANDLE, ctypes.POINTER(BOOL))
wait_handle = bind("WaitForSingleObject", DWORD, HANDLE, DWORD)
peek_pipe = bind(
    "PeekNamedPipe", BOOL, HANDLE, ctypes.c_void_p, DWORD, ctypes.POINTER(DWORD),
    ctypes.POINTER(DWORD), ctypes.POINTER(DWORD),
)


class Refusal(Exception):
    pass


def require(condition, reason):
    if not condition:
        raise Refusal(reason)


def checked(success):
    if not success:
        raise ctypes.WinError(ctypes.get_last_error())


def filetime_ticks(value):
    return (value.dwHighDateTime << 32) | value.dwLowDateTime


def snapshot(handle, observation, label):
    creation, exit_time, kernel, user = (FILETIME() for _ in range(4))
    cycles = U64()
    sample = observation[label] = {}
    sample["start_ns"] = CLOCK()
    checked(get_process_times(handle, ctypes.byref(creation), ctypes.byref(exit_time),
                              ctypes.byref(kernel), ctypes.byref(user)))
    sample["creation_filetime"] = filetime_ticks(creation)
    sample["kernel_100ns"] = filetime_ticks(kernel)
    sample["user_100ns"] = filetime_ticks(user)
    checked(get_cycles(handle, ctypes.byref(cycles)))
    sample["finish_ns"] = CLOCK()
    sample["cycles"] = cycles.value
    return sample


def write_message(stream, payload):
    require(stream.write(payload) == len(payload), "short IPC write")


def worker():
    stdin, stdout = sys.stdin.buffer.raw, sys.stdout.buffer.raw
    write_message(stdout, PACKET.pack(READY, 0))
    while True:
        command = stdin.read(1)
        require(len(command) == 1, "worker command stream closed")
        code = command[0]
        if code == QUIT:
            write_message(stdout, PACKET.pack(QUIT, 0))
            return
        require(code < len(PULSES), "invalid worker command")
        pulse_ns = PULSES[code] * MS
        elapsed_ns = 0
        if pulse_ns:
            start = CLOCK()
            elapsed_ns = CLOCK() - start
            while elapsed_ns < pulse_ns:
                elapsed_ns = CLOCK() - start
        write_message(stdout, PACKET.pack(code, elapsed_ns))


def read_message(stream, deadline_ns):
    handle = msvcrt.get_osfhandle(stream.fileno())
    available = DWORD()
    while CLOCK() <= deadline_ns:
        checked(peek_pipe(handle, None, 0, None, ctypes.byref(available), None))
        if available.value >= PACKET.size:
            data = stream.read(PACKET.size)
            received = CLOCK()
            require(received <= deadline_ns, "late worker acknowledgment")
            require(len(data) == PACKET.size, "short worker acknowledgment")
            return (*PACKET.unpack(data), received)
        time.sleep(0)
    raise Refusal("worker acknowledgment deadline missed")


def alive(handle, pid):
    require(get_process_id(handle) == pid, "held handle identity mismatch")
    require(wait_handle(handle, 0) == 258, "held child is not live")


def wait_until(target_ns):
    while CLOCK() < target_ns:
        time.sleep(0)


def measure(child, handle, row, creation_time, previous_slot_end_ns):
    code = CONDITIONS.index(row["condition"])
    wait_until(previous_slot_end_ns)
    alive(handle, child.pid)
    before = snapshot(handle, row, "before")
    command = bytes((code,))
    release_ns = CLOCK()
    try:
        write_message(child.stdin, command)
    finally:
        row["release_ns"] = release_ns
    received_code, pulse_ns, acknowledgment_ns = read_message(child.stdout, release_ns + 75 * MS)
    row.update(received_code=received_code, pulse_elapsed_ns=pulse_ns,
               acknowledgment_ns=acknowledgment_ns)
    require(received_code == code, "wrong trial acknowledgment")
    lower = PULSES[code] * MS
    upper = lower + MS if lower else 0
    require(lower <= pulse_ns <= upper, "pulse outside acceptance window")
    wait_until(release_ns + 90 * MS)
    after = snapshot(handle, row, "after")
    require(after["start_ns"] >= release_ns + 90 * MS
            and after["finish_ns"] < release_ns + 100 * MS, "missed post snapshot window")
    alive(handle, child.pid)
    require(before["creation_filetime"] == after["creation_filetime"], "creation identity changed")
    if creation_time is not None:
        require(before["creation_filetime"] == creation_time, "creation identity differs across trials")
    deltas = {key: after[key] - before[key] for key in ("user_100ns", "kernel_100ns", "cycles")}
    require(all(value >= 0 for value in deltas.values()), "negative counter delta")
    row["delta"] = {**deltas, "process_time_100ns": deltas["user_100ns"] + deltas["kernel_100ns"]}
    return before["creation_filetime"], release_ns + 100 * MS


def frozen_schedule(protocol_path):
    data = protocol_path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == PROTOCOL_SHA256, "frozen protocol hash mismatch")
    protocol = json.loads(data)
    require(protocol["schema"] == 1, "protocol schema mismatch")
    require(sys.version == protocol["python_version"], "pinned Python version mismatch")
    generator = random.Random(protocol["seed"])
    schedule = []
    for _ in range(12):
        quartet = list(CONDITIONS)
        generator.shuffle(quartet)
        schedule.append(quartet)
    require(schedule == protocol["measured_quartets"], "frozen randomized schedule mismatch")
    require(list(CONDITIONS) == protocol["warmup_excluded"], "frozen warmup mismatch")
    return [list(CONDITIONS), *schedule]


def score(quartets):
    require(len(quartets) == 12, "missing measured quartet")
    scores = {"cycles": [], "process_time_100ns": []}
    for quartet in quartets:
        require(len(quartet) == 4 and set(quartet) == set(CONDITIONS), "missing measured condition")
        for metric, results in scores.items():
            idle_a, idle_b, short, long = (quartet[name][metric] for name in CONDITIONS)
            idle_difference = abs(idle_a - idle_b)
            margin = max(1, 2 * idle_difference)
            short_difference = short - max(idle_a, idle_b)
            long_difference = long - short
            results.append(dict(idle_difference=idle_difference, margin=margin,
                                short_difference=short_difference, long_difference=long_difference,
                                passed=short_difference > margin and long_difference > margin))
    counts = {metric: sum(result["passed"] for result in results) for metric, results in scores.items()}
    cycles, process_time = counts["cycles"], counts["process_time_100ns"]
    return dict(scores=scores, pass_counts=counts,
                outcome="screen_passed" if cycles >= 11 and cycles - process_time >= 3 else "inconclusive")


def record(stream, event, **fields):
    stream.write(json.dumps({"event": event, **fields}, sort_keys=True) + "\n")
    stream.flush()
    os.fsync(stream.fileno())


def require_job(handle):
    in_job = BOOL()
    checked(is_process_in_job(handle, None, ctypes.byref(in_job)))
    require(in_job.value, "process is outside a Windows Job")


def stop_child(child, handle):
    start_ns = CLOCK()
    write_message(child.stdin, bytes((QUIT,)))
    code, payload, received_ns = read_message(child.stdout, start_ns + 500 * MS)
    require(code == QUIT and payload == 0, "invalid exit acknowledgment")
    remaining = start_ns + 500 * MS - CLOCK()
    require(remaining >= 0, "exit deadline missed")
    code = child.wait(timeout=remaining / 1_000_000_000)
    finish_ns = CLOCK()
    require(finish_ns <= start_ns + 500 * MS, "exit deadline missed")
    require(code == 0 and wait_handle(handle, 0) == 0, "held child did not exit zero")
    return dict(start_ns=start_ns, acknowledgment_ns=received_ns, finish_ns=finish_ns, exit_code=code)


def capture(output):
    instrument = Path(__file__).resolve()
    with output.open("x", encoding="utf-8", newline="\n") as journal:
        record(journal, "started", protocol_sha256=PROTOCOL_SHA256,
               instrument_sha256=hashlib.sha256(instrument.read_bytes()).hexdigest(),
               python=sys.version, executable=sys.executable, clock=time.get_clock_info("perf_counter").implementation)
        child = None
        try:
            require_job(get_current_process())
            schedule = frozen_schedule(instrument.with_name("protocol.json"))
            record(journal, "schedule", warmup=schedule[0], measured=schedule[1:])
            startup_ns = CLOCK()
            child = subprocess.Popen([sys.executable, "-I", "-B", str(instrument), "--worker"],
                                     stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     bufsize=0, close_fds=True)
            # Popen retains the original CreateProcess handle throughout this run.
            handle = int(child._handle)
            require_job(handle)
            code, payload, ready_ns = read_message(child.stdout, startup_ns + 500 * MS)
            require(code == READY and payload == 0, "invalid startup acknowledgment")
            alive(handle, child.pid)
            record(journal, "worker_ready", pid=child.pid, startup_ns=startup_ns, ready_ns=ready_ns)
            creation = None
            slot_end_ns = 0
            quartets = []
            for index, quartet in enumerate(schedule):
                results = {}
                for condition in quartet:
                    row = dict(quartet=index, condition=condition, warmup=(index == 0))
                    record(journal, "trial_attempt", **row)
                    try:
                        creation, slot_end_ns = measure(child, handle, row, creation, slot_end_ns)
                    except Exception as error:
                        record(journal, "trial_refused", **row, reason=str(error))
                        raise
                    record(journal, "trial_observed", **row)
                    results[condition] = row["delta"]
                if index:
                    quartets.append(results)
            wait_until(slot_end_ns)
            teardown = stop_child(child, handle)
            record(journal, "terminal", **score(quartets), teardown=teardown)
            return 0
        except (Exception, KeyboardInterrupt) as error:
            record(journal, "terminal", outcome="refused", error_type=type(error).__name__, reason=str(error))
            if child is not None and child.poll() is None:
                child.kill()
                child.wait(timeout=0.5)
            return 2
        finally:
            if child is not None:
                child.stdin.close()
                child.stdout.close()


if __name__ == "__main__":
    if sys.argv[1:] == ["--worker"]:
        worker()
    elif len(sys.argv) == 3 and sys.argv[1] == "--output":
        raise SystemExit(capture(Path(sys.argv[2])))
    else:
        raise SystemExit("Usage: calibration.py --output NEW_JOURNAL_PATH")
