from collections import Counter
from hashlib import sha256
import json
from pathlib import Path

root = Path(__file__).resolve().parent
folder = root / 'attempt-002'
protocol_raw = (root / 'protocol.json').read_bytes()
protocol = json.loads(protocol_raw)
sha = sha256(protocol_raw).hexdigest()
assert sha == 'f42b03f787681823c73e225bd78272e6bf3c92612b8154f135442297b28fec87'
launch = json.loads((folder / 'launch.json').read_bytes())
assert launch['whole_tree_seconds'] == 60 and launch['protocol_sha256'] == sha
assert sha256((root / 'calibration.py').read_bytes()).hexdigest() == launch['instrument_sha256']
events = [json.loads(line) for line in (folder / 'journal.jsonl').read_bytes().splitlines()]
assert events[0]['event'] == 'started' and events[0]['protocol_sha256'] == sha
assert events[-1]['event'] == 'terminal' and events[-1]['outcome'] == 'refused'
assert events[-1]['reason'] == 'pulse outside acceptance window'
planned = [(i, condition) for i, quartet in enumerate(
    [protocol['warmup_excluded'], *protocol['measured_quartets']]) for condition in quartet]
attempts = [row for row in events if row['event'] == 'trial_attempt']
observed = [row for row in events if row['event'] == 'trial_observed']
refused = [row for row in events if row['event'] == 'trial_refused']
assert len(attempts) == len(observed) + 1 == 45
assert [(r['quartet'], r['condition']) for r in attempts] == planned[:45]
assert [(r['quartet'], r['condition']) for r in observed] == planned[:44]
assert len(refused) == 1 and (refused[0]['quartet'], refused[0]['condition']) == planned[44]
assert refused[0]['pulse_elapsed_ns'] == 10715100 > 9000000
for row in observed:
    release = row['release_ns']
    assert row['acknowledgment_ns'] - release <= 75_000_000
    assert 90_000_000 <= row['after']['start_ns'] - release
    assert row['after']['finish_ns'] - release < 100_000_000
    assert row['before']['creation_filetime'] == row['after']['creation_filetime']
    for metric in ('user_100ns', 'kernel_100ns', 'cycles'):
        assert row['delta'][metric] == row['after'][metric] - row['before'][metric] >= 0
assert json.loads((folder / 'process-terminal.json').read_bytes())['process_exit'] == 2
assert json.loads((folder / 'external-terminal.json').read_bytes())['exit_code'] == 1
assert json.loads((folder / 'independent-cleanup.json').read_bytes())['calibration_worker_absent'] is True
report = {
    'protocol_sha256': sha, 'outcome': 'refused', 'score': None,
    'planned_total_slots_including_warmup': len(planned),
    'event_counts': Counter(row['event'] for row in events),
    'refused_quartet': refused[0]['quartet'], 'refused_condition': refused[0]['condition'],
    'refused_pulse_elapsed_ns': refused[0]['pulse_elapsed_ns'],
    'outer_launcher_exit': 1, 'inner_calibration_exit': 2,
    'independent_worker_absence': True,
}
encoded = (json.dumps(report, sort_keys=True, indent=2) + '\n').encode()
(folder / 'independent-verification.json').write_bytes(encoded)
print(encoded.decode(), end='')

