from hashlib import sha256
import json
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent
attempt = root / 'attempt-001'
protocol_data = (root / 'protocol.json').read_bytes()
spec = json.loads(protocol_data)
digest = sha256(protocol_data).hexdigest()
assert digest == 'dd5879f430d42593478adb68485026d8193fd9cc161ed453471f32da34ca7f35'
launch = json.loads((attempt / 'launch.json').read_bytes())
assert launch['whole_tree_seconds'] == 60 and launch['protocol_sha256'] == digest
assert launch['instrument_sha256'] == sha256((root / 'calibration.py').read_bytes()).hexdigest()
events = [json.loads(line) for line in (attempt / 'journal.jsonl').read_bytes().splitlines()]
assert events[0]['event'] == 'started' and events[0]['protocol_sha256'] == digest
assert events[1] == {'event': 'schedule', 'warmup': spec['warmup_excluded'],
                     'measured': spec['measured_quartets']}
assert events[2]['event'] == 'worker_ready'
assert events[2]['ready_ns'] - events[2]['startup_ns'] <= 500_000_000
planned = [(i, name) for i, quartet in enumerate(
    [spec['warmup_excluded'], *spec['measured_quartets']]) for name in quartet]
assert len(planned) == 52 and len(events) == 3 + 104 + 1
observed = []
previous_end = 0
creation_times = set()
for index, (quartet, condition) in enumerate(planned):
    begun, row = events[3 + 2*index:5 + 2*index]
    assert begun == {'event': 'trial_attempt', 'quartet': quartet,
                     'condition': condition, 'warmup': quartet == 0}
    assert row['event'] == 'trial_observed'
    assert all(row[key] == begun[key] for key in ('quartet', 'condition', 'warmup'))
    assert row['work_count'] == spec['worker_work_counts'][condition]
    assert row['checksum'] == spec['worker_expected_checksums'][condition]
    release = row['release_ns']
    before, after = row['before'], row['after']
    assert previous_end <= before['start_ns'] <= before['finish_ns'] <= release
    assert 0 <= row['acknowledgment_ns'] - release <= 75_000_000
    assert release + 90_000_000 <= after['start_ns'] <= after['finish_ns'] < release + 100_000_000
    previous_end = release + 100_000_000
    creation_times.update((before['creation_filetime'], after['creation_filetime']))
    deltas = {metric: after[metric] - before[metric] for metric in ('user_100ns', 'kernel_100ns', 'cycles')}
    assert all(value >= 0 for value in deltas.values())
    assert row['delta'] == dict(deltas, process_time_100ns=deltas['user_100ns'] + deltas['kernel_100ns'])
    if quartet:
        observed.append(row)
assert len(creation_times) == 1 and len(observed) == 48
terminal = events[-1]
assert terminal['event'] == 'terminal'
teardown = terminal['teardown']
assert teardown['exit_code'] == 0
assert previous_end <= teardown['start_ns'] <= teardown['acknowledgment_ns'] <= teardown['finish_ns']
assert teardown['finish_ns'] - teardown['start_ns'] <= 500_000_000
recomputed = {}
for metric in ('cycles', 'process_time_100ns'):
    outcomes = []
    for quartet in range(1, 13):
        values = {row['condition']: row['delta'][metric] for row in observed if row['quartet'] == quartet}
        idle = abs(values['idle_a'] - values['idle_b'])
        margin = max(1, 2 * idle)
        short = values['short'] - max(values['idle_a'], values['idle_b'])
        long = values['long'] - values['short']
        outcomes.append(short > margin and long > margin)
    recomputed[metric] = sum(outcomes)
assert recomputed == terminal['pass_counts'] == {'cycles': 12, 'process_time_100ns': 0}
assert terminal['outcome'] == 'screen_passed'
assert json.loads((attempt / 'process-terminal.json').read_bytes())['process_exit'] == 0
assert json.loads((attempt / 'external-terminal.json').read_bytes())['exit_code'] == 0
assert json.loads((attempt / 'independent-cleanup.json').read_bytes())['calibration_worker_absent'] is True
by_condition = {}
for condition in spec['worker_work_counts']:
    rows = [row for row in observed if row['condition'] == condition]
    assert len(rows) == 12
    by_condition[condition] = {
        'work_count': spec['worker_work_counts'][condition],
        'median_cycles': statistics.median(row['delta']['cycles'] for row in rows),
        'zero_process_time_count': sum(row['delta']['process_time_100ns'] == 0 for row in rows),
        'maximum_work_elapsed_ns': max(row['work_elapsed_ns'] for row in rows),
    }
report = {
    'protocol_sha256': digest, 'outcome': 'screen_passed',
    'planned_measured_quartets': 12, 'observed_measured_rows': len(observed),
    'pass_counts': recomputed, 'by_condition': by_condition,
    'independent_worker_absence': True,
}
encoded = (json.dumps(report, sort_keys=True, indent=2) + '\n').encode()
(attempt / 'independent-verification.json').write_bytes(encoded)
print(encoded.decode(), end='')

