# CPU counter calibration and replay

The 1,940-slot campaign and its CPU audit remain separate. The CPU audit
replayed on Linux ARM64 and physical macOS ARM64 through Tailscale. Both
results matched the Windows audit exactly after line-ending normalization.
The replay hashes, raw logs and independent cleanup are included.

The first Windows calibration used elapsed QPC pulses. A preflight refused
the Windows Store interpreter alias before capture. The qualified
interpreter was then pinned explicitly. The single capture refused a
10.7151 ms long pulse outside the preregistered 8-9 ms window. The
journal has 44 completed observations, including the four warmups, and
the refused trial. No score was computed or data reused.

The second Windows calibration used a separate preregistration and
prespecified fixed work. Two independent reviewers approved each protocol before its capture. The
second run completed 12 measured quartets, with checksum and bounded
held-handle timing verification on every row. Raw process cycles passed
the discrimination screen in 12 of 12 quartets. GetProcessTimes passed
zero. The verifier independently recomputed the score and both runs have
a separate worker-absence receipt.

Both captures ran inside a 60-second Windows Job deadline. The work
doses establish a synthetic raw-counter distinction for this host.
There is no conversion from cycles to elapsed time or CPU duration. The
original benchmark continues to use its archived process-time readings.

For offline replay, copy the receipt folder to attempt-002 beside
elapsed-pulse/verify-refusal.py and to attempt-001 beside
fixed-work/verify.py in their respective directories. Run the two
verifiers with ordinary Python under a finite whole-tree deadline.
Neither verifier launches a workload.
