import hashlib,json
from pathlib import Path
here=Path(__file__).resolve().parent
folder=here/'issue7-native-bulk-decoder-capture-001'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(folder/'native-001.jsonl').read_bytes()
assert sha(raw)=='f8b994e399d98128844991c3f36e64c94927cfb369c099b84f848f1dc025bbf5'
seal_raw=(folder/'native-seal.json').read_bytes()
assert sha(seal_raw)=='986950d2d85c1a93fe7eae922fdfe0d752cb5f0a7b67067cff95bb6c9dfcba25'
seal=json.loads(seal_raw)
for n,h in seal['source_sha256'].items():assert sha((folder/n).read_bytes())==h,n
for p,h in seal['tool_sha256'].items():assert sha(Path(p).read_bytes())==h,p
rows=[json.loads(x)for x in raw.splitlines()]
observed=[x for x in rows if x['kind']=='snapshot_observed']
snapshots=[x for x in rows if x['kind']=='snapshot']
assert len(observed)==len(snapshots)==1
obs,snapshot,terminal=observed[0],snapshots[0],rows[-1]
assert terminal['kind']=='terminal'and terminal['code']==0 and terminal['qualified']is True
assert terminal['baseline_handles']==terminal['final_handles']==165
assert terminal['observed_ns']<terminal['deadline_ns']
assert terminal['native_capture_attempts']==terminal['native_observation_count']==1
assert terminal['controller_identity_validated']is True
assert not terminal['cleanup_errors']and not terminal['reporting_failures']
assert terminal['primary_failure']is None and terminal['module_cleanup_failure']is None
for k in ('census_qualified','phase_qualified','campaign_qualified','benchmark_slots'):assert not terminal[k]
e=obs['evidence'];h=e['native']
assert h['count']==len(obs['rows'])==len(e['raw_utf16_rows'])==503
assert h['bytes']==120 and h['capacity']==4096 and h['name_units']==260
assert h['status']==h['primary_error']==h['close_error']==h['clock_error']==h['reserved']==0
chain=[h[k]for k in ('begin_qpc','snapshot_upper_begin_qpc','snapshot_upper_end_qpc','enumerate_begin_qpc','enumerate_end_qpc','close_begin_qpc','close_end_qpc','end_qpc')]
assert min(chain)>0 and chain==sorted(chain)
assert e['begin_ns']<=e['native_begin_ns']<=e['native_end_ns']<=e['end_ns']
pids=set()
for decoded,wire in zip(obs['rows'],e['raw_utf16_rows']):
 assert decoded['pid']==wire['pid']and decoded['parent_pid']==wire['parent_pid']
 assert decoded['pid']not in pids;pids.add(decoded['pid'])
 prefix=bytes.fromhex(wire['name_utf16le_hex']);assert len(prefix)==wire['name_units']*2 and 1<=wire['name_units']<260
 name=prefix.decode('utf-16le','surrogatepass');assert chr(0)not in name and name.casefold()==decoded['name']
assert snapshot['observer_pid']in pids and snapshot['guard_pid']in pids
assert 0<snapshot['observer_created_ticks']<=obs['upper_ticks']==h['upper_ticks']
assert 0<snapshot['guard_created_ticks']<=obs['upper_ticks']
assert snapshot['held_observer_alive']and snapshot['held_guard_alive']
assert (folder/'native-001.stderr.log').read_bytes()==b''
result={'schema':1,'audit':'ROOT_LOSSLESS_RAW_COMPONENT_AUDIT_PASSED','native_rows':503,'source_bindings':49,'tool_bindings':4,'native_raw_sha256':sha(raw),'source_seal_sha256':sha(seal_raw),'snapshot_ns':e['end_ns']-e['begin_ns'],'precall_ns':e['native_begin_ns']-e['begin_ns'],'native_ns':e['native_end_ns']-e['native_begin_ns'],'postnative_ns':e['end_ns']-e['native_end_ns'],'handles':[165,165],'benchmark_slots':0,'scope':'One actual native component. Raw exact integers, prefix bytes/decoding, anchor timing, native errors/QPC, refs and cleanup/deadline checked; no fresh native API, full census or guard-comparison proof.'}
with (folder/'root-audit-001.json').open('x',encoding='utf-8')as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps(result,indent=2))
