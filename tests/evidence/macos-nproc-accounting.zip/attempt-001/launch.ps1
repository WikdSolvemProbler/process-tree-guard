param([Parameter(Mandatory=$true)][ValidateSet('linux','macos')][string]$Platform)
$ErrorActionPreference='Stop'
$directory=$PSScriptRoot
$command=[IO.File]::ReadAllText("$directory/$Platform-command.txt")
$info=[Diagnostics.ProcessStartInfo]::new()
$info.FileName='C:/Windows/System32/OpenSSH/ssh.exe'
$info.UseShellExecute=$false
$info.CreateNoWindow=$true
$info.RedirectStandardInput=$true
$info.RedirectStandardOutput=$true
$info.RedirectStandardError=$true
foreach($argument in '-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8','peters-mac-mini',$command){
    $info.ArgumentList.Add($argument)
}
$out=[IO.File]::Open("$directory/$Platform.stdout.log",'CreateNew','Write','Read')
$err=[IO.File]::Open("$directory/$Platform.stderr.log",'CreateNew','Write','Read')
$inputFile=[IO.File]::OpenRead("$directory/payload.tar.gz")
try {
    $process=[Diagnostics.Process]::Start($info)
    $copyOut=$process.StandardOutput.BaseStream.CopyToAsync($out)
    $copyErr=$process.StandardError.BaseStream.CopyToAsync($err)
    $transferError=$null
    try { $inputFile.CopyTo($process.StandardInput.BaseStream) } catch { $transferError=$_ }
    finally { $process.StandardInput.Close() }
    $process.WaitForExit()
    $copyOut.GetAwaiter().GetResult()
    $copyErr.GetAwaiter().GetResult()
    $result=$process.ExitCode
    [IO.File]::WriteAllText("$directory/$Platform.ssh-exit.txt",[string]$result)
    if($null -ne $transferError){ throw $transferError }
} finally {
    $inputFile.Dispose(); $out.Dispose(); $err.Dispose()
}
Get-Content "$directory/$Platform.stderr.log" -Tail 16
exit $result
