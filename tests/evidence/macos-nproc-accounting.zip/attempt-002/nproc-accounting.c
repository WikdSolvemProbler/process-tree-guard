/* Ordinary-user check of native fork admission with one retained child. */
#include <errno.h>
#include <signal.h>
#include <spawn.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/sysctl.h>
#include <sys/wait.h>
#include <unistd.h>

static struct rlimit original;

static int set_ceiling(rlim_t ceiling)
{
    struct rlimit limit = original;
    limit.rlim_cur = ceiling;
    return setrlimit(RLIMIT_NPROC, &limit) == 0 ? 0 : errno;
}

static int reap(pid_t pid)
{
    int status;
    pid_t result;
    do {
        result = waitpid(pid, &status, 0);
    } while (result < 0 && errno == EINTR);
    if (result != pid)
        return result < 0 ? errno : ECHILD;
    return WIFEXITED(status) && WEXITSTATUS(status) == 0 ? 0 : EIO;
}

static int probe(rlim_t ceiling, bool spawn)
{
    int rc = set_ceiling(ceiling);
    if (rc != 0)
        return rc;
    pid_t pid;
    if (spawn) {
        char *const argv[] = {"true", NULL};
        char *const envp[] = {NULL};
        rc = posix_spawn(&pid, "/usr/bin/true", NULL, NULL, argv, envp);
        if (rc != 0)
            return rc;
    } else {
        pid = fork();
        if (pid < 0)
            return errno;
        if (pid == 0)
            _exit(0);
    }
    return reap(pid);
}

static rlim_t boundary(void)
{
    rlim_t low = 1;
    rlim_t high = original.rlim_cur > 512 ? 512 : original.rlim_cur;
    if (high < 2 || probe(high, false) != 0)
        return 0;
    while (low < high) {
        rlim_t mid = low + (high - low) / 2;
        int rc = probe(mid, false);
        if (rc == 0)
            high = mid;
        else if (rc == EAGAIN)
            low = mid + 1;
        else
            return 0;
    }
    return low;
}

static int retained_exit(pid_t pid)
{
    siginfo_t info = {0};
    int rc;
    do {
        rc = waitid(P_PID, (id_t)pid, &info, WEXITED | WNOWAIT);
    } while (rc < 0 && errno == EINTR);
    if (rc < 0)
        return errno;
    return info.si_pid == pid && info.si_code == CLD_EXITED
        && info.si_status == 0 ? 0 : EIO;
}

static bool trial(unsigned index)
{
    rlim_t limit = boundary();
    if (limit < 2 || limit >= original.rlim_cur || limit >= 512) {
        printf("trial=%u calibration_refused boundary=%llu\n",
               index, (unsigned long long)limit);
        return false;
    }
    int low_a = probe(limit - 1, false);
    int fork_a = probe(limit, false);
    int spawn_a = probe(limit, true);

    int reset = set_ceiling(original.rlim_cur);
    if (reset != 0) {
        printf("trial=%u reserve_ceiling_reset_errno=%d\n", index, reset);
        return false;
    }
    pid_t reserve = fork();
    if (reserve == 0)
        _exit(0);
    if (reserve < 0) {
        printf("trial=%u reserve_fork_errno=%d\n", index, errno);
        return false;
    }
    int owned = retained_exit(reserve);
    int fork_b = owned == 0 ? probe(limit, false) : -1;
    int spawn_b = owned == 0 ? probe(limit, true) : -1;
    int fork_above = owned == 0 ? probe(limit + 1, false) : -1;
    int spawn_above = owned == 0 ? probe(limit + 1, true) : -1;
    int still_owned = retained_exit(reserve);
    int reaped = reap(reserve);

    int low_c = probe(limit - 1, false);
    int fork_c = probe(limit, false);
    int spawn_c = probe(limit, true);
    bool pass = low_a == EAGAIN && fork_a == 0 && spawn_a == 0
        && owned == 0 && fork_b == EAGAIN && spawn_b == EAGAIN
        && fork_above == 0 && spawn_above == 0 && still_owned == 0
        && reaped == 0 && low_c == EAGAIN && fork_c == 0 && spawn_c == 0;
    printf("trial=%u boundary=%llu reserve_pid=%d "
           "before_low=%d before_fork=%d before_spawn=%d "
           "retained=%d held_fork=%d held_spawn=%d held_above_fork=%d "
           "held_above_spawn=%d still_retained=%d reaped=%d "
           "after_low=%d after_fork=%d after_spawn=%d pass=%d\n",
           index, (unsigned long long)limit, reserve, low_a, fork_a,
           spawn_a, owned, fork_b, spawn_b, fork_above, spawn_above,
           still_owned, reaped, low_c, fork_c, spawn_c, pass);
    return pass;
}

int main(void)
{
    enum { TRIALS = 8 };
    setvbuf(stdout, NULL, _IOLBF, 0);
    struct sigaction children = {0};
    children.sa_handler = SIG_DFL;
    sigemptyset(&children.sa_mask);
    if (getuid() == 0 || geteuid() != getuid()
        || sigaction(SIGCHLD, &children, NULL) != 0
        || getrlimit(RLIMIT_NPROC, &original) != 0)
        return 125;
    int uid_cap = 0;
    size_t cap_size = sizeof(uid_cap);
    if (sysctlbyname("kern.maxprocperuid", &uid_cap, &cap_size, NULL, 0) != 0
        || cap_size != sizeof(uid_cap) || uid_cap < 2) {
        printf("uid_cap_read_refused errno=%d\n", errno);
        return 125;
    }
    struct rlimit inherited = original;
    if (original.rlim_max > (rlim_t)uid_cap)
        original.rlim_max = (rlim_t)uid_cap;
    if (original.rlim_cur > original.rlim_max)
        original.rlim_cur = original.rlim_max;
    struct rlimit effective;
    if (setrlimit(RLIMIT_NPROC, &original) != 0
        || getrlimit(RLIMIT_NPROC, &effective) != 0
        || effective.rlim_cur != original.rlim_cur
        || effective.rlim_max != original.rlim_max) {
        printf("process_local_ceiling_setup_refused errno=%d\n", errno);
        return 125;
    }
    printf("inherited_soft=%llu inherited_hard=%llu uid_cap=%d\n",
           (unsigned long long)inherited.rlim_cur,
           (unsigned long long)inherited.rlim_max, uid_cap);
    printf("uid=%u pid=%d pgid=%d eagain=%d soft=%llu hard=%llu\n",
           getuid(), getpid(), getpgrp(), EAGAIN,
           (unsigned long long)original.rlim_cur,
           (unsigned long long)original.rlim_max);
    unsigned passes = 0;
    for (unsigned i = 1; i <= TRIALS; ++i)
        if (trial(i))
            ++passes;
    int restored = set_ceiling(original.rlim_cur) == 0;
    errno = 0;
    int no_child = waitpid(-1, NULL, WNOHANG) == -1 && errno == ECHILD;
    printf("trials=%d passed=%u no_owned_children=%d restored=%d\n", TRIALS, passes, no_child, restored);
    return passes == TRIALS && no_child && restored ? 0 : 1;
}
