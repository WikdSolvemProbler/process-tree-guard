"""ONE reviewed owned-event component attempt. No competitor/workload/session.
This file is prepared only; absent reviewed plan and exact SHA refuse execution.
"""
import time
ENTRY_NS = time.perf_counter_ns()
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import types
import weakref

HERE = Path(__file__).resolve().parent
PROTECT = 2
REPARSE = 0x400
CASES = ("junction",)

def sha(raw): return hashlib.sha256(raw).hexdigest()
def demand(value, message):
    if not value: raise ValueError(message)
def error_record(error):
    return {"type": type(error).__name__, "message": str(error),
            "winerror": getattr(error, "winerror", None), "errno": getattr(error, "errno", None)}
def captured_module(name, path, raw):
    module = types.ModuleType(name); module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module

def main(approved):
    deadline = ENTRY_NS + 35_000_000_000
    plan_raw = (HERE / "plan.json").read_bytes()
    demand(sha(plan_raw) == approved, "unapproved plan bytes")
    plan = json.loads(plan_raw)
    demand(plan.get("reviewed") is True and plan["inner_seconds"] == 35
           and plan["outer_seconds"] == 45 and plan["cases"] == list(CASES), "plan scope differs")
    demand(os.name == "nt", "Windows native component only")
    capture = Path(plan["capture"])
    demand(capture == HERE / "attempt-001" and not capture.exists(), "capture must be fresh fixed attempt")
    source_bytes = {}
    def bindings():
        demand(sha((HERE / "plan.json").read_bytes()) == approved, "plan changed")
        for path, pin in plan["source_sha256"].items():
            raw = Path(path).read_bytes()
            demand(sha(raw) == pin, "source pin differs: " + path)
            if Path(path) not in source_bytes: source_bytes[Path(path)] = raw
        for path, pin in plan["tool_sha256"].items():
            demand(sha(Path(path).read_bytes()) == pin, "tool pin differs: " + path)
    bindings()
    prerequisite = json.loads(source_bytes[Path(plan["pure_receipt"])])
    demand(prerequisite.get("qualified") is True and prerequisite.get("code") == 0
           and prerequisite.get("facts") == {"tests":24,"failures":0,"errors":0,"skipped":0}
           and prerequisite.get("errors") == [] and prerequisite.get("session_approved") is False,
           "actual PURE24 prerequisite not qualified")
    demand(sha(source_bytes[Path(plan["pure_log"])]) == prerequisite["log_sha256"]
           and type(prerequisite.get("observed_ns")) is int and type(prerequisite.get("deadline_ns")) is int
           and prerequisite["observed_ns"] < prerequisite["deadline_ns"], "PURE24 raw/deadline differs")
    capture.mkdir()
    fixtures = capture / "fixtures"; fixtures.mkdir()
    log_path = capture / "native.jsonl"
    log = log_path.open("x", encoding="utf-8")
    def emit(kind, **facts):
        log.write(json.dumps({"kind": kind, **facts}, ensure_ascii=True, allow_nan=False) + "\n"); log.flush()
    def check_time(): demand(time.perf_counter_ns() < deadline, "35s checked deadline expired")
    host = Path(plan["host_directory"])
    common = captured_module("owned_event_common", host / "common.py", source_bytes[host / "common.py"])
    worker = captured_module("owned_event_worker", host / "worker.py", source_bytes[host / "worker.py"])
    session = captured_module("owned_event_session", host / "session.py", source_bytes[host / "session.py"])
    event_mod = captured_module("owned_event_adapter", host / "owned_events.py", source_bytes[host / "owned_events.py"])
    api_path = Path(plan["native_api"])
    native = captured_module("owned_event_native", api_path, source_bytes[api_path])
    # Initialize all bindings before the handle-count baseline. No test process,
    # observer, worker.main, session.main or private DLL is loaded by these modules.
    set_handle = native.bind("SetHandleInformation", [native.w.HANDLE, native.w.DWORD, native.w.DWORD], native.w.BOOL)
    get_handle = native.bind("GetHandleInformation", [native.w.HANDLE, ctypes.POINTER(native.w.DWORD)], native.w.BOOL)
    get_count = native.bind("GetProcessHandleCount", [native.w.HANDLE, ctypes.POINTER(native.w.DWORD)], native.w.BOOL)
    get_type = native.bind("GetFileType", [native.w.HANDLE], native.w.DWORD)
    module_name = native.bind("GetModuleFileNameW", [native.w.HMODULE, native.w.LPWSTR, native.w.DWORD], native.w.DWORD)
    module_path = ctypes.create_unicode_buffer(32768); ctypes.set_last_error(0)
    module_count = module_name(native.kernel._handle, module_path, len(module_path)); module_error = ctypes.get_last_error()
    emit("native_binding_call", api="GetModuleFileNameW", module_handle=int(native.kernel._handle),
         result=int(module_count), error=module_error, path=module_path.value)
    demand(0 < module_count < len(module_path) and Path(module_path.value) == Path(plan["kernel32"]),
           "loaded kernel32 identity path differs")
    demand(sha(Path(module_path.value).read_bytes()) == plan["tool_sha256"][plan["kernel32"]],
           "loaded kernel32 file bytes differ")
    current = ctypes.c_void_p(-1).value
    def count():
        value = native.w.DWORD(); ctypes.set_last_error(0)
        result = get_count(current, ctypes.byref(value)); last = ctypes.get_last_error()
        emit("native_control_call", api="GetProcessHandleCount", result=int(result), error=last, count=value.value)
        demand(bool(result), "GetProcessHandleCount failed")
        return value.value
    baseline = count()
    baseline_modules = set(sys.modules)
    weak_owners = []
    def note_owner(label, value):
        weak_owners.append((label, weakref.ref(value)))
        emit("diagnostic_owner", label=label, python_id=id(value), type=type(value).__name__,
             closed=getattr(value, "closed", None),
             process_handle=None if not hasattr(value, "_handle") else int(value._handle))
    def owner_states():
        facts = []
        for label, reference in weak_owners:
            value = reference()
            facts.append({"label": label, "alive": value is not None,
                "closed": None if value is None else getattr(value, "closed", None),
                "returncode": None if value is None else getattr(value, "returncode", None),
                "process_handle_closed": None if value is None or not hasattr(value, "_handle")
                    else getattr(value._handle, "closed", None)})
        return facts
    def checkpoint(label):
        # owner_states returns only plain facts; its temporary strong references
        # are gone BEFORE the native count. Weakrefs never keep an owner alive.
        owners = owner_states()
        observed = count()
        emit("diagnostic_checkpoint", label=label, handles=observed, owners=owners,
             newly_imported_modules=sorted(set(sys.modules) - baseline_modules),
             observed_ns=time.perf_counter_ns())
        return observed
    results = []; failures = []; helper_process_attempts = 0; helper_quarantine = []
    emit("context", approved_plan_sha256=approved, source_sha256=plan["source_sha256"],
         tool_sha256=plan["tool_sha256"], pid=os.getpid(), origin_ns=ENTRY_NS, deadline_ns=deadline,
         handles_after_binding_init=baseline, scope="owned event/retention controls only; no comparative slots")

    class TracedAPI:
        def __init__(self, case, mutation=None, protect=None):
            self.case = case; self.calls = []; self.owned = {}; self.mutation = mutation
            self.protect = protect; self.mutated = False; self.protected = []
            self.reads = 0; self.cleanup = []; self.metadata_after_mutation = None
            for key in ("ctypes", "w", "BasicInfo", "StandardInfo", "IdInfo", "CHUNK", "FILE_READ_ATTRIBUTES",
                        "GENERIC_READ", "OPEN_EXISTING", "INVALID_HANDLE_VALUE", "checked"):
                setattr(self, key, getattr(native, key))
        def call(self, name, fn, args, details):
            ctypes.set_last_error(0)
            result = fn(*args); last = ctypes.get_last_error()
            row = {"api": name, "case": self.case, "result": None if result is None else int(result),
                   "error": last, "observed_ns": time.perf_counter_ns(), **details}
            if name == "ReadFile":
                row["read_count"] = ctypes.cast(args[3], ctypes.POINTER(native.w.DWORD)).contents.value
                self.reads += 1
            self.calls.append(row); emit("native_call", **row)
            ctypes.set_last_error(last)
            return result
        def bind(self, name, args, result):
            demand(name == "GetFileType", "unexpected adapter late binding")
            return lambda handle: self.call(name, get_type, (handle,), {"handle": int(handle)})
        def create_file(self, *args):
            result = self.call("CreateFileW", native.create_file, args,
                {"path": str(args[0]), "access": int(args[1]), "share": int(args[2]), "flags": int(args[5])})
            if result and result != native.INVALID_HANDLE_VALUE:
                handle = int(result); self.owned[handle] = str(args[0])
                if self.protect is not None and Path(args[0]) == self.protect:
                    # This exact handle was just opened for this own regular file.
                    changed = self.call("SetHandleInformation", set_handle, (handle, PROTECT, PROTECT), {"handle": handle, "mask": PROTECT, "flags": PROTECT})
                    demand(bool(changed), "could not protect exact owned file handle")
                    flags = native.w.DWORD()
                    confirmed = self.call("GetHandleInformation", get_handle, (handle, ctypes.byref(flags)), {"handle": handle})
                    demand(bool(confirmed) and flags.value & PROTECT, "own protection readback absent")
                    self.protected.append(handle)
            if int(args[5]) & 0x02000000:
                demand(int(args[1]) == native.FILE_READ_ATTRIBUTES | 1 and int(args[2]) == 3,
                       "actual directory CreateFileW lacks data access/no-DELETE share")
            return result
        def file_info(self, *args):
            return self.call("GetFileInformationByHandleEx", native.file_info, args, {"handle": int(args[0]), "class": int(args[1]), "bytes": int(args[3])})
        def read_file(self, *args):
            result = self.call("ReadFile", native.read_file, args, {"handle": int(args[0]), "requested": int(args[2])})
            count_read = ctypes.cast(args[3], ctypes.POINTER(native.w.DWORD)).contents.value
            if result and count_read and self.mutation is not None and not self.mutated:
                self.mutated = True
                before = self.mutation.stat().st_size
                with self.mutation.open("ab") as out:
                    demand(out.write(b"!") == 1, "controlled append short"); out.flush(); os.fsync(out.fileno())
                metadata = self.metadata_after_mutation(int(args[0]))
                emit("controlled_file_append", case=self.case, after_real_ReadFile=True,
                     path=str(self.mutation), before_size=before, after_size=self.mutation.stat().st_size,
                     held_native_metadata_after=metadata, bytes=1)
            return result
        def close_handle(self, handle):
            result = self.call("CloseHandle", native.close_handle, (handle,), {"handle": int(handle), "production_adapter": True})
            if result: self.owned.pop(int(handle), None)
            return result
        def recover_owned(self):
            # No discovery/PID lookup. Only actual CreateFileW handles retained
            # above may be cleared/closed. On failure ownership remains explicit.
            for handle, path in list(self.owned.items()):
                row = {"handle": handle, "path": path}; self.cleanup.append(row)
                try:
                    flags = native.w.DWORD()
                    got = self.call("GetHandleInformation", get_handle, (handle, ctypes.byref(flags)), {"handle": handle, "recovery": True})
                    demand(bool(got), "retained exact handle state unreadable; quarantine")
                    row["flags_before"] = flags.value
                    if flags.value & PROTECT:
                        demand(handle in self.protected, "unexpected protected owner; quarantine")
                        cleared = self.call("SetHandleInformation", set_handle, (handle, PROTECT, 0), {"handle": handle, "mask": PROTECT, "flags": 0, "recovery": True})
                        demand(bool(cleared), "retained protection could not clear")
                    closed = self.call("CloseHandle", native.close_handle, (handle,), {"handle": handle, "recovery": True})
                    demand(bool(closed), "retained own handle close failed")
                    self.owned.pop(handle); row["closed"] = True
                except BaseException as error: row["error"] = error_record(error)

    def write(path, data):
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as out: demand(out.write(data) == len(data), "fixture write short")
        emit("fixture_file", path=str(path), bytes=len(data), sha256=sha(data))
    def good_bytes():
        return common.encode({"schema_version": 1, "event": "run_started", "pid": os.getpid()}) + b"\n" + common.encode({"schema_version": 1, "event": "runner_exit", "code": 0}) + b"\n"
    def observed_record():
        return {"outcome": "ok", "exit_code": 0, "arm_pid": os.getpid(), "elapsed_ms": 1,
                "slot_job": {"active_after": 0}, "output_stdout_sha256": common.sha(b"ok"),
                "output_stdout_len": 2, "output_stdout_match": True,
                "output_stderr_sha256": common.sha(b""), "output_stderr_len": 0, "output_stderr_match": True}
    def verify_bundle(case_dir, acquired):
        artifacts = case_dir / "retained"; artifacts.mkdir()
        def store(name, data): write(artifacts / name, data)
        bundle = worker.retain_event_bundle(acquired, store, common)
        write(artifacts / "stdout.bin", b"ok"); write(artifacts / "stderr.bin", b"")
        record = observed_record()
        def read(name):
            with (artifacts / name).open("rb") as inp: return inp.read(common.MAX_BYTES + 1)
        verified, event_bad = session.verify_retained_outputs(common, "processkit", record,
            {"expected_stdout": "ok", "expected_stderr": ""}, bundle, read)
        # These synthetic record fields exercise only the actual pure classifier;
        # they are not native Job/arm/presentation receipts or comparative slots.
        value = {"record": record, "launches": [{"argv": ["component-fixture"]}], "failures": [],
                 "capture_errors": [], "jobs": [{"closed": True, "drain": {"active_after": 0}}]}
        classified = session.disposition(value, 0, False, presentation_verified=True,
            output_verified=verified, retained_event_contract_failed=event_bad)
        return {"bundle": bundle, "output_verified": verified, "event_contract_failed": event_bad,
                "pure_classifier_only": classified}
    def refusal(action, text=None):
        try: action()
        except (ValueError, OSError) as error:
            if text is not None: demand(text in str(error), "unexpected refusal: " + str(error))
            return error_record(error)
        raise ValueError("expected actual acquisition refusal did not occur")
    def safe_inside(path):
        demand(path.is_absolute() and path.parent.resolve().is_relative_to(fixtures.resolve()), "fixture path escapes fresh root")
        return path

    def run_case(name):
        nonlocal helper_process_attempts
        check_time()
        directory = fixtures / name; directory.mkdir()
        namespace = directory / "processkit-events"; namespace.mkdir()
        api = TracedAPI(name)
        reader = event_mod.NativeEvents(api)
        result = {"case": name, "begin_ns": time.perf_counter_ns(), "qualified": False}
        before_handles = count()
        try:
            good = good_bytes()
            if name == "missing_empty": pass
            elif name == "ambiguous_two":
                write(namespace / "slot-a" / "events.jsonl", good)
                write(namespace / "slot-b" / "events.jsonl", good)
            elif name == "wrong_type":
                (namespace / "slot-a" / "events.jsonl").mkdir(parents=True)
            elif name == "extra_entry":
                write(namespace / "slot-a" / "events.jsonl", good)
                write(namespace / "slot-a" / "unexpected.txt", b"owned extra")
            elif name == "junction":
                target = safe_inside(directory / "junction-target"); target.mkdir()
                write(target / "events.jsonl", good)
                link = safe_inside(namespace / "slot-junction")
                demand(not os.path.lexists(link), "junction leaf already exists")
                helper_dir = directory / "helper"; helper_dir.mkdir()
                command = [plan["guard"], "--timeout", "5", "--", plan["cmd"], "/d", "/c", "mklink", "/J", str(link), str(target)]
                emit("helper_prepare", command=command, direct_processes_planned=1, nested_cmd_planned=1,
                     timeout_seconds=5, caller_wait_seconds=7, no_admin=True)
                proc = None
                checkpoint("before_helper_stdio_open")
                with (helper_dir / "stdout.bin").open("xb") as stdout, (helper_dir / "stderr.bin").open("xb") as stderr:
                    note_owner("helper_stdout_buffer", stdout); note_owner("helper_stderr_buffer", stderr)
                    checkpoint("after_helper_stdio_open")
                    helper_process_attempts += 1
                    try:
                        proc = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
                        note_owner("helper_Popen", proc)
                        result["helper_pid"] = proc.pid
                        checkpoint("after_Popen")
                        result["helper_exit"] = proc.wait(timeout=7)
                        checkpoint("after_helper_wait")
                    finally:
                        if proc is not None:
                            if proc.poll() is None:
                                emit("helper_wait_failed", pid=proc.pid, exact_owned_process_handle=True)
                                proc.kill()
                                try: proc.wait(timeout=2)
                                except subprocess.TimeoutExpired: pass
                            # CPython3.12 pinned Windows process handle only.
                            if proc.poll() is not None:
                                proc._handle.Close(); result["helper_held_process_handle_closed"] = True
                                checkpoint("after_explicit_process_handle_close")
                            else:
                                helper_quarantine.append(proc)
                                result["helper_process_quarantined"] = {"pid": proc.pid, "held_handle": int(proc._handle)}
                checkpoint("after_helper_stdio_context_exit")
                for output in (helper_dir / "stdout.bin", helper_dir / "stderr.bin"):
                    checkpoint("before_read_" + output.name)
                    with output.open("rb") as inp:
                        note_owner("helper_read_buffer_" + output.name, inp)
                        checkpoint("after_open_read_" + output.name)
                        raw = inp.read(common.MAX_BYTES + 1)
                        checkpoint("after_bytes_read_" + output.name)
                    checkpoint("after_close_read_" + output.name)
                    demand(len(raw) <= common.MAX_BYTES, "helper output overflow")
                    result[output.name + "_sha256"] = sha(raw)
                demand(result.get("helper_exit") == 0, "mklink unavailable/refused; no fallback or retry")
                checkpoint("before_junction_lstat")
                junction_state = os.lstat(link)
                checkpoint("after_junction_lstat")
                demand(junction_state.st_file_attributes & REPARSE and link.parent.resolve().is_relative_to(fixtures.resolve()), "helper did not produce exact own junction")
                checkpoint("before_junction_readlink")
                target_text = os.readlink(link)
                checkpoint("after_junction_readlink")
                demand(target_text in (str(target), "\\\\?\\" + str(target)), "junction target is not exact own target")
                result["junction_before"] = {"path": str(link), "target": target_text,
                    "device": junction_state.st_dev, "inode": junction_state.st_ino, "attributes": junction_state.st_file_attributes}
                checkpoint("before_native_collect_refusal")
                result["refusal"] = refusal(lambda: reader.collect(directory, namespace, common.MAX_BYTES), "reparse/type")
                checkpoint("after_native_collect_refusal")
                demand(api.reads == 0 and any(r.get("before", {}).get("attributes", 0) & REPARSE
                                             for r in reader.evidence), "junction followed/read or no actual reparse metadata")
                # Preserve native reparse metadata and actual refusal before
                # removing only this exact junction leaf; retain all target files.
                result["native_evidence_before_leaf_removal"] = reader.evidence
                checkpoint("before_pre_removal_log_flush")
                emit("junction_pre_removal_receipt", **result)
                checkpoint("after_pre_removal_log_flush")
                current_state = os.lstat(link)
                demand((current_state.st_dev, current_state.st_ino, current_state.st_file_attributes) ==
                    (junction_state.st_dev, junction_state.st_ino, junction_state.st_file_attributes), "junction identity changed; quarantined")
                demand(os.readlink(link) == result["junction_before"]["target"], "junction target changed; quarantined")
                checkpoint("before_exact_junction_rmdir")
                os.rmdir(link)
                checkpoint("after_exact_junction_rmdir")
                demand(not os.path.lexists(link) and (target / "events.jsonl").read_bytes() == good, "junction leaf removal/retained target differs")
                result["junction_leaf_removed_only"] = True
            else:
                payload = good
                if name == "malformed_json": payload = b"not-json\n"
                if name == "duplicate_json": payload = good.replace(b'"code":0', b'"code":0,"code":0')
                if name == "overlong_json":
                    payload = common.encode({"schema_version":1,"event":"run_started","pid":os.getpid(),
                                             "padding":"x" * common.MAX_EVENT_LINE}) + b"\n" + good.splitlines(keepends=True)[-1]
                if name == "overflow": payload = b"x" * (common.MAX_BYTES + 1)
                write(namespace / "slot-a" / "events.jsonl", payload)
            target_file = namespace / "slot-a" / "events.jsonl"
            if name == "mutation_after_read":
                api.mutation = target_file; api.metadata_after_mutation = reader.info
            if name == "protected_close": api.protect = target_file
            if name in ("stable_one", "missing_empty", "ambiguous_two", "malformed_json", "duplicate_json", "overlong_json"):
                acquired = reader.collect(directory, namespace, common.MAX_BYTES)
                result["acquired"] = [{"source": p, "bytes": len(b), "sha256": sha(b)} for p, b in acquired]
                result["verification"] = verify_bundle(directory, acquired)
                bad_expected = name != "stable_one"
                demand(result["verification"]["output_verified"] is True and
                       result["verification"]["event_contract_failed"] is bad_expected, "event/bundle contract verdict differs")
                want = "observed_incorrect_completion" if bad_expected else "correct_completion"
                demand(result["verification"]["pure_classifier_only"]["category"] == want, "actual pure classifier verdict differs")
                if name == "stable_one":
                    demand(len(acquired) == 1 and acquired[0][1] == good and api.reads >= 2, "stable native bytes/EOF read differ")
                    demand(all(r.get("before") == r.get("after") and r.get("closed") is True for r in reader.evidence), "stable metadata/closure unconfirmed")
            elif name == "overflow":
                result["refusal"] = refusal(lambda: reader.collect(directory, namespace, common.MAX_BYTES), "exceeds bound or initial size")
                demand(api.reads > 0, "overflow never read")
            elif name == "mutation_after_read":
                result["refusal"] = refusal(lambda: reader.collect(directory, namespace, common.MAX_BYTES), "exceeds bound or initial size")
                demand(api.mutated and target_file.stat().st_size == len(good) + 1, "controlled real append did not occur")
            elif name == "wrong_type":
                result["refusal"] = refusal(lambda: reader.collect(directory, namespace, common.MAX_BYTES))
                demand(api.reads == 0, "wrong-type object read")
            elif name == "extra_entry":
                result["refusal"] = refusal(lambda: reader.collect(directory, namespace, common.MAX_BYTES), "bound/name differs")
            elif name == "held_directory_rename":
                folder = namespace / "slot-a"; renamed = namespace / "renamed-owned"
                with reader.opened(folder, True):
                    result["rename_refusal"] = refusal(lambda: folder.rename(renamed))
                    demand(result["rename_refusal"]["winerror"] == 32 and folder.exists() and not renamed.exists(),
                           "held directory rename did not produce actual sharing-violation refusal")
            elif name == "protected_close":
                result["refusal"] = refusal(lambda: reader.collect(directory, namespace, common.MAX_BYTES))
                demand(len(api.protected) == 1 and reader.quarantine_handles == api.protected,
                       "actual protected close did not retain exact quarantine handle")
                demand(any(r.get("closed") is False and "cleanup_error" in r for r in reader.evidence), "production close failure not observed")
                demand(any(row["api"] == "CloseHandle" and row.get("production_adapter") is True
                           and row["handle"] == api.protected[0] and not row["result"] and row["error"] == 6
                           for row in api.calls), "protected real CloseHandle error6 absent")
            result["qualified"] = True
        except BaseException as error:
            result["error"] = error_record(error)
        finally:
            # First preserve all production evidence, including leaked/protected
            # exact owners, before the test's narrowly owned recovery.
            result["adapter_evidence"] = reader.evidence
            result["production_quarantine_handles"] = list(reader.quarantine_handles)
            result["owned_handles_before_recovery"] = dict(api.owned)
            emit("case_pre_recovery", **result)
            api.recover_owned()
            result["recovery"] = api.cleanup
            result["remaining_exact_owners"] = dict(api.owned)
            result["native_read_calls"] = api.reads
            result["directory_open_requests"] = [row for row in api.calls if row["api"] == "CreateFileW"
                and row.get("flags", 0) & 0x02000000]
            if not result["directory_open_requests"] or not all(row["access"] == 129 and row["share"] == 3
                    for row in result["directory_open_requests"]):
                result["qualified"] = False; result["directory_request_error"] = True
            after_handles = count()
            result["handles_before"] = before_handles; result["handles_after"] = after_handles
            result["end_ns"] = time.perf_counter_ns()
            if api.owned or any("error" in row for row in api.cleanup) or before_handles != after_handles:
                result["qualified"] = False
                result["cleanup_qualification_error"] = "remaining exact owners/recovery error/handle-count imbalance"
            if result["end_ns"] >= deadline:
                result["qualified"] = False; result["deadline_error"] = True
            emit("case_terminal", **result)
            checkpoint("after_case_terminal_log_flush_inside_frame")
            results.append(result)
        return result["qualified"]

    try:
        for name in CASES:
            passed = run_case(name)
            checkpoint("after_natural_run_case_frame_return")
            if not passed:
                failures.append({"case": name, "message": "case failed; no automatic retry or later cases"}); break
    except BaseException as error: failures.append(error_record(error))
    finally:
        emit("cases_complete", helper_process_attempts=helper_process_attempts,
             cases_started=len(results), failures=failures,
             no_competitor_or_workload=True, native_event_component_only=True)
    # Preserve every normal file and reparse leaf as a no-follow inventory.
    # Never traverse or remove a surviving junction/unknown reparse directory.
    inventory = []
    def walk(directory):
        with os.scandir(directory) as entries:
            ordered = sorted(entries, key=lambda x: x.name)
        for entry in ordered:
            info = entry.stat(follow_symlinks=False)
            row = {"path": str(Path(entry.path).relative_to(capture)), "size": info.st_size,
                   "device": info.st_dev, "inode": info.st_ino, "attributes": getattr(info, "st_file_attributes", 0)}
            if row["attributes"] & REPARSE:
                row["reparse_quarantined"] = True
            elif stat.S_ISDIR(info.st_mode): walk(Path(entry.path)); continue
            elif stat.S_ISREG(info.st_mode): row["sha256"] = sha(Path(entry.path).read_bytes())
            else: row["nonregular_quarantined"] = True
            inventory.append(row)
    checkpoint("before_final_inventory")
    try: walk(fixtures)
    except BaseException as error: failures.append(error_record(error))
    try: bindings()
    except BaseException as error: failures.append(error_record(error))
    checkpoint("after_final_inventory_and_pins")
    final_handles = count()
    emit("terminal_native", handles_before=baseline, handles_after=final_handles,
         helper_process_attempts=helper_process_attempts, cases_started=len(results), failures=failures,
         exact_helper_quarantine=[{"pid":p.pid,"held_handle":int(p._handle)} for p in helper_quarantine],
         no_competitor_or_workload=True, native_event_component_only=True)
    log.close()
    native_log_sha256 = sha(log_path.read_bytes())
    observed = time.perf_counter_ns()
    if observed >= deadline: failures.append({"type": "TimeoutError", "message": "35s deadline after final pins/artifact hashes"})
    if final_handles != baseline: failures.append({"type": "HandleCountError", "message": "final handles differ after binding-init baseline"})
    if helper_quarantine: failures.append({"type":"QuarantineError","message":"exact helper process handle remains owned"})
    qualified = not failures and len(results) == len(CASES) and all(r["qualified"] for r in results)
    receipt = {"schema": "owned-event-native-controls-v1", "approved_plan_sha256": approved,
               "qualified": False, "diagnostic_only": True, "control_checks_satisfied": qualified,
               "code": 0 if qualified else 1, "cases": results, "failures": failures,
               "origin_ns": ENTRY_NS, "deadline_ns": deadline, "observed_ns": observed,
               "inventory": inventory, "native_log_sha256": native_log_sha256,
               "handles_after_binding_init": baseline, "handles_final": final_handles,
               "helper_process_attempts": helper_process_attempts,
               "helper_nested_cmd_expected": helper_process_attempts,
               "helper_process_count_scope": "one actual direct Popen guard attempt; one nested cmd required by pinned argv/exit; not independent OS process discovery",
               "normal_fixture_files_preserved": True, "comparative_slots": 0,
               "full13_component_qualified": False,
               "context_limit": "one junction-only lifecycle; does not repeat earlier12-case prefix or establish exact old6/2cause",
               "whole_arm_custody_qualified": False, "dispatcher_qualified": False,
               "session_approved": False, "performance_qualified": False,
               "native_call_scope": "explicit adapter/control Win32 calls instrumented; not all interpreter/OS internal calls"}
    with (capture / "receipt.json").open("x", encoding="utf-8") as out:
        json.dump(receipt, out, indent=2, allow_nan=False); out.write("\n")
    return receipt["code"]

if __name__ == "__main__":
    parser = argparse.ArgumentParser(); parser.add_argument("--approved-plan-sha", required=True)
    raise SystemExit(main(parser.parse_args().approved_plan_sha))
