"""Exact pure comparison only: real006 regression must fail; real00725pass."""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import sys
import time
import types
import unittest
HERE=Path(__file__).resolve().parent
NEGATIVE_TEST="ExceptionLifetimeControls.test_actual_opened_refusal_does_not_retain_caller_cycle"
SENTINEL="EXPECTED_REFUSAL_CALLER_RETAINED_BY_EXCEPTION_CYCLE"

def main(approved):
    origin=time.perf_counter_ns();deadline=origin+35_000_000_000
    raw=(HERE/"unit-plan.json").read_bytes()
    if hashlib.sha256(raw).hexdigest()!=approved:raise ValueError("unapproved pure plan")
    plan=json.loads(raw)
    if (plan.get("reviewed") is not True or plan["inner_seconds"]!=35 or plan["outer_seconds"]!=45
            or plan["tests"]!=25 or plan["negative_tests"]!=1 or plan["negative_test"]!=NEGATIVE_TEST):
        raise ValueError("comparison scope unapproved")
    captured={}
    def bindings():
        if hashlib.sha256((HERE/"unit-plan.json").read_bytes()).hexdigest()!=approved:
            raise ValueError("pure plan changed")
        for name,pin in plan["source_sha256"].items():
            data=(HERE/name).read_bytes()
            if hashlib.sha256(data).hexdigest()!=pin:raise ValueError("pure source differs: "+name)
            if name not in captured:captured[name]=data
        for path,pin in plan["tool_sha256"].items():
            if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=pin:raise ValueError("pure tool differs")
    bindings()
    code=0;errors=[];negative=None;positive=None;negative_expected=False
    gc_initial=gc.isenabled()
    def phase(name,event_source,only,logname):
        module=types.ModuleType(name);module.__file__=str(HERE/"test_pure.py")
        buffers=dict(captured);buffers["owned_events.py"]=event_source
        module.CAPTURED_SOURCES=buffers;sys.modules[name]=module
        exec(compile(captured["test_pure.py"],module.__file__,"exec"),module.__dict__)
        suite=(unittest.defaultTestLoader.loadTestsFromName(only,module) if only is not None
               else unittest.defaultTestLoader.loadTestsFromModule(module))
        with(HERE/logname).open("x",encoding="utf-8")as log:
            result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
        facts={"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}
        expected=(facts=={"tests":1,"failures":1,"errors":0,"skipped":0}
                  and result.failures[0][0].id()==name+"."+NEGATIVE_TEST
                  and SENTINEL in result.failures[0][1]) if only is not None else False
        if gc.isenabled()!=gc_initial:raise ValueError("test changed automaticGCstate")
        return facts,expected
    try:
        negative,negative_expected=phase("host_cycle_original006",
            captured["references/source006/owned_events.py"],NEGATIVE_TEST,"pure-negative-001.log")
        if not negative_expected:code=1;errors.append({"type":"NegativeControlError","message":"original006didnotproduceexactexpectedweakownerfailure"})
        positive,_=phase("host_cycle_repaired007",captured["owned_events.py"],None,"pure-positive-001.log")
        if positive!={"tests":25,"failures":0,"errors":0,"skipped":0}:code=1
    except BaseException as error:
        code=1;errors.append({"type":type(error).__name__,"message":str(error)})
    try:bindings()
    except BaseException as error:code=1;errors.append({"type":type(error).__name__,"message":str(error)})
    hashes={}
    for name in("pure-negative-001.log","pure-positive-001.log"):
        try:hashes[name]=hashlib.sha256((HERE/name).read_bytes()).hexdigest()
        except BaseException as error:code=1;errors.append({"type":type(error).__name__,"message":str(error)})
    observed=time.perf_counter_ns()
    if observed>=deadline:code=1;errors.append({"type":"TimeoutError","message":"deadlineafterfinalhashes"})
    receipt={"schema":"host-session-pure-cycle-comparison-v1","code":code,"qualified":code==0,
        "facts":positive,"negative_facts":negative,"negative_expected_failure_detected":negative_expected,
        "negative_source":"references/source006/owned_events.py","positive_source":"owned_events.py",
        "log_sha256":hashes,"errors":errors,"observed_ns":observed,"deadline_ns":deadline,
        "deadline_scope":"comparison/checks/hashes35s; receipt under45s outerJob",
        "gc_initial_enabled":gc_initial,"gc_final_enabled":gc.isenabled(),"gc_collect_calls":0,
        "private_dll_loads":0,"process_launches_by_tests":0,"native_api_calls_by_tests":0,
        "whole_arm_custody_qualified":False,"retention_native_qualified":False,"session_approved":False,
        "scope":"oneexpectedfailureoriginal006+25repairedpurepasses; not zero-failureoverall/nativeclosure/handlebalance/PSS/benchmark proof"}
    with(HERE/"pure-receipt-001.json").open("x",encoding="utf-8")as out:
        json.dump(receipt,out,indent=2,allow_nan=False);out.write("\n")
    return code
if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--approved-unit-plan-sha",required=True)
    raise SystemExit(main(parser.parse_args().approved_unit_plan_sha))
