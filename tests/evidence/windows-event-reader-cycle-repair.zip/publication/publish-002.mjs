// Filesystem/compression-only publisher. No subprocess/network/native test.
import fs from 'node:fs/promises';
import zlib from 'node:zlib';
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const demand=(v,m)=>{if(!v)throw Error(m)};
function verify(raw,members){
 let e=-1;for(let p=raw.length-22;p>=Math.max(0,raw.length-65557);p--){if(raw.readUInt32LE(p)===0x06054b50){e=p;break}}
 demand(e>=0,'EOCD');let count=raw.readUInt16LE(e+10),pos=raw.readUInt32LE(e+16),end=pos+raw.readUInt32LE(e+12),seen=new Map();
 for(let i=0;i<count;i++){
  demand(raw.readUInt32LE(pos)===0x02014b50,'central');let flags=raw.readUInt16LE(pos+8),method=raw.readUInt16LE(pos+10),crc=raw.readUInt32LE(pos+16),cl=raw.readUInt32LE(pos+20),ul=raw.readUInt32LE(pos+24),nl=raw.readUInt16LE(pos+28),el=raw.readUInt16LE(pos+30),co=raw.readUInt16LE(pos+32),off=raw.readUInt32LE(pos+42);
  let name=raw.subarray(pos+46,pos+46+nl).toString('utf8');demand(!seen.has(name)&&!(flags&1)&&ul<=64*1024*1024,'member bound');
  demand(raw.readUInt32LE(off)===0x04034b50,'local');let ln=raw.readUInt16LE(off+26),le=raw.readUInt16LE(off+28);demand(raw.subarray(off+30,off+30+ln).toString('utf8')===name,'name');
  let packed=raw.subarray(off+30+ln+le,off+30+ln+le+cl),b=method===8?zlib.inflateRawSync(packed,{maxOutputLength:64*1024*1024}):method===0?packed:null;
  demand(b&&b.length===ul&&zlib.crc32(b)===crc,'CRC/size '+name);demand(members.has(name)&&members.get(name).equals(b),'exact member '+name);seen.set(name,b);pos+=46+nl+el+co;
 }
 demand(pos===end&&seen.size===members.size,'complete central set');let index=JSON.parse(seen.get('INDEX.json'));
 demand(Object.keys(index).length+1===seen.size,'INDEX set');for(let[n,p]of Object.entries(index)){let b=seen.get(n);demand(b&&b.length===p.bytes&&sha(b)===p.sha256&&zlib.crc32(b)===p.crc32,'INDEX '+n)}
 return {members:seen.size,index_members:Object.keys(index).length,index_sha256:sha(seen.get('INDEX.json')),CRC_SHA_size:'all passed'};
}
export async function publish({manifestPath,manifestSha,outputPath,receiptPath}){
 const mr=await fs.readFile(manifestPath);demand(sha(mr)===manifestSha,'manifest samebytes');const manifest=JSON.parse(mr),members=new Map();
 for(let item of manifest.files){let b=await fs.readFile(item.path);demand(b.length===item.bytes&&sha(b)===item.sha256,'input '+item.path);demand(!members.has(item.member)&&!item.member.startsWith('/')&&!item.member.split('/').includes('..'),'member path');members.set(item.member,b)}
 demand(!members.has('publication/inputs.json'),'manifest collision');members.set('publication/inputs.json',mr);
 const index={};for(let[n,b]of [...members].sort(([a],[b])=>a.localeCompare(b,'en'))){index[n]={bytes:b.length,sha256:sha(b),crc32:zlib.crc32(b)}}
 members.set('INDEX.json',Buffer.from(JSON.stringify(index,null,2)+'\n'));
 const local=[],central=[];let offset=0;
 for(let[n,b]of [...members].sort(([a],[b])=>a.localeCompare(b,'en'))){let nb=Buffer.from(n),packed=zlib.deflateRawSync(b,{level:9}),crc=zlib.crc32(b),lh=Buffer.alloc(30),ch=Buffer.alloc(46);demand(nb.length<=65535&&packed.length<0xffffffff&&b.length<0xffffffff,'ZIP32 bound');
  lh.writeUInt32LE(0x04034b50,0);lh.writeUInt16LE(20,4);lh.writeUInt16LE(0x800,6);lh.writeUInt16LE(8,8);lh.writeUInt16LE(0x21,12);lh.writeUInt32LE(crc,14);lh.writeUInt32LE(packed.length,18);lh.writeUInt32LE(b.length,22);lh.writeUInt16LE(nb.length,26);
  ch.writeUInt32LE(0x02014b50,0);ch.writeUInt16LE(20,4);ch.writeUInt16LE(20,6);ch.writeUInt16LE(0x800,8);ch.writeUInt16LE(8,10);ch.writeUInt16LE(0x21,14);ch.writeUInt32LE(crc,16);ch.writeUInt32LE(packed.length,20);ch.writeUInt32LE(b.length,24);ch.writeUInt16LE(nb.length,28);ch.writeUInt32LE(0x20,38);ch.writeUInt32LE(offset,42);local.push(lh,nb,packed);central.push(ch,nb);offset+=lh.length+nb.length+packed.length;
 }
 demand(members.size<=65535,'member count');let cb=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(members.size,8);end.writeUInt16LE(members.size,10);end.writeUInt32LE(cb.length,12);end.writeUInt32LE(offset,16);let zip=Buffer.concat([...local,cb,end]);
 await fs.writeFile(outputPath,zip,{flag:'wx'});let readback=await fs.readFile(outputPath),verified=verify(readback,members);demand(readback.equals(zip),'whole readback');
 demand(sha(await fs.readFile(manifestPath))===manifestSha,'manifest post');for(let item of manifest.files){let b=await fs.readFile(item.path);demand(b.length===item.bytes&&sha(b)===item.sha256,'post input '+item.path)}
 const receipt={schema:1,archive:outputPath,archive_sha256:sha(readback),bytes:readback.length,...verified,input_manifest_sha256:manifestSha,source_files:manifest.files.length,operation:'Node filesystem/compression only; no process/native/test/Git',scope:'pure event-reader cycle repair plus failed003 evidence;0benchmarkslots/persistent2unresolved/noPSS'};
 await fs.writeFile(receiptPath,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});return receipt;
}
