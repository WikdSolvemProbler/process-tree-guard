#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <linux/capability.h>
#include <linux/magic.h>
#include <linux/sched.h>
#include <limits.h>
#include <poll.h>
#include <sched.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/syscall.h>
#include <sys/timerfd.h>
#include <time.h>
#include <sys/wait.h>
#include <unistd.h>

#define MOUNT "/sys/fs/cgroup"
#define SCOPE_PREFIX "/system.slice/"
#define MAX_PATH PATH_MAX

static void need(int ok, const char *operation)
{
    if (!ok) {
        int error = errno;
        fprintf(stderr, "invalid operation=%s errno=%d (%s)\n",
                operation, error, strerror(error));
        exit(90);
    }
}

static void join(char output[MAX_PATH], const char *base, const char *name)
{
    int count = snprintf(output, MAX_PATH, "%s/%s", base, name);
    need(count >= 0 && count < MAX_PATH, "join path");
}

static void procfile(char output[MAX_PATH], pid_t pid, const char *name)
{
    int count = snprintf(output, MAX_PATH, "/proc/%ld/%s", (long)pid, name);
    need(count >= 0 && count < MAX_PATH, "proc path");
}

static void read_text(const char *path, char *buffer, size_t size)
{
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    need(fd >= 0, path);
    ssize_t n = read(fd, buffer, size - 1);
    need(n >= 0 && (size_t)n < size - 1, "read text");
    buffer[n] = '\0';
    close(fd);
}

static void read_ns(const char *path, char output[128])
{
    ssize_t n = readlink(path, output, 127);
    need(n > 0 && n < 127, "read namespace link");
    output[n] = '\0';
}

static int put(const char *label, const char *path, const char *value)
{
    int fd = open(path, O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) {
        int error = errno;
        printf("%s stage=open errno=%d path=%s\n", label, error, path);
        return error;
    }
    size_t size = strlen(value);
    ssize_t n = write(fd, value, size);
    int error = n < 0 ? errno : 0;
    close(fd);
    need(n < 0 || (size_t)n == size, "control short write");
    printf("%s stage=write errno=%d path=%s\n", label, error, path);
    return error;
}

static int cg_put(const char *label, const char *cg, const char *name, const char *value)
{
    char path[MAX_PATH];
    join(path, cg, name);
    return put(label, path, value);
}

static void member(const char *label, pid_t pid, const char *suffix)
{
    char path[MAX_PATH], actual[MAX_PATH], expected[MAX_PATH];
    procfile(path, pid, "cgroup");
    read_text(path, actual, sizeof(actual));
    int n = snprintf(expected, sizeof(expected), "0::%s\n", suffix);
    need(n > 0 && (size_t)n < sizeof(expected), "membership expectation");
    printf("%s pid=%ld membership=%s", label, (long)pid, actual);
    need(strcmp(actual, expected) == 0, "membership mismatch");
}

static void no_processes(const char *cg)
{
    char path[MAX_PATH], events[128];
    join(path, cg, "cgroup.events");
    read_text(path, events, sizeof(events));
    printf("drain path=%s %s", cg, events);
    need(strstr(events, "populated 0\n") != NULL, "nonempty dedicated cgroup");
}

static int reap(int fd, pid_t pid, const char *label)
{
    siginfo_t result = {0};
    need(waitid(P_PIDFD, (id_t)fd, &result, WEXITED) == 0, "waitid pidfd");
    need(result.si_pid == pid, "wrong pidfd result");
    printf("%s held_pid=%ld si_code=%d si_status=%d\n",
           label, (long)pid, result.si_code, result.si_status);
    close(fd);
    return result.si_code == CLD_EXITED ? result.si_status : 128 + result.si_status;
}

static void still_held(int pidfd)
{
    struct pollfd pfd = {.fd = pidfd, .events = POLLIN};
    need(poll(&pfd, 1, 0) == 0, "expected held live process");
}


static const uid_t payload_uid = 501;
static const gid_t payload_gid = 1000;
static const gid_t payload_groups[] = {999, 1000};

struct held {
    pid_t pid;
    int fd;
};

static void verify_ids(const char *label)
{
    uid_t ru, eu, su;
    gid_t rg, eg, sg, groups[2];
    need(getresuid(&ru, &eu, &su) == 0 && getresgid(&rg, &eg, &sg) == 0,
         "read saved credentials");
    need(getgroups(2, groups) == 2, "read exact supplementary groups");
    printf("%s uid=%u/%u/%u gid=%u/%u/%u groups=%u,%u\n",
           label, ru, eu, su, rg, eg, sg, groups[0], groups[1]);
    need(ru == payload_uid && eu == payload_uid && su == payload_uid &&
         rg == payload_gid && eg == payload_gid && sg == payload_gid &&
         groups[0] == payload_groups[0] && groups[1] == payload_groups[1],
         "credential parity");
    struct __user_cap_header_struct header = {.version = _LINUX_CAPABILITY_VERSION_3};
    struct __user_cap_data_struct caps[2] = {0};
    need(syscall(SYS_capget, &header, caps) == 0, "read capabilities");
    int nnp = prctl(PR_GET_NO_NEW_PRIVS, 0L, 0L, 0L, 0L);
    printf("%s caps_eff=%08x%08x caps_prm=%08x%08x caps_inh=%08x%08x nnp=%d\n",
           label, caps[1].effective, caps[0].effective, caps[1].permitted,
           caps[0].permitted, caps[1].inheritable, caps[0].inheritable, nnp);
    need(!(caps[0].effective || caps[1].effective || caps[0].permitted ||
           caps[1].permitted || caps[0].inheritable || caps[1].inheritable) &&
         nnp == 1, "unprivileged no-new-privileges payload");
}

static void drop_to_guest(void)
{
    need(prctl(PR_CAP_AMBIENT, PR_CAP_AMBIENT_CLEAR_ALL, 0L, 0L, 0L) == 0,
         "clear ambient capabilities");
    need(setgroups(2, payload_groups) == 0, "set supplementary groups");
    need(setresgid(payload_gid, payload_gid, payload_gid) == 0, "drop gid");
    need(setresuid(payload_uid, payload_uid, payload_uid) == 0, "drop uid");
    need(prctl(PR_SET_NO_NEW_PRIVS, 1L, 0L, 0L, 0L) == 0, "lock no new privileges");
    verify_ids("child-pre-exec");
}

static void root_owned(const char *path, int directory)
{
    struct stat info;
    need(lstat(path, &info) == 0 && (directory ? S_ISDIR(info.st_mode) : S_ISREG(info.st_mode)) &&
         info.st_uid == 0 && info.st_gid == 0 && !(info.st_mode & (S_IWGRP | S_IWOTH)),
         "root-owned controller path");
    printf("ownership mode=%04o uid=%u gid=%u path=%s\n", info.st_mode & 07777,
           info.st_uid, info.st_gid, path);
}


enum cause { ARMED, SUPERVISOR_LOST, OWNER_LOST, DEADLINE, NORMAL, PROTOCOL_LOST };
struct watcher_note { pid_t pid; enum cause cause; };
struct payload_note { pid_t leader; pid_t detached; };
struct channels { int arm[2]; int permit[2]; int events[2]; };

static void pipe_pair(int pair[2])
{
    need(pipe2(pair, O_CLOEXEC) == 0, "make pipe");
}

static void emit_bytes(int fd, const void *data, size_t size)
{
    need(write(fd, data, size) == (ssize_t)size, "write complete handshake");
}

static void take_bytes(int fd, void *data, size_t size)
{
    need(read(fd, data, size) == (ssize_t)size, "read complete handshake");
}

static int pidfd_for(pid_t pid)
{
    int fd = (int)syscall(SYS_pidfd_open, pid, 0);
    need(fd >= 0, "pidfd_open");
    return fd;
}

static void send_kill(int fd)
{
    need(syscall(SYS_pidfd_send_signal, fd, SIGKILL, NULL, 0) == 0,
         "signal exact held test process");
}

static void verify_dead(int fd)
{
    struct pollfd pfd = {.fd = fd, .events = POLLIN};
    need(poll(&pfd, 1, 1000) == 1 && (pfd.revents & POLLIN), "original pidfd did not exit");
}

static void held_status(struct held process, const char *label, int expected)
{
    need(reap(process.fd, process.pid, label) == expected, "wrong held process status");
}

static long long boottime(void)
{
    struct timespec now;
    need(clock_gettime(CLOCK_BOOTTIME, &now) == 0, "boottime");
    return (long long)now.tv_sec * 1000000000LL + now.tv_nsec;
}

static int arm_timer(int seconds, long long *deadline)
{
    int fd = timerfd_create(CLOCK_BOOTTIME, TFD_CLOEXEC | TFD_NONBLOCK);
    need(fd >= 0, "deadline timerfd");
    *deadline = boottime() + (long long)seconds * 1000000000LL;
    struct itimerspec value = {.it_value = {.tv_sec = *deadline / 1000000000LL,
                                          .tv_nsec = *deadline % 1000000000LL}};
    need(timerfd_settime(fd, TFD_TIMER_ABSTIME, &value, NULL) == 0, "arm absolute deadline");
    return fd;
}

static void drain(const char *leaf)
{
    char path[MAX_PATH], events[128];
    join(path, leaf, "cgroup.events");
    const struct timespec pause_time = {.tv_nsec = 10000000};
    for (int attempt = 0; attempt < 100; ++attempt) {
        read_text(path, events, sizeof(events));
        if (strstr(events, "populated 0\n")) {
            no_processes(leaf);
            return;
        }
        nanosleep(&pause_time, NULL);
    }
    need(0, "watchdog drain timed out");
}

static void watch(const char *leaf, int kill_fd, int supervisor_fd, int owner_fd,
                  int timer, long long deadline, int normal, int ack, int events)
{
    struct watcher_note note = {.pid = getpid(), .cause = ARMED};
    struct pollfd p[4] = {
        {.fd = supervisor_fd, .events = POLLIN},
        {.fd = owner_fd, .events = POLLIN},
        {.fd = timer, .events = POLLIN},
        {.fd = normal, .events = POLLIN},
    };
    printf("watchdog-armed pid=%ld absolute_boottime_ns=%lld leaf=%s\n",
           (long)note.pid, deadline, leaf);
    emit_bytes(events, &note, sizeof(note));
    emit_bytes(ack, "A", 1);
    close(ack);
    need(poll(p, 4, -1) > 0, "poll watchdog inputs");
    if (p[0].revents & POLLIN) {
        note.cause = SUPERVISOR_LOST;
    } else if (p[1].revents & POLLIN) {
        note.cause = OWNER_LOST;
    } else if (p[2].revents & POLLIN) {
        uint64_t ticks;
        take_bytes(timer, &ticks, sizeof(ticks));
        need(ticks > 0 && boottime() >= deadline, "deadline fired early");
        note.cause = DEADLINE;
    } else {
        char byte;
        ssize_t n = read(normal, &byte, 1);
        if (n == 1 && byte == 'N') {
            note.cause = NORMAL;
        } else {
            struct pollfd original = {.fd = supervisor_fd, .events = POLLIN};
            note.cause = poll(&original, 1, 1000) == 1 && (original.revents & POLLIN)
                ? SUPERVISOR_LOST : PROTOCOL_LOST;
        }
    }
    printf("watchdog-cause pid=%ld cause=%d observed_boottime_ns=%lld absolute_boottime_ns=%lld\n",
           (long)note.pid, note.cause, boottime(), deadline);
    emit_bytes(kill_fd, "1", 1);
    close(kill_fd);
    printf("watchdog-kill pid=%ld exact_leaf=%s\n", (long)note.pid, leaf);
    drain(leaf);
    emit_bytes(events, &note, sizeof(note));
    _exit(50 + note.cause);
}

static void payload(const char *leaf, int normal)
{
    verify_ids("exec-lifecycle-payload");
    member("exec-lifecycle-membership", getpid(), leaf + strlen(MOUNT));
    need(fcntl(5, F_GETFD) < 0 && errno == EBADF, "unexpected inherited control descriptor");
    int handshake[2];
    pipe_pair(handshake);
    pid_t intermediary = fork();
    need(intermediary >= 0, "first fork");
    if (intermediary == 0) {
        close(3);
        close(4);
        close(handshake[0]);
        need(setsid() > 0, "detach session");
        pid_t descendant = fork();
        need(descendant >= 0, "second fork");
        if (descendant == 0) {
            pid_t me = getpid();
            printf("detached-descendant pid=%ld sid=%ld\n", (long)me, (long)getsid(0));
            member("detached-descendant-membership", me, leaf + strlen(MOUNT));
            emit_bytes(handshake[1], &me, sizeof(me));
            close(handshake[1]);
            for (;;) pause();
        }
        _exit(0);
    }
    close(handshake[1]);
    struct payload_note note = {.leader = getpid()};
    take_bytes(handshake[0], &note.detached, sizeof(note.detached));
    close(handshake[0]);
    int status;
    need(waitpid(intermediary, &status, 0) == intermediary &&
         WIFEXITED(status) && WEXITSTATUS(status) == 0, "intermediary exited");
    emit_bytes(3, &note, sizeof(note));
    close(3);
    if (normal) {
        char byte;
        take_bytes(4, &byte, 1);
        need(byte == 'N', "normal completion instruction");
        _exit(23);
    }
    close(4);
    for (;;) pause();
}

static struct held start_payload(const char *binary, const char *leaf,
                                 enum cause expected, int ready, int permit)
{
    int target = open(leaf, O_PATH | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    need(target >= 0, "open exact protected leaf");
    struct held held = {.fd = -1};
    struct clone_args args = {.flags = CLONE_INTO_CGROUP | CLONE_PIDFD,
                              .pidfd = (uintptr_t)&held.fd,
                              .cgroup = (uint64_t)target, .exit_signal = SIGCHLD};
    long child = syscall(SYS_clone3, &args, sizeof(args));
    int error = child < 0 ? errno : 0;
    if (child == 0) {
        close(target);
        member("atomic-lifecycle-before-exec", getpid(), leaf + strlen(MOUNT));
        int high_ready = fcntl(ready, F_DUPFD_CLOEXEC, 10);
        int high_permit = fcntl(permit, F_DUPFD_CLOEXEC, 10);
        need(high_ready >= 10 && high_permit >= 10, "stage only payload pipe descriptors");
        need(dup2(high_ready, 3) == 3 && dup2(high_permit, 4) == 4, "exec pipe descriptors");
        need(syscall(SYS_close_range, 5U, UINT_MAX, 0U) == 0, "close every other inherited fd");
        drop_to_guest();
        char *const args_child[] = {(char *)binary, "--payload", (char *)leaf,
                                    expected == NORMAL ? "normal" : "held", NULL};
        char *const clean_env[] = {"PATH=/usr/bin:/bin", "LC_ALL=C", NULL};
        execve(binary, args_child, clean_env);
        need(0, "exec lifecycle payload");
    }
    close(target);
    printf("supervisor-clone3 pid=%ld fd=%d errno=%d\n", child, held.fd, error);
    need(child > 0 && held.fd >= 0, "atomic lifecycle clone");
    held.pid = (pid_t)child;
    return held;
}

static void supervisor(const char *binary, const char *leaf, enum cause expected,
                       int owner_fd, struct channels channels)
{
    need(prctl(PR_SET_CHILD_SUBREAPER, 1L, 0L, 0L, 0L) == 0, "supervisor subreaper");
    char path[MAX_PATH];
    join(path, leaf, "cgroup.kill");
    int kill_fd = open(path, O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    need(kill_fd >= 0, "preopen exact cgroup.kill");
    int normal[2], ack[2];
    pipe_pair(normal);
    pipe_pair(ack);
    int self_fd = pidfd_for(getpid());
    long long deadline;
    int timer = arm_timer(expected == DEADLINE ? 2 : 6, &deadline);
    pid_t watcher_pid = fork();
    need(watcher_pid >= 0, "fork one-shot watchdog");
    if (watcher_pid == 0) {
        close(normal[1]);
        close(ack[0]);
        close(channels.arm[1]);
        close(channels.permit[0]);
        watch(leaf, kill_fd, self_fd, owner_fd, timer, deadline, normal[0],
              ack[1], channels.events[1]);
    }
    close(kill_fd);
    close(self_fd);
    close(owner_fd);
    close(timer);
    close(normal[0]);
    close(ack[1]);
    close(channels.events[1]);
    int watcher_fd = pidfd_for(watcher_pid);
    char byte;
    take_bytes(ack[0], &byte, 1);
    need(byte == 'A', "watchdog armed before clone");
    close(ack[0]);
    struct held leader = start_payload(binary, leaf, expected, channels.arm[1], channels.permit[0]);
    close(channels.arm[1]);
    close(channels.permit[0]);
    int child_status = reap(leader.fd, leader.pid, "supervisor-reaped-leader");
    if (child_status == 23) emit_bytes(normal[1], "N", 1);
    close(normal[1]);
    int watcher_status = reap(watcher_fd, watcher_pid, "supervisor-reaped-watchdog");
    int adopted_status;
    pid_t adopted = waitpid(-1, &adopted_status, 0);
    need(adopted > 0 && WIFSIGNALED(adopted_status) && WTERMSIG(adopted_status) == SIGKILL,
         "supervisor reaps detached orphan");
    printf("supervisor-subreaper-reaped pid=%ld signal=%d\n", (long)adopted, WTERMSIG(adopted_status));
    need(waitpid(-1, &adopted_status, WNOHANG) < 0 && errno == ECHILD, "unexpected retained child");
    need(watcher_status == 50 + (int)expected, "watchdog cause mismatch");
    need(child_status == (expected == NORMAL ? 23 : 128 + SIGKILL), "leader exit mismatch");
    _exit(expected == NORMAL ? 23 : (expected == DEADLINE ? 124 : 125));
}

static void lifecycle_case(const char *binary, const char *root, const char *name,
                           enum cause expected, int sibling_fd)
{
    char leaf[MAX_PATH];
    join(leaf, root, name);
    need(mkdir(leaf, 0755) == 0, "create unique lifecycle leaf");
    root_owned(leaf, 1);
    pid_t owner = fork();
    need(owner >= 0, "fork synthetic owner");
    if (owner == 0) {
        close(sibling_fd);
        for (;;) pause();
    }
    struct held own = {.pid = owner, .fd = pidfd_for(owner)};
    still_held(own.fd);
    struct channels channels;
    pipe_pair(channels.arm);
    pipe_pair(channels.permit);
    pipe_pair(channels.events);
    pid_t guardian = fork();
    need(guardian >= 0, "fork supervisor");
    if (guardian == 0) {
        close(sibling_fd);
        close(channels.arm[0]);
        close(channels.permit[1]);
        close(channels.events[0]);
        supervisor(binary, leaf, expected, own.fd, channels);
    }
    close(channels.arm[1]);
    close(channels.permit[0]);
    close(channels.events[1]);
    struct held guard = {.pid = guardian, .fd = pidfd_for(guardian)};
    struct watcher_note note;
    take_bytes(channels.events[0], &note, sizeof(note));
    need(note.cause == ARMED && note.pid > 0, "watchdog armed receipt");
    struct held watcher = {.pid = note.pid, .fd = pidfd_for(note.pid)};
    struct payload_note started;
    take_bytes(channels.arm[0], &started, sizeof(started));
    close(channels.arm[0]);
    need(started.leader > 0 && started.detached > 0 && started.leader != started.detached,
         "distinct payload identities");
    struct held leader = {.pid = started.leader, .fd = pidfd_for(started.leader)};
    struct held detached = {.pid = started.detached, .fd = pidfd_for(started.detached)};
    still_held(guard.fd);
    still_held(watcher.fd);
    still_held(leader.fd);
    still_held(detached.fd);
    member("held-original-payload", leader.pid, leaf + strlen(MOUNT));
    member("held-detached-descendant", detached.pid, leaf + strlen(MOUNT));
    pid_t leader_session = getsid(leader.pid), detached_session = getsid(detached.pid);
    need(leader_session > 0 && detached_session > 0 && leader_session != detached_session,
         "double fork created a separate session");
    printf("case-live case=%s supervisor=%ld watchdog=%ld owner=%ld payload=%ld detached=%ld separate_sid=%ld/%ld\n",
           name, (long)guard.pid, (long)watcher.pid, (long)owner, (long)leader.pid,
           (long)detached.pid, (long)leader_session, (long)detached_session);
    if (expected == SUPERVISOR_LOST) send_kill(guard.fd);
    if (expected == OWNER_LOST) send_kill(own.fd);
    if (expected == NORMAL) emit_bytes(channels.permit[1], "N", 1);
    close(channels.permit[1]);
    take_bytes(channels.events[0], &note, sizeof(note));
    close(channels.events[0]);
    need(note.pid == watcher.pid && note.cause == expected, "expected watchdog trigger");
    still_held(sibling_fd);
    if (expected == SUPERVISOR_LOST) {
        held_status(guard, "controller-reaped-supervisor", 128 + SIGKILL);
        held_status(watcher, "controller-reaped-independent-watchdog", 50 + expected);
        held_status(leader, "controller-reaped-orphan-leader", 128 + SIGKILL);
        held_status(detached, "controller-reaped-orphan-descendant", 128 + SIGKILL);
    } else {
        held_status(guard, "controller-reaped-supervisor",
                    expected == NORMAL ? 23 : (expected == DEADLINE ? 124 : 125));
        verify_dead(watcher.fd);
        verify_dead(leader.fd);
        verify_dead(detached.fd);
        close(watcher.fd);
        close(leader.fd);
        close(detached.fd);
    }
    if (expected != OWNER_LOST) {
        still_held(own.fd);
        send_kill(own.fd);
    }
    held_status(own, "controller-reaped-owner", 128 + SIGKILL);
    no_processes(leaf);
    printf("case-verdict case=%s pass=1 cause=%d independent_sibling_alive=1\n", name, expected);
}

static struct held start_sibling(const char *leaf)
{
    int ready[2];
    pipe_pair(ready);
    pid_t pid = fork();
    need(pid >= 0, "fork unrelated sibling canary");
    if (pid == 0) {
        close(ready[0]);
        need(cg_put("place-only-dedicated-canary", leaf, "cgroup.procs", "0") == 0, "place sibling");
        member("independent-canary-membership", getpid(), leaf + strlen(MOUNT));
        emit_bytes(ready[1], "R", 1);
        close(ready[1]);
        for (;;) pause();
    }
    close(ready[1]);
    struct held child = {.pid = pid, .fd = pidfd_for(pid)};
    char byte;
    take_bytes(ready[0], &byte, 1);
    close(ready[0]);
    need(byte == 'R', "unrelated sibling ready");
    still_held(child.fd);
    return child;
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    if (argc == 4 && strcmp(argv[1], "--payload") == 0) {
        payload(argv[2], strcmp(argv[3], "normal") == 0);
        return 99;
    }
    need(argc == 2 && geteuid() == 0 && getegid() == 0, "root system scope");
    const char *prefix = "ptg-linux-lifecycle-";
    size_t n = strlen(argv[1]);
    need(n > strlen(prefix) + 6 && n < 100 &&
         strncmp(argv[1], prefix, strlen(prefix)) == 0 &&
         strcmp(argv[1] + n - 6, ".scope") == 0 &&
         strspn(argv[1], "abcdefghijklmnopqrstuvwxyz0123456789.-") == n, "dedicated lifecycle scope");
    char suffix[MAX_PATH], root[MAX_PATH], binary[MAX_PATH], expected[MAX_PATH], path[MAX_PATH];
    snprintf(suffix, sizeof(suffix), "%s%s", SCOPE_PREFIX, argv[1]);
    snprintf(root, sizeof(root), "%s%s%s", MOUNT, SCOPE_PREFIX, argv[1]);
    snprintf(expected, sizeof(expected), "/tmp/%.*s/proof", (int)n - 6, argv[1]);
    ssize_t len = readlink("/proc/self/exe", binary, sizeof(binary) - 1);
    need(len > 0 && (size_t)len < sizeof(binary) - 1, "trusted executable path");
    binary[len] = '\0';
    need(strcmp(binary, expected) == 0, "exact trusted probe executable");
    member("verify-root-scope", getpid(), suffix);
    root_owned(root, 1);
    root_owned(binary, 0);
    struct statfs fs;
    need(statfs(root, &fs) == 0 && fs.f_type == CGROUP2_SUPER_MAGIC, "scope cgroup2");
    join(path, root, "cgroup.stat");
    char state[128];
    read_text(path, state, sizeof(state));
    need(strncmp(state, "nr_descendants 0\n", 17) == 0, "scope already populated by child cgroups");
    need(prctl(PR_SET_CHILD_SUBREAPER, 1L, 0L, 0L, 0L) == 0, "controller subreaper");
    umask(022);
    char sibling[MAX_PATH];
    join(sibling, root, "sibling");
    need(mkdir(sibling, 0755) == 0, "create independent sibling");
    root_owned(sibling, 1);
    struct held canary = start_sibling(sibling);
    lifecycle_case(binary, root, "case-supervisor", SUPERVISOR_LOST, canary.fd);
    lifecycle_case(binary, root, "case-deadline", DEADLINE, canary.fd);
    lifecycle_case(binary, root, "case-owner", OWNER_LOST, canary.fd);
    lifecycle_case(binary, root, "case-normal", NORMAL, canary.fd);
    need(cg_put("cleanup-independent-sibling", sibling, "cgroup.kill", "1") == 0, "kill only sibling");
    held_status(canary, "reaped-independent-sibling", 128 + SIGKILL);
    no_processes(sibling);
    printf("lifecycle-proof=passed\n");
    return 0;
}
