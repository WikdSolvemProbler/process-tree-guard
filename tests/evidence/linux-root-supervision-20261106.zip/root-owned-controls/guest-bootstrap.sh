set -eu
[ "$(/usr/bin/id -u)" = 501 ]
[ "$(/usr/bin/id -g)" = 1000 ]
[ "$(/usr/bin/cat /proc/$$/cgroup)" = "0::/user.slice/user-501.slice/user@501.service/app.slice/ptg-linux-root-bootstrap-20261106-acbda0ec.scope" ]
/usr/bin/grep -E '^(Uid|Gid|Groups|CapEff|NoNewPrivs):' /proc/$$/status
groups=$(/usr/bin/awk '$1=="Groups:" && NF==3 {print $2 " " $3; exit}' /proc/$$/status)
[ "$groups" = '999 1000' ]
/usr/bin/systemctl --user show ptg-linux-root-bootstrap-20261106-acbda0ec.scope --property=RuntimeMaxUSec,KillMode,KillSignal
exec /usr/bin/sudo -n -- /usr/bin/systemd-run --system --scope --quiet --unit ptg-linux-root-owned-20261106-acbda0ec.scope --slice=system.slice -p Delegate=no -p RuntimeMaxSec=30s -p KillMode=control-group -p KillSignal=SIGKILL -p SendSIGKILL=yes -- /bin/sh -c 'set -eu
umask 077
unit=ptg-linux-root-owned-20261106-acbda0ec.scope
scope=/system.slice/ptg-linux-root-owned-20261106-acbda0ec.scope
root=/sys/fs/cgroup$scope
scratch=/tmp/ptg-linux-root-owned-20261106-acbda0ec
[ "$(/usr/bin/id -u)" = 0 ]
[ "$(/usr/bin/id -g)" = 0 ]
[ "$(/usr/bin/cat /proc/$$/cgroup)" = "0::$scope" ]
[ "$(/usr/bin/realpath -e -- "$root")" = "$root" ]
[ "$(/usr/bin/stat -c '"'"'%u:%g'"'"' -- "$root")" = 0:0 ]
[ "$(/usr/bin/stat -f -c %T -- "$root")" = cgroup2fs ]
/usr/bin/grep -Fxq '"'"'nr_descendants 0'"'"' "$root/cgroup.stat"
properties=$(/usr/bin/systemctl --system show "$unit" --property=Delegate,ControlGroup,RuntimeMaxUSec,KillMode,KillSignal,SendSIGKILL,ActiveState)
printf '"'"'%s\n'"'"' "$properties"
for exact in Delegate=no "ControlGroup=$scope" RuntimeMaxUSec=30s KillMode=control-group KillSignal=9 SendSIGKILL=yes ActiveState=active; do
    printf '"'"'%s\n'"'"' "$properties" | /usr/bin/grep -Fxq -- "$exact"
done
/usr/bin/uname -srvmo
/usr/bin/mkdir -m 700 -- "$scratch"
cleanup() {
    result=$?
    trap - EXIT
    for leaf in sink sibling payload; do
        target="$root/$leaf"
        if [ -d "$target" ]; then
            if /usr/bin/grep -Fxq '"'"'populated 1'"'"' "$target/cgroup.events"; then
                printf '"'"'1'"'"' > "$target/cgroup.kill" || result=91
                attempt=0
                while /usr/bin/grep -Fxq '"'"'populated 1'"'"' "$target/cgroup.events" && [ "$attempt" -lt 20 ]; do
                    /usr/bin/sleep 0.025
                    attempt=$((attempt+1))
                done
            fi
            if /usr/bin/rmdir -- "$target"; then printf '"'"'removed cgroup=%s\n'"'"' "$target"; else result=91; fi
        fi
    done
    if /usr/bin/rm -f -- "$scratch/proof" "$scratch/root-owned.c" && /usr/bin/rmdir -- "$scratch" && [ ! -e "$scratch" ]; then
        printf '"'"'scratch_removed=%s\n'"'"' "$scratch"
    else
        result=92
    fi
    /usr/bin/cat "$root/cgroup.stat"
    exit "$result"
}
trap cleanup EXIT
/usr/bin/cat > "$scratch/root-owned.c" <<'"'"'PTG_ROOT_OWNED_SOURCE'"'"'
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <linux/capability.h>
#include <linux/magic.h>
#include <linux/sched.h>
#include <limits.h>
#include <poll.h>
#include <sched.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <unistd.h>

#define MOUNT "/sys/fs/cgroup"
#define SCOPE_PREFIX "/system.slice/"
#define MAX_PATH PATH_MAX

static void need(int ok, const char *operation)
{
    if (!ok) {
        int error = errno;
        fprintf(stderr, "invalid operation=%s errno=%d (%s)\n",
                operation, error, strerror(error));
        exit(90);
    }
}

static void join(char output[MAX_PATH], const char *base, const char *name)
{
    int count = snprintf(output, MAX_PATH, "%s/%s", base, name);
    need(count >= 0 && count < MAX_PATH, "join path");
}

static void procfile(char output[MAX_PATH], pid_t pid, const char *name)
{
    int count = snprintf(output, MAX_PATH, "/proc/%ld/%s", (long)pid, name);
    need(count >= 0 && count < MAX_PATH, "proc path");
}

static void read_text(const char *path, char *buffer, size_t size)
{
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    need(fd >= 0, path);
    ssize_t n = read(fd, buffer, size - 1);
    need(n >= 0 && (size_t)n < size - 1, "read text");
    buffer[n] = '"'"'\0'"'"';
    close(fd);
}

static void read_ns(const char *path, char output[128])
{
    ssize_t n = readlink(path, output, 127);
    need(n > 0 && n < 127, "read namespace link");
    output[n] = '"'"'\0'"'"';
}

static int put(const char *label, const char *path, const char *value)
{
    int fd = open(path, O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) {
        int error = errno;
        printf("%s stage=open errno=%d path=%s\n", label, error, path);
        return error;
    }
    size_t size = strlen(value);
    ssize_t n = write(fd, value, size);
    int error = n < 0 ? errno : 0;
    close(fd);
    need(n < 0 || (size_t)n == size, "control short write");
    printf("%s stage=write errno=%d path=%s\n", label, error, path);
    return error;
}

static int cg_put(const char *label, const char *cg, const char *name, const char *value)
{
    char path[MAX_PATH];
    join(path, cg, name);
    return put(label, path, value);
}

static void member(const char *label, pid_t pid, const char *suffix)
{
    char path[MAX_PATH], actual[MAX_PATH], expected[MAX_PATH];
    procfile(path, pid, "cgroup");
    read_text(path, actual, sizeof(actual));
    int n = snprintf(expected, sizeof(expected), "0::%s\n", suffix);
    need(n > 0 && (size_t)n < sizeof(expected), "membership expectation");
    printf("%s pid=%ld membership=%s", label, (long)pid, actual);
    need(strcmp(actual, expected) == 0, "membership mismatch");
}

static void no_processes(const char *cg)
{
    char path[MAX_PATH], events[128];
    join(path, cg, "cgroup.events");
    read_text(path, events, sizeof(events));
    printf("drain path=%s %s", cg, events);
    need(strstr(events, "populated 0\n") != NULL, "nonempty dedicated cgroup");
}

static int reap(int fd, pid_t pid, const char *label)
{
    siginfo_t result = {0};
    need(waitid(P_PIDFD, (id_t)fd, &result, WEXITED) == 0, "waitid pidfd");
    need(result.si_pid == pid, "wrong pidfd result");
    printf("%s held_pid=%ld si_code=%d si_status=%d\n",
           label, (long)pid, result.si_code, result.si_status);
    close(fd);
    return result.si_code == CLD_EXITED ? result.si_status : 128 + result.si_status;
}

static void still_held(int pidfd)
{
    struct pollfd pfd = {.fd = pidfd, .events = POLLIN};
    need(poll(&pfd, 1, 0) == 0, "expected held live process");
}


static const uid_t payload_uid = 501;
static const gid_t payload_gid = 1000;
static const gid_t payload_groups[] = {999, 1000};

struct held {
    pid_t pid;
    int fd;
};

static void verify_ids(const char *label)
{
    uid_t ru, eu, su;
    gid_t rg, eg, sg, groups[2];
    need(getresuid(&ru, &eu, &su) == 0 && getresgid(&rg, &eg, &sg) == 0,
         "read saved credentials");
    need(getgroups(2, groups) == 2, "read exact supplementary groups");
    printf("%s uid=%u/%u/%u gid=%u/%u/%u groups=%u,%u\n",
           label, ru, eu, su, rg, eg, sg, groups[0], groups[1]);
    need(ru == payload_uid && eu == payload_uid && su == payload_uid &&
         rg == payload_gid && eg == payload_gid && sg == payload_gid &&
         groups[0] == payload_groups[0] && groups[1] == payload_groups[1],
         "credential parity");
    struct __user_cap_header_struct header = {.version = _LINUX_CAPABILITY_VERSION_3};
    struct __user_cap_data_struct caps[2] = {0};
    need(syscall(SYS_capget, &header, caps) == 0, "read capabilities");
    int nnp = prctl(PR_GET_NO_NEW_PRIVS, 0L, 0L, 0L, 0L);
    printf("%s caps_eff=%08x%08x caps_prm=%08x%08x caps_inh=%08x%08x nnp=%d\n",
           label, caps[1].effective, caps[0].effective, caps[1].permitted,
           caps[0].permitted, caps[1].inheritable, caps[0].inheritable, nnp);
    need(!(caps[0].effective || caps[1].effective || caps[0].permitted ||
           caps[1].permitted || caps[0].inheritable || caps[1].inheritable) &&
         nnp == 1, "unprivileged no-new-privileges payload");
}

static void drop_to_guest(void)
{
    need(prctl(PR_CAP_AMBIENT, PR_CAP_AMBIENT_CLEAR_ALL, 0L, 0L, 0L) == 0,
         "clear ambient capabilities");
    need(setgroups(2, payload_groups) == 0, "set supplementary groups");
    need(setresgid(payload_gid, payload_gid, payload_gid) == 0, "drop gid");
    need(setresuid(payload_uid, payload_uid, payload_uid) == 0, "drop uid");
    need(prctl(PR_SET_NO_NEW_PRIVS, 1L, 0L, 0L, 0L) == 0, "lock no new privileges");
    verify_ids("child-pre-exec");
}

static void root_owned(const char *path, int directory)
{
    struct stat info;
    need(lstat(path, &info) == 0 && (directory ? S_ISDIR(info.st_mode) : S_ISREG(info.st_mode)) &&
         info.st_uid == 0 && info.st_gid == 0 && !(info.st_mode & (S_IWGRP | S_IWOTH)),
         "root-owned controller path");
    printf("ownership mode=%04o uid=%u gid=%u path=%s\n", info.st_mode & 07777,
           info.st_uid, info.st_gid, path);
}

static void require_write_denial(const char *leaf, const char *file)
{
    char path[MAX_PATH];
    join(path, leaf, file);
    int fd = open(path, O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    int error = fd < 0 ? errno : 0;
    printf("payload-control-write stage=open errno=%d path=%s\n", error, path);
    if (fd >= 0) close(fd);
    need(fd < 0 && (error == EACCES || error == EPERM), "unprivileged control file writable");
}

static void require_migration_denial(const char *sink)
{
    char path[MAX_PATH];
    join(path, sink, "cgroup.procs");
    int fd = open(path, O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    int error = fd < 0 ? errno : 0;
    printf("payload-writable-sink stage=open errno=%d path=%s\n", error, path);
    need(fd >= 0, "writable migration sink calibration");
    ssize_t result = write(fd, "0", 1);
    error = result < 0 ? errno : 0;
    close(fd);
    printf("payload-writable-sink stage=write errno=%d result=%ld path=%s\n",
           error, (long)result, path);
    need(result < 0 && error == EACCES, "migration to writable sink escaped root scope DAC");
}

static const char *controls[] = {
    "cgroup.procs", "cgroup.threads", "cgroup.kill", "cgroup.type", "cgroup.freeze"
};

static void payload_main(int argc, char **argv)
{
    need(argc == 6, "payload args");
    const char *role = argv[2], *own = argv[3], *sibling = argv[4], *sink = argv[5];
    need(strcmp(role, "payload") == 0 || strcmp(role, "canary") == 0, "payload role");
    verify_ids("exec-payload");
    member("exec-payload-membership", getpid(), own + strlen(MOUNT));
    char userns[128], mountns[128], cgroupns[128];
    read_ns("/proc/self/ns/user", userns);
    read_ns("/proc/self/ns/mnt", mountns);
    read_ns("/proc/self/ns/cgroup", cgroupns);
    printf("exec-payload role=%s user=%s mount=%s cgroup=%s\n",
           role, userns, mountns, cgroupns);
    need(fcntl(4, F_GETFD) < 0 && errno == EBADF, "unexpected inherited fd");
    if (strcmp(role, "payload") == 0) {
        for (size_t i = 0; i < sizeof(controls) / sizeof(controls[0]); ++i) {
            require_write_denial(own, controls[i]);
            require_write_denial(sibling, controls[i]);
        }
        require_migration_denial(sink);
        member("payload-remained", getpid(), own + strlen(MOUNT));
    }
    need(write(3, "R", 1) == 1, "exec payload ready");
    close(3);
    for (;;) pause();
}

static struct held launch(const char *binary, const char *role, const char *own,
                          const char *sibling, const char *sink)
{
    int target = open(own, O_PATH | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    need(target >= 0, "open intended root-owned leaf");
    struct stat info;
    need(fstat(target, &info) == 0 && info.st_uid == 0 && info.st_gid == 0 &&
         !(info.st_mode & (S_IWGRP | S_IWOTH)), "target descriptor identity");
    int ready[2];
    need(pipe2(ready, O_CLOEXEC) == 0, "exec handshake pipe");
    struct held held = {.fd = -1};
    struct clone_args args = {
        .flags = CLONE_INTO_CGROUP | CLONE_PIDFD,
        .pidfd = (uintptr_t)&held.fd,
        .cgroup = (uint64_t)target,
        .exit_signal = SIGCHLD,
    };
    long child = syscall(SYS_clone3, &args, sizeof(args));
    int error = child < 0 ? errno : 0;
    if (child == 0) {
        close(target);
        close(ready[0]);
        member("atomic-child-before-drop", getpid(), own + strlen(MOUNT));
        if (ready[1] != 3) {
            need(dup2(ready[1], 3) == 3, "install exec readiness fd");
            close(ready[1]);
        }
        need(fcntl(3, F_SETFD, 0) == 0, "readiness fd across exec");
        need(syscall(SYS_close_range, 4U, UINT_MAX, 0U) == 0, "close all other inherited fds");
        drop_to_guest();
        char *const child_argv[] = {(char *)binary, "--exec-payload", (char *)role,
                                    (char *)own, (char *)sibling, (char *)sink, NULL};
        char *const clean_env[] = {"PATH=/usr/bin:/bin", "LC_ALL=C", NULL};
        execve(binary, child_argv, clean_env);
        need(0, "execve payload");
    }
    close(target);
    close(ready[1]);
    printf("supervisor-clone3 role=%s errno=%d child=%ld pidfd=%d\n", role, error, child, held.fd);
    need(child > 0 && held.fd >= 0, "clone3 with cgroup and pidfd");
    held.pid = (pid_t)child;
    char byte;
    need(read(ready[0], &byte, 1) == 1 && byte == '"'"'R'"'"', "held exec payload readiness");
    close(ready[0]);
    still_held(held.fd);
    member("supervisor-held-exec-target", held.pid, own + strlen(MOUNT));
    return held;
}

static void kill_and_drain(const char *leaf, struct held target)
{
    need(cg_put("root-supervisor-cgroup-kill", leaf, "cgroup.kill", "1") == 0,
         "supervisor can kill exact leaf");
    need(reap(target.fd, target.pid, "root-supervisor-held-result") == 128 + SIGKILL,
         "target exited by SIGKILL");
    no_processes(leaf);
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    if (argc > 1 && strcmp(argv[1], "--exec-payload") == 0) {
        payload_main(argc, argv);
        return 99;
    }
    need(argc == 2 && geteuid() == 0 && getegid() == 0, "system-scope supervisor");
    const char *prefix = "ptg-linux-root-owned-";
    size_t n = strlen(argv[1]);
    need(n > strlen(prefix) + 6 && n < 100 &&
         strncmp(argv[1], prefix, strlen(prefix)) == 0 &&
         strcmp(argv[1] + n - 6, ".scope") == 0 &&
         strspn(argv[1], "abcdefghijklmnopqrstuvwxyz0123456789.-") == n, "dedicated scope ID");
    char suffix[MAX_PATH], scope[MAX_PATH], binary[MAX_PATH], expected[MAX_PATH];
    snprintf(suffix, sizeof(suffix), "%s%s", SCOPE_PREFIX, argv[1]);
    snprintf(scope, sizeof(scope), "%s%s%s", MOUNT, SCOPE_PREFIX, argv[1]);
    snprintf(expected, sizeof(expected), "/tmp/%.*s/proof", (int)n - 6, argv[1]);
    ssize_t len = readlink("/proc/self/exe", binary, sizeof(binary) - 1);
    need(len > 0 && (size_t)len < sizeof(binary) - 1, "read trusted proof executable path");
    binary[len] = '"'"'\0'"'"';
    need(strcmp(binary, expected) == 0, "trusted executable path");
    member("verify-fresh-root-scope", getpid(), suffix);
    root_owned(scope, 1);
    root_owned(binary, 0);
    struct statfs fs;
    need(statfs(scope, &fs) == 0 && fs.f_type == CGROUP2_SUPER_MAGIC, "scope cgroup2 filesystem");
    char path[MAX_PATH], state[128];
    join(path, scope, "cgroup.stat");
    read_text(path, state, sizeof(state));
    printf("before-leaves %s", state);
    need(strncmp(state, "nr_descendants 0\n", 17) == 0, "scope already has child cgroups");
    join(path, scope, "cgroup.procs");
    root_owned(path, 0);
    char payload[MAX_PATH], sibling[MAX_PATH], sink[MAX_PATH];
    join(payload, scope, "payload");
    join(sibling, scope, "sibling");
    join(sink, scope, "sink");
    umask(022);
    need(mkdir(payload, 0755) == 0 && mkdir(sibling, 0755) == 0 && mkdir(sink, 0755) == 0,
         "create exact dedicated leaves");
    root_owned(payload, 1);
    root_owned(sibling, 1);
    root_owned(sink, 1);
    for (size_t i = 0; i < sizeof(controls) / sizeof(controls[0]); ++i) {
        join(path, payload, controls[i]);
        root_owned(path, 0);
        join(path, sibling, controls[i]);
        root_owned(path, 0);
    }
    join(path, sink, "cgroup.procs");
    need(chown(path, payload_uid, payload_gid) == 0, "allow exact sink path for migration control");
    struct stat sink_info;
    need(lstat(path, &sink_info) == 0 && sink_info.st_uid == payload_uid &&
         sink_info.st_gid == payload_gid && (sink_info.st_mode & S_IWUSR), "sink permissions");
    printf("writable-sink uid=%u gid=%u mode=%04o path=%s\n",
           sink_info.st_uid, sink_info.st_gid, sink_info.st_mode & 07777, path);
    struct held canary = launch(binary, "canary", sibling, payload, sink);
    struct held target = launch(binary, "payload", payload, sibling, sink);
    still_held(canary.fd);
    kill_and_drain(payload, target);
    still_held(canary.fd);
    member("sibling-survived-target-kill", canary.pid, sibling + strlen(MOUNT));
    kill_and_drain(sibling, canary);
    no_processes(sink);
    printf("proof-verdict=passed\n");
    return 0;
}
PTG_ROOT_OWNED_SOURCE
/usr/bin/sha256sum "$scratch/root-owned.c"
/usr/bin/gcc --version | /usr/bin/sed -n '"'"'1p'"'"'
TMPDIR="$scratch" /usr/bin/gcc -std=gnu11 -Wall -Wextra -Werror -O2 "$scratch/root-owned.c" -o "$scratch/proof"
/usr/bin/chmod 0755 -- "$scratch" "$scratch/proof"
/usr/bin/sha256sum "$scratch/proof"
"$scratch/proof" "$unit"
'