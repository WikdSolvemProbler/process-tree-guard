import importlib.util
from pathlib import Path
import runpy
import sys
import unittest

work = Path(__file__).resolve().parent
campaign = work / 'checkout/tests/campaign'
sys.path[:0] = [str(campaign), str(work / 'checkout/tests/tests')]
mode, action, *args = sys.argv[1:]
if mode == 'baseline':
    spec = importlib.util.spec_from_file_location('report', campaign / 'report.py')
    module = importlib.util.module_from_spec(spec)
    sys.modules['report'] = module
    exec(compile((work / 'baseline-report.py').read_bytes(), spec.origin, 'exec'), module.__dict__)
else:
    assert mode == 'candidate'
if action == 'test':
    unittest.main(module=None, argv=[sys.argv[0], '-v', *args])
else:
    assert action == 'report' and not args
    harness = str(campaign / 'harness.py')
    sys.argv = [harness, 'report', '--out', str(work / 'capture')]
    runpy.run_path(harness, run_name='__main__')

