# Windows survivor report replay

The report replay used the preserved 1,940-slot observed-load Windows
campaign. It compared the normal report entry point with the source at
accadc289e2501f444ba51976246d8c2417de4e1 and the candidate formatter at
88f5a6db8ae4041389fb0de2b7c37e57edd3ba39 in the same checkout and launch
context. The captured observations, pricing observations, and manifest
were identical bytes in both replays.

Exactly 32 survivor labels changed: 24 measured and eight warmup scaling
slots. All other report lines were identical, including the incomplete
verdict and 44 standing losses. The first verifier counted the report's
trailing blank line as a loss; its terminal and the corrected verifier
are preserved. The replay did not execute any campaign workloads.

The focused native Linux and macOS logs cover the initial test packaging.
Commit 74629530534669ced29978b0f5a5a423586c404a places the same assertions
in the existing test, preserving the published 647-case census. The
Windows focused receipts include the originally reproduced failure and
the passing merged test plus the four census assertions.

To reproduce, place a clean LF export of the baseline commit in checkout/
beside replay.py. Copy its tests/campaign/report.py to baseline-report.py,
then apply candidate.patch inside checkout/. Extract the three complete/
entries run.json, observations.jsonl and pricing-observations.jsonl from the
original campaign ZIP into capture/ beside replay.py. Under a finite tree
deadline, invoke replay.py with baseline report or candidate report and
capture UTF-8 stdout separately. Run verify-replay-v2.py from the repository
root against those reports and the original archive.
