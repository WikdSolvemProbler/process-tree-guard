from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

work = Path(__file__).resolve().parent
archive = Path('tests/evidence/windows-campaign-20261106.zip')
archive_hash = sha256(archive.read_bytes()).hexdigest()
assert archive_hash == 'ef653c4fb2921adc9e466f767225ba257b26e0b9adecf354b8000f30ccf751bd'
with ZipFile(archive) as z:
    for path in sorted((work / 'capture').iterdir()):
        assert path.read_bytes() == z.read('complete/' + path.name)
rows = [json.loads(line) for line in (work / 'capture/observations.jsonl').read_bytes().splitlines()]
losses = [row for row in rows if (row['arm'], row['path'], row['outcome'])
          == ('nuewframe', 'scale', 'descendant-survived')]
assert len(rows) == 1940 and len(losses) == 32
old = (work / 'baseline-report.txt').read_text(encoding='utf-8').splitlines()
new = (work / 'candidate-report.txt').read_text(encoding='utf-8').splitlines()
old_status = next(line for line in old if line.startswith('STATUS:'))
new_status = next(line for line in new if line.startswith('STATUS:'))
assert old_status == new_status and 'INCOMPLETE CAMPAIGN' in old_status
assert old.index('Standing losses:') == new.index('Standing losses:')
for report in (old, new):
    assert sum(line.startswith('  - ') for line in report[report.index('Standing losses:') + 1:]) == 44
observed = [(before, after) for before, after in zip(old, new, strict=True) if before != after]
expected = [(
    f"  - nuewframe kill path left a descendant alive in {row['context']} rep {row['rep']}",
    f"  - nuewframe scale path left a descendant alive in {row['context']} "
    f"({row['kind']} rep {row['rep']} variant {row['variant']})",
) for row in losses]
assert observed == expected, (len(observed), observed[:2])
record = {
    'archive_sha256': archive_hash,
    'slots': len(rows),
    'standing_losses': 44,
    'changed_labels': len(observed),
    'warmup_scale_labels': sum(row['kind'] == 'warmup' for row in losses),
    'measured_scale_labels': sum(row['kind'] == 'measured' for row in losses),
    'status': old_status,
    'report_sha256': {mode: sha256((work / f'{mode}-report.txt').read_bytes()).hexdigest()
                      for mode in ('baseline', 'candidate')},
}
(work / 'replay-verification.json').write_text(json.dumps(record, indent=2) + '\n',
                                               encoding='utf-8')
print(json.dumps(record, indent=2))

