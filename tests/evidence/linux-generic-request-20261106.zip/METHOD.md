# Linux generic request prototype

The prototype defines a bounded request body for the one-shot Linux activation design. It parses byte strings and prepares owned, NUL-terminated argument buffers and the corresponding pointer array. The test program performs no process launch, credential transition, cgroup operation, or socket exchange.

## Wire shape

The byte layout is the six ASCII bytes PTGEX2, an eight-byte little-endian binary64 timeout in seconds, and a two-byte little-endian argument count. Each argument consists of a four-byte little-endian byte length followed by those exact bytes. Trailing bytes are refused. The full packet limit is 128 KiB and the argument count limit is 4,096. Both are prototype bounds that require native transport and product-interface qualification.

The first argument must contain at least one byte. Later arguments may be empty. Arguments preserve their native bytes, including non-UTF-8 sequences, spaces and delimiters. An embedded NUL is refused. The decoder owns the resulting C strings independently of the packet's lifetime. The pointer array has one final null pointer.

The numeric policy is the repository's src/deadline.rs. Conversion uses Rust's Duration representation. An accepted positive value that rounds to zero becomes one nanosecond, because an all-zero timerfd expiration disarms the timer. The 86,400-second cap remains exact.

## Receiver boundary

The archived external-admission receiver first obtains the accepted socket's SO_PEERCRED. Its recvmsg call collects per-packet SCM_CREDENTIALS and one transferred pidfd with MSG_CMSG_CLOEXEC. For a derivative receiver, use the fixed packet limit, retain all acquired descriptors in owned handles, and refuse MSG_TRUNC, MSG_CTRUNC, inconsistent or unsupported ancillary records, and any reported body length outside the receive buffer. Check the accepted and per-packet credentials and the actual held pidfd against each other and the existing kernel-backed identity rules before decoding the request. The new magic is distinct from the fixed PTGEX1 fixture.

Only the verified kernel identity supplies UID, GID, and groups. The new body carries no privilege, controller path, inherited handle, working directory, environment, or executable authority. Establish a checked absolute CLOCK_BOOTTIME deadline before allocating a payload scope, and retain both the deadline and held owner across placement and release. Any future command resolution or exec belongs in the atomically placed child after it has dropped privileges, enabled NoNewPrivs, and received the verified permit. Prebuild the argument strings and pointer array before cloning.

This source tests the request body and exec preparation. Socket truncation, activation, CWD, environment, stdio, owner-loss behavior with this packet, concurrent lifecycle, and the Linux 5.14 floor remain unqualified. The currently published product retains its unsupported-backend refusal.
