# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Peter Shiller
import hashlib,json,pathlib,sys,zipfile
HERE=pathlib.Path(__file__).resolve().parent
def sha(data):return hashlib.sha256(data).hexdigest()
raw=(HERE/'package-spec.json').read_bytes()
if len(sys.argv)!=2 or sha(raw)!=sys.argv[1]:raise SystemExit('package-spec hash mismatch')
spec=json.loads(raw);buffers={};index={}
for name,pin in spec['files'].items():
 p=pathlib.Path(pin['source'])
 if p.is_symlink() or not p.is_file():raise SystemExit('nonregular source '+name)
 data=p.read_bytes()
 if len(data)!=pin['bytes'] or sha(data)!=pin['sha256']:raise SystemExit('source changed '+name)
 buffers[name]=data;index[name]=pin
for name,value in [('RESULTS.json',spec['result']),('publication/package-spec.json',spec)]:
 data=(json.dumps(value,indent=2)+'\n').encode();buffers[name]=data;index[name]={'bytes':len(data),'sha256':sha(data),'source':None}
buffers['INDEX.json']=(json.dumps(index,indent=2)+'\n').encode()
output=pathlib.Path(spec['output'])
with output.open('xb')as target:
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
  for name,data in sorted(buffers.items()):archive.writestr(name,data)
with zipfile.ZipFile(output)as archive:
 if archive.testzip()is not None or set(archive.namelist())!=set(buffers):raise SystemExit('zip integrity/coverage failed')
 for name,data in buffers.items():
  if archive.read(name)!=data:raise SystemExit('zip byte mismatch '+name)
for name,pin in spec['files'].items():
 if sha(pathlib.Path(pin['source']).read_bytes())!=pin['sha256']:raise SystemExit('late source mutation '+name)
receipt={'archive_sha256':sha(output.read_bytes()),'bytes':output.stat().st_size,'members':len(buffers),'indexed_members':len(index),'integrity_verified':True,'pure21_passed':True,'pure24_passed':True,'native_or_comparative_qualification':False,'benchmark_slots':0}
with(HERE/'publication-receipt-001.json').open('x')as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
