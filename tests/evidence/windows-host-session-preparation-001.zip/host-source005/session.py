"""SOURCE ONLY: finite descriptive host-session orchestrator; execution disabled."""
import argparse
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import types

HERE = Path(__file__).resolve().parent

def bootstrap(approved):
    raw = (HERE / "implementation.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != approved: raise ValueError("unapproved exact implementation")
    plan = json.loads(raw)
    source = (HERE / "common.py").read_bytes()
    if hashlib.sha256(source).hexdigest() != plan["source_sha256"]["common.py"]: raise ValueError("common differs")
    common = types.ModuleType("supplement_common"); common.__file__ = str(HERE / "common.py")
    sys.modules[common.__name__] = common
    exec(compile(source, common.__file__, "exec"), common.__dict__)
    return plan, common

class Observer:
    """Owned finite thread. Lock prevents stamp/arm overlap, never selects low load."""
    def __init__(self, sampler, gate, out, deadline):
        self.sampler, self.gate, self.out, self.deadline = sampler, gate, out, deadline
        self.lock = threading.Lock(); self.stop = threading.Event(); self.busy = False
        self.origin = time.perf_counter_ns(); self.next_index = 1
        self.events = []; self.error = None
        self.thread = threading.Thread(target=self.run, name="supplement-finite-observer", daemon=False)
    def emit(self, row):
        self.out.write(json.dumps(row, allow_nan=False, ensure_ascii=True) + "\n"); self.out.flush()
        self.events.append(row)
    def stamp(self, kind, index):
        begin = time.perf_counter_ns()
        try:
            sample = self.sampler.stamp()
            self.emit({"kind": kind, "index": index, "scheduled_ns": self.origin + index * 5_000_000_000,
                       "begin_ns": begin, "end_ns": time.perf_counter_ns(), "raw": asdict(sample),
                       "native_errors": self.gate.sample_errors(sample, during=False),
                       "scope": "aggregate system accounting includes arms; no census/primary admission"})
        except BaseException as error:
            self.emit({"kind": "observer_error", "index": index, "begin_ns": begin,
                       "end_ns": time.perf_counter_ns(), "type": type(error).__name__, "error": str(error)})
    def run(self):
        try:
            while not self.stop.is_set():
                due = self.origin + self.next_index * 5_000_000_000
                remaining = min(due, self.deadline) - time.perf_counter_ns()
                if remaining > 0 and self.stop.wait(remaining / 1e9): return
                now = time.perf_counter_ns()
                if now >= self.deadline: return
                with self.lock:
                    # No catch-up bursts. Every missed boundary gets its own
                    # gap record; only current scheduled work can sample.
                    while due + 5_000_000_000 <= now:
                        self.emit({"kind": "observer_skipped", "index": self.next_index,
                                   "scheduled_ns": due, "observed_ns": now, "reason": "dispatcher_delayed"})
                        self.next_index += 1; due += 5_000_000_000
                    if self.busy:
                        self.emit({"kind": "observer_skipped", "index": self.next_index,
                                   "scheduled_ns": due, "observed_ns": now, "reason": "whole_arm_active"})
                    else: self.stamp("sample", self.next_index)
                    self.next_index += 1
        except BaseException as error: self.error = {"type": type(error).__name__, "message": str(error)}
    def set_busy(self, value):
        with self.lock: self.busy = value
    def start(self):
        with self.lock: self.stamp("initial", 0)
        self.thread.start()
    def close(self, remaining):
        self.stop.set(); self.thread.join(max(0, remaining))
        if self.thread.is_alive(): raise TimeoutError("observer did not join; outer session guard must settle")
        with self.lock: self.stamp("terminal", self.next_index)

def bounded_json(path, maximum=1024 * 1024):
    with Path(path).open("rb") as source: raw = source.read(maximum + 1)
    if len(raw) > maximum: raise ValueError("JSON evidence exceeds bound")
    return json.loads(raw), hashlib.sha256(raw).hexdigest()


def worker_cleanup_uncertain(worker):
    if worker is None: return False
    jobs = worker.get("jobs")
    if not isinstance(jobs, list) or len(jobs) != 1: return True
    for job in jobs:
        drain = job.get("drain")
        if (job.get("closed") is not True or "close_error" in job
                or not isinstance(drain, dict) or type(drain.get("active_after")) is not int
                or drain["active_after"] != 0 or "error" in drain): return True
    record = worker.get("record")
    if record is not None:
        isolated = record.get("slot_job", {})
        if (type(isolated.get("active_after")) is not int
                or isolated["active_after"] != 0 or "error" in isolated): return True
    return False

def dispatcher_stop(local_safety, failures, classification, worker):
    # Outer cleanup cannot waive uncertain inner custody. Used by actual loop.
    if local_safety or classification.get("category") == "safety_abort" or worker_cleanup_uncertain(worker):
        return "safety_abort"
    return "controller_failure" if failures else None


def verify_retained_outputs(c, arm, record, spec, event_bundle, read_artifact):
    """Return only after all required evidence has been read and checked.

    read_artifact is the actual bounded reader in main. No earlier partial
    success can survive a later event-file read or metadata error.
    """
    blobs = {label: read_artifact(label + ".bin") for label in ("stdout", "stderr")}
    streams_verified = c.output_record_valid(record, blobs, spec)
    if arm != "processkit": return streams_verified, False
    if (not isinstance(event_bundle, dict) or event_bundle.get("capture_complete") is not True
            or event_bundle.get("capture_failed") is not False
            or event_bundle.get("namespace_inspected") is not True):
        return False, False
    files = event_bundle.get("files")
    c.demand(isinstance(files, list) and len(files) <= 2, "event capture index differs")
    retained = []
    for index, item in enumerate(files):
        name = "processkit-events-%03d.bin" % index
        c.demand(isinstance(item, dict) and item.get("artifact") == name, "event artifact name differs")
        data = read_artifact(name)
        c.demand(isinstance(data, bytes) and len(data) <= c.MAX_BYTES
                 and type(item.get("bytes")) is int and item["bytes"] == len(data)
                 and item.get("sha256") == c.sha(data), "event artifact receipt differs")
        retained.append(data)
    event_bad = len(retained) != 1 or not c.event_contract_valid(retained[0], record)
    return streams_verified, event_bad

def disposition(worker, guard_exit, operation_overrun, presentation=None, presentation_verified=False, output_verified=False, retained_event_contract_failed=False):
    # Preserve canonical label/details; this is additive raw-fact classification.
    record = None if worker is None else worker.get("record")
    result = {"canonical_outcome": None if record is None else record.get("outcome"),
              "correctness": "unverified", "timing_valid": False, "utility_seconds": None}
    if worker_cleanup_uncertain(worker):
        result.update(category="safety_abort", reason="inner Job drain/close custody uncertain"); return result
    if record is None:
        result["category"] = "observed_noncompletion" if guard_exit == 124 else "instrument_uninterpretable"
        result["reason"] = "guard deadline, no complete worker record" if guard_exit == 124 else "missing worker record"
        if presentation_verified is True and guard_exit == 124:
            result["utility_seconds"] = 45
            result["reason"] = "validated presentation receipt followed by guardian deadline; cause unspecified"
        return result
    isolated = record.get("slot_job", {})
    if isolated.get("active_after") != 0 or "error" in isolated:
        result.update(category="safety_abort", reason="inner Job did not prove empty"); return result
    event_facts = worker.get("event_evidence") or {}
    failures = worker.get("failures", [])
    capture = worker.get("capture_errors", [])
    elapsed = record.get("elapsed_ms")
    time_ok = (type(elapsed) in (int, float) and not isinstance(elapsed, bool)
               and 0 <= elapsed < float("inf") and not operation_overrun)
    result["timing_valid"] = time_ok
    if len(worker.get("launches", [])) != 1:
        result.update(category="observed_spawn_failure", reason="no successful presentation receipt")
        return result
    if "spawn failed:" in str(record.get("detail", "")):
        category = "observed_spawn_failure"
    elif "exceeded its 30 s harness deadline" in str(record.get("detail", "")):
        category = "observed_noncompletion"
    elif record.get("exit_code") is not None and record["exit_code"] != 0:
        category = "observed_incorrect_completion"
    elif retained_event_contract_failed is True or event_facts.get("contract_failure"):
        category = "observed_incorrect_completion"
    elif capture or failures:
        category = "instrument_uninterpretable"
    elif output_verified is not True and record.get("exit_code") == 0:
        category = "instrument_uninterpretable"
    elif (output_verified is True and record.get("exit_code") == 0 and record.get("output_stdout_match") is True
          and record.get("output_stderr_match") is True):
        category = "correct_completion"
    elif record.get("exit_code") is not None:
        category = "observed_incorrect_completion"
    else: category = "instrument_uninterpretable"
    result["category"] = category
    if category == "correct_completion":
        result["correctness"] = "correct"
        if time_ok: result["utility_seconds"] = min(elapsed / 1000, 45)
    elif category in ("observed_spawn_failure", "observed_noncompletion", "observed_incorrect_completion"):
        result["correctness"] = "observed_adverse_cause_unspecified"
        result["utility_seconds"] = 45
    if presentation_verified is not True:
        result["utility_seconds"] = None
        result["timing_valid"] = False
        if result["category"] == "correct_completion":
            result.update(category="instrument_uninterpretable", correctness="unverified")
        result["presentation_unverified"] = True
    return result

def main(approved, destination):
    session_entry = time.perf_counter_ns()
    plan, c = bootstrap(approved)
    c.demand(plan["approved_for_execution"] is True, "source-only draft refuses execution")
    for name, pin in plan["source_sha256"].items(): c.checked(HERE / name, pin)
    c.demand(Path(sys.executable).samefile(c.PYTHON), "unsealed interpreter")
    index, config, captured = c.input_bindings()
    modules = c.frozen_modules(captured)
    effective, env_facts = c.environment()
    # Effective override occurs before observer or child work, never host-global.
    os.environ.clear(); os.environ.update(effective)
    output_root = Path(destination).absolute()
    output_root.mkdir()  # exclusive; no adoption/reuse/delete of prior evidence
    rows = c.schedule()
    schedule_raw = c.checked(HERE / "schedule.json", plan["schedule_sha256"])
    c.demand(c.encode(rows)+b"\n" == schedule_raw, "materialized source schedule differs")
    c.exclusive_json(output_root / "assignments.json", rows)
    for row in rows:
        directory = output_root / row["assignment_id"]; directory.mkdir()
        c.exclusive_json(directory / "assignment.json", row)
    start = session_entry; finish = start + 3_600_000_000_000
    last_work = finish - 60_000_000_000
    prep_ns = 0; arm_accounted_ns = 0; records = []; safety_abort = False; stop_reason = None
    session_job_module = modules["windows_slot_job"]
    # Frozen sampler code and its imports must be bound by final implementation.
    fixed = HERE.with_name("issue7-quiet-launch-013")
    for name in ("quiet_gate", "quiet_sampler"):
        raw = c.checked(fixed / (name + ".py"), plan["observer_sha256"][name + ".py"])
        c.module(name, fixed / (name + ".py"), raw)
    with ((output_root / "session.jsonl").open("x", encoding="utf-8") as out,
          (output_root / "observer.jsonl").open("x", encoding="utf-8") as observer_out):
        def emit(kind, **facts):
            out.write(json.dumps({"kind": kind, **facts}, allow_nan=False, ensure_ascii=True) + "\n"); out.flush()
        observer = Observer(sys.modules["quiet_sampler"], sys.modules["quiet_gate"], observer_out, last_work)
        emit("context", implementation_sha256=approved, schedule_sha256=c.sha(c.encode(rows)+b"\n"),
             environment=env_facts, candidate_inputs_sha256=c.CANDIDATE_INPUT_SHA,
             candidate_binding=index["supplement_candidate"],
             assigned=66, measured=60, warmup=6, primary_admission="NOT_EVALUATED",
             session_deadline_ns=finish, stop_work_ns=last_work, max_setup_observer_ns=240_000_000_000,
             scope="descriptive only; no CI/win/tie/certificate; no process census")
        observer.start()
        try:
            for row in rows:
                prep_ns = time.perf_counter_ns() - session_entry - arm_accounted_ns
                if time.perf_counter_ns() + 50_000_000_000 > last_work or prep_ns >= 240_000_000_000:
                    stop_reason = "administrative_budget"; break
                directory = output_root / row["assignment_id"]
                prep_begin = time.perf_counter_ns()
                boundary = c.ArmBoundary(prep_begin)
                guardian_job = session_job_module.SlotJob()
                guardian = None; ready = None; ready_received = None; arm_begin = None
                worker_value = None; worker_sha = None; guard_exit = None; drain = None; presentation = None
                presentation_verified = False; output_verified = False; retained_event_contract_failed = False
                failures = []; overrun = False
                try:
                    with ((directory / "guardian.stdout").open("xb") as stdout,
                          (directory / "guardian.stderr").open("xb") as stderr):
                        command = [str(c.GUARD), "--timeout", "45", "--", str(c.PYTHON), "-I", "-B",
                                   str(HERE / "worker.py"), "--implementation-sha", approved,
                                   "--assignment", str(directory / "assignment.json")]
                        # Python subprocess stdin PIPE is not available in SlotJob;
                        # an owned OS pipe is created and only reader inherited.
                        reader_fd, writer_fd = os.pipe()
                        try:
                            with os.fdopen(reader_fd, "rb", buffering=0) as gate_reader:
                                guardian = guardian_job.launch(command, creationflags=0x08000000,
                                    stdin=gate_reader, stdout=stdout, stderr=stderr)
                            preparation_deadline = min(prep_begin + 10_000_000_000, last_work)
                            while time.perf_counter_ns() < preparation_deadline:
                                with (directory / "guardian.stdout").open("rb") as source: first = source.readline(65537)
                                if first.endswith(b"\n"):
                                    c.demand(len(first) <= 65536, "READY exceeds bound")
                                    ready = json.loads(first)
                                    c.demand(ready.get("kind") == "ready" and type(ready.get("pid")) is int
                                        and ready["implementation_sha256"] == approved
                                        and ready["assignment_sha256"] == c.sha(c.encode(row)+b"\n")
                                        and c.encode(ready.get("assignment")) == c.encode(row),
                                        "invalid pinned worker READY")
                                    ready_received = time.perf_counter_ns()
                                    boundary.ready(ready_received)
                                    break
                                try:
                                    guard_exit = guardian.wait(0); break
                                except subprocess.TimeoutExpired: pass
                                time.sleep(.002)
                            c.demand(ready_received is not None, "prearm readiness absent; assignment not attempted")
                            prep_ns = ready_received - session_entry - arm_accounted_ns
                            c.demand(prep_ns < 240_000_000_000, "setup budget exhausted before gate")
                            observer.set_busy(True)
                            arm_begin = time.perf_counter_ns()
                            boundary.gate(arm_begin)
                            os.write(writer_fd, b"G\n")
                        finally: os.close(writer_fd)
                        # READY follows guard's own pre-spawn deadline anchor.
                        # No dependence on unchecked guard startup for this arm.
                        arm_deadline = ready_received + 50_000_000_000
                        while True:
                            try:
                                guard_exit = guardian.wait(max(0, min(.05, (arm_deadline-time.perf_counter_ns())/1e9)))
                                break
                            except subprocess.TimeoutExpired:
                                if time.perf_counter_ns() >= arm_deadline:
                                    overrun = True; raise TimeoutError("whole-arm observation exceeded50s")
                        if (directory / "presented.json").exists():
                            presentation, _ = bounded_json(directory / "presented.json")
                        if (directory / "worker-result.json").exists():
                            worker_value, worker_sha = bounded_json(directory / "worker-result.json")
                        if presentation is not None:
                            expected_argv = modules["runner"].fast_workload_argv(row["arm"], c.absolute_config(config, directory))
                            if row["arm"] == "processkit":
                                position = expected_argv.index("{event_log}")
                                event_path = Path(presentation["argv"][position])
                                c.demand(event_path.name == "events.jsonl" and event_path.parent.parent == directory / "processkit-events",
                                         "presented event path differs")
                                expected_argv[position] = str(event_path)
                            expected_stdin = config["children"]["fast"]["stdin"].encode()
                            with (directory / "stdin.bin").open("rb") as retained:
                                stdin_bytes = retained.read(c.MAX_BYTES+1)
                            expected = {"argv": expected_argv, "flags": modules["runner"].creation_flags("NO_WINDOW"),
                                        "cwd": str(c.TESTS), "environment_sha256": env_facts["effective_sha256"],
                                        "stdin_sha256": c.sha(expected_stdin), "stdin_bytes": len(expected_stdin)}
                            presentation_verified = (stdin_bytes == expected_stdin and
                                c.presentation_valid(row, presentation, expected, worker_value))
                            c.demand(presentation_verified, "presentation/assignment evidence differs")
                            if worker_value is not None and worker_value.get("record") is not None:
                                def read_artifact(name):
                                    with (directory / name).open("rb") as artifact:
                                        return artifact.read(c.MAX_BYTES + 1)
                                # Tuple assignment occurs only after the complete
                                # verifier returns; a later I/O error preservesFalse.
                                output_verified, retained_event_contract_failed = verify_retained_outputs(
                                    c, row["arm"], worker_value["record"], config["children"]["fast"],
                                    worker_value.get("event_evidence"), read_artifact)
                except BaseException as error: failures.append(c.error_record(error))
                finally:
                    try: drain = guardian_job.drain()
                    except BaseException as error:
                        failures.append(c.error_record(error)); safety_abort = True
                    finally:
                        if guardian is not None:
                            try: guardian.close()
                            except BaseException as error:
                                failures.append(c.error_record(error)); safety_abort = True
                        try: guardian_job.close()
                        except BaseException as error:
                            failures.append(c.error_record(error)); safety_abort = True
                    end = time.perf_counter_ns()
                    if ready_received is not None and end >= ready_received + 50_000_000_000: overrun = True
                    if arm_begin is not None and not boundary.finish(end, drain): safety_abort = True
                    if overrun: safety_abort = True
                    facts = {"assignment": row, "attempted": arm_begin is not None,
                             "prep_begin_ns": prep_begin, "ready_received_ns": ready_received,
                             "arm_gate_ns": arm_begin, "settled_observed_ns": end,
                             "guardian_exit": guard_exit, "guardian_cleanup": drain,
                             "operation_overrun": overrun, "worker_result_sha256": worker_sha,
                             "worker_result": worker_value, "presentation": presentation, "presentation_verified": presentation_verified, "output_verified": output_verified,
                             "retained_event_contract_failed": retained_event_contract_failed, "errors": failures,
                             "disposition": disposition(worker_value, guard_exit, overrun, presentation, presentation_verified, output_verified, retained_event_contract_failed)}
                    if arm_begin is None: facts["disposition"] = {"category": "not_attempted", "utility_seconds": None}
                    records.append(facts); emit("assignment", **facts)
                    # Whole-arm operation includes parent evidence reads, outer
                    # drain/close and full assignment serialization/flush.
                    serialization_end = time.perf_counter_ns()
                    if ready_received is not None:
                        arm_accounted_ns += serialization_end - ready_received
                    if arm_begin is not None and not boundary.finish(serialization_end, drain):
                        safety_abort = True
                        facts["operation_overrun"] = True
                        facts["disposition"] = disposition(worker_value, guard_exit, True, presentation, presentation_verified, output_verified, retained_event_contract_failed)
                    observer.set_busy(False)
                    outside_observed = time.perf_counter_ns()
                    prep_ns = outside_observed - session_entry - arm_accounted_ns
                    if prep_ns >= 240_000_000_000 or outside_observed >= last_work:
                        failures.append({"type":"TimeoutError","message":"outside-arm budget or final tail reached"})
                    facts["serialization_end_ns"] = serialization_end
                    emit("assignment_endpoint", assignment_id=row["assignment_id"],
                         serialization_end_ns=serialization_end, outside_observed_ns=outside_observed,
                         outside_wall_ns=prep_ns, outside_budget_ns=240_000_000_000,
                         safety_abort=safety_abort, final_disposition=facts["disposition"],
                         operation_overrun=facts["operation_overrun"],
                         scope="assignment JSON flush included in50s; endpoint report/unlock and all other non-arm work charged to240s")
                decision = dispatcher_stop(safety_abort, failures, facts["disposition"], worker_value)
                if decision is not None:
                    stop_reason = decision
                    safety_abort = safety_abort or decision == "safety_abort"
                    break
        except BaseException as error:
            safety_abort = True; stop_reason = "controller_failure"
            emit("controller_error", error=c.error_record(error))
        finally:
            try: observer.close((finish-time.perf_counter_ns())/1e9)
            except BaseException as error:
                safety_abort = True; stop_reason = "observer_join_or_terminal_failure"
                emit("observer_failure", error=c.error_record(error))
            done_ids = {r["assignment"]["assignment_id"] for r in records}
            for row in rows:
                if row["assignment_id"] not in done_ids:
                    emit("not_attempted", assignment=row, reason=stop_reason or "session_stopped", utility_seconds=None)
            emit("terminal", completed_schedule=len(records)==66 and all(r["attempted"] for r in records),
                 assigned=66, attempted=sum(r["attempted"] for r in records), recorded=len(records),
                 stop_reason=stop_reason, safety_abort=safety_abort, observer_error=observer.error,
                 observed_ns=time.perf_counter_ns(), deadline_ns=finish,
                 primary_admission="NOT_EVALUATED", phase_qualified=False, campaign_qualified=False,
                 scope="raw descriptive session; separate offline audit/summary required")
    return 1 if safety_abort or stop_reason or time.perf_counter_ns() >= finish else 0

if __name__ == "__main__":
    p = argparse.ArgumentParser(); p.add_argument("--implementation-sha", required=True)
    p.add_argument("--destination", required=True)
    a = p.parse_args(); raise SystemExit(main(a.implementation_sha, a.destination))
