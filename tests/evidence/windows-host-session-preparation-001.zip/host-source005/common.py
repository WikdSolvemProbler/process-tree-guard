"""Source-only supplement constants, schedule and bounded evidence primitives."""
import hashlib
import json
import os
from pathlib import Path
import types
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
FROZEN = HERE.with_name("issue7-quiet-campaign-inputs-002")
CHECKOUT = FROZEN / "checkout"
TESTS = CHECKOUT / "tests"
INPUT_SHA = "0826dc5baff96d28d24f78184b53df03d7f248f3c970344bac86929d89e2f9b0"
CONFIG = "tests/campaign-sysprims-fast-warn.json"
CONFIG_SHA = "dbd53f039277755f40d9c3156e85c6e92a67a018778109f11e5effd71d1e2ce5"
GUARD = HERE.with_name("issue7-host-session-inputs-003") / "process-tree-guard.exe"
GUARD_SHA = "8fa4e58bb6becf3e3c4536557be187b2b4163498d37b55a5ee8c030846fe0cf0"
CANDIDATE_INPUT_SHA = "947c9be98694366a77cc7980eb550388e297285a6a394d0f5610d37a19e8a4c5"
PYTHON = Path("C:/Users/Peter/AppData/Local/Programs/Python/Python312/python.exe")
PYTHON_SHA = "4d6f5f81a4bca11191c4c7c6b43632694d0a4ce74e068619d8fdc161d469859a"
CELL_IDS = ("processkit", "nuewframe", "sysprims")
SEED = "20261107"
EVENT_API = HERE.with_name("issue7-native-image-verification-001") / "native_image.py"
EVENT_API_SHA = "8adc1aa23a2298c3adab9ca561b621e8dccca4e78e59407aea39b9b08a2b9440"
MAX_BYTES = 1024 * 1024
MAX_EVENT_ROWS = 1024
MAX_EVENT_LINE = 65536

def demand(value, message):
    if not value: raise ValueError(message)

def sha(raw): return hashlib.sha256(raw).hexdigest()

def checked(path, pin):
    raw = Path(path).read_bytes()
    demand(sha(raw) == pin, "pinned bytes differ: " + str(path))
    return raw

def encode(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                      separators=(",", ":")).encode("utf-8")

def exclusive_json(path, value):
    with Path(path).open("xb") as out:
        out.write(encode(value) + b"\n")
        out.flush()

def module(name, path, raw):
    value = types.ModuleType(name)
    value.__file__ = str(path)
    sys.modules[name] = value
    exec(compile(raw, str(path), "exec"), value.__dict__)
    return value

def priority(*parts): return hashlib.sha256("|".join((SEED, *map(str, parts))).encode()).digest()

def schedule():
    rows = []
    def pair(cell, kind, index, orientation):
        block = kind + "-" + cell + "-" + str(index)
        for position, letter in enumerate(orientation):
            rows.append({"assignment_id": "a%03d" % len(rows), "block_id": block,
                         "kind": kind, "cell": cell, "pair_index": index,
                         "position": position, "orientation": orientation,
                         "arm": "guard" if letter == "A" else cell})
    for cell in sorted(CELL_IDS, key=lambda c: (priority("warmup-cell", c), c)):
        orientation = "AB" if priority("warmup-order", cell)[0] % 2 == 0 else "BA"
        pair(cell, "warmup", 0, orientation)
    orientations = {}
    tokens = [a + str(i) for a in ("AB", "BA") for i in range(5)]
    for cell in CELL_IDS:
        orientations[cell] = sorted(tokens, key=lambda t: (priority("orientation", cell, t), t))
    for index in range(10):
        for cell in sorted(CELL_IDS, key=lambda c: (priority("round", index, c), c)):
            pair(cell, "measured", index, orientations[cell][index][:2])
    demand(len(rows) == 66 and sum(r["kind"] == "measured" for r in rows) == 60,
           "schedule count differs")
    return rows

def environment():
    inherited = dict(os.environ)
    effective = dict(inherited)
    removed = effective.pop("RUST_LOG", None)
    def fingerprint(value):
        return sha(encode(sorted(value.items())))
    return effective, {"inherited_sha256": fingerprint(inherited),
                       "effective_sha256": fingerprint(effective),
                       "removed_RUST_LOG_present": removed is not None,
                       "removed_RUST_LOG_sha256": None if removed is None else sha(removed.encode())}

def input_bindings():
    raw = checked(FROZEN / "inputs.json", INPUT_SHA)
    index = json.loads(raw)
    demand(index["config_sha256"] == CONFIG_SHA, "frozen profile differs")
    config_raw = checked(CHECKOUT / CONFIG, CONFIG_SHA)
    candidate_raw = checked(HERE / "candidate-inputs.json", CANDIDATE_INPUT_SHA)
    candidate = json.loads(candidate_raw)
    demand(candidate["candidate_sha256"] == candidate["guardian_sha256"] == GUARD_SHA
           and Path(candidate["candidate_path"]) == Path(candidate["guardian_path"]) == GUARD,
           "candidate/guardian identity differs")
    checked(GUARD, GUARD_SHA)
    checked(PYTHON, PYTHON_SHA)
    index["supplement_candidate"] = candidate
    loaded = {}
    for name in ("arms", "plan", "windows_slot_job", "runner"):
        relative = "tests/campaign/" + name + ".py"
        path = CHECKOUT / relative
        loaded[name] = checked(path, index["file_sha256"][relative])
    for relative in ("tests/build/process-tree-guard.exe", "tests/build/testkit.exe",
                     "tests/build/competitors/timeout.exe", "tests/build/competitors/processkit-cli.exe",
                     "tests/build/competitors/sysprims.exe"):
        checked(CHECKOUT / relative, index["file_sha256"][relative])
    return index, json.loads(config_raw), loaded

def frozen_modules(loaded):
    result = {}
    for name in ("arms", "plan", "windows_slot_job", "runner"):
        path = TESTS / "campaign" / (name + ".py")
        result[name] = module(name, path, loaded[name])
    return result

def absolute_config(config, assignment_dir):
    import copy
    value = copy.deepcopy(config)
    for spec in value["arms"].values():
        spec["executable"] = str((TESTS / spec["executable"].replace("\\", "/")).resolve())
    # Prospective current-binary substitution only; never mutate the frozen
    # checkout/profile or silently execute its preserved legacy guard.
    value["arms"]["guard"]["executable"] = str(GUARD)
    for spec in value["children"].values():
        path = Path(spec["program"])
        if not path.is_absolute(): spec["program"] = str((TESTS / spec["program"].replace("\\", "/")).resolve())
    value["_windows_slot_jobs"] = True
    value["_processkit_event_dir"] = str(assignment_dir / "processkit-events")
    return value

def error_record(error):
    return {"type": type(error).__name__, "message": str(error),
            "winerror": getattr(error, "winerror", None)}


class ArmBoundary:
    """Actual controller state; timing checks do not replace independent custody."""
    def __init__(self, preparation_begin):
        demand(type(preparation_begin) is int and preparation_begin >= 0, "invalid preparation clock")
        self.preparation_begin = preparation_begin
        self.ready_ns = self.gate_ns = self.end_ns = None
    def ready(self, observed):
        demand(self.ready_ns is None and type(observed) is int
               and self.preparation_begin <= observed < self.preparation_begin + 10_000_000_000,
               "late/repeated/invalid READY")
        self.ready_ns = observed
    def gate(self, observed):
        demand(self.ready_ns is not None and self.gate_ns is None and type(observed) is int
               and self.ready_ns <= observed < self.ready_ns + 50_000_000_000,
               "gate before READY or after whole-arm bound")
        self.gate_ns = observed
    def finish(self, observed, cleanup):
        self.end_ns = observed
        return (self.ready_ns is not None and self.gate_ns is not None and type(observed) is int
                and self.gate_ns <= observed < self.ready_ns + 50_000_000_000
                and isinstance(cleanup, dict) and type(cleanup.get("active_after")) is int
                and cleanup["active_after"] == 0 and "error" not in cleanup)


def planned_assignment(raw, directory_name):
    expected = next((r for r in schedule() if r["assignment_id"] == directory_name), None)
    demand(expected is not None and raw == encode(expected) + b"\n", "assignment differs from frozen schedule")
    return expected

def presentation_valid(assignment, presentation, expected, worker=None):
    if not isinstance(presentation, dict): return False
    keys = ("assignment", "assignment_sha256", "argv", "flags", "cwd", "environment_sha256", "stdin_sha256", "stdin_bytes")
    wanted = {"assignment": assignment, "assignment_sha256": sha(encode(assignment)+b"\n"), **expected}
    if any(k not in presentation or encode(presentation[k]) != encode(wanted[k]) for k in keys): return False
    if worker is not None:
        if encode(worker.get("assignment")) != encode(assignment): return False
        launches = worker.get("launches")
        if not isinstance(launches, list) or len(launches) != 1: return False
        if any(k not in launches[0] or encode(launches[0][k]) != encode(presentation[k]) for k in keys): return False
    return True

def opened_identity_before_read(expected, observed, regular, read):
    demand(expected == observed and regular is True, "opened stream identity/type differs before read")
    return read()


def output_record_valid(record, blobs, spec):
    if not isinstance(record, dict): return False
    for label in ("stdout", "stderr"):
        data = blobs.get(label)
        expected = spec.get("expected_" + label)
        if not isinstance(data, bytes) or len(data) > MAX_BYTES or not isinstance(expected, str): return False
        # Receipt consistency is separate from whether the actual bytes match.
        # A false match flag with correct bytes is instrumentation contradiction,
        # while honestly recorded wrong bytes are a reliable adverse fact.
        facts = {"sha256": sha(data), "len": len(data), "match": data == expected.encode()}
        if any(encode(record.get("output_"+label+"_"+k)) != encode(v) for k,v in facts.items()): return False
    return True


def event_contract_valid(data, record):
    if not isinstance(data,bytes) or len(data)>MAX_BYTES:return False
    lines=data.splitlines()
    if not 0<len(lines)<=MAX_EVENT_ROWS or any(len(line)>MAX_EVENT_LINE for line in lines):return False
    def unique(pairs):
        value={}
        for key,item in pairs:
            demand(key not in value,"duplicate event JSON key")
            value[key]=item
        return value
    try:
        rows=[json.loads(line,object_pairs_hook=unique) for line in lines]
        return (all(isinstance(row,dict) and type(row.get("schema_version")) is int and row["schema_version"]==1 for row in rows)
                and rows[0].get("event")=="run_started" and type(rows[0].get("pid")) is int
                and rows[0]["pid"]==record.get("arm_pid") and rows[-1].get("event")=="runner_exit"
                and type(rows[-1].get("code")) is int and rows[-1]["code"]==record.get("exit_code"))
    except (ValueError,TypeError,KeyError):return False
