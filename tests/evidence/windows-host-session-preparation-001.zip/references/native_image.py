"""Per-row shared-read Windows file evidence. No identity or digest cache."""
from contextlib import contextmanager
import ctypes
from ctypes import wintypes as w
import hashlib
import time

kernel = ctypes.WinDLL("kernel32", use_last_error=True)
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
GENERIC_READ = 0x80000000
FILE_READ_ATTRIBUTES = 0x80
SHARE_ALL = 1 | 2 | 4
OPEN_EXISTING = 3
FILE_ATTRIBUTE_DIRECTORY = 0x10
CHUNK = 65536


class BasicInfo(ctypes.Structure):
    _fields_ = [
        ("creation", ctypes.c_int64), ("access", ctypes.c_int64),
        ("write", ctypes.c_int64), ("change", ctypes.c_int64),
        ("attributes", w.DWORD),
    ]


class StandardInfo(ctypes.Structure):
    _fields_ = [
        ("allocation", ctypes.c_int64), ("end", ctypes.c_int64),
        ("links", w.DWORD), ("delete_pending", w.BYTE), ("directory", w.BYTE),
    ]


class IdInfo(ctypes.Structure):
    _fields_ = [("volume", ctypes.c_uint64), ("file_id", ctypes.c_ubyte * 16)]


if (ctypes.sizeof(BasicInfo), ctypes.sizeof(StandardInfo), ctypes.sizeof(IdInfo)) != (40, 24, 24):
    raise RuntimeError("unsupported Windows file metadata layout")
if (BasicInfo.attributes.offset, StandardInfo.delete_pending.offset,
        StandardInfo.directory.offset, IdInfo.file_id.offset) != (32, 20, 21, 8):
    raise RuntimeError("Windows file metadata offsets differ")


def bind(name, args, result):
    call = getattr(kernel, name)
    call.argtypes = args
    call.restype = result
    return call


create_file = bind("CreateFileW", [
    w.LPCWSTR, w.DWORD, w.DWORD, ctypes.c_void_p, w.DWORD, w.DWORD, w.HANDLE,
], w.HANDLE)
file_info = bind("GetFileInformationByHandleEx", [
    w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD,
], w.BOOL)
read_file = bind("ReadFile", [
    w.HANDLE, ctypes.c_void_p, w.DWORD, ctypes.POINTER(w.DWORD), ctypes.c_void_p,
], w.BOOL)
set_pointer = bind("SetFilePointerEx", [
    w.HANDLE, ctypes.c_int64, ctypes.POINTER(ctypes.c_int64), w.DWORD,
], w.BOOL)
close_handle = bind("CloseHandle", [w.HANDLE], w.BOOL)


def checked(value):
    if not value:
        raise ctypes.WinError(ctypes.get_last_error())


@contextmanager
def opened(path, access):
    # Null SECURITY_ATTRIBUTES creates a non-inheritable handle. Explicitly
    # share reads, writes and deletes instead of excluding other workers.
    handle = create_file(str(path), access, SHARE_ALL, None, OPEN_EXISTING, 0, None)
    if not handle or handle == INVALID_HANDLE_VALUE:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        yield handle
    finally:
        checked(close_handle(handle))


def metadata(handle):
    basic, standard, identity = BasicInfo(), StandardInfo(), IdInfo()
    checked(file_info(handle, 0, ctypes.byref(basic), ctypes.sizeof(basic)))
    checked(file_info(handle, 1, ctypes.byref(standard), ctypes.sizeof(standard)))
    checked(file_info(handle, 18, ctypes.byref(identity), ctypes.sizeof(identity)))
    if (standard.directory or basic.attributes & FILE_ATTRIBUTE_DIRECTORY
            or standard.delete_pending or standard.end < 0 or standard.allocation < 0
            or not any(identity.file_id)):
        raise ValueError("image is not an identified regular file")
    return {
        "volume": identity.volume, "file_id_128": bytes(identity.file_id).hex(),
        "size": standard.end, "allocation": standard.allocation, "links": standard.links,
        "creation_ticks": basic.creation, "write_ticks": basic.write,
        "change_ticks": basic.change, "attributes": basic.attributes,
        "directory": bool(standard.directory), "delete_pending": bool(standard.delete_pending),
    }


def named_metadata(path):
    with opened(path, FILE_READ_ATTRIBUTES) as handle:
        return metadata(handle)


def held_digest(handle, size):
    digest = hashlib.sha256()
    buffer = ctypes.create_string_buffer(CHUNK)
    remaining = size
    while remaining:
        count = w.DWORD()
        checked(read_file(handle, buffer, min(CHUNK, remaining), ctypes.byref(count), None))
        if not 0 < count.value <= min(CHUNK, remaining):
            raise ValueError("image ended before its initial size")
        digest.update(buffer.raw[:count.value])
        remaining -= count.value
    count = w.DWORD()
    checked(read_file(handle, buffer, 1, ctypes.byref(count), None))
    if count.value:
        raise ValueError("image exceeds its initial size")
    return digest.hexdigest()


class ImageVerificationError(ValueError):
    def __init__(self, message, evidence):
        super().__init__(message)
        self.evidence = evidence


def inspect_image(path):
    evidence = {"schema": 2, "path": str(path), "begin_ns": time.perf_counter_ns(),
                "scope": "two fixed held-file read consistency; not atomic or loaded-byte proof"}
    try:
        before_name = named_metadata(path)
        evidence["named_before"] = before_name
        with opened(path, GENERIC_READ | FILE_READ_ATTRIBUTES) as handle:
            before_handle = metadata(handle)
            evidence["held_before"] = before_handle
            if before_name != before_handle:
                raise ImageVerificationError("image named entry differs from opened native identity", evidence)
            first_read = {"begin_ns": time.perf_counter_ns()}
            evidence["read_first"] = first_read
            try:
                first_digest = held_digest(handle, before_handle["size"])
            finally:
                first_read["end_ns"] = time.perf_counter_ns()
            first_read["sha256"] = first_digest
            rewind = {"begin_ns": time.perf_counter_ns()}
            evidence["rewind"] = rewind
            position = ctypes.c_int64()
            try:
                checked(set_pointer(handle, 0, ctypes.byref(position), 0))
            finally:
                rewind["end_ns"] = time.perf_counter_ns()
                rewind["position"] = position.value
            if position.value != 0:
                raise ImageVerificationError("image rewind returned nonzero position", evidence)
            second_read = {"begin_ns": time.perf_counter_ns()}
            evidence["read_second"] = second_read
            try:
                second_digest = held_digest(handle, before_handle["size"])
            finally:
                second_read["end_ns"] = time.perf_counter_ns()
            second_read["sha256"] = second_digest
            after_handle = metadata(handle)
            after_name = named_metadata(path)
            evidence.update(held_after=after_handle, named_after=after_name)
            if first_digest != second_digest:
                evidence["end_ns"] = time.perf_counter_ns()
                raise ImageVerificationError("image fixed read digests differ", evidence)
            if before_handle != after_handle or before_name != after_name or after_handle != after_name:
                evidence["end_ns"] = time.perf_counter_ns()
                raise ImageVerificationError("image native identity or metadata changed during inspection",
                                             evidence)
        evidence.update(sha256=first_digest, end_ns=time.perf_counter_ns())
        return first_digest, evidence
    except (OSError, ValueError) as error:
        evidence["end_ns"] = time.perf_counter_ns()
        if not hasattr(error, "evidence"):
            error.evidence = evidence
        raise
