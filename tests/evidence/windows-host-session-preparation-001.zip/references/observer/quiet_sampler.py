# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Peter Shiller
"""Windows telemetry qualification. It cannot launch a benchmark campaign."""

import argparse
import ctypes
import json
import subprocess
import sys
import time
from ctypes import wintypes
from dataclasses import asdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.with_name("issue7-quiet-campaign-inputs-002") / "checkout/tests/campaign")]

from quiet_gate import Cpu, INTERVALS, Job, ReadBounds, Sample, SECONDS, verdict, window
from windows_slot_job import (
    BasicAccountingInformation, JOB_OBJECT_BASIC_ACCOUNTING_INFORMATION,
    QueryInformationJobObject, SlotJob, _bind, _checked,
)

P = ctypes.POINTER


class MemoryStatus(ctypes.Structure):
    _fields_ = [("length", wintypes.DWORD), ("load", wintypes.DWORD),
                ("physical_total", ctypes.c_uint64), ("physical_available", ctypes.c_uint64),
                ("page_total", ctypes.c_uint64), ("page_available", ctypes.c_uint64),
                ("virtual_total", ctypes.c_uint64), ("virtual_available", ctypes.c_uint64),
                ("extended_available", ctypes.c_uint64)]


class PowerStatus(ctypes.Structure):
    _fields_ = [("ac_line", wintypes.BYTE), ("battery_flag", wintypes.BYTE),
                ("battery_percent", wintypes.BYTE), ("saver", wintypes.BYTE),
                ("battery_life", wintypes.DWORD), ("battery_full_life", wintypes.DWORD)]


GetSystemTimes = _bind("GetSystemTimes", [P(wintypes.FILETIME)] * 3, wintypes.BOOL)
GlobalMemoryStatusEx = _bind("GlobalMemoryStatusEx", [P(MemoryStatus)], wintypes.BOOL)
GetSystemPowerStatus = _bind("GetSystemPowerStatus", [P(PowerStatus)], wintypes.BOOL)
GetActiveProcessorGroupCount = _bind("GetActiveProcessorGroupCount", [], wintypes.WORD)
GetActiveProcessorCount = _bind("GetActiveProcessorCount", [wintypes.WORD], wintypes.DWORD)
realtime = ctypes.WinDLL("api-ms-win-core-realtime-l1-1-1")
QueryUnbiasedInterruptTimePrecise = realtime.QueryUnbiasedInterruptTimePrecise
QueryInterruptTimePrecise = realtime.QueryInterruptTimePrecise
for clock in (QueryUnbiasedInterruptTimePrecise, QueryInterruptTimePrecise):
    clock.argtypes = [P(ctypes.c_uint64)]
    clock.restype = None


def system_cpu():
    idle, kernel, user = (wintypes.FILETIME() for _ in range(3))
    _checked(GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)),
             "GetSystemTimes")
    return Cpu(*(item.dwHighDateTime << 32 | item.dwLowDateTime
                 for item in (idle, kernel, user)))


def job_cpu(job):
    value = BasicAccountingInformation()
    _checked(QueryInformationJobObject(job._handle, JOB_OBJECT_BASIC_ACCOUNTING_INFORMATION,
                                      ctypes.byref(value), ctypes.sizeof(value), None),
             "QueryInformationJobObject(BasicAccountingInformation)")
    return Job(value.total_kernel_time, value.total_user_time,
               value.total_processes, value.active_processes)


def stamp(job=None):
    memory = MemoryStatus()
    memory.length = ctypes.sizeof(memory)
    _checked(GlobalMemoryStatusEx(ctypes.byref(memory)), "GlobalMemoryStatusEx")
    power = PowerStatus()
    _checked(GetSystemPowerStatus(ctypes.byref(power)), "GetSystemPowerStatus")
    groups = GetActiveProcessorGroupCount()
    processors = GetActiveProcessorCount(0)
    awake = ctypes.c_uint64()
    interrupt = ctypes.c_uint64()
    begin = time.perf_counter_ns()
    QueryUnbiasedInterruptTimePrecise(ctypes.byref(awake))
    QueryInterruptTimePrecise(ctypes.byref(interrupt))
    errors = []
    timings = []

    def measured(name, call):
        start = time.perf_counter_ns()
        try:
            value = call()
        except OSError as error:
            errors.append(f"{name}:{type(error).__name__}:{error}")
            value = None
        finish = time.perf_counter_ns()
        timings.extend((start, finish))
        return value

    before = measured("job_before", lambda: job_cpu(job)) if job is not None else None
    if job is None:
        timings.extend((0, 0))
    system_awake_before = ctypes.c_uint64()
    measured("awake_before", lambda: QueryUnbiasedInterruptTimePrecise(ctypes.byref(system_awake_before)))
    system = measured("system", system_cpu)
    system_awake_after = ctypes.c_uint64()
    measured("awake_after", lambda: QueryUnbiasedInterruptTimePrecise(ctypes.byref(system_awake_after)))
    after = measured("job_after", lambda: job_cpu(job)) if job is not None else None
    if job is None:
        timings.extend((0, 0))
    end = time.perf_counter_ns()
    return Sample(begin, awake.value, interrupt.value, time.process_time_ns(), end - begin,
                  groups, processors, memory.physical_available, power.ac_line, power.saver,
                  2, system if system is not None else Cpu(0, 0, 0),
                  system_awake_before.value, system_awake_after.value,
                  before, after, ReadBounds(*timings), tuple(errors))


def warm_job_query():
    job = SlotJob()
    try:
        if job_cpu(job) != Job(0, 0, 0, 0):
            raise RuntimeError("new control Job is not empty")
    finally:
        job.close()


def emit(stream, kind, **values):
    print(json.dumps({"kind": kind, "utc_ns": time.time_ns(), **values}), file=stream, flush=True)


def observe(output):
    with output.open("x", encoding="utf-8") as stream:
        emit(stream, "context", purpose="observation only", win_build=sys.getwindowsversion().build,
             seconds=SECONDS, intervals=INTERVALS, benchmark_slots=0)
        previous = stamp()
        origin = previous.monotonic_ns / 1e9
        emit(stream, "sample", raw=asdict(previous))
        windows = []
        for index in range(1, INTERVALS + 1):
            time.sleep(max(0, origin + SECONDS * index - time.perf_counter()))
            current = stamp()
            row = window(previous, current)
            windows.append(row)
            emit(stream, "sample", raw=asdict(current), interval=row)
            previous = current
        emit(stream, "draft_decision", **verdict(windows))


def fixture_argv(mode):
    return [sys.executable, "-I", "-B", str(Path(__file__).resolve()), mode]


def contained_fixture(job, mode, output, errors):
    child = job.launch(fixture_argv(mode), 0, stdin=subprocess.DEVNULL,
                       stdout=output, stderr=errors)
    try:
        code = child.wait(4)
    finally:
        child.close()
    drain = job.drain()
    if code != 0 or drain != {"active_before": 0, "terminated": False, "active_after": 0}:
        raise RuntimeError(f"fixture failed or required forced cleanup: {code}, {drain}")
    return drain


def burn():
    before = time.process_time_ns()
    cpu_deadline = before + 350_000_000
    wall_deadline = time.perf_counter() + 1.5
    while time.process_time_ns() < cpu_deadline:
        if time.perf_counter() > wall_deadline:
            raise TimeoutError("calibration CPU budget unavailable")
    emit(sys.stdout, "burn", cpu_ns=time.process_time_ns() - before)


def nested():
    job = SlotJob()
    try:
        drain = contained_fixture(job, "--burn", sys.stdout, sys.stderr)
        accounting = job_cpu(job)
        if accounting.total_processes != 1 or accounting.active_processes != 0:
            raise RuntimeError("unexpected nested Job census")
        emit(sys.stdout, "nested", accounting=asdict(accounting), drain=drain)
    finally:
        job.close()


def calibrate(output):
    job = SlotJob()
    try:
        with output.open("x", encoding="utf-8") as stream, \
                output.with_suffix(".fixture.stdout").open("xb") as child_stdout, \
                output.with_suffix(".fixture.stderr").open("xb") as child_stderr:
            before = stamp(job)
            emit(stream, "before", raw=asdict(before))
            drain = contained_fixture(job, "--nested", child_stdout, child_stderr)
            time.sleep(max(0, before.monotonic_ns / 1e9 + SECONDS - time.perf_counter()))
            after = stamp(job)
            row = window(before, after, during=True)
            accounting = after.job
            child_stdout.flush()
            messages = [json.loads(line) for line in
                        output.with_suffix(".fixture.stdout").read_bytes().splitlines()]
            burn_cpu = messages[0]["cpu_ns"] // 100
            inner = Job(**messages[1]["accounting"])
            emit(stream, "after", raw=asdict(after), interval=row, drain=drain,
                 nested_messages=messages, benchmark_slots=0)
            if (before.job != Job(0, 0, 0, 0) or accounting.total_processes != 2
                    or accounting.active_processes != 0 or inner.total_processes != 1
                    or inner.active_processes != 0 or burn_cpu < 3_500_000
                    or inner.total < burn_cpu - 500_000 or accounting.total < inner.total):
                raise RuntimeError("nested Job accounting or drain check failed")
            emit(stream, "calibration", nested_accounting=True,
                 interval_valid=not row["errors"], errors=row["errors"])
    finally:
        job.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    commands = parser.add_mutually_exclusive_group(required=True)
    commands.add_argument("--observe", type=Path)
    commands.add_argument("--calibrate", type=Path)
    commands.add_argument("--nested", action="store_true", help=argparse.SUPPRESS)
    commands.add_argument("--burn", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.observe:
        observe(args.observe)
    elif args.calibrate:
        calibrate(args.calibrate)
    elif args.nested:
        nested()
    else:
        burn()
