# Supplementary host-session comparison — unexecuted design

Status: draft for two independent source/method reviews. No benchmark implementation, launch, measurements, or primary acceptance is authorized. This document cannot close strict issue #7, reinterpret a rejected capture, or earn the existing campaign's win-or-tie certificate.

## Question and estimand

For each explicitly listed matched workload/context/variant and each pinned rival, compare process-tree-guard with that rival on this laptop during the prospectively bounded session, under the SAME mandatory enclosing Job and observed background activity. The experimental unit is a temporally adjacent two-arm block. The target is a host-session conditional distribution of protected-slot outcomes, not a quiet-machine, standalone, general Windows, or universal product ranking.

Use the existing runner's elapsed boundary: controller work begins before construction/spawn, then includes arm waiting, expected output verification and the recorded-PID survivor probe. It ends before outer Job drainage. Job setup and drainage are separate safety costs. Preserve their receipts and stop on failed drainage. This endpoint is neither pure process startup nor kernel kill latency. Resource counters are per arm process, not whole-tree consumption.

Publish three separate results per cell: (1) every assigned outcome and the proportion achieving the cell's correct expected result; (2) paired successful-block elapsed ratios/differences, explicitly conditional on BOTH arms being correct, with selection risk disclosed; (3) all-assignment deadline completion loss. For (3), predeclare B=45 seconds of slot operation, L=min(T,B), with T=infinity for incorrect result, noncompletion, or product failure. This is an explicit capped completion utility, NOT successful latency or an imputed actual failure duration. Keep actual elapsed time and reason separately. Protocol/observer corruption makes the block uninterpretable rather than silently assigning a product loss. Expected product timeout (for example a correct kill-path code124) is not itself failure.

No pooling across cells is required. If a summary is later requested, its cell weights and treatment of unsupported cells must be declared before new data. Do not pool raw milliseconds or choose weights after seeing results.

## Prospective schedule

Before implementation approval, the final public manifest must enumerate exact cell IDs, argv/config/output expectations, rivals, source/executable/environment hashes, and the complete materialized order. Use only semantically matched operations; unsupported functionality is reported separately, never converted into a latency win. The frozen verified fast workload profile is a possible input, not an implicit substitution for the primary profile.

For EACH cell/rival, fix20 adjacent two-arm measured blocks: ten AB and ten BA, shuffled prospectively with seed20261107 and a pinned schedule generator. A=guard, B=that rival. Materialize and hash every assignment before running. Interleave cells/rivals across rounds under a separately derived recorded shuffle so one product/cell is not always early or late. Rep labels in the existing globally shuffled primary plan are NOT temporal pairs and cannot be reused as blocks.

Use one explicitly scheduled warmup per arm/cell before its measured blocks, with balanced seeded order. Retain warmup outcomes and exact costs, but exclude them from the predeclared measured estimand. No extra warmup, cache flush, process killing, settings change, quiet-period search, retries, or replacement blocks. No competitors run concurrently. Record predecessor/order to expose carryover; balancing does not prove its absence.

Stop at the earlier of the complete fixed schedule or an absolute3600-second session deadline, with an independent whole-tree finite envelope and an explicitly reserved cleanup tail in the final launch plan. Existing slot30-second, probe10-second, and drain5-second limits remain unchanged. The final plan must show feasible slot and descendant bounds; this draft does not authorize a launch. Safety failure or irrecoverable instrumentation failure stops the session. A stopped prefix is INCOMPLETE, never expanded/repeated until a favorable result appears.

## Evidence and contamination

Keep every assignment, attempted/not-attempted status, actual argv, expected/observed exit/output, marker identities, survivor probe result, arm resource counter, Job cleanup receipt, timestamp and raw telemetry. Keep all earlier strict-protocol failures immutable. No post-result exclusions, outlier trimming, optional stopping or unplanned reruns.

The primary quiet-host thresholds stay EXACTLY frozen, including CPU, RAM, power, observer and50ms census constraints. Record their pass/refusal facts as primary qualification outcomes; do not relabel them as passing this supplement. Supplementary host-session rows are explicitly collected outside primary admission and cannot feed its certificate.

Contamination is part of this host-session estimand: retain background CPU, available memory, power, observer costs, competing/unverified process observations, gaps and counters. Predetermine arm-blind rules for malformed/missing timing or mismatched source/argv/output instrumentation; invalidate the WHOLE paired block for inference, retain its raw record/count and never replace it. A real product output or cleanup failure is not a conveniently excludable measurement defect. Conditional subsets and contamination strata are sensitivity analyses only, fully counted. Tool-induced CPU/RAM may be post-treatment: do not adjust it away or exclude arms asymmetrically.

An observer that exceeds the primary50ms/CPU budget remains a failed primary observer. Its costs and sampling cadence must be explicit in the supplement. Do not quietly remove monitoring, claim equivalent cleanliness, or infer no competitor from sparse snapshots. A separate observer/sampling definition requires exact review before code or measurement.

## Analysis and disposition

For matched successful blocks, report each cell's block-level log elapsed ratio log(A/B), paired absolute difference, distribution, and confidence interval. The default inferential summary is the mean block logratio (geometric mean paired ratio), with an explicitly predeclared block-aware uncertainty method. Treat the pair/block as the unit; do not treat thousands of slots/rows inside a block as independent replication. Sessions are not independent machines. Temporal dependence/carryover must be assessed and limitations stated; if the model or effective independent-block support is inadequate, restrict publication to descriptive summaries and INCONCLUSIVE inference.

Before launch, seal the exact interval/randomization procedure and family of contrasts. A conservative option is predeclared simultaneous95% intervals over all reported confirmatory cells (for example Bonferroni-adjusted paired logratio intervals with the assumption check stated). Correlated drift, heavy tails or insufficient successful pairs may defeat that analysis; do not switch methods opportunistically. An alternative procedure requires prospective independent review, not retrospective selection of narrower intervals.

For lower-is-better ratio R=A/B: an entire simultaneous interval below1 supports directional guard advantage in this host-session endpoint; an entire interval above1 supports directional disadvantage; otherwise report INCONCLUSIVE. Statistical direction does not establish practical importance. There is NO practical tie/equivalence margin in this draft. Rounded-equal medians, nonsignificance, overlap with1, or missing data NEVER establish equivalence. Application-justified margins would require a separate prospective amendment before new timings. Publish completion failures beside any conditional timing direction; a fast incorrect arm is not a latency success.

Twenty blocks is a fixed exploratory budget, not a power guarantee. Do not promise a decisive answer. New observed variance may inform a separately registered future session, but cannot enlarge this one after looking at direction. No general winner, quiet-host pass, standalone escape resistance, prolonged durability or safety certification follows from this supplement.

## Source-grounded boundaries

Canonical references: SPEC_Benchmark.md sections on operationalization, instrumentation validation and finite resource limits; tests/campaign/windows_slot_job.py kill-on-close/no-breakaway Job setup and five-second drain; runner.py run_slot/_run_slot and pre-drain survivor observation; plan.py seeded global shuffle; tests/README.md claim ledger and incomplete-run rules; campaign.json explicit no-soak/no-recovery/no-data-integrity and single-platform scope decisions.

The outer non-breakaway Job changes the environment before any cleanup. A successful survivor check cannot establish what an uncontained arm would do on breakaway. The probe reopens recorded numeric PIDs, not original process handles/creation identities, and does not discover unpublished descendants. Preserve these limits in every comparative claim. Guard guarantees and the user's mandatory finite process deadlines remain unchanged.
