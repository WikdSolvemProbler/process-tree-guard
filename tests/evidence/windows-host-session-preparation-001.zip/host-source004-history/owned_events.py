"""Unexecuted event acquisition: fresh no-reparse handles under owned namespace.
No target process, Job, host setting or primary runner change. Native qualification pending.
"""
from contextlib import ExitStack, contextmanager
from pathlib import Path
import time

REPARSE = 0x400
DIRECTORY = 0x10
BACKUP_SEMANTICS = 0x02000000
OPEN_REPARSE_POINT = 0x00200000

def require_plain(info, directory):
    if (info["attributes"] & REPARSE or info["delete_pending"]
            or info["directory"] is not directory
            or bool(info["attributes"] & DIRECTORY) is not directory):
        raise ValueError("event namespace reparse/type/delete state refused before read")

class NativeEvents:
    def __init__(self, api):
        self.api=api; self.evidence=[]; self.quarantine_handles=[]
        self.file_type=api.bind("GetFileType",[api.w.HANDLE],api.w.DWORD)
    def info(self, handle):
        n=self.api
        basic,standard,identity=n.BasicInfo(),n.StandardInfo(),n.IdInfo()
        n.checked(n.file_info(handle,0,n.ctypes.byref(basic),n.ctypes.sizeof(basic)))
        n.checked(n.file_info(handle,1,n.ctypes.byref(standard),n.ctypes.sizeof(standard)))
        n.checked(n.file_info(handle,18,n.ctypes.byref(identity),n.ctypes.sizeof(identity)))
        if not any(identity.file_id) or standard.end<0 or standard.allocation<0:
            raise ValueError("event object lacks identified nonnegative metadata")
        return {"volume":identity.volume,"file_id_128":bytes(identity.file_id).hex(),
            "size":standard.end,"allocation":standard.allocation,"links":standard.links,
            "creation_ticks":basic.creation,"write_ticks":basic.write,"change_ticks":basic.change,
            "attributes":basic.attributes,"directory":bool(standard.directory),
            "delete_pending":bool(standard.delete_pending)}
    @contextmanager
    def opened(self,path,directory):
        n=self.api
        # Only owned post-run artifacts. Denying DELETE while held prevents
        # rebinding these entries during traversal; this is not an image lock.
        flags=OPEN_REPARSE_POINT | (BACKUP_SEMANTICS if directory else 0)
        access=n.FILE_READ_ATTRIBUTES | (0 if directory else n.GENERIC_READ)
        handle=n.create_file(str(path),access,1|2,None,n.OPEN_EXISTING,flags,None)
        if not handle or handle==n.INVALID_HANDLE_VALUE:
            raise n.ctypes.WinError(n.ctypes.get_last_error())
        row={"path":str(path),"directory":directory,"handle":handle,"begin_ns":time.perf_counter_ns()}
        self.evidence.append(row)
        primary=None
        try:
            if self.file_type(handle)!=1:raise ValueError("event handle is not a disk object")
            before=self.info(handle);row["before"]=before
            require_plain(before,directory)
            yield handle,before
            after=self.info(handle);row["after"]=after
            require_plain(after,directory)
            if before!=after: raise ValueError("event object changed during acquisition")
        except BaseException as error:
            primary=error
            row["primary_error"]={"type":type(error).__name__,"message":str(error)}
            raise
        finally:
            closed=bool(n.close_handle(handle));row["closed"]=closed;row["end_ns"]=time.perf_counter_ns()
            if not closed:
                self.quarantine_handles.append(handle)
                close_error=n.ctypes.WinError(n.ctypes.get_last_error())
                row["cleanup_error"]={"type":type(close_error).__name__,"message":str(close_error)}
                if primary is None: raise close_error
    def collect(self,assignment,namespace,maximum):
        assignment,namespace=Path(assignment),Path(namespace)
        if namespace != assignment/"processkit-events": raise ValueError("foreign event namespace")
        result=[]
        with ExitStack() as stack:
            # Fresh handles for own session + assignment + event directory,
            # retained through enumeration/read; every opened final component
            # rejects reparse rather than following it.
            for path in (assignment.parent,assignment,namespace):stack.enter_context(self.opened(path,True))
            for index,folder in enumerate(namespace.iterdir()):
                if index>=2 or not folder.name.startswith("slot-"): raise ValueError("event folder bound/name differs")
                stack.enter_context(self.opened(folder,True))
                for number,path in enumerate(folder.iterdir()):
                    if number>=1 or path.name!="events.jsonl":raise ValueError("event file bound/name differs")
                    with self.opened(path,False) as (handle,before):
                        n=self.api; data=bytearray();buffer=n.ctypes.create_string_buffer(n.CHUNK)
                        while len(data)<=maximum:
                            count=n.w.DWORD();limit=min(n.CHUNK,maximum+1-len(data))
                            n.checked(n.read_file(handle,buffer,limit,n.ctypes.byref(count),None))
                            if count.value>limit:raise ValueError("event ReadFile count exceeds request")
                            if not count.value:break
                            data.extend(buffer.raw[:count.value])
                        if len(data)>maximum or len(data)!=before["size"]:raise ValueError("event capture exceeds bound or initial size")
                        result.append((str(path),bytes(data)))
        return result
