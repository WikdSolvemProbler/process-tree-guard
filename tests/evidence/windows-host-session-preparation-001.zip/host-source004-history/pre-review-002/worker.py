"""Source-only held worker: no slot resources before READY/gate; never standalone."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent

def bootstrap(plan_sha):
    raw = (HERE / "implementation.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != plan_sha: raise ValueError("unapproved implementation")
    plan = json.loads(raw)
    captured = (HERE / "common.py").read_bytes()
    if hashlib.sha256(captured).hexdigest() != plan["source_sha256"]["common.py"]: raise ValueError("common differs")
    value = types.ModuleType("supplement_common"); value.__file__ = str(HERE / "common.py")
    sys.modules[value.__name__] = value
    exec(compile(captured, value.__file__, "exec"), value.__dict__)
    return plan, value


class RetentionLedger:
    """Only a complete, stable, read-back-verified artifact authorizes unlink."""
    def __init__(self): self.receipts = {}
    def capture(self, key, read_source, write_verified, maximum):
        data, evidence = read_source()
        # Keep bounded forensic prefix even when the original must quarantine.
        retained = data[:maximum]
        artifact = write_verified(retained)
        complete = len(data) <= maximum and len(data) == evidence["size"]
        if not complete or evidence["stable"] is not True:
            raise ValueError("bounded capture incomplete/unstable; original quarantined")
        self.receipts[key] = {"identity": evidence["identity"], "artifact": artifact}
        return data, evidence
    def unlink(self, key, expected_identity, current_identity, capture_missing, unlink):
        if key not in self.receipts: capture_missing()
        receipt = self.receipts.get(key)
        if (receipt is None or receipt["identity"] != expected_identity
                or current_identity() != expected_identity):
            raise ValueError("unretained or changed original quarantined")
        unlink()

def main(approved, row_path):
    plan, c = bootstrap(approved)
    c.demand(plan["approved_for_execution"] is True, "source-only draft refuses execution")
    for name, pin in plan["source_sha256"].items(): c.checked(HERE / name, pin)
    assignment_raw = Path(row_path).read_bytes()
    assignment = json.loads(assignment_raw)
    directory = Path(row_path).parent
    c.demand(directory.is_dir() and assignment["assignment_id"] == directory.name, "assignment binding differs")
    index, profile, captured = c.input_bindings()
    modules = c.frozen_modules(captured)
    # The isolated guard must already have created this worker under its armed
    # deadline before this source is reachable. No SlotJob/event/stdin files yet.
    print(json.dumps({"kind": "ready", "pid": os.getpid(), "parent_pid": os.getppid(),
                      "assignment_sha256": c.sha(assignment_raw), "implementation_sha256": approved,
                      "ready_ns": time.perf_counter_ns()}, allow_nan=False), flush=True)
    if sys.stdin.buffer.read(2) != b"G\n": raise ValueError("sole gate absent or malformed")
    whole_begin = time.perf_counter_ns()
    os.chdir(c.TESTS)
    config = c.absolute_config(profile, directory)
    runner, slot_module = modules["runner"], modules["windows_slot_job"]
    original_observe = runner._observe_output
    original_job = slot_module.SlotJob
    original_os, original_tempfile = runner.os, runner.tempfile
    temporary = {}
    retained_paths = RetentionLedger()
    stream_directory = directory / "stream-temporary"
    stream_directory.mkdir()
    retentions = []
    created_jobs = []
    launches = []
    stream_errors = []
    events = None
    record = None
    failures = []
    expected_argv = runner.fast_workload_argv(assignment["arm"], config)
    expected_flags = runner.creation_flags("NO_WINDOW")
    class ObservedJob(original_job):
        def __init__(self):
            began = time.perf_counter_ns()
            super().__init__()
            created_jobs.append({"begin_ns": began, "end_ns": time.perf_counter_ns(),
                                 "job_handle": self._handle, "closed": False})
            self.observation = created_jobs[-1]
        def launch(self, argv, creationflags, **streams):
            vector = list(argv)
            # Only ProcessKit's fresh owned event token is substituted by runner.
            if assignment["arm"] == "processkit":
                position = expected_argv.index("{event_log}")
                c.demand(len(vector) == len(expected_argv), "argv size differs")
                c.demand(vector[:position] == expected_argv[:position]
                         and vector[position+1:] == expected_argv[position+1:], "argv differs")
                event = Path(vector[position])
                c.demand(event.name == "events.jsonl" and event.parent.parent == directory / "processkit-events",
                         "event path escapes assignment")
            else: c.demand(vector == expected_argv, "argv differs")
            c.demand(creationflags == expected_flags, "context flags differ")
            call = {"argv": vector, "flags": creationflags, "begin_ns": time.perf_counter_ns()}
            launches.append(call)
            c.exclusive_json(directory / "presented.json", call)
            if streams.get("stdin") is not None:
                capture(streams["stdin"].name, "stdin")
            try:
                process = super().launch(vector, creationflags, **streams)
                call["pid"] = process.pid
                return process
            finally: call["end_ns"] = time.perf_counter_ns()
        def drain(self):
            begin = time.perf_counter_ns()
            try:
                value = super().drain()
                self.observation["drain"] = value
                return value
            finally:
                self.observation["drain_begin_ns"] = begin
                self.observation["drain_end_ns"] = time.perf_counter_ns()
        def close(self):
            try: return super().close()
            except BaseException as error:
                if hasattr(self, "observation"): self.observation["close_error"] = c.error_record(error)
                raise
            finally:
                if hasattr(self, "observation"):
                    self.observation["closed"] = self._handle is None
                    self.observation["closed_ns"] = time.perf_counter_ns()
    def capture(path, label):
        begin = time.perf_counter_ns()
        path = Path(path)
        result = {"label": label, "source": str(path), "begin_ns": begin}
        try:
            def read_source():
                with open(path, "rb") as source:
                    before = os.fstat(source.fileno())
                    data = source.read(c.MAX_BYTES + 1)
                    after = os.fstat(source.fileno())
                stable = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
                result.update(observed_file_bytes=after.st_size, retained_bytes=min(len(data), c.MAX_BYTES),
                              complete=len(data) <= c.MAX_BYTES, identity=[before.st_dev, before.st_ino], stable=stable)
                return data, {"size": after.st_size, "identity": (before.st_dev, before.st_ino), "stable": stable}
            def write_verified(retained):
                target = directory / (label + ".bin")
                with target.open("xb") as out:
                    if out.write(retained) != len(retained): raise OSError("short artifact write")
                with target.open("rb") as source: verified = source.read(c.MAX_BYTES + 1)
                c.demand(verified == retained, "retained artifact readback differs")
                result["retained_sha256"] = c.sha(verified)
                result["artifact_verified"] = True
                return {"path": str(target), "sha256": c.sha(verified), "bytes": len(verified)}
            data, _ = retained_paths.capture(str(path), read_source, write_verified, c.MAX_BYTES)
            result["unlink_authorized"] = True
            return data, result
        except BaseException as error:
            result["error"] = c.error_record(error)
            stream_errors.append(result)
            return None, result
        finally:
            result["end_ns"] = time.perf_counter_ns()
            retentions.append(result)
    def retain_output(record, spec, stdout, stderr):
        # Replaces only unbounded byte acquisition/verification in isolated
        # worker, before original finally deletes files. No canonical edit.
        for label, path, expected_key in (("stdout", stdout, "expected_stdout"),
                                          ("stderr", stderr, "expected_stderr")):
            data, evidence = capture(path, label)
            if data is not None:
                record["output_" + label + "_sha256"] = c.sha(data)
                record["output_" + label + "_len"] = len(data)
                expected = spec.get(expected_key)
                record["output_" + label + "_match"] = isinstance(expected, str) and data == expected.encode()
        record["supplement_capture_errors"] = list(stream_errors)
    class TempProxy:
        def __getattr__(self, key): return getattr(original_tempfile, key)
        def mkstemp(self, *args, **kwargs):
            kwargs["dir"] = str(stream_directory)
            descriptor, path = original_tempfile.mkstemp(*args, **kwargs)
            info = os.fstat(descriptor)
            temporary[str(Path(path))] = (info.st_dev, info.st_ino)
            return descriptor, path
    class OsProxy:
        def __getattr__(self, key): return getattr(original_os, key)
        def unlink(self, path, *args, **kwargs):
            key = str(Path(path))
            c.demand(key in temporary and not args and not kwargs, "unknown unlink quarantined")
            def current_identity():
                info = original_os.stat(path, follow_symlinks=False)
                return (info.st_dev, info.st_ino)
            def capture_missing():
                capture(path, "error-path-" + str(len(retentions)))
            return retained_paths.unlink(key, temporary[key], current_identity,
                                         capture_missing, lambda: original_os.unlink(path))

    runner.os, runner.tempfile = OsProxy(), TempProxy()
    slot_module.SlotJob = ObservedJob
    runner._observe_output = retain_output
    try:
        c.exclusive_json(directory / "stdin-expected.json", {"hex": profile["children"]["fast"]["stdin"].encode().hex()})
        slot = modules["plan"].Slot("measured" if assignment["kind"] == "measured" else "warmup",
                                    assignment["arm"], "fast", "NO_WINDOW", assignment["pair_index"])
        record = runner.run_slot(slot, config)
        c.exclusive_json(directory / "slot-record.json", record)
        if assignment["arm"] == "processkit":
            root = directory / "processkit-events"
            paths = []
            # Bounded namespace traversal, never unbounded glob on product data.
            for folder_index, folder in enumerate(root.iterdir()):
                c.demand(folder_index < 2 and folder.is_dir() and folder.name.startswith("slot-"),
                         "unexpected event namespace quarantined")
                for file_index, path in enumerate(folder.iterdir()):
                    c.demand(file_index < 1 and path.name == "events.jsonl" and path.is_file(),
                             "unexpected event artifact quarantined")
                    paths.append(path)
            if not paths:
                events = {"structurally_valid": False, "contract_failure": "required event log absent",
                          "namespace_inspected": True, "capture_failed": False}
            else:
                c.demand(len(paths) == 1, "required event file ambiguous")
                data, evidence = capture(paths[0], "processkit-events")
                if data is None:
                    events = {"structurally_valid": False, "capture_failed": True}
                else:
                    try:
                        lines = data.splitlines()
                        c.demand(0 < len(lines) <= c.MAX_EVENT_ROWS and all(len(line) <= c.MAX_EVENT_LINE for line in lines),
                                 "event parser bounds exceeded")
                        parsed = [json.loads(line) for line in lines]
                        c.demand(all(isinstance(row, dict) and type(row.get("schema_version")) is int
                                     and row["schema_version"] == 1 for row in parsed), "event schema differs")
                        c.demand(parsed[0].get("event") == "run_started" and type(parsed[0].get("pid")) is int
                                 and parsed[0]["pid"] == record["arm_pid"]
                                 and parsed[-1].get("event") == "runner_exit" and type(parsed[-1].get("code")) is int
                                 and parsed[-1]["code"] == record["exit_code"], "event identity/exit differs")
                        events = {"structurally_valid": True, "rows": len(parsed), "sha256": c.sha(data)}
                    except (ValueError, TypeError, KeyError) as error:
                        events = {"structurally_valid": False, "capture_failed": False,
                                  "contract_failure": c.error_record(error), "sha256": c.sha(data)}
    except BaseException as error:
        failures.append(c.error_record(error))
    finally:
        runner._observe_output = original_observe
        slot_module.SlotJob = original_job
        runner.os, runner.tempfile = original_os, original_tempfile
    c.demand(c.sha(Path(row_path).read_bytes()) == c.sha(assignment_raw), "assignment changed")
    c.input_bindings()
    c.exclusive_json(directory / "worker-result.json", {
        "schema": "host-session-worker-v1", "assignment": assignment, "whole_begin_ns": whole_begin,
        "result_observed_ns": time.perf_counter_ns(), "record": record, "jobs": created_jobs,
        "launches": launches, "retention": retentions, "capture_errors": stream_errors,
        "event_evidence": events, "failures": failures,
        "primary_T_scope": "frozen _run_slot start/end with bounded retention seam INCLUDED; not unchanged primary timing",
        "census_qualified": False, "phase_qualified": False, "campaign_qualified": False})
    return 0 if record is not None and not failures else 1

if __name__ == "__main__":
    p = argparse.ArgumentParser(); p.add_argument("--implementation-sha", required=True)
    p.add_argument("--assignment", required=True)
    a = p.parse_args(); raise SystemExit(main(a.implementation_sha, a.assignment))
