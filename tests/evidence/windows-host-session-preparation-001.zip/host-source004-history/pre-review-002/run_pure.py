"""Proposed pure phase only. Consumed unit-plan.json is deliberately absent."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import types
import unittest
HERE=Path(__file__).resolve().parent

def main(approved):
    origin=time.perf_counter_ns();deadline=origin+35_000_000_000
    raw=(HERE/"unit-plan.json").read_bytes()
    if hashlib.sha256(raw).hexdigest()!=approved:raise ValueError("unapproved pure plan")
    plan=json.loads(raw)
    if plan.get("reviewed") is not True or plan["inner_seconds"]!=35 or plan["outer_seconds"]!=45:
        raise ValueError("pure scope unapproved")
    captured={}
    def bindings():
        if hashlib.sha256((HERE/"unit-plan.json").read_bytes()).hexdigest()!=approved:
            raise ValueError("pure plan changed")
        for name,pin in plan["source_sha256"].items():
            data=(HERE/name).read_bytes()
            if hashlib.sha256(data).hexdigest()!=pin:raise ValueError("pure source differs: "+name)
            if name not in captured:captured[name]=data
        for path,pin in plan["tool_sha256"].items():
            if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=pin:raise ValueError("pure tool differs")
    bindings()
    code=0;errors=[];facts=None
    with (HERE/"pure-001.log").open("x",encoding="utf-8") as log:
        try:
            module=types.ModuleType("host_session_pure_tests")
            module.__file__=str(HERE/"test_pure.py")
            module.CAPTURED_SOURCES=captured
            sys.modules[module.__name__]=module
            exec(compile(captured["test_pure.py"],module.__file__,"exec"),module.__dict__)
            result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
            facts={"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}
            if not result.wasSuccessful() or result.testsRun!=14 or result.skipped:code=1
        except BaseException as error:code=1;errors.append({"type":type(error).__name__,"message":str(error)})
    try:bindings()
    except BaseException as error:code=1;errors.append({"type":type(error).__name__,"message":str(error)})
    log_sha=hashlib.sha256((HERE/"pure-001.log").read_bytes()).hexdigest()
    observed=time.perf_counter_ns()
    if observed>=deadline:code=1;errors.append({"type":"TimeoutError","message":"deadline after final hashes"})
    receipt={"schema":"host-session-pure-receipt-v1","code":code,"qualified":code==0,
             "facts":facts,"errors":errors,"log_sha256":log_sha,"observed_ns":observed,"deadline_ns":deadline,
             "deadline_scope":"checks and hashes35s; emission under45s enclosingJob",
             "private_dll_loads":0,"process_launches_by_tests":0,"native_api_calls_by_tests":0,
             "whole_arm_custody_qualified":False,"retention_native_qualified":False,"session_approved":False}
    with(HERE/"pure-receipt-001.json").open("x",encoding="utf-8")as out:
        json.dump(receipt,out,indent=2,allow_nan=False);out.write("\n")
    return code
if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--approved-unit-plan-sha",required=True)
    raise SystemExit(main(p.parse_args().approved_unit_plan_sha))
