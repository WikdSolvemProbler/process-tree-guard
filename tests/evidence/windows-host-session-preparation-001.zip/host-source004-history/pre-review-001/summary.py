"""Pure descriptive summaries; never calculates a test, CI, winner or tie."""
import math
import statistics

CELLS = ("processkit", "nuewframe", "sysprims")

def number(value): return type(value) in (int, float) and math.isfinite(value)

def summarize(schedule, records):
    expected = {row["assignment_id"]: row for row in schedule}
    if len(expected) != 66: raise ValueError("expected fixed66 assignments")
    observed = {}
    for item in records:
        row = item["assignment"]
        key = row["assignment_id"]
        if key not in expected or row != expected[key] or key in observed:
            raise ValueError("foreign/duplicate/relabelled assignment")
        observed[key] = item
    full_attempt = len(observed) == 66 and all(item.get("attempted") is True for item in observed.values())
    result = {"scope": "DESCRIPTIVE_ONLY", "complete_assignment_attempts": full_attempt,
              "primary_admission": "NOT_EVALUATED", "cells": {}, "inference": None,
              "equivalence": None, "certificate": False}
    for cell in CELLS:
        counts = {}; pairs = {}; timing = []; losses = []
        planned = [r for r in schedule if r["cell"] == cell]
        for arm in ("guard", cell):
            counts[arm] = {}
            for kind in ("warmup", "measured"):
                assignments = [r for r in planned if r["arm"] == arm and r["kind"] == kind]
                selected = [observed[r["assignment_id"]] for r in assignments if r["assignment_id"] in observed]
                categories = {}
                for item in selected:
                    category = item.get("disposition", {}).get("category", "unverified")
                    categories[category] = categories.get(category, 0) + 1
                attempted = sum(r.get("attempted") is True for r in selected)
                interpretable = sum(r.get("disposition", {}).get("utility_seconds") is not None for r in selected)
                correct = sum(r.get("disposition", {}).get("category") == "correct_completion" for r in selected)
                correctness_interpretable = sum(r.get("disposition", {}).get("category") in ("correct_completion", "observed_incorrect_completion", "observed_noncompletion", "observed_spawn_failure") for r in selected)
                counts[arm][kind] = {"assigned": len(assignments), "attempted": attempted,
                    "not_attempted": len(assignments) - attempted, "utility_interpretable": interpretable,
                    "correct": correct, "correct_over_attempted": [correct, attempted],
                    "correct_over_interpretable": [correct, correctness_interpretable], "categories": categories}
        for row in planned:
            if row["kind"] != "measured": continue
            pairs.setdefault(row["block_id"], {})[row["arm"]] = observed.get(row["assignment_id"])
        all_utilities = True
        for block_id, values in pairs.items():
            a, b = values.get("guard"), values.get(cell)
            pair = {"block_id": block_id, "both_correct": False, "timing_difference_ms": None,
                    "ratio": None, "utility_difference_seconds": None}
            if a is not None and b is not None and a.get("attempted") is True and b.get("attempted") is True:
                ad, bd = a["disposition"], b["disposition"]
                pair["both_correct"] = ad.get("category") == bd.get("category") == "correct_completion"
                if pair["both_correct"] and ad.get("timing_valid") is True and bd.get("timing_valid") is True:
                    at = a["worker_result"]["record"]["elapsed_ms"]
                    bt = b["worker_result"]["record"]["elapsed_ms"]
                    if number(at) and number(bt) and at > 0 and bt > 0:
                        pair.update(timing_difference_ms=at-bt, ratio=at/bt)
                        timing.append((at-bt, at/bt))
                av, bv = ad.get("utility_seconds"), bd.get("utility_seconds")
                if number(av) and number(bv) and 0 <= av <= 45 and 0 <= bv <= 45:
                    pair["utility_difference_seconds"] = av-bv; losses.append(av-bv)
                else: all_utilities = False
            else: all_utilities = False
            values["descriptive"] = pair
        def spread(values):
            return None if not values else {"n": len(values), "median": statistics.median(values),
                                            "min": min(values), "max": max(values)}
        diffs = [a for a,b in timing]; ratios = [b for a,b in timing]
        result["cells"][cell] = {"counts": counts,
            "ordered_pairs": [values["descriptive"] for values in pairs.values()],
            "conditional_both_correct_difference_ms": spread(diffs),
            "conditional_both_correct_ratio": spread(ratios),
            "conditional_geometric_mean_ratio": None if not ratios else math.exp(statistics.mean(map(math.log, ratios))),
            "utility_complete_case_mean_difference_seconds": None if not losses else statistics.mean(losses),
            "utility_complete_case_n": len(losses),
            "finite_session_all_assignment_utility_mean_difference_seconds":
                statistics.mean(losses) if full_attempt and all_utilities and len(losses) == 10 else None,
            "utility_scope": "all-assignment finite-session only when complete; otherwise conditional complete-case/prefix",
            "selection_limit": "both-correct timing subset is post-assignment; no causal/population inference"}
    return result
