"""PROPOSED pure controls. Never starts worker/Job/API; no execution authorized."""
import types
import json
from pathlib import Path
import unittest
HERE = Path(__file__).resolve().parent

def load(name, filename):
    raw = CAPTURED_SOURCES[filename]
    value = types.ModuleType(name); value.__file__ = str(HERE / filename)
    exec(compile(raw, value.__file__, "exec"), value.__dict__); return value
c = load("pure_common", "common.py")
s = load("pure_session", "session.py")
a = load("pure_summary", "summary.py")

class ScheduleControls(unittest.TestCase):
    def test_materialized_exact_order_and_balance(self):
        rows = c.schedule()
        self.assertEqual(c.encode(rows)+b"\n", CAPTURED_SOURCES["schedule.json"])
        for cell in c.CELL_IDS:
            first = [r for r in rows if r["cell"] == cell and r["kind"] == "measured" and r["position"] == 0]
            self.assertEqual([r["orientation"] for r in first].count("AB"), 5)
            self.assertEqual([r["orientation"] for r in first].count("BA"), 5)
    def test_every_pair_is_adjacent_and_unique(self):
        rows = c.schedule(); self.assertEqual(len({r["assignment_id"] for r in rows}),66)
        for i in range(0,66,2):
            self.assertEqual(rows[i]["block_id"], rows[i+1]["block_id"])
            self.assertEqual({rows[i]["arm"], rows[i+1]["arm"]}, {"guard", rows[i]["cell"]})

class BoundaryControls(unittest.TestCase):
    def test_guard_startup_not_an_admitted_arm(self):
        state = c.ArmBoundary(100)
        with self.assertRaises(ValueError): state.gate(200)
        with self.assertRaises(ValueError): state.ready(10_000_000_100)
        self.assertFalse(state.finish(1000,{"active_after":0}))
    def test_parent_stall_never_reads_as_bounded_even_if_job_empty(self):
        state = c.ArmBoundary(0); state.ready(100); state.gate(101)
        self.assertFalse(state.finish(50_000_000_100,{"active_after":0}))
    def test_uncertain_cleanup_does_not_earn_pass(self):
        state=c.ArmBoundary(0);state.ready(100);state.gate(101)
        self.assertFalse(state.finish(200,{"error":"injected"}))
        self.assertFalse(state.finish(200,{"active_after":True}))
        self.assertTrue(state.finish(200,{"active_after":0}))

class ClassificationControls(unittest.TestCase):
    def worker(self, **changes):
        record={"outcome":"ok","exit_code":0,"elapsed_ms":3,
                "output_stdout_match":True,"output_stderr_match":True,"slot_job":{"active_after":0}}
        record.update(changes)
        return {"record":record,"launches":[{"argv":["pinned"]}],"failures":[],"capture_errors":[]}
    def test_harness_infra_timeout_is_not_excluded_as_instrument_corruption(self):
        value=s.disposition(self.worker(outcome="infra-failure",exit_code=None,
            detail="slot exceeded its 30 s harness deadline"),124,False)
        self.assertEqual(value["category"],"observed_noncompletion");self.assertEqual(value["utility_seconds"],45)
    def test_unattempted_or_missing_presentation_not_a_product_loss(self):
        self.assertIsNone(s.disposition(None,124,False)["utility_seconds"])
        self.assertEqual(s.disposition(None,124,False,{"validated":True})["utility_seconds"],45)
    def test_capture_failure_does_not_erase_known_bad_exit(self):
        worker=self.worker(exit_code=7);worker["capture_errors"]=[{"error":"read refused"}]
        self.assertEqual(s.disposition(worker,0,False)["category"],"observed_incorrect_completion")
    def test_bad_output_log_and_safety_are_distinct(self):
        worker=self.worker();worker["event_evidence"]={"contract_failure":"bad code"}
        self.assertEqual(s.disposition(worker,0,False)["category"],"observed_incorrect_completion")
        worker["record"]["slot_job"]={"error":"drain refused"}
        self.assertEqual(s.disposition(worker,0,False)["category"],"safety_abort")

class SummaryControls(unittest.TestCase):
    def test_half_pair_missing_never_imputed_and_no_inference(self):
        rows=c.schedule(); row=next(r for r in rows if r["kind"]=="measured")
        observed={"assignment":row,"attempted":True,"disposition":{"category":"observed_noncompletion","utility_seconds":45}}
        result=a.summarize(rows,[observed])
        self.assertFalse(result["complete_assignment_attempts"]);self.assertIsNone(result["inference"])
        self.assertIsNone(result["cells"][row["cell"]]["finite_session_all_assignment_utility_mean_difference_seconds"])
    def test_relabelled_or_duplicate_assignments_refused(self):
        rows=c.schedule(); row=rows[0]
        observed={"assignment":row,"attempted":False,"disposition":{"category":"not_attempted"}}
        with self.assertRaises(ValueError):a.summarize(rows,[observed,observed])
        changed={**observed,"assignment":{**row,"arm":"unknown"}}
        with self.assertRaises(ValueError):a.summarize(rows,[changed])

if __name__=="__main__":unittest.main(verbosity=2)
