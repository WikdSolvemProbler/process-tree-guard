"""PROPOSED pure controls. Never starts worker/Job/API; no execution authorized."""
import types
import json
from pathlib import Path
import unittest
HERE = Path(__file__).resolve().parent

def load(name, filename):
    raw = CAPTURED_SOURCES[filename]
    value = types.ModuleType(name); value.__file__ = str(HERE / filename)
    exec(compile(raw, value.__file__, "exec"), value.__dict__); return value
c = load("pure_common", "common.py")
s = load("pure_session", "session.py")
a = load("pure_summary", "summary.py")
w = load("pure_worker", "worker.py")
e = load("pure_events", "owned_events.py")

class ScheduleControls(unittest.TestCase):
    def test_materialized_exact_order_and_balance(self):
        rows = c.schedule()
        self.assertEqual(c.encode(rows)+b"\n", CAPTURED_SOURCES["schedule.json"])
        for cell in c.CELL_IDS:
            first = [r for r in rows if r["cell"] == cell and r["kind"] == "measured" and r["position"] == 0]
            self.assertEqual([r["orientation"] for r in first].count("AB"), 5)
            self.assertEqual([r["orientation"] for r in first].count("BA"), 5)
    def test_every_pair_is_adjacent_and_unique(self):
        rows = c.schedule(); self.assertEqual(len({r["assignment_id"] for r in rows}),66)
        for i in range(0,66,2):
            self.assertEqual(rows[i]["block_id"], rows[i+1]["block_id"])
            self.assertEqual({rows[i]["arm"], rows[i+1]["arm"]}, {"guard", rows[i]["cell"]})

class BoundaryControls(unittest.TestCase):
    def test_guard_startup_not_an_admitted_arm(self):
        state = c.ArmBoundary(100)
        with self.assertRaises(ValueError): state.gate(200)
        with self.assertRaises(ValueError): state.ready(10_000_000_100)
        self.assertFalse(state.finish(1000,{"active_after":0}))
    def test_parent_stall_never_reads_as_bounded_even_if_job_empty(self):
        state = c.ArmBoundary(0); state.ready(100); state.gate(101)
        self.assertFalse(state.finish(50_000_000_100,{"active_after":0}))
    def test_uncertain_cleanup_does_not_earn_pass(self):
        state=c.ArmBoundary(0);state.ready(100);state.gate(101)
        self.assertFalse(state.finish(200,{"error":"injected"}))
        self.assertFalse(state.finish(200,{"active_after":True}))
        self.assertTrue(state.finish(200,{"active_after":0}))

class ClassificationControls(unittest.TestCase):
    def worker(self, **changes):
        record={"outcome":"ok","exit_code":0,"elapsed_ms":3,
                "output_stdout_match":True,"output_stderr_match":True,"slot_job":{"active_after":0}}
        record.update(changes)
        return {"record":record,"launches":[{"argv":["pinned"]}],"failures":[],"capture_errors":[],"jobs":[{"closed":True,"drain":{"active_after":0}}]}
    def test_harness_infra_timeout_is_not_excluded_as_instrument_corruption(self):
        value=s.disposition(self.worker(outcome="infra-failure",exit_code=None,
            detail="slot exceeded its 30 s harness deadline"),124,False,presentation_verified=True)
        self.assertEqual(value["category"],"observed_noncompletion");self.assertEqual(value["utility_seconds"],45)
    def test_unattempted_or_missing_presentation_not_a_product_loss(self):
        self.assertIsNone(s.disposition(None,124,False)["utility_seconds"])
        self.assertIsNone(s.disposition(None,124,False,{"validated":True})["utility_seconds"])
        self.assertEqual(s.disposition(None,124,False,{"validated":True},presentation_verified=True)["utility_seconds"],45)
    def test_capture_failure_does_not_erase_known_bad_exit(self):
        worker=self.worker(exit_code=7);worker["capture_errors"]=[{"error":"read refused"}]
        self.assertEqual(s.disposition(worker,0,False)["category"],"observed_incorrect_completion")
    def test_bad_output_log_and_safety_are_distinct(self):
        worker=self.worker();worker["event_evidence"]={"contract_failure":"bad code"}
        self.assertEqual(s.disposition(worker,0,False)["category"],"observed_incorrect_completion")
        worker["record"]["slot_job"]={"error":"drain refused"}
        self.assertEqual(s.disposition(worker,0,False)["category"],"safety_abort")

class SummaryControls(unittest.TestCase):
    def test_half_pair_missing_never_imputed_and_no_inference(self):
        rows=c.schedule(); row=next(r for r in rows if r["kind"]=="measured")
        observed={"assignment":row,"attempted":True,"disposition":{"category":"observed_noncompletion","utility_seconds":45}}
        result=a.summarize(rows,[observed])
        self.assertFalse(result["complete_assignment_attempts"]);self.assertIsNone(result["inference"])
        self.assertIsNone(result["cells"][row["cell"]]["finite_session_all_assignment_utility_mean_difference_seconds"])
    def test_relabelled_or_duplicate_assignments_refused(self):
        rows=c.schedule(); row=rows[0]
        observed={"assignment":row,"attempted":False,"disposition":{"category":"not_attempted"}}
        with self.assertRaises(ValueError):a.summarize(rows,[observed,observed])
        changed={**observed,"assignment":{**row,"arm":"unknown"}}
        with self.assertRaises(ValueError):a.summarize(rows,[changed])

if __name__=="__main__":unittest.main(verbosity=2)

class RetentionFailureControls(unittest.TestCase):
    def test_actual_capture_write_failure_preserves_original(self):
        ledger=w.RetentionLedger(); unlinked=[]
        def source(): return b"only-copy", {"size":9,"identity":(1,2),"stable":True}
        def failed_write(data): raise OSError("injected destination write failure")
        with self.assertRaises(OSError): ledger.capture("owned",source,failed_write,1024)
        self.assertNotIn("owned",ledger.receipts)
        with self.assertRaises(ValueError):
            ledger.unlink("owned",(1,2),lambda:(1,2),lambda:None,lambda:unlinked.append(True))
        self.assertEqual(unlinked,[])
    def test_actual_complete_capture_authorizes_only_same_original(self):
        ledger=w.RetentionLedger(); unlinked=[]
        ledger.capture("owned",lambda:(b"ok",{"size":2,"identity":(1,2),"stable":True}),lambda data:{"verified":True},1024)
        with self.assertRaises(ValueError):
            ledger.unlink("owned",(1,2),lambda:(1,3),lambda:None,lambda:unlinked.append(True))
        ledger.unlink("owned",(1,2),lambda:(1,2),lambda:None,lambda:unlinked.append(True))
        self.assertEqual(unlinked,[True])
    def test_actual_dispatcher_no_next_arm_after_inner_cleanup_failure(self):
        base=ClassificationControls().worker()
        for bad in ({"closed":False,"drain":{"active_after":0}},
                    {"closed":True,"close_error":"injected","drain":{"active_after":0}},
                    {"closed":True,"drain":{"active_after":1}},
                    {"closed":True,"drain":{"error":"injected"}}):
            worker={**base,"jobs":[bad]}
            classification=s.disposition(worker,0,False)
            self.assertEqual(s.dispatcher_stop(False,[],classification,worker),"safety_abort")
        self.assertEqual(s.dispatcher_stop(False,[],{"category":"safety_abort"},base),"safety_abort")
        self.assertIsNone(s.dispatcher_stop(False,[],s.disposition(base,0,False),base))

class EvidenceBindingControls(unittest.TestCase):
    def test_actual_frozen_assignment_relabel_refused(self):
        row=c.schedule()[0]
        self.assertEqual(c.planned_assignment(c.encode(row)+b"\n",row["assignment_id"]),row)
        changed={**row,"arm":"sysprims" if row["arm"]!="sysprims" else "guard"}
        with self.assertRaises(ValueError): c.planned_assignment(c.encode(changed)+b"\n",row["assignment_id"])
    def test_actual_presentation_rejects_foreign_assignment_and_context(self):
        row=c.schedule()[0]
        expected={"argv":["pinned"],"flags":0,"cwd":"owned","environment_sha256":"e","stdin_sha256":"s","stdin_bytes":3}
        presented={"assignment":row,"assignment_sha256":c.sha(c.encode(row)+b"\n"),**expected}
        self.assertTrue(c.presentation_valid(row,presented,expected))
        for key,value in (("flags",False),("stdin_sha256","bad"),("argv",["foreign"]),("cwd","foreign")):
            self.assertFalse(c.presentation_valid(row,{**presented,key:value},expected))
        self.assertFalse(c.presentation_valid(row,{},expected))
    def test_actual_opened_identity_refused_before_read(self):
        reads=[]
        for observed,regular in (((1,3),True),((1,2),False)):
            with self.assertRaises(ValueError):c.opened_identity_before_read((1,2),observed,regular,lambda:reads.append(True))
        self.assertEqual(reads,[])
        self.assertEqual(c.opened_identity_before_read((1,2),(1,2),True,lambda:b"ok"),b"ok")
    def test_actual_output_flags_need_matching_retained_bytes(self):
        record={"output_stdout_sha256":c.sha(b"ok"),"output_stdout_len":2,"output_stdout_match":True,
                "output_stderr_sha256":c.sha(b""),"output_stderr_len":0,"output_stderr_match":True}
        spec={"expected_stdout":"ok","expected_stderr":""}
        self.assertTrue(c.output_record_valid(record,{"stdout":b"ok","stderr":b""},spec))
        self.assertFalse(c.output_record_valid(record,{"stdout":b"bad","stderr":b""},spec))

class EventControls(unittest.TestCase):
    def test_actual_no_reparse_gate_rejects_before_read(self):
        regular={"attributes":0,"delete_pending":False,"directory":False}
        e.require_plain(regular,False)
        for changed in ({**regular,"attributes":0x400},{**regular,"directory":True},
                        {**regular,"delete_pending":True},{**regular,"attributes":0x10}):
            with self.assertRaises(ValueError):e.require_plain(changed,False)
    def test_actual_retained_event_parser_checks_identity_exit_and_duplicate_keys(self):
        raw=b'{"schema_version":1,"event":"run_started","pid":4}\n{"schema_version":1,"event":"runner_exit","code":0}\n'
        self.assertTrue(c.event_contract_valid(raw,{"arm_pid":4,"exit_code":0}))
        self.assertFalse(c.event_contract_valid(raw,{"arm_pid":5,"exit_code":0}))
        self.assertFalse(c.event_contract_valid(raw.replace(b'"code":0',b'"code":0,"code":0'),{"arm_pid":4,"exit_code":0}))
