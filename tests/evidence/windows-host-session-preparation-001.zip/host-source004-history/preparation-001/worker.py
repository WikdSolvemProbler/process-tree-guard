"""Source-only held worker: no slot resources before READY/gate; never standalone."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent

def bootstrap(plan_sha):
    raw = (HERE / "implementation.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != plan_sha: raise ValueError("unapproved implementation")
    plan = json.loads(raw)
    captured = (HERE / "common.py").read_bytes()
    if hashlib.sha256(captured).hexdigest() != plan["source_sha256"]["common.py"]: raise ValueError("common differs")
    value = types.ModuleType("supplement_common"); value.__file__ = str(HERE / "common.py")
    sys.modules[value.__name__] = value
    exec(compile(captured, value.__file__, "exec"), value.__dict__)
    return plan, value

def main(approved, row_path):
    plan, c = bootstrap(approved)
    c.demand(plan["approved_for_execution"] is True, "source-only draft refuses execution")
    for name, pin in plan["source_sha256"].items(): c.checked(HERE / name, pin)
    assignment_raw = Path(row_path).read_bytes()
    assignment = json.loads(assignment_raw)
    directory = Path(row_path).parent
    c.demand(directory.is_dir() and assignment["assignment_id"] == directory.name, "assignment binding differs")
    index, profile, captured = c.input_bindings()
    modules = c.frozen_modules(captured)
    # The isolated guard must already have created this worker under its armed
    # deadline before this source is reachable. No SlotJob/event/stdin files yet.
    print(json.dumps({"kind": "ready", "pid": os.getpid(), "parent_pid": os.getppid(),
                      "assignment_sha256": c.sha(assignment_raw), "implementation_sha256": approved,
                      "ready_ns": time.perf_counter_ns()}, allow_nan=False), flush=True)
    if sys.stdin.buffer.read(2) != b"G\n": raise ValueError("sole gate absent or malformed")
    whole_begin = time.perf_counter_ns()
    os.chdir(c.TESTS)
    config = c.absolute_config(profile, directory)
    runner, slot_module = modules["runner"], modules["windows_slot_job"]
    original_observe = runner._observe_output
    original_job = slot_module.SlotJob
    retentions = []
    created_jobs = []
    launches = []
    stream_errors = []
    events = None
    record = None
    failures = []
    expected_argv = runner.fast_workload_argv(assignment["arm"], config)
    expected_flags = runner.creation_flags("NO_WINDOW")
    class ObservedJob(original_job):
        def __init__(self):
            began = time.perf_counter_ns()
            super().__init__()
            created_jobs.append({"begin_ns": began, "end_ns": time.perf_counter_ns(),
                                 "job_handle": self._handle, "closed": False})
            self.observation = created_jobs[-1]
        def launch(self, argv, creationflags, **streams):
            vector = list(argv)
            # Only ProcessKit's fresh owned event token is substituted by runner.
            if assignment["arm"] == "processkit":
                position = expected_argv.index("{event_log}")
                c.demand(len(vector) == len(expected_argv), "argv size differs")
                c.demand(vector[:position] == expected_argv[:position]
                         and vector[position+1:] == expected_argv[position+1:], "argv differs")
                event = Path(vector[position])
                c.demand(event.name == "events.jsonl" and event.parent.parent == directory / "processkit-events",
                         "event path escapes assignment")
            else: c.demand(vector == expected_argv, "argv differs")
            c.demand(creationflags == expected_flags, "context flags differ")
            call = {"argv": vector, "flags": creationflags, "begin_ns": time.perf_counter_ns()}
            launches.append(call)
            c.exclusive_json(directory / "presented.json", call)
            try:
                process = super().launch(vector, creationflags, **streams)
                call["pid"] = process.pid
                return process
            finally: call["end_ns"] = time.perf_counter_ns()
        def drain(self):
            begin = time.perf_counter_ns()
            try:
                value = super().drain()
                self.observation["drain"] = value
                return value
            finally:
                self.observation["drain_begin_ns"] = begin
                self.observation["drain_end_ns"] = time.perf_counter_ns()
        def close(self):
            try: return super().close()
            finally:
                if hasattr(self, "observation"):
                    self.observation["closed"] = self._handle is None
                    self.observation["closed_ns"] = time.perf_counter_ns()
    def capture(path, label):
        begin = time.perf_counter_ns()
        result = {"label": label, "source": str(path), "begin_ns": begin}
        try:
            with open(path, "rb") as source:
                before = os.fstat(source.fileno())
                data = source.read(c.MAX_BYTES + 1)
                after = os.fstat(source.fileno())
            result.update(observed_file_bytes=after.st_size, retained_bytes=min(len(data), c.MAX_BYTES),
                          complete=len(data) <= c.MAX_BYTES,
                          identity=[before.st_dev, before.st_ino],
                          stable=(before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                                 == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns))
            retained = data[:c.MAX_BYTES]
            with (directory / (label + ".bin")).open("xb") as out: out.write(retained)
            result["retained_sha256"] = c.sha(retained)
            c.demand(result["complete"] and result["stable"] and len(data) == after.st_size,
                     "bounded capture incomplete/unstable")
            return data, result
        except BaseException as error:
            result["error"] = c.error_record(error)
            stream_errors.append(result)
            return None, result
        finally:
            result["end_ns"] = time.perf_counter_ns()
            retentions.append(result)
    def retain_output(record, spec, stdout, stderr):
        # Replaces only unbounded byte acquisition/verification in isolated
        # worker, before original finally deletes files. No canonical edit.
        for label, path, expected_key in (("stdout", stdout, "expected_stdout"),
                                          ("stderr", stderr, "expected_stderr")):
            data, evidence = capture(path, label)
            if data is not None:
                record["output_" + label + "_sha256"] = c.sha(data)
                record["output_" + label + "_len"] = len(data)
                expected = spec.get(expected_key)
                record["output_" + label + "_match"] = isinstance(expected, str) and data == expected.encode()
        record["supplement_capture_errors"] = list(stream_errors)
    slot_module.SlotJob = ObservedJob
    runner._observe_output = retain_output
    try:
        c.exclusive_json(directory / "stdin-expected.json", {"hex": profile["children"]["fast"]["stdin"].encode().hex()})
        slot = modules["plan"].Slot("measured" if assignment["kind"] == "measured" else "warmup",
                                    assignment["arm"], "fast", "NO_WINDOW", assignment["pair_index"])
        record = runner.run_slot(slot, config)
        c.exclusive_json(directory / "slot-record.json", record)
        if assignment["arm"] == "processkit":
            paths = list((directory / "processkit-events").glob("slot-*/events.jsonl"))
            c.demand(len(paths) == 1, "required event file absent/ambiguous")
            data, evidence = capture(paths[0], "processkit-events")
            c.demand(data is not None, "required event capture unavailable")
            lines = data.splitlines()
            c.demand(0 < len(lines) <= c.MAX_EVENT_ROWS and all(len(line) <= c.MAX_EVENT_LINE for line in lines),
                     "event parser bounds exceeded")
            parsed = [json.loads(line) for line in lines]
            c.demand(all(isinstance(row, dict) and type(row.get("schema_version")) is int
                         and row["schema_version"] == 1 for row in parsed), "event schema differs")
            c.demand(parsed[0].get("event") == "run_started" and type(parsed[0].get("pid")) is int
                     and parsed[0]["pid"] == record["arm_pid"]
                     and parsed[-1].get("event") == "runner_exit" and type(parsed[-1].get("code")) is int
                     and parsed[-1]["code"] == record["exit_code"], "event identity/exit differs")
            events = {"structurally_valid": True, "rows": len(parsed), "sha256": c.sha(data)}
    except BaseException as error:
        failures.append(c.error_record(error))
    finally:
        runner._observe_output = original_observe
        slot_module.SlotJob = original_job
    c.demand(c.sha(Path(row_path).read_bytes()) == c.sha(assignment_raw), "assignment changed")
    c.input_bindings()
    c.exclusive_json(directory / "worker-result.json", {
        "schema": "host-session-worker-v1", "assignment": assignment, "whole_begin_ns": whole_begin,
        "result_observed_ns": time.perf_counter_ns(), "record": record, "jobs": created_jobs,
        "launches": launches, "retention": retentions, "capture_errors": stream_errors,
        "event_evidence": events, "failures": failures,
        "primary_T_scope": "frozen _run_slot start/end with bounded retention seam INCLUDED; not unchanged primary timing",
        "census_qualified": False, "phase_qualified": False, "campaign_qualified": False})
    return 0 if record is not None and not failures else 1

if __name__ == "__main__":
    p = argparse.ArgumentParser(); p.add_argument("--implementation-sha", required=True)
    p.add_argument("--assignment", required=True)
    a = p.parse_args(); raise SystemExit(main(a.implementation_sha, a.assignment))
