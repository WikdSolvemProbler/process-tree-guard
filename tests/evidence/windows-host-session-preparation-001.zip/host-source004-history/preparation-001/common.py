"""Source-only supplement constants, schedule and bounded evidence primitives."""
import hashlib
import json
import os
from pathlib import Path
import types
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
FROZEN = HERE.with_name("issue7-quiet-campaign-inputs-002")
CHECKOUT = FROZEN / "checkout"
TESTS = CHECKOUT / "tests"
INPUT_SHA = "0826dc5baff96d28d24f78184b53df03d7f248f3c970344bac86929d89e2f9b0"
CONFIG = "tests/campaign-sysprims-fast-warn.json"
CONFIG_SHA = "dbd53f039277755f40d9c3156e85c6e92a67a018778109f11e5effd71d1e2ce5"
GUARD = Path("C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe")
GUARD_SHA = "1899137f687541256fb89749b2fe6a2940f2e420faaf2330fc84f32cfd7fae43"
PYTHON = Path("C:/Users/Peter/AppData/Local/Programs/Python/Python312/python.exe")
PYTHON_SHA = "4d6f5f81a4bca11191c4c7c6b43632694d0a4ce74e068619d8fdc161d469859a"
CELL_IDS = ("processkit", "nuewframe", "sysprims")
SEED = "20261107"
MAX_BYTES = 1024 * 1024
MAX_EVENT_ROWS = 1024
MAX_EVENT_LINE = 65536

def demand(value, message):
    if not value: raise ValueError(message)

def sha(raw): return hashlib.sha256(raw).hexdigest()

def checked(path, pin):
    raw = Path(path).read_bytes()
    demand(sha(raw) == pin, "pinned bytes differ: " + str(path))
    return raw

def encode(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                      separators=(",", ":")).encode("utf-8")

def exclusive_json(path, value):
    with Path(path).open("xb") as out:
        out.write(encode(value) + b"\n")
        out.flush()

def module(name, path, raw):
    value = types.ModuleType(name)
    value.__file__ = str(path)
    sys.modules[name] = value
    exec(compile(raw, str(path), "exec"), value.__dict__)
    return value

def priority(*parts): return hashlib.sha256("|".join((SEED, *map(str, parts))).encode()).digest()

def schedule():
    rows = []
    def pair(cell, kind, index, orientation):
        block = kind + "-" + cell + "-" + str(index)
        for position, letter in enumerate(orientation):
            rows.append({"assignment_id": "a%03d" % len(rows), "block_id": block,
                         "kind": kind, "cell": cell, "pair_index": index,
                         "position": position, "orientation": orientation,
                         "arm": "guard" if letter == "A" else cell})
    for cell in sorted(CELL_IDS, key=lambda c: (priority("warmup-cell", c), c)):
        orientation = "AB" if priority("warmup-order", cell)[0] % 2 == 0 else "BA"
        pair(cell, "warmup", 0, orientation)
    orientations = {}
    tokens = [a + str(i) for a in ("AB", "BA") for i in range(5)]
    for cell in CELL_IDS:
        orientations[cell] = sorted(tokens, key=lambda t: (priority("orientation", cell, t), t))
    for index in range(10):
        for cell in sorted(CELL_IDS, key=lambda c: (priority("round", index, c), c)):
            pair(cell, "measured", index, orientations[cell][index][:2])
    demand(len(rows) == 66 and sum(r["kind"] == "measured" for r in rows) == 60,
           "schedule count differs")
    return rows

def environment():
    inherited = dict(os.environ)
    effective = dict(inherited)
    removed = effective.pop("RUST_LOG", None)
    def fingerprint(value):
        return sha(encode(sorted(value.items())))
    return effective, {"inherited_sha256": fingerprint(inherited),
                       "effective_sha256": fingerprint(effective),
                       "removed_RUST_LOG_present": removed is not None,
                       "removed_RUST_LOG_sha256": None if removed is None else sha(removed.encode())}

def input_bindings():
    raw = checked(FROZEN / "inputs.json", INPUT_SHA)
    index = json.loads(raw)
    demand(index["config_sha256"] == CONFIG_SHA, "frozen profile differs")
    config_raw = checked(CHECKOUT / CONFIG, CONFIG_SHA)
    checked(GUARD, GUARD_SHA)
    checked(PYTHON, PYTHON_SHA)
    loaded = {}
    for name in ("arms", "plan", "windows_slot_job", "runner"):
        relative = "tests/campaign/" + name + ".py"
        path = CHECKOUT / relative
        loaded[name] = checked(path, index["file_sha256"][relative])
    for relative in ("tests/build/process-tree-guard.exe", "tests/build/testkit.exe",
                     "tests/build/competitors/timeout.exe", "tests/build/competitors/processkit-cli.exe",
                     "tests/build/competitors/sysprims.exe"):
        checked(CHECKOUT / relative, index["file_sha256"][relative])
    return index, json.loads(config_raw), loaded

def frozen_modules(loaded):
    result = {}
    for name in ("arms", "plan", "windows_slot_job", "runner"):
        path = TESTS / "campaign" / (name + ".py")
        result[name] = module(name, path, loaded[name])
    return result

def absolute_config(config, assignment_dir):
    import copy
    value = copy.deepcopy(config)
    for spec in value["arms"].values():
        spec["executable"] = str((TESTS / spec["executable"].replace("\\", "/")).resolve())
    for spec in value["children"].values():
        path = Path(spec["program"])
        if not path.is_absolute(): spec["program"] = str((TESTS / spec["program"].replace("\\", "/")).resolve())
    value["_windows_slot_jobs"] = True
    value["_processkit_event_dir"] = str(assignment_dir / "processkit-events")
    return value

def error_record(error):
    return {"type": type(error).__name__, "message": str(error),
            "winerror": getattr(error, "winerror", None)}
