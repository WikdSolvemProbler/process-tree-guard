from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile,ZIP_DEFLATED
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PREV=BASE/'issue7-quiet-launch-012'
REPO=ROOT.parents[2]
APPROVED=(ROOT/'APPROVED-MANIFEST.sha256').read_text(encoding='ascii').strip()
assert re.fullmatch(r'[0-9a-f]{64}',APPROVED)
OUT=REPO/'tests/evidence/windows-laptop-exploratory-protocol-016.zip'
assert not (ROOT/'capture').exists()
assert sha256((ROOT/'manifest.json').read_bytes()).hexdigest()==APPROVED
manifest=json.loads((ROOT/'manifest.json').read_bytes())
freeze=json.loads((ROOT/'source_freeze.json').read_bytes())
assert freeze['file_sha256']==manifest['file_sha256']
for n,h in freeze['file_sha256'].items():assert sha256((ROOT/n).read_bytes()).hexdigest()==h,n
links=json.loads((ROOT/'qualification_links.json').read_bytes())
assert sha256((PREV/'source_freeze.json').read_bytes()).hexdigest()==links['qualified_source_freeze_sha256']
assert sha256((PREV/'native_qualification.json').read_bytes()).hexdigest()==links['native_qualification_sha256']
for n in links['unchanged_measurement_files']:assert (ROOT/n).read_bytes()==(PREV/n).read_bytes(),n
assert (ROOT/'quiet_sampler.py').read_text()==(PREV/'quiet_sampler.py').read_text().replace('issue7-quiet-campaign-inputs-002','issue7-quiet-campaign-inputs-003')
assert (ROOT/'quiet_launch.py').read_text()==(PREV/'quiet_launch.py').read_text().replace('issue7-quiet-20261107-012-s20261029','issue7-quiet-20261107-016-s20261029').replace('issue7-quiet-campaign-inputs-002','issue7-quiet-campaign-inputs-003')
qualification=json.loads((PREV/'native_qualification.json').read_bytes())
for n,h in qualification['file_sha256'].items():assert sha256((PREV/n).read_bytes()).hexdigest()==h,n
files={}
def add(p,name=None):
    key=name or p.relative_to(REPO).as_posix()
    data=p.read_bytes()
    if key in files:assert files[key]==data
    files[key]=data
for n in manifest['file_sha256']:add(ROOT/n)
for p in ROOT.glob('*review*.json'):
    if p.is_file():add(p)
for n in ('manifest.json','source_freeze.json','qualification_links.json','package_preregistration.py','APPROVED-MANIFEST.sha256'):add(ROOT/n)
for d in ROOT.glob('preparation-*'):
    for p in d.iterdir():
        if p.is_file():add(p)
for n in json.loads((PREV/'source_freeze.json').read_bytes())['file_sha256']:add(PREV/n)
for n in ('source_freeze.json','native_qualification.json','smoke_control.py','edge_control.py'):add(PREV/n)
for n in qualification['file_sha256']:add(PREV/n)
for p in (PREV/'smoke-001').iterdir():
    if p.is_file():add(p)
groups={'test_observed_accounting':13,'test_quiet_runner':6,'test_sampler_protocol':2,'test_saved_inventory':3,'test_terminal_population':6,'test_v2_replay':1}
for n,count in groups.items():
    add(PREV/(n+'.py'))
    log=(PREV/(n+'.005.stderr.log')).read_bytes()
    assert int(re.search(rb'Ran ([0-9]+) tests? in ',log).group(1))==count and log.rstrip().endswith(b'OK')
    assert (PREV/(n+'.005.exit.txt')).read_text().strip()=='0'
for p in PREV.iterdir():
    if p.is_file() and (p.suffix in ('.log','.jsonl','.stdout','.stderr') or p.name.endswith('.exit.txt')):add(p)
for n in ('telemetry.jsonl','inventory.jsonl'):add(BASE/'issue7-quiet-launch-010/smoke-001'/n)
inputs=BASE/'issue7-quiet-campaign-inputs-003'
for n in ('inputs.json','check_inputs.py','source.tar','REFRESH-DELTA.json'):add(inputs/n)
for p in (ROOT/'references'/'slot-close').iterdir():
    if p.is_file():add(p)
for n,h in json.loads((inputs/'inputs.json').read_bytes())['file_sha256'].items():
    p=inputs/'checkout'/n
    assert sha256(p.read_bytes()).hexdigest()==h,n
    add(p)
outer=Path(manifest['tools']['outer_guard']['path'])
assert sha256(outer.read_bytes()).hexdigest()==manifest['tools']['outer_guard']['sha256']
add(outer,'tools/outer-process-tree-guard.exe')
add(REPO/'SPEC_Benchmark.md')
summary={'schema':1,'scope':manifest['purpose'],'approved_manifest_sha256':APPROVED,
    'full_attempts_started':0,'approved_full_attempts':1,'telemetry_schema':2,
    'reviews':{"profile_verified_method":{"file":"review-method.json","sha256":"dcac8baf0a1c7f99259b1a113f227ab88ad4b1a1a098e981cff93e6e47b5a2fa","approved_manifest_sha256":"40d2d0713ed38c0243df3bc040f78223ad6404a19aaa3b705689b00e27c0d9b5","disposition":"Zero unresolved objections for exactly one declared attempt after both reviews and public preregistration."},"profile_verified_critic":{"file":"review-critic.json","sha256":"8d9fdc8e16e27e5787550cf2bf3c1fef6886d10de42b6494671660782da4163b","approved_manifest_sha256":"40d2d0713ed38c0243df3bc040f78223ad6404a19aaa3b705689b00e27c0d9b5","disposition":"Zero unresolved objections for exactly one declared attempt after both reviews and public preregistration."}},
    'qualified_implementation_source':'issue7-quiet-launch-012/013 measurement code plus separately qualified94f close dependency','qualification_links':links,
    'native_qualification':qualification,'focused_checks_passed':sum(groups.values()),'focused_groups':groups,
    'chronology':'Six measurement modules stay byte-identical to native-qualified012/013; sampler changes exactly one inputnamespace literal and no measurementlogic. Launcher changes only INPUTS002→003 and RUN_ID013→016. Inputs change only SUTde2→8fa and qualifiedSlotJob94f, with18otherfilesexact; c92source and stagedUSTAR/oldtarprovenance are explicit. Actual new016 reviews must accompany final public approval; no control is rerun or oldcapture rescored.',
    'estimator_limits':'Conservative for Job-subtraction and awake/QPC call-positioning skew in observed accounting; unknown system-counter error has no physical bound here.',
    'previous_rejected_captures':[{'path':'windows-laptop-exploratory-attempt-015.zip','sha256':'1293357f1527a4a4efa096a5fbedecd29ed0c654ccdbd6eac9ea332a2afb813b'},{'path':'windows-laptop-exploratory-attempt-013.zip','sha256':'3686ef75656a67fbe7dc27dc4e873d32326440b33112c5a8d471aad48c0206ac'},{'path':'windows-laptop-exploratory-attempt-011.zip','sha256':'db31b44814b8e9250b8a4e88174a03da481f00212427695469859b4033421171'},{'path':'windows-laptop-exploratory-attempt-012.zip','sha256':'766f52661cd8362d32e15bde3d890c17cdcf56418c99d7718fed6de384c683d7'}],
    'charger_confirmation':'Operator said charger will remain connected; later observedAC1/saveroff. Prospective CPU,power,memory,clock,census and cleanup gates still apply without exception.',
    'strict_issue7_complete':False,'final_certification':False}
files['PREREGISTRATION.json']=(json.dumps(summary,indent=2)+'\n').encode()
files['INDEX.json']=(json.dumps({n:sha256(b).hexdigest() for n,b in files.items()},indent=2)+'\n').encode()
with ZipFile(OUT,'x',compression=ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
with ZipFile(OUT) as z:
    assert z.testzip() is None and set(z.namelist())==set(files)
    for n,b in files.items():assert z.read(n)==b,n
print(json.dumps({'path':str(OUT),'sha256':sha256(OUT.read_bytes()).hexdigest(),'bytes':OUT.stat().st_size,'members':len(files)},indent=2))
