"""Fixed four-image API-call envelopes; instrumentation is not native-only cost."""
import ctypes
import hashlib
import json
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
SOURCE = HERE.with_name("issue7-native-image-verification-001")
FIXED = HERE.with_name("issue7-quiet-launch-013")
HELPER = "8adc1aa23a2298c3adab9ca561b621e8dccca4e78e59407aea39b9b08a2b9440"
MANIFEST = "313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae"
CALLS = ("create_file", "file_info", "read_file", "set_pointer", "close_handle")


def checked_bytes(path, expected):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError("fixed source/image differs: " + str(path))
    return raw


def main():
    manifest_raw = checked_bytes(FIXED / "manifest.json", MANIFEST)
    manifest = json.loads(manifest_raw)
    helper_raw = checked_bytes(SOURCE / "native_image.py", HELPER)
    for name, digest in manifest["file_sha256"].items():
        checked_bytes(FIXED / name, digest)
    image = types.ModuleType("native_image")
    image.__file__ = str(SOURCE / "native_image.py")
    sys.modules["native_image"] = image
    exec(compile(helper_raw, image.__file__, "exec"), image.__dict__)
    originals = {name: getattr(image, name) for name in CALLS}
    deadline = time.perf_counter_ns() + 15_000_000_000
    code = 0
    completed = 0
    with (HERE / "api-cost-001.jsonl").open("x", encoding="utf-8") as output:
        def emit(kind, **values):
            print(json.dumps({"kind": kind, **values}, allow_nan=False), file=output, flush=True)
        emit("context", helper_sha256=HELPER, manifest_sha256=MANIFEST,
             scope="four pinned images once each; component call-envelope diagnostic only",
             instrumentation="perf_counter_ns only around existing WinDLL calls; no process CPU queries",
             limitations="call envelopes include ctypes/Python boundary overhead, not pure kernel latency; remainder includes wrappers/hash/allocations/QPC/unattributed time",
             inner_deadline_seconds=15, benchmark_slots=0)
        images = (("python", manifest["tools"]["python"]),
                  ("guard", manifest["fingerprints"]["guard"]),
                  ("sysprims", manifest["fingerprints"]["sysprims"]),
                  ("outer_guard", manifest["tools"]["outer_guard"]))
        try:
            for label, pin in images:
                if time.perf_counter_ns() >= deadline:
                    raise TimeoutError("15-second component deadline")
                calls = []
                live_handles = set()
                handle_errors = []

                def wrap(name):
                    original = originals[name]
                    def measured(*args):
                        details = {"call": name}
                        if name == "create_file":
                            details.update(path=args[0], access=args[1], sharing=args[2],
                                           security_attributes_null=args[3] is None,
                                           disposition=args[4], flags=args[5])
                        else:
                            details["handle"] = args[0]
                        if name == "file_info":
                            details.update(info_class=args[1], buffer_bytes=args[3])
                        elif name == "read_file":
                            details["requested_bytes"] = args[2]
                        elif name == "set_pointer":
                            details.update(distance=args[1], origin=args[3])
                        begin = time.perf_counter_ns()
                        try:
                            result = original(*args)
                        except BaseException as caught:
                            details["exception"] = {"type": type(caught).__name__, "message": str(caught)}
                            raise
                        finally:
                            end = time.perf_counter_ns()
                            details.update(begin_ns=begin, end_ns=end)
                            calls.append(details)
                        details.update(begin_ns=begin, end_ns=end, returned=result)
                        if name == "read_file":
                            details["returned_bytes"] = args[3]._obj.value
                        elif name == "set_pointer":
                            details["returned_position"] = args[2]._obj.value
                        if name == "create_file" and result and result != image.INVALID_HANDLE_VALUE:
                            if result in live_handles:
                                handle_errors.append("native handle reopened while still owned")
                            live_handles.add(result)
                        elif name == "close_handle" and result:
                            if args[0] not in live_handles:
                                handle_errors.append("close of untracked handle")
                            live_handles.discard(args[0])
                        if not result or (name == "create_file" and result == image.INVALID_HANDLE_VALUE):
                            details["last_error"] = ctypes.get_last_error()
                        return result
                    return measured

                result = error = None
                for name in CALLS:
                    setattr(image, name, wrap(name))
                begin = time.perf_counter_ns()
                try:
                    digest, evidence = image.inspect_image(Path(pin["path"]))
                    result = {"sha256": digest, "evidence": evidence}
                except BaseException as caught:
                    error = {"type": type(caught).__name__, "message": str(caught),
                             "winerror": getattr(caught, "winerror", None),
                             "evidence": getattr(caught, "evidence", None)}
                finally:
                    end = time.perf_counter_ns()
                    for name, original in originals.items():
                        setattr(image, name, original)
                # No native call should remain owned even on inspection failure.
                leaked = sorted(live_handles)
                if leaked:
                    code = 1
                    for handle in leaked:
                        if not originals["close_handle"](handle):
                            handle_errors.append("emergency close failed")
                grouped = {}
                for call in calls:
                    key = call["call"] + ("/" + str(call["info_class"]) if call["call"] == "file_info" else "")
                    group = grouped.setdefault(key, {"calls": 0, "elapsed_ns": 0})
                    group["calls"] += 1
                    group["elapsed_ns"] += call["end_ns"] - call["begin_ns"]
                call_ns = sum(call["end_ns"] - call["begin_ns"] for call in calls)
                pin_match = (result is not None and result["sha256"] == pin["sha256"]
                             and result["evidence"]["read_first"]["sha256"] == pin["sha256"]
                             and result["evidence"]["read_second"]["sha256"] == pin["sha256"])
                emit("image", name=label, path=pin["path"], pinned_sha256=pin["sha256"],
                     begin_ns=begin, end_ns=end, elapsed_ns=end-begin,
                     call_envelopes=calls, grouped_call_envelopes=grouped,
                     sum_call_envelopes_ns=call_ns,
                     python_wrapper_hash_and_unattributed_ns=(end-begin)-call_ns,
                     result=result, error=error, both_reads_match_pin=pin_match,
                     unclosed_handles_before_emergency_cleanup=leaked,
                     handle_errors=handle_errors)
                completed += 1
                if error or not pin_match or leaked or handle_errors:
                    code = 1
                if time.perf_counter_ns() >= deadline:
                    raise TimeoutError("15-second deadline after completed image")
        except BaseException as caught:
            code = 1
            emit("error", type=type(caught).__name__, message=str(caught),
                 winerror=getattr(caught, "winerror", None),
                 evidence=getattr(caught, "evidence", None))
        finally:
            for name, original in originals.items():
                setattr(image, name, original)
            try:
                checked_bytes(SOURCE / "native_image.py", HELPER)
                checked_bytes(FIXED / "manifest.json", MANIFEST)
                for name, digest in manifest["file_sha256"].items():
                    checked_bytes(FIXED / name, digest)
                unchanged = True
            except BaseException as caught:
                unchanged = False
                code = 1
                emit("source_error", type=type(caught).__name__, message=str(caught))
            if time.perf_counter_ns() >= deadline:
                code = 1
                emit("deadline", stage="terminal")
            emit("terminal", code=code, completed_images=completed,
                 sources_unchanged=unchanged, benchmark_slots=0,
                 scope="call-envelope diagnostic only, no observer/campaign qualification")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
