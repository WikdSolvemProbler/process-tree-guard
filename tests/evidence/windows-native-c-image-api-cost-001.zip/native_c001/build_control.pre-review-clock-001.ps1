$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/Users/Peter/process-tree-guard/target/codex-security/issue7-native-c-image-api-cost-001'
$pins=@{
'native_api_cost.c'='d6d8ef97b268255ecbc2524a267ee2ae2101ef8b22a54d010bf83cc1fb07dc2a'
'build_native.cmd'='024b4be7783732407d858166bb9203e2c0bd9af2eec634c5801065deea84d5dc'
'C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe'='b0a1818ebae6da7f18230a84e76ce839212584ac4c2ab55b97a0d5268085da57'
'C:/Windows/System32/cmd.exe'='ccd79a7568ea9240ccd6fe124807b9d3e4dbc3a4cf92954299ac3029f4a91d02'
}
foreach($name in $pins.Keys){if((Get-FileHash -LiteralPath $name -Algorithm SHA256).Hash.ToLower() -ne $pins[$name]){throw "pin differs: $name"}}
foreach($name in @('build-001.stdout.log','build-001.stderr.log','build-001.exit.txt','build-receipt-001.json','native_api_cost.exe','native_api_cost.obj')){if(Test-Path -LiteralPath $name){throw "preexisting output: $name"}}
& 'C:/Windows/System32/cmd.exe' /d /c build_native.cmd 1>build-001.stdout.log 2>build-001.stderr.log
$buildExit=$LASTEXITCODE
Set-Content -LiteralPath build-001.exit.txt -Value $buildExit
$binaryHash=$null
if($buildExit -eq 0){$binaryHash=(Get-FileHash -LiteralPath native_api_cost.exe -Algorithm SHA256).Hash.ToLower()}
$after=@{}
foreach($name in $pins.Keys){$after[$name]=(Get-FileHash -LiteralPath $name -Algorithm SHA256).Hash.ToLower();if($after[$name] -ne $pins[$name]){throw "pin changed: $name"}}
@{schema=1;compile_exit=$buildExit;source_sha256=$pins['native_api_cost.c'];binary_sha256=$binaryHash;tool_source_pins=$after;os_version=[Environment]::OSVersion.Version.ToString();process_architecture=[Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture.ToString();compile_outer_seconds=60;native_payload_runs=0}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath build-receipt-001.json
Get-Content -LiteralPath build-001.stdout.log
Get-Content -LiteralPath build-001.stderr.log
exit $buildExit
