#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0A00
#include <windows.h>
#include <bcrypt.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <limits.h>

_Static_assert(sizeof(void *) == 8, "x64 control");
_Static_assert(sizeof(FILE_BASIC_INFO) == 40, "basic ABI");
_Static_assert(sizeof(FILE_STANDARD_INFO) == 24, "standard ABI");
_Static_assert(sizeof(FILE_ID_INFO) == 24, "ID ABI");
_Static_assert(sizeof(FILE_ID_128) == 16, "full ID");
_Static_assert(FileBasicInfo == 0 && FileStandardInfo == 1 && FileIdInfo == 18, "classes");

typedef struct {
    const char *name, *category;
    LONGLONG begin, end, position;
    unsigned long long handle;
    DWORD argument, amount, count, error;
    LONG status;
    int ok;
} Call;
typedef struct {
    FILE_BASIC_INFO basic;
    FILE_STANDARD_INFO standard;
    FILE_ID_INFO id;
    unsigned queried_mask;
} Signature;
typedef struct {
    const char *name;
    const wchar_t *path;
    const char *sha;
} Target;
static const Target targets[] = {
    {"python", L"C:/Users/Peter/AppData/Local/Programs/Python/Python312/python.exe", "4d6f5f81a4bca11191c4c7c6b43632694d0a4ce74e068619d8fdc161d469859a"},
    {"guard", L"C:/Users/Peter/process-tree-guard/target/codex-security/issue7-quiet-campaign-inputs-002/checkout/tests/build/process-tree-guard.exe", "de2b7ccc1ed69bf655ceea0920692affafdfbc3dbbd2cbe1e6f744bde1c11f01"},
    {"sysprims", L"C:/Users/Peter/process-tree-guard/target/codex-security/issue7-quiet-campaign-inputs-002/checkout/tests/build/competitors/sysprims.exe", "0a3144a6ca7b2df7ee382bbbac85d89f5ed75ee2643e1036356a8eaa4d490867"},
    {"outer_guard", L"C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe", "1899137f687541256fb89749b2fe6a2940f2e420faaf2330fc84f32cfd7fae43"}
};
static Call calls[8192];
static unsigned call_count;
static LONGLONG frequency, deadline_tick;
static int failed, open_files, open_hashes, unlogged_cleanup_calls;
static const char *problem = "";
static BCRYPT_ALG_HANDLE algorithm;

static void fail(const char *message) {
    if (!failed) problem = message;
    failed = 1;
}
static LONGLONG tick(void) {
    LARGE_INTEGER value;
    if (!QueryPerformanceCounter(&value) || value.QuadPart < 0) {
        fail("QPC failed");
        return 0;
    }
    return value.QuadPart;
}
static Call *begin_call(const char *name, const char *category, HANDLE handle, DWORD argument, DWORD amount) {
    Call *item;
    if (call_count >= (unsigned)(sizeof(calls)/sizeof(calls[0]))) {
        fail("call log capacity");
        return NULL;
    }
    item = &calls[call_count++];
    memset(item, 0, sizeof(*item));
    item->name = name; item->category = category;
    item->handle = (unsigned long long)(uintptr_t)handle;
    item->argument = argument; item->amount = amount;
    item->begin = tick();
    return item;
}
static void end_call(Call *item, int ok, DWORD error, DWORD count, LONG status) {
    item->end = tick();
    item->ok = ok; item->error = error; item->count = count; item->status = status;
    if (item->end < item->begin) fail("QPC ordering");
    if (item->end >= deadline_tick) fail("15-second deadline");
}
static HANDLE open_file(const wchar_t *path, DWORD access) {
    HANDLE h;
    DWORD error;
    Call *item = begin_call("CreateFileW", "file", NULL, access, 7);
    if (!item) return INVALID_HANDLE_VALUE;
    h = CreateFileW(path, access, FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,
                    NULL, OPEN_EXISTING, 0, NULL);
    error = h == INVALID_HANDLE_VALUE ? GetLastError() : 0;
    end_call(item, h != INVALID_HANDLE_VALUE, error, 0, 0);
    item->handle = (unsigned long long)(uintptr_t)h;
    if (h != INVALID_HANDLE_VALUE) ++open_files;
    else fail("CreateFileW failed");
    return h;
}
static int close_file(HANDLE h) {
    BOOL ok;
    DWORD error;
    Call *item = begin_call("CloseHandle", "file", h, 0, 0);
    if (!item) {
        ++unlogged_cleanup_calls;
        ok = CloseHandle(h);
        if(ok) --open_files;
        return ok != 0; /* log exhaustion already makes the diagnostic fail */
    }
    ok = CloseHandle(h); error = ok ? 0 : GetLastError();
    end_call(item, ok != 0, error, 0, 0);
    if (ok) --open_files;
    else fail("CloseHandle failed");
    return ok != 0;
}
static int query(HANDLE h, FILE_INFO_BY_HANDLE_CLASS which, void *value, DWORD size) {
    BOOL ok;
    DWORD error;
    Call *item = begin_call("GetFileInformationByHandleEx", "file", h, (DWORD)which, size);
    if (!item) return 0;
    ok = GetFileInformationByHandleEx(h, which, value, size); error = ok ? 0 : GetLastError();
    end_call(item, ok != 0, error, 0, 0);
    if (!ok) fail("GetFileInformationByHandleEx failed");
    return ok != 0 && !failed;
}
static int metadata(HANDLE h, Signature *s) {
    unsigned i, nonzero = 0;
    memset(s, 0, sizeof(*s));
    if (!query(h, FileBasicInfo, &s->basic, (DWORD)sizeof(s->basic))) return 0;
    s->queried_mask |= 1;
    if (!query(h, FileStandardInfo, &s->standard, (DWORD)sizeof(s->standard))) return 0;
    s->queried_mask |= 2;
    if (!query(h, FileIdInfo, &s->id, (DWORD)sizeof(s->id))) return 0;
    s->queried_mask |= 4;
    for (i=0; i<16; ++i) nonzero |= s->id.FileId.Identifier[i];
    if (s->standard.Directory || (s->basic.FileAttributes & FILE_ATTRIBUTE_DIRECTORY) ||
        s->standard.DeletePending || s->standard.EndOfFile.QuadPart < 0 ||
        s->standard.AllocationSize.QuadPart < 0 || !nonzero) {
        fail("not an identified regular file"); return 0;
    }
    return 1;
}
static int named(const wchar_t *path, Signature *s) {
    HANDLE h = open_file(path, FILE_READ_ATTRIBUTES);
    int ok;
    if (h == INVALID_HANDLE_VALUE) return 0;
    ok = !failed && metadata(h, s);
    if (!close_file(h)) ok = 0;
    return ok && !failed;
}
static int same(const Signature *a, const Signature *b) {
    return a->id.VolumeSerialNumber == b->id.VolumeSerialNumber &&
        memcmp(a->id.FileId.Identifier,b->id.FileId.Identifier,16)==0 &&
        a->basic.CreationTime.QuadPart == b->basic.CreationTime.QuadPart &&
        a->basic.LastWriteTime.QuadPart == b->basic.LastWriteTime.QuadPart &&
        a->basic.ChangeTime.QuadPart == b->basic.ChangeTime.QuadPart &&
        a->basic.FileAttributes == b->basic.FileAttributes &&
        a->standard.AllocationSize.QuadPart == b->standard.AllocationSize.QuadPart &&
        a->standard.EndOfFile.QuadPart == b->standard.EndOfFile.QuadPart &&
        a->standard.NumberOfLinks == b->standard.NumberOfLinks &&
        a->standard.DeletePending == b->standard.DeletePending &&
        a->standard.Directory == b->standard.Directory;
}
static int read_bytes(HANDLE h, BYTE *buffer, DWORD amount, DWORD *count) {
    BOOL ok;
    DWORD error;
    Call *item = begin_call("ReadFile", "file", h, 0, amount);
    if (!item) return 0;
    *count = 0;
    ok = ReadFile(h, buffer, amount, count, NULL); error = ok ? 0 : GetLastError();
    end_call(item, ok != 0, error, *count, 0);
    if (!ok) fail("ReadFile failed");
    return ok != 0 && !failed;
}
static int rewind_file(HANDLE h) {
    LARGE_INTEGER zero, result;
    BOOL ok;
    DWORD error;
    Call *item = begin_call("SetFilePointerEx", "file", h, FILE_BEGIN, 0);
    if (!item) return 0;
    zero.QuadPart = 0; result.QuadPart = -1;
    ok = SetFilePointerEx(h, zero, &result, FILE_BEGIN); error = ok ? 0 : GetLastError();
    end_call(item, ok != 0, error, 0, 0);
    item->position = result.QuadPart;
    if (!ok || result.QuadPart != 0) { fail("rewind failed/nonzero"); return 0; }
    return !failed;
}
static int cng_status(Call *item, NTSTATUS status) {
    end_call(item, status >= 0, 0, 0, status);
    if (status < 0) fail("CNG operation failed");
    return status >= 0 && !failed;
}
static int hash_file(HANDLE h, LONGLONG size, BYTE digest[32]) {
    BYTE buffer[65536];
    BCRYPT_HASH_HANDLE hash = NULL;
    LONGLONG remaining = size;
    DWORD amount, count;
    NTSTATUS status;
    int ok = 0;
    Call *item = begin_call("BCryptCreateHash", "cng", NULL, 0, 0);
    if (!item) return 0;
    status = BCryptCreateHash(algorithm, &hash, NULL, 0, NULL, 0, 0);
    if (hash) ++open_hashes;
    if (!cng_status(item,status)) goto done;
    while (remaining > 0) {
        amount = remaining > 65536 ? 65536 : (DWORD)remaining;
        if (!read_bytes(h, buffer, amount, &count)) goto done;
        if (count == 0 || count > amount) { fail("file ended before initial size"); goto done; }
        item = begin_call("BCryptHashData", "cng", NULL, 0, count);
        if (!item) goto done;
        status = BCryptHashData(hash, buffer, count, 0);
        if (!cng_status(item,status)) goto done;
        remaining -= count;
    }
    if (!read_bytes(h, buffer, 1, &count)) goto done;
    if (count) { fail("file exceeds initial size"); goto done; }
    item = begin_call("BCryptFinishHash", "cng", NULL, 0, 32);
    if (!item) goto done;
    status = BCryptFinishHash(hash, digest, 32, 0);
    if (!cng_status(item,status)) goto done;
    ok = 1;
done:
    if (hash) {
        item = begin_call("BCryptDestroyHash", "cng", NULL, 0, 0);
        if (!item) {
            ++unlogged_cleanup_calls;
            status = BCryptDestroyHash(hash);
            if(status >= 0) --open_hashes;
            return 0;
        }
        status = BCryptDestroyHash(hash);
        if (status >= 0) --open_hashes;
        if (!cng_status(item,status)) ok = 0;
    }
    return ok && !failed;
}
static void hex(const BYTE *bytes, unsigned length, char *out) {
    static const char digits[] = "0123456789abcdef";
    unsigned i;
    for(i=0;i<length;++i) { out[i*2]=digits[bytes[i]>>4]; out[i*2+1]=digits[bytes[i]&15]; }
    out[length*2]=0;
}
static void signature_json(const Signature *s) {
    char id[33]; hex(s->id.FileId.Identifier,16,id);
    printf("{\"queried_mask\":%u,\"volume\":%llu,\"file_id_128\":\"%s\",\"size\":%lld,\"allocation\":%lld,"
           "\"links\":%lu,\"creation_ticks\":%lld,\"write_ticks\":%lld,\"change_ticks\":%lld,"
           "\"attributes\":%lu,\"directory\":%s,\"delete_pending\":%s}",
           s->queried_mask,s->id.VolumeSerialNumber,id,s->standard.EndOfFile.QuadPart,s->standard.AllocationSize.QuadPart,
           s->standard.NumberOfLinks,s->basic.CreationTime.QuadPart,s->basic.LastWriteTime.QuadPart,
           s->basic.ChangeTime.QuadPart,s->basic.FileAttributes,
           s->standard.Directory?"true":"false",s->standard.DeletePending?"true":"false");
}
static void calls_json(void) {
    unsigned i;
    printf("[");
    for(i=0;i<call_count;++i) {
        const Call *c=&calls[i];
        printf("%s{\"name\":\"%s\",\"category\":\"%s\",\"begin_qpc\":%lld,\"end_qpc\":%lld,"
               "\"handle\":%llu,\"returned_position\":%lld,\"argument\":%lu,\"amount\":%lu,"
               "\"returned_bytes\":%lu,\"ok\":%s,\"winerror\":%lu,\"ntstatus\":%ld}",
               i?",":"",c->name,c->category,c->begin,c->end,c->handle,c->position,c->argument,c->amount,
               c->count,c->ok?"true":"false",c->error,c->status);
    }
    printf("]");
}
static int inspect(const Target *t) {
    Signature s[4];
    HANDLE h = INVALID_HANDLE_VALUE;
    BYTE first[32]={0},second[32]={0};
    char first_hex[65],second_hex[65];
    LONGLONG begin,end;
    int have[4]={0,0,0,0}, first_ok=0,second_ok=0,ok=0;
    call_count=0; memset(s,0,sizeof(s)); begin=tick();
    if(failed) goto done;
    if (!named(t->path,&s[0])) goto done;
    have[0]=1;
    h=open_file(t->path, GENERIC_READ|FILE_READ_ATTRIBUTES);
    if (h==INVALID_HANDLE_VALUE || failed) goto done;
    if (!metadata(h,&s[1])) goto done;
    have[1]=1;
    if (!same(&s[0],&s[1])) { fail("named and held identities differ"); goto done; }
    if (!hash_file(h,s[1].standard.EndOfFile.QuadPart,first)) goto done;
    first_ok=1;
    if (!rewind_file(h)) goto done;
    if (!hash_file(h,s[1].standard.EndOfFile.QuadPart,second)) goto done;
    second_ok=1;
    if (!metadata(h,&s[2])) goto done;
    have[2]=1;
    if (!named(t->path,&s[3])) goto done;
    have[3]=1;
    if (memcmp(first,second,32)!=0) { fail("two digests differ"); goto done; }
    if (!same(&s[0],&s[1]) || !same(&s[1],&s[2]) || !same(&s[2],&s[3])) {
        fail("metadata changed"); goto done;
    }
    ok=1;
done:
    if(h!=INVALID_HANDLE_VALUE && !close_file(h)) ok=0;
    end=tick();
    hex(first,32,first_hex); hex(second,32,second_hex);
    if (!first_ok || !second_ok || strcmp(first_hex,t->sha)!=0 || strcmp(second_hex,t->sha)!=0) {
        fail("hashes do not match pin"); ok=0;
    }
    if (failed || open_files || open_hashes || end >= deadline_tick) ok=0;
    printf("{\"kind\":\"image\",\"name\":\"%s\",\"path\":\"%ls\",\"pinned_sha256\":\"%s\",\"begin_qpc\":%lld,\"end_qpc\":%lld,"
           "\"first_hash\":\"%s\",\"second_hash\":\"%s\",\"first_complete\":%s,\"second_complete\":%s,"
           "\"both_reads_match_pin\":%s,\"open_file_handles\":%d,\"open_hash_handles\":%d,"
           "\"error\":\"%s\",\"signatures\":[",
           t->name,t->path,t->sha,begin,end,first_hex,second_hex,first_ok?"true":"false",second_ok?"true":"false",
           ok?"true":"false",open_files,open_hashes,problem);
    { unsigned i; for(i=0;i<4;++i) { if(i) printf(","); if(have[i] || s[i].queried_mask) signature_json(&s[i]); else printf("null"); } }
    printf("],\"calls\":"); calls_json(); printf("}\n"); fflush(stdout);
    return ok;
}
int main(void) {
    LARGE_INTEGER f;
    LONGLONG origin,now;
    SYSTEM_INFO info;
    Call *item;
    NTSTATUS status;
    unsigned i,completed=0;
    int code=0;
    if(!QueryPerformanceFrequency(&f) || f.QuadPart<=0 || f.QuadPart>LLONG_MAX/15) {
        fprintf(stderr,"QPC frequency failed/range, WinError=%lu\n",GetLastError()); return 1;
    }
    frequency=f.QuadPart; origin=tick();
    if(failed || origin>LLONG_MAX-frequency*15) return 1;
    deadline_tick=origin+frequency*15;
    GetNativeSystemInfo(&info);
    printf("{\"kind\":\"context\",\"qpc_frequency\":%lld,\"pid\":%lu,\"pointer_bytes\":%zu,"
           "\"native_architecture\":%u,\"processors\":%lu,\"share_mask\":7,\"inherit_handles\":false,"
           "\"inner_seconds\":15,\"benchmark_slots\":0,\"scope\":\"independent C call envelopes only; CNG SHA256; not end-to-end parity\"}\n",
           frequency,GetCurrentProcessId(),sizeof(void*),(unsigned)info.wProcessorArchitecture,info.dwNumberOfProcessors);
    item=begin_call("BCryptOpenAlgorithmProvider","cng",NULL,0,0);
    if(!item) return 1;
    status=BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,NULL,0);
    if(!cng_status(item,status)) code=1;
    printf("{\"kind\":\"provider_open\",\"calls\":");calls_json();printf("}\n");fflush(stdout);
    if(!code) for(i=0;i<4;++i) {
        now=tick();
        if(failed || now>=deadline_tick) {code=1;break;}
        if(!inspect(&targets[i])) code=1;
        ++completed;
        now=tick();
        if(failed || open_files || open_hashes || now>=deadline_tick) {code=1;break;}
    }
    call_count=0;
    if(algorithm) {
        item=begin_call("BCryptCloseAlgorithmProvider","cng",NULL,0,0);
        if(!item) {
            ++unlogged_cleanup_calls;
            status=BCryptCloseAlgorithmProvider(algorithm,0);
            if(status >= 0) algorithm=NULL;
            code=1;
        } else {
            status=BCryptCloseAlgorithmProvider(algorithm,0);
            if(status >= 0) algorithm=NULL;
            if(!cng_status(item,status)) code=1;
        }
    }
    printf("{\"kind\":\"provider_close\",\"calls\":");calls_json();printf("}\n");
    now=tick();
    if(failed || now>=deadline_tick || open_files || open_hashes || algorithm) code=1;
    printf("{\"kind\":\"terminal\",\"code\":%d,\"completed_images\":%u,\"open_file_handles\":%d,"
           "\"open_hash_handles\":%d,\"provider_closed\":%s,\"unlogged_cleanup_calls\":%d,\"benchmark_slots\":0}\n",
           code,completed,open_files,open_hashes,algorithm?"false":"true",unlogged_cleanup_calls);
    fflush(stdout);return code;
}
