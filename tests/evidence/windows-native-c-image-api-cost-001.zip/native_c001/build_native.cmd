@echo off
call "C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Auxiliary/Build/vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
"C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Tools/MSVC/14.51.36231/bin/Hostx64/x64/cl.exe" /nologo /Bv /std:c11 /W4 /WX /O2 native_api_cost.c /Fe:native_api_cost.exe /Fo:native_api_cost.obj /link bcrypt.lib
exit /b %errorlevel%
