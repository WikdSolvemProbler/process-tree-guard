# Unexecuted preparation revisions

No compiler or native fixture attempt has run for011.

The initial Rust draft is preserved in pre-review-001 with SHA256
8772e6f98b974bae54dc92739f91f99b393525a982c54acd7c8cb2347dc31555.
It logged before binding positive clone ownership, logged before failure kill,
and made a redundant ABI query after a consuming cleanup wait. The exact draft
was reconstructed from its unchanged intermediate bytes by reversing the
recorded source edits, and its SHA matches the parent's independent read.
Those ordering problems were identified in source review before execution.

pre-review-002 preserves the intermediate Rust/C/header/METHOD bytes before
the later ownership-before-formatting correction. Current source retains the
actual SpawnFrame in Case, binds the direct child before post-clone validation,
kills before failure logging and stores cleanup raw consumption evidence before
later work. Signal readback now explicitly refuses ignored/non-default SIGCHLD,
SA_NOCLDWAIT and blocked SIGCHLD, alongside default/unblocked SIGTERM.

No failed native run, child, root action or runtime fallback is hidden by these
unexecuted source revisions. Both exact source and launch plan remain pending
independent review before any fixture runtime.
