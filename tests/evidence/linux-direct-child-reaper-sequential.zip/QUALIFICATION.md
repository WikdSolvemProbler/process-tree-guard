# Linux011 stopped at linking; no child-reaper runtime evidence

The sole reviewed attempt returned1. All three installed-header C translation
units, the constant ABI reporter and the two actual Rust full-graph objects
compiled successfully. The native test binary failed to link. Neither the exact
test list nor the selected test ran. No fixture child was created, and no
component waitid/reaper call, payload exec, root action or cgroup component
operation ran. The child's timer loop, Pending/terminal transitions and cleanup
code are compiled source, not qualified runtime behavior.

Both independent reviewers approved source candidate
71ebdbb20a9af5a347a8bdbf46c0fa597eaa03b6d52bbdc7de818dbba1d69714
and plan e6a7273a2509215a6eca875f3af990df9824bd831fe9000d7cf209b9168290c3
for one ordinary sequential attempt. The100/80/75/70 finite chain and effective
Linux ordinary scope properties were verified. Every source byte remained
unchanged after the attempt. Earlier unexecuted drafts and the superseded plan
remain in the archive. No retry or hardening change occurred under011.

GCC/ld reported an unresolved __stack_chk_guard@@GLIBC_2.17 from waitid-bridge.o
and “DSO missing from command line” for /lib/ld-linux-aarch64.so.1. The actual
Rust-generated linker command puts -lc before the C objects supplied through
late -C link-arg. That supports an ordering hypothesis under --as-needed; it is
not yet a validated cause. A future fresh reviewed attempt should use normal
Rust native static-archive linkage and retain stack protection and all existing
flags. It must preserve the actual link ordering, archive members and stack-guard
reference evidence. Disabling stack protection or injecting a loader path is
not a repair used here.

Header provenance matched before/after compilation for114 bridge dependencies,
37 reporter dependencies and134 child-fixture dependencies. The final raw
header-provenance JSON SHA is
9eacc005cb75d559a18d64dbd843227a1dc45ca035771a1bbdbde066902cd51c.
Its original bytes, including full-width timestamp integers, are preserved.
The constant reporter again described native siginfo size128/alignment8 and
the40-byte/alignment4 normalized frame. This reporter performs no child wait.

All81 native artifacts were independently verified and downloaded through held
no-follow descriptors. They include the exact sources and dependencies, C and
Rust objects, partial Rust link objects, reporter binary, compiler/linker raw
streams and every observed exit. The complete local pre-removal ZIP passed CRC
and every indexed byte/length/hash check before removal; its SHA is
8ad1311ac9c170b64a85989c9b9d5704131354c4c19a53d80a3ded64081ee1c9.

Original scratch /tmp/ptg-child-reaper-011.dezzpex_ was UID501 mode0700,
device64769/inode1111959. Ordinary bounded preservation and removal both checked
the original unit/cgroup absent and all14 exact recorded controller/tool PIDs
absent. This is PID-absence evidence, not an invented creation-time claim.
Only the exact verified files and directories were removed descriptor-relatively
after checking their held identities/hashes against the downloaded inventory.
The original scratch was confirmed absent. No root or guessed recursive cleanup
was used. Full raw preservation/removal receipts remain unchanged.

This failed attempt does not establish functional reaper correctness, deadline
runtime, populated drain, watchdog settlement, adopted-descendant handling,
terminal orchestration, production readiness or performance. Those open items
remain visible; the immediate next step is a separate reviewed linkage repair,
then the same bounded sequential fixture before full-run terminal integration.
