// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller

//! One sequential ordinary-user native qualification. No payload exec/cgroup.
use super::*;
use std::ffi::c_void;
use std::os::fd::FromRawFd;

#[repr(C)]
#[derive(Debug, Default)]
struct SpawnFrame {
    schema: u32,
    result: i32,
    call_errno: i32,
    pid: i32,
    pidfd: i32,
    timerfd: i32,
    gate_read: i32,
    gate_write: i32,
    ready_read: i32,
    ready_write: i32,
    setup_close_errno: i32,
    reserved: i32,
    child_deadline_ns: u64,
    before_arm_ns: u64,
    after_arm_ns: u64,
    before_clone_ns: u64,
    after_clone_ns: u64,
    armed_remaining_ns: u64,
}
const _: () = {
    assert!(size_of::<SpawnFrame>() == 96);
    assert!(align_of::<SpawnFrame>() == 8);
    assert!(offset_of!(SpawnFrame, child_deadline_ns) == 48);
    assert!(offset_of!(SpawnFrame, armed_remaining_ns) == 88);
};

unsafe extern "C" {
    fn ptg_fixture_spawn_abi(word: u32) -> u64;
    fn ptg_fixture_now(error: *mut i32) -> u64;
    fn ptg_fixture_ordinary(error: *mut i32) -> i32;
    fn ptg_fixture_spawn(mode: u32, until_ns: u64, out: *mut SpawnFrame);
    fn ptg_fixture_signal(pidfd: i32, which: u32, error: *mut i32) -> i32;
    fn ptg_fixture_poll(event: i32, timer: i32, event_bits: *mut i32,
                        timer_bits: *mut i32, error: *mut i32) -> i32;
    fn read(fd: i32, data: *mut c_void, size: usize) -> isize;
    fn write(fd: i32, data: *const c_void, size: usize) -> isize;
    fn getuid() -> u32;
}

fn demand(value: bool, message: &str) -> Result<(), String> {
    if value { Ok(()) } else { Err(message.into()) }
}

fn now() -> Result<u64, String> {
    let mut error = 0;
    let value = unsafe { ptg_fixture_now(&mut error) };
    demand(error == 0 && value > 0, &format!("CLOCK_BOOTTIME errno={error}"))?;
    Ok(value)
}

fn raw_hex(observation: &RawWaitObservation) -> String {
    // Full retained native bytes, not a Rust interpretation of siginfo padding.
    observation.native_bytes.iter()
        .take(observation.frame.native_size.min(NATIVE_CAPACITY as u32) as usize)
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

fn log_raw(label: &str, observation: &RawWaitObservation) {
    println!("RAW_WAIT label={label} expected_pid={} target_pidfd={} before_ns={} frame={:?} native_hex={} abi={:?}",
        observation.expected_pid, observation.target_pidfd, observation.before_ns,
        observation.frame, raw_hex(observation), observation.abi.words);
}

fn direct_raw(pid: i32, pidfd: i32, before_ns: u64) -> Result<RawWaitObservation, String> {
    let abi = verified_abi().map_err(|failure| format!("ABI refusal: {} {:?}",
        failure.reason, failure.report.words))?;
    let mut observed = RawWaitObservation {
        frame: WaitFrame::default(), native_bytes: [0; NATIVE_CAPACITY],
        abi: abi.report, expected_pid: pid, target_pidfd: pidfd, before_ns,
    };
    unsafe { ptg_waitid_once(pidfd, &mut observed.frame, observed.native_bytes.as_mut_ptr(),
                            NATIVE_CAPACITY as u32); }
    Ok(observed)
}

enum Custody {
    Owned(DirectChild),
    Failure(ReapFailure),
    Reaped(ReapedChild),
}

impl Custody {
    fn identity(&self) -> (i32, i32) {
        match self {
            Self::Owned(child) => (child.pid, child.pidfd.as_raw_fd()),
            Self::Reaped(child) => (child.pid, child.pidfd.as_raw_fd()),
            Self::Failure(ReapFailure::AfterReap { reaped, .. }) =>
                (reaped.pid, reaped.pidfd.as_raw_fd()),
            Self::Failure(ReapFailure::NotCalled { owner, .. }
                | ReapFailure::Unresolved { owner, .. }
                | ReapFailure::ConsumedInvalid { owner, .. }) => (owner.pid(), owner.pidfd()),
        }
    }

    fn exact_reaped(&self) -> bool {
        matches!(self, Self::Reaped(_) | Self::Failure(ReapFailure::AfterReap { .. }))
    }

    fn log(&self, label: &str) {
        match self {
            Self::Owned(_) => println!("CUSTODY label={label} disposition=owned identity={:?}", self.identity()),
            Self::Reaped(child) => {
                log_raw(label, &child.observation);
                println!("CUSTODY label={label} disposition=reaped after_ns={:?} outcome={:?}",
                    child.after_ns, child.outcome);
            }
            Self::Failure(failure) => {
                match failure {
                    ReapFailure::NotCalled { observation, .. } => {
                        match observation {
                            NotCalledObservation::DeadlineBeforeAbi { error } =>
                                println!("REAP_FAILURE label={label} kind=before_abi error={error:?}"),
                            NotCalledObservation::Abi(failure) =>
                                println!("REAP_FAILURE label={label} kind=abi error={:?} abi={:?}",
                                    failure.reason, failure.report.words),
                            NotCalledObservation::DeadlineAfterAbi { error, report } =>
                                println!("REAP_FAILURE label={label} kind=after_abi error={error:?} abi={:?}", report.words),
                        }
                    }
                    ReapFailure::Unresolved { observation, reason, post_deadline, .. } => {
                        log_raw(label, observation);
                        let reason = match reason {
                            ObservationProblem::BridgeRefusedOrMalformed => "bridge_refusal".into(),
                            ObservationProblem::WaitError { errno, is_echild } =>
                                format!("wait_error errno={errno} echild={is_echild}"),
                            ObservationProblem::InvalidZeroOrReturn => "invalid_zero_return".into(),
                            ObservationProblem::DeadlineAfterPending => "deadline_after_pending".into(),
                        };
                        println!("REAP_FAILURE label={label} kind=unresolved reason={reason:?} post_deadline={post_deadline:?}");
                    }
                    ReapFailure::ConsumedInvalid { observation, reason, post_deadline, .. } => {
                        log_raw(label, observation);
                        println!("REAP_FAILURE label={label} kind=consumed_invalid reason={reason:?} post_deadline={post_deadline:?}");
                    }
                    ReapFailure::AfterReap { reaped, deadline_error } => {
                        log_raw(label, &reaped.observation);
                        println!("REAP_FAILURE label={label} kind=after_valid_reap outcome={:?} error={deadline_error:?}", reaped.outcome);
                    }
                }
                println!("CUSTODY label={label} disposition=failure_retained identity={:?}", self.identity());
            }
        }
    }
}

struct Case {
    mode: u32,
    pid: i32,
    pidfd: i32,
    child_deadline_ns: u64,
    cleanup_deadline_ns: u64,
    deadline: Deadline,
    gate: OwnedFd,
    ready: OwnedFd,
    custody: Option<Custody>,
    // If cleanup consumes a positive exact raw event, retain it alongside the
    // original failure custody. It never becomes a fabricated ReapedChild/pass.
    recovery: Option<RawWaitObservation>,
}

fn optional_fd(value: i32) -> Option<OwnedFd> {
    (value >= 0).then(|| unsafe { OwnedFd::from_raw_fd(value) })
}

impl Case {
    fn create(mode: u32) -> Result<Self, String> {
        let before = now()?;
        let child_deadline_ns = before.checked_add(3_000_000_000).ok_or("clock overflow")?;
        let cleanup_deadline_ns = before.checked_add(5_000_000_000).ok_or("clock overflow")?;
        // The real parent cleanup timer is owned before clone; no failure may
        // create a child and only then attempt to allocate its cleanup timer.
        let deadline = Deadline::fixture_arm(cleanup_deadline_ns)?;
        deadline.check()?;
        let mut frame = SpawnFrame::default();
        unsafe { ptg_fixture_spawn(mode, child_deadline_ns, &mut frame); }
        println!("SPAWN mode={mode} cleanup_deadline_ns={cleanup_deadline_ns} frame={frame:?}");
        let timer = optional_fd(frame.timerfd);
        let gate_read = optional_fd(frame.gate_read);
        let gate = optional_fd(frame.gate_write);
        let ready = optional_fd(frame.ready_read);
        let ready_write = optional_fd(frame.ready_write);
        let pidfd = optional_fd(frame.pidfd);
        if frame.result != 1 || frame.pid <= 0 {
            // No successful clone: retain all native failure values and close
            // every setup FD returned by C. ENOSYS/EPERM have no fallback.
            drop((timer, gate_read, gate, ready, ready_write, pidfd));
            return Err(format!("clone refused mode={mode} raw={frame:?}"));
        }
        if pidfd.is_none() || gate.is_none() || ready.is_none() {
            // A broken success ABI cannot be promoted into normal ownership.
            // Keep exact clone PID/setup handles quarantined until shutdown;
            // the child's prearmed timer and finite unit still bound the tree.
            eprintln!("QUARANTINE positive_clone_without_required_fd raw={frame:?}");
            std::mem::forget((timer, gate_read, gate, ready, ready_write, pidfd, deadline));
            return Err("positive clone missing required owned descriptors".into());
        }
        let child = unsafe { DirectChild::from_successful_clone(frame.pid, pidfd.expect("checked")) };
        // Parent must not retain the child's timer or pipe ends. Child keeps its
        // own inherited timer and monitors it; no disarm/rearm occurs anywhere.
        drop((timer, gate_read, ready_write));
        let mut case = Self {
            mode, pid: frame.pid, pidfd: child.pidfd.as_raw_fd(), child_deadline_ns,
            cleanup_deadline_ns, deadline, gate: gate.expect("checked"),
            ready: ready.expect("checked"), custody: Some(Custody::Owned(child)), recovery: None,
        };
        let valid = frame.schema == 1 && frame.call_errno == 0 && frame.setup_close_errno == 0
            && frame.reserved == 0 && frame.child_deadline_ns == child_deadline_ns
            && before <= frame.before_arm_ns && frame.before_arm_ns <= frame.after_arm_ns
            && frame.after_arm_ns <= frame.before_clone_ns && frame.before_clone_ns <= frame.after_clone_ns
            && frame.after_clone_ns < child_deadline_ns && frame.armed_remaining_ns > 0;
        if !valid {
            return case.fail("post-clone setup/clock receipt differs".into());
        }
        case.custody.as_ref().expect("owned").log("clone_bound");
        Ok(case)
    }

    fn wait_event(&self, event: i32) -> Result<i32, String> {
        loop {
            self.deadline.check()?;
            let (mut event_bits, mut timer_bits, mut error) = (0, 0, 0);
            let result = unsafe { ptg_fixture_poll(event, self.deadline.timer_fd(),
                &mut event_bits, &mut timer_bits, &mut error) };
            println!("POLL mode={} event={event} result={result} errno={error} event_bits={event_bits} timer_bits={timer_bits}", self.mode);
            if result < 0 && error as u64 == unsafe { ptg_fixture_spawn_abi(13) } { continue; }
            demand(result > 0 && error == 0 && timer_bits == 0, "event poll failed or cleanup timer fired")?;
            self.deadline.check()?;
            let allowed = unsafe { ptg_fixture_spawn_abi(15) | ptg_fixture_spawn_abi(16) } as i32;
            demand(event_bits > 0 && event_bits & !allowed == 0, "unexpected event revents")?;
            return Ok(event_bits);
        }
    }

    fn poll_owned(&mut self, label: &str) -> Result<bool, String> {
        let custody = self.custody.take().expect("custody is always restored");
        let child = match custody {
            Custody::Owned(child) => child,
            other => { self.custody = Some(other); return Err("nonreusable custody cannot be polled".into()); }
        };
        let (state, pending) = match poll_reap(child, &self.deadline) {
            Ok(ReapStep::Pending { child, observation, after_ns }) => {
                // Move the same owner back before any diagnostic formatting.
                self.custody = Some(Custody::Owned(child));
                log_raw(label, &observation);
                println!("PENDING mode={} after_ns={after_ns} identity={:?}", self.mode,
                    self.custody.as_ref().expect("restored").identity());
                demand(self.custody.as_ref().expect("restored").identity() == (self.pid, self.pidfd),
                    "Pending changed original PID/pidfd")?;
                return Ok(true);
            }
            Ok(ReapStep::Reaped(reaped)) => (Custody::Reaped(reaped), false),
            Err(error) => (Custody::Failure(error), false),
        };
        self.custody = Some(state);
        self.custody.as_ref().expect("restored").log(label);
        demand(!matches!(self.custody, Some(Custody::Failure(_))), "native reaper failed with custody retained")?;
        Ok(pending)
    }

    fn await_reap(&mut self) -> Result<(), String> {
        loop {
            if !self.poll_owned("await_reap")? { return Ok(()); }
            self.wait_event(self.pidfd)?;
        }
    }

    fn execute(&mut self) -> Result<(), String> {
        self.wait_event(self.ready.as_raw_fd())?;
        let mut token = 0u8;
        let result = unsafe { read(self.ready.as_raw_fd(), (&mut token as *mut u8).cast(), 1) };
        demand(result == 1 && token == b'R', "readiness token differs")?;
        if self.mode != 1 {
            demand(self.poll_owned("gated_before_release")?, "held child exited before release/signal")?;
            if self.mode == 2 {
                self.deadline.check()?;
                let token = b'G';
                let result = unsafe { write(self.gate.as_raw_fd(), (&token as *const u8).cast(), 1) };
                demand(result == 1, "nonblocking gate write failed")?;
                println!("RELEASE mode=2 pid={} pidfd={}", self.pid, self.pidfd);
            } else {
                let mut error = 0;
                let result = unsafe { ptg_fixture_signal(self.pidfd, 0, &mut error) };
                println!("SIGNAL mode=3 pid={} pidfd={} signal=SIGTERM result={result} errno={error}", self.pid, self.pidfd);
                demand(result == 0 && error == 0, "pidfd SIGTERM failed")?;
            }
        }
        self.await_reap()?;
        let reaped = match self.custody.as_ref() {
            Some(Custody::Reaped(child)) => child,
            _ => return Err("no exact ReapedChild receipt".into()),
        };
        let expected = match self.mode {
            1 => ExitOutcome::Exited { code: 23 },
            2 => ExitOutcome::Exited { code: 29 },
            _ => ExitOutcome::Signaled { signal: unsafe { ptg_fixture_spawn_abi(8) } as i32, core_dumped: false },
        };
        demand(reaped.pid() == self.pid && reaped.outcome() == expected,
            "exact native terminal outcome differs")?;
        demand(reaped.observation().frame.uid == unsafe { getuid() }, "wait UID differs")?;
        // Borrow the still-held pidfd from an already validated receipt. No
        // second DirectChild or successful reap receipt can be constructed.
        let repeat = direct_raw(self.pid, self.pidfd, self.deadline.check()?)?;
        log_raw("repeat_after_reaped", &repeat);
        let repeat_consumed = repeat.frame.called == 1 && repeat.frame.result == 0 && repeat.frame.pid > 0;
        let post = self.deadline.check();
        demand(!repeat_consumed && repeat.frame.called == 1 && repeat.frame.result == -1
            && repeat.frame.call_errno as u64 == unsafe { ptg_fixture_spawn_abi(12) },
            "repeat wait did not return native ECHILD")?;
        post?;
        println!("CASE_PASSED mode={} pid={} pidfd={} child_deadline_ns={} cleanup_deadline_ns={} outcome={expected:?} repeat=ECHILD",
            self.mode, self.pid, self.pidfd, self.child_deadline_ns, self.cleanup_deadline_ns);
        Ok(())
    }

    fn cleanup(&mut self) -> Result<(), String> {
        self.custody.as_ref().expect("retained").log("failure_before_cleanup");
        if self.custody.as_ref().expect("retained").exact_reaped() {
            println!("FAILURE_CLEANUP mode={} state=already_exact_reaped", self.mode);
            return Ok(());
        }
        // Attempt termination through the original held pidfd before any new
        // clock/ABI query. No cleanup result changes the original failed verdict.
        let mut error = 0;
        let result = unsafe { ptg_fixture_signal(self.pidfd, 1, &mut error) };
        println!("FAILURE_KILL mode={} pid={} pidfd={} result={result} errno={error}", self.mode, self.pid, self.pidfd);
        demand(result == 0 || (result == -1 && error as u64 == unsafe { ptg_fixture_spawn_abi(14) }),
            "pidfd cleanup SIGKILL failed")?;
        loop {
            let observed = direct_raw(self.pid, self.pidfd, self.deadline.check()?)?;
            // Classify consumption before a post-wait clock query.
            let abi = verified_abi().map_err(|failure| failure.reason.to_owned())?;
            let consumed = matches!(classify(&observed, &abi), Classification::Reaped(_));
            let positive = observed.frame.called == 1 && observed.frame.result == 0 && observed.frame.pid > 0;
            let pending = matches!(classify(&observed, &abi), Classification::Pending);
            self.recovery = Some(observed);
            log_raw("failure_cleanup_raw", self.recovery.as_ref().expect("retained"));
            if consumed {
                println!("FAILURE_CLEANUP mode={} state=exact_raw_reaped original_failure_unchanged=true post_deadline={:?}",
                    self.mode, self.deadline.check());
                return Ok(());
            }
            demand(!positive && pending, "cleanup wait ambiguous; custody quarantined")?;
            self.deadline.check()?;
            self.wait_event(self.pidfd)?;
        }
    }

    fn fail<T>(mut self, original: String) -> Result<T, String> {
        let cleanup = self.cleanup();
        eprintln!("CASE_FAILED mode={} original={original:?} cleanup={cleanup:?} passing_receipt=false", self.mode);
        if cleanup.is_err() {
            // Deliberate quarantine: retain all real custody and timers until
            // this test process shuts down. Child timer and outer unit remain
            // active; no claim of automatic Drop termination/reaping is made.
            eprintln!("QUARANTINE mode={} identity=({}, {}) child_deadline_ns={} outer_scope_required=true",
                self.mode, self.pid, self.pidfd, self.child_deadline_ns);
            std::mem::forget(self);
        }
        Err(format!("case failed: {original}; cleanup={cleanup:?}"))
    }
}

fn fd_count() -> Result<usize, String> {
    std::fs::read_dir("/proc/self/fd").map_err(|error| error.to_string())?
        .collect::<Result<Vec<_>, _>>().map(|values| values.len()).map_err(|error| error.to_string())
}

fn run() -> Result<(), String> {
    let mut error = 0;
    let ordinary = unsafe { ptg_fixture_ordinary(&mut error) };
    demand(ordinary == 0 && error == 0, &format!("ordinary/SIGTERM preflight errno={error}"))?;
    let words: Vec<_> = (0..18).map(|index| unsafe { ptg_fixture_spawn_abi(index) }).collect();
    println!("FIXTURE_ABI words={words:?}");
    demand(words[..4] == [1, size_of::<SpawnFrame>() as u64, align_of::<SpawnFrame>() as u64,
                         offset_of!(SpawnFrame, child_deadline_ns) as u64], "spawn C/Rust ABI differs")?;
    let baseline = fd_count()?;
    for mode in 1..=3 {
        let mut case = Case::create(mode)?;
        if let Err(error) = case.execute() { return case.fail(error); }
        drop(case);
        demand(fd_count()? == baseline, "fixture leaked a parent descriptor")?;
    }
    println!("SEQUENTIAL_REAPER_PASSED cases=3 exit23=verified pending_release29=verified pidfd_sigterm=verified repeat_echild=3 payload_execs=0 cgroup_operations=0 descriptors=settled");
    Ok(())
}

#[test]
fn sequential_native_children() {
    if let Err(error) = run() {
        panic!("sequential native child qualification failed: {error}");
    }
}
