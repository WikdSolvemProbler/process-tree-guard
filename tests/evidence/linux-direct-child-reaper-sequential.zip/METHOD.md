# Linux011 sequential ordinary child-reaper qualification (prepared, unrun)

This fresh directory preserves010 and uses its actual DirectChild, poll_reap,
installed-header waitid bridge and Deadline. No production backend is enabled.
The fixture is one exact Rust test. It runs only under a separately reviewed
finite ordinary-user launch plan after two exact-source reviews.

The three cases run sequentially, never concurrently: clone3(CLONE_PIDFD) child
exits23; a pipe-held child first yields actual Pending with the original
PID/pidfd, then exits29 after one permit byte; a pipe-held child first yields
Pending, then receives SIGTERM through that exact pidfd and yields a native
signaled receipt. Each validated ReapedChild retains its pidfd for one explicit
raw repeated wait, which must return ECHILD. No second DirectChild or successful
reap receipt is fabricated for that repeat. All native wait bytes and normalized
fields, ABI words, clone PID/fds, timer bounds and status are printed to retained
raw streams. A native refusal (including ENOSYS/EPERM) stops without fallback.

Before each clone, Rust owns a real parent cleanup Deadline at now+5s. C creates
and arms the child's separate CLOCK_BOOTTIME timerfd at the same now+3s absolute
deadline, reads it back, and records arm-before-clone timestamps. Every held
child loop polls that inherited timer together with its nonblocking pipe and
exits124 on timer readiness. Ready/gate pipes are O_NONBLOCK|O_CLOEXEC. Parent
polls include the already-armed cleanup timer. Neither timer is rearmed.

The child executes only fixed C code after fork-like clone3 without CLONE_VM:
async-signal-safe close/getppid/poll/read/write/_exit calls, no Rust, allocation,
stdio, locks, exec, credentials, namespaces, process creation or payload work.
The Rust test harness may contain its own main thread; it never executes Rust
in the cloned child. Signal disposition/mask readback must show SIGTERM and
SIGCHLD default and unblocked, with SA_NOCLDWAIT absent. No disposition or mask
is changed. Exact one-selected-test execution excludes another harness waiter;
the constant ABI reporter does not establish exclusive wait ownership.

Every nonnegative setup FD returned before a failed clone is owned and closed
by the parent. A successful clone binds the returned PID+pidfd to actual
DirectChild before validation of post-clone clock facts. Post-clone errors retain
that owner (including actual ReapFailure variants). Cleanup first attempts
SIGKILL through the held pidfd, then uses raw WNOHANG waits under the original
parent cleanup timer. A valid positive cleanup event is retained alongside the
original failure and never changes the failed qualification verdict. Positive
invalid or ECHILD without a prior genuine reap is ambiguous and quarantined.
Consumed state is classified before subsequent clock validation.

If cleanup cannot establish an exact terminal receipt, the fixture explicitly
quarantines its real owners/FDs until process shutdown (no Drop cleanup claim).
The child's inherited3s timer and independently enforced enclosing user scope
still bound descendants. Native syscall scheduling or a blocked kernel call
requires that external scope; the timerfd alone cannot forcibly interrupt it.

No root, cgroup provisioning/placement/kill, payload exec, process discovery,
adversarial concurrency, global setting/account change or daemon is included.
Only /proc/self/fd is enumerated to check the fixture's own descriptor baseline.
The earlier rejected privileged concurrency experiment is not resumed or routed
through this qualification. Populated cgroup drain, watchdog supervision,
adopted descendants/subreaper rules, full terminal orchestration and production
activation remain open. After this component the next implementation target is
the actual full-run terminal owner, including exec-report/lease/watchdog custody
and removal only after exact direct/adopted reaping.
