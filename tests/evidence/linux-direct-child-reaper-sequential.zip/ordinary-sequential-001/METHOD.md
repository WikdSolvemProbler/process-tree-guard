# Prepared Linux011 ordinary sequential child fixture

Prepared only. Source candidate71ebdbb20a9af5a347a8bdbf46c0fa597eaa03b6d52bbdc7de818dbba1d69714
is reviewed for this ordinary three-child sequential scope. This exact launch
plan and all preparation helpers must also pass both independent reviews before
the single attempt. No runtime or build has happened under this attempt ID.

The chain is Windows Job100s → pinned Mac gtimeout80s/kill-after3s → guest waiting
client timeout75s/kill-after3s → verified ordinary user scope70s. Actual UID501,
ARM64 and RuntimeMax/KillMode=control-group/KillSignal=9/SendSIGKILL=yes/cgroup
membership are checked before source staging. SSH is noninteractive with strict
known hosts and8s connection timeout. There is no sudo/admin/root fallback.

The launcher reads plan/source/command/payload bytes once and uses those same
verified buffers. Source goes into a fresh UID5010700 private scratch. Rust and
GCC have exact hashes inherited from010. Compiler, constant ABI reporter and
fixture environments receive fixed PATH/locale/privateTMPDIR; compiler/include/
loader/Rust test override keys are removed per process and only present-value
hashes are retained. This changes no host setting.

GCC dependency lists and identities/bytes/hashes/times are verified before and
after each C translation unit: unchanged010 waitid bridge and ABI reporter,
plus011 child fixture. Only pinned private sources or root-owned non-writable
installed headers under the three declared include roots are accepted. A trusted
administrator/toolchain is assumed; this is not a hostile-root ABA proof.

First run the constant ABI reporter. It performs no wait/clone and is distinct
from the fixture. It must agree with the40-byte normalized frame and describe
the actual native siginfo layout/flags without a Rust padding assumption.
Then compile actual full-graph ordinary and test objects with warnings denied.
Link the real test binary with the verified C objects and exact GCC linker.
Run --list with --exact and assert the sole fully qualified fixture test and
the summary1test/0benchmarks. Check all source and binary bytes again. Invoke
exactly that one selected test with --nocapture --test-threads=1. The selected
Rust test creates only three sequential native no-exec children; other compiled
tests, the old main, root fixtures and other control lanes are never invoked.

Accept success only with exit0, exactly one selected test passing, ordered mode
receipts1/2/3, all three repeat-ECHILD raw streams, at least the two held Pending
observations, and the unique terminal marker. Raw streams remain authoritative:
receipt checks do not substitute for reviewing the actual kernel observations.
Every runtime refusal/error stops without a retry, alternate clone API or root
fallback. Partial raw streams and source/artifact inventory are preserved.

The3s child timer and5s parent cleanup timer are prearmed before each clone.
The child actually polls its timer, and every parent wait polls its cleanup
timer. Native syscalls can still block; the outer finite scope independently
covers abrupt termination and all inherited descendants. The fixture's cleanup
routine attempts held-pidfd SIGKILL before its failure-formatting/clock/ABI work.
Earlier per-call raw diagnostics can precede entering that cleanup routine;
there is no claim that every possible failure message follows termination.
Failed exact cleanup retains original custody for explicit quarantine until
the test process exits; it cannot mint a passing qualification.

Preservation uses a distinct ordinary30s scope, guest35s/Mac45s/Windows65s. It
checks the original unit/cgroup gone and only exact recorded controller/tool/
fixture PIDs absent (no global process discovery and no fabricated creation-time
claim). It validates original UID5010700 scratch device/inode and every regular
file through held no-follow FDs, downloads raw bytes and source/object/binary/
header evidence, and verifies a local pre-removal ZIP before removal is enabled.
Removal checks that same held directory and each preserved file identity/hash
again, removes only the exact observed inventory descriptor-relatively, and
confirms the original scratch absent. Unexpected identity/file/process state
refuses removal and remains quarantined; no guessed recursive deletion occurs.

This qualifies only ordinary native direct-child reaping if the sole attempt
passes. It does not qualify populated cgroup drain, original-lease supervision,
watchdog settlement, exec-report ownership, adopted descendants/subreaper
semantics, full terminal orchestration, production activation or performance.
No payload exec, privilege, namespace/account/setting change, daemon, adversarial
concurrency or prior rejected privileged concurrency experiment is included.
