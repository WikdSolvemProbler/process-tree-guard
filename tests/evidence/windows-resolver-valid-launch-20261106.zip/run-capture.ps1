param(
    [Parameter(Mandatory)][string]$Manifest,
    [Parameter(Mandatory)][string]$ManifestSha256,
    [Parameter(Mandatory)][string]$Approval,
    [Parameter(Mandatory)][string]$ApprovalSha256,
    [Parameter(Mandatory)][string]$Attempt,
    [Parameter(Mandatory)][string]$ReceiptDir
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false

function Get-Digest([string]$Path) {
    (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

function Read-Json([string]$Path) {
    Get-Content -LiteralPath $Path -Raw -Encoding utf8 | ConvertFrom-Json -AsHashtable
}

if ((Get-Digest $Manifest) -cne $ManifestSha256 -or (Get-Digest $Approval) -cne $ApprovalSha256) {
    throw 'Manifest or approval digest mismatch'
}
$plan = Read-Json $Manifest
if ($plan.invocation.manifest -cne $Manifest -or $plan.invocation.approval -cne $Approval -or
    $plan.invocation.attempt -cne $Attempt -or $plan.invocation.receipt_dir -cne $ReceiptDir) {
    throw 'Capture arguments differ from the manifest invocation'
}
$approvalReceipt = Read-Json $Approval
if ($approvalReceipt.state -cne 'APPROVED' -or $approvalReceipt.manifest_sha256 -cne $ManifestSha256 -or
    ($approvalReceipt.reviewers -join ',') -cne 'resolver_method,resolver_critic') {
    throw 'The exact capture manifest has not been approved'
}
foreach ($role in @('wrapper', 'outer_guard', 'controller_python', 'driver')) {
    $asset = $plan.assets[$role]
    if ((Get-Digest $asset.path) -cne $asset.sha256) {
        throw "Wrapper input digest mismatch for $role"
    }
}
if ((Get-Digest $PSCommandPath) -cne $plan.assets.wrapper.sha256 -or $plan.outer_seconds -ne 120) {
    throw 'Wrapper identity or primary deadline mismatch'
}
if ((Test-Path -LiteralPath $Attempt) -or (Test-Path -LiteralPath $ReceiptDir)) {
    throw 'Attempt and receipt paths must be fresh'
}

New-Item -ItemType Directory -Path $ReceiptDir -ErrorAction Stop | Out-Null
$stdout = Join-Path $ReceiptDir 'stdout.log'
$stderr = Join-Path $ReceiptDir 'stderr.log'
$guard = $plan.assets.outer_guard.path
$argv = @(
    '--timeout', '120', '--', $plan.assets.controller_python.path,
    '-I', '-B', $plan.assets.driver.path, 'capture', '--manifest', $Manifest,
    '--manifest-sha256', $ManifestSha256, '--approval', $Approval,
    '--approval-sha256', $ApprovalSha256, '--out', $Attempt
)
$before = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
& $guard @argv 1> $stdout 2> $stderr
$primaryExit = $LASTEXITCODE
$after = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()

$attemptFiles = [ordered]@{}
foreach ($name in @('preflight.json', 'postflight.json', 'terminal.json', 'journal.jsonl', 'telemetry.jsonl')) {
    $file = Join-Path $Attempt $name
    if (Test-Path -LiteralPath $file -PathType Leaf) {
        $attemptFiles[$name] = Get-Digest $file
    }
}
$controller = $null
$primary = $null
$observed = [System.Collections.Generic.Dictionary[int, System.Collections.Generic.HashSet[long]]]::new()
function Add-Identity([int]$Id, [long]$Created) {
    if ($Id -le 0 -or $Created -le 0) {
        throw 'An observed process identity was incomplete'
    }
    if (!$observed.ContainsKey($Id)) {
        $observed.Add($Id, [System.Collections.Generic.HashSet[long]]::new())
    }
    [void]$observed[$Id].Add($Created)
}

$terminalComplete = $false
$observationError = $null
$remaining = @()
try {
    if ($attemptFiles.Contains('terminal.json')) {
        $terminal = Read-Json (Join-Path $Attempt 'terminal.json')
        $terminalComplete = $terminal.state -ceq 'COMPLETE' -and $terminal.complete -eq $true
    }
    if ($attemptFiles.Contains('preflight.json')) {
        $preflight = Read-Json (Join-Path $Attempt 'preflight.json')
        $controller = @{
            pid = $preflight.controller_pid
            creation_filetime = $preflight.controller_creation_filetime
        }
        $primary = $preflight.outer_guard
        Add-Identity $controller.pid $controller.creation_filetime
        Add-Identity $primary.pid $primary.creation_filetime
    }
    if ($attemptFiles.Contains('journal.jsonl')) {
        foreach ($line in Get-Content -LiteralPath (Join-Path $Attempt 'journal.jsonl') -Encoding utf8) {
            $row = $line | ConvertFrom-Json -AsHashtable
            if ($row.Contains('identity_before')) {
                Add-Identity $row.identity_before.pid $row.identity_before.creation_time
            }
        }
    }
    if ($observed.Count) {
        $remaining = @(
            Get-Process -Id @($observed.Keys) -ErrorAction SilentlyContinue | ForEach-Object {
                $creation = $_.StartTime.ToFileTimeUtc()
                [ordered]@{
                    pid = $_.Id
                    creation_filetime = $creation
                    observed_instance = $observed[$_.Id].Contains($creation)
                }
            }
        )
    }
} catch {
    $observationError = $_.Exception.Message
}
$observedAlive = @($remaining | Where-Object { $_.observed_instance })
$receipt = [ordered]@{
    schema = 'ptg-resolver-wrapper-v1'
    manifest_sha256 = $ManifestSha256
    approval_sha256 = $ApprovalSha256
    primary_guard_sha256 = $plan.assets.outer_guard.sha256
    primary_exit = $primaryExit
    guard_argv = $argv
    started_unix_ms = $before
    finished_unix_ms = $after
    stdout_sha256 = Get-Digest $stdout
    stderr_sha256 = Get-Digest $stderr
    attempt_sha256 = $attemptFiles
    primary_guard_pid = if ($null -ne $primary) { $primary.pid } else { $null }
    controller_pid = if ($null -ne $controller) { $controller.pid } else { $null }
    observed_pid_count = $observed.Count
    current_processes = $remaining
    observed_instances_alive = $observedAlive.Count
    observation_error = $observationError
}
$receiptPath = Join-Path $ReceiptDir 'wrapper.json'
$receiptJson = $receipt | ConvertTo-Json -Depth 8
$receiptBytes = [Text.Encoding]::UTF8.GetBytes($receiptJson + [Environment]::NewLine)
$pending = Join-Path $ReceiptDir 'wrapper.pending.json'
$stream = [IO.File]::Open($pending, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
try {
    $stream.Write($receiptBytes, 0, $receiptBytes.Length)
    $stream.Flush($true)
} finally {
    $stream.Dispose()
}
[IO.File]::Move($pending, $receiptPath)
if ($primaryExit -ne 0) { exit $primaryExit }
if ($observationError -or $observedAlive.Count -or !$terminalComplete) { exit 125 }
exit 0
