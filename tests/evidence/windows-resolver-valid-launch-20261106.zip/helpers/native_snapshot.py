"""Standalone Win32 qualification adapter, copied structure layouts; no harness imports."""
import ctypes as C
from ctypes import wintypes as W
import msvcrt
import os
import subprocess
import time

if os.name != "nt": raise RuntimeError("Windows-only qualification")
k = C.WinDLL("kernel32", use_last_error=True)
HANDLE = W.HANDLE
SIZE_T = C.c_size_t
ULONG_PTR = C.c_size_t
class FILETIME(C.Structure):
    _fields_ = [("low", W.DWORD), ("high", W.DWORD)]


class STARTUPINFO(C.Structure):
    _fields_ = [
        ("cb", W.DWORD),
        ("reserved", W.LPWSTR),
        ("desktop", W.LPWSTR),
        ("title", W.LPWSTR),
        ("x", W.DWORD),
        ("y", W.DWORD),
        ("xsize", W.DWORD),
        ("ysize", W.DWORD),
        ("xchars", W.DWORD),
        ("ychars", W.DWORD),
        ("fill", W.DWORD),
        ("flags", W.DWORD),
        ("show", W.WORD),
        ("reserved2size", W.WORD),
        ("reserved2", C.POINTER(C.c_ubyte)),
        ("stdin", HANDLE),
        ("stdout", HANDLE),
        ("stderr", HANDLE),
    ]


class STARTUPINFOEX(C.Structure):
    _fields_ = [("info", STARTUPINFO), ("attributes", C.c_void_p)]


class PROCESS_INFORMATION(C.Structure):
    _fields_ = [
        ("process", HANDLE),
        ("thread", HANDLE),
        ("pid", W.DWORD),
        ("tid", W.DWORD),
    ]


class BASIC_LIMIT(C.Structure):
    _fields_ = [
        ("process_user_time", C.c_int64),
        ("job_user_time", C.c_int64),
        ("flags", W.DWORD),
        ("min_ws", SIZE_T),
        ("max_ws", SIZE_T),
        ("active_process_limit", W.DWORD),
        ("affinity", ULONG_PTR),
        ("priority_class", W.DWORD),
        ("scheduling_class", W.DWORD),
    ]


class IO_COUNTERS(C.Structure):
    _fields_ = [
        (n, C.c_uint64)
        for n in (
            "read_ops",
            "write_ops",
            "other_ops",
            "read_bytes",
            "write_bytes",
            "other_bytes",
        )
    ]


class EXTENDED_LIMIT(C.Structure):
    _fields_ = [
        ("basic", BASIC_LIMIT),
        ("io", IO_COUNTERS),
        ("process_memory_limit", SIZE_T),
        ("job_memory_limit", SIZE_T),
        ("peak_process_memory", SIZE_T),
        ("peak_job_memory", SIZE_T),
    ]


class BASIC_ACCOUNTING(C.Structure):
    _fields_ = [
        ("user_100ns", C.c_int64),
        ("kernel_100ns", C.c_int64),
        ("period_user_100ns", C.c_int64),
        ("period_kernel_100ns", C.c_int64),
        ("page_faults", W.DWORD),
        ("total_processes", W.DWORD),
        ("active_processes", W.DWORD),
        ("terminated_processes", W.DWORD),
    ]


class MEMORY_STATUS(C.Structure):
    _fields_ = [
        ("length", W.DWORD),
        ("load_percent", W.DWORD),
        ("total_physical", C.c_uint64),
        ("available_physical", C.c_uint64),
        ("total_pagefile", C.c_uint64),
        ("available_pagefile", C.c_uint64),
        ("total_virtual", C.c_uint64),
        ("available_virtual", C.c_uint64),
        ("available_extended_virtual", C.c_uint64),
    ]



def definition(name, args, restype):
    function = getattr(k, name)
    function.argtypes, function.restype = args, restype
    return function

CloseHandle = definition("CloseHandle", [HANDLE], W.BOOL)
GetProcessId = definition("GetProcessId", [HANDLE], W.DWORD)
GetProcessTimes = definition("GetProcessTimes", [HANDLE, C.POINTER(FILETIME), C.POINTER(FILETIME), C.POINTER(FILETIME), C.POINTER(FILETIME)], W.BOOL)
WaitForSingleObject = definition("WaitForSingleObject", [HANDLE, W.DWORD], W.DWORD)
GetExitCodeProcess = definition("GetExitCodeProcess", [HANDLE, C.POINTER(W.DWORD)], W.BOOL)
TerminateProcess = definition("TerminateProcess", [HANDLE, W.UINT], W.BOOL)
CreateJobObjectW = definition("CreateJobObjectW", [C.c_void_p, W.LPCWSTR], HANDLE)
SetInformationJobObject = definition("SetInformationJobObject", [HANDLE, C.c_int, C.c_void_p, W.DWORD], W.BOOL)
QueryInformationJobObject = definition("QueryInformationJobObject", [HANDLE, C.c_int, C.c_void_p, W.DWORD, C.POINTER(W.DWORD)], W.BOOL)
AssignProcessToJobObject = definition("AssignProcessToJobObject", [HANDLE, HANDLE], W.BOOL)
IsProcessInJob = definition("IsProcessInJob", [HANDLE, HANDLE, C.POINTER(W.BOOL)], W.BOOL)
TerminateJobObject = definition("TerminateJobObject", [HANDLE, W.UINT], W.BOOL)
ResumeThread = definition("ResumeThread", [HANDLE], W.DWORD)
CreateProcessW = definition("CreateProcessW", [W.LPCWSTR, W.LPWSTR, C.c_void_p, C.c_void_p, W.BOOL, W.DWORD, C.c_void_p, W.LPCWSTR, C.POINTER(STARTUPINFO), C.POINTER(PROCESS_INFORMATION)], W.BOOL)
InitializeProcThreadAttributeList = definition("InitializeProcThreadAttributeList", [C.c_void_p, W.DWORD, W.DWORD, C.POINTER(SIZE_T)], W.BOOL)
UpdateProcThreadAttribute = definition("UpdateProcThreadAttribute", [C.c_void_p, W.DWORD, SIZE_T, C.c_void_p, SIZE_T, C.c_void_p, C.c_void_p], W.BOOL)
DeleteProcThreadAttributeList = definition("DeleteProcThreadAttributeList", [C.c_void_p], None)
QueryPerformanceCounter = definition("QueryPerformanceCounter", [C.POINTER(C.c_int64)], W.BOOL)
QueryPerformanceFrequency = definition("QueryPerformanceFrequency", [C.POINTER(C.c_int64)], W.BOOL)
GetTickCount64 = definition("GetTickCount64", [], C.c_uint64)
GlobalMemoryStatusEx = definition("GlobalMemoryStatusEx", [C.POINTER(MEMORY_STATUS)], W.BOOL)
PeekNamedPipe = definition("PeekNamedPipe", [HANDLE, C.c_void_p, W.DWORD, C.c_void_p, C.POINTER(W.DWORD), C.c_void_p], W.BOOL)
GetNamedPipeInfo = definition("GetNamedPipeInfo", [HANDLE, C.POINTER(W.DWORD), C.POINTER(W.DWORD), C.POINTER(W.DWORD), C.POINTER(W.DWORD)], W.BOOL)

def checked(value, what):
    if not value: raise C.WinError(C.get_last_error(), what)
    return value

_last_qpc = None

def qpc():
    global _last_qpc
    value = C.c_int64()
    checked(QueryPerformanceCounter(C.byref(value)), "QueryPerformanceCounter")
    if value.value < 0 or (_last_qpc is not None and value.value < _last_qpc): raise ValueError("negative/backwards external QPC")
    _last_qpc = value.value
    return value.value

def frequency():
    value = C.c_int64()
    checked(QueryPerformanceFrequency(C.byref(value)), "QueryPerformanceFrequency")
    if value.value <= 0: raise ValueError("nonpositive QPC frequency")
    return value.value

def receipt(api, call, **arguments):
    result = dict(api=api, arguments=arguments, query_start_qpc=qpc())
    C.set_last_error(0)
    result["native_return"] = int(call())
    result["last_error"] = C.get_last_error()
    result["query_end_qpc"] = qpc()
    C.set_last_error(result["last_error"])
    return result

def clock():
    before = qpc()
    tick = int(GetTickCount64())
    after = qpc()
    return dict(qpc_before=before, g_ms=tick, qpc_after=after, qpc_frequency=frequency())

def identity(handle):
    pid = checked(GetProcessId(handle), "GetProcessId")
    c, e, ktime, user = FILETIME(), FILETIME(), FILETIME(), FILETIME()
    checked(GetProcessTimes(handle, C.byref(c), C.byref(e), C.byref(ktime), C.byref(user)), "GetProcessTimes")
    return dict(pid=int(pid), creation_time=(int(c.high) << 32) | int(c.low))

def native_exit(handle):
    value = W.DWORD()
    checked(GetExitCodeProcess(handle, C.byref(value)), "GetExitCodeProcess")
    return int(value.value)

def probe(handle, expected):
    result = receipt("WaitForSingleObject", lambda: WaitForSingleObject(handle, 0), process_handle=int(handle), timeout_ms=0)
    try:
        if result["native_return"] not in (0,258): raise ValueError("unexpected original-handle wait result")
        result["identity_after"] = identity(handle)
        if result["identity_after"] != expected: raise ValueError("original process identity changed")
        if result["native_return"] == 0: result["clock_after_wait"] = clock()
    except BaseException as error: result["instrument_error"] = repr(error)
    return result

def admission():
    status = MEMORY_STATUS()
    status.length = C.sizeof(status)
    checked(GlobalMemoryStatusEx(C.byref(status)), "GlobalMemoryStatusEx")
    return dict(available_physical=int(status.available_physical), required_physical=896*1024*1024,
                admitted=int(status.available_physical) >= 896*1024*1024)

class Job:
    def __init__(self):
        self.handle = checked(CreateJobObjectW(None, None), "CreateJobObjectW")
        limits = EXTENDED_LIMIT()
        limits.basic.flags = 0x2000 | 0x200 | 0x8
        limits.basic.active_process_limit = 8
        limits.job_memory_limit = 384*1024*1024
        try: checked(SetInformationJobObject(self.handle, 9, C.byref(limits), C.sizeof(limits)), "SetInformationJobObject")
        except BaseException:
            CloseHandle(self.handle)
            self.handle = None
            raise
    def accounting(self):
        result = BASIC_ACCOUNTING()
        call = receipt("QueryInformationJobObject(BasicAccounting)", lambda: QueryInformationJobObject(self.handle, 1, C.byref(result), C.sizeof(result), None), job_handle=int(self.handle))
        checked(call["native_return"], "QueryInformationJobObject")
        call["values"] = {name:int(getattr(result,name)) for name, _ in result._fields_}
        return call
    def kill(self):
        checked(TerminateJobObject(self.handle, 0xe0000071), "TerminateJobObject")
    def close(self):
        if self.handle:
            CloseHandle(self.handle)
            self.handle = None

def launch(argv, job, stdfiles, env, cwd):
    """Retain original handles; release after assignment; clean every partial launch failure."""
    handles = (HANDLE*3)(*(msvcrt.get_osfhandle(item.fileno()) for item in stdfiles))
    process = PROCESS_INFORMATION()
    attributes_ready = False
    inherited = []
    launch_receipts = {}
    failure = result = storage = None
    try:
        size = SIZE_T()
        InitializeProcThreadAttributeList(None, 1, 0, C.byref(size))
        storage = C.create_string_buffer(size.value)
        checked(InitializeProcThreadAttributeList(storage, 1, 0, C.byref(size)), "InitializeProcThreadAttributeList")
        attributes_ready = True
        si = STARTUPINFOEX()
        si.info.cb, si.info.flags, si.info.show = C.sizeof(si), 0x100 | 1, 0
        si.info.stdin, si.info.stdout, si.info.stderr = handles
        si.attributes = C.cast(storage, C.c_void_p)
        for handle in handles:
            os.set_handle_inheritable(handle, True)
            inherited.append(handle)
        checked(UpdateProcThreadAttribute(storage, 0, 0x00020002, handles, C.sizeof(handles), None, None), "Handle whitelist")
        command = C.create_unicode_buffer(subprocess.list2cmdline([str(value) for value in argv]))
        block = C.create_unicode_buffer("\0".join(key+"="+value for key,value in sorted(env.items(), key=lambda item:item[0].upper()))+"\0\0")
        create = receipt("CreateProcessW", lambda: CreateProcessW(str(argv[0]), command, None, None, True, 0x4 | 0x80000 | 0x400 | 0x08000000, block, str(cwd), C.byref(si.info), C.byref(process)), flags=0x4 | 0x80000 | 0x400 | 0x08000000)
        launch_receipts["create"] = create
        checked(create["native_return"], "CreateProcessW")
        ident = identity(process.process)
        launch_receipts["identity"] = ident
        if ident["pid"] != int(process.pid): raise ValueError("original CreateProcess PID differs")
        assign = receipt("AssignProcessToJobObject", lambda: AssignProcessToJobObject(job.handle, process.process), job_handle=int(job.handle), process_handle=int(process.process))
        launch_receipts["assign"] = assign
        checked(assign["native_return"], "AssignProcessToJobObject")
        member = W.BOOL()
        checked(IsProcessInJob(process.process, job.handle, C.byref(member)), "IsProcessInJob")
        if member.value != 1: raise ValueError("original SUT not in exact emergency Job")
        live = probe(process.process, ident)
        launch_receipts["suspended_live_probe"] = live
        if live["native_return"] != 258 or live.get("instrument_error"): raise ValueError("suspended SUT native identity/liveness invalid: " + repr(live))
        release_clock = clock()
        launch_receipts["pre_resume_clock"] = release_clock
        resume = receipt("ResumeThread", lambda: ResumeThread(process.thread), thread_handle=int(process.thread))
        launch_receipts["resume"] = resume
        if resume["native_return"] != 1: raise ValueError("original primary thread previous suspend count differs from1")
        result = (int(process.process), dict(identity=ident, original_handle=int(process.process), create=create, assign=assign,
            exact_job_membership=True, suspended_live_probe=live, pre_resume_clock=release_clock, resume=resume))
    except BaseException as error:
        failure = error
    finally:
        cleanup_errors = []
        if process.thread:
            try:
                if not CloseHandle(process.thread): raise C.WinError(C.get_last_error(), "CloseHandle(original thread)")
            except BaseException as error: cleanup_errors.append(repr(error))
        if attributes_ready:
            try: DeleteProcThreadAttributeList(storage)
            except BaseException as error: cleanup_errors.append(repr(error))
        for handle in inherited:
            try: os.set_handle_inheritable(handle, False)
            except BaseException as error: cleanup_errors.append(repr(error))
        if cleanup_errors:
            launch_receipts["launch_finalizer_errors"] = cleanup_errors
            if failure is None: failure = ValueError("launch finalization failed: " + repr(cleanup_errors))
        if failure is not None and process.process:
            # Native creation may succeed even if its trailing QPC receipt fails.
            # A nonnull original handle, not an after-call boolean, owns cleanup.
            launch_receipts["partial_process_information"] = dict(process_handle=int(process.process), pid=int(process.pid))
            try:
                launch_receipts["failure_direct_terminate_return"] = int(TerminateProcess(process.process, 0xe0000072))
            except BaseException as error: launch_receipts["failure_direct_terminate_error"] = repr(error)
            try: job.kill()
            except BaseException as error: launch_receipts["failure_job_kill_error"] = repr(error)
            try: launch_receipts["failure_original_handle_wait"] = int(WaitForSingleObject(process.process, 500))
            except BaseException as error: launch_receipts["failure_original_handle_wait_error"] = repr(error)
            CloseHandle(process.process)
    if failure is not None:
        failure.native_launch_receipts = launch_receipts
        raise failure
    return result

def pipe_info(fd):
    flags, outsize, insize, instances = W.DWORD(), W.DWORD(), W.DWORD(), W.DWORD()
    checked(GetNamedPipeInfo(msvcrt.get_osfhandle(fd), C.byref(flags), C.byref(outsize), C.byref(insize), C.byref(instances)), "GetNamedPipeInfo")
    return dict(out_buffer=int(outsize.value), in_buffer=int(insize.value))

def available(fd):
    result = W.DWORD()
    checked(PeekNamedPipe(msvcrt.get_osfhandle(fd), None, 0, None, C.byref(result), None), "PeekNamedPipe")
    return int(result.value)
