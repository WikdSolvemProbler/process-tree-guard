"""Fail-closed Windows MSVC directional capture controller."""

import argparse
from contextlib import ExitStack
import ctypes as C
from ctypes import wintypes as W
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
CAPTURE_SOURCE = HERE / "capture.py"
SUSPENDED = HERE / "qualify-suspended.py"
FILETIME_EPOCH_NS = 11_644_473_600_000_000_000


def load_source(name, path, expected=None):
    import hashlib

    source = path.read_bytes()
    actual = hashlib.sha256(source).hexdigest()
    if expected is not None and actual != expected:
        raise ValueError(f"{name} source digest mismatch")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    exec(compile(source, str(path), "exec"), module.__dict__)
    return module, actual


A, ANALYSIS_SHA = load_source("capture_analysis", HERE / "analysis.py")
schedule = A.schedule


def hash_file(path):
    return A.sha(path.read_bytes())


def runtime_hold_bindings(manifest):
    bindings = {f"asset:{name}": value for name, value in manifest["assets"].items()}
    files = {
        "capture": (CAPTURE_SOURCE, "driver_sha256"),
        "suspended": (SUSPENDED, "suspended_sha256"),
        "analysis": (HERE / "analysis.py", "analysis_sha256"),
        "schedule_generator": (HERE / "schedule.py", "schedule_generator_sha256"),
        "python": (Path(sys.executable), "python_sha256"),
        "schedule": (Path(manifest["schedule"]["path"]), "schedule_sha256"),
    }
    for role, (path, key) in files.items():
        bindings[role] = {"path": str(path), "sha256": manifest[key]}
    for role in ("root", "backup"):
        policy = manifest["launch"]
        bindings[f"guard:{role}"] = {"path": policy[f"{role}_path"], "sha256": policy[f"{role}_sha256"]}
    return bindings


class RuntimeHold:
    """Keep independently opened read-share-only native handles until completion."""

    def __init__(self, bindings):
        kernel = C.WinDLL("kernel32", use_last_error=True)
        self.create = kernel.CreateFileW
        self.create.argtypes = (W.LPCWSTR, W.DWORD, W.DWORD, C.c_void_p, W.DWORD, W.DWORD, W.HANDLE)
        self.create.restype = W.HANDLE
        self.final_path = kernel.GetFinalPathNameByHandleW
        self.final_path.argtypes = (W.HANDLE, W.LPWSTR, W.DWORD, W.DWORD)
        self.final_path.restype = W.DWORD
        self.close = kernel.CloseHandle
        self.close.argtypes = (W.HANDLE,)
        self.close.restype = W.BOOL
        self.resources = ExitStack()
        self.bindings = bindings
        self.files = {}
        self.before = {}

    def open(self, path):
        import msvcrt

        handle = self.create(str(path), 0x80000000, 1, None, 3, 0x80, None)
        if handle in (None, C.c_void_p(-1).value):
            raise C.WinError(C.get_last_error(), f"read-share-only open: {path}")
        try:
            fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
        except BaseException:
            self.close(handle)
            raise
        try:
            return os.fdopen(fd, "rb", buffering=0)
        except BaseException:
            os.close(fd)
            raise

    def snapshot(self, stream, path):
        import hashlib
        import msvcrt

        name = C.create_unicode_buffer(32768)
        count = self.final_path(msvcrt.get_osfhandle(stream.fileno()), name, len(name), 0)
        A.require(0 < count < len(name), "held native path could not be resolved")
        final_path = name.value.removeprefix("\\\\?\\")
        A.require(os.path.normcase(final_path) == os.path.normcase(str(path)),
                  f"held file resolves to a different path: {path}")
        file_stat = os.fstat(stream.fileno())
        stream.seek(0)
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
        A.require(file_stat.st_ino > 0, f"held file identity unavailable: {path}")
        return {"path": str(path), "final_path": final_path, "sha256": digest,
                "volume": file_stat.st_dev, "file_id": file_stat.st_ino, "size": file_stat.st_size}

    def acquire(self):
        for role, binding in self.bindings.items():
            path = Path(binding["path"])
            A.require(path.is_absolute(), f"{role} hold path is not absolute")
            file = self.resources.enter_context(self.open(path))
            self.files[role] = file
            self.before[role] = self.snapshot(file, path)
            A.require(self.before[role]["sha256"] == binding["sha256"], f"{role} held bytes differ")
        return self.before

    def verify(self):
        after = {}
        for role, file in self.files.items():
            path = Path(self.bindings[role]["path"])
            held = self.snapshot(file, path)
            with self.open(path) as reopened:
                current = self.snapshot(reopened, path)
            A.require(held == current == self.before[role], f"{role} path or held bytes changed")
            after[role] = {"held": held, "reopened_path": current}
        return after

    def prove_denied_access(self, path):
        denied = {}
        for label, access in (("write", 0x40000000), ("delete", 0x00010000)):
            handle = self.create(str(path), access, 7, None, 3, 0x80, None)
            if handle not in (None, C.c_void_p(-1).value):
                self.close(handle)
                raise ValueError(f"runtime hold allowed {label} access")
            denied[label] = C.get_last_error()
            A.require(denied[label] == 32, f"{label} access did not fail with ERROR_SHARING_VIOLATION")
        return denied


def write_record(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(value, indent=2, allow_nan=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def verify_inputs(args):
    raw = args.manifest.read_bytes()
    A.require(A.valid_sha(args.manifest_sha256) and A.sha(raw) == args.manifest_sha256,
              "manifest digest mismatch")
    manifest = A.parse(raw)
    A.require(A.is_int(manifest.get("schema"), 1), "manifest schema mismatch")
    exact = {"driver_sha256": Path(__file__), "suspended_sha256": SUSPENDED,
             "python_sha256": Path(sys.executable)}
    for key, path in exact.items():
        A.require(hash_file(path) == manifest.get(key), f"{key} digest mismatch")
    A.require(manifest.get("analysis_sha256") == ANALYSIS_SHA
              and manifest.get("schedule_generator_sha256") == A.SCHEDULE_SOURCE_SHA,
              "loaded analysis or schedule digest mismatch")
    raw_plan = args.schedule.read_bytes()
    plan = A.parse(raw_plan)
    A.require(A.sha(raw_plan) == manifest.get("schedule_sha256")
              and schedule.schedule_bytes(plan["seed_hex"]) == raw_plan, "schedule mismatch")
    A.require(tuple(manifest["control_ids"]) == A.CONTROL_IDS, "control order differs")
    A.verify_admission(args.admission.read_bytes(), args.admission_sha256, args.manifest_sha256)
    return manifest, plan


def load_suspended(expected=None):
    return load_source("capture_suspended", SUSPENDED, expected)[0]


def qualification_receipts(manifest, D, outer_sha):
    bindings = manifest["qualification_receipts"]
    required = {"watchdog-3", "watchdog-10", "suspended", "safety", "ancestry"}
    A.require(set(bindings) == required, "incomplete exact native qualifications")
    qualified = {}
    for label, binding in bindings.items():
        path = Path(binding["path"])
        raw = path.read_bytes()
        digest = A.sha(raw)
        A.require(path.is_absolute() and digest == binding["sha256"], f"{label} qualification digest mismatch")
        row = A.parse(raw)
        if label == "ancestry":
            A.require(row.get("passed") is True and row.get("capture_driver_sha256") == manifest["driver_sha256"]
                      and row.get("job_membership_any") == {"controller": True, "root_guard": True}
                      and all(row["verified_chain"][role]["sha256"] == manifest["launch"][f"{role}_sha256"]
                              for role in ("root", "backup")), "ancestry qualification binding mismatch")
            qualified[label] = {"path": str(path), "sha256": digest}
            continue
        source_key = "suspended_driver_sha256" if label == "safety" else "driver_sha256"
        A.require(row.get("passed") is True and row.get(source_key) == manifest["suspended_sha256"]
                  and row["outer"].get("sha256") == outer_sha, f"{label} qualification binding mismatch")
        if label.startswith("watchdog-"):
            seconds = int(label.split("-")[1])
            original = row["suspended"]
            ended = row["root_before_cleanup"]
            final = row["root_after_cleanup"]
            for snapshot in (ended, final):
                A.require((original["pid"], original["creation_filetime"]) ==
                          (snapshot["pid"], snapshot["creation_filetime"]), f"{label} held identity changed")
            A.require(A.is_int(row["deadline_seconds"], seconds)
                      and A.is_int(row["armed_deadline_ns"], row["armed_ns"] + seconds * 1_000_000_000)
                      and row["armed_deadline_ns"] <= row["watchdog_fired_ns"] <= row["native_wait_observed_ns"]
                      and row["testkit_sha256"] == D.INPUTS["testkit"][1]
                      and row["watchdog_owns_distinct_job_handle"] is True
                      and row["watchdog_handle_closed"] is True
                      and row["watchdog_fired"] is True and A.is_int(row["watchdog_terminate_return"], 1)
                      and A.is_int(ended["native_wait"], 0) and A.is_int(ended["exit_code_u32"], D.WATCHDOG_EXIT)
                      and A.is_int(final["native_wait"], 0) and A.is_int(final["exit_code_u32"], D.WATCHDOG_EXIT)
                      and not row.get("trusted_cleanup_requested")
                      and A.is_int(row["accounting_after_cleanup"]["values"]["active_processes"], 0),
                      f"{label} asynchronous watchdog evidence mismatch")
        else:
            cases = row["cases"]
            if label == "suspended":
                names = set(A.CONTROL_IDS) | {f"{role}-{mode}-{workload}" for role in schedule.ARMS
                                              for mode in schedule.MODES for workload in schedule.WORKLOADS}
            else:
                names = {f"{role}-{mode}-{contract}" for role in ("main", "wake") for mode in schedule.MODES
                         for contract in ("owner-exits", "deadline", "normal-exit")}
            A.require(len(cases) == len(names) and {case["case"] for case in cases} == names
                      and all(case["passed"] is True and case["watchdog_handle_closed"] is True for case in cases),
                      f"{label} native qualification case population mismatch")
        qualified[label] = {"path": str(path), "sha256": digest}
    return qualified


def controller_argv():
    return [sys.executable, "-B", str(Path(__file__).resolve()), *sys.argv[1:]]


def guard_chain(S, manifest):
    import _winapi

    class Basic(C.Structure):
        _fields_ = [("exit_status", C.c_void_p), ("peb", C.c_void_p),
                    ("affinity", C.c_void_p), ("priority", C.c_void_p),
                    ("pid", C.c_size_t), ("parent_pid", C.c_size_t)]

    class UnicodeString(C.Structure):
        _fields_ = [("length", W.USHORT), ("maximum", W.USHORT), ("buffer", C.c_void_p)]

    ntquery = C.WinDLL("ntdll").NtQueryInformationProcess
    ntquery.argtypes = (W.HANDLE, W.ULONG, C.c_void_p, W.ULONG, C.POINTER(W.ULONG))
    ntquery.restype = W.LONG
    argv_parser = C.WinDLL("shell32", use_last_error=True).CommandLineToArgvW
    argv_parser.argtypes = (W.LPCWSTR, C.POINTER(C.c_int))
    argv_parser.restype = C.POINTER(W.LPWSTR)
    free = S.bind("LocalFree", [C.c_void_p], C.c_void_p)

    def inspect(pid):
        handle = _winapi.OpenProcess(S.SYNC_QUERY, False, pid)
        try:
            A.require(_winapi.WaitForSingleObject(handle, 0) == 258, "guard ancestor is already dead")
            size = W.DWORD(32768)
            image = C.create_unicode_buffer(size.value)
            S.native_ok(S.image_name(handle, 0, image, C.byref(size)))
            basic = Basic()
            A.require(ntquery(handle, 0, C.byref(basic), C.sizeof(basic), None) == 0
                      and basic.pid == pid, "cannot verify guard ancestor identity")
            storage = C.create_string_buffer(65536)
            returned = W.ULONG()
            A.require(ntquery(handle, 60, storage, C.sizeof(storage), C.byref(returned)) == 0,
                      "cannot verify actual guard ancestor command line")
            command = UnicodeString.from_buffer(storage)
            origin = C.addressof(storage)
            A.require(command.length > 0 and command.length % 2 == 0 and
                      origin <= command.buffer <= origin + len(storage) - command.length,
                      "guard command-line buffer is malformed")
            argc = C.c_int()
            argv = argv_parser(C.wstring_at(command.buffer, command.length // 2), C.byref(argc))
            S.native_ok(argv)
            try:
                values = [argv[index] for index in range(argc.value)]
            finally:
                free(C.cast(argv, C.c_void_p))
            creation, exit_time, kernel, user = [W.FILETIME() for _ in range(4)]
            S.native_ok(S.process_times(handle, *(C.byref(t) for t in (creation, exit_time, kernel, user))))
            return dict(pid=pid, parent_pid=basic.parent_pid, path=image.value, argv=values,
                        creation_filetime=(creation.dwHighDateTime << 32) | creation.dwLowDateTime)
        finally:
            _winapi.CloseHandle(handle)

    root = inspect(os.getppid())
    backup = inspect(root["parent_pid"])
    policy = manifest["launch"]
    root_seconds, backup_seconds = policy["root_seconds"], policy["backup_seconds"]
    reserve = policy["reserve_seconds"]
    A.require(all(map(A.positive_integer, (root_seconds, backup_seconds, reserve))) and
              11 <= reserve < root_seconds < backup_seconds <= 86400, "invalid total deadlines")
    tail = controller_argv()
    for name, observed, seconds in (("root", root, root_seconds), ("backup", backup, backup_seconds)):
        path = Path(policy[f"{name}_path"])
        expected_sha = policy[f"{name}_sha256"]
        A.require(path.is_absolute() and os.path.normcase(str(path)) == os.path.normcase(observed["path"])
                  and hash_file(path) == expected_sha, f"{name} guard binary mismatch")
        expected_argv = [str(path), "--timeout", str(seconds), "--", *tail]
        A.require(observed["argv"] == expected_argv, f"{name} guard argv/deadline mismatch")
        observed.update(sha256=expected_sha, timeout_seconds=seconds)
        tail = expected_argv
    A.require(root["sha256"] == S.OUTER_SHA, "root guard was not the qualified independent guard")
    A.require(root["creation_filetime"] >= backup["creation_filetime"], "guard creation order mismatch")
    # Creation time precedes deadline arming, so this deliberately subtracts
    # startup time from the available budget rather than borrowing it.
    now_ns = time.time_ns() + FILETIME_EPOCH_NS
    remaining = min(
        row["timeout_seconds"] - (now_ns - row["creation_filetime"] * 100) / 1e9
        for row in (root, backup))
    A.require(0 < remaining <= root_seconds, "guard deadline origin is inconsistent")
    return {"root": root, "backup": backup}, time.monotonic() + remaining - reserve


def telemetry(S):
    system_times = S.bind("GetSystemTimes", [C.POINTER(W.FILETIME)] * 3, W.BOOL)
    unbiased = S.bind("QueryUnbiasedInterruptTime", [C.POINTER(C.c_uint64)], W.BOOL)
    tick = S.bind("GetTickCount64", [], C.c_uint64)
    idle, kernel, user = [W.FILETIME() for _ in range(3)]
    active = C.c_uint64()
    S.native_ok(system_times(*(C.byref(t) for t in (idle, kernel, user))))
    S.native_ok(unbiased(C.byref(active)))
    values = [(t.dwHighDateTime << 32) | t.dwLowDateTime for t in (idle, kernel, user)]
    return dict(monotonic_ns=time.perf_counter_ns(), wall_ns=time.time_ns(), tick_ms=tick(),
                awake_100ns=active.value, idle_100ns=values[0], kernel_100ns=values[1], user_100ns=values[2])


def make_case(D, plan, folder, row):
    if plan["phase"] == "control":
        control = A.CONTROL_IDS[plan["control_slot"]]
        row["control_id"] = control
        kit = str(D.INPUTS["testkit"][0])
        values = {"exit-zero": 0, "exit-seven": 7, "exit-dword": 0xffffffff}
        if control in values:
            code = values[control]
            return [kit, "exit", str(code)], 3, code, b"", None
        if control == "forced-timeout":
            return [kit, "sleep", "5"], 3, None, b"", None
        marker = folder / "leak.pid"
        return [kit, "spawn-marked", "0", str(marker), "2", kit, "mark", str(marker), "5"], 3, 0, b"", marker
    role = plan["arm"]
    row["arm_sha256"] = D.INPUTS["fixture" if role == "bare" else role][1]
    row["token"] = token = uuid.uuid4().hex
    verb, duration, budget = ("exit", "0", 3) if plan["workload"] == "startup" else ("wait", "50", 10)
    payload = [str(D.INPUTS["fixture"][0]), verb, duration, token]
    if role != "bare":
        prefix = ["auto"] if plan["mode"] == "auto" else []
        payload = [str(D.INPUTS[role][0]), *prefix, "--timeout", "2", "--", *payload]
    return payload, budget, 0, f"BENCHMARK_DONE {verb} {duration} {token}\n".encode("ascii"), None


def run(args, out):
    capture = dict(schema=1, complete=False, driver_sha256=hash_file(Path(__file__)),
                   manifest_sha256=args.manifest_sha256, admission_sha256=args.admission_sha256, rows=[],
                   output_directory=str(out),
                   host_stability=dict(interrupted=False, suspend_resume=False,
                                       major_instrumentation_drift=False), telemetry=[])
    hold = None
    try:
        manifest, plan = verify_inputs(args)
        capture["schedule_sha256"] = manifest["schedule_sha256"]
        D = load_suspended(manifest["suspended_sha256"])
        A.require(C.sizeof(C.c_void_p) == 8 and os.name == "nt", "expected x64 Windows")
        A.require(str(D.CWD) == manifest["cwd"] and D.CWD.is_dir(), "neutral cwd mismatch")
        assets = {name: {"path": str(path), "sha256": expected}
                  for name, (path, expected) in D.INPUTS.items()}
        A.require(assets == manifest["assets"], "runtime asset manifest differs")
        for item in assets.values():
            A.require(hash_file(Path(item["path"])) == item["sha256"], "runtime asset changed")
        A.require(manifest["arm_sha256"] == {role: assets["fixture" if role == "bare" else role]["sha256"]
                                             for role in schedule.ARMS}, "arm bindings differ")
        bindings = runtime_hold_bindings(manifest)
        A.require(bindings == manifest["runtime_hold_bindings"], "runtime hold manifest differs")
        hold = RuntimeHold(bindings)
        capture["asset_hold"] = {"share_mode": "FILE_SHARE_READ", "before": hold.acquire()}
        S, N, P = (D.load(role) for role in ("support", "native", "policy"))
        capture["qualification_receipts"] = qualification_receipts(manifest, D, S.OUTER_SHA)
        capture["controller_argv"] = controller_argv()
        capture["outer_guards"], cutoff = guard_chain(S, manifest)
        A.verify_outer_receipt(manifest, capture)
        first = telemetry(S)
        capture["host_telemetry_origin"] = first
        previous_block = None
        policy = manifest["telemetry"]
        A.require(all(A.positive_integer(policy.get(key)) for key in ("suspend_threshold_ms", "clock_drift_threshold_ms")),
                  "host telemetry thresholds must be fixed before capture")
        expected_env = manifest["child_environment_sha256"]
        A.require(A.valid_sha(expected_env), "missing exact sanitized environment binding")
        A.require(D.environment_block(P)[1]["utf16_sha256"] == expected_env,
                  "sanitized environment differs before capture")
        write_record(out / "preflight.json", {key: value for key, value in capture.items() if key != "rows"})
        def observe_host(index):
            now = telemetry(S)
            capture["telemetry"].append(dict(index=index, **now))
            capture["host_stability"].update(A.telemetry_flags(first, capture["telemetry"], policy))
            A.require(not any(capture["host_stability"].values()), "host stability gate failed")

        for expected in plan["rows"]:
            A.require(time.monotonic() < cutoff, "independent guard admission cutoff reached")
            block = (expected["phase"], expected.get("checkpoint"), expected.get("macroblock"))
            if block != previous_block:
                observe_host(expected["index"])
                previous_block = block
            folder = out / f"{expected['index']:04}"
            folder.mkdir()
            row = dict(scheduled=expected, status="INCOMPLETE", oracle={"passed": False})
            capture["rows"].append(row)
            argv, budget, exit_code, stdout, marker = make_case(D, expected, folder, row)
            row["argv"] = argv
            write_record(folder / "prepared.json", row)
            try:
                D.arm(N, P, S, row, folder, argv, budget, exit_code, stdout, marker=marker,
                      capture=True, expected_env_sha256=expected_env)
                A.verify_armed_deadline(row, budget, f"row {expected['index']}")
                if expected["phase"] == "control":
                    A.validate_control(row, row["control_id"])
                else:
                    A.require(not row.get("trusted_cleanup_requested"), "candidate required external cleanup")
                row.update(status="PASS", oracle={"passed": True})
            except Exception as error:
                row.update(status="FAIL", error=repr(error))
                raise
            finally:
                write_record(folder / "final.json", row)
        observe_host(len(plan["rows"]))
        capture["asset_hold"]["after"] = hold.verify()
        A.verify_asset_holds(manifest, capture)
        capture["complete"] = True
        A.validate(args.schedule.read_bytes(), args.manifest.read_bytes(), args.manifest_sha256, capture)
        A.verify_raw_rows(out, capture["rows"])
    except BaseException as error:
        capture.update(complete=False, error=repr(error))
    finally:
        try:
            write_record(out / "capture.json", capture)
        finally:
            if hold is not None:
                hold.resources.close()
    return 0 if capture["complete"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("manifest", "schedule", "admission", "out"):
        parser.add_argument(f"--{option}", required=True, type=Path)
    for option in ("manifest-sha256", "admission-sha256"):
        parser.add_argument(f"--{option}", required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    A.require(out.parent == HERE, "choose a fresh adjacent capture directory")
    out.mkdir(exist_ok=False)
    return run(args, out)


if __name__ == "__main__":
    sys.exit(main())
