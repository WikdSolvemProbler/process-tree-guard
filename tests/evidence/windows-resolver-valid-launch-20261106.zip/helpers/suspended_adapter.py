"""Untimed Windows launch and endpoint qualification for pinned development inputs."""

import argparse
from contextlib import ExitStack
import ctypes as C
from ctypes import wintypes as W
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
from types import SimpleNamespace
import uuid

import _winapi


HERE = Path(__file__).resolve().parent
BUILD = HERE.parent / "wake-msvc-matched-build-001"
PILOT = Path("C:/Users/Peter/HerrNest/benchmark-lab-20261025")
PILOT_DRIVER = PILOT / "diagnostics/unified-startup-development-pilot-003"
CWD = BUILD / "neutral-cwd"
FLAGS = 0x08080404
WAIT_LIVE = 258
CLEANUP_EXIT = 0xE0000071
WATCHDOG_EXIT = 0xE0000081
NS_PER_SECOND = 1_000_000_000
INPUTS = {
    "support": (HERE / "qualify-controls.py", "ad65c7035f9d3917aa6a1982e3ffae8eb0280799571f49f9f68135d5e89feda7"),
    "native": (PILOT_DRIVER / "native_snapshot.py", "85a23643c60410929646416a224d13440a93246e4a9fd0dea3cb15066e1e0643"),
    "policy": (PILOT_DRIVER / "pilot_policy.py", "fc21bb7315327990eeee6ac48525f455e07fdb0d223ae47ee1ce95b3b79b3cf8"),
    "build_receipt": (BUILD / "completion.json", "e1e64d6bad830b77824faae61b663d5eaa495f2fa985ddcb40f825216282c25b"),
    "testkit": (HERE.parent / "issue3-windows-python-build-003/testkit.exe", "d55d6b947c921b9d28e803a5057dac51e8df044fbdd7106b88880292c4c47a2f"),
    "fixture": (PILOT / "build/fixture-latebirth-001/release/guard-benchmark-fixture.exe", "81678345d3b1bb31bbeaee1872580764386274d64f98129b538c80b20ed058d0"),
    "wake": (BUILD / "wake-target/release/process-guard.exe", "50f73d903f03ab580d4dbe1335a055febcd2aef4a79d04c5a5a179d358324770"),
    "main": (BUILD / "main-target/release/process-tree-guard.exe", "f7f6e1fca2533e651ece4b44f6a484e6903612252d3aa466870314b920dc2e02"),
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(role):
    path, expected = INPUTS[role]
    source = path.read_bytes()
    require(hashlib.sha256(source).hexdigest() == expected, f"{role} digest mismatch")
    spec = importlib.util.spec_from_file_location("qualification_" + role, path)
    module = importlib.util.module_from_spec(spec)
    exec(compile(source, str(path), "exec"), module.__dict__)
    return module


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def stream_bytes(path):
    require(path.stat().st_size <= 65536, f"output limit exceeded: {path.name}")
    return path.read_bytes()


def environment_block(P):
    env, receipt = P.environment(dict(os.environ))
    block = C.create_unicode_buffer("\0".join(
        f"{key}={value}" for key, value in sorted(env.items(), key=lambda item: item[0].upper())
    ) + "\0\0")
    receipt["utf16_sha256"] = hashlib.sha256(
        C.string_at(C.addressof(block), C.sizeof(block))).hexdigest()
    return block, receipt


def arm(N, P, S, row, folder, argv, budget, expected_exit, expected_stdout,
        marker=None, observe=None, expected_stderr=b"", capture=False, expected_env_sha256=None,
        expect_watchdog=False, stdin_payload=b""):
    require(not expect_watchdog or (not capture and expected_exit == WATCHDOG_EXIT),
            "watchdog observation grace is only for untimed synthetic qualification")
    row.update(argv=argv, creation_flags=FLAGS, cwd=str(CWD), deadline_seconds=budget,
               expected_exit_u32=expected_exit, admission=N.admission())
    require(row["admission"]["admitted"], "RAM below 896 MiB")
    require(shutil.disk_usage(folder).free >= 256 * 1024 * 1024, "disk below 256 MiB")
    block, row["environment"] = environment_block(P)
    if expected_env_sha256 is not None:
        require(row["environment"]["utf16_sha256"] == expected_env_sha256, "sanitized environment changed")
    job = N.Job()
    snapshot_job = SimpleNamespace(_handle=job.handle)
    pi = N.PROCESS_INFORMATION()
    child = None
    extra_handles = {}
    alarm = None
    stop = threading.Event()
    expired = threading.Event()
    lock = threading.Lock()

    def watchdog():
        with lock:
            owned_handle = handoff.pop() if handoff else None
        if owned_handle is None:
            return
        try:
            while True:
                remaining_ns = armed_deadline_ns - time.perf_counter_ns()
                if remaining_ns <= 0:
                    break
                if stop.wait(remaining_ns / NS_PER_SECOND):
                    return
            with lock:
                if stop.is_set():
                    return
                row["watchdog_fired_ns"] = time.perf_counter_ns()
                expired.set()
            row["watchdog_terminate_return"] = int(N.TerminateJobObject(owned_handle, WATCHDOG_EXIT))
        except Exception as error:
            row["watchdog_error"] = repr(error)
        finally:
            row["watchdog_handle_closed"] = bool(N.CloseHandle(owned_handle))

    try:
        with ExitStack() as resources:
            paths = [folder / name for name in ("stdin.bin", "stdout.bin", "stderr.bin")]
            streams = [resources.enter_context(path.open("w+b", buffering=0)) for path in paths]
            streams[0].write(stdin_payload)
            streams[0].seek(0)
            handles = (N.HANDLE * 3)(*(N.msvcrt.get_osfhandle(item.fileno()) for item in streams))
            jobs = (N.HANDLE * 1)(job.handle)
            size = N.SIZE_T()
            N.InitializeProcThreadAttributeList(None, 2, 0, C.byref(size))
            require(size.value, "attribute list size unavailable")
            storage = C.create_string_buffer(size.value)
            N.checked(N.InitializeProcThreadAttributeList(storage, 2, 0, C.byref(size)), "attributes")
            resources.callback(N.DeleteProcThreadAttributeList, storage)
            N.checked(N.UpdateProcThreadAttribute(storage, 0, 0x20002, handles, C.sizeof(handles), None, None), "stdio")
            N.checked(N.UpdateProcThreadAttribute(storage, 0, 0x2000D, jobs, C.sizeof(jobs), None, None), "atomic Job")
            for handle in handles:
                resources.callback(os.set_handle_inheritable, handle, os.get_handle_inheritable(handle))
                os.set_handle_inheritable(handle, True)
            si = N.STARTUPINFOEX()
            si.info.cb, si.info.flags, si.info.show = C.sizeof(si), 0x101, 0
            si.info.stdin, si.info.stdout, si.info.stderr = handles
            si.attributes = C.cast(storage, C.c_void_p)
            command = C.create_unicode_buffer(subprocess.list2cmdline(argv))
            current = _winapi.GetCurrentProcess()
            watchdog_handle = _winapi.DuplicateHandle(
                current, job.handle, current, 0, False, _winapi.DUPLICATE_SAME_ACCESS)
            require(watchdog_handle != job.handle, "watchdog Job handle was not distinct")
            handoff = [watchdog_handle]
            row["watchdog_owns_distinct_job_handle"] = True
            try:
                alarm = threading.Thread(target=watchdog, daemon=True)
                armed_ns = time.perf_counter_ns()
                armed_deadline_ns = armed_ns + budget * NS_PER_SECOND
                row.update(armed_ns=armed_ns, armed_deadline_ns=armed_deadline_ns)
                alarm.start()
            except BaseException:
                stop.set()
                with lock:
                    unclaimed = handoff.pop() if handoff else None
                if unclaimed is not None:
                    N.CloseHandle(unclaimed)
                    alarm = None
                raise
            app, cwd = argv[0], str(CWD)
            startup, process_info = C.byref(si.info), C.byref(pi)
            if capture:
                start_ns = time.perf_counter_ns()
            created = int(N.CreateProcessW(app, command, None, None, True, FLAGS,
                                           block, cwd, startup, process_info))
            row["create"] = (dict(native_return=created, pid=int(pi.pid), process_handle=int(pi.process or 0))
                             if capture else created)
            if capture:
                row["start_ns"] = start_ns
            N.checked(created, "CreateProcessW")
            row["suspended"] = S.snapshot(pi.process, snapshot_job)
            require(row["suspended"]["pid"] == pi.pid and row["suspended"]["member"]
                    and row["suspended"]["native_wait"] == WAIT_LIVE, "suspended identity/membership not verified")
            with lock:
                require(not expired.is_set() and time.perf_counter_ns() < armed_deadline_ns,
                        "deadline elapsed before resume")
                row["resume_previous_suspend_count"] = int(N.ResumeThread(pi.thread))
            require(row["resume_previous_suspend_count"] == 1, "unexpected suspend count")
            if observe is not None:
                remaining = max(0, armed_deadline_ns - time.perf_counter_ns()) / NS_PER_SECOND
                observe(pi.process, snapshot_job, time.monotonic() + remaining, extra_handles, row)
            signal_deadline_ns = armed_deadline_ns + (500_000_000 if expect_watchdog else 0)
            wait_ms = min(250 if expected_exit is None else int((budget + 0.5) * 1000),
                          max(0, (signal_deadline_ns - time.perf_counter_ns()) // 1_000_000))
            row["wait_ms"] = wait_ms
            handle = pi.process
            native_wait = N.WaitForSingleObject(handle, wait_ms)
            end_ns = time.perf_counter_ns()
            if capture:
                row.update(measurement_end_ns=end_ns, elapsed_ns=end_ns - start_ns,
                           wait=dict(process_handle=int(handle), native_return=int(native_wait),
                                     query_end_ns=end_ns))
            row["native_wait_observed_ns"] = end_ns
            row["native_wait"] = int(native_wait)
            require(expect_watchdog or end_ns <= armed_deadline_ns,
                    "native wait endpoint crossed the armed deadline")
            row["root_before_cleanup"] = S.snapshot(pi.process, snapshot_job)
            require(row["root_before_cleanup"]["pid"] == row["suspended"]["pid"]
                    and row["root_before_cleanup"]["creation_filetime"] == row["suspended"]["creation_filetime"],
                    "held root identity changed")
            if capture:
                status = W.DWORD()
                exit_ok = N.GetExitCodeProcess(handle, C.byref(status))
                row["exit"] = dict(process_handle=int(handle), native_return=int(exit_ok),
                                   exit_code_u32=int(status.value))
                row["identity_before"] = dict(pid=row["suspended"]["pid"],
                                              creation_time=row["suspended"]["creation_filetime"])
                row["identity_after"] = dict(pid=row["root_before_cleanup"]["pid"],
                                             creation_time=row["root_before_cleanup"]["creation_filetime"])
                N.checked(exit_ok, "GetExitCodeProcess")
                require(int(status.value) == row["root_before_cleanup"]["exit_code_u32"],
                        "native exit queries differ")
            if expected_exit is None:
                require(wait_ms == 250 and row["native_wait"] == WAIT_LIVE
                        and row["root_before_cleanup"]["native_wait"] == WAIT_LIVE, "forced 250 ms timeout not observed")
            else:
                require(row["native_wait"] == 0 and row["root_before_cleanup"]["exit_code_u32"] == expected_exit,
                        "natural native exit mismatch")
            if marker is not None:
                child_pid = int(marker.read_text(encoding="ascii"))
                child = _winapi.OpenProcess(S.SYNC_QUERY, False, child_pid)
                row["child_before_cleanup"] = S.snapshot(child, snapshot_job)
                child_before = row["child_before_cleanup"]
                require(child_before["pid"] == child_pid != pi.pid and child_before["member"]
                        and child_before["creation_filetime"] >= row["suspended"]["creation_filetime"]
                        and child_before["native_wait"] == WAIT_LIVE, "intended leak was not live in the Job")
            stdout, stderr = stream_bytes(paths[1]), stream_bytes(paths[2])
            row["streams_before_cleanup"] = {"stdout_hex": stdout.hex(), "stderr_hex": stderr.hex()}
            require(stdout == expected_stdout and (expected_stderr is None or stderr == expected_stderr),
                    "pre-cleanup output oracle mismatch")
            observe_deadline_ns = min(signal_deadline_ns, time.perf_counter_ns() + 500_000_000)
            needs_cleanup = expected_exit is None or marker is not None
            while True:
                row["accounting_before_cleanup"] = job.accounting()
                active = row["accounting_before_cleanup"]["values"]["active_processes"]
                if (active > 0) == needs_cleanup or time.perf_counter_ns() >= observe_deadline_ns:
                    break
                time.sleep(0.005)
            require((active > 0) == needs_cleanup, "pre-cleanup Job accounting mismatch")
    finally:
        try:
            stop.set()
            if alarm is not None:
                alarm.join(0.5)
                require(not alarm.is_alive(), "native watchdog still outstanding; independent outer guard owns cleanup")
                require(row.get("watchdog_handle_closed") is True and not row.get("watchdog_error"),
                        "watchdog did not safely close its owned Job handle")
            row["watchdog_fired"] = expired.is_set()
            row["accounting_at_cleanup"] = job.accounting()
            if row["accounting_at_cleanup"]["values"]["active_processes"]:
                job.kill()
                row["trusted_cleanup_requested"] = True
            cleanup_deadline = time.monotonic() + 0.5
            while True:
                row["accounting_after_cleanup"] = job.accounting()
                if not row["accounting_after_cleanup"]["values"]["active_processes"]:
                    break
                require(time.monotonic() < cleanup_deadline, "Job drain deadline exceeded")
                time.sleep(0.005)
            for name, handle in (("root", pi.process), ("child", child), *extra_handles.items()):
                if handle:
                    remaining_ms = max(0, int((cleanup_deadline - time.monotonic()) * 1000))
                    require(N.WaitForSingleObject(handle, remaining_ms) == 0, f"held {name} did not signal")
                    after = S.snapshot(handle, snapshot_job)
                    row[f"{name}_after_cleanup"] = after
                    before = row.get(f"{name}_before_cleanup")
                    if before is not None:
                        require((after["pid"], after["creation_filetime"]) ==
                                (before["pid"], before["creation_filetime"]), f"held {name} identity changed")
                        if before["native_wait"] == WAIT_LIVE:
                            require(after["exit_code_u32"] == CLEANUP_EXIT, f"held {name} cleanup exit mismatch")
            require(row["watchdog_fired"] is expect_watchdog, "unexpected hard arm deadline outcome")
            if expect_watchdog:
                require(row.get("watchdog_terminate_return") == 1 and not row.get("trusted_cleanup_requested"),
                        "asynchronous watchdog did not independently settle the Job")
                require(armed_deadline_ns <= row["watchdog_fired_ns"] <= row["native_wait_observed_ns"],
                        "watchdog firing and endpoint chronology mismatch")
        finally:
            for handle in extra_handles.values():
                N.CloseHandle(handle)
            if child:
                N.CloseHandle(child)
            if pi.thread:
                N.CloseHandle(pi.thread)
            if pi.process:
                N.CloseHandle(pi.process)
            job.close()
    if capture:
        row["cleanup"] = {"active_after": row["accounting_after_cleanup"]["values"]["active_processes"]}
        row["settled_ns"] = time.perf_counter_ns()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--controls-only", action="store_true")
    options = parser.parse_args()
    out = options.out.resolve()
    require(out.parent == HERE, "choose a fresh adjacent receipt directory")
    out.mkdir(exist_ok=False)
    receipt = dict(scope="untimed suspended qualification, no comparative performance data",
                   passed=False, cases=[], job=dict(flags=0x2208, memory_mib=384, active_limit=8))
    try:
        require(CWD.is_dir() and C.sizeof(C.c_void_p) == 8, "expected x64 Windows and pinned working directory")
        receipt["driver_sha256"] = sha(Path(__file__))
        receipt["python"] = {"path": sys.executable, "sha256": sha(Path(sys.executable))}
        receipt["inputs"] = {}
        for name, (path, expected) in INPUTS.items():
            actual = sha(path)
            receipt["inputs"][name] = {"path": str(path), "sha256": actual}
            require(actual == expected, f"{name} digest mismatch")
        S, N, P = (load(role) for role in ("support", "native", "policy"))
        receipt["outer"] = S.outer_identity()
        testkit = str(INPUTS["testkit"][0])

        def case(name, argv, expected_exit=0, expected_stdout=b"", budget=3, marker=None):
            folder = out / name
            folder.mkdir()
            row = dict(case=name, passed=False)
            receipt["cases"].append(row)
            try:
                arm(N, P, S, row, folder, argv, budget, expected_exit, expected_stdout, marker)
                row["passed"] = True
            except Exception as error:
                row["error"] = repr(error)
                raise
            finally:
                save(folder / "receipt.json", row)

        for label, code in (("zero", 0), ("seven", 7), ("dword", 0xffffffff)):
            case("exit-" + label, [testkit, "exit", str(code)], expected_exit=code)
        marker = out / "natural-leak" / "leak.pid"
        case("natural-leak", [testkit, "spawn-marked", "0", str(marker), "2",
                              testkit, "mark", str(marker), "5"], marker=marker)
        case("forced-timeout", [testkit, "sleep", "5"], expected_exit=None)
        if not options.controls_only:
            for role in ("bare", "wake", "main"):
                for mode in ("manual", "auto"):
                    for workload, verb, duration, budget in (("startup", "exit", "0", 3),
                                                              ("wait50", "wait", "50", 10)):
                        token = uuid.uuid4().hex
                        fixture = [str(INPUTS["fixture"][0]), verb, duration, token]
                        guard = [] if role == "bare" else [str(INPUTS[role][0]),
                            *(["auto"] if mode == "auto" else []), "--timeout", "2", "--"]
                        expected = f"BENCHMARK_DONE {verb} {duration} {token}\n".encode("ascii")
                        case(f"{role}-{mode}-{workload}", guard + fixture, expected_stdout=expected, budget=budget)
        receipt["passed"] = True
    except Exception as error:
        receipt["error"] = repr(error)
    finally:
        save(out / "receipt.json", receipt)
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
