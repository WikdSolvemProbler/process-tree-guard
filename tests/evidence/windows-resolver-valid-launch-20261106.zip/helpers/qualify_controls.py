"""Bounded fixture qualification only. Never launches either benchmark arm."""

import argparse
import ctypes as C
from ctypes import wintypes as W
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import _winapi


ROOT = Path(__file__).resolve().parents[3]
TESTKIT = ROOT / "target/codex-security/issue3-windows-python-build-003/testkit.exe"
NATIVE = ROOT / "tests/campaign/windows_slot_job.py"
TESTKIT_SHA = "d55d6b947c921b9d28e803a5057dac51e8df044fbdd7106b88880292c4c47a2f"
NATIVE_SHA = "a4d1ee810a6db1565f1e22bdc13dd3d535bbf08e487b594234d0a79922094e15"
OUTER_SHA = "1899137f687541256fb89749b2fe6a2940f2e420faaf2330fc84f32cfd7fae43"
JOB_FLAGS = 0x2208
JOB_MEMORY = 384 * 1024 * 1024
JOB_MEMBERS = 8
CREATE_NO_WINDOW = 0x08000000
SYNC_QUERY = 0x00101000


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bind(name, args, result):
    fn = getattr(KERNEL, name)
    fn.argtypes = args
    fn.restype = result
    return fn


KERNEL = C.WinDLL("kernel32", use_last_error=True)
image_name = bind("QueryFullProcessImageNameW",
                  [W.HANDLE, W.DWORD, W.LPWSTR, C.POINTER(W.DWORD)], W.BOOL)
is_member = bind("IsProcessInJob", [W.HANDLE, W.HANDLE, C.POINTER(W.BOOL)], W.BOOL)
process_times = bind("GetProcessTimes", [W.HANDLE, *([C.POINTER(W.FILETIME)] * 4)], W.BOOL)
process_id = bind("GetProcessId", [W.HANDLE], W.DWORD)


def native_ok(value):
    if not value:
        raise C.WinError(C.get_last_error())
    return value


def outer_identity():
    pid = os.getppid()
    handle = _winapi.OpenProcess(SYNC_QUERY, False, pid)
    try:
        size = W.DWORD(32768)
        buf = C.create_unicode_buffer(size.value)
        native_ok(image_name(handle, 0, buf, C.byref(size)))
        path = Path(buf.value)
        sha = digest(path)
        check(sha == OUTER_SHA, "expected verified independent outer guard as direct parent")
        return {"pid": pid, "path": str(path), "sha256": sha}
    finally:
        _winapi.CloseHandle(handle)


def snapshot(handle, job):
    creation, exit_time, kernel, user = [W.FILETIME() for _ in range(4)]
    native_ok(process_times(handle, *(C.byref(t) for t in (creation, exit_time, kernel, user))))
    member = W.BOOL()
    native_ok(is_member(handle, job._handle, C.byref(member)))
    return {
        "pid": native_ok(process_id(handle)),
        "creation_filetime": (creation.dwHighDateTime << 32) | creation.dwLowDateTime,
        "member": bool(member.value),
        "native_wait": _winapi.WaitForSingleObject(handle, 0),
        "exit_code_u32": _winapi.GetExitCodeProcess(handle),
    }


def qualify(native, directory, row, args, expected_exit):
    proc = child = job = None
    marker = directory / "leak.pid"
    row["argv"] = [str(TESTKIT), *args]
    try:
        job = native.SlotJob()
        limits = native.ExtendedLimitInformation()
        limits.basic.flags = JOB_FLAGS
        limits.basic.active_process_limit = JOB_MEMBERS
        limits.job_memory_limit = JOB_MEMORY
        native_ok(native.SetInformationJobObject(
            job._handle, native.JOB_OBJECT_EXTENDED_LIMIT_INFORMATION,
            C.byref(limits), C.sizeof(limits)))
        with (directory / "stdout.bin").open("wb") as stdout, (directory / "stderr.bin").open("wb") as stderr:
            proc = job.launch(row["argv"], creationflags=CREATE_NO_WINDOW,
                              stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
            handle = proc._handle
            row["root_initial"] = snapshot(handle, job)
            check(row["root_initial"]["member"], "original process was not a Job member")
            if expected_exit is None:
                try:
                    proc.wait(timeout=0.25)
                except subprocess.TimeoutExpired:
                    row["wait_timeout_ms"] = 250
                else:
                    raise RuntimeError("forced-timeout process exited before the native timeout")
                row["root_before_cleanup"] = snapshot(handle, job)
                check(row["root_before_cleanup"]["native_wait"] == _winapi.WAIT_TIMEOUT,
                      "forced-timeout process was not live before cleanup")
            else:
                observed = proc.wait(timeout=3.0)
                row["root_before_cleanup"] = snapshot(handle, job)
                check(observed == expected_exit == row["root_before_cleanup"]["exit_code_u32"],
                      f"native exit mismatch: expected {expected_exit}, observed {observed}")
                check(row["root_before_cleanup"]["native_wait"] == _winapi.WAIT_OBJECT_0,
                      "original process did not naturally exit")
                if row["control"] == "natural-leak":
                    child_pid = int(marker.read_text(encoding="ascii").strip())
                    child = _winapi.OpenProcess(SYNC_QUERY, False, child_pid)
                    row["child_before_cleanup"] = snapshot(child, job)
                    before = row["child_before_cleanup"]
                    check(before["pid"] == child_pid and child_pid != proc.pid
                          and before["creation_filetime"] >= row["root_initial"]["creation_filetime"]
                          and before["member"] and before["native_wait"] == _winapi.WAIT_TIMEOUT,
                          "published descendant was not a live identified Job member")
        needs_termination = child is not None or expected_exit is None
        accounting_deadline = time.monotonic() + 0.5
        row["accounting_before_cleanup"] = []
        while True:
            active = job._active_processes()
            row["accounting_before_cleanup"].append(active)
            if needs_termination == (active > 0) or time.monotonic() >= accounting_deadline:
                break
            time.sleep(0.005)
        row["active_before_cleanup"] = active
        check(needs_termination == (active > 0), "unexpected pre-cleanup Job accounting")
    finally:
        try:
            if job is not None:
                row["drain"] = job.drain()
                check(row["drain"]["active_after"] == 0, "Job did not drain")
                signal_deadline = time.monotonic() + 0.5
                for name, held in (("root", proc._handle if proc else None), ("child", child)):
                    if held is not None:
                        remaining = max(0, int((signal_deadline - time.monotonic()) * 1000))
                        check(_winapi.WaitForSingleObject(held, remaining) == _winapi.WAIT_OBJECT_0,
                              f"held {name} did not signal within the post-drain bound")
                        after = snapshot(held, job)
                        row[f"{name}_after_cleanup"] = after
                        check(after["native_wait"] == _winapi.WAIT_OBJECT_0,
                              f"held {name} still live after drain")
                        before = row.get(f"{name}_before_cleanup")
                        if before is not None:
                            check((after["pid"], after["creation_filetime"]) ==
                                  (before["pid"], before["creation_filetime"]),
                                  f"held {name} identity changed")
                            if before["native_wait"] == _winapi.WAIT_TIMEOUT:
                                check(after["exit_code_u32"] == native.CLEANUP_EXIT_CODE,
                                      f"held {name} did not report the trusted cleanup exit")
        finally:
            if child is not None:
                _winapi.CloseHandle(child)
            if proc is not None:
                proc.close()
            if job is not None:
                job.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    options = parser.parse_args()
    out = options.out.resolve()
    check(out.parent == Path(__file__).resolve().parent, "choose a fresh adjacent receipt directory")
    out.mkdir(exist_ok=False)
    receipt = {
        "scope": "control feasibility only; atomic launch without pilot suspended/resume flags",
        "job": {"flags": JOB_FLAGS, "memory_bytes": JOB_MEMORY, "active_limit": JOB_MEMBERS},
        "controls": [],
        "passed": False,
    }
    try:
        receipt["outer"] = outer_identity()
        receipt["testkit"] = {"path": str(TESTKIT), "sha256": digest(TESTKIT)}
        receipt["native"] = {"path": str(NATIVE), "sha256": digest(NATIVE)}
        receipt["driver_sha256"] = digest(Path(__file__))
        check(receipt["testkit"]["sha256"] == TESTKIT_SHA, "testkit digest mismatch")
        check(receipt["native"]["sha256"] == NATIVE_SHA, "native helper digest mismatch")
        spec = importlib.util.spec_from_file_location("control_slot_job", NATIVE)
        native = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(native)
        for name, args, expected in (
            ("exit-zero", ["exit", "0"], 0),
            ("exit-seven", ["exit", "7"], 7),
            ("exit-dword-all-ones", ["exit", "0xffffffff"], 0xffffffff),
            ("natural-leak", None, 0),
            ("forced-timeout", ["sleep", "5"], None),
        ):
            directory = out / name
            directory.mkdir()
            row = {"control": name, "expected_exit_u32": expected, "passed": False}
            receipt["controls"].append(row)
            if args is None:
                marker = str(directory / "leak.pid")
                args = ["spawn-marked", "0", marker, "2", str(TESTKIT), "mark", marker, "5"]
            try:
                qualify(native, directory, row, args, expected)
                row["passed"] = True
            finally:
                (directory / "receipt.json").write_text(json.dumps(row, indent=2) + "\n", encoding="utf-8")
        receipt["passed"] = True
    except Exception as error:
        receipt["error"] = repr(error)
    finally:
        (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
