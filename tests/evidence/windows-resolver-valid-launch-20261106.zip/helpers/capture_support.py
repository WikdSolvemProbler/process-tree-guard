from contextlib import ExitStack
import ctypes as C
from ctypes import wintypes as W
import os
from pathlib import Path
import time
from types import SimpleNamespace


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


A = SimpleNamespace(require=require)


class RuntimeHold:
    """Keep independently opened read-share-only native handles until completion."""

    def __init__(self, bindings):
        kernel = C.WinDLL("kernel32", use_last_error=True)
        self.create = kernel.CreateFileW
        self.create.argtypes = (W.LPCWSTR, W.DWORD, W.DWORD, C.c_void_p, W.DWORD, W.DWORD, W.HANDLE)
        self.create.restype = W.HANDLE
        self.final_path = kernel.GetFinalPathNameByHandleW
        self.final_path.argtypes = (W.HANDLE, W.LPWSTR, W.DWORD, W.DWORD)
        self.final_path.restype = W.DWORD
        self.close = kernel.CloseHandle
        self.close.argtypes = (W.HANDLE,)
        self.close.restype = W.BOOL
        self.resources = ExitStack()
        self.bindings = bindings
        self.files = {}
        self.before = {}

    def open(self, path):
        import msvcrt

        handle = self.create(str(path), 0x80000000, 1, None, 3, 0x80, None)
        if handle in (None, C.c_void_p(-1).value):
            raise C.WinError(C.get_last_error(), f"read-share-only open: {path}")
        try:
            fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
        except BaseException:
            self.close(handle)
            raise
        try:
            return os.fdopen(fd, "rb", buffering=0)
        except BaseException:
            os.close(fd)
            raise

    def snapshot(self, stream, path):
        import hashlib
        import msvcrt

        name = C.create_unicode_buffer(32768)
        count = self.final_path(msvcrt.get_osfhandle(stream.fileno()), name, len(name), 0)
        A.require(0 < count < len(name), "held native path could not be resolved")
        final_path = name.value.removeprefix("\\\\?\\")
        A.require(os.path.normcase(final_path) == os.path.normcase(str(path)),
                  f"held file resolves to a different path: {path}")
        file_stat = os.fstat(stream.fileno())
        stream.seek(0)
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
        A.require(file_stat.st_ino > 0, f"held file identity unavailable: {path}")
        return {"path": str(path), "final_path": final_path, "sha256": digest,
                "volume": file_stat.st_dev, "file_id": file_stat.st_ino, "size": file_stat.st_size}

    def acquire(self):
        for role, binding in self.bindings.items():
            path = Path(binding["path"])
            A.require(path.is_absolute(), f"{role} hold path is not absolute")
            file = self.resources.enter_context(self.open(path))
            self.files[role] = file
            self.before[role] = self.snapshot(file, path)
            A.require(self.before[role]["sha256"] == binding["sha256"], f"{role} held bytes differ")
        return self.before

    def verify(self):
        after = {}
        for role, file in self.files.items():
            path = Path(self.bindings[role]["path"])
            held = self.snapshot(file, path)
            with self.open(path) as reopened:
                current = self.snapshot(reopened, path)
            A.require(held == current == self.before[role], f"{role} path or held bytes changed")
            after[role] = {"held": held, "reopened_path": current}
        return after

    def prove_denied_access(self, path):
        denied = {}
        for label, access in (("write", 0x40000000), ("delete", 0x00010000)):
            handle = self.create(str(path), access, 7, None, 3, 0x80, None)
            if handle not in (None, C.c_void_p(-1).value):
                self.close(handle)
                raise ValueError(f"runtime hold allowed {label} access")
            denied[label] = C.get_last_error()
            A.require(denied[label] == 32, f"{label} access did not fail with ERROR_SHARING_VIOLATION")
        return denied


def telemetry(S):
    system_times = S.bind("GetSystemTimes", [C.POINTER(W.FILETIME)] * 3, W.BOOL)
    unbiased = S.bind("QueryUnbiasedInterruptTime", [C.POINTER(C.c_uint64)], W.BOOL)
    tick = S.bind("GetTickCount64", [], C.c_uint64)
    idle, kernel, user = [W.FILETIME() for _ in range(3)]
    active = C.c_uint64()
    S.native_ok(system_times(*(C.byref(t) for t in (idle, kernel, user))))
    S.native_ok(unbiased(C.byref(active)))
    values = [(t.dwHighDateTime << 32) | t.dwLowDateTime for t in (idle, kernel, user)]
    return dict(monotonic_ns=time.perf_counter_ns(), wall_ns=time.time_ns(), tick_ms=tick(),
                awake_100ns=active.value, idle_100ns=values[0], kernel_100ns=values[1], user_100ns=values[2])


def inspect_outer(S):
    import _winapi

    class Basic(C.Structure):
        _fields_ = [("exit_status", C.c_void_p), ("peb", C.c_void_p),
                    ("affinity", C.c_void_p), ("priority", C.c_void_p),
                    ("pid", C.c_size_t), ("parent_pid", C.c_size_t)]

    class UnicodeString(C.Structure):
        _fields_ = [("length", W.USHORT), ("maximum", W.USHORT), ("buffer", C.c_void_p)]

    ntquery = C.WinDLL("ntdll").NtQueryInformationProcess
    ntquery.argtypes = (W.HANDLE, W.ULONG, C.c_void_p, W.ULONG, C.POINTER(W.ULONG))
    ntquery.restype = W.LONG
    argv_parser = C.WinDLL("shell32", use_last_error=True).CommandLineToArgvW
    argv_parser.argtypes = (W.LPCWSTR, C.POINTER(C.c_int))
    argv_parser.restype = C.POINTER(W.LPWSTR)
    free = S.bind("LocalFree", [C.c_void_p], C.c_void_p)

    def inspect(pid):
        handle = _winapi.OpenProcess(S.SYNC_QUERY, False, pid)
        try:
            A.require(_winapi.WaitForSingleObject(handle, 0) == 258, "guard ancestor is already dead")
            size = W.DWORD(32768)
            image = C.create_unicode_buffer(size.value)
            S.native_ok(S.image_name(handle, 0, image, C.byref(size)))
            basic = Basic()
            A.require(ntquery(handle, 0, C.byref(basic), C.sizeof(basic), None) == 0
                      and basic.pid == pid, "cannot verify guard ancestor identity")
            storage = C.create_string_buffer(65536)
            returned = W.ULONG()
            A.require(ntquery(handle, 60, storage, C.sizeof(storage), C.byref(returned)) == 0,
                      "cannot verify actual guard ancestor command line")
            command = UnicodeString.from_buffer(storage)
            origin = C.addressof(storage)
            A.require(command.length > 0 and command.length % 2 == 0 and
                      origin <= command.buffer <= origin + len(storage) - command.length,
                      "guard command-line buffer is malformed")
            argc = C.c_int()
            argv = argv_parser(C.wstring_at(command.buffer, command.length // 2), C.byref(argc))
            S.native_ok(argv)
            try:
                values = [argv[index] for index in range(argc.value)]
            finally:
                free(C.cast(argv, C.c_void_p))
            creation, exit_time, kernel, user = [W.FILETIME() for _ in range(4)]
            S.native_ok(S.process_times(handle, *(C.byref(t) for t in (creation, exit_time, kernel, user))))
            return dict(pid=pid, parent_pid=basic.parent_pid, path=image.value, argv=values,
                        creation_filetime=(creation.dwHighDateTime << 32) | creation.dwLowDateTime)
        finally:
            _winapi.CloseHandle(handle)

    return inspect(os.getppid())
