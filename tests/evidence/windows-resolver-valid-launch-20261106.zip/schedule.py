from hashlib import sha256
from itertools import product

CELLS = (
    ("NO_WINDOW", "absolute"),
    ("NO_WINDOW", "bare"),
    ("DETACHED", "absolute"),
    ("DETACHED", "bare"),
)
ARMS = {
    "B": "baseline",
    "C": "candidate",
    "W": "repaired_wake",
}
PERMUTATIONS = ("BCW", "BWC", "CBW", "CWB", "WBC", "WCB")


def _block_order(pair):
    rotation, permutation = pair
    key = f"ptg-resolver-valid-launch-v1:{rotation}:{permutation}"
    return sha256(key.encode("ascii")).digest(), rotation, permutation


def plan():
    rows = []

    def add(kind, block, rotation, permutation, cell, arm_order):
        context, lookup = CELLS[cell]
        for arm_position, arm in enumerate(arm_order):
            rows.append({
                "index": len(rows),
                "kind": kind,
                "block": block,
                "rotation": rotation,
                "permutation": permutation,
                "cell": cell,
                "context": context,
                "lookup": lookup,
                "arm": ARMS[arm],
                "arm_position": arm_position,
            })

    for cell in range(len(CELLS)):
        add("control", None, None, None, cell, "BCW")
    pairs = sorted(product(range(4), range(6)), key=_block_order)
    for block, (rotation, permutation) in enumerate(pairs):
        for position in range(len(CELLS)):
            cell = (rotation + position) % len(CELLS)
            arm_order = PERMUTATIONS[(permutation + cell) % len(PERMUTATIONS)]
            add("measured", block, rotation, permutation, cell, arm_order)
    return rows
