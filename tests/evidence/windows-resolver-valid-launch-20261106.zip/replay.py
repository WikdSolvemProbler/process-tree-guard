import argparse
from hashlib import sha256
import json
from pathlib import Path, PureWindowsPath
from statistics import median

from schedule import ARMS, CELLS, plan


STDIN = b"valid resolver fixture"
STDOUT = STDIN + b"\n"
STDERR = b"error-stream\n"
NS_PER_MS = 1_000_000
SLOT_NS = 4_000_000_000
SETTLE_NS = 1_000_000_000
CONTEXT_FLAGS = {"NO_WINDOW": 0x08000000, "DETACHED": 0x00000008}
COMMON_FLAGS = 0x00080404


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha(data):
    return sha256(data).hexdigest()


def canonical(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def environment_digest(environment):
    ordered = sorted(environment.items(), key=lambda item: item[0].upper())
    block = "\0".join(f"{key}={value}" for key, value in ordered) + "\0\0\0"
    return sha(block.encode("utf-16le"))


def verify_row(row, expected, manifest):
    require(row["scheduled"] == expected, "wrong schedule row")
    require(row["status"] == "PASS", "slot did not pass")
    assets = manifest["assets"]
    fixture = assets["fixture"]["path"]
    token = fixture if expected["lookup"] == "absolute" else PureWindowsPath(fixture).stem
    require(row["argv"] == [
        assets[expected["arm"]]["path"], "--timeout", "2", "--", token, "relay", "7",
    ], "wrong arm or fixture argv")
    require(row["cwd"] == manifest["cwd"], "wrong working directory")
    require(row["environment"]["utf16_sha256"] == environment_digest(manifest["child_environment"]),
            "wrong child environment")
    require(row["creation_flags"] == COMMON_FLAGS | CONTEXT_FLAGS[expected["context"]],
            "wrong creation flags")
    require(row["deadline_seconds"] == 4 and row["watchdog_owns_distinct_job_handle"] is True
            and row["watchdog_handle_closed"] is True and row["watchdog_fired"] is False
            and not row.get("trusted_cleanup_requested"), "invalid slot watchdog or unexpected cleanup")
    start, end, armed, limit, settled = (row[key] for key in (
        "start_ns", "measurement_end_ns", "armed_ns", "armed_deadline_ns", "settled_ns",
    ))
    require(all(type(value) is int for value in (start, end, armed, limit, settled))
            and 0 < armed <= start < end <= limit and 0 <= settled - end <= SETTLE_NS
            and limit - armed == SLOT_NS and row["elapsed_ns"] == end - start,
            "invalid clock bracket or watchdog chronology")
    create, wait, exit_result = (row[key] for key in ("create", "wait", "exit"))
    require(create["native_return"] == 1 and create["process_handle"] > 0
            and create["process_handle"] == wait["process_handle"] == exit_result["process_handle"]
            and wait["native_return"] == 0 and wait["query_end_ns"] == end
            and row["native_wait_observed_ns"] == end and row["native_wait"] == 0
            and exit_result["native_return"] == 1 and exit_result["exit_code_u32"] == 7,
            "invalid held process handle, native wait or exit")
    suspended = row["suspended"]
    identity = row["identity_before"]
    require(row["identity_after"] == identity == {
        "pid": suspended["pid"], "creation_time": suspended["creation_filetime"],
    } and identity["pid"] == create["pid"] > 0 and identity["creation_time"] > 0
        and suspended["member"] is True and suspended["native_wait"] == 258
        and row["resume_previous_suspend_count"] == 1, "invalid suspended admission or identity")
    require(all(row[key]["values"]["active_processes"] == 0 for key in (
        "accounting_before_cleanup", "accounting_at_cleanup", "accounting_after_cleanup",
    )) and row["cleanup"]["active_after"] == 0, "slot Job did not drain naturally")
    require(row["streams_before_cleanup"] == {
        "stdout_hex": STDOUT.hex(), "stderr_hex": STDERR.hex(),
    }, "stream oracle mismatch")
    require(row["oracle"] == {
        "passed": True,
        "stdin_sha256": sha(STDIN),
        "stdout_sha256": sha(STDOUT),
        "stderr_sha256": sha(STDERR),
    }, "stream hash oracle mismatch")


def _distribution(values):
    return {
        "median_ms": median(values) / NS_PER_MS,
        "min_ms": min(values) / NS_PER_MS,
        "max_ms": max(values) / NS_PER_MS,
        "negative": sum(value < 0 for value in values),
        "zero": values.count(0),
        "positive": sum(value > 0 for value in values),
        "first_half_median_ms": median(values[:12]) / NS_PER_MS,
        "second_half_median_ms": median(values[12:]) / NS_PER_MS,
        "chronological_ms": [value / NS_PER_MS for value in values],
    }


def summarize(rows):
    measured = {}
    for row in rows:
        slot = row["scheduled"]
        if slot["kind"] == "measured":
            measured[slot["cell"], slot["block"], slot["arm"]] = row["elapsed_ns"]

    cells, baseline_contrasts = [], {}
    for cell, (context, lookup) in enumerate(CELLS):
        times = {
            arm: [measured[cell, block, arm] for block in range(24)]
            for arm in ARMS.values()
        }
        contrasts = {
            arm: [candidate - reference for candidate, reference in zip(times["candidate"], times[arm])]
            for arm in ("baseline", "repaired_wake")
        }
        baseline_contrasts[cell] = contrasts["baseline"]
        cells.append({
            "context": context, "lookup": lookup,
            "arms": {
                arm: {
                    "median_ms": median(values) / NS_PER_MS,
                    "p90_ms": sorted(values)[21] / NS_PER_MS,
                }
                for arm, values in times.items()
            },
            "candidate_minus_baseline": _distribution(contrasts["baseline"]),
            "candidate_minus_repaired_wake": _distribution(contrasts["repaired_wake"]),
        })
    return {
        "cells": cells,
        "bare_minus_absolute_candidate_minus_baseline": {
            CELLS[cell][0]: _distribution([
                bare - absolute for bare, absolute in
                zip(baseline_contrasts[cell + 1], baseline_contrasts[cell])
            ]) for cell in (0, 2)
        },
    }


def verify_wrapper(receipt_dir, attempt, approval_path, manifest, manifest_sha, terminal, records):
    receipt_bytes = (receipt_dir / "wrapper.json").read_bytes()
    receipt = json.loads(receipt_bytes)
    assets = manifest["assets"]
    require(receipt["schema"] == "ptg-resolver-wrapper-v1"
            and receipt["manifest_sha256"] == manifest_sha
            and receipt["primary_guard_sha256"] == assets["outer_guard"]["sha256"]
            and receipt["primary_exit"] == 0
            and receipt["started_unix_ms"] < receipt["finished_unix_ms"]
            and receipt["observed_instances_alive"] == 0
            and receipt["observation_error"] is None, "invalid independent wrapper receipt")
    approval_bytes = approval_path.read_bytes()
    approval = json.loads(approval_bytes)
    require(sha(approval_bytes) == receipt["approval_sha256"] == terminal["approval_sha256"]
            and approval["schema"] == manifest["schema"]
            and approval["state"] == "APPROVED" and approval["manifest_sha256"] == manifest_sha
            and approval["reviewers"] == ["resolver_method", "resolver_critic"],
            "capture approval is missing or unbound")
    argv = receipt["guard_argv"]
    require(len(argv) == 18 and argv[:8] == [
        "--timeout", "120", "--", assets["controller_python"]["path"],
        "-I", "-B", assets["driver"]["path"], "capture",
    ] and argv[8::2] == ["--manifest", "--manifest-sha256", "--approval",
                         "--approval-sha256", "--out"]
      and argv[11] == manifest_sha and argv[15] == receipt["approval_sha256"]
      and (argv[9], argv[13], argv[17]) == tuple(manifest["invocation"][role]
                                            for role in ("manifest", "approval", "attempt")),
      "wrapper invocation differs")
    for name in ("stdout", "stderr"):
        require(receipt[f"{name}_sha256"] == sha((receipt_dir / f"{name}.log").read_bytes()),
                f"wrapper {name} digest mismatch")
    names = ("preflight.json", "postflight.json", "terminal.json", "journal.jsonl", "telemetry.jsonl")
    require(receipt["attempt_sha256"] == {name: sha((attempt / name).read_bytes()) for name in names},
            "wrapper attempt digests differ")

    preflight = json.loads((attempt / "preflight.json").read_bytes())
    postflight = json.loads((attempt / "postflight.json").read_bytes())
    require(preflight["manifest_sha256"] == manifest_sha
            and preflight["child_environment"] == manifest["child_environment"]
            and preflight["child_environment_utf16_sha256"] ==
                terminal["child_environment_utf16_sha256"] == environment_digest(manifest["child_environment"])
            and postflight["rows_completed"] == len(records), "preflight or postflight context differs")
    bindings = dict(assets, manifest={"path": manifest["invocation"]["manifest"], "sha256": manifest_sha},
                    approval={"path": manifest["invocation"]["approval"], "sha256": sha(approval_bytes)})
    before, after = preflight["asset_hold"], postflight["asset_hold"]
    require(set(before) == set(after) == set(bindings), "held input roles differ")
    for role, binding in bindings.items():
        identity = before[role]
        require(identity == after[role]["held"] == after[role]["reopened_path"]
                and identity["path"] == binding["path"] and identity["sha256"] == binding["sha256"]
                and PureWindowsPath(identity["path"]) == PureWindowsPath(identity["final_path"])
                and identity["file_id"] > 0 and identity["size"] > 0, f"held identity differs: {role}")
    guard = preflight["outer_guard"]
    require(guard["pid"] == receipt["primary_guard_pid"] == terminal["primary_guard_pid"] > 0
            and guard["creation_filetime"] == terminal["primary_guard_creation_filetime"] > 0
            and guard["controller_in_job"] is True
            and guard["sha256"] == receipt["primary_guard_sha256"]
            and guard["argv"] == [assets["outer_guard"]["path"], *argv]
            and guard["timeout_seconds"] == 120 and guard["reserve_seconds"] == 10
            and preflight["controller_pid"] == terminal["controller_pid"] == receipt["controller_pid"] > 0
            and preflight["controller_creation_filetime"] == terminal["controller_creation_filetime"] > 0, "wrapper and live ancestry differ")
    pids = {guard["pid"], preflight["controller_pid"]}
    pids.update(row["identity_before"]["pid"] for row in records)
    require(receipt["observed_pid_count"] == len(pids)
            and all(process["pid"] in pids and process["observed_instance"] is False
                    for process in receipt["current_processes"]), "wrapper process observations differ")
    return sha(receipt_bytes)


def verify_telemetry(attempt, terminal, records):
    raw = (attempt / "telemetry.jsonl").read_bytes()
    require(sha(raw) == terminal["telemetry_sha256"], "telemetry digest mismatch")
    samples = [json.loads(line) for line in raw.splitlines()]
    indexes = [0, *range(12, 300, 12), 300]
    require([sample["index"] for sample in samples] == indexes, "telemetry boundaries differ")
    previous_time = 0
    for index, sample in zip(indexes, samples):
        when = sample["monotonic_ns"]
        require(type(when) is int and when > previous_time
                and (index == 0 or records[index - 1]["settled_ns"] < when)
                and (index == 300 or when < records[index]["armed_ns"]),
                "telemetry chronology differs")
        require(sample["native_admission"]["admitted"] is True
                and sample["disk_free_bytes"] >= 256 * 1024 * 1024
                and all(type(sample[key]) is int and sample[key] >= 0 for key in (
                    "wall_ns", "tick_ms", "awake_100ns", "idle_100ns", "kernel_100ns", "user_100ns",
                )), "invalid telemetry sample")
        previous_time = when


def replay(manifest_path, expected_manifest_sha, attempt, receipt_dir, approval_path):
    manifest_bytes = manifest_path.read_bytes()
    require(sha(manifest_bytes) == expected_manifest_sha, "manifest digest mismatch")
    manifest = json.loads(manifest_bytes)
    require(manifest["schema"] == "ptg-resolver-valid-launch-v1", "wrong manifest schema")
    for role, path in (("schedule", Path(__file__).with_name("schedule.py")),
                       ("replay", Path(__file__))):
        require(sha(path.read_bytes()) == manifest["assets"][role]["sha256"],
                f"{role} source digest mismatch")
    terminal = json.loads((attempt / "terminal.json").read_bytes())
    journal = (attempt / "journal.jsonl").read_bytes()
    expected_plan = plan()
    require(terminal["state"] == "COMPLETE" and terminal["complete"] is True
            and terminal["rows_expected"] == terminal["rows_completed"] == len(expected_plan)
            and terminal["manifest_sha256"] == expected_manifest_sha
            and terminal["journal_sha256"] == sha(journal)
            and terminal["schedule_sha256"] == manifest["assets"]["schedule"]["sha256"]
            and terminal["schedule_rows_sha256"] == sha(canonical(expected_plan)),
            "incomplete or unbound terminal")
    records = [json.loads(line) for line in journal.splitlines()]
    require(len(records) == len(expected_plan), "wrong journal length")
    previous_settled = 0
    for row, expected in zip(records, expected_plan):
        verify_row(row, expected, manifest)
        require(row["armed_ns"] > previous_settled, "overlapping or reordered slots")
        previous_settled = row["settled_ns"]
        folder = attempt / f"{expected['index']:04d}"
        require(json.loads((folder / "final.json").read_bytes()) == row, "row receipt differs")
        for name, data in (("stdin", STDIN), ("stdout", STDOUT), ("stderr", STDERR)):
            require((folder / f"{name}.bin").read_bytes() == data,
                    f"raw stream differs in row {expected['index']}: {name}")
    verify_telemetry(attempt, terminal, records)
    wrapper_sha = verify_wrapper(receipt_dir, attempt, approval_path, manifest,
                                 expected_manifest_sha, terminal, records)
    return {
        "scope": "descriptive observed-load Windows valid launches; no equivalence decision",
        "wrapper_sha256": wrapper_sha,
        "manifest_sha256": expected_manifest_sha,
        "journal_sha256": sha(journal),
        "control_rows": 12,
        "measured_rows": 288,
        "blocks": 24,
        **summarize(records),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Verify and replay the resolver timing diagnostic")
    parser.add_argument("manifest", type=Path)
    parser.add_argument("manifest_sha256")
    parser.add_argument("attempt", type=Path)
    parser.add_argument("receipt_dir", type=Path)
    parser.add_argument("approval", type=Path)
    args = parser.parse_args()
    print(json.dumps(replay(args.manifest, args.manifest_sha256, args.attempt, args.receipt_dir, args.approval), indent=2))
