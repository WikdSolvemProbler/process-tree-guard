"""Scratch Windows valid-launch capture. Recipe and validate never launch an arm."""

import argparse
import ctypes as C
from ctypes import wintypes as W
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import shutil
import sys
import time
from types import ModuleType, SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SECURITY = HERE.parent
HELPERS = HERE / "helpers"
PRE = SECURITY / "resolver-valid-launch-preflight-001"
BUILD = SECURITY / "empty-command-resolver-fdb8a5f-win-001"
WAKE = SECURITY / "wake-msvc-driver-dev-001"
OUTER = Path("C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe")
RELEASE = Path("x86_64-pc-windows-msvc/release/process-tree-guard.exe")
SCHEMA = "ptg-resolver-valid-launch-v1"
OUTER_SECONDS = 120
RESERVE_SECONDS = 10
SLOT_SECONDS = 4
NS_PER_SECOND = 1_000_000_000
FILETIME_EPOCH_NS = 11_644_473_600_000_000_000
INPUT = b"valid resolver fixture"
STDOUT = b"valid resolver fixture\n"
STDERR = b"error-stream\n"
FLAGS = {"NO_WINDOW": 0x08080404, "DETACHED": 0x0008040C}
PINNED = {
    "baseline": "4b9035dee574f020a1a6ef1abe0002fa0648d70f8aabde4abaaea3125b4df76b",
    "candidate": "3dcac83b847994558e50a8c6696b230b32efcfff1dc7418ee944dbddfb132b48",
    "repaired_wake": "50f73d903f03ab580d4dbe1335a055febcd2aef4a79d04c5a5a179d358324770",
    "fixture": "d55d6b947c921b9d28e803a5057dac51e8df044fbdd7106b88880292c4c47a2f",
    "outer_guard": "1899137f687541256fb89749b2fe6a2940f2e420faaf2330fc84f32cfd7fae43",
    "schedule": "1acf443f73a5a0b442f4044d5e9600d425a5698f182793c6588d9c5e56194707",
    "archive": "56d7e8282ce249dc5bfc3ab984ea03e97d99b463bb85e96db1684a7992f47038",
    "native": "85a23643c60410929646416a224d13440a93246e4a9fd0dea3cb15066e1e0643",
    "support": "ad65c7035f9d3917aa6a1982e3ffae8eb0280799571f49f9f68135d5e89feda7",
    "suspended": "21b02fcab537e36cecc3847d1dfb87f7c31d77646fae3631148263c3788a0ff3",
    "hold_source": "d75345872f5dad6b89d6cdacf8b1c88303561a58995c827506294f61ee39203d",
    "suspended_original": "e11cd48dce9f4b3612323f870dd539bdf7c5fc8ffc643a879410151bb0695523",
    "capture_original": "9b2586e765222da108d726e8ae1702fb413810046ed1a0c78436ae00e50f9fff",
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def canonical_json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def checked_path(path):
    require(path.is_absolute() and path == path.resolve(strict=True), f"path is not canonical: {path}")
    return path


def fixed_paths():
    return {
        "driver": HERE / "capture.py",
        "schedule": HERE / "schedule.py",
        "protocol": HERE / "PROTOCOL.md",
        "replay": HERE / "replay.py",
        "wrapper": HERE / "run-capture.ps1",
        "qualification_driver": HERE / "qualify-replay.py",
        "wrapper_powershell": Path("C:/Users/Peter/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe"),
        "native": HELPERS / "native_snapshot.py",
        "support": HELPERS / "qualify_controls.py",
        "suspended": HELPERS / "suspended_adapter.py",
        "hold_source": HELPERS / "capture_support.py",
        "suspended_original": HELPERS / "qualify_suspended_original.py",
        "capture_original": HELPERS / "capture_original.py",
        "helper_provenance": HERE / "helper-provenance.json",
        "helper_preparation": HERE / "prepare-helpers-v2.py",
        "baseline": BUILD / "baseline-target" / RELEASE,
        "candidate": BUILD / "live-target" / RELEASE,
        "repaired_wake": PRE / "wake.exe",
        "fixture": PRE / "fixture/ptg-resolver-validation.exe",
        "outer_guard": OUTER,
        "controller_python": Path(sys.executable).resolve(strict=True),
        "archive": ROOT / "tests/evidence/windows-wake-directional-20261106.zip",
        "prior_valid_launch": PRE / "result.json",
        "resolver_regression": BUILD / "qualification.json",
        "historical_safety": WAKE / "safety-qualification-deadline-005/receipt.json",
        "historical_suspended": WAKE / "suspended-qualification-deadline-006/receipt.json",
        "historical_watchdog_3": WAKE / "watchdog-qualification-deadline-006/receipt.json",
        "historical_watchdog_10": WAKE / "watchdog-qualification-deadline-007/receipt.json",
    }


def controlled_environment(fixture):
    inherited = {name.upper(): value for name, value in os.environ.items()}
    system_root = inherited.get("SYSTEMROOT")
    require(system_root and Path(system_root).is_absolute(), "absolute SYSTEMROOT required")
    env = {
        "SystemRoot": system_root,
        "WINDIR": inherited.get("WINDIR", system_root),
        "COMSPEC": inherited.get("COMSPEC", str(Path(system_root) / "System32/cmd.exe")),
        "PATH": str(fixture.parent),
        "PATHEXT": ".EXE",
        "NoDefaultCurrentDirectoryInExePath": "1",
    }
    for name in ("SYSTEMDRIVE", "TEMP", "TMP"):
        if value := inherited.get(name):
            env[name] = value
    require(all("\0" not in value and value for value in env.values()), "malformed child environment")
    return env


def load_source(role, assets):
    binding = assets[role]
    path = Path(binding["path"])
    source = path.read_bytes()
    require(sha256(source).hexdigest() == binding["sha256"], f"{role} source hash changed")
    module = ModuleType(f"resolver_timing_{role}")
    module.__file__ = str(path)
    exec(compile(source, str(path), "exec"), module.__dict__)
    return module


def path_state(manifest):
    cwd = checked_path(Path(manifest["cwd"]))
    fixture = checked_path(Path(manifest["assets"]["fixture"]["path"]))
    require(cwd == PRE / "cwd" and cwd.is_dir() and not any(cwd.iterdir()), "neutral CWD changed")
    require(list(fixture.parent.iterdir()) == [fixture], "fixture directory changed")
    require(fixture.name == "ptg-resolver-validation.exe", "unexpected fixture name")
    return cwd, fixture


def recipe():
    paths = fixed_paths()
    assets = {}
    for role, path in paths.items():
        checked_path(path)
        actual = digest(path)
        require(role not in PINNED or actual == PINNED[role], f"{role} differs from pinned identity")
        assets[role] = {"path": str(path), "sha256": actual}
    return {
        "schema": SCHEMA,
        "cwd": str(PRE / "cwd"),
        "outer_seconds": OUTER_SECONDS,
        "child_environment": controlled_environment(paths["fixture"]),
        "assets": assets,
    }


def read_bound_json(path, expected):
    checked_path(path)
    require(path.parent == HERE, f"expected scratch input in {HERE}")
    raw = path.read_bytes()
    require(sha256(raw).hexdigest() == expected, f"input hash mismatch: {path.name}")
    return json.loads(raw)


def validate(manifest):
    expected = recipe()
    for key in ("schema", "cwd", "outer_seconds", "child_environment"):
        require(manifest.get(key) == expected[key], f"manifest {key} differs from controlled recipe")
    assets = manifest["assets"]
    for name, binding in expected["assets"].items():
        require(assets.get(name) == binding, f"manifest asset differs: {name}")
    approved_paths = {Path(binding["path"]) for binding in expected["assets"].values()}
    for name, binding in assets.items():
        require(set(binding) == {"path", "sha256"}, f"invalid binding: {name}")
        path = checked_path(Path(binding["path"]))
        require(path.is_relative_to(ROOT) or path in approved_paths, f"unexpected external asset: {name}")
        require(digest(path) == binding["sha256"], f"asset hash differs: {name}")
    cwd, fixture = path_state(manifest)
    rows = load_source("schedule", assets).plan()
    require(len(rows) == 300 and [row["index"] for row in rows] == list(range(300)), "bad schedule")
    require([row["kind"] for row in rows] == ["control"] * 12 + ["measured"] * 288, "bad schedule phases")
    native, support, suspended, held = (
        load_source(name, assets) for name in ("native", "support", "suspended", "hold_source")
    )
    environment = SimpleNamespace(environment=lambda _: (dict(manifest["child_environment"]), {}))
    _, environment_receipt = suspended.environment_block(environment)
    clock = time.get_clock_info("perf_counter")
    require(os.name == "nt" and C.sizeof(C.c_void_p) == 8 and
            "QueryPerformanceCounter" in clock.implementation and clock.monotonic, "expected native Windows QPC")
    require(sys.flags.isolated and sys.dont_write_bytecode, "use the exact isolated -I -B Python launch")
    return SimpleNamespace(
        cwd=cwd, fixture=fixture, rows=rows, native=native, support=support, suspended=suspended,
        held=held, environment=environment, environment_receipt=environment_receipt,
        clock={"implementation": clock.implementation, "resolution_seconds": clock.resolution,
               "units": "nanoseconds"},
    )


def verify_outer(state, manifest):
    import _winapi

    outer = state.held.inspect_outer(state.support)
    guard = manifest["assets"]["outer_guard"]
    python = manifest["assets"]["controller_python"]["path"]
    controller = [python, "-I", "-B", *sys.argv]
    expected = [guard["path"], "--timeout", str(OUTER_SECONDS), "--", *controller]
    require(os.path.normcase(outer["path"]) == os.path.normcase(guard["path"]) and
            outer["argv"] == expected and digest(Path(outer["path"])) == guard["sha256"],
            "actual parent image, arguments, or deadline differ from the finite guard binding")
    current = _winapi.GetCurrentProcess()
    member = W.BOOL()
    state.support.native_ok(state.support.is_member(current, None, C.byref(member)))
    require(member.value, "controller is outside a Windows Job")
    creation, exit_time, kernel, user = [W.FILETIME() for _ in range(4)]
    state.support.native_ok(state.support.process_times(
        current, *(C.byref(value) for value in (creation, exit_time, kernel, user))
    ))
    controller_birth = (creation.dwHighDateTime << 32) | creation.dwLowDateTime
    require(outer["creation_filetime"] <= controller_birth, "controller predates enclosing guard")
    age_ns = time.time_ns() + FILETIME_EPOCH_NS - outer["creation_filetime"] * 100
    remaining_ns = OUTER_SECONDS * NS_PER_SECOND - age_ns
    require(0 <= age_ns and remaining_ns > RESERVE_SECONDS * NS_PER_SECOND, "outer cutoff already reached")
    cutoff_ns = time.perf_counter_ns() + remaining_ns - RESERVE_SECONDS * NS_PER_SECOND
    outer.update(sha256=guard["sha256"], timeout_seconds=OUTER_SECONDS, reserve_seconds=RESERVE_SECONDS,
                 controller_in_job=True, cutoff_ns=cutoff_ns, controller_argv=controller)
    return outer, controller_birth


def save(path, value):
    with path.open("xb") as handle:
        append(handle, value)


def append(journal, row):
    journal.write(canonical_json(row) + b"\n")
    journal.flush()
    os.fsync(journal.fileno())


def verify_slot(row, folder, expected_env):
    require(row["armed_deadline_ns"] == row["armed_ns"] + SLOT_SECONDS * NS_PER_SECOND and
            row["armed_ns"] <= row["start_ns"] < row["measurement_end_ns"] <= row["armed_deadline_ns"] and
            row["elapsed_ns"] == row["measurement_end_ns"] - row["start_ns"], "invalid bracket chronology")
    require(row["create"]["native_return"] == 1 and row["wait"]["native_return"] == 0 and
            row["exit"]["native_return"] == 1 and row["exit"]["exit_code_u32"] == 7 and
            row["create"]["process_handle"] == row["wait"]["process_handle"] == row["exit"]["process_handle"],
            "held original process outcome mismatch")
    require(row["identity_before"] == row["identity_after"] and row["suspended"]["member"] is True and
            row["resume_previous_suspend_count"] == 1, "original suspended process identity mismatch")
    require(row["cleanup"]["active_after"] == 0 and row["watchdog_fired"] is False and
            not row.get("trusted_cleanup_requested"), "unexpected external Job cleanup")
    require(0 <= row["settled_ns"] - row["measurement_end_ns"] <= NS_PER_SECOND,
            "post-signal Job settlement exceeded one second")
    require(row["environment"]["utf16_sha256"] == expected_env, "child environment digest mismatch")
    oracle = {"passed": True}
    for label, expected in (("stdin", INPUT), ("stdout", STDOUT), ("stderr", STDERR)):
        path = folder / f"{label}.bin"
        with path.open("r+b", buffering=0) as handle:
            require(handle.read(len(expected)+1) == expected, f"raw {label} mismatch")
            os.fsync(handle.fileno())
        oracle[f"{label}_sha256"] = sha256(expected).hexdigest()
    return oracle


def observe_host(state, directory, journal, index):
    row = {
        "index": index,
        **state.held.telemetry(state.support),
        "native_admission": state.native.admission(),
        "disk_free_bytes": shutil.disk_usage(directory).free,
    }
    append(journal, row)
    require(row["native_admission"]["admitted"] and row["disk_free_bytes"] >= 256*1024*1024,
            "native resource admission failed")
    return row


def run_capture(args, manifest, state, approval):
    require(approval.get("schema") == SCHEMA and approval.get("state") == "APPROVED" and
            approval.get("manifest_sha256") == args.manifest_sha256 and
            approval.get("reviewers") == ["resolver_method", "resolver_critic"],
            "capture is not approved for this manifest by both reviewers")
    invocation = manifest["invocation"]
    require(all(str(getattr(args, arg)) == invocation[role] for role, arg in (
        ("manifest", "manifest"), ("approval", "approval"), ("attempt", "out"),
    )), "capture arguments differ from the manifest invocation")
    out = args.out
    require(out.is_absolute() and out.parent == HERE and not out.exists(), "fresh direct scratch output required")
    outer, controller_birth = verify_outer(state, manifest)
    out.mkdir()
    journal_path = out / "journal.jsonl"
    telemetry_path = out / "telemetry.jsonl"
    terminal_path = out / "terminal.json"
    identities = {
        "controller_pid": os.getpid(),
        "controller_creation_filetime": controller_birth,
        "primary_guard_pid": outer["pid"],
        "primary_guard_creation_filetime": outer["creation_filetime"],
    }
    terminal = {
        "schema": SCHEMA, "state": "RUNNING", "complete": False, "rows_expected": len(state.rows),
        "rows_completed": 0, "error": None, "manifest_sha256": args.manifest_sha256,
        "approval_sha256": args.approval_sha256, "schedule_sha256": manifest["assets"]["schedule"]["sha256"],
        "schedule_rows_sha256": sha256(canonical_json(state.rows)).hexdigest(), "journal_sha256": None,
        "telemetry_sha256": None, "child_environment_utf16_sha256": state.environment_receipt["utf16_sha256"],
        "clock": state.clock, **identities,
    }
    save(terminal_path, terminal)
    try:
        bindings = dict(manifest["assets"], manifest={"path": str(args.manifest), "sha256": args.manifest_sha256},
                        approval={"path": str(args.approval), "sha256": args.approval_sha256})
        hold = state.held.RuntimeHold(bindings)
        with hold.resources, journal_path.open("xb") as journal, telemetry_path.open("xb") as telemetry:
            held_before = hold.acquire()
            path_state(manifest)
            expected_env = state.environment_receipt["utf16_sha256"]
            first = observe_host(state, out, telemetry, 0)
            save(out / "preflight.json", {
                "schema": SCHEMA, "outer_guard": outer, "asset_hold": held_before,
                "manifest_sha256": args.manifest_sha256, "child_environment": manifest["child_environment"],
                "child_environment_utf16_sha256": expected_env, "native_admission": first["native_admission"],
                "clock": state.clock, **identities,
            })
            state.suspended.CWD = state.cwd
            last_block = None
            for expected in state.rows:
                require(time.perf_counter_ns() < outer["cutoff_ns"], "finite outer admission cutoff reached")
                if last_block != expected["block"]:
                    observe_host(state, out, telemetry, expected["index"])
                    last_block = expected["block"]
                folder = out / f"{expected['index']:04d}"
                folder.mkdir()
                image = manifest["assets"][expected["arm"]]["path"]
                command = str(state.fixture) if expected["lookup"] == "absolute" else state.fixture.stem
                argv = [image, "--timeout", "2", "--", command, "relay", "7"]
                flags = FLAGS[expected["context"]]
                row = {"scheduled": expected, "status": "INCOMPLETE", "oracle": {"passed": False},
                       "argv": argv, "creation_flags": flags, "cwd": str(state.cwd)}
                save(folder / "prepared.json", row)
                try:
                    state.suspended.FLAGS = flags
                    state.suspended.arm(
                        state.native, state.environment, state.support, row, folder, argv, SLOT_SECONDS, 7, STDOUT,
                        expected_stderr=STDERR, capture=True, expected_env_sha256=expected_env, stdin_payload=INPUT,
                    )
                    row["oracle"] = verify_slot(row, folder, expected_env)
                    row["status"] = "PASS"
                except BaseException as error:
                    row.update(status="FAIL", error=repr(error))
                    raise
                finally:
                    save(folder / "final.json", row)
                    append(journal, row)
                    if row["status"] == "PASS":
                        terminal["rows_completed"] += 1
            last = observe_host(state, out, telemetry, len(state.rows))
            path_state(manifest)
            require(controlled_environment(state.fixture) == manifest["child_environment"], "host environment changed")
            held_after = hold.verify()
            save(out / "postflight.json", {
                "schema": SCHEMA, "asset_hold": held_after, "native_admission": last["native_admission"],
                "rows_completed": terminal["rows_completed"],
            })
        terminal.update(state="COMPLETE", complete=True)
    except BaseException as error:
        terminal.update(state="FAILED", complete=False, error=repr(error))
    finally:
        if journal_path.is_file():
            terminal["journal_sha256"] = digest(journal_path)
        if telemetry_path.is_file():
            terminal["telemetry_sha256"] = digest(telemetry_path)
        pending = out / "terminal.pending.json"
        save(pending, terminal)
        os.replace(pending, terminal_path)
    print(json.dumps(terminal, indent=2, allow_nan=False))
    return 0 if terminal["complete"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    sub.add_parser("recipe")
    for mode in ("validate", "capture"):
        command = sub.add_parser(mode)
        command.add_argument("--manifest", type=Path, required=True)
        command.add_argument("--manifest-sha256", required=True)
        if mode == "capture":
            command.add_argument("--approval", type=Path, required=True)
            command.add_argument("--approval-sha256", required=True)
            command.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.mode == "recipe":
        print(json.dumps(recipe(), indent=2))
        return 0
    manifest = read_bound_json(args.manifest, args.manifest_sha256)
    state = validate(manifest)
    if args.mode == "validate":
        print(json.dumps({
            "schema": SCHEMA, "state": "VALIDATED_NO_LAUNCH", "manifest_sha256": args.manifest_sha256,
            "rows_expected": len(state.rows), "schedule_rows_sha256": sha256(canonical_json(state.rows)).hexdigest(),
            "child_environment_utf16_sha256": state.environment_receipt["utf16_sha256"], "clock": state.clock,
        }, indent=2))
        return 0
    approval = read_bound_json(args.approval, args.approval_sha256)
    return run_capture(args, manifest, state, approval)


if __name__ == "__main__":
    raise SystemExit(main())
