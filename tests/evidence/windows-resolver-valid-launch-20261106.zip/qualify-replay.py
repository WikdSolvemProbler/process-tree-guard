from copy import deepcopy
import json
from pathlib import Path
from unittest.mock import patch

import replay
from schedule import ARMS, plan


ROOT = Path(__file__).resolve().parent


def sample_row(slot, manifest):
    base = 10_000_000_000 + slot["index"] * 1_000_000_000
    elapsed = {"baseline": 40_000_000, "candidate": 41_000_000, "repaired_wake": 42_000_000}
    end = base + elapsed[slot["arm"]]
    pid = 1000 + slot["index"]
    identity = {"pid": pid, "creation_time": pid + 20}
    accounting = {"values": {"active_processes": 0}}
    assets = manifest["assets"]
    fixture = assets["fixture"]["path"]
    return {
        "scheduled": slot, "status": "PASS", "cwd": manifest["cwd"],
        "argv": [assets[slot["arm"]]["path"], "--timeout", "2", "--",
                 fixture if slot["lookup"] == "absolute" else "testkit", "relay", "7"],
        "creation_flags": replay.COMMON_FLAGS | replay.CONTEXT_FLAGS[slot["context"]],
        "environment": {"utf16_sha256": replay.environment_digest(manifest["child_environment"])},
        "deadline_seconds": 4, "watchdog_owns_distinct_job_handle": True,
        "watchdog_handle_closed": True, "watchdog_fired": False,
        "start_ns": base, "measurement_end_ns": end, "armed_ns": base - 1,
        "armed_deadline_ns": base - 1 + replay.SLOT_NS, "settled_ns": end + 1,
        "elapsed_ns": end - base,
        "create": {"native_return": 1, "pid": pid, "process_handle": pid + 1},
        "wait": {"native_return": 0, "process_handle": pid + 1, "query_end_ns": end},
        "exit": {"native_return": 1, "process_handle": pid + 1, "exit_code_u32": 7},
        "identity_before": identity, "identity_after": identity,
        "suspended": {"pid": pid, "creation_filetime": identity["creation_time"],
                      "member": True, "native_wait": 258},
        "resume_previous_suspend_count": 1,
        "native_wait_observed_ns": end, "native_wait": 0,
        "accounting_before_cleanup": accounting, "accounting_at_cleanup": accounting,
        "accounting_after_cleanup": accounting, "cleanup": {"active_after": 0},
        "streams_before_cleanup": {"stdout_hex": replay.STDOUT.hex(), "stderr_hex": replay.STDERR.hex()},
        "oracle": {"passed": True, "stdin_sha256": replay.sha(replay.STDIN),
                   "stdout_sha256": replay.sha(replay.STDOUT), "stderr_sha256": replay.sha(replay.STDERR)},
    }


def main():
    assets = {role: {"path": f"C:/synthetic/arms/{role}.exe"} for role in ARMS.values()}
    assets["fixture"] = {"path": "C:/synthetic/fixture with spaces/testkit.exe"}
    assets.update({
        "outer_guard": {"path": "C:/synthetic/outer.exe", "sha256": "a" * 64},
        "controller_python": {"path": "C:/synthetic/python.exe"},
        "driver": {"path": "C:/synthetic/capture.py"},
    })
    assets.update({role: {"sha256": replay.sha((ROOT / f"{role}.py").read_bytes())}
                   for role in ("schedule", "replay")})
    for role, binding in assets.items():
        binding.setdefault("path", f"C:/synthetic/{role}.py")
        binding.setdefault("sha256", "0" * 64)
    manifest = {
        "schema": "ptg-resolver-valid-launch-v1", "assets": assets,
        "cwd": "C:/synthetic/neutral",
        "child_environment": {"PATH": "C:/synthetic/fixture with spaces", "PATHEXT": ".EXE",
                              "NoDefaultCurrentDirectoryInExePath": "1"},
    }
    manifest_path = ROOT / "synthetic-manifest.json"
    approval_path = ROOT / "synthetic-approval.json"
    attempt = ROOT / "synthetic-attempt"
    receipt_dir = ROOT / "synthetic-wrapper"
    manifest["invocation"] = {
        "manifest": str(manifest_path), "approval": str(approval_path),
        "attempt": str(attempt), "receipt_dir": str(receipt_dir),
    }
    manifest_bytes = replay.canonical(manifest)
    manifest_hash = replay.sha(manifest_bytes)
    approval = replay.canonical({
        "schema": manifest["schema"], "state": "APPROVED", "manifest_sha256": manifest_hash,
        "reviewers": ["resolver_method", "resolver_critic"],
    })
    approval_hash = replay.sha(approval)
    argv = [
        "--timeout", "120", "--", assets["controller_python"]["path"], "-I", "-B",
        assets["driver"]["path"], "capture", "--manifest", str(manifest_path),
        "--manifest-sha256", manifest_hash, "--approval", str(approval_path),
        "--approval-sha256", approval_hash, "--out", str(attempt),
    ]
    schedule = plan()
    valid = [sample_row(slot, manifest) for slot in schedule]
    native_read = Path.read_bytes

    def check(rows, change_terminal=None, bad_stream=False, expected_hash=manifest_hash, change_wrapper=None,
              bad_approval=False, bad_telemetry=False, bad_hold=False):
        journal = b"\n".join(replay.canonical(row) for row in rows) + b"\n"
        samples = [{
            "index": i, "monotonic_ns": (valid[i]["armed_ns"] - 1 if i < 300
                                         else valid[-1]["settled_ns"] + 1),
            "native_admission": {"admitted": True}, "disk_free_bytes": 1_000_000_000,
            **{key: i for key in ("wall_ns", "tick_ms", "awake_100ns", "idle_100ns",
                                  "kernel_100ns", "user_100ns")},
        } for i in [0, *range(12, 300, 12), 300]]
        if bad_telemetry:
            del samples[1]
        telemetry = b"\n".join(replay.canonical(sample) for sample in samples) + b"\n"
        terminal = {
            "state": "COMPLETE", "complete": True, "rows_expected": 300, "rows_completed": 300,
            "manifest_sha256": manifest_hash, "journal_sha256": replay.sha(journal),
            "schedule_sha256": assets["schedule"]["sha256"],
            "schedule_rows_sha256": replay.sha(replay.canonical(schedule)),
            "controller_pid": 42, "controller_creation_filetime": 200,
            "primary_guard_pid": 43, "primary_guard_creation_filetime": 100,
            "approval_sha256": approval_hash,
            "child_environment_utf16_sha256": replay.environment_digest(manifest["child_environment"]),
            "telemetry_sha256": replay.sha(telemetry),
        }
        if change_terminal:
            terminal.update(change_terminal)
        files = {manifest_path: manifest_bytes, attempt / "terminal.json": replay.canonical(terminal),
                 attempt / "journal.jsonl": journal,
                 attempt / "telemetry.jsonl": telemetry,
                 approval_path: b"{}" if bad_approval else approval}
        held = {
            role: {**binding, "final_path": binding["path"], "file_id": i + 1, "size": 10}
            for i, (role, binding) in enumerate(dict(
                assets, manifest={"path": str(manifest_path), "sha256": manifest_hash},
                approval={"path": str(approval_path), "sha256": approval_hash},
            ).items())
        }
        preflight = {
            "manifest_sha256": manifest_hash, "asset_hold": held,
            "child_environment": manifest["child_environment"],
            "child_environment_utf16_sha256": replay.environment_digest(manifest["child_environment"]),
            "outer_guard": {"pid": 43, "creation_filetime": 100, "controller_in_job": True,
                            "sha256": "a" * 64, "timeout_seconds": 120, "reserve_seconds": 10,
                            "argv": [assets["outer_guard"]["path"], *argv]},
            "controller_pid": 42, "controller_creation_filetime": 200,
        }
        files[attempt / "preflight.json"] = replay.canonical(preflight)
        after = {role: {"held": item, "reopened_path": item} for role, item in held.items()}
        if bad_hold:
            after["fixture"]["reopened_path"] = {**held["fixture"], "file_id": 999}
        files[attempt / "postflight.json"] = replay.canonical({
            "asset_hold": after, "rows_completed": len(rows),
        })
        wrapper = {
            "schema": "ptg-resolver-wrapper-v1", "manifest_sha256": manifest_hash,
            "approval_sha256": approval_hash, "primary_guard_sha256": "a" * 64, "primary_exit": 0,
            "started_unix_ms": 123, "finished_unix_ms": 456, "observed_instances_alive": 0,
            "observation_error": None, "primary_guard_pid": 43, "controller_pid": 42,
            "observed_pid_count": len({row["identity_before"]["pid"] for row in rows}) + 2,
            "current_processes": [],
            "guard_argv": argv,
            "stdout_sha256": replay.sha(b""), "stderr_sha256": replay.sha(b""),
            "attempt_sha256": {path.name: replay.sha(contents) for path, contents in files.items()
                               if path.parent == attempt},
        }
        if change_wrapper:
            wrapper.update(change_wrapper)
        files[receipt_dir / "wrapper.json"] = replay.canonical(wrapper)
        files[receipt_dir / "stdout.log"] = b""
        files[receipt_dir / "stderr.log"] = b""
        for i, row in enumerate(rows):
            folder = attempt / f"{i:04d}"
            files[folder / "final.json"] = replay.canonical(row)
            files[folder / "stdin.bin"] = replay.STDIN
            files[folder / "stdout.bin"] = replay.STDOUT if not (bad_stream and i == 0) else b"wrong"
            files[folder / "stderr.bin"] = replay.STDERR

        def read_file(path):
            if path in files:
                return files[path]
            return native_read(path)

        with patch.object(Path, "read_bytes", read_file):
            return replay.replay(manifest_path, expected_hash, attempt, receipt_dir, approval_path)

    report = check(valid)
    assert report["blocks"] == 24 and report["control_rows"] == 12 and report["measured_rows"] == 288
    for cell in report["cells"]:
        assert cell["candidate_minus_baseline"]["median_ms"] == 1.0
        assert cell["candidate_minus_repaired_wake"]["median_ms"] == -1.0
        assert cell["arms"]["candidate"] == {"median_ms": 41.0, "p90_ms": 41.0}
    for contrast in report["bare_minus_absolute_candidate_minus_baseline"].values():
        assert contrast["zero"] == 24 and contrast["median_ms"] == 0

    outcomes = {}

    def refuse(name, reason, rows=valid, **kwargs):
        try:
            check(rows, **kwargs)
        except ValueError as error:
            assert str(error).startswith(reason), (name, str(error))
            outcomes[name] = str(error)
        else:
            raise AssertionError(f"accepted invalid mutation: {name}")

    refuse("missing", "wrong journal length", valid[:-1])
    refuse("duplicate", "wrong schedule row", valid[:2] + [valid[1]] + valid[3:])
    refuse("reorder", "wrong schedule row", [valid[1], valid[0], *valid[2:]])
    refuse("terminal_incomplete", "incomplete", change_terminal={"complete": False})
    refuse("terminal_journal_digest", "incomplete", change_terminal={"journal_sha256": "wrong"})
    refuse("terminal_schedule_digest", "incomplete", change_terminal={"schedule_rows_sha256": "wrong"})
    refuse("manifest_digest", "manifest digest mismatch", expected_hash="wrong")
    refuse("raw_stream", "raw stream differs", bad_stream=True)
    refuse("wrapper_nonzero", "invalid independent wrapper", change_wrapper={"primary_exit": 124})
    refuse("wrapper_invocation", "wrapper invocation differs",
           change_wrapper={"guard_argv": [*argv[:17], "wrong-attempt"]})
    refuse("changed_held_input", "held identity differs", bad_hold=True)
    refuse("wrapper_approval", "capture approval is missing", bad_approval=True)
    refuse("missing_telemetry_boundary", "telemetry boundaries differ", bad_telemetry=True)
    refuse("wrapper_survivor", "invalid independent wrapper", change_wrapper={"observed_instances_alive": 1})
    refuse("wrapper_digests", "wrapper attempt digests differ", change_wrapper={"attempt_sha256": {}})
    refuse("wrapper_identity", "wrapper and live ancestry differ", change_wrapper={"controller_pid": 101})

    mutations = {
        "child_environment": ("wrong child environment", {"environment": {"utf16_sha256": "wrong"}}),
        "flag_context": ("wrong creation flags", {"creation_flags": replay.COMMON_FLAGS | 8}),
        "late_settlement": ("invalid clock bracket", {"settled_ns": valid[0]["measurement_end_ns"] + replay.SETTLE_NS + 1}),
        "late_watchdog": ("invalid slot watchdog", {"watchdog_fired": True}),
        "wrong_handle": ("invalid held process handle", {"wait": {**valid[0]["wait"], "process_handle": -1}}),
        "not_signaled": ("invalid held process handle", {"wait": {**valid[0]["wait"], "native_return": 258}}),
        "not_admitted": ("invalid suspended admission", {"suspended": {**valid[0]["suspended"], "member": False}}),
        "bad_exit": ("invalid held process handle", {"exit": {**valid[0]["exit"], "exit_code_u32": 0}}),
        "bad_oracle": ("stream hash oracle", {"oracle": {**valid[0]["oracle"], "stderr_sha256": "wrong"}}),
        "survivor": ("slot Job did not drain", {"cleanup": {"active_after": 1}}),
    }
    for name, (reason, update) in mutations.items():
        row = deepcopy(valid[0])
        row.update(update)
        refuse(name, reason, [row, *valid[1:]])

    print(json.dumps({"synthetic_valid_rows": 300, "mutations_refused": len(outcomes),
                      "refusal_reasons": outcomes}, indent=2))


if __name__ == "__main__":
    main()
