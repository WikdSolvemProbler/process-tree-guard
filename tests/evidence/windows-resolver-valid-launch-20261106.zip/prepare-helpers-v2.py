import ast
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

here = Path(__file__).resolve().parent
repo = here.parents[2]
archive = repo / "tests/evidence/windows-wake-directional-20261106.zip"
expected_archive = "56d7e8282ce249dc5bfc3ab984ea03e97d99b463bb85e96db1684a7992f47038"
assert sha256(archive.read_bytes()).hexdigest() == expected_archive
helpers = here / "helpers"
assert helpers.is_dir()
receipt = {"archive_sha256": expected_archive, "sources": {}}

def digest(data):
    return sha256(data).hexdigest()

def write(name, data, member, original):
    output = helpers / name
    if output.exists():
        assert output.read_bytes() == data
    else:
        with output.open("xb") as handle:
            handle.write(data)
    receipt["sources"][name] = {
        "archive_member": member,
        "archive_member_sha256": digest(original),
        "output_sha256": digest(data),
    }

with ZipFile(archive) as evidence:
    for name, member in (
        ("native_snapshot.py", "tools/native_snapshot.py"),
        ("qualify_controls.py", "dev/qualify-controls.py"),
        ("qualify_suspended_original.py", "dev/qualify-suspended.py"),
        ("capture_original.py", "dev/capture.py"),
    ):
        raw = evidence.read(member)
        write(name, raw, member, raw)

    member = "dev/qualify-suspended.py"
    original = evidence.read(member)
    text = original.decode("utf-8")
    signature = "        expect_watchdog=False):"
    stream_anchor = '            streams = [resources.enter_context(path.open("w+b", buffering=0)) for path in paths]'
    assert text.count(signature) == text.count(stream_anchor) == 1
    text = text.replace(signature, "        expect_watchdog=False, stdin_payload=b\"\"):")
    text = text.replace(stream_anchor, stream_anchor + "\n            streams[0].write(stdin_payload)\n            streams[0].seek(0)")
    ast.parse(text)
    write("suspended_adapter.py", text.encode("utf-8"), member, original)

    member = "dev/capture.py"
    original = evidence.read(member)
    text = original.decode("utf-8")
    tree = ast.parse(text)
    definitions = {node.name: node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    hold = ast.get_source_segment(text, definitions["RuntimeHold"])
    telemetry = ast.get_source_segment(text, definitions["telemetry"])
    chain = ast.get_source_segment(text, definitions["guard_chain"])
    anchor = "    root = inspect(os.getppid())"
    assert chain.count(anchor) == 1
    inspect_outer = chain[:chain.index(anchor)].replace("def guard_chain(S, manifest):", "def inspect_outer(S):", 1)
    inspect_outer += "    return inspect(os.getppid())"
    imports = """from contextlib import ExitStack
import ctypes as C
from ctypes import wintypes as W
import os
from pathlib import Path
import time
from types import SimpleNamespace


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


A = SimpleNamespace(require=require)
"""
    source = "\n\n\n".join((imports.rstrip(), hold, telemetry, inspect_outer)) + "\n"
    ast.parse(source)
    write("capture_support.py", source.encode("utf-8"), member, original)
with (here / "helper-provenance.json").open("x", encoding="utf-8") as handle:
    json.dump(receipt, handle, indent=2)
    handle.write("\n")
print(json.dumps(receipt, indent=2))
