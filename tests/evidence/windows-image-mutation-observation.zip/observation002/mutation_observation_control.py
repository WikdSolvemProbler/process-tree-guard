"""Two fixed owned-file observations; no collector changes or workload process."""
import ctypes
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
FIXED = HERE.with_name("issue7-quiet-launch-013")
PINS = {
    "native_image.py": "6b1efb97b74cc24fe29d8a764d37ddd35ab251ba9685bf90d990759e92b1ab4b",
    "native_image_control.py": "8c404575ea297ce8fe7d7d5916ddd6bee1e99beda4d5ea46d5bfe0043951a789",
}
MANIFEST = "313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae"


def load(name, path, digest):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError("source differs: " + name)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def stat_values(value):
    return {name: getattr(value, name) for name in
            ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")}


def main():
    raw = (FIXED / "manifest.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != MANIFEST:
        raise ValueError("manifest differs")
    manifest = json.loads(raw)
    for name, digest in manifest["file_sha256"].items():
        if hashlib.sha256((FIXED / name).read_bytes()).hexdigest() != digest:
            raise ValueError("frozen013 differs: " + name)
    owner_module = load("fixture_owner_control", HERE / "native_image_control.py",
                        PINS["native_image_control.py"])
    image = load("native_image", HERE / "native_image.py", PINS["native_image.py"])
    load("image_policy", FIXED / "image_policy.py",
         manifest["file_sha256"]["image_policy.py"])
    old = load("old_inventory_observation", FIXED / "inventory_gate.py",
               manifest["file_sha256"]["inventory_gate.py"])
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = w.HANDLE
    kernel.GetProcessHandleCount.argtypes = [w.HANDLE, ctypes.POINTER(w.DWORD)]
    kernel.GetProcessHandleCount.restype = w.BOOL

    def handles():
        count = w.DWORD()
        if not kernel.GetProcessHandleCount(kernel.GetCurrentProcess(), ctypes.byref(count)):
            raise ctypes.WinError(ctypes.get_last_error())
        return count.value

    deadline = time.perf_counter_ns() + 15_000_000_000
    owned = owner_module.OwnedFixture(HERE / "observation-fixture-002")
    code = 0
    with (HERE / "mutation-observation-002.jsonl").open("x", encoding="utf-8") as output:
        def emit(kind, **values):
            print(json.dumps({"kind": kind, **values}), file=output, flush=True)

        baseline = handles()
        emit("context", manifest_sha256=MANIFEST, source_sha256=PINS,
             scope="same after-read same-length edit on two own files; no benchmark",
             benchmark_slots=0)
        try:
            owned.create()
            for backend in ("013", "014"):
                if time.perf_counter_ns() >= deadline:
                    raise TimeoutError("15-second observation deadline")
                name = "image-" + backend
                owned.write(name, b"same")
                path = owned.check_file(name)
                observation_begin_ns = time.perf_counter_ns()
                records = []
                returned = error = evidence = None
                real_fstat = old.os.fstat
                real_digest = old.hashlib.file_digest
                real_metadata = image.metadata
                real_held_digest = image.held_digest

                def log_metadata(handle):
                    result = real_metadata(handle)
                    records.append({"call": "native_metadata", "ns": time.perf_counter_ns(),
                                    "handle": handle, "result": result})
                    return result

                def log_fstat(fd):
                    result = real_fstat(fd)
                    records.append({"call": "fstat", "ns": time.perf_counter_ns(),
                                    "result": stat_values(result)})
                    return result

                class ObservedPath:
                    def stat(self):
                        result = path.stat()
                        records.append({"call": "path_stat", "ns": time.perf_counter_ns(),
                                        "result": stat_values(result)})
                        return result

                    def open(self, *args, **kwargs):
                        return path.open(*args, **kwargs)

                def mutate():
                    records.append({"call": "mutation_begin", "ns": time.perf_counter_ns()})
                    checked_path = owned.check_file(name)
                    with checked_path.open("wb") as writer:
                        records.append({"call": "writer_opened", "ns": time.perf_counter_ns()})
                        written = writer.write(b"edit")
                        records.append({"call": "writer_write_returned", "bytes": written,
                                        "ns": time.perf_counter_ns()})
                    owned.check_file(name)
                    records.append({"call": "mutation_writer_closed",
                                    "ns": time.perf_counter_ns()})

                def old_read(stream, algorithm):
                    result = real_digest(stream, algorithm)
                    records.append({"call": "digest_completed", "ns": time.perf_counter_ns(),
                                    "digest": result.hexdigest()})
                    mutate()
                    return result

                def native_read(handle, size):
                    result = real_held_digest(handle, size)
                    records.append({"call": "digest_completed", "ns": time.perf_counter_ns(),
                                    "digest": result})
                    mutate()
                    return result

                try:
                    image.metadata = log_metadata
                    if backend == "013":
                        old.os.fstat = log_fstat
                        old.hashlib.file_digest = old_read
                        returned = old.image_digest(ObservedPath())
                    else:
                        image.held_digest = native_read
                        returned, evidence = image.inspect_image(path)
                except (OSError, ValueError) as exception:
                    error = f"{type(exception).__name__}: {exception}"
                finally:
                    old.os.fstat = real_fstat
                    old.hashlib.file_digest = real_digest
                    image.metadata = real_metadata
                    image.held_digest = real_held_digest
                # Both functions have exited their content-handle context here.
                final_bytes = path.read_bytes()
                final_native = image.named_metadata(path)
                final_stat = stat_values(path.stat())
                emit("observation", backend=backend, observation_begin_ns=observation_begin_ns,
                     records=records, returned_digest=returned,
                     returned_evidence=evidence, error=error, final_bytes_hex=final_bytes.hex(),
                     final_digest=hashlib.sha256(final_bytes).hexdigest(),
                     final_length=len(final_bytes), observation_end_ns=time.perf_counter_ns(),
                     final_native_metadata=final_native, final_path_stat=final_stat,
                     handle_count=handles(), baseline=baseline)
                if final_bytes != b"edit" or handles() != baseline:
                    raise ValueError("mutation/readback/handle control failed")
                if time.perf_counter_ns() >= deadline:
                    raise TimeoutError("15-second deadline after completed observation")
        except BaseException as exception:
            code = 1
            emit("error", error=f"{type(exception).__name__}: {exception}")
        finally:
            cleanup_errors = owned.cleanup()
            if cleanup_errors:
                code = 1
                emit("cleanup_refused", reasons=cleanup_errors)
            for name, digest in PINS.items():
                if hashlib.sha256((HERE / name).read_bytes()).hexdigest() != digest:
                    code = 1
                    emit("error", error="source changed: " + name)
            if time.perf_counter_ns() >= deadline:
                code = 1
                emit("error", error="15-second deadline before terminal")
            emit("terminal", code=code, handle_count=handles(), baseline=baseline,
                 fixture_absent=not owned.path.exists(), benchmark_slots=0)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
