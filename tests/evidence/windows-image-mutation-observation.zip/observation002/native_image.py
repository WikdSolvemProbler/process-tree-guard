"""Per-row shared-read Windows file evidence. No identity or digest cache."""
from contextlib import contextmanager
import ctypes
from ctypes import wintypes as w
import hashlib
import time

kernel = ctypes.WinDLL("kernel32", use_last_error=True)
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
GENERIC_READ = 0x80000000
FILE_READ_ATTRIBUTES = 0x80
SHARE_ALL = 1 | 2 | 4
OPEN_EXISTING = 3
FILE_ATTRIBUTE_DIRECTORY = 0x10
CHUNK = 65536


class BasicInfo(ctypes.Structure):
    _fields_ = [
        ("creation", ctypes.c_int64), ("access", ctypes.c_int64),
        ("write", ctypes.c_int64), ("change", ctypes.c_int64),
        ("attributes", w.DWORD),
    ]


class StandardInfo(ctypes.Structure):
    _fields_ = [
        ("allocation", ctypes.c_int64), ("end", ctypes.c_int64),
        ("links", w.DWORD), ("delete_pending", w.BYTE), ("directory", w.BYTE),
    ]


class IdInfo(ctypes.Structure):
    _fields_ = [("volume", ctypes.c_uint64), ("file_id", ctypes.c_ubyte * 16)]


if (ctypes.sizeof(BasicInfo), ctypes.sizeof(StandardInfo), ctypes.sizeof(IdInfo)) != (40, 24, 24):
    raise RuntimeError("unsupported Windows file metadata layout")
if (BasicInfo.attributes.offset, StandardInfo.delete_pending.offset,
        StandardInfo.directory.offset, IdInfo.file_id.offset) != (32, 20, 21, 8):
    raise RuntimeError("Windows file metadata offsets differ")


def bind(name, args, result):
    call = getattr(kernel, name)
    call.argtypes = args
    call.restype = result
    return call


create_file = bind("CreateFileW", [
    w.LPCWSTR, w.DWORD, w.DWORD, ctypes.c_void_p, w.DWORD, w.DWORD, w.HANDLE,
], w.HANDLE)
file_info = bind("GetFileInformationByHandleEx", [
    w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD,
], w.BOOL)
read_file = bind("ReadFile", [
    w.HANDLE, ctypes.c_void_p, w.DWORD, ctypes.POINTER(w.DWORD), ctypes.c_void_p,
], w.BOOL)
close_handle = bind("CloseHandle", [w.HANDLE], w.BOOL)


def checked(value):
    if not value:
        raise ctypes.WinError(ctypes.get_last_error())


@contextmanager
def opened(path, access):
    # Null SECURITY_ATTRIBUTES creates a non-inheritable handle. Explicitly
    # share reads, writes and deletes instead of excluding other workers.
    handle = create_file(str(path), access, SHARE_ALL, None, OPEN_EXISTING, 0, None)
    if not handle or handle == INVALID_HANDLE_VALUE:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        yield handle
    finally:
        checked(close_handle(handle))


def metadata(handle):
    basic, standard, identity = BasicInfo(), StandardInfo(), IdInfo()
    checked(file_info(handle, 0, ctypes.byref(basic), ctypes.sizeof(basic)))
    checked(file_info(handle, 1, ctypes.byref(standard), ctypes.sizeof(standard)))
    checked(file_info(handle, 18, ctypes.byref(identity), ctypes.sizeof(identity)))
    if (standard.directory or basic.attributes & FILE_ATTRIBUTE_DIRECTORY
            or standard.delete_pending or standard.end < 0 or standard.allocation < 0
            or not any(identity.file_id)):
        raise ValueError("image is not an identified regular file")
    return {
        "volume": identity.volume, "file_id_128": bytes(identity.file_id).hex(),
        "size": standard.end, "allocation": standard.allocation, "links": standard.links,
        "creation_ticks": basic.creation, "write_ticks": basic.write,
        "change_ticks": basic.change, "attributes": basic.attributes,
        "directory": bool(standard.directory), "delete_pending": bool(standard.delete_pending),
    }


def named_metadata(path):
    with opened(path, FILE_READ_ATTRIBUTES) as handle:
        return metadata(handle)


def held_digest(handle, size):
    digest = hashlib.sha256()
    buffer = ctypes.create_string_buffer(CHUNK)
    remaining = size
    while remaining:
        count = w.DWORD()
        checked(read_file(handle, buffer, min(CHUNK, remaining), ctypes.byref(count), None))
        if not 0 < count.value <= min(CHUNK, remaining):
            raise ValueError("image ended before its initial size")
        digest.update(buffer.raw[:count.value])
        remaining -= count.value
    count = w.DWORD()
    checked(read_file(handle, buffer, 1, ctypes.byref(count), None))
    if count.value:
        raise ValueError("image exceeds its initial size")
    return digest.hexdigest()


def inspect_image(path):
    evidence = {"schema": 1, "path": str(path), "begin_ns": time.perf_counter_ns()}
    before_name = named_metadata(path)
    with opened(path, GENERIC_READ | FILE_READ_ATTRIBUTES) as handle:
        before_handle = metadata(handle)
        if before_name != before_handle:
            raise ValueError("image named entry differs from opened native identity")
        digest = held_digest(handle, before_handle["size"])
        after_handle = metadata(handle)
        after_name = named_metadata(path)
        if before_handle != after_handle or before_name != after_name or after_handle != after_name:
            raise ValueError("image native identity or metadata changed during inspection")
    evidence.update(named_before=before_name, held_before=before_handle,
                    held_after=after_handle, named_after=after_name,
                    sha256=digest, end_ns=time.perf_counter_ns())
    return digest, evidence
