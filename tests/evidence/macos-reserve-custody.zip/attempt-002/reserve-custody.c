/* Ordinary-user Darwin check of exact retained-child custody. */
#define _DARWIN_C_SOURCE 1

#if !defined(__APPLE__) || !defined(__aarch64__)
#error This probe targets macOS arm64.
#endif
#include <errno.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <sys/proc.h>
#include <sys/sysctl.h>
#include <sys/wait.h>
#include <unistd.h>

enum { CASE_DEADLINE_SECONDS = 5 };

struct reserve_report {
    pid_t pid;
    int retained_error;
};

static bool exited_ok(pid_t pid)
{
    int status;
    pid_t done;
    do {
        done = waitpid(pid, &status, 0);
    } while (done < 0 && errno == EINTR);
    return done == pid && WIFEXITED(status) && WEXITSTATUS(status) == 0;
}

static int wait_retained(pid_t pid)
{
    siginfo_t info = {0};
    int rc;
    do {
        rc = waitid(P_PID, (id_t)pid, &info, WEXITED | WNOWAIT);
    } while (rc != 0 && errno == EINTR);
    if (rc != 0)
        return errno;
    return info.si_pid == pid && info.si_code == CLD_EXITED
        && info.si_status == 0 ? 0 : EIO;
}

static bool read_full(int fd, void *buffer, size_t size)
{
    unsigned char *cursor = buffer;
    while (size > 0) {
        ssize_t n = read(fd, cursor, size);
        if (n < 0 && errno == EINTR)
            continue;
        if (n <= 0)
            return false;
        cursor += n;
        size -= (size_t)n;
    }
    return true;
}

static int inspect_pid(pid_t pid, struct kinfo_proc *info, bool *present)
{
    int mib[] = {CTL_KERN, KERN_PROC, KERN_PROC_PID, pid};
    size_t length = sizeof(*info);
    if (sysctl(mib, 4, info, &length, NULL, 0) != 0)
        return errno;
    if (length != 0 && length != sizeof(*info))
        return EIO;
    *present = length == sizeof(*info);
    return *present && info->kp_proc.p_pid != pid ? EIO : 0;
}

static _Noreturn void own_reserve(int ready_fd, int release_fd, bool explicit_reap)
{
    alarm(CASE_DEADLINE_SECONDS);
    struct reserve_report report = {0};
    report.pid = fork();
    if (report.pid == 0)
        _exit(0);
    report.retained_error = report.pid < 0 ? errno : wait_retained(report.pid);
    const bool reported = write(ready_fd, &report, sizeof(report)) == (ssize_t)sizeof(report);
    close(ready_fd);
    unsigned char release = 0;
    const bool released = read_full(release_fd, &release, sizeof(release))
        && release == 1;
    close(release_fd);
    if (!reported || !released || report.retained_error != 0) {
        if (report.pid > 0)
            (void)exited_ok(report.pid);
        _exit(1);
    }
    if (explicit_reap && !exited_ok(report.pid))
        _exit(2);
    _exit(0);
}

static bool trial(bool explicit_reap)
{
    int ready[2];
    int release[2];
    if (pipe(ready) != 0) {
        perror("ready pipe");
        return false;
    }
    if (pipe(release) != 0) {
        perror("release pipe");
        close(ready[0]);
        close(ready[1]);
        return false;
    }
    alarm(CASE_DEADLINE_SECONDS);
    pid_t owner = fork();
    if (owner == 0) {
        close(ready[0]);
        close(release[1]);
        own_reserve(ready[1], release[0], explicit_reap);
    }
    close(ready[1]);
    close(release[0]);
    if (owner < 0) {
        perror("owner fork");
        close(ready[0]);
        close(release[1]);
        alarm(0);
        return false;
    }

    struct reserve_report report = {0};
    bool reported = read_full(ready[0], &report, sizeof(report));
    close(ready[0]);
    struct kinfo_proc before = {0};
    bool present_before = false;
    int before_error = reported && report.pid > 0
        ? inspect_pid(report.pid, &before, &present_before) : EINVAL;
    bool exact_zombie = before_error == 0 && present_before
        && before.kp_proc.p_stat == SZOMB && before.kp_eproc.e_ppid == owner
        && before.kp_eproc.e_pcred.p_ruid == getuid()
        && before.kp_proc.p_starttime.tv_sec > 0;

    siginfo_t info = {0};
    int nonparent_error = EINVAL;
    if (exact_zombie) {
        int rc = waitid(P_PID, (id_t)report.pid, &info, WEXITED | WNOWAIT | WNOHANG);
        nonparent_error = rc == 0 ? 0 : errno;
    }
    unsigned char go = 1;
    bool released = write(release[1], &go, sizeof(go)) == (ssize_t)sizeof(go);
    close(release[1]);
    bool owner_reaped = exited_ok(owner);

    struct kinfo_proc after = {0};
    bool present_after = false;
    int after_error = report.pid > 0
        ? inspect_pid(report.pid, &after, &present_after) : EINVAL;
    bool original_absent = after_error == 0
        && (!present_after
            || after.kp_proc.p_starttime.tv_sec != before.kp_proc.p_starttime.tv_sec
            || after.kp_proc.p_starttime.tv_usec != before.kp_proc.p_starttime.tv_usec);
    alarm(0);

    bool pass = reported && report.retained_error == 0 && exact_zombie
        && nonparent_error == ECHILD && released && owner_reaped && original_absent;
    printf("mode=%s owner=%d reserve=%d reported=%d owner_wait=%d "
           "before_errno=%d present_before=%d exact_zombie=%d "
           "reserve_ppid=%d reserve_ruid=%u reserve_status=%d "
           "reserve_start_sec=%lld reserve_start_usec=%ld "
           "nonparent_wait_errno=%d released=%d owner_reaped=%d "
           "after_errno=%d present_after=%d after_start_sec=%lld after_start_usec=%ld "
           "original_absent=%d pass=%d\n",
           explicit_reap ? "explicit-reap" : "owner-exit",
           (int)owner, (int)report.pid, reported, report.retained_error,
           before_error, present_before, exact_zombie,
           (int)before.kp_eproc.e_ppid, (unsigned)before.kp_eproc.e_pcred.p_ruid,
           (int)before.kp_proc.p_stat,
           (long long)before.kp_proc.p_starttime.tv_sec,
           (long)before.kp_proc.p_starttime.tv_usec,
           nonparent_error, released, owner_reaped, after_error, present_after,
           (long long)after.kp_proc.p_starttime.tv_sec,
           (long)after.kp_proc.p_starttime.tv_usec,
           original_absent, pass);
    return pass;
}

int main(void)
{
    sigset_t alarm_mask;
    if (getuid() == 0 || getuid() != geteuid()
        || sigemptyset(&alarm_mask) != 0
        || sigaddset(&alarm_mask, SIGALRM) != 0
        || sigprocmask(SIG_UNBLOCK, &alarm_mask, NULL) != 0
        || signal(SIGCHLD, SIG_DFL) == SIG_ERR
        || signal(SIGALRM, SIG_DFL) == SIG_ERR
        || signal(SIGPIPE, SIG_IGN) == SIG_ERR)
        return 125;
    setvbuf(stdout, NULL, _IOLBF, 0);
    printf("driver=%d pgid=%d ruid=%u echild=%d\n",
           (int)getpid(), (int)getpgrp(), (unsigned)getuid(), ECHILD);
    bool control = trial(true);
    bool parent_exit = trial(false);
    errno = 0;
    bool no_child = waitpid(-1, NULL, WNOHANG) == -1 && errno == ECHILD;
    printf("control=%d parent_exit=%d no_owned_children=%d\n",
           control, parent_exit, no_child);
    return control && parent_exit && no_child ? 0 : 1;
}
