$ErrorActionPreference='Stop'
$bundle=$PSScriptRoot
Add-Type -AssemblyName System.Reflection.Metadata
function Get-Digest([byte[]]$Bytes) {
 [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($Bytes)).ToLowerInvariant()
}
function Get-MappedSection($Sections,[int64]$Rva,[int64]$Size) {
 $match=@($Sections | Where-Object { $Rva -ge $_.rva -and ($Rva+$Size) -le ($_.rva+$_.mapped.Length) })
 if($match.Count -ne 1){throw "PE virtual range is outside one section: RVA=$Rva size=$Size"}
 $match[0]
}
function Clear-DebugRange($Sections,[int]$Rva,[int]$Size,[string]$Kind) {
 if($Size -eq 0 -or $Rva -eq 0){return}
 $owner=Get-MappedSection $Sections $Rva $Size
 if($owner.name -cnotin @('.rdata','.debug')){throw "untrusted PE debug range owner: $($owner.name)"}
 [Array]::Clear($owner.normalized,$Rva-$owner.rva,$Size)
 [pscustomobject]@{section=$owner.name;rva=$Rva;size=$Size;kind=$Kind}
}
function Read-Pe([string]$Variant,[string]$Artifact) {
 $file=[IO.File]::ReadAllBytes((Join-Path $bundle $Artifact))
 $stream=[IO.MemoryStream]::new($file,$false)
 $reader=[Reflection.PortableExecutable.PEReader]::new($stream)
 try {
  $headers=$reader.PEHeaders
  $pe=$headers.PEHeader
  if($headers.CoffHeader.Machine.ToString() -cne 'Amd64' -or $pe.Magic.ToString() -cne 'PE32Plus'){throw "unexpected PE platform: $Variant"}
  $sections=@(foreach($section in $headers.SectionHeaders) {
   $size=$section.VirtualSize
   $rawSize=$section.SizeOfRawData
   $rawOffset=$section.PointerToRawData
   if($size -le 0 -or $rawSize -lt 0 -or $rawOffset -lt 0 -or
      ($rawSize -gt 0 -and ($rawOffset -eq 0 -or [int64]$rawOffset+$rawSize -gt $file.Length))){
    throw "invalid PE extent: $Variant $($section.Name)"
   }
   $raw=[byte[]]::new($rawSize)
   if($rawSize -gt 0){[Array]::Copy($file,$rawOffset,$raw,0,$raw.Length)}
   $mapped=[byte[]]::new($size)
   [Array]::Copy($raw,$mapped,[Math]::Min($mapped.Length,$raw.Length))
   [pscustomobject]@{
    name=$section.Name
    rva=$section.VirtualAddress
    characteristics=('0x{0:x8}' -f [uint32]$section.SectionCharacteristics)
    raw_size=$rawSize
    raw_sha256=(Get-Digest $raw)
    mapped=$mapped
    normalized=[byte[]]$mapped.Clone()
   }
  })
  $text=@($sections | Where-Object Name -CEQ '.text')
  if($text.Count -ne 1 -or ([Convert]::ToUInt32($text[0].characteristics.Substring(2),16) -band 0x20000020) -ne 0x20000020){
   throw "expected one executable PE .text section: $Variant"
  }
  $text=$text[0]
  $debug=$pe.DebugTableDirectory
  $debugRanges=@()
  if($debug.Size -gt 0){
   $entries=$reader.ReadDebugDirectory()
   if($debug.Size%28 -ne 0 -or $entries.Length -ne ($debug.Size/28)){throw "unexpected PE debug table: $Variant"}
   $debugRanges=@(for($index=0;$index -lt $entries.Length;$index++){
    $entry=$entries[$index]
    $type=$entry.Type.ToString()
    if($type -cnotin @('CodeView','Reproducible','EmbeddedPortablePdb','PdbChecksum')){continue}
    Clear-DebugRange $sections ($debug.RelativeVirtualAddress+28*$index) 28 "$type-directory"
    Clear-DebugRange $sections $entry.DataRelativeVirtualAddress $entry.DataSize "$type-payload"
   })
  }
  $textRelocations=0
  $relocations=$pe.BaseRelocationTableDirectory
  if($relocations.Size -gt 0){
   $owner=Get-MappedSection $sections $relocations.RelativeVirtualAddress $relocations.Size
   $offset=$relocations.RelativeVirtualAddress-$owner.rva
   $end=$offset+$relocations.Size
   while($offset -lt $end){
    if($offset+8 -gt $end){throw "truncated PE relocation block: $Variant"}
    $page=[BitConverter]::ToUInt32($owner.mapped,$offset)
    $size=[BitConverter]::ToUInt32($owner.mapped,$offset+4)
    if($size -lt 8 -or $size%2 -ne 0 -or $offset+$size -gt $end){throw "invalid PE relocation block: $Variant"}
    for($index=$offset+8;$index -lt ($offset+$size);$index+=2){
     $entry=[BitConverter]::ToUInt16($owner.mapped,$index)
     if(($entry -shr 12) -eq 0){continue}
     $address=$page+($entry -band 0xfff)
     if($address -ge $text.rva -and $address -lt ($text.rva+$text.mapped.Length)){$textRelocations++}
    }
    $offset+=$size
   }
  }
  $runtimeHeaders=[ordered]@{
   machine=$headers.CoffHeader.Machine.ToString(); magic=$pe.Magic.ToString()
   coff_characteristics=$headers.CoffHeader.Characteristics.ToString()
   entry_rva=$pe.AddressOfEntryPoint; image_base=$pe.ImageBase; base_of_code=$pe.BaseOfCode
   section_alignment=$pe.SectionAlignment; file_alignment=$pe.FileAlignment
   size_of_image=$pe.SizeOfImage; size_of_headers=$pe.SizeOfHeaders
   subsystem=$pe.Subsystem.ToString(); dll_characteristics=$pe.DllCharacteristics.ToString()
   subsystem_major=$pe.MajorSubsystemVersion; subsystem_minor=$pe.MinorSubsystemVersion
   stack_reserve=$pe.SizeOfStackReserve; stack_commit=$pe.SizeOfStackCommit
   heap_reserve=$pe.SizeOfHeapReserve; heap_commit=$pe.SizeOfHeapCommit
  }
  $runtimeDirectories=[ordered]@{}
  foreach($property in ($pe.GetType().GetProperties() | Where-Object {$_.PropertyType.Name -ceq 'DirectoryEntry' -and $_.Name -cne 'DebugTableDirectory'} | Sort-Object Name)){
   $entry=$property.GetValue($pe)
   $runtimeDirectories[$property.Name]=@($entry.RelativeVirtualAddress,$entry.Size)
  }
  [IO.File]::WriteAllBytes((Join-Path $bundle "$Variant.text.bin"),$text.mapped)
  [pscustomobject]@{
   file=$Artifact
   file_size=$file.Length
   file_sha256=(Get-Digest $file)
   runtime_headers=$runtimeHeaders
   runtime_directories=$runtimeDirectories
   text_base_relocation_count=$textRelocations
   debug_ranges=$debugRanges
   sections=@(foreach($section in $sections){
    [ordered]@{
     name=$section.name;rva=$section.rva;characteristics=$section.characteristics
     raw_size=$section.raw_size;raw_sha256=$section.raw_sha256
     virtual_size=$section.mapped.Length;virtual_sha256=(Get-Digest $section.mapped)
     virtual_sha256_excluding_recognized_debug=(Get-Digest $section.normalized)
    }
   })
  }
 } finally {$reader.Dispose();$stream.Dispose()}
}
$baseline=Read-Pe 'baseline' 'baseline-target/x86_64-pc-windows-msvc/release/process-tree-guard.exe'
$candidate=Read-Pe 'candidate' 'live-target/x86_64-pc-windows-msvc/release/process-tree-guard.exe'
$baselineSections=@{}
$candidateSections=@{}
foreach($section in $baseline.sections){$baselineSections.Add($section.name,$section)}
foreach($section in $candidate.sections){$candidateSections.Add($section.name,$section)}
$differences=@(foreach($name in ((@($baselineSections.Keys)+@($candidateSections.Keys)) | Sort-Object -Unique)){
 $left=$baselineSections[$name]
 $right=$candidateSections[$name]
 $sameExtent=$null -ne $left -and $null -ne $right -and $left.rva -eq $right.rva -and $left.virtual_size -eq $right.virtual_size -and $left.characteristics -ceq $right.characteristics
 [pscustomobject]@{
  name=$name
  extent_identical=$sameExtent
  raw_bytes_identical=$sameExtent -and $left.raw_size -eq $right.raw_size -and $left.raw_sha256 -ceq $right.raw_sha256
  virtual_bytes_identical=$sameExtent -and $left.virtual_sha256 -ceq $right.virtual_sha256
  virtual_bytes_identical_excluding_recognized_debug=$sameExtent -and $left.virtual_sha256_excluding_recognized_debug -ceq $right.virtual_sha256_excluding_recognized_debug
 }
})
$baseText=$baselineSections['.text']
$candidateText=$candidateSections['.text']
$result=[ordered]@{
 baseline=$baseline
 candidate=$candidate
 file_size_delta_bytes=$candidate.file_size-$baseline.file_size
 text_virtual_size_delta_bytes=$candidateText.virtual_size-$baseText.virtual_size
 text_virtual_bytes_identical=@($differences | Where-Object Name -CEQ '.text')[0].virtual_bytes_identical
 runtime_headers_identical=(($baseline.runtime_headers | ConvertTo-Json -Compress) -ceq ($candidate.runtime_headers | ConvertTo-Json -Compress))
 runtime_directories_identical=(($baseline.runtime_directories | ConvertTo-Json -Compress) -ceq ($candidate.runtime_directories | ConvertTo-Json -Compress))
 all_mapped_sections_identical=@($differences | Where-Object {-not $_.virtual_bytes_identical}).Count -eq 0
 all_mapped_sections_identical_excluding_recognized_debug=@($differences | Where-Object {-not $_.virtual_bytes_identical_excluding_recognized_debug}).Count -eq 0
 sections=$differences
 method='PE VirtualSize extent at original RVA, copied from raw bytes and zero-filled where needed. File alignment padding excluded. Debug normalization clears only recognized CodeView, Reproducible, EmbeddedPortablePdb, and PdbChecksum directory records and payload ranges in .rdata or .debug. Runtime PE header and non-debug directory comparisons are separate.'
}
$json=$result | ConvertTo-Json -Depth 7
[IO.File]::WriteAllText((Join-Path $bundle 'pe-comparison.json'),$json+[Environment]::NewLine)
$result | Select-Object file_size_delta_bytes,text_virtual_size_delta_bytes,text_virtual_bytes_identical,runtime_headers_identical,runtime_directories_identical,all_mapped_sections_identical,all_mapped_sections_identical_excluding_recognized_debug | ConvertTo-Json
$differences | Format-Table -AutoSize
