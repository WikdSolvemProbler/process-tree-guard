# Candidate 002 census and rendering scope

The baseline is 6e46bbf3630fee7f816887455af549fbebd49812. The scratch baseline ZIP was created with core.autocrlf=false, and all 84 staged src/ file blobs matched Git. The candidate lane uses the same archive plus the three verified candidate-source.json files. Candidate 002 changes the CLI's deadline predicate relative to the baseline, although its CLI bytes match candidate 001. Two staging checks initially stopped on the flat candidate-src layout and then on an erroneous expectation of a byte-identical baseline CLI. No census ran until the exact paths and candidate scope were verified.

Both lanes use the exact historical generator blob 50b44f53a0346d51b92b6ad0e3d750af05940725 and Python 3.12 with -I -B -X utf8. Each ran under its own 150-second Job deadline. The baseline layout is the reconciled attempt 003 layout. The candidate layout adds only src/deadline.rs to pins.pure_set.

## Publication-only rendering proposal

Keep the raw outputs and historical generator unchanged. In a separately identified renderer or renderer-only derivative, format the std-platform table from std_platform_census and mark an empty table as empty within its census scope. Compute the displayed pure-set occurrences by intersecting std_platform_census with the computed pure list, then list the exact entries or state that no occurrence was recorded. Do not infer that Windows backend files contain no std::os reference. The backend encoder is outside that census population.

The historical output hardcodes a paragraph about environment.rs retaining an OsStrExt occurrence in the pure set even though the current source and computed list show otherwise. It also prints a historical workspace path and describes historical D4, D43 and D45. Update the publication heading to identify the exact generator, input tree, and layout. Explicitly state that the full design gate was not run. Preserve the mechanical tables, edges, pins and all raw receipts. Such a rendered derivative cannot satisfy historical D4 byte comparison by itself.

There is an independent historical gate issue. D43's embedded OCCURRENCE_PINS still contains environment.rs, and lacks deadline.rs. Its implementation compares those exact file keys against the manifest before other checks. Thus the reconciled layouts cannot be presented as a pass of the old full gate. The scope of this run is the revived dependency-graph generator.

## Results

Both original-generator runs exited 0. The baseline graph covers 67 files and 26,295 lines and is byte-identical to the accadc2 baseline (SHA-256 932c2e5465f2f5a57831c90d09df06fcafb533e7dd85408eb6ccd277cc0f5fb4). Candidate 002 covers 68 files and 26,329 lines (SHA-256 fdf500c342c5438b3f709a621ca3a8c70ef5860af9e5833dfe29e0c076efd529). The only new pure member is the 34-line deadline module, with zero direct Windows references. The raw diff also adds its declaration and two dependency edges.

The separate renderer exited 0 against the exact candidate and layout. Its SHA-256 output is 636dfb67996d71f2488b8858b86234adf84c88c6897fe04566d9da2ca77565b6. Renderer source changes and output changes each comprise exactly two hunks, for the provenance heading and scoped std-platform prose. The renderer-only patch SHA-256 is dea237a58097a586ff2587d446c7521ab6c6cbfe4e63966551a374ffab7f5a4b. The raw-to-rendered output patch SHA-256 is 9ec2b568b972ec591be1a10d9476311bca0b9c9c389a3e7460f20f41c43e89e1. The raw generator and outputs remain unchanged. An initial renderer staging attempt stopped at its exact multiline seam before any generator ran. The succeeding derivative used named section boundaries and verified old line counts.
