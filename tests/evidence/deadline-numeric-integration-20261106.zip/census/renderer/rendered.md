# process-tree-guard — module dependency graph
<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- Copyright 2026 Peter Shiller -->

Computed with the dependency-graph generator from HerrNest commit
`d7d64f6516df9f6df98fdfe9b531e2799ec5ae85`. The source is process-tree-guard
commit `6e46bbf3630fee7f816887455af549fbebd49812` with deadline prototype patch
SHA-256 `a36dd2dcf5edb81c5a38548dccf22c39984539e8b3e2b8d9c46368ead437377b`.
This rendering records the revived generator result. The full historical
design gate was not run.

Edges are mechanical: a `mod` declaration
(parent -> child) or a textual `crate::<module>` reference in the
file, where the name after `crate::` is one of the crate's declared
modules (references to root types, constants and functions are not
module edges and are not listed). Submodule files also glob-import their parent (`use super::*;`),
which is how they reach the parent's re-exports; that channel is
structural, not an edge per file. `sys` does not travel it:
every production file imports the sys names
it uses from `crate::sys` explicitly, in its own text, and the
Files table's census counts that coupling per file.
The crate root (`src/lib.rs`) can name its own modules bare, so for
that file alone a declared module named as a path head (`<module>::`)
also counts as an edge.

The Files table also carries, per production file, its direct-sys-call
census: the count of call sites of the functions declared in the
production `extern` blocks of `src/sys/windows.rs`, matched by name over the
file's production text — the file with its `#[cfg(test)]` items and
modules removed, the production definition the design gate's
production-line counter applies, so test code is not counted as
production coupling. A production file is a file under `src/`
excluding any `tests.rs` file, `tests/support/testkit.rs` (a separate
program, counted in its own right by design gate D44) and the `sys`
subtree itself — and excluding any file whose every `mod`
declaration in its parent chain is `#[cfg(test)]`-gated: the
production definition sees the parents' declarations, resolved to
their actual target files (a `#[path = "..."]` attribute on a
declaration, or on an enclosing inline module, is honoured, and
file-module children of an inline module resolve under that
module's directory, as a `src/bin/*.rs` root's children resolve
beside the root), so a file with any ungated declaration, by
whatever path, is production, and such a file as has none is test
code, recorded as such below, not production;
non-production rows show — in that column. A
production file whose census is non-zero shows its `sys` edge in the
cross-module table even when its own text names no `crate::sys`,
because its own header imports the names from `crate::sys`.

## Files

| File | Lines | Direct sys calls | First doc line |
|---|---|---|---|
| `src/auth/console.rs` | 323 | 9 | The console approval prompt: the password asked on a console that is really there, its attempts and its bounded worker. |
| `src/auth/desktop.rs` | 218 | 4 | The desktop approval prompt: presence on an interactive desktop, and the credential dialog on the secure desktop. |
| `src/auth/hello/operation.rs` | 292 | 4 | The Windows Runtime operation of a request for Windows Hello: the thread it is waited on, the loop that drives it, and the window that owns it. |
| `src/auth/hello/text.rs` | 125 | 0 | The counted text of the request for Windows Hello: the fixed words and the fields, with its length in UTF-16 units counted as it is built. |
| `src/auth/hello.rs` | 448 | 4 | Windows Hello approval: the consent of the signed-in user, asked through the Windows Runtime. |
| `src/auth/message.rs` | 220 | 0 | The approval prompt's text: how a command is shown without letting look-alike characters disguise it. |
| `src/auth/names.rs` | 88 | 2 | Account names for the approval: the domain and user a logon checks, and the names a token reports. |
| `src/auth/password_budget/tests.rs` | 329 | — | Exercise the native retry store from separate test processes. |
| `src/auth/password_budget.rs` | 292 | 6 | A password attempt is charged before it reaches Windows. The charge |
| `src/auth/refusal.rs` | 350 | 2 | Why an approval is refused before anyone is asked: the refusal reasons, and the tests that detect a guard above. |
| `src/auth/seam.rs` | 32 | — | The test seam of the approval: the prompt and verifier a unit test substitutes, and the answer it gives. |
| `src/auth/secrets.rs` | 210 | 1 | Secrets held by the approval: wiping the compiler may not drop, and the registry of where a live secret is. |
| `src/auth/tests.rs` | 2988 | — | — |
| `src/auth/verify.rs` | 205 | 1 | Checking a password: the bounded background logon, so a check that never answers cannot hold the run. |
| `src/auth.rs` | 447 | 8 | The exception above the cap: the approval of the signed-in user, at the start of a run. |
| `src/base64.rs` | 432 | 0 | Standard Base64 and the encoded command text the guard accepts. |
| `src/bin/process-tree-guard-contain.rs` | 10 | 0 | `process-tree-guard-contain`: the contain role. It runs one command in a job of |
| `src/bin/process-tree-guard-deadline.rs` | 10 | 0 | `process-tree-guard-deadline`: the deadline role. It is `process-tree-guard` |
| `src/bin/process-tree-guard-gate.rs` | 10 | 0 | `process-tree-guard-gate`: the hook role. It takes the vendors and formats |
| `src/bin/ptg.rs` | 9 | 0 | `ptg`: the short name of the full role, the same program as `process-tree-guard`. |
| `src/cli/auto.rs` | 292 | 0 | Automatic mode: the wrapper a host puts in front of every shell command. |
| `src/cli/help.rs` | 30 | 0 | The command-line texts: every role's usage string, plus the one place a role is given its text. |
| `src/cli.rs` | 508 | 0 | The command line forms: `--timeout SECONDS ...`, automatic mode, `extend` and the contain role. |
| `src/cli_process/harden.rs` | 228 | 8 | Hardening a process-owning invocation: the deny-only access lists on its process and its threads. |
| `src/cli_process/stdio.rs` | 430 | 15 | The standard handles of a process-owning invocation: each probed once, kept, and written as lines. |
| `src/cli_process.rs` | 602 | 22 | Process-owning CLI policy. No supervision engine lives |
| `src/deadline.rs` | 34 | 0 | Numeric policy for requested deadlines. |
| `src/diagnostics.rs` | 508 | 4 | Returning APIs own optional output; only the explicit CLI finalizer writes it. |
| `src/dispatch.rs` | 152 | 0 | Role dispatch: the choice of which role behaviour a process performs, from its arguments or its own file name. |
| `src/engine/attributes.rs` | 97 | 7 | The creation attributes of a run: the attribute list that places the child in its job and limits the handles it inherits. |
| `src/engine/environment.rs` | 139 | 0 | The environment block a run's child is created with: this process's environment with one entry set, sorted as `CreateProcessW` takes it. |
| `src/engine/owners.rs` | 693 | 37 | The owners a run watches: the parent and ancestors, opened once, and the walk that finds the boundary above them. |
| `src/engine/resolve.rs` | 366 | 0 | Finding the program to run: the PATH and PATHEXT search, in the order the system search uses. |
| `src/engine/tests.rs` | 1153 | — | — |
| `src/engine/trace.rs` | 94 | 0 | The trace of a run: the stage lines kept until the tree has ended, and the run's sample of whether the trace is on. |
| `src/engine/wait.rs` | 489 | 21 | The waits of a run: the plain and extendable deadline waits over the child and its owners, and the teardown wait. |
| `src/engine.rs` | 692 | 16 | The engine: one command in a job object, a deadline, and the cleanup of |
| `src/extend/client.rs` | 333 | 13 | The client of an extendable run: finding its channel, connecting, and exchanging one request and one reply. |
| `src/extend/codec.rs` | 93 | 0 | The wire form of an extension exchange: the fixed-size request and reply messages of the channel. |
| `src/extend/descriptor.rs` | 231 | 15 | The channel's security descriptor: the current user's identifier, in the text form the pipe's access list is built from. |
| `src/extend/log/audit.rs` | 284 | 0 | The audit file: lines are appended, and the file is turned over to `PATH.1` when a line would take it past its limit. |
| `src/extend/log/format.rs` | 272 | 0 | One audit line's form: how a request, a grant and a refusal are written into the log's text. |
| `src/extend/log.rs` | 663 | 7 | The audit log of an extendable run: its sinks, their threads, and the file that is turned over at its limit. |
| `src/extend/serve/decide.rs` | 382 | 3 | Admission: the arrival of a connection and the decision that answers its request. |
| `src/extend/serve.rs` | 473 | 36 | Serving the channel: the pipe threads, their overlapped I/O, and the monitor that reports a job exit. |
| `src/extend/server.rs` | 287 | 10 | The extension server: a run's settings, and the running channel with its pipes, threads and deadline. |
| `src/extend/state/process.rs` | 180 | 9 | A process opened by handle: its image, its parent, and the shell that encloses it. |
| `src/extend/state/rate.rs` | 255 | 0 | The rate limit of an extendable run: the share of requests each process is allowed in a window. |
| `src/extend/state.rs` | 457 | 0 | The state of an extendable run: the processes it opened, the holds it granted, and the rate limit it keeps. |
| `src/extend/tests.rs` | 1487 | — | — |
| `src/extend.rs` | 362 | 2 | Extendable runs: the channel, the holds, the deadline and the log. |
| `src/hook/envelope.rs` | 1439 | 0 | The envelope check: whether a watched command string is exactly the guard's envelope form, checked as it decodes. |
| `src/hook/json.rs` | 283 | 0 | JSON in the hook: the value tree of the parsed verdict, and the writer the hook's answers are built with. |
| `src/hook/paths.rs` | 490 | 0 | The hook's own paths: the program's names and family, and the automatic copy and policy file it looks for beside itself. |
| `src/hook/scanner.rs` | 758 | 0 | The streaming scanner: a payload walked through one window, its watched strings decoded straight into their checkers. |
| `src/hook.rs` | 35 | 0 | The core hook mechanism: whether a hook payload's command is exactly the guard envelope. |
| `src/lib.rs` | 437 | 0 | Runs one command under a finite deadline and ends the whole |
| `src/main.rs` | 9 | 0 | `process-tree-guard`: the full command. Every mode runs in this process, with |
| `src/plugins/antigravity.rs` | 581 | 0 | The Antigravity vendor: rewriting a run_command call into the automatic wrapper, or denying it. |
| `src/plugins/powershell_auto.rs` | 338 | 0 | The powershell-auto vendor: rewriting a PowerShell tool call into the automatic wrapper, or denying it. |
| `src/plugins/verdict.rs` | 88 | 0 | The verdict family: the check-only hook vendors — one scan, one verdict, answered in each vendor's shape. |
| `src/plugins.rs` | 794 | 0 | `process-tree-guard hook VENDOR`: the command envelope check for agent shell tools. |
| `src/sys/mod.rs` | 10 | — | This module selects the backend; it declares nothing; a declaration found here is a defect by definition. |
| `src/sys/windows/encoding.rs` | 8 | — | — |
| `src/sys/windows/rng.rs` | 380 | — | The system random generator: `RtlGenRandom`, resolved from the system folder at first use and retained for the process. |
| `src/sys/windows/test_api.rs` | 31 | — | Native functions used only by Windows test fixtures. |
| `src/sys/windows.rs` | 977 | — | The Windows declarations for the whole crate: types, constants and `extern` blocks; the API tables bound at run time from the system folder, |
| `src/timing.rs` | 367 | 8 | Opt-in, source-pinned self-measurement. No I/O or workers during supervision. |

Total: 26329 lines in 68 files.

The working instruments that took this census — `tools/arch-gate.sh` (87 lines), `tools/clippy-baseline.txt` (133 lines), `tools/clippy-gate.sh` (231 lines), `tools/design-gate.sh` (21097 lines), `tools/gen_dependency_graph.py` (14192 lines), `tools/impl_census.py` (555 lines), `tools/layout.json` (123 lines), `tools/README.md` (77 lines), `tools/security-gate.sh` (330 lines), `tools/speed-gate.sh` (2244 lines), `tools/ste_check.py` (513 lines) —
total 39582 lines against the tree's 26329 lines: about
150 per cent (reported, not gated). These instruments produced the
shipped results in this tree; they do not ship in process-tree-guard,
and they are preserved on the `ptg-gauntlet-instruments` branch in HerrNest.

Recorded as test code, not production, under the parent-declaration
half of the production definition (each file's only `mod`
declaration in its parent chain is `#[cfg(test)]`-gated):

- `src/auth/password_budget/tests.rs` — declared only under `#[cfg(test)]` in `src/auth/password_budget.rs`
- `src/auth/seam.rs` — declared only under `#[cfg(test)]` in `src/auth.rs`
- `src/auth/tests.rs` — declared only under `#[cfg(test)]` in `src/auth.rs`
- `src/engine/tests.rs` — declared only under `#[cfg(test)]` in `src/engine.rs`
- `src/extend/tests.rs` — declared only under `#[cfg(test)]` in `src/extend.rs`
- `src/sys/windows/test_api.rs` — declared only under `#[cfg(test)]` in `src/sys/windows.rs`

## Module declarations (parent -> child)

- `src/auth/hello.rs` declares `operation`
- `src/auth/hello.rs` declares `text`
- `src/auth/password_budget.rs` declares `process_tests`
- `src/auth.rs` declares `console`
- `src/auth.rs` declares `secrets`
- `src/auth.rs` declares `desktop`
- `src/auth.rs` declares `hello`
- `src/auth.rs` declares `refusal`
- `src/auth.rs` declares `message`
- `src/auth.rs` declares `names`
- `src/auth.rs` declares `password_budget`
- `src/auth.rs` declares `verify`
- `src/auth.rs` declares `tests`
- `src/auth.rs` declares `seam`
- `src/cli.rs` declares `auto`
- `src/cli.rs` declares `help`
- `src/cli_process.rs` declares `harden`
- `src/cli_process.rs` declares `stdio`
- `src/engine.rs` declares `attributes`
- `src/engine.rs` declares `environment`
- `src/engine.rs` declares `owners`
- `src/engine.rs` declares `resolve`
- `src/engine.rs` declares `trace`
- `src/engine.rs` declares `wait`
- `src/engine.rs` declares `tests`
- `src/extend/log.rs` declares `audit`
- `src/extend/log.rs` declares `format`
- `src/extend/serve.rs` declares `decide`
- `src/extend/state.rs` declares `process`
- `src/extend/state.rs` declares `rate`
- `src/extend.rs` declares `client`
- `src/extend.rs` declares `codec`
- `src/extend.rs` declares `descriptor`
- `src/extend.rs` declares `log`
- `src/extend.rs` declares `serve`
- `src/extend.rs` declares `server`
- `src/extend.rs` declares `state`
- `src/extend.rs` declares `tests`
- `src/hook.rs` declares `envelope`
- `src/hook.rs` declares `json`
- `src/hook.rs` declares `paths`
- `src/hook.rs` declares `scanner`
- `src/lib.rs` declares `sys`
- `src/lib.rs` declares `auth`
- `src/lib.rs` declares `base64`
- `src/lib.rs` declares `cli`
- `src/lib.rs` declares `cli_process`
- `src/lib.rs` declares `diagnostics`
- `src/lib.rs` declares `dispatch`
- `src/lib.rs` declares `engine`
- `src/lib.rs` declares `extend`
- `src/lib.rs` declares `hook`
- `src/lib.rs` declares `plugins`
- `src/lib.rs` declares `timing`
- `src/lib.rs` declares `deadline`
- `src/plugins.rs` declares `antigravity`
- `src/plugins.rs` declares `powershell_auto`
- `src/plugins.rs` declares `verdict`
- `src/sys/mod.rs` declares `windows`
- `src/sys/windows.rs` declares `encoding`
- `src/sys/windows.rs` declares `rng`
- `src/sys/windows.rs` declares `test_api`

## Cross-module references (file -> crate modules named)

- `src/auth.rs` -> `engine`, `extend`, `sys`
- `src/auth/console.rs` -> `cli_process`, `sys`
- `src/auth/desktop.rs` -> `sys`
- `src/auth/hello.rs` -> `sys`
- `src/auth/hello/operation.rs` -> `cli_process`, `sys`
- `src/auth/names.rs` -> `sys`
- `src/auth/password_budget.rs` -> `sys`
- `src/auth/password_budget/tests.rs` -> `extend`, `sys`
- `src/auth/refusal.rs` -> `sys`
- `src/auth/secrets.rs` -> `sys`
- `src/auth/tests.rs` -> `engine`, `extend`, `sys`, `test_temp`
- `src/auth/verify.rs` -> `cli_process`, `sys`
- `src/cli.rs` -> `auth`, `base64`, `cli_process`, `deadline`, `engine`, `extend`
- `src/cli/auto.rs` -> `base64`, `cli_process`, `engine`
- `src/cli/help.rs` -> `diagnostics`
- `src/cli_process.rs` -> `diagnostics`, `engine`, `sys`
- `src/cli_process/harden.rs` -> `sys`
- `src/cli_process/stdio.rs` -> `sys`
- `src/diagnostics.rs` -> `cli_process`, `engine`, `sys`
- `src/dispatch.rs` -> `plugins`, `sys`
- `src/engine.rs` -> `auth`, `cli_process`, `extend`, `sys`, `timing`
- `src/engine/attributes.rs` -> `sys`
- `src/engine/environment.rs` -> `sys`
- `src/engine/owners.rs` -> `sys`
- `src/engine/resolve.rs` -> `cli_process`
- `src/engine/tests.rs` -> `diagnostics`, `sys`, `test_temp`
- `src/engine/trace.rs` -> `cli_process`
- `src/engine/wait.rs` -> `diagnostics`, `sys`
- `src/extend.rs` -> `auth`, `engine`, `sys`
- `src/extend/client.rs` -> `cli_process`, `sys`
- `src/extend/descriptor.rs` -> `sys`
- `src/extend/log.rs` -> `cli_process`, `sys`
- `src/extend/serve.rs` -> `cli_process`, `sys`
- `src/extend/serve/decide.rs` -> `sys`
- `src/extend/server.rs` -> `cli_process`, `sys`
- `src/extend/state.rs` -> `engine`, `sys`
- `src/extend/state/process.rs` -> `sys`
- `src/extend/tests.rs` -> `sys`, `test_temp`
- `src/hook.rs` -> `cli_process`
- `src/hook/envelope.rs` -> `base64`
- `src/hook/paths.rs` -> `cli_process`, `sys`
- `src/lib.rs` -> `base64`, `cli`, `cli_process`, `deadline`, `diagnostics`, `dispatch`, `engine`, `extend`, `plugins`
- `src/plugins.rs` -> `base64`, `cli`, `cli_process`, `diagnostics`, `hook`
- `src/plugins/antigravity.rs` -> `base64`, `cli_process`
- `src/plugins/powershell_auto.rs` -> `base64`, `cli_process`
- `src/plugins/verdict.rs` -> `cli_process`, `hook`
- `src/timing.rs` -> `diagnostics`, `engine`, `sys`

## The sys fan-in

274 direct sys call sites in 27 production files:

- `src/auth.rs` -> 8 direct sys call sites
- `src/auth/console.rs` -> 9 direct sys call sites
- `src/auth/desktop.rs` -> 4 direct sys call sites
- `src/auth/hello.rs` -> 4 direct sys call sites
- `src/auth/hello/operation.rs` -> 4 direct sys call sites
- `src/auth/names.rs` -> 2 direct sys call sites
- `src/auth/password_budget.rs` -> 6 direct sys call sites
- `src/auth/refusal.rs` -> 2 direct sys call sites
- `src/auth/secrets.rs` -> 1 direct sys call sites
- `src/auth/verify.rs` -> 1 direct sys call sites
- `src/cli_process.rs` -> 22 direct sys call sites
- `src/cli_process/harden.rs` -> 8 direct sys call sites
- `src/cli_process/stdio.rs` -> 15 direct sys call sites
- `src/diagnostics.rs` -> 4 direct sys call sites
- `src/engine.rs` -> 16 direct sys call sites
- `src/engine/attributes.rs` -> 7 direct sys call sites
- `src/engine/owners.rs` -> 37 direct sys call sites
- `src/engine/wait.rs` -> 21 direct sys call sites
- `src/extend.rs` -> 2 direct sys call sites
- `src/extend/client.rs` -> 13 direct sys call sites
- `src/extend/descriptor.rs` -> 15 direct sys call sites
- `src/extend/log.rs` -> 7 direct sys call sites
- `src/extend/serve.rs` -> 36 direct sys call sites
- `src/extend/serve/decide.rs` -> 3 direct sys call sites
- `src/extend/server.rs` -> 10 direct sys call sites
- `src/extend/state/process.rs` -> 9 direct sys call sites
- `src/timing.rs` -> 8 direct sys call sites

Production files with no direct sys call that still reference `sys`,
each with the reason the computation gives for it:

- `src/bin/process-tree-guard-contain.rs` — uses the wrapper `cli_exit`, which itself reaches `sys` where it is defined (in `src/diagnostics.rs`) — recorded as an entry shim: the file exists only to call the process-owning boundary (`cli_exit` in `src/diagnostics.rs`)
- `src/bin/process-tree-guard-deadline.rs` — uses the wrapper `cli_exit`, which itself reaches `sys` where it is defined (in `src/diagnostics.rs`) — recorded as an entry shim: the file exists only to call the process-owning boundary (`cli_exit` in `src/diagnostics.rs`)
- `src/bin/process-tree-guard-gate.rs` — uses the wrapper `cli_exit`, which itself reaches `sys` where it is defined (in `src/diagnostics.rs`) — recorded as an entry shim: the file exists only to call the process-owning boundary (`cli_exit` in `src/diagnostics.rs`)
- `src/bin/ptg.rs` — uses the wrapper `cli_exit`, which itself reaches `sys` where it is defined (in `src/diagnostics.rs`)
- `src/cli.rs` — uses the wrapper `write_stdout_line`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`)
- `src/cli/auto.rs` — uses the wrapper `ParentFacts::open`, which itself reaches `sys` where it is defined (in `src/engine/owners.rs`); uses the wrapper `ParentFacts (wrapper type)`, which itself reaches `sys` where it is defined (in `src/engine/owners.rs`)
- `src/dispatch.rs` — names a `sys::` path or a `crate::sys` import; names the sys-declared name(s) `image_name_units`
- `src/engine/environment.rs` — names a `sys::` path or a `crate::sys` import
- `src/extend/state.rs` — names a `sys::` path or a `crate::sys` import; names the sys-declared name(s) `Handle`; uses the wrapper `Process::alive`, which itself reaches `sys` where it is defined (in `src/extend/state/process.rs`); uses the wrapper `Log (wrapper type)`, which itself reaches `sys` where it is defined (in `src/extend/log.rs`); uses the wrapper `Process (wrapper type)`, which itself reaches `sys` where it is defined (in `src/extend/state/process.rs`) — recorded mechanism-adjacent, not pure: the extendable run's state machine, keyed on the `Handle` type `sys` declares
- `src/extend/state/rate.rs` — uses the wrapper `Process::open`, which itself reaches `sys` where it is defined (in `src/extend/state/process.rs`); uses the wrapper `Process::alive`, which itself reaches `sys` where it is defined (in `src/extend/state/process.rs`); uses the wrapper `Process (wrapper type)`, which itself reaches `sys` where it is defined (in `src/extend/state/process.rs`) — recorded mechanism-adjacent beside `src/extend/state.rs`, not pure: the state machine's other half, whose liveness oracle opens live process handles through `Process::open` and waits on them through its `alive` method
- `src/hook.rs` — uses the wrapper `write_stdout_line`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`)
- `src/hook/envelope.rs` — uses the wrapper `stack_self_path`, which itself reaches `sys` where it is defined (in `src/hook/paths.rs`); uses the wrapper `scan_verdict (generic parameter instantiated with StandardInput)`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`)
- `src/hook/paths.rs` — names a `sys::` path or a `crate::sys` import; names the sys-declared name(s) `image_name_units`; uses the wrapper `read_file_bytes`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`); uses the wrapper `drive`, which itself reaches `sys` where it is defined (in `src/auth/hello/operation.rs`); uses the wrapper `drive`, which itself reaches `sys` where it is defined (in `src/auth/hello/operation.rs`)
- `src/lib.rs` — uses the wrapper `Gate (wrapper type)`, which itself reaches `sys` where it is defined (in `src/extend/serve.rs`)
- `src/main.rs` — uses the wrapper `cli_exit`, which itself reaches `sys` where it is defined (in `src/diagnostics.rs`) — recorded as an entry shim: the file exists only to call the process-owning boundary (`cli_exit` in `src/diagnostics.rs`)
- `src/plugins.rs` — uses the wrapper `write_stderr_line`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`)
- `src/plugins/antigravity.rs` — uses the wrapper `standard_input`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`); uses the wrapper `stack_self_path`, which itself reaches `sys` where it is defined (in `src/hook/paths.rs`); uses the wrapper `antigravity_scan (generic parameter instantiated with StandardInput)`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`)
- `src/plugins/powershell_auto.rs` — uses the wrapper `try_write_stdout_line`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`); uses the wrapper `write_stderr_line`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`); uses the wrapper `standard_input`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`); uses the wrapper `stack_self_path`, which itself reaches `sys` where it is defined (in `src/hook/paths.rs`); uses the wrapper `powershell_payload_facts (generic parameter instantiated with StandardInput)`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`)
- `src/plugins/verdict.rs` — uses the wrapper `standard_input`, which itself reaches `sys` where it is defined (in `src/cli_process/stdio.rs`)

The remaining 12 production files contain no sys reference
of any kind — no `sys::` path, no `crate::sys` import, no whole-word
naming of any of the 277 names `sys` declares outside
the 2 recorded exclusions (judged by occurrence: a
`slot` call shape and a bare `Bool` outside `src/hook/json.rs` are
never exempt), and no one-hop use of a wrapper that itself reaches
`sys` (every production function and method in the crate whose own
body names a `sys::` path, calls a declared extern name unqualified,
or names an extended-mint item, or whose item text carries a `slot`
call shape or a bare `Bool`) — where a free wrapper is used by call
or by name as a value, a method wrapper is used by its defining
type's associated path or by a receiver call whose receiver's type
is determinable from declared types, resolved to a fixed point (a
parameter typed `Type`/`&Type`/`&mut Type`, a `Self` receiver inside
`impl Type`, or a binding annotated with the type — a pattern
binding destructuring a determinable declared type binds each
variable with its position's declared type; a field receiver
through the field's declared type in its defining struct; a chained
receiver through the inner callee's declared return type; an
unannotated binding initialised by such a call or field access —
multi-hop fields and chains fall out of the iteration), a wrapper
type — a type carrying any derived wrapper method, constructors and
`Drop` included, the set closed under by-value field containment
(a type owning a wrapper type by value in a field, transitively,
is itself one; reference and pointer fields do not contain) and
under production type aliases (an alias in whose target a wrapper
type occurs by value anywhere is one, its home the alias's file) — is used by being
named whole-word in type position, in an associated path with any
method name, or in a value construction (a type the file itself
defines — where Rust's own scoping makes the definition the
name's meaning: the use's own scope, an ancestor module the
intervening modules import it from, or the file's own `use` of
an item from a descendant or sibling scope, the self-defined
exclusions being computed under that scoping for types and
names alike — and a same-named enum variant path, are not the
type), and a by-value generic parameter a file owns to a scope
exit is used where any production instantiation of its item —
supply computed to a fixed point through generic-to-generic
hops — supplies a wrapper type,
computed at the call sites with the same machinery.
Use statements yield per-scope rename maps, and every arm
resolves a spelled local name through its scope's map before
lookup; const and static items whose initialiser is a wrapper
path are wrapper values, and naming one is a wrapper use;
receiver resolution takes a Deref step and binds `for` loop
variables and closure parameters from the declared types that
bind them; and name supply is textual and local to each
file — `sys` names reach a file only through its own
`crate::sys` import list, tied below to this census. The
recorded limit of the computation: a receiver call whose
receiver's type arrives through a generic parameter, a trait
object, or an expression with no declared type in the crate
is not counted as a wrapper use, and neither is a bare name
with more than one production definition.
Glob bindings yield rename entries — a scope that
glob-imports a module gains entries for the names that module
exports, its re-export renames included, a name two glob
sources export with different identities yielding none; the
std-platform channel below is censused by resolution, not by
spelling; and the re-export chase is bounded — 8 re-export
hops, 16 module-path variants — and fails closed by name past
the bound, the bound and the deepest live chain (2 hops)
recorded in src/lib.rs and in D43. The chase's variant record
condition may not be suppressed by renaming — exhaustion in
a chase whose top-level resolution fails records a named
refusal when the spelled final segment is any production
binding local (a definition name, a wrapper value, or a use
binding's local name, renamed re-exports included), while
exhaustion inside a chase another frame completes records
nothing; resolution is root-confined — a candidate from
another crate's root never satisfies a path, and the chase
runs in the root that owns the path; extern declarations
outside src/sys/windows.rs and the recorded testkit mirror are censused
in their own right, a pure file declaring any extern fn
being named as a platform reach; glob roots join the
std-platform resolution census, and that census follows
re-exports to the definition, a name whose definition is a
std-platform item being censused at every use site; wrapper
values are derived from every expression position that
yields the wrapper, array and table elements included; and
arch paths (std::arch, core::arch, and their re-export
spellings) join the censused platform channels for pure
files, recorded below.
Sys items are derivation sources — a production alias or
const/static whose target or initialiser resolves into sys
joins the census universe as a sys-derived name, and naming
one is named; trait default methods are method wrappers of
their trait, reached through the receivers of types that
implement it; the platform chase expands re-exported module
segments within the recorded bounds; the channel censuses'
bare-name arm follows glob bindings; a one-segment root
bound to the std or core crate itself joins the censused
roots; the receiver fixed point unwraps ?-bindings; the
own-extern census extracts every extern item, fns and
statics alike; functions whose return expression yields a
wrapper are wrapper-yielding, like consts; the chase's
module map honours #[path] — a file's declared module path
is a candidate home for its items; and the macro channel
stands in the include! idiom — a macro defined outside sys
whose expansion reaches a wrapper or sys item, invoked from
a pinned file, is named as an unmodelled channel, refused
for the pure set.
The yield derivation runs over methods as the criterion's
text names them — a method whose return expression yields a
wrapper is wrapper-yielding, and a call through its return
is a wrapper use; a trait default method supplied by a
blanket impl is keyed by the impl's trait, not by the
spelled generic parameter's name, so a receiver call on any
determinable receiver type reaches it; a wrapper carried in
a struct field at construction is yielded for that field,
and a call through the field's projection is a use; a
returned closure whose body reaches a wrapper is a yield
attached to its defining item; both value closures follow
calls in initialiser position — a holder whose initialiser
calls a sys-reaching const fn derives from the callee's
returned value, in the plain-const and associated-const
forms alike; the module map is built from declarations — an
inline module is a candidate home at its path in both
chases, and a file's binding reads are scoped to the module
that declares the binding; the macro census reads sys's own
macro definitions; re-export bindings that rename a sys
item are derivation sources in the mint, the sys-derived
closure and the chase; and a production module declaration
whose resolved target file is absent from the tree is
refused by name in the include! idiom.
Function scopes are homes — an inline module declared
inside a function body is a candidate home scoped to that
body, and a call through its local path resolves as a
module-path call; both value closures follow initialiser
calls through associated functions and methods as through
free functions, the callee's body read from the method
tables; carriage runs over tuple constructions as over
literals, a positional argument carrying its wrapper at its
index, and a variant literal is keyed by the enum it
denotes; the yield derivation runs over trait default
methods, keyed by (trait, method); macro expansions are
read as items of the invocation site — the expansion's use
bindings and function definitions stand in the invoking
file's tables, for macros defined in sys and
#[macro_export] macros; #[path] on an inline module
resolves relative to the declaring file's directory in the
production definition, the declared-path map and the
missing-target census alike; and the field initialiser's
judgement extends through constructor calls, a field
initialised by a call carrying what its wrapper or
wrapper-reaching closure argument denotes.
Both value closures resolve an initialiser call's callee
type through production type aliases to its defining type;
the carriage derivation reads field-init shorthand as the
explicit initialiser its same-named let binding denotes;
field carriage follows a value through a method chain,
every call in the chain judged as a constructor call is
judged; the field initialiser's judgement reads a call's
RESULT as it reads its arguments — a field initialised by a
wrapper-yielding call, free or trait-path spelled, carries
the yielded wrapper; the use arms count a wrapper-denoting
value bound to a local and then called, by its bound field
projection or its bound yield return; the pattern-carried
arm reads destructuring function parameters and closure
parameters as it reads let and match patterns; the
qualified-path yield arm and its sibling yield arms read
through the grouping parentheses Rust permits around a
call; trait-yield and trait-wrapper attribution reads the
receiver type's own impl — where the impl defines the
method, the item judged is the override and its own yield
or wrapper derivation, and the default is attributed only
to types whose impl leaves it in place, in both directions;
blanket-impl attribution reads the blanket's bound against
the receiver type's own impls and a generic parameter's
signature bounds, under the satisfaction rule stated below;
a macro's expansion is a derivation input in expression
position as in item position — an invocation whose matching
arm's template is a single expression, in a const
initialiser or any derivation position, derives as the
expression it expands to, for production macros generally,
simple dollar-parameter substitution included (repetition
and token-tree patterns beyond that form are not read, the
recorded limit); a file module loaded by #[path] records
its subtree under its DECLARED path, in the declared-path
map and the type qualifications alike, so re-exports inside
its children are chaseable by the paths consumers spell;
and the use arms count projections of container-carried
fields — a call through a carried field's
value-preserving projection chain, the unwrap() chain and
the pattern-bound chain alike.
The trait-path result arm resolves the callee type through
production type aliases to its defining type, so an
override is judged by the defining type's own impl in both
directions; the carriage derivation reads field-init
shorthand fed by a destructuring let binding as the
projection of the destructured value it denotes; field
carriage follows a value through a method chain across a
`?` in the chain; the field result judgement reads
receiver-spelled method callees, a wrapper-yielding method
called on a value whose type its const or static
declaration spells; the bound-local arm counts container
projections of bound values — an `unwrap()` or a `?`
applied before the binding — and a bound value returned by
its item whose result is called through in the file; the
pattern-carried arm reads `for` patterns as it reads let
and match patterns; the bound-local arm reads through
grouping parentheses around the projection; the macro
expression arm applies its template rule at the depth it
states — a statement separator at nested depth does not
reject a block-expression template; the module map follows
the compiler's resolution for `#[path]` — a `#[path]` value
on a declaration resolves relative to the directory
containing the declaring file, and the children of a file
loaded by `#[path]` resolve beside the file itself, so a
subtree stands chaseable at the placement rustc accepts, a
placement rustc rejects is never the model, and a
declaration whose compiler-resolved target stands in no
file list is refused by name; the item slicer tracks
bracket depth as it tracks parenthesis depth, and reads a
const-generic brace in a signature as an argument, not a
body, so bracketed and braced signature shapes do not blind
it; blanket satisfaction is keyed on the parameter's
identity, not its spelled name — a blanket impl records no
impl under its parameter's name, and a bound is satisfied
where it stands among the receiver type's own impls, among
a generic parameter's signature bounds, or is supplied to
either through a supertrait chain or another blanket impl,
the recorded limit standing at this boundary: a bound
satisfied only through another parameter's bound is not
read; and field carriage reads array-literal initialisers
as it reads scalar ones.
The use-side receiver typing reads the payload step — an
`unwrap()`, `expect()` or `as_ref()` on a determinable
`Result`/`Option` receiver, and the direct `?` chain,
resolve to the payload type, as the `?`-binding fixed point
and the bound-local strip read it; a generic-instantiated
receiver identity is normalised to its defining type in the
field arms and every sibling arm keyed on bare type
identity; the bound-local arm reads a trailing index suffix
as it reads `unwrap()` / `?`, with the variable-index,
array-pattern-binding and field-of-index forms; the
shorthand judgement reads nested subpatterns, the
variable's projection path composed stepwise; the
returned-bound-value step reads tuple-packaged and closure
returns, and the field judgement reads an invoked-closure
initialiser; and the nested-`;` block-expression macro
template derives in fact, the const value closures reading
it as the other derivation positions do.
Carriage reads a turbofish head — a struct literal or tuple
construction spelled `Type::<args>` is keyed by the head it
stands on; a field's declared type is read through the
instantiation that supplies it, the instantiation's
arguments substituted for its defining type's parameters,
position for position; the associated-path arms read a
turbofish segment standing in a spelled path, as every
sibling arm that segments a spelled path on `::` does; the
bound-local strip reads a trailing `expect(...)` as it
reads `unwrap()`; the returned-bound-value step reads tuple
packaging to the depth the caller's destructure reaches,
the pattern the guide; the const/static capture reads the
item head at its full breadth — `static mut` included, and
a declared type read to its depth-zero `=`, as the
initialiser is read to its depth-zero `;`, and a field
initialised from an element of such a value carries the
value's wrapper, the index step the bound-local strip
reads; a signature's return type ends at a depth-zero
`where` clause; and the payload step reads `unwrap`,
`expect`, `as_ref`, `as_mut`, `ok` and `?` on the ground
stated with the full enumeration below: each such step is
declared on the container and exposes the payload the
container holds — the payload itself, a reference to it,
or, for `ok`, the same payload under the sibling container
— while `Clone` is declared on the payload, not on any
container, and its return is a second value of the
receiver's own type, made by copying, not the held payload
exposed; a step through a method the crate does not declare
that is not in the payload enumeration is not read, the
standard library's `Clone` the standing instance.
A field's declared type is read through the instantiation
that supplies it with the substitution made simultaneous —
one pass over the declared text, each parameter token
replaced by its argument exactly once, an inserted argument
never rescanned, so no later parameter can capture it; the
arms that segment a spelled path on `::` read a turbofish
segment standing on the construction they bind — the
receiver fixed point's bare-name binding arm reads such a
segment on the construction it binds, the construction arms
judging a construction as a naming event and never typing
the binding it initialises, `_expr_yields_wrapper` strips
the segment as `_yielded_wrapper` does, and the
generic-supply spelled-callee arm reads a segment standing
on the type or on the method; the bound-local strip reads
the enumeration's own steps — `ok()`, `as_ref()` and
`as_mut()` beside `expect(...)` and the rest of the
enumeration that can stand in bound-local position, the
balanced-paren head check generalised past `.expect`; the
returned-bound-value step judges a tuple element that is
itself a field projection by the projection arms, at every
packaging depth the caller's destructure reaches — nested
tuples, and a projection packaged inside a container
constructor such as `Ok(...)`, whose single argument stands
at the path the destructure reaches after its payload step
— the judgement recorded from the callee's own file and
made in the caller's, so the helper's home file no longer
bounds it; and the payload step's enumeration also reads
`copied`, `cloned`, `as_deref`, `as_deref_mut`,
`transpose`, `unwrap_or`, `unwrap_or_else` and
`unwrap_or_default`. The rationale is what the step does to
the value it stands on, judged by the receiver it stands
on: every read step is declared on the container itself —
on `Result` or `Option` — and its result carries the
payload the container holds: the payload itself (`unwrap`,
`expect`, `?`, and the `unwrap_or` family, whose result is
the payload on the branch where the container holds one), a
reference to it (`as_ref`, `as_mut`), a reference to what
the payload itself dereferences to (`as_deref`,
`as_deref_mut`), the payload made by copying it out of the
reference the container holds (`copied`, `cloned`), or the
same payload under the sibling container (`ok`;
`transpose`, the containers swapped). The closure steps
`map` and `and_then` are read in the closure arm on the
same ground: each hands the held payload to its closure as
the closure's parameter. `Clone` is not read, and the
separation is the receiver: `Clone` is declared on the
payload itself — on whatever value type implements it,
container or not — and stands on no container; its return
is a second value of the receiver's own type, and no
container is opened by it. `copied` and `cloned` make their
copies by the same copying, but they are declared on the
container and open it, and that is the clause that governs:
a step read here stands on a `Result` or `Option` receiver
and carries its held payload out; a step whose receiver is
the payload itself does not. A step through a method the
crate does not declare that is not in the enumeration is
not read, and the standard library's `Clone` is the
standing instance.
The payload step's enumeration also reads its next ring —
the sibling-container steps `ok_or`, `ok_or_else`, `or`,
`or_else`, `and` and `zip`, the payload-preserving and
payload-extracting steps `map_err`, `flatten`, `take`,
`replace` and `get_or_insert`, the closure steps
`is_some_and`, `is_ok_and`, `map_or` and `map_or_else`, and
`clone` on a container receiver — each guarded by the
container head itself, so `Clone` on a payload receiver
stands unread as before, the separation now the receiver
the computation itself types; the iterator-consumer arm's
membership stands named where the closure steps are named —
`any`, `all`, `for_each`, `find`, `find_map`, `position`,
`fold`, `inspect`, `map`, `filter`, `filter_map`,
`flat_map` and `map_while`; the bound-local strip reads the
same ring in bound-local position and a turbofish segment
standing on a step's head, its head check placed in the
sibling enumeration's fixed class; the carriage derivation
records every wrapper-carrying field of a construction —
the declaration split reads a function pointer's arrow as
two neutral characters, so no field stands dropped by its
position after such a field; the return-projection walk
reads array and `vec!` element packagings at their index
paths and struct-literal field packagings at their field
paths; and the return-projection table is keyed by the
item's identity — defining file and name — the caller-side
arm judging the call it resolves, a bare name with more than
one production definition refusing by name in the
recorded-limit idiom rather than merging.
`and` is read at the argument's container and `zip`'s pair
at both elements, the whole result payload standing as `()`
for `and` and the second element as `()` for `zip` only
where an argument's container text is not determinable at a
call; `xor` and `insert` are read, `err` and
`unwrap_err`/`expect_err` at the error payload, and the
error payload's closure steps — `is_err_and`,
`inspect_err`, `map_err`'s own closure, and the error
closures of `or_else`, `unwrap_or_else` and `map_or_else`
— beside the success side's, with `is_none_or` beside
`is_some_and` and `get_or_insert_with` named as
`get_or_insert`'s twin; the declaration split reads a
comparison or shift `>` inside const-generic braces or a
parenthesised group as no angle close; the direct caller
arm follows the tuple step `.<idx>`, so mixed packaging
paths judge as their pattern equivalents do; the
return-projection key carries the item's module path within
its defining file and, for a method, its impl kind; and a
bare call shadowed by a scoped `use` import is resolved to
the import's target or refused by name.
The `and`/`zip` record is computed, not read — the callee's
type parameters are replaced by the call's actual arguments
(the turbofish where it stands, otherwise inferred from the
argument expressions' own types), and the constructor arm
reads turbofish spellings; the payload ring stands closed
against a mechanical census of `Option`'s and `Result`'s
stable combinator surface at this toolchain, `take_if`,
`get_or_insert_default` and `as_slice` read at their
payloads' breadths and the census's exclusions named beside
it; the pattern arm composes through the packaging steps
that remain on a pattern-bound local; the impl kind carries
the trait's module path, and a blanket impl is resolved to
its bound's concrete types or refused by name; and a
wrapper standing directly as a returned tuple or array
element is recorded at its element path, the walk running
on that ground even where no field carries.
Judged on
production code with comments and literal
contents blanked, so a name mentioned in prose is not a
reference. The pinned pure set is exactly those files:

- `src/auth/hello/text.rs`
- `src/auth/message.rs`
- `src/base64.rs`
- `src/cli/help.rs`
- `src/deadline.rs`
- `src/engine/resolve.rs`
- `src/engine/trace.rs`
- `src/extend/codec.rs`
- `src/extend/log/audit.rs`
- `src/extend/log/format.rs`
- `src/hook/json.rs`
- `src/hook/scanner.rs`

D45's judged set is recorded here as its second home: the
(struct, field) pairs of `src/sys/windows.rs` the shape
rule judges pointer-carrying on their own homes' evidence. D45's
check compares its own pin against this list on every run, so a
pair retires only by coordinated visible edits in both records —
the pin in D45's section and this list, regenerated from the
generator's record:

- `AssociateCompletionPort.key`
- `AssociateCompletionPort.port`
- `BasicLimitInformation.affinity`
- `BasicLimitInformation.maximum_working_set_size`
- `BasicLimitInformation.minimum_working_set_size`
- `Com.0`
- `ConsoleApi.expunge`
- `ConsoleApi.handler`
- `ConsoleApi.prompt`
- `CredUiInfoW.banner`
- `CredUiInfoW.caption`
- `CredUiInfoW.message`
- `CredUiInfoW.parent`
- `DesktopApi.free`
- `DesktopApi.prompt`
- `DesktopApi.protected`
- `DesktopApi.unpack`
- `DesktopApi.unprotect`
- `ExtendedLimitInformation.job_memory_limit`
- `ExtendedLimitInformation.peak_job_memory_used`
- `ExtendedLimitInformation.peak_process_memory_used`
- `ExtendedLimitInformation.process_memory_limit`
- `HString.delete`
- `HString.raw`
- `HelloApi.create`
- `HelloApi.delete`
- `HelloApi.factory`
- `HelloApi.initialize`
- `HelloApi.uninitialize`
- `LogonApi.logon`
- `LogonApi.lookup`
- `Msg.l`
- `Msg.w`
- `Msg.window`
- `NameApi.name`
- `Overlapped.event`
- `Overlapped.internal`
- `Overlapped.internal_high`
- `ProcessBasicInformation.affinity`
- `ProcessBasicInformation.parent_process_id`
- `ProcessBasicInformation.peb`
- `ProcessBasicInformation.unique_process_id`
- `ProcessEntry32W.default_heap_id`
- `ProcessInformation.process`
- `ProcessInformation.thread`
- `SecurityAttributes.descriptor`
- `StartupInfoExW.attribute_list`
- `StartupInfoW.desktop`
- `StartupInfoW.reserved`
- `StartupInfoW.reserved2`
- `StartupInfoW.std_error`
- `StartupInfoW.std_input`
- `StartupInfoW.std_output`
- `StartupInfoW.title`
- `WindowApi.create`
- `WindowApi.default_procedure`
- `WindowApi.destroy`
- `WindowApi.dispatch`
- `WindowApi.peek`
- `WindowApi.register`
- `WindowApi.unregister`
- `WindowApi.wait`
- `WindowStationApi.close_desktop`
- `WindowStationApi.information`
- `WindowStationApi.input_desktop`
- `WindowStationApi.station`
- `WindowStationApi.thread_desktop`
- `WndClassExW.background`
- `WndClassExW.class_name`
- `WndClassExW.cursor`
- `WndClassExW.icon`
- `WndClassExW.icon_small`
- `WndClassExW.instance`
- `WndClassExW.menu`
- `WndClassExW.procedure`
- `WtsApi.free`
- `WtsApi.query`

The pinned pure set is recorded in `tools/design-gate.sh` (D43),
which recomputes this set's facts and fails while its recorded set
differs from the set computed here: a pinned file gaining a sys
reference fails the gate and must win its argument explicitly, and
the two records cannot drift silently. The tie is stated honestly:
it ties two RECORDS (this computation and D43's recomputation), not
two independent computations — gate and generator share the one
comment/literal lexer, so a lexer bug would corrupt both at once
and the tie could not catch it. The lexer's correctness rests on
the pinned test corpus inside D43 (raw strings with embedded
quotes, raw byte strings, raw C strings, plain C strings, byte
strings, char literals against lifetimes, nested block comments,
and negative fixtures), not on the tie. The macro channel stands
in the refusal idiom: a macro defined outside sys whose expansion
reaches a wrapper or sys item, invoked from a pinned file, is
named as an unmodelled channel and refused for the pure set —
the tree contains no `macro_rules!` anywhere today, so the
channel has no live instance. The census also reads sys's own
macro definitions, so a macro defined in src/sys/windows.rs itself
stands in the table beside the production ones.
The built-in inclusion channel beside it is not a note but a
refusal: production `include!` is
refused by name in this census and in D43 — included text stands
in no file list this computation walks, so no census can see it;
`include_str!` and `include_bytes!` splice data, not code, and
stand outside the refusal. The tree carries no production
`include!` today.

The std-platform channel is censused
per file beside the sys channels: production `std::os::<platform>`
paths — spelled absolutely, or through a root the file's own
imports bind to `std::os` or a deeper `std::os::<platform>` prefix
(a glob root included), or through a
crate re-export of the platform item itself, the census
being by resolution — stand
in exactly these production files:

No occurrence was recorded in this production census scope.

No std-platform occurrence was recorded in the computed pure set.

The arch channel is censused per file
beside it: production `std::arch::…` and `core::arch::…` paths —
spelled absolutely, through a root bound to `std::arch` or
`core::arch`, through a glob root, or through a crate re-export
— stand in exactly these production files:


Inside the pure set the channel stands only as its pinned
occurrences (the empty set): the tree carries no production arch
path today, and any arch occurrence in a pinned file fails by
name in D43.

Extern declarations are censused in
their own right beside the channels above: a production file
outside `src/sys/windows.rs` and the recorded testkit mirror that
declares an extern item — fn, static or type — in its own
extern block reaches the
platform through its own declaration and is named where it
stands — no such declaration stands in a member of the pinned
pure set today.

Name supply is textual and local to
each file: the `crate::sys::*` glob roots are removed, and every
production file imports the sys names it uses from `crate::sys`
explicitly, in that file — the rename maps are
read from the same headers. D43 ties each file's import list to
the set of sys names this census records for it:

- 28 production files carry a `crate::sys` import list, 413 names in all, each list the census set of its file.

D45's repr record: the structural
census of `src/sys/windows.rs` records each censused struct's attributes
beside its fields; the structs standing with `#[repr(C)]` are:

- `AssociateCompletionPort`
- `BasicAccountingInformation`
- `BasicLimitInformation`
- `CredUiInfoW`
- `ExtendedLimitInformation`
- `Guid`
- `IoCounters`
- `Msg`
- `Overlapped`
- `ProcessBasicInformation`
- `ProcessEntry32W`
- `ProcessIdInformation`
- `ProcessInformation`
- `SecurityAttributes`
- `StartupInfoExW`
- `StartupInfoW`
- `UserObjectFlags`
- `WndClassExW`

The remaining censused structs stand recorded in D45 as the
non-repr exceptions (the `*Api` tables, `Com`, `HString`); a
repr-carrying struct losing `#[repr(C)]` fails by name in D45.
