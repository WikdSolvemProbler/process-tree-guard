# Shared numeric deadline qualification

The minimal source change shares the existing finite positive deadline
bound and leaves parsing, diagnostics, and platform enforcement at their
existing entry points. The previous larger extraction remains a separate
prototype.

Matched Windows x64 MSVC release builds of 6e46bbf and candidate 002 had
the same code and runtime data. The 20 differing positions were confined
to parsed PE timestamps and the PDB GUID. Exact field normalization and
build receipts are preserved. This is build equivalence for this target
and toolchain. Performance timing and ARM64 binary equivalence are
outside this check.

The exact standalone deadline module passed two tests each on Linux
ARM64 and physical macOS ARM64. The same module bytes are in candidate
002. Exact candidate 002 retained the intentional unsupported-backend
build refusal on both hosts. Tailscale tests were bounded and followed
by independent scope, process-group, and scratch checks.

The unchanged historical generator ran the complete dependency census
using reconciled baseline and candidate layouts. Its raw results are
included. The separate renderer changes two prose sections while keeping
all mechanical tables and pure-set results. The historical design gate
still needs reconciliation of its embedded occurrence pins.
