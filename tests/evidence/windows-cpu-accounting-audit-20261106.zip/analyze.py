from collections import Counter
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

archive, source = map(Path, sys.argv[1:])
digest = sha256(archive.read_bytes()).hexdigest()
if digest != "ef653c4fb2921adc9e466f767225ba257b26e0b9adecf354b8000f30ccf751bd":
    sys.exit("Unexpected capture archive")
with ZipFile(archive) as bundle:
    manifest = json.loads(bundle.read("evidence-index.json"))
    if manifest["harness_commit"] != "8cafa1e11d2925f51560d6d8fff6261e685027f2":
        sys.exit("Unexpected historical harness")
    observations = bundle.read("complete/observations.jsonl")
    expected = manifest["entries"]["complete/observations.jsonl"]
    if len(observations) != expected["bytes"] or sha256(observations).hexdigest() != expected["sha256"]:
        sys.exit("Observation identity mismatch")
    archived_report = bundle.read("complete/report.txt").decode("utf-8")

quantum = Decimal("15.625")
exact = [json.loads(line, parse_float=Decimal) for line in observations.splitlines()]
histograms = {}
for record in exact:
    value = record.get("cpu_ms")
    if value is None:
        name = "null" if "cpu_ms" in record else "missing"
    elif type(value) not in (int, Decimal) or not Decimal(value).is_finite() or value < 0:
        name = "invalid"
    elif Decimal(value) % quantum:
        name = "off_grid"
    else:
        name = str(int(Decimal(value) / quantum))
    histograms.setdefault(record["kind"], Counter())[name] += 1

sys.path.insert(0, str((source / "tests/campaign").resolve()))
import report

rows = [json.loads(line) for line in observations.splitlines()]
def evaluate(records):
    losses, unpaired, compared, failed = report._paired_cost_comparison_detail(records)
    cpu = [{"comparison": name, "failing_ranks": count}
           for name, count in failed if " on cpu_ms in " in name]
    if len(cpu) != sum(" on cpu_ms in " in line for line in losses):
        sys.exit("Unexpected historical CPU detail schema")
    return {
        "cpu_failing_comparisons": len(cpu),
        "cpu_failing_ranks": sum(item["failing_ranks"] for item in cpu),
        "cpu_failed_cells": cpu,
        "other_failures": [line for line in losses if " on cpu_ms in " not in line],
        "unpaired": unpaired,
        "comparisons_reported": len(compared),
    }

original = evaluate(rows)
if (original["cpu_failing_comparisons"], original["cpu_failing_ranks"]) != (30, 77):
    sys.exit("Original CPU verdict did not reproduce")
if "30 failing unit" not in archived_report or "77 failing rank" not in archived_report:
    sys.exit("Archived report does not match the strict comparison")
scenarios = {}
for ticks in (1, 2):
    shift = float(quantum * ticks)
    adjusted = [
        dict(row, cpu_ms=row["cpu_ms"] + shift)
        if row["arm"] in ("processkit", "nuewframe", "sysprims")
        and type(row.get("cpu_ms")) in (int, float)
        else row
        for row in rows
    ]
    result = evaluate(adjusted)
    for key in ("unpaired", "other_failures", "comparisons_reported"):
        if result[key] != original[key]:
            sys.exit("Sensitivity calculation changed non-CPU criteria or coverage")
    scenarios[str(ticks)] = result

print(json.dumps({
    "scope": "Post-hoc arithmetic sensitivity. The allowances favor the guard and do not estimate counter error.",
    "archive_sha256": digest,
    "observations_sha256": expected["sha256"],
    "historical_harness_commit": manifest["harness_commit"],
    "historical_report_source_sha256": sha256(Path(report.__file__).read_bytes()).hexdigest(),
    "historical_campaign_status": "incomplete",
    "archived_cpu_gate": "FAIL",
    "stored_cpu_measurement": "arm process user plus kernel milliseconds",
    "grid_step_ms": str(quantum),
    "stored_cpu_histograms_ticks": histograms,
    "original_strict_comparison": original,
    "rival_only_allowance_ticks": scenarios,
}, indent=2, sort_keys=True))

