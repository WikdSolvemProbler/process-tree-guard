# Windows CPU accounting audit

The original 1,940-slot archive is windows-campaign-20261106.zip. Its SHA-256
and the observation and report source digests are in analysis-v2.json. The
original harness commit is 8cafa1e11d2925f51560d6d8fff6261e685027f2.

This offline audit parses the serialized aggregate arm-process CPU readings
with exact decimal arithmetic. It checks membership in the 15.625 ms grid,
including zero. The raw user and kernel components were not retained. The
grid describes the recorded values and supplies no accuracy or error bound.

The strict evaluation runs the original report helper, preserving its
planned populations and sorted-rank comparison. Each sensitivity scenario
adds one or two grid steps to the rival CPU values from the original capture.
Memory, missing values, coverage rules, and guard values stay fixed. These
post-hoc arithmetic allowances favor the guard. They are independent
scenarios and leave the historical CPU gate and incomplete campaign verdict
in place. The output lists the affected units and failing ranks for each.

To replay, stage a clean LF export of tests/campaign, tests/campaign.json,
and tests/usability-evidence.json from the original harness commit. Under a
finite whole-tree deadline run analyze-v2.py with the original ZIP path
and the export root. The first replay refused a mismatched literal report
phrase. Its script and error are preserved.
