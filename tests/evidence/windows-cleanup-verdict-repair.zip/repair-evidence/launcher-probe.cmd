@echo off
echo bounded-batch-probe
exit /b 0
