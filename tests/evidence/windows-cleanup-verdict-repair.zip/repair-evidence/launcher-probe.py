import json,pathlib,subprocess
here=pathlib.Path(__file__).resolve().parent
rows=[]
for cmd in ['C:/Windows/System32/cmd.exe',r'C:\Windows\System32\cmd.exe']:
 argv=[cmd,'/d','/c','call',str(here/'launcher-probe.cmd')]
 result=subprocess.run(argv,stdin=subprocess.DEVNULL,capture_output=True,check=False)
 rows.append({'argv':argv,'command_line':subprocess.list2cmdline(argv),'exit_code':result.returncode,'stdout':result.stdout.decode('utf-8','replace'),'stderr':result.stderr.decode('utf-8','replace')})
with (here/'launcher-probe-python.json').open('x') as f:json.dump(rows,f,indent=2);f.write('\n')
print(json.dumps(rows))
