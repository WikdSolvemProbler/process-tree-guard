# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Peter Shiller
import hashlib,json,pathlib,subprocess,sys,time
ROOT=pathlib.Path(r"C:/Users/Peter/process-tree-guard")
HERE=pathlib.Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((HERE/'plan.json').read_text())
if len(sys.argv)!=2 or digest(HERE/'plan.json')!=sys.argv[1]:raise SystemExit('plan hash mismatch')
if digest(pathlib.Path(__file__))!=plan['controller_sha256']:raise SystemExit('controller changed')
for p,h in plan['pins'].items():
 if digest(pathlib.Path(p))!=h:raise SystemExit('input changed: '+p)
start=time.monotonic_ns()
with (HERE/'stdout.log').open('xb') as out,(HERE/'stderr.log').open('xb') as err:
 result=subprocess.run([plan['cmd_path'],'/d','/s','/c',str(HERE/'build.cmd')],cwd=ROOT,stdin=subprocess.DEVNULL,stdout=out,stderr=err,check=False)
end=time.monotonic_ns()
changed=[p for p,h in plan['pins'].items() if digest(pathlib.Path(p))!=h]
receipt={'schema':1,'source_manifest_sha256':plan['source_manifest_sha256'],'exit_code':result.returncode,'elapsed_ns':end-start,'changed_inputs':changed,'stdout_sha256':digest(HERE/'stdout.log'),'stderr_sha256':digest(HERE/'stderr.log'),'scope':'actual full release library tests; outer isolated Job deadline 300 seconds; no competitive performance qualification'}
with (HERE/'receipt.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(result.returncode if not changed else 125)
