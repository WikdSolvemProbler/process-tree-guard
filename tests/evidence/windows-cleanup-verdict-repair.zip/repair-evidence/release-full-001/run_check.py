# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Peter Shiller
import hashlib,json,pathlib,subprocess,sys,time
ROOT=pathlib.Path(r"C:/Users/Peter/process-tree-guard")
HERE=pathlib.Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((HERE/'plan.json').read_text())
if len(sys.argv)!=2 or digest(HERE/'plan.json')!=sys.argv[1]:raise SystemExit('plan hash mismatch')
if digest(pathlib.Path(__file__))!=plan['controller_sha256']:raise SystemExit('controller changed')
for p,h in plan['pins'].items():
 if digest(pathlib.Path(p))!=h:raise SystemExit('input changed: '+p)
command=[plan['cmd_path'],'/d','/c','call',str(HERE/'build.cmd')]
with (HERE/'actual-command.json').open('x') as f:json.dump({'argv':command,'windows_command_line':subprocess.list2cmdline(command)},f,indent=2);f.write('\n')
start=time.monotonic_ns()
with (HERE/'stdout.log').open('xb') as out,(HERE/'stderr.log').open('xb') as err:
 result=subprocess.run(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=out,stderr=err,check=False)
end=time.monotonic_ns()
changed=[p for p,h in plan['pins'].items() if digest(pathlib.Path(p))!=h]
receipt={'schema':1,'source_manifest_sha256':plan['source_manifest_sha256'],'exit_code':result.returncode,'elapsed_ns':end-start,'changed_inputs':changed,'stdout_sha256':digest(HERE/'stdout.log'),'stderr_sha256':digest(HERE/'stderr.log'),'scope':'actual complete default release Cargo test suite; outer isolated Job deadline 900 seconds; no competitive performance qualification'}
with (HERE/'receipt.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(result.returncode if not changed else 125)
