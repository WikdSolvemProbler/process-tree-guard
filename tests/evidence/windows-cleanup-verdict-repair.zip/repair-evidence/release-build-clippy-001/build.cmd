@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat" 10.0.28000.0 -vcvars_ver=14.51
if errorlevel 1 exit /b %errorlevel%
echo SelectedWindowsSDKVersion=%WindowsSDKVersion%
echo SelectedVCToolsVersion=%VCToolsVersion%
set "PATH=C:\Users\Peter\.rustup\toolchains\stable-x86_64-pc-windows-msvc\bin;C:\Program Files\Git\bin;%PATH%"
set "RUSTC=C:\Users\Peter\.rustup\toolchains\stable-x86_64-pc-windows-msvc\bin\rustc.exe"
set "CARGO_TARGET_DIR=C:\Users\Peter\process-tree-guard\target\codex-security\windows-cleanup-verdict-001\cargo-target-001"
set "CARGO_BUILD_JOBS=2"
set "CARGO_INCREMENTAL=0"
set "RUSTFLAGS=-D warnings"
set "PROCESS_TREE_GUARD_REQUIRE_RESOURCES=1"
"C:\Users\Peter\.rustup\toolchains\stable-x86_64-pc-windows-msvc\bin\cargo.exe" build --offline --locked --release --bins --features testkit
if errorlevel 1 exit /b %errorlevel%
"C:\Users\Peter\.rustup\toolchains\stable-x86_64-pc-windows-msvc\bin\cargo.exe" clippy --offline --locked --release --all-targets -- -D warnings
exit /b %errorlevel%
