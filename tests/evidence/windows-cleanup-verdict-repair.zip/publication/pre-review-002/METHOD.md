# Cleanup verdict repair evidence publication preparation

This is an unexecuted publisher preparation. No ZIP publication is authorized yet. The frozen candidate is 5eb80d5a01dbbe2720c54fb370058c382c28eb7f00958ea8cbc356d7d9d8f318. Root owns qualification, repository changes and publication authorization.

The source snapshot captures 68 current Rust source files, all 8 integration/support Rust files, Cargo.toml, Cargo.lock, build.rs, top-level documentation and the changed guarantee wiki (90 repository files). Top-level documents include CHANGELOG/CONTRIBUTING/SECURITY because integration tests read them, plus SPEC_Benchmark, LICENSE and NOTICE. This snapshot is source inventory, not a passing test receipt or atomic-host immutability proof.

The publisher imports only Node filesystem/path/crypto/zlib modules and defines functions. Import has no publication action. It never launches a process, compiler, native test, archived executable or benchmark. Parent may inspect or syntax-check the source through the existing persistent runtime; do not run a new command for this preparation.

## Terminal publication contract

After parent explicitly declares qualification terminal, parent may create publication-001/RESULTS.json and authorization.json with exclusive creation. The authorization must match authorization.template.json, set qualification_terminal=true, pin this publisher, pin the source snapshot and pin the exact RESULTS bytes. It must provide explicit complete/interrupted/not_run states for release-lib-003, release-full-001 and release-build-clippy-001. Complete states require exact actual receipt hashes; interrupted or not-run states require a reason and no fabricated receipt. An unexecuted plan is retained as preparation, never a test result.

RESULTS must bind source_manifest_sha256 to the candidate, declare performance_qualified=false and live_survivor_reproduced=false, and contain a nonempty limitations array. Root should record exact actual test totals/conditional cases, elapsed times, launcher-only failures, Clippy/build outcomes and the full-suite source coverage limitation. The publisher preserves those results rather than inventing test counts.

Parent can then use the persistent Node runtime to read/hash the approved publisher and authorization bytes, import the reviewed module, and call publish(the exact authorization SHA256). It refuses absent or nonterminal authorization, changed source, changed receipts or an existing destination. Do not substitute a source-only review for the parent's terminal authorization.

## Archive contents and integrity

The intended final path is tests/evidence/windows-cleanup-verdict-repair.zip. Members use current-repository/, repair-evidence/, publication/ and release-binaries/ prefixes. All current repair evidence is enumerated after termination: original six files, rejected 9a six-file draft/manifest/review, all launcher attempts/probes/environment discovery, successful library logs, final full-suite and quality plans/logs/receipts, and independent reviews/audits. Failed and unexecuted preparations remain present. Cargo-target cache directories and recursive publication output are excluded. Selected publication sources, original skeleton, exact authorization/results and tool metadata are added explicitly. The final INDEX excludes only itself and records every other member's SHA256 and byte length.

All plan-pinned outside-repository tools are verified and retained as explicit path/hash/size metadata in TOOLS.json. Rust/MSVC/SDK distributions are not copied. If the actual quality receipt passed, the publisher requires exactly six role identities and includes their exact release EXE bytes after size/hash and provenance checks. Whole Cargo caches are never included. A successful build/Clippy receipt alone is not a performance result.

Every captured source is checked before and after construction. ZIP local/central records, member sizes, CRC32 and captured bytes are verified; readback is checked. The writer uses exclusive creation and never overwrites an existing archive or publication artifact. Any partial/error artifact must be preserved by parent before a separately reviewed correction. No automatic retry, cleanup or Git operation exists.

The initial full-suite plan did not pre-pin every integration-test Rust file. Later source hashes are not retroactive atomic snapshot proof; full-suite-source-coverage-note.json is retained explicitly. Environment-gated or interactive cases must retain their actual coverage limits. The repair has no live-survivor reproduction and no head-to-head speed/parity qualification. Those objectives remain open.
