// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller
// Source preparation only. Importing this module performs no publication.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';

const ROOT = 'C:/Users/Peter/process-tree-guard';
const REPAIR = ROOT + '/target/codex-security/windows-cleanup-verdict-001';
const PUB = REPAIR + '/publication-001';
const SOURCE_SHA = '5eb80d5a01dbbe2720c54fb370058c382c28eb7f00958ea8cbc356d7d9d8f318';
const SNAPSHOT_SHA = '0ddfa90802ad7671c0ad987ffe018d5c3f5c846a47c1b20ad7ef09f576379f15';
const OUTPUT = ROOT + '/tests/evidence/windows-cleanup-verdict-repair.zip';
const ROLES = ['process-tree-guard','process-tree-guard-deadline','process-tree-guard-gate','process-tree-guard-contain','ptg','testkit'];
const TERMINAL_ATTEMPTS = ['release-lib-003','release-full-001','release-build-clippy-001','release-build-clippy-002'];
const REQUIRED_ATTEMPTS = ['release-lib-003','release-full-001','release-build-clippy-002'];
const QUALIFYING_BINARY_ATTEMPT = 'release-build-clippy-002';
const PUB_EXCLUDE = new Set(['INDEX.json','PACKAGE.json','TOOLS.json','publication-receipt-001.json','authorization.json','RESULTS.json']);
const sha = raw => crypto.createHash('sha256').update(raw).digest('hex');
function requireFact(ok, text) { if (!ok) throw new Error(text); }
const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
async function bytes(file) {
  const stat = await fs.lstat(file);
  requireFact(stat.isFile() && !stat.isSymbolicLink(), 'regular non-link input required: ' + file);
  return fs.readFile(file);
}
async function bound(file, expected) {
  const raw = await bytes(file);
  requireFact(sha(raw) === expected, 'bound bytes differ: ' + file);
  return raw;
}
async function absent(file) { try { await fs.lstat(file); return false; } catch (error) { if (error.code === 'ENOENT') return true; throw error; } }
function inside(file, parent) {
  const resolved = path.win32.resolve(file), rel = path.win32.relative(path.win32.resolve(parent), resolved);
  return rel !== '' && rel !== '..' && !rel.startsWith('..\\') && !path.win32.isAbsolute(rel);
}
function key(file) { return path.win32.normalize(file).toLowerCase(); }
async function walk(dir, rel = '') {
  const answer = [];
  for (const item of await fs.readdir(dir, {withFileTypes:true})) {
    const name = rel + item.name;
    if (item.isSymbolicLink()) throw new Error('link refused: ' + name);
    if (item.isDirectory()) {
      if (/^cargo-target(?:-|$)/.test(item.name) || name === 'publication-001') continue;
      answer.push(...await walk(dir + '/' + item.name, name + '/'));
    } else if (item.isFile()) answer.push(name);
    else throw new Error('nonregular repair entry refused: ' + name);
  }
  return answer.sort();
}
function crc32(raw) {
  let crc = 0xffffffff;
  for (const byte of raw) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc & 1) ? (0xedb88320 ^ (crc >>> 1)) : (crc >>> 1);
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function zipBytes(members) {
  const locals = [], central = [], seen = new Set(); let offset = 0;
  requireFact(members.length < 65535, 'ZIP64 not supported');
  for (const item of members) {
    requireFact(!seen.has(item.name) && !item.name.startsWith('/') && !item.name.includes('\\') && !item.name.split('/').includes('..'), 'unsafe or duplicate member');
    seen.add(item.name);
    const name = Buffer.from(item.name, 'utf8'), compressed = zlib.deflateRawSync(item.raw, {level:9}), crc = crc32(item.raw);
    requireFact(name.length <= 65535 && item.raw.length < 0xffffffff && compressed.length < 0xffffffff, 'ZIP32 bounds');
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50,0); local.writeUInt16LE(20,4); local.writeUInt16LE(0x800,6); local.writeUInt16LE(8,8);
    local.writeUInt16LE(0x21,12); local.writeUInt32LE(crc,14); local.writeUInt32LE(compressed.length,18); local.writeUInt32LE(item.raw.length,22); local.writeUInt16LE(name.length,26);
    const record = Buffer.alloc(46);
    record.writeUInt32LE(0x02014b50,0); record.writeUInt16LE(20,4); record.writeUInt16LE(20,6); record.writeUInt16LE(0x800,8); record.writeUInt16LE(8,10);
    record.writeUInt16LE(0x21,14); record.writeUInt32LE(crc,16); record.writeUInt32LE(compressed.length,20); record.writeUInt32LE(item.raw.length,24); record.writeUInt16LE(name.length,28); record.writeUInt32LE(offset,42);
    locals.push(local,name,compressed); central.push(record,name); offset += local.length + name.length + compressed.length;
  }
  const cd = Buffer.concat(central), end = Buffer.alloc(22);
  requireFact(offset < 0xffffffff && cd.length < 0xffffffff, 'ZIP32 central bounds');
  end.writeUInt32LE(0x06054b50,0); end.writeUInt16LE(members.length,8); end.writeUInt16LE(members.length,10); end.writeUInt32LE(cd.length,12); end.writeUInt32LE(offset,16);
  return Buffer.concat([...locals,cd,end]);
}
function inspectZip(raw, members) {
  const expected = new Map(members.map(item => [item.name,item.raw]));
  const eocd = raw.length - 22;
  requireFact(raw.readUInt32LE(eocd) === 0x06054b50 && raw.readUInt16LE(eocd+10) === members.length, 'ZIP terminal coverage');
  let at = raw.readUInt32LE(eocd+16); const stop = at + raw.readUInt32LE(eocd+12); const seen = new Set();
  for (let index = 0; index < members.length; index++) {
    requireFact(raw.readUInt32LE(at) === 0x02014b50, 'ZIP central signature');
    const length = raw.readUInt16LE(at+28), extra = raw.readUInt16LE(at+30), comment = raw.readUInt16LE(at+32);
    const name = raw.subarray(at+46,at+46+length).toString('utf8'), local = raw.readUInt32LE(at+42);
    const compressed = raw.readUInt32LE(at+20), size = raw.readUInt32LE(at+24), crc = raw.readUInt32LE(at+16);
    requireFact(!seen.has(name) && expected.has(name) && raw.readUInt32LE(local) === 0x04034b50, 'ZIP member identity'); seen.add(name);
    const begin = local + 30 + raw.readUInt16LE(local+26) + raw.readUInt16LE(local+28);
    const plain = zlib.inflateRawSync(raw.subarray(begin,begin+compressed), {maxOutputLength:size+1});
    requireFact(plain.length === size && crc32(plain) === crc && plain.equals(expected.get(name)), 'ZIP member CRC/bytes: ' + name);
    at += 46 + length + extra + comment;
  }
  requireFact(at === stop && stop === eocd && seen.size === expected.size, 'ZIP exact central closure');
}
async function terminalAttempt(name, control) {
  requireFact(control && ['complete','interrupted','not_run'].includes(control.state), 'explicit terminal attempt state required: ' + name);
  const receiptPath = REPAIR + '/' + name + '/receipt.json';
  if (control.state !== 'complete') {
    requireFact(control.receipt_sha256 === null && typeof control.reason === 'string' && control.reason.length > 0, 'noncompleted attempt reason required');
    requireFact(await absent(receiptPath), 'receipt contradicts noncompleted attempt');
    if (control.state === 'not_run') for (const file of ['actual-command.json','stdout.log','stderr.log']) requireFact(await absent(REPAIR + '/' + name + '/' + file), 'not_run has execution artifact');
    return {state:control.state,passed:false,reason:control.reason,receipt:null};
  }
  requireFact(typeof control.receipt_sha256 === 'string', 'terminal receipt hash required');
  const receiptRaw = await bound(receiptPath,control.receipt_sha256), receipt = JSON.parse(receiptRaw);
  requireFact(receipt.source_manifest_sha256 === SOURCE_SHA && Number.isInteger(receipt.exit_code) && Array.isArray(receipt.changed_inputs), 'receipt source/outcome shape');
  await bound(REPAIR + '/' + name + '/stdout.log',receipt.stdout_sha256);
  await bound(REPAIR + '/' + name + '/stderr.log',receipt.stderr_sha256);
  const actualPlan = JSON.parse(await bytes(REPAIR + '/' + name + '/plan.json'));
  requireFact(actualPlan.source_manifest_sha256 === SOURCE_SHA, 'terminal plan source differs');
  return {state:'complete',passed:receipt.exit_code===0 && receipt.changed_inputs.length===0,receipt,receipt_sha256:control.receipt_sha256};
}

export async function publish(approvedAuthorizationSha256) {
  // Parent must create this exact file only after all qualification processes are terminal.
  const authorizationRaw = await bound(PUB + '/authorization.json',approvedAuthorizationSha256), authorization = JSON.parse(authorizationRaw);
  requireFact(authorization.schema === 'cleanup-repair-publication-authorization-v1' && authorization.qualification_terminal === true, 'publication not authorized/terminal');
  requireFact(authorization.source_manifest_sha256 === SOURCE_SHA && authorization.repository_source_snapshot_sha256 === SNAPSHOT_SHA, 'authorization source differs');
  await bound(PUB + '/publish_repair.mjs',authorization.publisher_sha256);
  requireFact(await absent(OUTPUT), 'existing archive is immutable; refuse overwrite');
  const sourceRaw = await bound(REPAIR + '/source-candidate.json',SOURCE_SHA), source = JSON.parse(sourceRaw);
  for (const [name,pin] of Object.entries(source.files)) await bound(ROOT + '/' + name,pin);
  const snapshot = JSON.parse(await bound(PUB + '/repository-source-snapshot-002.json',SNAPSHOT_SHA));
  const resultsRaw = await bound(PUB + '/RESULTS.json',authorization.results_sha256), results = JSON.parse(resultsRaw);
  requireFact(results.source_manifest_sha256 === SOURCE_SHA && results.performance_qualified === false && results.live_survivor_reproduced === false, 'honest source-bound RESULTS required');
  requireFact(Array.isArray(results.limitations) && results.limitations.length > 0, 'functional/test coverage limitations must be explicit');
  const attempts = {};
  for (const name of TERMINAL_ATTEMPTS) attempts[name] = await terminalAttempt(name,authorization.terminal_attempts[name]);
  const entries = [], sourceRows = [], external = new Map();
  function add(name, raw, file=null) { entries.push({name,raw}); sourceRows.push({name,bytes:raw.length,sha256:sha(raw),source:file}); }
  async function addSource(name,file) { add(name,await bytes(file),file); }
  for (const [name,identity] of Object.entries(snapshot.files)) {
    const raw = await bound(ROOT + '/' + name,identity.sha256); requireFact(raw.length===identity.bytes,'repository size differs'); add('current-repository/' + name,raw,ROOT + '/' + name);
  }
  const repairNames = await walk(REPAIR);
  for (const name of repairNames) await addSource('repair-evidence/' + name,REPAIR + '/' + name);
  for (const name of (await walk(PUB)).filter(name => !PUB_EXCLUDE.has(name))) await addSource('publication/' + name,PUB + '/' + name);
  add('publication/authorization.json',authorizationRaw,PUB + '/authorization.json');
  add('publication/RESULTS.json',resultsRaw,PUB + '/RESULTS.json');
  // Explicit plan-pinned external tool metadata; never copy Rust/MSVC/SDK installations.
  for (const item of entries.filter(item => /(?:plan(?:\.proposed|\.unexecuted-preparation)?\.json)$/.test(item.name))) {
    const plan = JSON.parse(item.raw);
    for (const [file,pin] of Object.entries(plan.pins || {})) {
      if (inside(file,ROOT)) continue;
      const old = external.get(key(file)); requireFact(!old || old.sha256===pin,'conflicting external pin');
      const raw = await bound(file,pin); external.set(key(file),{path:file,sha256:pin,bytes:raw.length,disposition:'Pinned external toolchain/runtime input; not redistributed.'});
    }
  }
  const quality = attempts[QUALIFYING_BINARY_ATTEMPT]; const binaries = {};
  if (quality.passed) {
    requireFact(Object.keys(quality.receipt.executables || {}).sort().join('|')===ROLES.slice().sort().join('|'),'exact six release roles required');
    for (const role of ROLES) {
      const identity = quality.receipt.executables[role];
      requireFact(inside(identity.path,REPAIR + '/cargo-target-001/release') && path.win32.basename(identity.path)===role+'.exe','release binary provenance');
      const raw = await bound(identity.path,identity.sha256); requireFact(raw.length===identity.bytes,'release binary size');
      add('release-binaries/' + role + '.exe',raw,identity.path); binaries[role]={bytes:raw.length,sha256:sha(raw),member:'release-binaries/'+role+'.exe'};
    }
  }
  const toolRows = [...external.values()].sort((a,b)=>a.path.localeCompare(b.path));
  add('publication/TOOLS.json',jsonBytes({schema:'cleanup-repair-external-tools-v1',tools:toolRows}));
  const packageRecord = {schema:'windows-cleanup-verdict-repair-package-v1',source_manifest_sha256:SOURCE_SHA,repository_source_snapshot_sha256:SNAPSHOT_SHA,
    functional_tests_passed:['release-lib-003','release-full-001'].every(name=>attempts[name].passed),
    required_validation_passed:REQUIRED_ATTEMPTS.every(name=>attempts[name].passed),
    all_recorded_attempts_passed:TERMINAL_ATTEMPTS.every(name=>attempts[name].passed),
    extra_strict_clippy_passed:attempts['release-build-clippy-001'].passed,
    qualifying_binary_attempt:QUALIFYING_BINARY_ATTEMPT,terminal_attempts:attempts,release_binaries:binaries,
    performance_qualified:false,live_survivor_reproduced:false,benchmark_slots:0,
    scope:'Failure-reporting and conservative cleanup evidence repair. Actual validation receipts and unexecuted/failed preparations preserved. Optional extra-strict Clippy001 failed four existing advisories; local repository-CI-equivalent Clippy002 passed without -D warnings. No zero-advisory lint, remote CI execution, head-to-head speed or universal kernel termination claim.',results_member:'publication/RESULTS.json',
    lint_context_member:'publication/strict-lint-context-001.json',ci_workflow_member:'current-repository/.github/workflows/rust-clippy.yml',
    source_coverage_note:'Full-suite initial plan did not pre-pin every integration-test Rust file; preserve full-suite-source-coverage-note.json. Later hashes are not retroactive atomic snapshot proof.',external_tool_members:'publication/TOOLS.json',cache_policy:'No Cargo-target cache or Rust/MSVC/SDK distribution is redistributed; only exact quality-receipt release binaries are selected.'};
  add('publication/PACKAGE.json',jsonBytes(packageRecord));
  const index = Object.fromEntries(sourceRows.sort((a,b)=>a.name.localeCompare(b.name)).map(row=>[row.name,{bytes:row.bytes,sha256:row.sha256,source:row.source}]));
  const indexRaw = jsonBytes(index); entries.push({name:'INDEX.json',raw:indexRaw}); entries.sort((a,b)=>a.name.localeCompare(b.name));
  const archive = zipBytes(entries); inspectZip(archive,entries);
  // Capture before/after exact bytes; late mutations cannot produce a qualified archive.
  for (const row of sourceRows) if (row.source) await bound(row.source,row.sha256);
  await bound(PUB + '/authorization.json',approvedAuthorizationSha256);
  await fs.writeFile(PUB + '/INDEX.json',indexRaw,{flag:'wx'});
  await fs.writeFile(PUB + '/PACKAGE.json',jsonBytes(packageRecord),{flag:'wx'});
  await fs.writeFile(PUB + '/TOOLS.json',jsonBytes({schema:'cleanup-repair-external-tools-v1',tools:toolRows}),{flag:'wx'});
  await fs.writeFile(OUTPUT,archive,{flag:'wx'});
  const readback = await bytes(OUTPUT); requireFact(readback.equals(archive),'archive readback differs'); inspectZip(readback,entries);
  const receipt = {schema:'cleanup-repair-publication-receipt-v1',archive_path:OUTPUT,archive_sha256:sha(readback),archive_bytes:readback.length,
    members:entries.length,indexed_members:sourceRows.length,index_sha256:sha(indexRaw),source_manifest_sha256:SOURCE_SHA,authorization_sha256:approvedAuthorizationSha256,
    integrity_verified:true,external_tool_count:toolRows.length,release_binary_count:Object.keys(binaries).length,
    functional_tests_passed:packageRecord.functional_tests_passed,required_validation_passed:packageRecord.required_validation_passed,
    extra_strict_clippy_passed:packageRecord.extra_strict_clippy_passed,all_recorded_attempts_passed:packageRecord.all_recorded_attempts_passed,
    performance_qualified:false,live_survivor_reproduced:false,benchmark_slots:0,scope:'Persistent Node filesystem packaging only. No process, compiler, test, archived executable or benchmark launched.'};
  await fs.writeFile(PUB + '/publication-receipt-001.json',jsonBytes(receipt),{flag:'wx'});
  return receipt;
}
