# Attempt013: immutable zero-slot preflight refusal

This archive preserves the sole approved exploratory Windows laptop attempt013,
which ended with outer exit1 during its first preflight inventory. It is rejected
and incomplete. No campaign worker was launched, no slot ran, and no latency or
protection comparison can be inferred. `started` in telemetry records the planned
argument vector and observer start; it is not a worker-launch receipt. No normal
campaign run metadata is present, and none was fabricated for this archive.

The exact manifest is
313bf9796153453177636419137275ebd0f5374d71c359138c8001455a6e81ae.
The prospective public protocol archive is
windows-laptop-exploratory-protocol-013.zip with SHA-256
77ef0d6eca6835f087b77114c871373684134b6b4464b35a0f3e37e52427722a.
Its complete INDEX was verified, and its INDEX/PREREGISTRATION bytes are included.
The exact attempt source freeze, qualification links, current manifest, earlier
preparation drafts, complete raw capture, frozen campaign source/input manifest,
and the linked qualification metadata are preserved. Executable input bytes are
already pinned in the referenced protocol package; their digests are retained.
This packaging does not rerun or rescore any prior qualification.

Raw telemetry contains only started, one pre sample, and rejected terminal records.
There is one corresponding inventory snapshot containing33 rows:32 classified
unclassified_background and one exact pinned enclosing guard. All33 saved states
were allowed by the frozen predicate; no disallowed state triggered the refusal.
The sample monotonic timestamp is764463120416300ns and inventory finished at
764464227884200ns, a span of1,107,467,900ns. The frozen50,000,000ns budget was
exceeded. In quiet_launch.py's on_sample OR condition, that timing predicate is
true and the disallowed-state predicate is false. Thus the saved generic error
`competing or unverified process inventory` was a time-budget-only rejection for
this sample. That generic text is retained unchanged. The archive does not
attribute the collector delay to any particular process or operation.

The raw counter-read span is892,900ns. Available memory was4,585,127,936bytes,
AC line was1, saver was0, and native_errors was empty. These are the single saved
sample's values; they do not establish sustained CPU, memory, power, or clock
conditions. There are no windows, phase decisions, worker-launched records,
campaign output directory, run metadata, observations, or Job abort-drain records.
Empty stdout/stderr files remain empty and unchanged.

The only recorded owned process identity independently checked here is enclosing
guard PID47408, creation FILETIME134384998304080451. A bounded native Windows
read-only helper uses OpenProcess(query+synchronize), GetProcessTimes, and a
zero-time WaitForSingleObject. Python integer arithmetic preserves every FILETIME
bit; no JSON-to-floating-point conversion is used. Read independent-cleanup.json
for the exact observed current state. No process is terminated by this check.
Observer PID16456 lacks a recorded creation FILETIME, so no exact observer identity
claim is made. There is no campaign-worker cleanup claim because none was launched
or recorded. No additional slot, rerun, source change, or admin test was performed.

Before and after packaging, the complete original source/capture file set and
each file's bytes are compared against source-and-capture-before.json. Every
archive member except INDEX.json has an exact length and SHA-256 in INDEX.json;
ZIP CRC and exact-member verification also pass. Rejected status is immutable.
Any later collector profiling belongs to a separate, explicitly zero-slot
diagnostic and cannot retroactively admit this attempt. Issue7 and strict
certification remain open. Mac administrator validation remains deferred under
the user's instruction and is unrelated to this Windows refusal.
