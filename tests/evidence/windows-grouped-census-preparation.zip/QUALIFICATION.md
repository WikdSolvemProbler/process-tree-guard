# Grouped census source and mock checkpoint

This is a prospective observation-method change. All process queries and rows
remain, but identical exact raw image-path strings share one file observation:
P0, first complete size-bounded read, all members P1, checked rewind, second read,
final file checks, owned cleanup and census decision. It is fewer independent
content observations than the former per-row schedule. The full METHOD.json
states the transient/ABA, freshness, loaded-image and other sampling limits.

Twenty-seven fake/mocked controls passed; no native grouped census, file control
or pipeline has run. Two independent Sol reviewers approved the exact collector
source with zero unresolved source objections. These approvals are not native
evidence or permission to claim full benchmark readiness.

The separate pipeline draft includes strict emitted census and telemetry replay,
unaltered013 numerical CPU/resource gates, both original and stricter output-
inclusive timing spans, and an explicit incomplete two-window phase verdict.
Its native-control receipt is intentionally unset, so it refuses before sampling.
Independent final review and a qualified pinned native receipt are still needed.

Earlier unexecuted clock and telemetry-replay drafts and the successful mock
attempts are preserved. The original failed native pipelines are unchanged.
No production guard source, protection/default, numeric budget or performance
result changes in this checkpoint. INDEX.json binds every other member.
