"""Prepared macOS root accounting primitive controller. Not executed at preparation."""
import hashlib
import json
import os
from pathlib import Path
import pwd
import stat
import subprocess
import sys
import tempfile

SOURCE_DIR = "/private/tmp/ptg-saturated-uid-build-002.dmQM2CNt"
TARGET_UID = 60001
GTIMEOUT = "/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout"
GTIMEOUT_SHA = "6a7b0620313d337d70366cd4d3b969b49854abfeb1db602bdf3328122e223c6d"
EXPECTED = {
    "saturated_uid.c": {"sha256": "12252db8cb1c38dcc98c1bfc81dfe2e9427a6a9a0110d293d587490597f490e5",
                        "bytes": 13645, "max_bytes": 13645},
    "saturated-uid": {"sha256": "3f05d8a37dadac23cff602b6628b81f8138d0dad151d05405643ee5050fd722b",
                      "bytes": None, "max_bytes": 32 * 1024 * 1024},
}

def demand(value, message):
    if not value:
        raise RuntimeError(message)

def identity(value):
    return value.st_dev, value.st_ino

def stable(value):
    return (value.st_dev, value.st_ino, value.st_size,
            value.st_mtime_ns, value.st_ctime_ns)

def write_all(fd, data):
    while data:
        n = os.write(fd, data)
        demand(n > 0, "short private-file write")
        data = data[n:]

def read_verified(fd, pin):
    before = os.fstat(fd)
    demand(stat.S_ISREG(before.st_mode) and before.st_nlink == 1,
           "pinned input is not one regular inode")
    demand(0 < before.st_size <= pin["max_bytes"], "pinned input length out of bounds")
    if pin["bytes"] is not None:
        demand(before.st_size == pin["bytes"], "pinned input length differs")
    data = bytearray()
    while len(data) <= pin["max_bytes"]:
        part = os.read(fd, 65536)
        if not part:
            break
        data.extend(part)
    demand(stable(os.fstat(fd)) == stable(before), "pinned input changed during read")
    demand(hashlib.sha256(data).hexdigest() == pin["sha256"], "pinned input digest differs")
    return bytes(data), before

def timeout_fd():
    demand(os.path.realpath(GTIMEOUT) == GTIMEOUT, "gtimeout canonical path changed")
    fd = os.open(GTIMEOUT, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        pin = {"sha256": GTIMEOUT_SHA, "bytes": None, "max_bytes": 32 * 1024 * 1024}
        data, initial = read_verified(fd, pin)
        demand(identity(os.stat(GTIMEOUT, follow_symlinks=False)) == identity(initial),
               "gtimeout path differs from held input")
        return fd, initial
    except BaseException:
        os.close(fd)
        raise

def process_snapshot():
    result = subprocess.run(
        ["/bin/ps", "-axo", "pid=,ppid=,pgid=,ruid=,uid="],
        capture_output=True, text=True, check=True, timeout=3,
    )
    rows = []
    for line in result.stdout.splitlines():
        values = line.split()
        demand(len(values) == 5, "malformed ps identity census")
        pid, parent, group, real, effective = map(int, values)
        rows.append({"pid": pid, "parent": parent, "pgid": group,
                     "ruid": real, "euid": effective})
    return rows

def unused_uid(label):
    outputs = {}
    for key, argv in (
        ("local_directory", ["/usr/bin/dscl", ".", "-search", "/Users", "UniqueID", str(TARGET_UID)]),
        ("directory_cache", ["/usr/bin/dscacheutil", "-q", "user", "-a", "uid", str(TARGET_UID)]),
    ):
        result = subprocess.run(argv, capture_output=True, text=True, check=True, timeout=3)
        outputs[key] = {"argv": argv, "stdout": result.stdout, "stderr": result.stderr,
                        "exit": result.returncode}
        demand(not result.stdout.strip(), "target UID has an account/cache entry")
    try:
        account = pwd.getpwuid(TARGET_UID)
    except KeyError:
        account = None
    demand(account is None, "getpwuid resolved the proposed UID")
    rows = process_snapshot()
    selected = [row for row in rows if TARGET_UID in (row["ruid"], row["euid"])]
    print("UID_REVALIDATION=" + json.dumps({
        "phase": label, "target_uid": TARGET_UID, "queries": outputs,
        "real_or_effective_uid_processes": selected,
    }), flush=True)
    demand(not selected, "target UID has existing real/effective processes")
    return rows

scratch = None
target_fd = None
source_fd = None
held_timeout = None
child = None
native_stdout = b""
native_stderr = b""
try:
    os.umask(0o077)
    demand(os.getuid() == 0 and os.geteuid() == 0, "controller requires trusted root")
    demand(os.uname().machine == "arm64", "prepared native binary requires macOS ARM64")
    demand(os.getpgrp() == os.getppid() and os.getpgrp() != os.getpid(),
           "controller is outside the immediate root timeout group")
    held_timeout, initial_timeout = timeout_fd()
    host = subprocess.run(["/usr/bin/sw_vers"], check=True, capture_output=True, text=True, timeout=3)
    print("CONTROLLER_CONTEXT=" + json.dumps({
        "pid": os.getpid(), "parent": os.getppid(), "pgid": os.getpgrp(),
        "python": sys.version, "platform": list(os.uname()),
        "sw_vers": host.stdout, "gtimeout": GTIMEOUT, "gtimeout_sha256": GTIMEOUT_SHA,
    }), flush=True)
    unused_uid("before-staging")
    demand(os.path.realpath(SOURCE_DIR) == SOURCE_DIR, "ordinary build directory is not canonical")
    source_fd = os.open(SOURCE_DIR, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    original = os.fstat(source_fd)
    demand(original.st_uid == 501 and stat.S_IMODE(original.st_mode) == 0o700,
           "ordinary build directory is not private UID 501 input")
    scratch = tempfile.mkdtemp(prefix="ptg-saturated-uid-root-001.", dir="/private/tmp")
    target_fd = os.open(scratch, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    target = os.fstat(target_fd)
    demand(target.st_uid == 0 and stat.S_IMODE(target.st_mode) == 0o700,
           "root scratch is not private")
    print("ROOT_SCRATCH=" + json.dumps({
        "path": scratch, "device": target.st_dev, "inode": target.st_ino,
        "target_uid": TARGET_UID, "M": 8, "payload_runs": 0,
    }), flush=True)
    owned = {}
    for name, pin in EXPECTED.items():
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=source_fd)
        try:
            data, before = read_verified(fd, pin)
            demand(before.st_uid == 501 and before.st_mode & 0o022 == 0,
                   "ordinary build input is writable by another principal")
            output = os.open(
                name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                0o600, dir_fd=target_fd,
            )
            try:
                write_all(output, data)
                os.lseek(output, 0, os.SEEK_SET)
                root_pin = {"sha256": pin["sha256"], "bytes": len(data), "max_bytes": len(data)}
                copied, copied_stat = read_verified(output, root_pin)
                if name == "saturated-uid":
                    os.fchmod(output, 0o700)
                owned[name] = identity(os.fstat(output))
                print("ROOT_COPIED=" + json.dumps({
                    "name": name, "bytes": len(copied), "sha256": pin["sha256"],
                    "device": copied_stat.st_dev, "inode": copied_stat.st_ino,
                }), flush=True)
            finally:
                os.close(output)
        finally:
            os.close(fd)
    unused_uid("immediately-before-primitive")
    demand(stable(os.fstat(held_timeout)) == stable(initial_timeout),
           "held gtimeout changed before launch")
    demand(identity(os.stat(GTIMEOUT, follow_symlinks=False)) == identity(initial_timeout),
           "gtimeout path changed before launch")
    argv = [
        GTIMEOUT, "--signal=KILL", "--kill-after=3s", "25s",
        scratch + "/saturated-uid", str(TARGET_UID), GTIMEOUT,
    ]
    print("PRIMITIVE_ARGV=" + json.dumps(argv), flush=True)
    # Default gtimeout establishes its own process group. No foreground,
    # setsid, process-group parameter, shell, or payload is added here.
    child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, close_fds=True)
    print("ROOT_GTIMEOUT_CHILD=" + str(child.pid), flush=True)
    native_stdout, native_stderr = child.communicate()
    print("PRIMITIVE_STDOUT_BEGIN", flush=True)
    write_all(1, native_stdout)
    print("PRIMITIVE_STDOUT_END", flush=True)
    print("PRIMITIVE_STDERR_BEGIN", flush=True)
    write_all(1, native_stderr)
    print("PRIMITIVE_STDERR_END", flush=True)
    print("PRIMITIVE_EXIT=" + str(child.returncode), flush=True)
    demand(child.returncode == 0, "primitive did not return success")
    records = [json.loads(line) for line in native_stdout.splitlines() if line]
    contexts = [row for row in records if row["kind"] == "context"]
    terminals = [row for row in records if row["kind"] == "terminal"]
    cases = [row for row in records if row["kind"] == "case"]
    demand(len(contexts) == 1 and len(terminals) == 1, "missing unique native context/terminal")
    context, terminal = contexts[0], terminals[0]
    demand(context["pgid"] == child.pid == context["root_gtimeout_pid"],
           "native root timeout group identity differs")
    demand(context["target_uid"] == TARGET_UID and context["M"] == 8
           and context["payload_runs"] == 0, "native fixed scope differs")
    demand([row["reserves"] for row in cases] == [6, 7, 8]
           and all(row["valid"] and row["uid_empty"] for row in cases),
           "native sequential cases did not qualify")
    demand(terminal["valid"] and terminal["exact_children_reaped"]
           and terminal["uid_empty"] and not terminal["deadline_hit"]
           and terminal["payload_runs"] == 0, "native terminal does not qualify")
    rows = unused_uid("after-primitive")
    group = [row for row in rows if row["pgid"] == child.pid]
    print("FINAL_GROUP=" + json.dumps({"pgid": child.pid, "processes": group}), flush=True)
    demand(not group, "native root timeout group is not empty")
    os.lseek(held_timeout, 0, os.SEEK_SET)
    _, after_timeout = read_verified(
        held_timeout, {"sha256": GTIMEOUT_SHA, "bytes": initial_timeout.st_size,
                       "max_bytes": initial_timeout.st_size},
    )
    demand(stable(after_timeout) == stable(initial_timeout)
           and identity(os.stat(GTIMEOUT, follow_symlinks=False)) == identity(initial_timeout),
           "gtimeout identity changed across primitive")
    demand(identity(os.lstat(scratch)) == identity(target), "root scratch name changed")
    demand(set(os.listdir(target_fd)) == set(owned), "unexpected root scratch entries")
    for name, expected in owned.items():
        current = os.stat(name, dir_fd=target_fd, follow_symlinks=False)
        demand(current.st_uid == 0 and stat.S_ISREG(current.st_mode)
               and identity(current) == expected, "root artifact identity changed")
    for name in owned:
        os.unlink(name, dir_fd=target_fd)
    demand(identity(os.lstat(scratch)) == identity(target), "root scratch identity changed")
    os.rmdir(scratch)
    demand(not os.path.lexists(scratch), "root scratch removal unverified")
    print("ROOT_PRIMITIVE_COMPLETE=" + json.dumps({
        "valid": True, "target_uid": TARGET_UID, "M": 8,
        "exact_group": child.pid, "group_empty": True, "uid_empty": True,
        "root_scratch_removed": True, "payload_runs": 0,
        "scope": "sequential saturated-UID credential accounting only",
    }), flush=True)
except BaseException as error:
    print("QUARANTINE_REQUIRED=" + json.dumps({
        "error": type(error).__name__ + ": " + str(error), "root_scratch": scratch,
        "target_uid": TARGET_UID, "root_gtimeout_child": None if child is None else child.pid,
        "policy": "preserve every receipt; leave uncertain artifacts and process state untouched",
    }), flush=True)
    raise
finally:
    for fd in (target_fd, source_fd, held_timeout):
        if fd is not None:
            os.close(fd)
