# Saturated dedicated-UID credential-transfer control

This source is prepared for review. It has not been compiled or executed natively. The earlier ordinary-user accounting and custody probes did not exercise transfer of root-started processes into a saturated real-UID ledger.

The program requires root, an unused numeric UID of at least 60000 with no account entry or existing processes, and the canonical executable path of its immediate root gtimeout parent. It verifies that this parent's PID is the inherited process group and that the parent has real UID zero. It performs no account creation, configuration change, payload exec, new session or process-group operation.

M is fixed at eight. Sequential cases retain six, seven and eight exited children charged to the target UID. The root driver owns those exact children and retains each with waitid WNOWAIT. proc_pidinfo must confirm each zombie's target real/effective UID and exact parent. The verifier is forked while still root, sets and reads back both RLIMIT_NPROC bounds at eight, and attempts permanent UID/GID transfer with supplementary groups cleared. The first result records whether that transfer succeeded even at an already full UID. A successful transfer attempts exactly one fork of an immediate-exit C child, reaping its exact PID. Six reserves must allow it and seven must return EAGAIN. With eight reserves the transfer may either report EAGAIN or succeed and then encounter EAGAIN on fork. Any other outcome refuses this control.

The verifier then waits on a pipe while the exact root parent reaps one reserve in the six/seven cases or two in the eight case. The verifier retries a previously refused transfer if necessary and requires one successful fork with the unchanged effective limit. All exact reservations and the verifier must be reaped before the next case. A maximum of eight reserves and one verifier exist at once, with a witness child admitted only in a case below saturation. A final UID census must be empty.

All children inherit the root gtimeout group. There is no group/session change, detached process, fork churn, arbitrary command or kill(-1). Cleanup signals only unreaped exact owned children, followed by bounded polling reaps. The driver has a 14-second work deadline and reserves up to one second for cleanup within a 15-second absolute budget and alarm. Each wait polls within its deadline. The separately reviewed root gtimeout command supplies the independent whole-group 25-second deadline and a three-second KILL escalation. Source review must verify those enclosing conditions before any privileged execution.

Compile as the ordinary user in a fresh private scratch directory, within the separately finite Mac and transport wrappers.

```sh
/usr/bin/clang -std=c17 -Wall -Wextra -Werror -O2 saturated_uid.c -o saturated-uid
/usr/bin/shasum -a 256 saturated_uid.c saturated-uid /usr/bin/clang
/usr/bin/clang --version
```

The proposed privileged command is below. It is a review template and has not run. Resolve and hash the installed Homebrew gtimeout first. Replace the three placeholders with the reviewed absolute binary path, chosen unused numeric UID, and exact gtimeout executable path. Default gtimeout mode is mandatory. Do not add --foreground.

```sh
sudo /opt/homebrew/bin/gtimeout --signal=KILL --kill-after=3s 25s /ABSOLUTE/PRIVATE/SCRATCH/saturated-uid UNUSED_UID /EXACT/CANONICAL/GTIMEOUT/EXECUTABLE
```

The Mac wrapper must also have its own finite descendant-killing deadline, and SSH and Windows launchers must remain independently bounded. Preserve source/binary/compiler/OS hashes and versions, exact command, both streams and exits, group identity, and an independent final check that the unique group and target UID are empty. Never use another process's group for cleanup. No root execution is authorized by this document.

A passing result proves only the tested saturation and transfer interleaving. It does not prove a fork-publication fence, supervisor-death custody, bounded adversarial cleanup, or a production backend.
