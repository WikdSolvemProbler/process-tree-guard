# macOS administrator-validation preparation and refusal

This package preserves preparation and an administrator-authentication refusal.
It contains no executed saturated-UID primitive and establishes no privileged
credential-accounting result. The user deferred Mac administrator tests and asked
for that remaining work to be recorded as an issue. No authentication workaround,
new administrator attempt, root artifact deletion, account creation, or system
setting change was performed in packaging.

Source001 is preserved as an unapproved, never-root-executed draft. Its first
ordinary compile failed because the direct compiler invocation lacked the SDK
include root. Its second ordinary compile succeeded with an explicit SDK root.
Both streams, exits, source, commands, compiler/SDK/OS/tool pins, and the ordinary
compiled binary are retained. That source incorrectly expected an empty Darwin
getgroups readback; its exact unexecuted draft remains evidence, not a candidate
that passed validation.

Corrected source002 requires one explicit target GID and exact readback. Its
ordinary compile succeeded. The downloaded ordinary binary has SHA-256
39e4c7ba2bf024189331e4431a8d86b4b115a78017f66a2588b7da26ce1a19a4;
the corrected source has SHA-256
4b72fcbf0f54d38120c2ec9878735e76c2d1b551fd79c458ac149d88653c527b.
The binary was downloaded and hashed; it was not executed during packaging.

Parent/root attempted exactly reviewed source002 preparation002 plan
c826f08e070b6c9eed615574ceda9e74a8185aede630504a1d65742bf654cbde.
Its SSH exit was1. Raw stdout contains the pinned gtimeout hash check `OK`;
raw stderr says `sudo: a password is required`. This refusal happened before
the root Python controller or C primitive started: neither controller nor
primitive context, scratch, or terminal markers exist in that receipt. There
was no root private staging directory to remove and no target-UID transfer.
The package does not turn a refusal into a correctness pass.

Both source002 preparation revisions and source001's controller draft are
preserved. Preparation002 adds incremental exact stdout/stderr chunk receipts
to the root controller. Its proposed finite bounds are Windows Job100s,
Mac default-group gtimeout65s, root controller40s, and native group25s with
three-second KILL setting; C work14s and absolute cleanup/alarm15s. These are
reviewed preparation, not proof that the root enclosure or primitive ran.

The separate ordinary-only preservation step used a30s Mac default-group
gtimeout,40s local SSH wait, and55s Windows Job bound. It rechecked local
Directory Services, directory cache, getpwuid, and real/effective UID process
census: UID60001 was absent. It found no saturated-UID primitive worker, no
compiler with an exact fixture path, and no process retaining any exact build
working directory. This is a current cleanup observation, not a privileged test.

Every ordinary scratch source/binary and compiler output was copied through
held no-follow file descriptors, required to be a single regular UID501-owned
inode, and checked for stable identity and pinned source/binary hashes.
The exact directory inventory, inode identities, modes, hashes, raw query
output, downloaded bytes, and command are retained in before.json and its
raw stdout receipt. A complete local pre-removal ZIP was built and every member
checked against its SHA-256 INDEX before any ordinary scratch removal.

The subsequent removal step repeats ordinary worker/UID checks, opens only the
three named private UID501 scratch directories through /private/tmp, and compares
each directory and every file against the preserved exact identity/hash/mode
receipt. It unlinks only those known files through held directory descriptors,
revalidates each parent/name binding, and removes only the now-empty exact
directory. Any discrepancy refuses cleanup. No recursive, root, guessed-name,
or broad process cleanup is used. The removal receipt is included as-is; it
must be read to determine whether all three removals actually completed.

The ordinary directories are:

* /private/tmp/ptg-saturated-uid-build-001.AYrG3fc4
* /private/tmp/ptg-saturated-uid-build-002.dmQM2CNt
* /private/tmp/ptg-saturated-uid-transfer-002.iUlJHNHK

All archive members except INDEX.json have exact byte length and SHA-256 in
INDEX.json. Raw build and refusal receipts are unchanged. The local pre-removal
archive is deliberately excluded from the public ZIP to avoid recursive copies;
its digest is recorded separately, and all of its evidence members are included
directly in the public archive together with subsequent cleanup receipts.

Open: administrator execution of corrected source002 and independent native
cleanup validation, subject to fresh source/tool review and explicit permission
to resume Mac administrator tests. Even a future primitive pass would establish
only fixed-M8 sequential credential-accounting cases6,7,8. Fork-publication
fencing, supervisor-death custody, adversarial bounded cleanup, complete Mac
backend guarantees, and performance remain outside this primitive's proof scope.
