"""Verify package continuity and write preservation/cleanup summary, no native launches."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
arm=HERE.parent/"issue1-saturated-uid-transfer-002"
root=arm/"root-preparation-002"
assert sha(root/"root-plan.json")=="c826f08e070b6c9eed615574ceda9e74a8185aede630504a1d65742bf654cbde"
plan=json.loads((root/"root-plan.json").read_bytes())
for name,digest in plan["files"].items():assert sha(root/name)==digest,name
out=(root/"root.stdout.log").read_bytes()
err=(root/"root.stderr.log").read_bytes()
assert (root/"root.ssh-exit.txt").read_bytes()==b"1"
assert b"gtimeout: OK"in out and b"sudo: a password is required"in err
assert not any(s in out+err for s in (b"CONTROLLER_CONTEXT=",b"ROOT_SCRATCH=",b"PRIMITIVE_ARGV=",b'"kind":"context"'))
before=json.loads((HERE/"before.json").read_bytes())
removed=json.loads((HERE/"removal.json").read_bytes())
assert set(before["directories"])==set(removed["directories"])
assert before["checks"]==removed["checks"]
for path,row in before["directories"].items():
    final=removed["directories"][path]
    assert final["removed"]is True and final["identity"]==row["identity"]
    assert set(final["exact_files"])==set(row["files"])
    for name,info in row["files"].items():
        p=HERE/"native-artifacts"/path.rsplit("/",1)[-1]/name
        assert p.stat().st_size==info["bytes"] and sha(p)==info["sha256"]
pre=HERE/"pre-removal.zip"
assert sha(pre)=="d4d7317a48fc4fb6e177d33709d8286d794482f30dfdfb91c793ccf1b0c5e686"
with zipfile.ZipFile(pre)as z:
    assert z.testzip()is None
    index=json.loads(z.read("INDEX.json"))
    for name,info in index.items():
        raw=z.read(name)
        assert len(raw)==info["bytes"]and hashlib.sha256(raw).hexdigest()==info["sha256"]
# Avoid publishing recognizable credential tokens from incidental host query
# output. This check reports only categories/counts, never matched values.
patterns={"github_token":rb"(?:ghp_|github_pat_)[A-Za-z0-9_]{20,}",
          "openai_key":rb"sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}",
          "aws_access_key":rb"(?:AKIA|ASIA)[A-Z0-9]{16}",
          "private_key":rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"}
counts={key:0 for key in patterns}
for p in HERE.glob("*.stdout.log"):
    raw=p.read_bytes()
    for name,pattern in patterns.items():counts[name]+=len(re.findall(pattern,raw))
assert not any(counts.values()),"Potential credential pattern; public packaging refused without exposing values"
summary={"schema":1,"state":"admin_deferred_sudo_refused_before_controller_primitive",
         "attempted_plan_sha256":sha(root/"root-plan.json"),"ssh_exit":1,
         "root_controller_started":False,"primitive_started":False,"target_uid_transfers":0,
         "ordinary_before_receipt_sha256":sha(HERE/"before.json"),
         "ordinary_removal_receipt_sha256":sha(HERE/"removal.json"),
         "pre_removal_archive":{"sha256":sha(pre),"bytes":pre.stat().st_size,"members":len(index)+1},
         "ordinary_directories_removed":{k:v["identity"]for k,v in removed["directories"].items()},
         "uid60001_absent":True,"exact_fixture_workers_and_cwd_users":0,
         "recognizable_credential_pattern_counts":counts,
         "scope":"No new native or admin test; ordinary preservation/identity-bound cleanup only",
         "remaining":"Mac admin validation issue; no further authentication attempt"}
with(HERE/"FINAL_STATUS.json").open("x",encoding="utf-8",newline="\n")as f:f.write(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary,indent=2))
