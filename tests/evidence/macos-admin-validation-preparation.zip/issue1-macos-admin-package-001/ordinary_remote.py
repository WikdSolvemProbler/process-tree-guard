"""Ordinary read-only preservation or exact owned artifact cleanup. No test execution."""
import base64
import hashlib
import json
import os
import pwd
import stat
import subprocess
import sys

PATHS = [
    "/private/tmp/ptg-saturated-uid-build-001.AYrG3fc4",
    "/private/tmp/ptg-saturated-uid-build-002.dmQM2CNt",
    "/private/tmp/ptg-saturated-uid-transfer-002.iUlJHNHK",
]
PINS = {
    PATHS[0]: {"saturated_uid.c": "12252db8cb1c38dcc98c1bfc81dfe2e9427a6a9a0110d293d587490597f490e5"},
    PATHS[1]: {"saturated_uid.c": "12252db8cb1c38dcc98c1bfc81dfe2e9427a6a9a0110d293d587490597f490e5",
               "saturated-uid": "3f05d8a37dadac23cff602b6628b81f8138d0dad151d05405643ee5050fd722b"},
    PATHS[2]: {"saturated_uid.c": "4b72fcbf0f54d38120c2ec9878735e76c2d1b551fd79c458ac149d88653c527b",
               "saturated-uid": "39e4c7ba2bf024189331e4431a8d86b4b115a78017f66a2588b7da26ce1a19a4"},
}
def demand(v, text):
    if not v:
        raise RuntimeError(text)
def ident(s):
    return [s.st_dev, s.st_ino]
def query(argv, allowed=(0,)):
    r = subprocess.run(argv, capture_output=True, text=True, timeout=4)
    row = {"argv": argv, "exit":r.returncode,"stdout":r.stdout,"stderr":r.stderr}
    print("QUERY="+json.dumps(row), flush=True)
    demand(r.returncode in allowed, "ordinary query refused")
    return r
def check_workers():
    ps = query(["/bin/ps","-axo","pid=,ppid=,pgid=,ruid=,uid=,comm=,args="])
    selected=[]
    for line in ps.stdout.splitlines():
        v=line.split(None,6)
        demand(len(v)>=6,"malformed ps row")
        pid,parent,group,ruid,euid=map(int,v[:5])
        command=v[5]
        args=v[6] if len(v)==7 else ""
        # Match actual executable field, not this inspector's embedded source.
        is_primitive=command.endswith("/saturated-uid") or command=="saturated-uid"
        is_compiler=command.rsplit("/",1)[-1] in ("clang","clang-21","cc1")
        exact_path=any(p in args or p.replace("/private/tmp/","/tmp/") in args for p in PATHS)
        if is_primitive or (is_compiler and exact_path) or ruid==60001 or euid==60001:
            selected.append({"pid":pid,"parent":parent,"group":group,"ruid":ruid,"euid":euid,
                             "command":command,"args":args})
    demand(not selected,"exact primitive/compiler or target UID process remains")
    # Exact build working directories cover relative-argv compiler workers.
    cwd=query(["/usr/sbin/lsof","-nP","-Fpcn","-a","-d","cwd","--",*PATHS],(0,1))
    demand(cwd.returncode==1 and not cwd.stdout.strip(),"a process retains an exact build cwd")
    ds=query(["/usr/bin/dscl",".","-search","/Users","UniqueID","60001"])
    cache=query(["/usr/bin/dscacheutil","-q","user","-a","uid","60001"])
    demand(not ds.stdout.strip() and not cache.stdout.strip(),"UID60001 has an account/cache entry")
    try:
        pwd.getpwuid(60001)
    except KeyError:
        pass
    else:
        raise RuntimeError("UID60001 resolves through getpwuid")
    return {"selected_workers":selected,"exact_build_cwd_users":[],"target_uid":60001,
            "uid_account_absent":True,"uid_real_effective_processes":0}

def file_data(dirfd,name):
    fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=dirfd)
    try:
        s=os.fstat(fd)
        demand(stat.S_ISREG(s.st_mode) and s.st_uid==501 and s.st_nlink==1,"not one ordinary-owned regular file")
        demand(0<=s.st_size<=32*1024*1024,"unexpected artifact size")
        data=bytearray()
        while len(data)<=32*1024*1024:
            part=os.read(fd,65536)
            if not part:break
            data.extend(part)
        t=os.fstat(fd)
        demand((ident(s),s.st_size,s.st_mtime_ns,s.st_ctime_ns)==
               (ident(t),t.st_size,t.st_mtime_ns,t.st_ctime_ns),"artifact changed while reading")
        demand(ident(os.stat(name,dir_fd=dirfd,follow_symlinks=False))==ident(s),"artifact name changed")
        return {"identity":ident(s),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),
                "mode":stat.S_IMODE(s.st_mode),"data_b64":base64.b64encode(data).decode("ascii")}
    finally:os.close(fd)

mode=sys.argv[1]
demand(os.getuid()==501 and os.geteuid()==501,"ordinary UID501 required")
checks=check_workers()
expected=json.loads(sys.stdin.read()) if mode=="remove" else None
result={"mode":mode,"uid":os.getuid(),"checks":checks,"directories":{}}
parent=os.open("/private/tmp",os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
try:
    for path in PATHS:
        demand(os.path.realpath(path)==path,"scratch path not canonical")
        leaf=path.rsplit("/",1)[-1]
        fd=os.open(leaf,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent)
        try:
            s=os.fstat(fd)
            demand(s.st_uid==501 and stat.S_IMODE(s.st_mode)==0o700,"not a private ordinary-owned scratch")
            allowed={"saturated_uid.c","compile.stdout.log","compile.stderr.log","compile.exit.txt"}
            if path!=PATHS[0]:allowed.add("saturated-uid")
            demand(set(os.listdir(fd))==allowed,"unexpected scratch inventory")
            files={name:file_data(fd,name) for name in sorted(allowed)}
            for name,pin in PINS[path].items():demand(files[name]["sha256"]==pin,"source/binary pin differs")
            row={"identity":ident(s),"uid":s.st_uid,"mode":stat.S_IMODE(s.st_mode),"files":files}
            if mode=="remove":
                old=expected["directories"][path]
                demand(old["identity"]==ident(s),"scratch identity differs from preserved receipt")
                demand(set(old["files"])==set(files),"preserved inventory differs")
                for name,data in files.items():
                    demand(all(data[k]==old["files"][name][k] for k in ("identity","bytes","sha256","mode")),
                           "preserved artifact changed")
                demand(ident(os.stat(leaf,dir_fd=parent,follow_symlinks=False))==ident(s),"scratch name changed")
                for name in files:os.unlink(name,dir_fd=fd)
                demand(ident(os.stat(leaf,dir_fd=parent,follow_symlinks=False))==ident(s),"scratch name changed before rmdir")
                os.rmdir(leaf,dir_fd=parent)
                demand(not os.path.lexists(path),"scratch removal unverified")
                row={"identity":ident(s),"removed":True,"exact_files":list(files)}
            result["directories"][path]=row
        finally:os.close(fd)
finally:os.close(parent)
print("RESULT="+json.dumps(result),flush=True)
