"""Run only finite ordinary custody/census steps, or build preservation ZIPs."""
import ast
import base64
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys
import zipfile

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]
SOURCE=HERE/"ordinary_remote.py"
TOOL="/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(mode):
    ast.parse(SOURCE.read_text(encoding="utf-8"))
    prefix="before" if mode=="collect" else "removal"
    command=shlex.join([TOOL,"--signal=KILL","--kill-after=3s","30s","/usr/bin/python3","-I","-B","-c",SOURCE.read_text(encoding="utf-8"),mode])+"\n"
    with(HERE/(prefix+"-command.txt")).open("x",encoding="utf-8",newline="\n")as f:f.write(command)
    data=None
    if mode=="remove":
        verify_zip(HERE/"pre-removal.zip")
        data=(HERE/"before.json").read_bytes()
    r=subprocess.run(["C:/Windows/System32/OpenSSH/ssh.exe","-T","-o","BatchMode=yes","-o","StrictHostKeyChecking=yes","-o","ConnectTimeout=8","peters-mac-mini",command],input=data,capture_output=True,timeout=40)
    for suffix,content in [(".stdout.log",r.stdout),(".stderr.log",r.stderr),(".exit.txt",str(r.returncode).encode())]:
        with(HERE/(prefix+suffix)).open("xb")as f:f.write(content)
    if r.returncode:raise RuntimeError("ordinary "+mode+" refused; preserve raw receipts")
    records=[line[7:] for line in r.stdout.splitlines()if line.startswith(b"RESULT=")]
    assert len(records)==1
    result=json.loads(records[0])
    with(HERE/(prefix+".json")).open("x",encoding="utf-8",newline="\n")as f:f.write(json.dumps(result,indent=2)+"\n")
    if mode=="collect":
        for path,row in result["directories"].items():
            dest=HERE/"native-artifacts"/path.rsplit("/",1)[-1]
            dest.mkdir(parents=True)
            for name,info in row["files"].items():
                content=base64.b64decode(info["data_b64"],validate=True)
                assert hashlib.sha256(content).hexdigest()==info["sha256"]
                with(dest/name).open("xb")as f:f.write(content)
    print(json.dumps({"mode":mode,"exit":r.returncode,"receipt_sha256":sha(HERE/(prefix+".json")),
                      "directories":{k:({"identity":v["identity"],"files":len(v["files"])} if mode=="collect"else v)for k,v in result["directories"].items()}},indent=2))

def archive(path):
    assert not path.exists()
    files=[]
    for root in [HERE.parent/"issue1-saturated-uid-transfer-001",HERE.parent/"issue1-saturated-uid-transfer-002",HERE]:
        for p in root.rglob("*"):
            if p.is_file() and p.suffix!=".zip" and "__pycache__"not in p.parts:
                files.append(p)
    files=sorted(set(files))
    index={str(p.relative_to(HERE.parent)).replace('\\','/'):{"bytes":p.stat().st_size,"sha256":sha(p)}for p in files}
    with zipfile.ZipFile(path,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in files:z.write(p,str(p.relative_to(HERE.parent)).replace('\\','/'))
        z.writestr("INDEX.json",json.dumps(index,indent=2)+"\n")
    verify_zip(path)
    print(json.dumps({"archive":str(path),"sha256":sha(path),"bytes":path.stat().st_size,"members":len(index)+1},indent=2))
def verify_zip(path):
    with zipfile.ZipFile(path)as z:
        assert z.testzip() is None
        index=json.loads(z.read("INDEX.json"))
        assert set(z.namelist())==set(index)|{"INDEX.json"}
        for name,info in index.items():
            data=z.read(name)
            assert len(data)==info["bytes"]and hashlib.sha256(data).hexdigest()==info["sha256"]

if sys.argv[1]in("collect","remove"):run(sys.argv[1])
elif sys.argv[1]=="prearchive":archive(HERE/"pre-removal.zip")
elif sys.argv[1]=="archive":archive(REPO/"tests/evidence/macos-admin-validation-preparation.zip")
else:raise RuntimeError("unknown action")
