// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Peter Shiller
#define _DARWIN_C_SOURCE
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/sysctl.h>
#include <sys/wait.h>
#include <sys/proc_info.h>
#include <sys/proc.h>
#include <libproc.h>
#include <errno.h>
#include <grp.h>
#include <limits.h>
#include <poll.h>
#include <pwd.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define FLOOR 8
#define MAX_OWNED 9

static volatile sig_atomic_t stopped;
static uint64_t deadline_ns;
static uint64_t final_deadline_ns;
static pid_t owned[MAX_OWNED];
static size_t owned_count;
static pid_t fixture_group;
static uid_t target_uid;

struct report {
    int stage;
    int transfer_errno;
    int credential_stage;
    int limit_errno;
    uid_t ruid, euid;
    gid_t rgid, egid;
    int groups_count;
    gid_t group_gid;
    int group_errno;
    uint64_t soft, hard;
    int fork_errno;
    pid_t fork_pid;
    int fork_status;
    int group_ok;
};

static void stop_signal(int value) {
    (void)value;
    stopped = 1;
}

static uint64_t now_ns(void) {
    struct timespec value;
    if (clock_gettime(CLOCK_MONOTONIC, &value) != 0) return UINT64_MAX;
    return (uint64_t)value.tv_sec * 1000000000ULL + (uint64_t)value.tv_nsec;
}

static int active(void) {
    return !stopped && now_ns() < deadline_ns;
}

static int await_fd(int fd, short events) {
    while (active()) {
        struct pollfd entry = {fd, events, 0};
        int result = poll(&entry, 1, 50);
        if (result > 0) return (entry.revents & events) != 0;
        if (result < 0 && errno != EINTR) return 0;
    }
    return 0;
}

static int transfer(int fd, void *buffer, size_t bytes, int writing) {
    unsigned char *pointer = buffer;
    size_t done = 0;
    while (done < bytes) {
        if (!await_fd(fd, writing ? POLLOUT : POLLIN)) return 0;
        ssize_t count = writing ? write(fd, pointer + done, bytes - done)
                                : read(fd, pointer + done, bytes - done);
        if (count > 0) done += (size_t)count;
        else if (count == 0 || errno != EINTR) return 0;
    }
    return 1;
}

static int bsd_info(pid_t pid, struct proc_bsdinfo *info) {
    memset(info, 0, sizeof(*info));
    return proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, info, sizeof(*info)) == (int)sizeof(*info);
}

static int unused_uid(uid_t uid) {
    int mib[] = {CTL_KERN, KERN_PROC, KERN_PROC_UID, (int)uid};
    size_t size = 0;
    errno = 0;
    if (getpwuid(uid) != NULL || errno != 0) return 0;
    return sysctl(mib, 4, NULL, &size, NULL, 0) == 0 && size == 0;
}

static int add_owned(pid_t pid) {
    if (pid <= 0 || owned_count == MAX_OWNED) return 0;
    owned[owned_count++] = pid;
    return 1;
}

static int reap_owned(pid_t pid, int expected) {
    while (active()) {
        int status = 0;
        pid_t result = waitpid(pid, &status, WNOHANG);
        if (result == pid) {
            for (size_t index = 0; index < owned_count; index++) {
                if (owned[index] == pid) owned[index] = 0;
            }
            return WIFEXITED(status) && WEXITSTATUS(status) == expected;
        }
        if (result < 0 && errno != EINTR) return 0;
        struct timespec pause = {0, 1000000};
        (void)nanosleep(&pause, NULL);
    }
    return 0;
}

static int permanent_drop(int *failed_stage) {
    gid_t group = (gid_t)target_uid;
    *failed_stage = 1;
    if (setgroups(1, &group) != 0) return errno;
    *failed_stage = 2;
    if (setgid(group) != 0) return errno;
    *failed_stage = 3;
    if (setuid(target_uid) != 0) return errno;
    *failed_stage = 4;
    gid_t returned = 0;
    int count = getgroups(0, NULL);
    if (count < 0) return errno;
    if (count != 1) return EINVAL;
    int copied = getgroups(1, &returned);
    if (copied < 0) return errno;
    if (getuid() != target_uid || geteuid() != target_uid
        || getgid() != group || getegid() != group || group == 0
        || copied != 1 || returned != group) return EINVAL;
    *failed_stage = 0;
    return 0;
}

static void verifier_report(struct report *out, int stage) {
    struct rlimit limits = {0, 0};
    memset(out, 0, sizeof(*out));
    out->stage = stage;
    out->ruid = getuid();
    out->euid = geteuid();
    out->rgid = getgid();
    out->egid = getegid();
    out->groups_count = getgroups(0, NULL);
    if (out->groups_count < 0) out->group_errno = errno;
    else if (out->groups_count == 1 && getgroups(1, &out->group_gid) != 1)
        out->group_errno = errno;
    out->group_ok = getpgrp() == fixture_group;
    if (getrlimit(RLIMIT_NPROC, &limits) != 0) out->limit_errno = errno;
    out->soft = limits.rlim_cur;
    out->hard = limits.rlim_max;
}

static void fork_trial(struct report *out) {
    errno = 0;
    pid_t child = fork();
    out->fork_pid = child;
    out->fork_errno = child < 0 ? errno : 0;
    if (child == 0) _exit(getpgrp() == fixture_group ? 23 : 93);
    if (child < 0) return;
    while (active()) {
        int status = 0;
        pid_t result = waitpid(child, &status, WNOHANG);
        if (result == child) {
            out->fork_status = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
            return;
        }
        if (result < 0 && errno != EINTR) break;
        struct timespec pause = {0, 1000000};
        (void)nanosleep(&pause, NULL);
    }
    // This remains an unreaped exact child identity until this cleanup.
    (void)kill(child, SIGKILL);
    uint64_t cleanup_until = now_ns() + 1000000000ULL;
    if (cleanup_until > final_deadline_ns) cleanup_until = final_deadline_ns;
    while (now_ns() < cleanup_until) {
        pid_t result = waitpid(child, NULL, WNOHANG);
        if (result == child || (result < 0 && errno != EINTR)) break;
        struct timespec pause = {0, 1000000};
        (void)nanosleep(&pause, NULL);
    }
    out->fork_status = -2;
}

static void verifier(int reports, int commands) {
    struct rlimit limits = {FLOOR, FLOOR};
    struct report first, second;
    if (setrlimit(RLIMIT_NPROC, &limits) != 0) _exit(80);
    int credential_stage = 0;
    int transfer_errno = permanent_drop(&credential_stage);
    verifier_report(&first, 1);
    first.transfer_errno = transfer_errno;
    first.credential_stage = credential_stage;
    if (!transfer_errno) fork_trial(&first);
    if (!transfer(reports, &first, sizeof(first), 1)) _exit(81);
    unsigned char permit = 0;
    if (!transfer(commands, &permit, 1, 0) || permit != 'R') _exit(82);
    if (transfer_errno) transfer_errno = permanent_drop(&credential_stage);
    verifier_report(&second, 2);
    second.transfer_errno = transfer_errno;
    second.credential_stage = credential_stage;
    if (!transfer_errno) fork_trial(&second);
    if (!transfer(reports, &second, sizeof(second), 1)) _exit(83);
    _exit(0);
}

static int retain_reserve(pid_t child) {
    while (active()) {
        siginfo_t value;
        memset(&value, 0, sizeof(value));
        if (waitid(P_PID, (id_t)child, &value, WEXITED | WNOWAIT | WNOHANG) != 0) return 0;
        if (value.si_pid == child) {
            struct proc_bsdinfo info;
            return value.si_code == CLD_EXITED && value.si_status == 0
                && bsd_info(child, &info) && info.pbi_ppid == (uint32_t)getpid()
                && info.pbi_ruid == target_uid && info.pbi_uid == target_uid
                && info.pbi_status == SZOMB && getpgrp() == fixture_group;
        }
        struct timespec pause = {0, 1000000};
        (void)nanosleep(&pause, NULL);
    }
    return 0;
}

static const char *credential_name(int stage) {
    switch (stage) {
        case 0: return "complete";
        case 1: return "setgroups";
        case 2: return "setgid";
        case 3: return "setuid";
        case 4: return "readback";
    }
    return "invalid";
}

static void print_report(int reserves, const struct report *value) {
    const char *stage = credential_name(value->credential_stage);
    printf("{\"kind\":\"verifier\",\"reserves\":%d,\"stage\":%d,"
           "\"transfer_errno\":%d,\"credential_stage\":\"%s\",\"ruid\":%u,\"euid\":%u,"
           "\"rgid\":%u,\"egid\":%u,\"soft\":%llu,\"hard\":%llu,"
           "\"groups_count\":%d,\"group_gid\":%u,\"group_errno\":%d,"
           "\"limit_errno\":%d,\"fork_pid\":%d,\"fork_errno\":%d,"
           "\"fork_status\":%d,\"group_ok\":%d}\n",
           reserves, value->stage, value->transfer_errno, stage, value->ruid, value->euid,
           value->rgid, value->egid, (unsigned long long)value->soft,
           (unsigned long long)value->hard, value->groups_count, value->group_gid,
           value->group_errno, value->limit_errno,
           value->fork_pid, value->fork_errno, value->fork_status, value->group_ok);
    fflush(stdout);
}

static int report_valid(const struct report *value) {
    if (value->limit_errno || value->soft != FLOOR || value->hard != FLOOR || !value->group_ok)
        return 0;
    return value->transfer_errno || (value->ruid == target_uid && value->euid == target_uid
                                    && value->rgid == target_uid && value->egid == target_uid
                                    && value->credential_stage == 0 && value->groups_count == 1
                                    && value->group_gid == (gid_t)target_uid && !value->group_errno);
}

static int run_case(int count) {
    pid_t reserves[FLOOR] = {0};
    int reports[2] = {-1, -1}, commands[2] = {-1, -1};
    int passed = 0;
    struct report first, second;
    if (!unused_uid(target_uid)) return 0;
    owned_count = 0;
    for (int index = 0; index < count; index++) {
        pid_t child = fork();
        if (child == 0) {
            int stage = 0;
            int error = permanent_drop(&stage);
            if (error) {
                printf("{\"kind\":\"reserve_credential_error\",\"pid\":%d,"
                       "\"credential_stage\":\"%s\",\"errno\":%d}\n",
                       getpid(), credential_name(stage), error);
                fflush(stdout);
            }
            _exit(error == 0 && getpgrp() == fixture_group ? 0 : 90);
        }
        if (!add_owned(child)) return 0;
        reserves[index] = child;
        if (!retain_reserve(child)) return 0;
        printf("{\"kind\":\"reserve\",\"reserves\":%d,\"index\":%d,"
               "\"pid\":%d,\"parent\":%d,\"ruid\":%u,\"retained\":true}\n",
               count, index, child, getpid(), target_uid);
        fflush(stdout);
    }
    if (pipe(reports) != 0 || pipe(commands) != 0) goto done;
    pid_t child = fork();
    if (child == 0) {
        close(reports[0]);
        close(commands[1]);
        verifier(reports[1], commands[0]);
    }
    if (!add_owned(child)) goto done;
    close(reports[1]); reports[1] = -1;
    close(commands[0]); commands[0] = -1;
    if (!transfer(reports[0], &first, sizeof(first), 0)) goto done;
    print_report(count, &first);
    if (!report_valid(&first)) goto done;
    if (count == 6 && (first.transfer_errno || first.fork_errno || first.fork_status != 23))
        goto done;
    if (count == 7 && (first.transfer_errno || first.fork_pid != -1 || first.fork_errno != EAGAIN))
        goto done;
    if (count == 8 && first.transfer_errno != 0 && first.transfer_errno != EAGAIN) goto done;
    if (count == 8 && !first.transfer_errno && (first.fork_pid != -1 || first.fork_errno != EAGAIN))
        goto done;
    int release_count = count == 8 ? 2 : 1;
    for (int index = 0; index < release_count; index++) {
        if (!reap_owned(reserves[index], 0)) goto done;
        printf("{\"kind\":\"explicit_reap\",\"reserves\":%d,\"pid\":%d}\n",
               count, reserves[index]);
        fflush(stdout);
        reserves[index] = 0;
    }
    unsigned char permit = 'R';
    if (!transfer(commands[1], &permit, 1, 1)
        || !transfer(reports[0], &second, sizeof(second), 0)) goto done;
    print_report(count, &second);
    if (!report_valid(&second) || second.transfer_errno || second.fork_errno
        || second.fork_status != 23 || !reap_owned(child, 0)) goto done;
    for (int index = 0; index < count; index++) {
        if (reserves[index] && !reap_owned(reserves[index], 0)) goto done;
    }
    if (!unused_uid(target_uid)) goto done;
    printf("{\"kind\":\"case\",\"reserves\":%d,\"valid\":true,"
           "\"full_uid_transfer\":\"%s\",\"uid_empty\":true}\n",
           count, first.transfer_errno ? "denied" : "allowed");
    passed = 1;
done:
    for (int index = 0; index < 2; index++) {
        if (reports[index] >= 0) close(reports[index]);
        if (commands[index] >= 0) close(commands[index]);
    }
    return passed;
}

static int cleanup(void) {
    int complete = 1;
    for (size_t index = 0; index < owned_count; index++) {
        if (owned[index] > 0) (void)kill(owned[index], SIGKILL);
    }
    uint64_t until = now_ns() + 1000000000ULL;
    if (until > final_deadline_ns) until = final_deadline_ns;
    for (size_t index = 0; index < owned_count; index++) {
        if (owned[index] <= 0) continue;
        int settled = 0;
        while (now_ns() < until) {
            pid_t result = waitpid(owned[index], NULL, WNOHANG);
            if (result == owned[index]) { settled = 1; break; }
            if (result < 0 && errno != EINTR) break;
            struct timespec pause = {0, 1000000};
            (void)nanosleep(&pause, NULL);
        }
        if (!settled) complete = 0;
    }
    return complete;
}

int main(int argc, char **argv) {
    struct proc_bsdinfo parent;
    char parent_image[PROC_PIDPATHINFO_MAXSIZE];
    char expected[PATH_MAX], observed[PATH_MAX];
    char *end = NULL;
    if (argc != 3 || getuid() != 0 || geteuid() != 0) return 64;
    unsigned long requested = strtoul(argv[1], &end, 10);
    if (!end || *end || requested < 60000 || requested > INT_MAX) return 64;
    target_uid = (uid_t)requested;
    fixture_group = getpgrp();
    if (fixture_group != getppid() || fixture_group == getpid()
        || !bsd_info(getppid(), &parent) || parent.pbi_ruid != 0
        || proc_pidpath(getppid(), parent_image, sizeof(parent_image)) <= 0
        || !realpath(argv[2], expected) || !realpath(parent_image, observed)
        || strcmp(expected, observed) != 0 || !unused_uid(target_uid)) return 65;
    uint64_t origin = now_ns();
    if (origin == UINT64_MAX) return 66;
    deadline_ns = origin + 14000000000ULL;
    final_deadline_ns = origin + 15000000000ULL;
    struct sigaction action;
    memset(&action, 0, sizeof(action));
    action.sa_handler = stop_signal;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGALRM, &action, NULL) || sigaction(SIGTERM, &action, NULL)
        || sigaction(SIGINT, &action, NULL)) return 66;
    signal(SIGPIPE, SIG_IGN);
    signal(SIGCHLD, SIG_DFL);
    alarm(15);
    printf("{\"kind\":\"context\",\"pid\":%d,\"pgid\":%d,\"root_gtimeout_pid\":%d,"
           "\"target_uid\":%u,\"M\":8,\"payload_runs\":0}\n",
           getpid(), fixture_group, getppid(), target_uid);
    fflush(stdout);
    int passed = run_case(6) && run_case(7) && run_case(8);
    int cleaned = cleanup();
    alarm(0);
    int empty = unused_uid(target_uid);
    printf("{\"kind\":\"terminal\",\"valid\":%s,\"exact_children_reaped\":%s,"
           "\"uid_empty\":%s,\"deadline_hit\":%s,\"payload_runs\":0}\n",
           passed && cleaned && empty && active() ? "true" : "false",
           cleaned ? "true" : "false", empty ? "true" : "false",
           active() ? "false" : "true");
    return passed && cleaned && empty && active() ? 0 : 1;
}
