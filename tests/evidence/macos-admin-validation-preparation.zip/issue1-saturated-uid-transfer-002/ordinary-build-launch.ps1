$ErrorActionPreference='Stop'
$directory=$PSScriptRoot
$source=[IO.File]::ReadAllBytes("$directory/saturated_uid.c")
$sha=[Security.Cryptography.SHA256]::HashData($source)
if ([Convert]::ToHexString($sha).ToLowerInvariant() -ne '4b72fcbf0f54d38120c2ec9878735e76c2d1b551fd79c458ac149d88653c527b') {
    throw 'saturated UID source differs before upload'
}
$command=[IO.File]::ReadAllText("$directory/ordinary-build-command.txt")
$info=[Diagnostics.ProcessStartInfo]::new()
$info.FileName='C:/Windows/System32/OpenSSH/ssh.exe'
$info.UseShellExecute=$false
$info.CreateNoWindow=$true
$info.RedirectStandardInput=$true
$info.RedirectStandardOutput=$true
$info.RedirectStandardError=$true
foreach($argument in '-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8','peters-mac-mini',$command){
    $info.ArgumentList.Add($argument)
}
$out=[IO.File]::Open("$directory/ordinary-build.stdout.log",'CreateNew','Write','Read')
$err=[IO.File]::Open("$directory/ordinary-build.stderr.log",'CreateNew','Write','Read')
try {
    $process=[Diagnostics.Process]::Start($info)
    $copyOut=$process.StandardOutput.BaseStream.CopyToAsync($out)
    $copyErr=$process.StandardError.BaseStream.CopyToAsync($err)
    $transferError=$null
    try { $process.StandardInput.BaseStream.Write($source,0,$source.Length) } catch { $transferError=$_ }
    finally { $process.StandardInput.Close() }
    if (-not $process.WaitForExit(55000)) {
        $process.Kill($true)
        throw 'ordinary SSH compile exceeded local 55 second deadline'
    }
    $copyOut.GetAwaiter().GetResult()
    $copyErr.GetAwaiter().GetResult()
    $result=$process.ExitCode
    [IO.File]::WriteAllText("$directory/ordinary-build.ssh-exit.txt",[string]$result)
    if($null -ne $transferError){ throw $transferError }
} finally {
    $out.Dispose()
    $err.Dispose()
}
Get-Content "$directory/ordinary-build.stdout.log","$directory/ordinary-build.stderr.log"
exit $result
