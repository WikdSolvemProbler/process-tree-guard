# Prepared Mac saturated-UID control, corrected source002

PREPARED ONLY. No privileged execution occurred in preparation. Parent review of
this exact plan is required before using approved-local-argv.json. The source001
draft and both source001 ordinary compile outcomes remain unchanged; source002's
ordinary compile and exact binary are pinned alongside its corrected protocol.

The exact native argv is the private root binary, numeric UID60001, and canonical
/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout. The same pinned gtimeout creates
the direct native parent and default process group. Native context must report
that exact Popen PID as both group and root timeout parent. No foreground flag,
new session, group-changing operation, arbitrary payload, account creation, global
setting change, fork churn, or kill(-1) is introduced. M=8, cases6,7,8 only.

All source/binary input bytes are opened no-follow, read/hash checked through held
FDs with stable identities, then copied and rehashed in a fresh root-owned0700
scratch directory. A fresh local-DS, cache, getpwuid, and real/effective process
census must show UID60001 unused immediately before execution. The controller is
bounded by root gtimeout40s; primitive gtimeout25s independently bounds its own
group, with a3s KILL setting. Mac65s and Windows Job100s cover the enclosing chain.
The C has its separate14s work and15s absolute cleanup/alarm budgets.

Primitive stdout/stderr chunks are retained immediately as base64-labeled stream
receipts, followed by exact full streams and exit. A failed/interrupted run cannot
qualify. A successful native terminal, exact child reaps, all three valid cases,
independent final UID emptiness and exact native group emptiness are prerequisites
to root artifact removal. Deletion checks held directory and exact root-owned file
identities; any uncertainty leaves artifacts untouched for explicit quarantine.
An abrupt outer stop may leave those artifacts; do not guess identities or erase
them. No account/global state is restored because none is changed.

This relies on the trusted local administrator and Apple system utilities. The
installed Homebrew gtimeout path and held inode are rehashed before/after; this
does not establish an executable-replacement defense against a hostile local
administrator. The primitive's descendants do not execute an external payload.

A pass is limited to this sequential saturated-UID credential-accounting control.
It does not prove an in-flight fork-publication fence, supervisor-death custody,
adversarial bounded cleanup, a production Mac backend, or benchmark performance.
