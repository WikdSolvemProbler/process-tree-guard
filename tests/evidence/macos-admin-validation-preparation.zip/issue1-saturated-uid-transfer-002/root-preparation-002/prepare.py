"""Review-only stream-preserving revision; no primitive is executed."""
import ast
import hashlib
import json
from pathlib import Path
import shlex

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "root-preparation-001"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old_plan = json.loads((OLD / "root-plan.json").read_bytes())
assert sha(OLD / "root-plan.json") == "02e62be0728070508f0d8f47f25b7f7c951ccd2082a169967186e4939c076ca5"
for name, digest in old_plan["files"].items():
    assert sha(OLD / name) == digest, name
source = (OLD / "root_controller.py").read_text(encoding="utf-8")
source = source.replace("import hashlib\n", "import base64\nimport hashlib\n")
source = source.replace("import pwd\n", "import pwd\nimport selectors\n")
old = '    native_stdout, native_stderr = child.communicate()\n'
assert source.count(old) == 1
source = source.replace(old, '''    captured = {"stdout": bytearray(), "stderr": bytearray()}
    # Stream each exact chunk before parsing, so deadline/error attempts retain
    # already-observed bytes in the transport receipt, including partial lines.
    with selectors.DefaultSelector() as selector:
        selector.register(child.stdout, selectors.EVENT_READ, "stdout")
        selector.register(child.stderr, selectors.EVENT_READ, "stderr")
        while selector.get_map():
            for key, events in selector.select(timeout=0.1):
                data = os.read(key.fileobj.fileno(), 4096)
                if not data:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                captured[key.data].extend(data)
                print("PRIMITIVE_STREAM=" + json.dumps({
                    "stream": key.data, "bytes_b64": base64.b64encode(data).decode("ascii"),
                }), flush=True)
    child.wait()
    native_stdout, native_stderr = bytes(captured["stdout"]), bytes(captured["stderr"])
''')
ast.parse(source, filename="root_controller.py")
with (HERE / "root_controller.py").open("x", encoding="utf-8", newline="\n") as f:
    f.write(source)
tool = old_plan["gtimeout"]["canonical_path"]
tool_hash = old_plan["gtimeout"]["sha256"]
controller_argv = [tool, "--signal=KILL", "--kill-after=3s", "40s", "/usr/bin/python3", "-I", "-B", "-c", source]
preflight = (
    "set -eu\n"
    "test \"$(/usr/bin/uname -m)\" = arm64\n"
    f"printf '%s  %s\\n' {shlex.quote(tool_hash)} {shlex.quote(tool)} | /usr/bin/shasum -a 256 -c -\n"
    "exec /usr/bin/sudo -n " + shlex.join(controller_argv) + "\n"
)
command = shlex.join([tool,"--signal=KILL","--kill-after=3s","65s","/bin/sh","-c",preflight])+"\n"
for name, value in [("root-preflight.sh",preflight),("root-command.txt",command),
                    ("root-launch.ps1",(OLD/"root-launch.ps1").read_text(encoding="utf-8"))]:
    with (HERE/name).open("x",encoding="utf-8",newline="\n") as f:
        f.write(value)
method = """# Prepared Mac saturated-UID control, corrected source002

PREPARED ONLY. No privileged execution occurred in preparation. Parent review of
this exact plan is required before using approved-local-argv.json. The source001
draft and both source001 ordinary compile outcomes remain unchanged; source002's
ordinary compile and exact binary are pinned alongside its corrected protocol.

The exact native argv is the private root binary, numeric UID60001, and canonical
/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout. The same pinned gtimeout creates
the direct native parent and default process group. Native context must report
that exact Popen PID as both group and root timeout parent. No foreground flag,
new session, group-changing operation, arbitrary payload, account creation, global
setting change, fork churn, or kill(-1) is introduced. M=8, cases6,7,8 only.

All source/binary input bytes are opened no-follow, read/hash checked through held
FDs with stable identities, then copied and rehashed in a fresh root-owned0700
scratch directory. A fresh local-DS, cache, getpwuid, and real/effective process
census must show UID60001 unused immediately before execution. The controller is
bounded by root gtimeout40s; primitive gtimeout25s independently bounds its own
group, with a3s KILL setting. Mac65s and Windows Job100s cover the enclosing chain.
The C has its separate14s work and15s absolute cleanup/alarm budgets.

Primitive stdout/stderr chunks are retained immediately as base64-labeled stream
receipts, followed by exact full streams and exit. A failed/interrupted run cannot
qualify. A successful native terminal, exact child reaps, all three valid cases,
independent final UID emptiness and exact native group emptiness are prerequisites
to root artifact removal. Deletion checks held directory and exact root-owned file
identities; any uncertainty leaves artifacts untouched for explicit quarantine.
An abrupt outer stop may leave those artifacts; do not guess identities or erase
them. No account/global state is restored because none is changed.

This relies on the trusted local administrator and Apple system utilities. The
installed Homebrew gtimeout path and held inode are rehashed before/after; this
does not establish an executable-replacement defense against a hostile local
administrator. The primitive's descendants do not execute an external payload.

A pass is limited to this sequential saturated-UID credential-accounting control.
It does not prove an in-flight fork-publication fence, supervisor-death custody,
adversarial bounded cleanup, a production Mac backend, or benchmark performance.
"""
with (HERE/"ROOT_PLAN.md").open("x",encoding="utf-8",newline="\n") as f:
    f.write(method)
plan = dict(old_plan)
plan["previous_preparation_sha256"] = sha(OLD/"root-plan.json")
plan["stream_preservation"] = "Immediate labeled base64 stdout/stderr chunks plus exact full streams; failed/partial attempts remain unevaluated"
names = list(old_plan["files"])
names.append("ROOT_PLAN.md")
plan["files"] = {name:sha(HERE/name) for name in names}
with (HERE/"root-plan.json").open("x",encoding="utf-8",newline="\n") as f:
    f.write(json.dumps(plan,indent=2)+"\n")
plan_sha = sha(HERE/"root-plan.json")
guard,pwsh = list(plan["local_executable_sha256"])[:2]
argv = [guard,"--timeout","100","--",pwsh,"-NoProfile","-NonInteractive","-File",
        str(HERE/"root-launch.ps1").replace('\\','/'),"-ApprovedPlanSha",plan_sha]
with (HERE/"approved-local-argv.json").open("x",encoding="utf-8",newline="\n") as f:
    f.write(json.dumps({"PREPARED_ONLY":True,"approved_plan_sha256":plan_sha,"argv":argv},indent=2)+"\n")
print(json.dumps({"prepared_only":True,"plan_sha256":plan_sha,
                  "controller_sha256":sha(HERE/"root_controller.py"),
                  "command_sha256":sha(HERE/"root-command.txt"),
                  "launcher_sha256":sha(HERE/"root-launch.ps1"),"files":len(plan["files"])},indent=2))
