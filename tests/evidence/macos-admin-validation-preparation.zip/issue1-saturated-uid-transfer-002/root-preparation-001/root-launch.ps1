param([Parameter(Mandatory=$true)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ApprovedPlanSha)
$ErrorActionPreference='Stop'
$directory=$PSScriptRoot
$planPath=Join-Path $directory 'root-plan.json'
if((Get-FileHash -LiteralPath $planPath).Hash -ne $ApprovedPlanSha){throw 'Reviewed root plan hash differs'}
$plan=[IO.File]::ReadAllText($planPath) | ConvertFrom-Json -AsHashtable
foreach($name in $plan.files.Keys){
    if((Get-FileHash -LiteralPath (Join-Path $directory $name)).Hash -ne $plan.files[$name]){
        throw "Reviewed source differs: $name"
    }
}
foreach($path in $plan.local_executable_sha256.Keys){
    if((Get-FileHash -LiteralPath $path).Hash -ne $plan.local_executable_sha256[$path]){
        throw "Reviewed local executable differs: $path"
    }
}
$command=[IO.File]::ReadAllText("$directory/root-command.txt")
$info=[Diagnostics.ProcessStartInfo]::new()
$info.FileName='C:/Windows/System32/OpenSSH/ssh.exe'
$info.UseShellExecute=$false
$info.CreateNoWindow=$true
$info.RedirectStandardInput=$true
$info.RedirectStandardOutput=$true
$info.RedirectStandardError=$true
foreach($argument in '-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8','peters-mac-mini',$command){
    $info.ArgumentList.Add($argument)
}
$out=[IO.File]::Open("$directory/root.stdout.log",'CreateNew','Write','Read')
$err=[IO.File]::Open("$directory/root.stderr.log",'CreateNew','Write','Read')
try {
    $process=[Diagnostics.Process]::Start($info)
    $process.StandardInput.Close()
    $copyOut=$process.StandardOutput.BaseStream.CopyToAsync($out)
    $copyErr=$process.StandardError.BaseStream.CopyToAsync($err)
    $process.WaitForExit()
    $copyOut.GetAwaiter().GetResult() | Out-Null
    $copyErr.GetAwaiter().GetResult() | Out-Null
    $result=$process.ExitCode
    [IO.File]::WriteAllText("$directory/root.ssh-exit.txt",[string]$result)
} finally {
    $out.Dispose()
    $err.Dispose()
}
exit $result
