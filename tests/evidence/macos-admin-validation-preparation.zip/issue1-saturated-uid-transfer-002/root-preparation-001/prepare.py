"""Build a review-only exact Mac launch from the preserved controller draft."""
import ast
import hashlib
import json
from pathlib import Path
import shlex

HERE = Path(__file__).resolve().parent
ARM = HERE.parent
OLD = ARM.parent / "issue1-saturated-uid-transfer-001"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pins = {
    "saturated_uid.c": "4b72fcbf0f54d38120c2ec9878735e76c2d1b551fd79c458ac149d88653c527b",
    "PROTOCOL.md": "a8fbc3971a43ff51c9cea732fd683c0e4483bc6be6ccb5513cab2de20aeef310",
    "native-build-001.json": "91b318bf334fbc41461d398771a509c5815c0da2588a2280172550beba22e610",
}
for name, expected in pins.items():
    assert sha(ARM / name) == expected, name
native = json.loads((ARM / "native-build-001.json").read_bytes())
assert native["binary"]["executed"] is False
assert native["binary"]["sha256"] == "39e4c7ba2bf024189331e4431a8d86b4b115a78017f66a2588b7da26ce1a19a4"
assert native["binary"]["path"] == "/tmp/ptg-saturated-uid-transfer-002.iUlJHNHK/saturated-uid"

source = (OLD / "root-preparation-001/root_controller.py").read_text(encoding="utf-8")
changes = {
    'SOURCE_DIR = "/private/tmp/ptg-saturated-uid-build-002.dmQM2CNt"':
        'SOURCE_DIR = "/private/tmp/ptg-saturated-uid-transfer-002.iUlJHNHK"',
    "12252db8cb1c38dcc98c1bfc81dfe2e9427a6a9a0110d293d587490597f490e5": pins["saturated_uid.c"],
    '"bytes": 13645, "max_bytes": 13645': '"bytes": 15541, "max_bytes": 15541',
    "3f05d8a37dadac23cff602b6628b81f8138d0dad151d05405643ee5050fd722b": native["binary"]["sha256"],
    'prefix="ptg-saturated-uid-root-001."': 'prefix="ptg-saturated-uid-root-002."',
}
for old, new in changes.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
# Preserve raw account/census evidence even when a prerequisite refuses.
source = source.replace(
    'capture_output=True, text=True, check=True, timeout=3,\n    )\n    rows = []',
    'capture_output=True, text=True, check=False, timeout=3,\n    )\n'
    '    print("PROCESS_CENSUS=" + json.dumps({"stdout": result.stdout, "stderr": result.stderr,\n'
    '          "exit": result.returncode}), flush=True)\n'
    '    demand(result.returncode == 0, "ps identity census refused")\n    rows = []',
)
source = source.replace(
    'result = subprocess.run(argv, capture_output=True, text=True, check=True, timeout=3)',
    'result = subprocess.run(argv, capture_output=True, text=True, check=False, timeout=3)'
)
source = source.replace(
    '        demand(not result.stdout.strip(), "target UID has an account/cache entry")',
    '        print("UID_QUERY=" + json.dumps({"phase": label, "query": key, **outputs[key]}), flush=True)\n'
    '        demand(result.returncode == 0, "target UID account/cache query refused")\n'
    '        demand(not result.stdout.strip(), "target UID has an account/cache entry")'
)
ast.parse(source, filename="root_controller.py")
with (HERE / "root_controller.py").open("x", encoding="utf-8", newline="\n") as f:
    f.write(source)

tool = native["gtimeout"]["canonical_path"]
tool_hash = native["gtimeout"]["sha256"]
controller_argv = [tool, "--signal=KILL", "--kill-after=3s", "40s", "/usr/bin/python3", "-I", "-B", "-c", source]
preflight = (
    "set -eu\n"
    "test \"$(/usr/bin/uname -m)\" = arm64\n"
    f"printf '%s  %s\\n' {shlex.quote(tool_hash)} {shlex.quote(tool)} | /usr/bin/shasum -a 256 -c -\n"
    "exec /usr/bin/sudo -n " + shlex.join(controller_argv) + "\n"
)
command = shlex.join([tool, "--signal=KILL", "--kill-after=3s", "65s", "/bin/sh", "-c", preflight]) + "\n"
for name, value in [("root-preflight.sh", preflight), ("root-command.txt", command)]:
    with (HERE / name).open("x", encoding="utf-8", newline="\n") as f:
        f.write(value)

launcher = r'''param([Parameter(Mandatory=$true)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ApprovedPlanSha)
$ErrorActionPreference='Stop'
$directory=$PSScriptRoot
$planPath=Join-Path $directory 'root-plan.json'
if((Get-FileHash -LiteralPath $planPath).Hash -ne $ApprovedPlanSha){throw 'Reviewed root plan hash differs'}
$plan=[IO.File]::ReadAllText($planPath) | ConvertFrom-Json -AsHashtable
foreach($name in $plan.files.Keys){
    if((Get-FileHash -LiteralPath (Join-Path $directory $name)).Hash -ne $plan.files[$name]){
        throw "Reviewed source differs: $name"
    }
}
foreach($path in $plan.local_executable_sha256.Keys){
    if((Get-FileHash -LiteralPath $path).Hash -ne $plan.local_executable_sha256[$path]){
        throw "Reviewed local executable differs: $path"
    }
}
$command=[IO.File]::ReadAllText("$directory/root-command.txt")
$info=[Diagnostics.ProcessStartInfo]::new()
$info.FileName='C:/Windows/System32/OpenSSH/ssh.exe'
$info.UseShellExecute=$false
$info.CreateNoWindow=$true
$info.RedirectStandardInput=$true
$info.RedirectStandardOutput=$true
$info.RedirectStandardError=$true
foreach($argument in '-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8','peters-mac-mini',$command){
    $info.ArgumentList.Add($argument)
}
$out=[IO.File]::Open("$directory/root.stdout.log",'CreateNew','Write','Read')
$err=[IO.File]::Open("$directory/root.stderr.log",'CreateNew','Write','Read')
try {
    $process=[Diagnostics.Process]::Start($info)
    $process.StandardInput.Close()
    $copyOut=$process.StandardOutput.BaseStream.CopyToAsync($out)
    $copyErr=$process.StandardError.BaseStream.CopyToAsync($err)
    $process.WaitForExit()
    $copyOut.GetAwaiter().GetResult() | Out-Null
    $copyErr.GetAwaiter().GetResult() | Out-Null
    $result=$process.ExitCode
    [IO.File]::WriteAllText("$directory/root.ssh-exit.txt",[string]$result)
} finally {
    $out.Dispose()
    $err.Dispose()
}
exit $result
'''
with (HERE / "root-launch.ps1").open("x", encoding="utf-8", newline="\n") as f:
    f.write(launcher)

guard = Path("C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe")
powershell = Path("C:/Users/Peter/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe")
ssh = Path("C:/Windows/System32/OpenSSH/ssh.exe")
inputs = ["root_controller.py", "root-preflight.sh", "root-command.txt", "root-launch.ps1", "prepare.py",
          "../saturated_uid.c", "../PROTOCOL.md", "../native-build-001.json",
          "../ordinary-build-command.txt", "../ordinary-build-launch.ps1", "../ordinary-build.stdout.log",
          "../ordinary-build.stderr.log", "../ordinary-build.ssh-exit.txt"]
plan = {
    "schema": 1, "state": "PREPARED_ONLY_NO_PRIVILEGED_RUN",
    "host": "peters-mac-mini; macOS27 ARM64",
    "ordinary_source_dir": "/private/tmp/ptg-saturated-uid-transfer-002.iUlJHNHK",
    "binary_sha256": native["binary"]["sha256"], "source_sha256": pins["saturated_uid.c"],
    "gtimeout": native["gtimeout"], "target_uid": 60001,
    "scope": "Fixed M8 sequential cases 6,7,8; no account/global settings/payload exec/session change/fork churn",
    "deadlines_seconds": {"windows_job":100,"mac_outer":65,"root_controller":40,"root_primitive_group":25,
                          "gtimeout_kill_after":3,"C_work":14,"C_absolute_cleanup_alarm":15},
    "native_argv": ["<private root scratch>/saturated-uid", "60001", tool],
    "group_policy": "Default gtimeout groups only; native PGID and root_gtimeout_pid must equal exact inner Popen PID",
    "cleanup": "Only after exit0, native valid terminal/exact reaps/UIDempty and independent UID+exactPGIDempty; exact held root identities only. Otherwise leave uncertain artifacts and preserve receipts for quarantine.",
    "trust_boundary": "Trusted local administrator and installed Apple tools/Homebrew executable path; tool held-hash/path checked before/after, not a hostile administrator executable-replacement proof.",
    "limitations": "Does not prove fork publication fence, supervisor death custody, adversarial cleanup, full backend, or comparative performance.",
    "preserved_previous": "001 source, SDK-header compile failure and ordinary compile success, no 001 privileged execution",
    "files": {name: sha(HERE / name) for name in inputs},
    "local_executable_sha256": {str(p).replace('\\','/'):sha(p) for p in (guard,powershell,ssh)},
}
with (HERE / "root-plan.json").open("x", encoding="utf-8", newline="\n") as f:
    f.write(json.dumps(plan, indent=2) + "\n")
plan_sha = sha(HERE / "root-plan.json")
argv = [str(guard).replace('\\','/'), '--timeout', '100', '--', str(powershell).replace('\\','/'),
        '-NoProfile', '-NonInteractive', '-File', str(HERE / 'root-launch.ps1').replace('\\','/'),
        '-ApprovedPlanSha', plan_sha]
with (HERE / "approved-local-argv.json").open("x", encoding="utf-8", newline="\n") as f:
    f.write(json.dumps({"PREPARED_ONLY": True, "approved_plan_sha256": plan_sha, "argv": argv}, indent=2) + "\n")
print(json.dumps({"prepared_only": True,"plan_sha256":plan_sha,
                  "controller_sha256":sha(HERE/'root_controller.py'),
                  "command_sha256":sha(HERE/'root-command.txt'),
                  "launcher_sha256":sha(HERE/'root-launch.ps1'),
                  "files":len(plan['files'])},indent=2))
