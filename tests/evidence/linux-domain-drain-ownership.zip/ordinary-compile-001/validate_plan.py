"""Static AST/hash/shell-argument checks only; no VM/native launch."""
import ast
import base64
import hashlib
import json
from pathlib import Path
import shlex

HERE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
plan_bytes=(HERE/"plan.json").read_bytes()
assert sha(plan_bytes)=="a1be6642ecee082589a298f96cb808b9c1aa7e500d75476ffde8a6de141a2a30"
plan=json.loads(plan_bytes)
for name,digest in plan["files"].items():assert sha((HERE/name).read_bytes())==digest,name
for name,digest in plan["local_executable_sha256"].items():assert sha(Path(name).read_bytes())==digest,name
driver=(HERE/"guest_controller.py").read_text(encoding="utf-8")
ast.parse(driver)
assert "FILTER" not in driver and "authority-tests" not in driver
assert "--emit=obj" in driver
assert plan["object_builds"] == ["activation-main.o", "activation-tests.o"]
assert plan["runtime_test_invocations"] == 0
outer=shlex.split((HERE/"linux-command.txt").read_text(encoding="utf-8"))
assert outer[:6]==[plan["mac_gtimeout"]["path"],"--signal=KILL","--kill-after=3s","80s","/bin/sh","-c"]
assert len(outer)==7 and outer[-1]==(HERE/"mac-preflight.sh").read_text(encoding="utf-8")
preflight=outer[-1]
nested=shlex.split(preflight[preflight.index("\nexec ")+6:])
assert nested[:4]==["/opt/homebrew/bin/limactl","shell","ae1-runner","--"]
assert nested[4:-1]==plan["guest_argv"][:-1]
assert nested[-1]==driver
assert "--foreground"not in nested and "sudo"not in nested
payload=(HERE/"payload.json").read_bytes()
assert sha(payload)==plan["source_payload_sha256"]
entries=json.loads(payload)["files"]
assert set(entries)==set(plan["source_inputs"])
for name,pin in plan["source_inputs"].items():
    raw=base64.b64decode(entries[name],validate=True)
    assert len(raw)==pin["bytes"]and sha(raw)==pin["sha256"],name
receipt={"plan_sha256":sha(plan_bytes),"validator_sha256":sha(Path(__file__).read_bytes()),
         "python_ast":"pass","all_plan_source_and_tool_hashes":"pass","shell_argument_roundtrip":"pass",
         "payload_member_bytes":"pass","native_or_VM_launch":False}
with(HERE/"static-validation.json").open("x",encoding="utf-8",newline="\n")as f:f.write(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
