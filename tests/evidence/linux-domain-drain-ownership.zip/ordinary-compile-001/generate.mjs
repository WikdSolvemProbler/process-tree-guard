import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here=path.dirname(fileURLToPath(import.meta.url));
const arm=path.dirname(here);
const base=path.dirname(arm);
const repo=path.dirname(path.dirname(base));
const sha=b=>createHash('sha256').update(b).digest('hex');
const read=p=>fs.readFile(p);
const put=(name,data)=>fs.writeFile(path.join(here,name),data,{flag:'wx'});
const quote=s=>"'"+s.replaceAll("'","'\"'\"'")+"'";
const join=a=>a.map(quote).join(' ');
const candidateBytes=await read(path.join(arm,'source-candidate.json'));
if(sha(candidateBytes)!=='a9f5bf7a2b001e93cbab98fd647d3dee0ddc2a63703e7094d306fd284edc98b5')throw Error('reviewed source candidate differs');
const candidate=JSON.parse(candidateBytes);
for(const [name,pin]of Object.entries(candidate.files)){
  const data=await read(path.join(arm,name));
  if(sha(data)!==pin.sha256 || data.length!==pin.bytes)throw Error('reviewed source differs: '+name);
}
const modules=['transport.rs','cross_peer.rs','release_lease.rs','prepared_run.rs','native_activation.rs',
  'cgroup_authority.rs','settlement.rs','settlement_fixture.rs','settlement_controls.rs','abi-flags.c'];
const sourceFiles={};
for(const n of modules)sourceFiles['target/codex-security/issue2-linux-cgroup-authority-009/'+n]=await read(path.join(arm,n));
for(const [name,digest]of Object.entries({
  'target/codex-security/issue2-linux-generic-request-001/request.rs':'6531478a6cb85c31ba4639c01c144c789968178df57b64d3d128073a8d91b4c4',
  'src/deadline.rs':'56252eb28270b4743d73e17e05ae933d3fad8168e7b4ba34405e859be9c85c53',
})){
  const data=await read(path.join(repo,name));
  if(sha(data)!==digest)throw Error('inherited source dependency changed: '+name);
  sourceFiles[name]=data;
}
const expected=Object.fromEntries(Object.entries(sourceFiles).map(([n,b])=>[n,{bytes:b.length,sha256:sha(b)}]));
const payload=Buffer.from(JSON.stringify({files:Object.fromEntries(Object.entries(sourceFiles).map(([n,b])=>[n,b.toString('base64')]))})+'\n');
if(payload.length>1024*1024)throw Error('payload bound exceeded');
await put('payload.json',payload);
const template=(await read(path.join(here,'guest_controller.template.py'))).toString('utf8');
const driver=template.replace('@EXPECTED_JSON@',JSON.stringify(expected)).replace('@PAYLOAD_SHA256@',sha(payload));
if(driver.includes('@EXPECTED_JSON@')||driver.includes('@PAYLOAD_SHA256@'))throw Error('unreplaced driver pin');
await put('guest_controller.py',driver);
const guestArgv=['/usr/bin/timeout','--signal=KILL','--kill-after=3s','75s',
  '/usr/bin/systemd-run','--user','--scope','--quiet','--expand-environment=no',
  '--unit','ptg-authority-linux-009.scope','-p','RuntimeMaxSec=70s',
  '-p','KillMode=control-group','-p','KillSignal=SIGKILL','-p','SendSIGKILL=yes',
  '--','/usr/bin/python3','-I','-B','-c',driver];
const tool='/opt/homebrew/Cellar/coreutils/9.12/bin/gtimeout';
const toolSha='6a7b0620313d337d70366cd4d3b969b49854abfeb1db602bdf3328122e223c6d';
const preflight='set -eu\n'+
  "test \"$(/usr/bin/id -u)\" = 501\n"+
  `printf '%s  %s\\n' ${quote(toolSha)} ${quote(tool)} | /usr/bin/shasum -a 256 -c -\n`+
  'exec '+join(['/opt/homebrew/bin/limactl','shell','ae1-runner','--',...guestArgv])+'\n';
const macArgv=[tool,'--signal=KILL','--kill-after=3s','80s','/bin/sh','-c',preflight];
await put('mac-preflight.sh',preflight);
await put('linux-command.txt',join(macArgv)+'\n');
const locals=[
  'C:/Users/Peter/AppData/Local/Temp/codex-guard-replacement-20261105-001/process-tree-guard.exe',
  'C:/Users/Peter/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe',
  'C:/Windows/System32/OpenSSH/ssh.exe',
];
const inputs=['generate.mjs','guest_controller.template.py','guest_controller.py','launch.ps1','METHOD.md',
  'payload.json','mac-preflight.sh','linux-command.txt','../source-candidate.json',
  ...Object.keys(candidate.files).map(n=>'../'+n)];
const files={};for(const n of inputs)files[n]=sha(await read(path.join(here,n)));
const toolPins={};for(const n of locals)toolPins[n]=sha(await read(n));
const plan={schema:1,state:'PREPARED_NO_NATIVE_LAUNCH',purpose:'009 ordinary full-graph and test object compilation only',
  reviewed_source_candidate_sha256:sha(candidateBytes),files,local_executable_sha256:toolPins,
  source_payload_sha256:sha(payload),source_payload_bytes:payload.length,source_inputs:expected,
  mac_gtimeout:{path:tool,sha256:toolSha},native_compiler:{path:'/home/petershiller1.guest/.rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu/bin/rustc',sha256:'b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f'},guest_argv:guestArgv.slice(0,-1).concat('<exact pinned guest_controller.py bytes>'),
  source002_mac_admin:'DEFERRED; no sudo/admin command here',
  deadlines_seconds:{windows_job:100,mac_outer:80,guest_waiting_client:75,linux_user_scope:70,kill_after:3},
  target:'peters-mac-mini -> ordinary Lima ae1-runner UID501 ARM64',
  object_builds:["activation-main.o","activation-tests.o"],runtime_test_invocations:0,
  prohibitions:'No root, cgroup write/provision, payload, concurrency, any prototype executable or harness invocation, root fixture invocation, source rewrite or automatic retry',
  failure_policy:'Preserve raw streams and owned scratch identity; no cleanup in this command; archive before separately reviewed exact ordinary cleanup',
  source_scope:'Owning held-kill-first drain and final-removal split; full graph object compilation only, no reaping/runtime proof'};
const planBytes=Buffer.from(JSON.stringify(plan,null,2)+'\n');
await put('plan.json',planBytes);
const digest=sha(planBytes);
const argv=[locals[0],'--timeout','100','--',locals[1],'-NoProfile','-NonInteractive','-File',
  path.join(here,'launch.ps1').replaceAll('\\','/'),'-ApprovedPlanSha',digest];
await put('local-argv.json',JSON.stringify({prepared_only:true,plan_sha256:digest,argv},null,2)+'\n');
console.log(JSON.stringify({plan_sha256:digest,payload_sha256:sha(payload),payload_bytes:payload.length,
  guest_driver_sha256:sha(Buffer.from(driver)),command_sha256:files['linux-command.txt'],
  launcher_sha256:files['launch.ps1'],files:Object.keys(files).length},null,2));
