"""Ordinary full-graph object compilation only; no harness or activation runs."""
import base64
import hashlib
import json
import os
from pathlib import Path
import selectors
import stat
import subprocess
import sys
import tempfile

EXPECTED = {"target/codex-security/issue2-linux-cgroup-authority-009/transport.rs":{"bytes":16882,"sha256":"907472caaa18f3e4a288f323c8969d85b5b0e494bcfad2cbf65357d24185fee9"},"target/codex-security/issue2-linux-cgroup-authority-009/cross_peer.rs":{"bytes":18353,"sha256":"dab5eb3884ff1711d4396aa422b795cf5747c06a8d647f731e4250028dcd4091"},"target/codex-security/issue2-linux-cgroup-authority-009/release_lease.rs":{"bytes":18547,"sha256":"8b148c0f6a8a445af0e577a669d233c74eed1c75ec4dfd8311e54d70ece20bf4"},"target/codex-security/issue2-linux-cgroup-authority-009/prepared_run.rs":{"bytes":17124,"sha256":"55e302b30dee581f7fe0515847fcdcfa2abd8998775275cb48e705c45a6ea78a"},"target/codex-security/issue2-linux-cgroup-authority-009/native_activation.rs":{"bytes":11189,"sha256":"a9d85a721a69e5d37b124a09b6e3d826af9c75b23903bc19400130b15915b2bc"},"target/codex-security/issue2-linux-cgroup-authority-009/cgroup_authority.rs":{"bytes":18950,"sha256":"7b579ec2a118c10b788f401e0cb32263dc262363a8d12f5576e2da5cb62bea15"},"target/codex-security/issue2-linux-cgroup-authority-009/settlement.rs":{"bytes":13222,"sha256":"b9c7f7b129aadcc591fc6335b4a438975b39fbf0342c2ae762e9f51774abe26a"},"target/codex-security/issue2-linux-cgroup-authority-009/settlement_fixture.rs":{"bytes":7825,"sha256":"b6dc0456d2f30a37dc6222167044e9458dcb05fabfa2636626311b3a964b7058"},"target/codex-security/issue2-linux-cgroup-authority-009/settlement_controls.rs":{"bytes":3515,"sha256":"e45852239c8e67e85f94d01558f20df8c655e14bffcb683c6158ceeb1198388a"},"target/codex-security/issue2-linux-cgroup-authority-009/abi-flags.c":{"bytes":273,"sha256":"dabf258922de316924704d822c48160eb9d489289496ee18f45bfc5a8000d4c2"},"target/codex-security/issue2-linux-generic-request-001/request.rs":{"bytes":9207,"sha256":"6531478a6cb85c31ba4639c01c144c789968178df57b64d3d128073a8d91b4c4"},"src/deadline.rs":{"bytes":1171,"sha256":"56252eb28270b4743d73e17e05ae933d3fad8168e7b4ba34405e859be9c85c53"}}
PAYLOAD_SHA256 = "8bcf05cc086113301712dd4440b28c2bf33b4497a99ffba89bc8a4ae890503d5"
UNIT = "ptg-authority-linux-009.scope"
CONTROL_GROUP = "/user.slice/user-501.slice/user@501.service/app.slice/" + UNIT
COMPILER = "/home/petershiller1.guest/.rustup/toolchains/1.99.0-aarch64-unknown-linux-gnu/bin/rustc"
COMPILER_SHA256 = "b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f"

def demand(value, text):
    if not value:
        raise RuntimeError(text)

def write_all(fd, data):
    while data:
        n = os.write(fd, data)
        demand(n > 0, "short retained stream write")
        data = data[n:]

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for part in iter(lambda: f.read(65536), b""):
            h.update(part)
    return h.hexdigest()

tree = None
try:
    os.umask(0o077)
    demand(os.getuid() == 501 and os.geteuid() == 501, "ordinary UID501 required")
    demand(os.getgid() != 0 and os.getegid() != 0, "root group refused")
    demand(os.uname().machine == "aarch64", "ARM64 qualification only")
    scope = Path("/proc/self/cgroup").read_text().strip()
    demand(scope == "0::" + CONTROL_GROUP, "unexpected actual user scope")
    prop = subprocess.run(["/usr/bin/systemctl", "--user", "show", UNIT,
                           "-p", "RuntimeMaxUSec", "-p", "KillMode", "-p", "KillSignal",
                           "-p", "SendSIGKILL", "-p", "ControlGroup", "-p", "ActiveState"],
                          capture_output=True, text=True, timeout=3)
    print("SCOPE_PROPERTIES=" + json.dumps({"stdout": prop.stdout, "stderr": prop.stderr,
          "exit": prop.returncode, "actual_cgroup": scope}), flush=True)
    demand(prop.returncode == 0, "effective scope query refused")
    properties = dict(line.split("=", 1) for line in prop.stdout.splitlines())
    for key, value in {"RuntimeMaxUSec": "1min 10s", "KillMode": "control-group", "KillSignal": "9",
                       "SendSIGKILL": "yes", "ControlGroup": CONTROL_GROUP, "ActiveState": "active"}.items():
        demand(properties.get(key) == value, "effective finite scope property differs: " + key)
    packet = sys.stdin.buffer.read(1024 * 1024 + 1)
    demand(len(packet) <= 1024 * 1024 and hashlib.sha256(packet).hexdigest() == PAYLOAD_SHA256,
           "exact source payload differs")
    entries = json.loads(packet)["files"]
    demand(set(entries) == set(EXPECTED), "source member set differs")
    tree = Path(tempfile.mkdtemp(prefix="ptg-authority-linux-009.", dir="/tmp"))
    held = tree.stat()
    demand(held.st_uid == 501 and stat.S_IMODE(held.st_mode) == 0o700, "scratch custody differs")
    print("ORDINARY_SCRATCH=" + json.dumps({"path": str(tree), "device": held.st_dev,
          "inode": held.st_ino, "uid": held.st_uid, "mode": stat.S_IMODE(held.st_mode)}), flush=True)
    for name, pin in EXPECTED.items():
        data = base64.b64decode(entries[name], validate=True)
        demand(len(data) == pin["bytes"] and hashlib.sha256(data).hexdigest() == pin["sha256"],
               "source bytes differ: " + name)
        path = tree / name
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with path.open("xb") as f:
            f.write(data)
        demand(digest(path) == pin["sha256"], "staged source differs: " + name)
    os.environ["TMPDIR"] = str(tree)
    os.chdir(tree)

    def command(argv, tag):
        print("NATIVE_ARGV=" + json.dumps({"tag": tag, "argv": argv}), flush=True)
        out_path, err_path = tree / (tag + ".stdout.log"), tree / (tag + ".stderr.log")
        with out_path.open("xb") as out, err_path.open("xb") as err:
            child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, close_fds=True)
            print("NATIVE_CHILD=" + json.dumps({"tag": tag, "pid": child.pid}), flush=True)
            with selectors.DefaultSelector() as selector:
                selector.register(child.stdout, selectors.EVENT_READ, (out, 1))
                selector.register(child.stderr, selectors.EVENT_READ, (err, 2))
                while selector.get_map():
                    for key, events in selector.select(timeout=0.1):
                        data = os.read(key.fileobj.fileno(), 4096)
                        if not data:
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                            continue
                        retained, transport = key.data
                        retained.write(data)
                        retained.flush()
                        write_all(transport, data)
            code = child.wait()
        (tree / (tag + ".exit.txt")).write_text(str(code))
        print("NATIVE_EXIT=" + json.dumps({"tag": tag, "pid": child.pid, "exit": code,
              "stdout_sha256": digest(out_path), "stderr_sha256": digest(err_path)}), flush=True)
        demand(code == 0, "native step failed: " + tag)
        return out_path

    demand(digest(Path(COMPILER)) == COMPILER_SHA256, "pinned native compiler differs")
    print("NATIVE_CONTEXT=" + json.dumps({"pid": os.getpid(), "uid": os.getuid(),
          "uname": list(os.uname()), "compiler": COMPILER, "compiler_sha256": digest(Path(COMPILER)),
          "gcc_sha256": digest(Path("/usr/bin/gcc")), "payload_executions": 0,
          "root_fixture_executions": 0, "cgroup_writes": 0}), flush=True)
    command([COMPILER, "--version", "--verbose"], "compiler-version")
    for testing, output_name in ((False, "activation-main.o"), (True, "activation-tests.o")):
        args = [COMPILER, "--edition=2021", "-D", "warnings", "--emit=obj"]
        if testing:
            args.append("--test")
        args.extend(["target/codex-security/issue2-linux-cgroup-authority-009/transport.rs", "-o", output_name])
        command(args, "compile-test-object" if testing else "compile-main-object")
        print("NATIVE_OBJECT=" + json.dumps({"path": str(tree / output_name),
              "test_object": testing, "sha256": digest(tree / output_name)}), flush=True)
    for name, pin in EXPECTED.items():
        demand(digest(tree / name) == pin["sha256"], "source changed during qualification: " + name)
    inventory = {str(p.relative_to(tree)): {"bytes": p.stat().st_size, "sha256": digest(p),
                 "device": p.stat().st_dev, "inode": p.stat().st_ino}
                 for p in sorted(tree.rglob("*")) if p.is_file()}
    (tree / "ordinary-inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
    print("ORDINARY_COMPONENT_COMPLETE=" + json.dumps({"object_builds_passed": 2,
          "scratch_retained": str(tree), "scratch_identity": [held.st_dev, held.st_ino],
          "file_inventory": inventory, "payload_executions": 0, "root_fixture_executions": 0,
          "cgroup_writes": 0, "scope": "full actual graph ordinary and test object compilation only; no harness execution"}), flush=True)
except BaseException as error:
    print("ORDINARY_COMPONENT_REFUSED=" + json.dumps({"error": type(error).__name__ + ": " + str(error),
          "scratch_retained": None if tree is None else str(tree),
          "policy": "preserve raw failure and owned artifacts before exact identity cleanup; no retry/root fallback"}), flush=True)
    raise
