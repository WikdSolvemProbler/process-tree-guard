# Owning drain/removal split candidate009

SOURCE ONLY at preparation: no compiler, harness or native activation has run for009.
This fresh graph preserves008 and its receipts. The inherited Rust changes are
settlement.rs, the authority module's internal settlement visibility, and the
existing fixture/control signature adaptations. No production backend is enabled.

The former DomainControls::settle removed the leaf and dropped controls after
empty-domain success. A later child-reap error could no longer retain those
authorities. Production now has terminate_and_drain instead. Its first native
operation remains the original held supervisor-kill write, before any clock,
timer allocation or path validation. Failed/short writes retain original controls
and outcome, with no cleanup authority and no wait. Successful writes enter the
existing finite deadline/validate/populated-wait path.

The shared terminate_then helper now returns its actual custody on success as
well as failure. terminate_and_drain returns DrainedDomain owning all original
DomainControls, the same armed cleanup Deadline and a DrainReceipt containing the
verified empty observation, kill outcome, post-kill clock observation, identity,
poll wakeups and absolute cleanup deadline. Nothing is unlinked or closed merely
because drainage succeeded. The original execution lease remains a separate
PreparedRun resource; this component never rearms or extends that lease.

The cleanup deadline is stored before the post-arm check. Every returned error
after successful timerfd_settime retains that actual armed Deadline along with
controls, kill outcome and the available post-kill timestamp. Setup failures
before successful arming may close a newly allocated unused timer and retain no
usable cleanup Deadline; no wait is entered in that state. Waiting still requires
a successfully armed owned Deadline and checks it before polling. An already-past
deadline still requests held termination before returning quarantine.

Final removal is a separate consuming DrainedDomain::remove_after_reaping method.
It uses only the retained cleanup Deadline: there is no new timer creation or
rearm. It checks time, revalidates the original controls/name, removes the exact
leaf and confirms absence before that same bound. Every error retains controls,
the same Deadline, DrainReceipt and kill outcome; removal_succeeded distinguishes
failure before unlink from failure after unlink/confirmation. Only fully confirmed
success releases those resources into a RemovedDomain receipt.

remove_after_reaping is internal and unsafe under an explicit trusted-caller
contract: all payload, watchdog and adopted children must already be reaped, the
permit closed and further placement prevented. Its name and unsafe declaration
are not a proof that a native reaper has done this. The reaper/controller remains
unimplemented and must eventually seal that ordering. Read-only borrowed receipt
and deadline/timer access is provided for that next concrete component; it cannot
construct or rearm a Deadline through this API.

The old production settle convenience no longer exists. The cfg(test) empty
fixture explicitly drains, then calls removal with a local safety explanation:
it has never created a child, watchdog, permit or payload. It is the only current
removal caller and is not executed by the proposed qualification. Its separate
test-root removal remains fixture-only. Existing signature checks now compile
the actual owning drain, unsafe final-remove and borrowed-deadline APIs. Existing
helper controls are adapted only for the retained-custody success tuple; no new
mock behavior, fake reaper token or runtime fault-coverage claim is introduced.

After exact source review, the proposed qualification is ordinary Linux ARM64
whole-graph object and test-object generation with warnings denied, using the
same finite70s user scope/75s guest client/80s Mac/100s Windows chain as008. No
compiled prototype, harness, root fixture, payload or concurrency test is to run.
Source/tool/command/object hashes, every raw output and exact ordinary cleanup
must be preserved. A compiler pass establishes native API acceptance only.

Limits remain: a kernel write or validation syscall can block; independent finite
watchdog coverage and a pre-established full-run cleanup policy are still needed.
Returned ownership does not protect against drop, panic or process death. No
payload/watchdog pidfd waitid reaper, subreaper, exec-result channel, populated
cleanup proof or consuming full terminal controller is implemented here. Earlier
qualified007/008 evidence is preserved, not reinterpreted as009 runtime evidence.
