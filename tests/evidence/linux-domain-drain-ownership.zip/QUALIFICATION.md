# Owning domain drainage: source and native compiler evidence

Candidate009 replaces production DomainControls::settle with terminate_and_drain.
The original held kill attempt still precedes clock reads, timer setup and path
checks. Successful drainage now returns DrainedDomain owning every original
control, the actual same armed cleanup Deadline and its empty/kill receipt. The
helper retains custody on success and error. The deadline is stored before its
post-arm check, so later returned errors retain that armed authority.

Final removal is separate and consuming. It creates/rearms no timer and retains
controls, deadline, drain/kill receipts and removal_succeeded on failure. The
internal unsafe remove_after_reaping caller contract requires actual prior reaping,
a closed permit and prevention of further placement. Neither its name nor its
unsafe declaration proves those obligations. The native reaper remains future
work. Only the cfg(test) empty fixture currently calls removal; that fixture has
no child, watchdog or permit and was not executed here. There is no production
settle convenience or automatic Drop cleanup claim.

Root and independent critic approved exact source-candidate.json SHA
a9f5bf7a2b001e93cbab98fd647d3dee0ddc2a63703e7094d306fd284edc98b5
for ordinary whole-graph/test-object compilation only. REVIEW.json records the
narrow review scope. All13 reviewed source entries retain their exact lengths
and hashes after compilation. The four changed inherited Rust files are included
alongside their008 baselines. Earlier008 evidence remains bound by archive SHA
c19869448c84258d15f47ebef214e38c6b57d1d1817d23e89f55eaad3d65a155.

Exactly one ordinary Linux ARM64 VM attempt ran under plan
a1be6642ecee082589a298f96cb808b9c1aa7e500d75476ffde8a6de141a2a30.
The environment was kernel6.8.0-147-generic, with pinned Rust1.99 compiler SHA
b3a6b57674bb153f842dbed5de751b35fe9464768cb986f469451b6480b1ba5f.
The real module graph compiled twice with edition2021, -D warnings and --emit=obj,
ordinary and with --test. Both returned0 with empty compiler streams. No compiled
prototype or test harness was linked or invoked. No reaper, arming, root fixture,
payload or runtime cgroup component executed. Existing signature/control code
was compiled only and is not counted as a009 runtime test.

The actual user scope was verified before staging to use RuntimeMax70s,
KillMode control-group, KillSignal9 and SendSIGKILLyes. Independent guest waiting
client75s, Mac80s and Windows Job100s deadlines bounded the enclosing chain.
The Windows diagnostic worker explicitly held native profiling until this
compile/preservation/cleanup window ended; no diagnostic run is scored here.

The preserved ARM64 ELF64 little-endian relocatable objects are:

* activation-main.o:1,013,856bytes; SHA
  1dd30d86d47ac122c2b98da8be36e3aaebcff5f04b464727876b6e9f15c8c0a6.
* activation-tests.o:1,104,824bytes; SHA
  edca4688a274227512a9924d335220a4e9b436cbc18cdf2f4b89a5b1a7f48248.

Local header inspection confirmed relocatable type1/machine183 without executing
either output. Exact sources/dependencies, tool/payload/command pins, native
context, compiler version, child PIDs, exits, all raw streams and both object
bytes are preserved. SOURCE_ONLY preparation snapshots remain unchanged as
chronology; RESULTS.json records the later actual compilation and cleanup.

Independent ordinary checks found the original unit not loaded/inactive, its
exact cgroup path absent and all four recorded controller/compiler PIDs absent.
The preserved scratch was only /tmp/ptg-authority-linux-009.i5c9axri, UID501,
dev64769 inode1111952. All24 files matched the exact completion inventory,
lengths, hashes and recorded inodes and were downloaded and locally verified.
PID absence is reported without inventing creation timestamps.

A full pre-removal ZIP was verified first: SHA
de392753f70f8d68e2559a85cac3f8a060bfeacf4f146c6ff1e7ab53691a0d7f,
1,653,902bytes,63members. The subsequent bounded ordinary cleanup repeated the
worker/scope checks, opened the exact private scratch with retained no-follow
descriptors, compared identities/hashes/modes/inventory, unlinked only those24
files and their verified empty directories and confirmed the original scratch
absent. Every removal is recorded. No root or guessed recursive deletion was used.
The local pre-removal ZIP is not nested here; its evidence members appear
directly alongside the later cleanup receipts.

This establishes native compiler acceptance of the actual owning phase APIs.
It does not qualify populated drainage, actual post-arm error behavior, final
removal after native reaping or a complete terminal controller. Kernel syscalls
can still block, and ownership does not protect against drop, panic or death.
The original execution lease is not extended; the full-run pre-established
cleanup/watchdog policy remains to be integrated. pidfd/waitid reaping, subreaper
ownership and exec-result distinction remain separate next work. No production
backend, performance, supported-kernel-floor or concurrency qualification is
claimed, and no previously rejected experiment was resumed.

INDEX.json gives exact lengths and SHA-256 for every other public member.
Archive CRC, membership and exact bytes are verified. No tracked documentation
or Git history was changed by this task.
